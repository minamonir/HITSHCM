CREATE   FUNCTION [dbo].[X_PMS_GetOldValue]
  (@ProfileId int,@FieldNo int, @EffectiveDate smalldatetime, @ToCurrency smallint=null)
	
RETURNS numeric(18,3)
AS
 BEGIN
 /* sql statement ... */
 declare @oldvalue numeric(18,3)
 declare @OldEffectiveDate smalldatetime
  set @OldEffectiveDate = @EffectiveDate
 declare @FromCurrency smallint
 declare @hiredate smalldatetime
 select @hiredate=isnull(profile.firsthireddate,empassignment.hiredate) from empassignment inner join profile on empassignment.empid=profile.profileid where empid=@ProfileId 

if @EffectiveDate<=@hiredate    
  select @oldvalue=case  @FieldNo 
         when 5 then null
         when 6 then null
         when 7 then null
         when 8 then null
         when 9 then null
         when 10 then null
         when 19 then NULL
         when 21 then null
         when 28 then null
         else 0.00 end  
else
  begin
   	IF @FieldNo<>15
  	BEGIN
	    select top 1 @oldvalue=NewValue, @FromCurrency=EmpStatusHdr.HrCurrency , @OldEffectiveDate =EffectiveDate from  EmpStatusHdr INNER JOIN  EmpStatusDtl ON EmpStatusHdr.EmpId = EmpStatusDtl.EmpId 
        AND EmpStatusHdr.DocumentNo = EmpStatusDtl.DocumentNo  where @ProfileId=EmpStatusHdr.EmpId and 
       @FieldNo=FieldNo and  EffectiveDate<@EffectiveDate and 
       dbo.EmpStatusHdr.DocumentStatus=1 order by EffectiveDate DESC,EmpStatusDtl.NewValue DESC
  	END
  	ELSE
  	BEGIN
  		-------calc total salary
		set @oldvalue=[dbo].[calcEmpTotalSal](@ProfileId, @EffectiveDate-1,1)
		SELECT  @FromCurrency=empassignment.HrCurrency,@OldEffectiveDate=@EffectiveDate-1
		FROM empassignment WHERE empid=@ProfileId
  	END
  	
    if @oldvalue is null 
        if @FieldNo>1000  select @oldvalue=isnull(inputamnt,0),@FromCurrency=empassignment.hrcurrency from hrpcodes inner join  empassignment on  empassignment.empid=hrpcodes.empid
                    where hrpcodes.empid=@profileid and hrpcodes.paycode= @FieldNo-1000
         else     select @oldvalue=case  @FieldNo 
               when 1 then isnull(hrstatus,0)
               when 2 then isnull(HrTaxStat,0)
               when 3 then isnull(milstatus,0)
               when 4 then isnull(socstatus,0)
               when 5 then job
               when 6 then organization
               when 7 then grade
               when 8 then positionno
               when 9 then locationno
               when 10 then employerid
               when 11 then isnull(hrscstatus,0.00)
               when 12 then isnull(hrssappl,0.00)         
               when 13 then isnull(hrpoints,0.00)         
               when 14 then isnull(hrbasicsal,0.00)
               when 15 then isnull(hrtotalsal,0.00)
               when 16 then isnull(hrssfixval,0.00)
               when 17 then isnull(hrssvarval,0.00)
               when 18 then isnull(hrssbonval,0.00)
               when 19 then vacpack
               when 20 then isnull(ContBasSal,0.00)
               when 21 then SSGroup
               when 22 then SalaryScaleId
               when 23 then ContractType
               when 24 then isnull(cast(convert(nchar(8),ContStart,112) as numeric(8)),0) 
               when 25 then isnull(cast(convert(nchar(8),ContEnd,112) as numeric(8)),0) 
               when 26 then isnull(cast(convert(nchar(8),ProbDate,112) as numeric(8)),0)  
               when 27 then isnull(cast(convert(nchar(8),RevisedHireDate,112) as numeric(8)),0) 
               when 28 then TimeRule
               else null end 
               ,@FromCurrency= CASE WHEN @fieldno=20 THEN isnull(ContBasCur,empassignment.hrcurrency) ELSE empassignment.hrcurrency end
                  from empassignment inner join profile on empassignment.empid=profile.profileid where empassignment.empid=@profileid
          
 end 
if @FieldNo>1000 or @FieldNo in (14,15,16,17,18,20) set @oldvalue=0.00
return isnull(@oldvalue,0.000)

END

GO

