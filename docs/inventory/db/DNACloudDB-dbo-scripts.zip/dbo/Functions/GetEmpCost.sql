-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE  FUNCTION [dbo].[GetEmpCost]
(
	@CostItemType AS INT,
	@Event AS INT
)
RETURNS NUMERIC(18, 3) 
AS
BEGIN
	DECLARE @cost AS NUMERIC(18, 3)
	    SET @Cost = 
	           ( SELECT SUM(
	                       dbo.ConvertAmount(
	                           EmpTrainingCostItems.CostItemAmount,
	                           EmpTrainingCostItems.CostItemCurrency,
	                           TrainingEvents.PriceCurrency,
	                           EmpTrainingCostItems.CostItemDate
	                       )
	                   )
	        
	        FROM EmpTraining
	        LEFT JOIN EmpTrainingCostItems ON EmpTrainingCostItems.EmpId = EmpTraining.EmpId
	        AND EmpTrainingCostItems.DocumentNo = EmpTraining.DocumentNo
	        INNER JOIN Profile ON Profile.ProfileId=EmpTraining.EmpId AND PROFILE.PersonType=8 
	        LEFT JOIN TrainingCostItems	ON TrainingCostItems.TrainingCostItem = EmpTrainingCostItems.TrainingCostItem
	        LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
	        LEFT JOIN TrainingEnrollStatus On EmpTraining.EnrollStatus=TrainingEnrollStatus.EnrollStatus 
	        WHERE EmpTraining.TrainingEvent=@Event AND TrainingCostItems.TrainingCostItemType=@CostItemType
	        AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4) AND EmpTraining.TrainingEvent IS NOT NULL )
	
	RETURN isnull(@Cost,0)
END

GO

