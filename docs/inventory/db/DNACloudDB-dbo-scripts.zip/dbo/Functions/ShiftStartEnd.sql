CREATE  FUNCTION [dbo].[ShiftStartEnd] (@empid AS INT ,@date AS SMALLDATETIME,@Type AS SMALLINT,@Part AS SMALLINT  )
RETURNS datetime 
--@Empid               => Empid
--@Date                  => Shift date 
--@Type                  => 1(shift From)    2 (shift To)
-- @Part                    => 1 (part 1)   2 (part 2)

AS 

BEGIN 
DECLARE @ShiftStartEnd DATETIME ,@ShiftNo AS SMALLINT ,@ShiftType AS SMALLINT,@FromTime AS NVARCHAR(5),
@ToTime AS NVARCHAR(5),@FromTime1 AS NVARCHAR(5),@ToTime1 AS NVARCHAR(5)


SELECT  @ShiftNo=EmpShift.ShiftNo ,@ShiftType=ShiftType,@FromTime=FromTime,@ToTime=ToTime,@FromTime1=FromTime1,@ToTime1=ToTime1
FROM  EmpShift
LEFT JOIN dbo.TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo
WHERE  EmpShift.empid=@empid AND EmpShift.shiftdate =@date

IF @Part=2 AND @ShiftType<>2 RETURN convert(datetime,convert(nchar(10),@date,120)+' '+'00:00',120) --'00:00'--null--------not splitted shift

IF(@ShiftType=2)
BEGIN 
SELECT @ShiftStartEnd= CASE WHEN @Type=1 AND @Part=1 THEN convert(datetime,convert(nchar(10),@date,120)+' '+@FromTime,120)
WHEN @Type=2 AND @Part=1 THEN( CASE when convert(datetime,convert(nchar(10),@date,120)+' '+@FromTime,120) >convert(datetime,convert(nchar(10),@date,120)+
' '+@ToTime,120) THEN convert(datetime,convert(NCHAR  (10),@date,120)+' '+@ToTime,120)+1 ELSE convert(datetime,convert(nchar(10),@date,120)+' '+@ToTime,120) END)
WHEN @Type=1 AND @Part=2 THEN (case when @FromTime1='00:00' or ltrim(@FromTime1)='' or @FromTime1='  :  ' or @TOTime1='00:00' or ltrim(@TOTime1)='' or @TOTime1='  :  ' then null ELSE CONVERT(datetime,convert(NCHAR (10),@date,120)+' '+@FromTime1,120) END )
WHEN @Type=2 AND @Part=2 THEN ISNULL(CASE when convert(datetime,convert(nchar(10),@date,120)+
' '+@FromTime1,120)  > convert(datetime,convert(NCHAR(10),@date,120)+' '+@ToTime1,120) THEN  CONVERT (datetime,convert(nchar(10),@date,120)+' '+@ToTime1,120)+1 ELSE  convert(datetime,
CONVERT(nchar(10),@date,120)+' '+@ToTime1,120)  END,0)   END 


                                
END

IF(@ShiftType=6)
BEGIN 
	SELECT @ShiftStartEnd = CASE WHEN @Type=1 THEN  MIN(shiftin) WHEN @Type=2 THEN MAX(shiftout) END
	FROM  empshiftinout 
	WHERE  empshiftinout.empid=@empid AND empshiftinout.EntryDate =@date AND shiftin IS NOT NULL  AND shiftout IS NOT null     
	              
END
								
IF(@ShiftType NOT IN(2,6))
BEGIN
SELECT @ShiftStartEnd =	CASE WHEN @Type=1 AND @Part=1 THEN convert(datetime,convert(nchar(10),@date,120)+' '+@FromTime,120)
WHEN @Type=2 AND @Part=1 THEN( CASE when convert(datetime,convert(nchar(10),@date,120)+' '+@FromTime,120) >convert(datetime,convert(nchar(10),@date,120)+
' '+@ToTime,120) THEN convert(datetime,convert(NCHAR  (10),@date,120)+' '+@ToTime,120)+1 ELSE convert(datetime,convert(nchar(10),@date,120)+' '+@ToTime,120) END) END
                              
END 
RETURN  convert(datetime,@ShiftStartEnd,120) 
END

GO

