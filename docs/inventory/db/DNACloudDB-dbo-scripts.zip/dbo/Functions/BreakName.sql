
CREATE   FUNCTION [dbo].[BreakName] (@inc_expr nvarchar(100), @namepart smallint)
RETURNS Nvarchar(20)
BEGIN 
  set @inc_expr=ltrim(rtrim(@inc_expr))
  declare @first_name nvarchar(100), @mid_name nvarchar(100), @last_name nvarchar(100),@fourth_name nvarchar(100)
  declare @first_off smallint, @last_off smallint, @temp_off smallint, @n smallint,@second_off smallint
  set @first_name=N''
  set @mid_name=N''
  set @last_name=N''
  SET @fourth_name=N''
  set @first_off=0
  set @last_off=0
  set @n=1
  WHILE 1=1
  Begin
    set @temp_off=CHARINDEX(N' ', @inc_expr, @n)
    IF @temp_off=0
      BREAK
    IF @n=1 set @first_off=@temp_off
           SET @second_off=CHARINDEX(N' ',@inc_expr,charindex(N' ',@inc_expr,1)+1)
           set @last_off=@temp_off
      
    set @n=@n+1
    CONTINUE
  END

  IF (select fullnameorder from sysparam)=2 --&& last first
    set @last_name=@inc_expr
  IF @last_off<>0
  Begin
    set @first_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @last_off, 60)))
    set @last_name=rTRIM(ltrim(SUBSTRING(@inc_expr, 1, @last_off)))
  END
  
  
  
  IF (select fullnameorder from sysparam)=3 --&& first last
  Begin
    set @first_name=@inc_expr
    IF @first_off<>0
    Begin
      set @first_name=rTRIM(ltrim(SUBSTRING(@inc_expr, 1, @first_off)))
      set @last_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @first_off, 60)))
    END
  End
  If (select fullnameorder from sysparam)<>2 and (select fullnameorder from sysparam)<>3 --&& first middle last
  Begin
    set @first_name=@inc_expr
    IF @first_off<>0
    Begin
      set @first_name=rTRIM(ltrim(SUBSTRING(@inc_expr, 1, @first_off)))
      IF @second_off>@first_off AND @last_off>@second_off
          BEGIN
          	SET @mid_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @first_off,@second_off-@first_off)))
          	SET @last_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @second_off, @last_off-@second_off)))
          	SET @fourth_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @last_off, 60)))
          END
       ELSE IF @second_off>@first_off AND @last_off=@second_off   
    BEGIN
    	SET @mid_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @first_off,@second_off-@first_off)))
        SET @last_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @second_off, 60)))
    END
    
     ELSE IF @last_off=@first_off
      
        set @last_name=rTRIM(ltrim(SUBSTRING(@inc_expr, @last_off, 60)))
    END
  End
  
  
  if @first_name=N'' set @first_name=N'?'
  if @last_name=N'' set @last_name=N'?'
  
  Return (case when @namepart=1 then @first_Name when @namepart=2 then cast(@mid_Name as Nvarchar(20)) when @namepart=3 then @last_Name WHEN @namepart=4 THEN @fourth_name else Null end)
  
END

GO

