

CREATE   FUNCTION dbo.GetPersonType
  (@ProfileId int)
RETURNS  smallint
as
BEGIN 
/*([dbo].[GetPersonType]([ProfileId]))*/
  declare @returntype as smallint
  declare @returntype1 as smallint
  declare @returntype2 as smallint
  set  @returntype2=0
  set  @returntype1=0
  set  @returntype=0
  select @returntype=isnull(hrstatus.paystatus,0) from empassignment left join hrstatus on empassignment.hrstatus=hrstatus.hrstatus where empid=@ProfileId
  if @returntype>1 set @returntype=4  /*ex-employee*/
  if @returntype=1 set @returntype=3  /*employee*/
  select top 1 @returntype1=isnull(ApplicationStatus.ApplicationSystemStatus,0) from appassignment inner join ApplicationStatus on appassignment.ApplicationStatus=ApplicationStatus.ApplicationStatus where empid=@ProfileId order by 1
  select top 1 @returntype2=isnull(ApplicationStatus.ApplicationSystemStatus,0) from appassignment inner join ApplicationStatus on appassignment.ApplicationStatus=ApplicationStatus.ApplicationStatus where empid=@ProfileId and ApplicationStatus.ApplicationSystemStatus=6
  /* check if he is applicant*/ 
  if @returntype=0 and @returntype1<>6 and @returntype1<>0 set @returntype=1  /*applicat*/
  if @returntype=0 and @returntype1=6 set @returntype=2  /*ex-applicat*/
  if @returntype=3 and @returntype1=0 set @returntype=3  /*employee*/
  if @returntype=4 and (@returntype1=6 or @returntype1=0) set @returntype=4  /*ex-employee*/
  if @returntype=3 and @returntype1<>6 and @returntype1<>0 set @returntype=5  /*employee & applicat*/
  if @returntype=3 and @returntype1<>6 and @returntype1<>0 and @returntype2=6 set @returntype=6  /*applicat & ex-applicat*/
  if @returntype=4 and @returntype1<>6 and @returntype1<>0 set @returntype=7  /*ex-employee & applicat*/
  if @returntype=0 and @returntype1=0 set @returntype=8  /*external*/
  return @returntype
END

GO

