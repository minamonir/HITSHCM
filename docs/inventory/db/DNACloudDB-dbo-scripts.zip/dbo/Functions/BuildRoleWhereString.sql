

CREATE FUNCTION [dbo].[BuildRoleWhereString]
(
	@Logonname nvarchar(80),
	@RoleField nvarchar(max),
	@RoleID int=0
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
declare @ProfileId as int
select @ProfileId = empid from nasusers where ltrim(rtrim(logonname)) = ltrim(rtrim(@logonname))

	DECLARE @AllRoles AS NVARCHAR(MAX) = ' 1=2 ', @RoleIDS AS NVARCHAR(MAX)
	SELECT @AllRoles=CASE WHEN @RoleID=0 THEN (SELECT STUFF((
         SELECT DISTINCT ' OR '+@RoleField+' LIKE ''%#' + LTRIM(RTRIM(STR(SSGroupRole.RoleId)))+'#%'''
            FROM dbo.SSGroupRole
			INNER JOIN dbo.SSRole ON SSRole.RoleId = SSGroupRole.RoleId 
			WHERE  dbo.SSGroupRole.ProfileId =@ProfileId
            FOR XML PATH('')
         ), 1, 3, '')) ELSE @RoleField +' LIKE ''%#' + LTRIM(RTRIM(STR(@RoleID)))+'#%''' END
		  SELECT @AllRoles=@AllRoles+' OR '+LTRIM(RTRIM(@RoleField))+'='''' '

--	SELECT @RoleIDS= STUFF((
--         SELECT DISTINCT ',' + LTRIM(RTRIM(STR(SSGroupRole.RoleId)))
--            FROM dbo.SSGroupRole
--			INNER JOIN dbo.SSRole ON SSRole.RoleId = SSGroupRole.RoleId 
--			WHERE  dbo.SSGroupRole.ProfileId = @ProfileId
--            FOR XML PATH('')
--         ), 1, 1, '')

--		 --Print @RoleIDS

--		 DECLARE @curRole AS NVARCHAR(10)
--IF @Type = 1
--BEGIN
--	WHILE @RoleIDs <> ''
--	BEGIN
--	IF CHARINDEX(',', @RoleIDS) = 0
--		BEGIN
--			SELECT @RoleWhere = @RoleWhere + N' OR VacationRoles like N''%#'+ @RoleIDS +'#%'' '
--			SELECT @RoleIDs = N''
--		END
--	    ELSE
--        BEGIN
--			SELECT @curRole = SUBSTRING(@RoleIDs,0, CHARINDEX(',', @RoleIDS) - 1)
--			SELECT @RoleWhere = @RoleWhere + N' OR VacationRoles like N''%#'+ @curRole +'#%'' '
--			SELECT @RoleIDS = SUBSTRING(@RoleIDs, CHARINDEX(',', @RoleIDS) + 1, LEN(@RoleIDS) - CHARINDEX(',', @RoleIDS) + 1)
--		end
		
--	END
--END

	--RETURN @RoleWhere
	RETURN @AllRoles
END

GO

