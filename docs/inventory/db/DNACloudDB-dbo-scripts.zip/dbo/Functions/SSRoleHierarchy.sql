
CREATE     Function [dbo].[SSRoleHierarchy] (@empid As Int, @RoleId As Int)
RETURNS  nvarchar(max) AS 
begin

declare @str as nvarchar(max),@EmpName as nvarchar(60),@Empid2 as int
set @EmpName=(select ltrim(rtrim(Profile.Name)) from Profile where Profile.ProfileId=@empid)
set @str=N''

while ((SELECT  count(Profile.ProfileId)
FROM         EmpAssignment Left JOIN
                      SSGroupRole ON EmpAssignment.SSGroup = SSGroupRole.SSGroup Left JOIN
                      Profile ON SSGroupRole.ProfileId = Profile.ProfileId
WHERE     (EmpAssignment.EmpId = @empid) AND (SSGroupRole.RoleId = @RoleId))<>0)
begin
set @str=cast((SELECT  rtrim(ltrim(Profile.Name))
FROM         EmpAssignment Left JOIN
                      SSGroupRole ON EmpAssignment.SSGroup = SSGroupRole.SSGroup Left JOIN
                      Profile ON SSGroupRole.ProfileId = Profile.ProfileId
WHERE     (EmpAssignment.EmpId = @empid) AND (SSGroupRole.RoleId = @RoleId)) as nvarchar(60))+N' > '+@str

set @Empid2=@empid
set @empid=(SELECT  distinct   Profile.ProfileId
FROM         EmpAssignment Left JOIN
                      SSGroupRole ON EmpAssignment.SSGroup = SSGroupRole.SSGroup Left JOIN
                      Profile ON SSGroupRole.ProfileId = Profile.ProfileId
WHERE     (EmpAssignment.EmpId = @empid) AND (SSGroupRole.RoleId = @RoleId))

if @empid=@Empid2
begin
set @empid=0
end

end
set @str=@str+@EmpName
return @str

end

GO

