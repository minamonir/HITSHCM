


CREATE    FUNCTION HITS_SSActionLastRoleAccess (@doctype as int = null , @empid as int  = null , @docno as int  = null, @ssgroup as int = null )
RETURNS int AS  
BEGIN 
declare @lastoprovalorder as int
declare @lastrolestatus as int
declare @myorder as int



if    @doctype = 2
SELECT      TOP 1 @lastoprovalorder = EmpVacatApproval.RoleId
FROM         EmpVacatApproval INNER JOIN
                      EmpAssignment ON EmpVacatApproval.EmpId = EmpAssignment.EmpId INNER JOIN
                      SSDocumentRole ON EmpVacatApproval.RoleId = SSDocumentRole.RoleId
WHERE     (EmpAssignment.SSGroup = @ssgroup) AND (SSDocumentRole.SSDocNo = @doctype)
and EmpVacatApproval.EmpId = @empid and  EmpVacatApproval.DocumentNo=@docno
ORDER BY SSDocumentRole.RoleOrder DESC


 

return @lastoprovalorder

END

GO

