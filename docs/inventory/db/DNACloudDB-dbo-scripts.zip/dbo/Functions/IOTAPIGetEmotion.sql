CREATE FUNCTION [dbo].[IOTAPIGetEmotion]
(
	-- Add the parameters for the function here
	@userlogonname AS NVARCHAR(80), @parentno AS SMALLINT, @modern AS SMALLINT, @mydate AS SMALLDATETIME, @where AS NVARCHAR(MAX) = ''
,@lang char(1)='E',@version INT ,@pofileid AS INT,@templateNo AS BIGINT, @timeDevice AS SMALLINT , @ReturnType AS SMALLINT ---- 0 --> percent   1 ---> Name    2  --->image   3 --- >code
)  
RETURNS NVARCHAR(max)
AS
BEGIN
DECLARE @emotionsPercent AS NUMERIC (18,3)=0 ,@emotionCode AS NVARCHAR(1) 
DECLARE @emotionname AS NVARCHAR(20),@emotionImage AS NVARCHAR(20)
SELECT @emotionImage='FaceAnger',@emotionCode='1',@emotionsPercent=Anger,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','1',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Anger
SELECT @emotionImage='FaceTired',@emotionCode='2',@emotionsPercent=Contempt,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','2',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Contempt
SELECT @emotionImage='FaceGrinTongueSquint',@emotionCode='3',@emotionsPercent=Disgust,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','3',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Disgust
SELECT @emotionImage='FaceFrownOpen',@emotionCode='4',@emotionsPercent=Fear,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','4',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Fear
SELECT @emotionImage='FaceSmileBeam',@emotionCode='5',@emotionsPercent=Happiness,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','5',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Happiness
SELECT @emotionImage='FaceMeh',@emotionCode='6',@emotionsPercent=Neutral,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','6',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Neutral
SELECT @emotionImage='FaceSadTear',@emotionCode='7',@emotionsPercent=Sadness,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','7',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Sadness
SELECT @emotionImage='FaceSurprise',@emotionCode='8',@emotionsPercent=Surprise,@emotionname=LTRIM(RTRIM(dbo.Hits_GetDCCaptionWzLogon('MobileEmotions','8',@lang,@userlogonname))) FROM dbo.ProfileTemplates WHERE ProfileId=@pofileid  AND TimeDevice = @timeDevice AND Templateno = @templateNo AND @emotionsPercent<Surprise
IF @ReturnType=0
BEGIN
RETURN CAST(@emotionsPercent AS NVARCHAR(20))
END 
ELSE IF @ReturnType=1
BEGIN
RETURN @emotionname
END
ELSE IF @ReturnType=2
BEGIN
RETURN @emotionImage
END
ELSE IF @ReturnType=3
BEGIN
RETURN @emotionCode 
END
RETURN ''
END

GO

