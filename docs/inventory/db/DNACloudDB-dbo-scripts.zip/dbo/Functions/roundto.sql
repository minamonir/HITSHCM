
CREATE  FUNCTION dbo.[roundto]
	(@roundamount numeric(18,3),  @roundmethod smallint, @roundto numeric(18,3))
RETURNS  numeric(18,3)
AS
BEGIN
--round method 1=arithmatic  2=up  3=down  

declare @int_part  as numeric(18,3), @rem_part as numeric(18,3)
declare @DecimalScale as smallint
select @DecimalScale=DecimalScale from sysparam


if @roundamount<>0 and   @roundto<>0 
  begin
     set @int_part=floor(@roundamount/@roundto)
     set @rem_part=@roundamount-@int_part*@roundto
     if @roundmethod=1
        begin
            if  @rem_part>=@roundto/2 set @roundamount=@int_part*@roundto+@roundto else set @roundamount=@int_part*@roundto
        end
     if @roundmethod=2 
        begin
            if  @rem_part>0 set @roundamount=@int_part*@roundto+@roundto else set @roundamount=@int_part*@roundto
        end
     if @roundmethod=3 set @roundamount=@int_part*@roundto
  end
else

  set @roundamount=round(@roundamount,@DecimalScale) 

return @roundamount
END

GO

