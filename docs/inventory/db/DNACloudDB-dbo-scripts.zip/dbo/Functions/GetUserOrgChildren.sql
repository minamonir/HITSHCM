CREATE FUNCTION [dbo].[GetUserOrgChildren](@userorganization NVARCHAR(max),@logonname NVARCHAR(80))

RETURNS nvarchar(max) AS  


BEGIN 
declare @userorgstr AS nvarchar(max)=''

DECLARE @enableOrgSetup AS BIT --, @userOrganization AS NVARCHAR(MAX)=''
SELECT @enableOrgSetup=EnableOrgSetup-- ,@userOrganization=UserOrganization
FROM nasusers 
cross JOIN sysparam 
WHERE nasusers.LogonName=@logonname 


IF @enableOrgSetup =0 or @userOrganization='' 
BEGIN
	SET @userorgstr=''
END
ELSE 
	BEGIN
		

		select @userorgstr=@userorgstr+ ltrim(rtrim(str(max(organizationParentorChild))))+',' 
		from OrganizationParentChild  
		cross apply dbo.HitsStringSplit(@UserOrganization,'#') t
		where  t.value <>'' and t.value=Organization  and OrgRelation IN (2,3)  
		group by organizationParentorChild

		--select @userorgstr=@userorgstr+ ltrim(rtrim(str(max(organizationParentorChild))))+',' 
		--from OrganizationParentChild  
		--where  @UserOrganization like '%#'+ltrim(rtrim(str(organization)))+'#%' and OrgRelation IN (2,3)  
		--group by organizationParentorChild


		set @userorgstr=case when @userorgstr<>'' then left(@userorgstr,len(@userorgstr)-1)else @userorgstr end	
	END

return @userorgstr
END

GO

