
CREATE FUNCTION [dbo].[EmpAppraisalValidations] (@empid INT ,@documentno INT ,@lang CHAR(1) = 'e' )
RETURNS NVARCHAR(MAX)
BEGIN
	
	-- This Function will be used from now on to check on all new Validations according to SysparamConfig Values or according to query strings 
	--it will return all validation messages that will be displayed to the user
	DECLARE @ValidationCaption NVARCHAR(MAX) = N'' 
	
	IF EXISTS (SELECT * FROM sysparamconfig WHERE configid = N'AppraisalMisconductDays' AND CASE WHEN SysParamConfig.ConfigValue='' THEN 0 ELSE SysParamConfig.ConfigValue END >0 )
	BEGIN 
		DECLARE  @MaxMisDays SMALLINT , @RatingLevel SMALLINT , @maxRatingLevel AS SMALLINT 
		
		DECLARE @appraisaldate AS SMALLDATETIME 
		SELECT @appraisaldate = appraisaldate ,@RatingLevel = dbo.EmpAppraisalRatingLevel(@empid ,@documentno) 
		FROM empappraisal 
		WHERE empid =@empid AND documentno=@documentno
		
		
		
		SELECT @MaxMisDays = CASE WHEN  LTRIM(RTRIM(ISNULL(SysParamConfig.ConfigValue,N''))) = N'' THEN 0 ELSE CONVERT(SMALLINT,SysParamConfig.ConfigValue) END 
		FROM SysParamConfig 
		WHERE SysParamConfig.ConfigID = N'AppraisalMisconductDays'
		
		SELECT top 1 @maxRatingLevel = ratinglevels.RatingLevel
		FROM empappraisal 
		LEFT JOIN appraisals ON appraisals.AppraisalNo = empappraisal.AppraisalNo
		LEFT JOIN ratinglevels ON ratinglevels.RatingScale = appraisals.RatingScale
		WHERE empappraisal.empid =@empid AND  empappraisal.documentno=@documentno
		ORDER BY ratinglevels.LevelPercent DESC 
		
		if  dbo.CountMisconductDays(@empid,@appraisaldate,@appraisaldate,1,1) >=@MaxMisDays AND @RatingLevel=@maxRatingLevel
		BEGIN
			 SELECT @ValidationCaption = CASE WHEN LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaption('EmpAppraisalValidations','ValidationMsg',@lang),N''))) = N'' THEN (CASE WHEN @lang='e' THEN N'The Rating Level doesn''t match no. of Misconduct Days  ' ELSE N'مستوي االقياس لا يتناسب مع أيام الجزاءات' END) ELSE  LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaption('EmpAppraisalValidations','ValidationMsg',@lang),N''))) END 
		END
				 
	END 
	  RETURN @ValidationCaption
END

GO

