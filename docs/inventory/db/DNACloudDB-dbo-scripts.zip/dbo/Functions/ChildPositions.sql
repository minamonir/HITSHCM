
--This fn gets the Position Childs Names for the @PositionNo 
--@lang =N'E' get the english name else get arabic name 
CREATE  FUNCTION [dbo].[ChildPositions](@PositionNo Int, @Lang NChar)
RETURNS  nVarChar(max)
AS
BEGIN
Declare Positions Cursor For SELECT Case When @Lang=N'E' Then PositionName Else PositionAName End From dbo.PositionsStructure
 Left Join Positions On Positions.PositionNo=PositionsStructure.PositionNo Where PositionParent=@PositionNo
OPEN Positions
Declare @PositionName As nVarChar(250)
Declare @Positions As nVarChar(max)
Set @Positions = N''
FETCH NEXT FROM Positions 
INTO @PositionName
WHILE @@FETCH_STATUS = 0
BEGIN
If @Positions = N'' Set @Positions = Ltrim(Rtrim(@PositionName))
Else Set @Positions = @Positions + N', '+ Ltrim(Rtrim(@PositionName))
FETCH NEXT FROM Positions INTO @PositionName
End
Close Positions
DeAllocate Positions
Return @Positions
END

GO

