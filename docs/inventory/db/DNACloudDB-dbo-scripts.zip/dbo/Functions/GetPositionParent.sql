
CREATE FUNCTION [dbo].[GetPositionParent](@Position AS INT,@PositionType as INT,@IgnoreVacantPosition AS BIT=0)
RETURNS smallint
BEGIN
	
	IF ISNULL(@Position,0)=0 RETURN 0
	DECLARE @PositionParent AS	 smallint = 0,@Count AS INT = 0 , @CountEmp AS smallint

	WHILE @PositionType <>@count 
	BEGIN
		IF @IgnoreVacantPosition=0
		   BEGIN
			 SELECT @PositionParent =  PositionParent FROM PositionsStructure WHERE PositionNo = @Position
			 SET @count=@count+1
			 SET @Position=@PositionParent
		   END 
		ELSE 
		   BEGIN 
		     SELECT @PositionParent =  PositionParent FROM PositionsStructure WHERE PositionNo = @Position
		     IF @PositionParent IS NULL OR @PositionParent=@Position
		     BEGIN
		     	SET @PositionParent=0
			 	BREAK 
		     END
		     IF  @PositionParent=@Position
		     BEGIN
			 	BREAK 
		     END
		     SET @count=@count+1
			 SET @Position=@PositionParent
	
			IF DB_NAME() LIKE '%Cl000014%'
				SELECT @CountEmp=COUNT(*) FROM empassignment WHERE isnull(PositionNo,0)=isnull(@PositionParent,0)
			ELSE
				SELECT @CountEmp=COUNT(*) FROM empassignment WHERE isnull(PositionNo,0)=isnull(@PositionParent,0)
				AND empassignment.status=1 
				
			IF @CountEmp=0  SET @PositionType=@PositionType+1

		   END 
	END 	

return @PositionParent
END

GO

