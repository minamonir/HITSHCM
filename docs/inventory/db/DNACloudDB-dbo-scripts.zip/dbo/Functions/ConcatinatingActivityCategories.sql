CREATE FUNCTION [dbo].[ConcatinatingActivityCategories]
	(@TrainingActivityNo SMALLINT, @Lang nCHAR(1))
	
RETURNS nvarchar(max)
AS
	BEGIN
            declare @returnval nvarchar(max)
            SET @returnval=N''
		/* sql statement ... */
           SELECT @returnval=@returnval+Case when @Lang='A' THEN LTRIM(RTRIM(TrainingCategories.TrainingCategoryAName)) ELSE LTRIM(RTRIM(TrainingCategories.TrainingCategoryName)) END+N', '
FROM TrainingActivitiesCategories
LEFT JOIN TrainingCategories ON TrainingCategories.TrainingCategory = TrainingActivitiesCategories.TrainingCategory
WHERE TrainingActivity=@TrainingActivityNo

set @returnval=substring(@returnval,0,LEN(@returnval))

	RETURN @returnval
	END

GO

