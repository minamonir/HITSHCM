
CREATE FUNCTION [dbo].[WebAPI2GeolocationInAccDistance] (@Lat FLOAT, @Long FLOAT,@empid INT,@attendtime smalldatetime )
RETURNS NVARCHAR(MAX) 
AS
BEGIN
	
DECLARE @point1Geo AS GEOGRAPHY, @geolocation AS NVARCHAR(MAX)

SELECT @point1Geo = GEOGRAPHY::STPointFromText('POINT (' + STR(@Long,10,6) + ' ' + STR(@Lat,10,6) + ')', 4326)

 IF @empid <>0
		 BEGIN 
				SELECT TOP 1 @geolocation = ISNULL(GeoLocations.GeoLocation,0)
				FROM EmpGeoLocation
				Inner JOIN GeoLocations ON GeoLocations.GeoLocation = EmpGeoLocation.GeoLocation  
				WHERE EmpGeoLocation.empid=@empid
				AND DATEADD(hh, GMTZone, cast(@attendtime AS DATETIME)) BETWEEN EmpGeoLocation.StartDate AND ISNULL(EmpGeoLocation.enddate,DATEADD(hh, GMTZone, cast(@attendtime AS DATETIME)) )
				AND Locationgeo IS NOT NULL 
				AND Locationgeo.STBuffer(geoAcceptedDistc).STIntersects(@point1Geo)=1
		END 
ELSE 
		BEGIN
			SELECT TOP 1 @geolocation = ISNULL(GeoLocations.GeoLocation,0)
			FROM GeoLocations
			WHERE Locationgeo IS NOT NULL 
			AND Locationgeo.STBuffer(geoAcceptedDistc).STIntersects(@point1Geo)=1
		END

RETURN @geolocation 

END

GO

