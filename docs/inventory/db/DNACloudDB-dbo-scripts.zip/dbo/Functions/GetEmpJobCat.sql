CREATE FUNCTION [dbo].[GetEmpJobCat] (@empid AS INT,@lang AS NCHAR(1)) RETURNS NVARCHAR(503)
AS

BEGIN
	DECLARE @jobcat AS NVARCHAR(250),@jobcatgrb AS NVARCHAR(250)
		
	SELECT @jobcatgrb=case when @lang =N'A' then JobCatGrp.JobCatGrpAName ELSE JobCatGrp.JobCatGrpName END,
	@jobcat=case when @lang =N'A' then jobcat.JobCatAName ELSE jobcat.JobCatName end
	From EmpAssignment 				
	LEFT JOIN jobs ON jobs.job = EmpAssignment.Job
	LEFT JOIN jobcat ON jobcat.jobcat = Jobs.jobcat
	LEFT JOIN JobCatGrp ON JobCatGrp.JobCatGrp = JobCat.JobCatGrp
	where EmpAssignment.empid= @empid

	RETURN LTRIM(RTRIM(@jobcat)) + ISNULL(' - ' +LTRIM(RTRIM(@jobcatgrb)),'')
END

GO

