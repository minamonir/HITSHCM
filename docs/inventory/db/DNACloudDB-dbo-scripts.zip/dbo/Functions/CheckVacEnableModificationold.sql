
create  FUNCTION [dbo].[CheckVacEnableModificationold]
(
    @VacCode INT,
    @EmpId INT,
    @DocumentNo INT,
    @ActionType INT
)
RETURNS BIT
AS
BEGIN

    --@ActionType = 0 => Modification
    --@ActionType = 1 => Cancelation

    DECLARE @VacStatus SMALLINT
    DECLARE @FromDate SMALLDATETIME
    DECLARE @ToDate SMALLDATETIME
    DECLARE @EnableModify BIT
    DECLARE @CanModify BIT
    DECLARE @CanCancel SMALLINT
    DECLARE @Result BIT

    -- Early exit: if modification is disabled at the vacation, nothing else matters
    SELECT @EnableModify = EnableModify
    FROM Vacation
    WHERE vaccode = @VacCode

    IF ISNULL(@EnableModify, 0) = 0
    BEGIN
        RETURN 0
    END

     -- Early exit: if a cancelation record already exists for this document, block both modify and cancel
    IF EXISTS (
        SELECT 1
        FROM EmpVacModifications
        WHERE EmpId = @EmpId AND ActionType = 1 AND OriginalDocumentNo = @DocumentNo
    )
    BEGIN
        RETURN 0
    END

    -- Shared: is modification currently allowed for this vacation?
    SELECT
        @VacStatus = VacStatus,
        @FromDate = FromDate,
        @ToDate = ToDate
    FROM EmpVacat
    WHERE EmpId = @EmpId AND DocumentNo = @DocumentNo

    SET @CanModify = CASE
        WHEN @VacStatus <> 1                                  THEN 0   -- not approved
        WHEN CAST(@ToDate AS DATE) < CAST(GETDATE() AS DATE)  THEN 0   -- already past
        ELSE 1
    END

    -- CanModify
    IF @ActionType = 0
    BEGIN
        SET @Result = @CanModify
    END

    -- CanCancel
    IF @ActionType = 1
    BEGIN
        SELECT @CanCancel = VacStatus
        FROM EmpVacModifications
        WHERE EmpId = @EmpId AND OriginalDocumentNo = @DocumentNo

        -- Case: status is entered
        SET @Result = CASE
            WHEN @CanModify = 0                         THEN 0   -- if modification isn't allowed, cancelation isn't either
            WHEN @CanCancel IS NULL OR @CanCancel = 6   THEN 1
            ELSE 0
        END
    END

    RETURN @Result
    
END

GO

