

CREATE FUNCTION [dbo].[IOTAPIGetConclusionPerStoreFun]()

RETURNS @temp1ate TABLE (TemplateDate DATETIME,profileId INT ,templateNo BIGINT,timeDevice SMALLINT,timesystem SMALLINT,emotion SMALLINT)


BEGIN

--CREATE TABLE #temp1ate (TemplateDate DATETIME,profileId INT ,templateNo BIGINT,timeDevice SMALLINT,timesystem SMALLINT)
DECLARE @cursor_date AS DATETIME ,@cur_profileId AS INT ,@old_profileId AS INT,@templateNo AS BIGINT ,@cur_TimeDevice AS SMALLINT,
@olddate AS DATETIME ,@oldTimesystem AS SMALLINT ,@cur_Timesystem AS SMALLINT ,@intervalnoofvisits AS NUMERIC(18,3)
SELECT @intervalnoofvisits =configvalue FROM sysparamconfig WHERE ConfigID='IOTIntervalBetweenNoOfVisits'




DECLARE  cursor_Templatedate  CURSOR  FOR 
 SELECT ProfileTemplates.TemplateDate,ProfileTemplates.ProfileId,ProfileTemplates.Templateno,ProfileTemplates.TimeDevice,TimeSystemDevices.timesystem
FROM dbo.ProfileTemplates
 LEFT JOIN dbo.EmpAssignment ON EmpAssignment.EmpId=ProfileId
LEFT JOIN dbo.TimeSystemDevices ON TimeSystemDevices.TimeDevice = ProfileTemplates.TimeDevice
WHERE ProfileId <>0 
ORDER BY TimeSystem , ProfileId  ,TemplateDate DESC



 OPEN cursor_Templatedate

 FETCH NEXT FROM cursor_Templatedate INTO @cursor_date,@cur_profileId  ,@templateNo ,@cur_TimeDevice,@cur_Timesystem
WHILE @@FETCH_STATUS = 0   
 BEGIN 
 IF @olddate IS NULL OR DATEDIFF(SECOND ,@cursor_date,@olddate)/3600.00 >= @intervalnoofvisits OR @cur_Timesystem <>@oldTimesystem OR @cur_profileId<>@old_profileId
BEGIN
set @old_profileId=@cur_profileId
INSERT INTO @temp1ate( TemplateDate ,profileId  ,templateNo ,timeDevice,timesystem ,emotion) 
SELECT @cursor_date,@cur_profileId,@templateNo ,@cur_timeDevice,@cur_Timesystem,dbo.IOTAPIGetEmotion('', 0, 0, GETDATE(), '', 'E', 0, @cur_profileId, @templateNo,@cur_timeDevice, 3)

SET @olddate=@cursor_date
SET @oldTimesystem=@cur_Timesystem
END 


FETCH next from cursor_Templatedate INTO @cursor_date,@cur_profileId  ,@templateNo ,@cur_TimeDevice,@cur_Timesystem
END 
 
 CLOSE cursor_Templatedate

 
 DEALLOCATE cursor_Templatedate
	

	
	


	
	RETURN 
END

GO

