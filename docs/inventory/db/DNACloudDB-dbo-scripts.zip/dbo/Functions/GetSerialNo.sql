
CREATE FUNCTION [dbo].[GetSerialNo]
  (@BoxYear smallint, @BoxTypeId smallint, @BoxType smallint)
RETURNS int
AS 
BEGIN 

	DECLARE @SerialNo AS int, @StartSerial AS int
	
	SELECT @StartSerial=StartSerial
	FROM HRInOutBoxType
	WHERE BoxTypeId=@BoxTypeId AND BoxType=@BoxType

	IF @BoxType=1 --InBox
	BEGIN
		SELECT @SerialNo= CASE WHEN (max(InBoxSerialNo )+1) IS NULL THEN isnull(@StartSerial,0) ELSE (max(InBoxSerialNo )+1) END  
		FROM HRInBox 
		WHERE InBoxYear =@BoxYear AND BoxTypeId=@BoxTypeId
	END
	IF @BoxType=2 --OutBox
	BEGIN
		SELECT @SerialNo= CASE WHEN (max(OutBoxSerialNo)+1) IS NULL THEN isnull(@StartSerial,0) ELSE (max(OutBoxSerialNo)+1) END  
		FROM HROutBox 
		WHERE OutBoxYear=@BoxYear AND BoxTypeId=@BoxTypeId
	END
	
	RETURN @SerialNo
END

GO

