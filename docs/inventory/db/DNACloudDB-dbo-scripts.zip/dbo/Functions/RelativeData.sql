
---Get relatives data [name,birthdate,passno,passexp,....] for this employee (@Empid) according to
--@Type (to specify the field which i need for this relative (name,birthdate,passno,passexp,Gender,Religion,Nation,EntryPort,EntryNo) ) 
--and @Order (to specify the relative order ) 
CREATE  FUNCTION [dbo].[RelativeData]
	(@Empid int,  @Order smallint,@Type nchar(20))
 RETURNS nvarchar(120)
AS
BEGIN
	declare @RelProfileId as int
	declare @RelCount as int
	declare @Rdata as nchar(120)
	select @RelCount=count(*) from Relatives where Profileid=@Empid

--Compare the order wanted with the count of employee relatives

if @RelCount >= @order 

Begin
	if @Order=1 
	begin 
		select  top 1 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end

	if @Order=2
	begin 
		select  top 2 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end

	if @Order=3
	begin 
		select  top 3 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end

	if @Order=4
	begin 
		select  top 4 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end
	if @Order=5
	begin 
		select  top 5 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end

	if @Order=6
	begin 
		select  top 6 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end
	if @Order=7
	begin 
		select  top 7 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end
	if @Order=8
	begin 
		select  top 8 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end
	if @Order=9
	begin 
		select  top 9 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end
	if @Order=10
	begin 
		select  top 10 @RelProfileId = RelProfileId  from Relatives where  Profileid=@Empid order by  RelProfileId asc
	end
--Get the lables wanted for each relatives
	if @Type='Name'
	begin
		 select @Rdata= AName from Profile where Profileid=@RelProfileId
	end
	if @Type='BirthDate'
	Begin
		    select @Rdata=convert(nchar(10),dbo.Profile.BirthDate,103)  from Profile where Profileid=@RelProfileId
		   --select @Rdata=dbo.Greg2Hijri(Profile.BirthDate,'E')   from Profile where Profileid=@RelProfileId
	End
	if @Type='RelationType'
	Begin
		 select @Rdata= RelationAName from Relatives Left Join RelationType on Relatives.relationType=RelationType.RelationType where  Relatives.RelProfileid=@RelProfileId and Relatives.Profileid=@empid

	End
	if @Type='PassNo'
	Begin
		select @Rdata= ForPassNo from Profile where Profileid=@RelProfileId

	End
	
	if @Type='PassExp'
	Begin
		select @Rdata=convert(nchar(10),dbo.Profile.ForPasExp,103) from Profile where Profileid=@RelProfileId
		--select @Rdata=dbo.Greg2Hijri(Profile.ForPasExp,'E')  from Profile where Profileid=@RelProfileId


	End
	
	if @Type='Gender'
	Begin
		select @Rdata=Gender.adesc  from Profile LEFT JOIN NasArrays Gender ON Gender.itemno = Profile.Gender AND Gender.arrayname = 'Gender'  where Profileid=@RelProfileId

	End

	if @Type='Religion'
	Begin
		select @Rdata=Religion.adesc  from Profile LEFT JOIN NasArrays Religion ON Religion.itemno = Profile.Religion AND Religion.arrayname = 'Religion'  where Profileid=@RelProfileId

	End

	if @Type='Nation'
	Begin
		select @Rdata=Nations.NationAName  from Profile LEFT JOIN Nations ON Profile.NationId = Nations.nationid where Profileid=@RelProfileId

	End



	if @Type='EntryPort'
	Begin
	(SELECT distinct @RData= (CASE WHEN UserFieldsNames.FieldType=1 THEN UserFieldsValues.FieldAValue ELSE UserFieldsItems.FieldItemAValue end)
	FROM UserFieldsValues 
	LEFT JOIN UserFieldsItems ON UserFieldsValues.FormNo = UserFieldsItems.FormNo AND UserFieldsValues.FieldNo = UserFieldsItems.FieldNo 
	And UserFieldsValues.FieldValue = (cast(UserFieldsItems.FieldItemNo as nchar(254))) 
	INNER JOIN UserFieldsNames ON UserFieldsValues.FormNo = UserFieldsNames.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsNames.FieldNo and UserFieldsNames.FormNo = 1
	where  UserFieldsValues.fieldno=4 and UserFieldsValues.profileid=@RelProfileId)
	End

	if @Type='EntryNo'
	Begin
	(SELECT distinct @RData= (CASE WHEN UserFieldsNames.FieldType=1 THEN UserFieldsValues.FieldAValue ELSE UserFieldsItems.FieldItemAValue end)
	FROM UserFieldsValues 
	LEFT JOIN UserFieldsItems ON UserFieldsValues.FormNo = UserFieldsItems.FormNo AND UserFieldsValues.FieldNo = UserFieldsItems.FieldNo 
	And UserFieldsValues.FieldValue = (cast(UserFieldsItems.FieldItemNo as nchar(254))) 
	INNER JOIN UserFieldsNames ON UserFieldsValues.FormNo = UserFieldsNames.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsNames.FieldNo and UserFieldsNames.FormNo = 1
	where  UserFieldsValues.fieldno=6 and UserFieldsValues.profileid=@RelProfileId)
	End
-------------------------------------------------------------------------------------------------------------------

	if @Type='RelationEType'
	Begin
		 select @Rdata= RelationName from Relatives Left Join RelationType on Relatives.relationType=RelationType.RelationType where  Relatives.RelProfileid=@RelProfileId and Relatives.Profileid=@empid

	END
	IF @Type='TeleNo1'
	BEGIN
		SELECT @Rdata = TeleNo1 FROM profile WHERE profile.profileid = @RelProfileId
	END

    if @Type='EName'
	begin
		 select @Rdata= Name from Profile where Profileid=@RelProfileId
	END
	
	if @Type='NatnlNo'
	begin
		 select @Rdata= NatnlNo from Profile where Profileid=@RelProfileId
	end
------------------------------------------------------------------------------------------------------------------
End

return @Rdata
END

GO

