/*** Sum Percentage For the Evaluation Items / Count of The Items To Get The Average  ****/
CREATE FUNCTION [dbo].[EmpTrainersEvaluation](@EmpID int,@DocumentNo int,@TrainingEval SMALLINT ,@Resource INT,@ResourceCat SMALLINT,@Subject SMALLINT)   
RETURNS numeric (18,3) AS  

BEGIN
	DECLARE @Score AS numeric(18,3)
	
		SET @Score=
		(	SELECT Sum(RatingLevels.LevelPercent)/COUNT(EmpTrainingEvalTrainers.TrainingEvalItem)
			FROM EmpTrainingEvalTrainers
			LEFT JOIN TrainingEvalItems ON  TrainingEvalItems.TrainingEval = EmpTrainingEvalTrainers.TrainingEval 
				  AND TrainingEvalItems.TrainingEvalItem = EmpTrainingEvalTrainers.TrainingEvalItem
				  AND TrainingEvalItems.ResourceCategory =EmpTrainingEvalTrainers.ResourceCategory
			LEFT JOIN TrainingEvals ON TrainingEvals.TrainingEval = EmpTrainingEvalTrainers.TrainingEval
			lEFT JOIN RatingScales  ON ISNULL(TrainingEvalItems.RatingScale, TrainingEvals.RatingScale) = RatingScales.RatingScale
			LEFT JOIN RatingLevels  ON RatingScales.RatingScale  = RatingLevels.RatingScale  
				  AND RatingLevels.RatingLevel = EmpTrainingEvalTrainers.RatingLevel	
			WHERE EmpTrainingEvalTrainers.EmpId= @EmpID 
			  AND EmpTrainingEvalTrainers.DocumentNo= @DocumentNo 
			  AND EmpTrainingEvalTrainers.TrainingEval=@TrainingEval 
			  AND EmpTrainingEvalTrainers.TrainingResource = CASE WHEN @Resource IS NULL THEN EmpTrainingEvalTrainers.TrainingResource ELSE @Resource END 
			  AND EmpTrainingEvalTrainers.ResourceCategory = CASE WHEN @ResourceCat IS NULL THEN EmpTrainingEvalTrainers.ResourceCategory ELSE @ResourceCat END
			  AND EmpTrainingEvalTrainers.TrainingSubject  = CASE WHEN @Subject IS NULL THEN EmpTrainingEvalTrainers.TrainingSubject ELSE @Subject END
		)
		
RETURN ISNULL(@Score,0)
END

GO

