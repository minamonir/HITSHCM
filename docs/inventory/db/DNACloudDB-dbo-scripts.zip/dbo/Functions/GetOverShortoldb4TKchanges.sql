
CREATE               FUNCTION [dbo].[GetOverShortoldb4TKchanges]
	(@EmpId int,  @FromDate smalldatetime, @ToDate smalldatetime, @ValueType as smallint)
 RETURNS numeric(18,3)
AS
BEGIN
--@ValueType=1 over, @ValueType=2 short, @ValueType=3 allowance

declare @returnvalue numeric(18,3), @UseTime bit, @FixedHours bit, 
  @PerShiftPart bit, @AccumulateRanges bit, 
  @UsePermissionOver bit,  @UsePermissionShort bit,@HourlyPayroll bit

select @UsePermissionOver=0,  @UsePermissionShort=0

select @UseTime=isnull(UseTime,0), @FixedHours=isnull(FixedHours,0),
  @PerShiftPart=PerShiftPart, @AccumulateRanges=AccumulateRanges, @UsePermissionOver=UsePermissionOver,
  @UsePermissionShort=UsePermissionShort,@HourlyPayroll=HourlyPayroll
  from  EmpAssignment INNER JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
  where EmpAssignment.empid=@EmpId

set @returnvalue=0
if @UseTime =1
begin
  if @ValueType=3
  begin
    DECLARE @TempOverShort TABLE (EmpId int, EntryDate datetime,
      WorkHours numeric(18,3), allowamnt numeric(18,3))
    insert @TempOverShort 
    SELECT EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate,
      SUM(EmpShiftInOut.WorkSeconds*1.000)/3600, MAX(TimeShifts.allowamnt)  AS allowamnt
    FROM  EmpShiftInOut  INNER JOIN  EmpShift 
      ON EmpShiftInOut.EmpId = EmpShift.EmpId AND EmpShiftInOut.EntryDate = EmpShift.ShiftDate 
      INNER JOIN  TimeShifts ON EmpShift.ShiftNo = TimeShifts.ShiftNo
    WHERE EmpShiftInOut.empid=@EmpId and EmpShiftInOut.EntryDate between @FromDate and @ToDate
      and TimeShifts.allowamnt<>0
    GROUP BY EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate, EmpShift.ShiftNo 
    SELECT @returnvalue=sum(allowamnt) from @TempOverShort  where WorkHours<>0
  end
  else
  begin
    DECLARE @TempOverShort1 TABLE (EmpId int, EntryDate datetime, ShiftNo smallint, 
      HoursIn1 numeric(18,3), HoursOut1 numeric(18,3), 
      HoursIn2 numeric(18,3), HoursOut2 numeric(18,3),
      HoursTotal1 numeric(18,3), HoursTotal2 numeric(18,3),
      ShiftHours numeric(18,3), WorkHours numeric(18,3),
      PHoursIn1 numeric(18,3), PHoursOut1 numeric(18,3), 
      PHoursIn2 numeric(18,3), PHoursOut2 numeric(18,3),
      PHoursTotal1 numeric(18,3), PHoursTotal2 numeric(18,3))
      
      
      
        -------------------------------------------
    
  IF @ValueType=2   -- short time and vacation with fraction less than 1 (ex. 1/2 day  vacation)
  BEGIN
  	
  	   DECLARE @TempVac TABLE (EmpId int, FromDate datetime, ToDate datetime,ShiftDate DATETIME,VacTaken numeric(18,3) ,TempShiftHours numeric(18,3),VacHours numeric(18,3))
      
       INSERT INTO @TempVac
		SELECT EmpVacat.empid,FromDate,todate,EmpShift.ShiftDate,sum(isnull(dbo.vactakendays(EmpVacat.empid, case when EmpShift.ShiftDate <@FromDate then
		@FromDate else EmpShift.ShiftDate  end,case when EmpShift.ShiftDate >@ToDate then @ToDate else EmpShift.ShiftDate  end, EmpVacat.VacCode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo),0)),
		max((datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120), 
		case when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120)>convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120) THEN convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)+1 ELSE convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)end)
		+ case when FromTime1='00:00' or ltrim(FromTime1)='' or FromTime1='  :  ' or TOTime1='00:00' or ltrim(TOTime1)='' or TOTime1='  :  ' then 0 else isnull(datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120) ,CASE when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120)  > convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)THEN  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)+1 ELSE  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)  end),0)end
		)/3600.0 ),0
	
	FROM EmpVacat 
		LEFT JOIN Vacation ON  Vacation.vaccode = EmpVacat.VacCode
		inner JOIN EmpShift ON EmpShift.EmpId = EmpVacat.EmpId 
		
		AND (
			(EmpShift.ShiftDate between EmpVacat.FromDate AND  EmpVacat.todate AND (Vacation.DayFactor<1 and Vacation.DayFactor >0 ) )
		or
			(EmpShift.ShiftDate = EmpVacat.FromDate AND EmpVacat.PartDayFrom=1 )
		
		OR  (EmpShift.ShiftDate = EmpVacat.todate AND EmpVacat.PartDayTo=1  )
		
		)
		
		LEFT JOIN TimeShifts ON EmpShift.ShiftNo = TimeShifts.ShiftNo
		
		WHERE Vacation.UseDayFactor=1 AND  EmpVacat.empid=@EmpId AND 
		(EmpVacat.FromDate BETWEEN @FromDate AND @ToDate 
		OR EmpVacat.todate BETWEEN @FromDate AND @ToDate
		OR  @FromDate BETWEEN EmpVacat.FromDate AND EmpVacat.todate
		OR @ToDate BETWEEN EmpVacat.FromDate AND EmpVacat.todate) AND EmpVacat.VacStatus=1	
		AND shiftdate BETWEEN @FromDate AND @ToDate
		GROUP BY EmpVacat.empid,FromDate,todate,EmpShift.ShiftDate
		
		delete from @TempVac where VacTaken >=1 or VacTaken<=0
		
		update @TempVac set VacHours=VacTaken*tempShiftHours
  	 	
  END
  -------------------------------------------
  
  
    if @PerShiftPart=1 and @FixedHours=0
    begin 
      insert @TempOverShort1
      SELECT EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate, EmpShift.ShiftNo, 
        SUM(case when ShiftTimeNo=1 then case when @ValueType=1 then EmpShiftInOut.OverSecondsIn else EmpShiftInOut.ShortSecondsIn end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=1 then case when @ValueType=1 then EmpShiftInOut.OverSecondsOut else EmpShiftInOut.ShortSecondsOut end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=2 then case when @ValueType=1 then EmpShiftInOut.OverSecondsIn else EmpShiftInOut.ShortSecondsIn end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=2 then case when @ValueType=1 then EmpShiftInOut.OverSecondsOut else EmpShiftInOut.ShortSecondsOut end else 0 end*1.000)/3600, 
        SUM(case when ShiftTimeNo<=1 then case when @ValueType=1 then EmpShiftInOut.OverSeconds else EmpShiftInOut.ShortSeconds end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=2 then case when @ValueType=1 then EmpShiftInOut.OverSeconds else EmpShiftInOut.ShortSeconds end else 0 end*1.000)/3600,
        SUM(EmpShiftInOut.ShiftSeconds*1.000)/3600, SUM(EmpShiftInOut.WorkSeconds*1.000)/3600,
        SUM(case when ShiftTimeNo=1 then case when @ValueType=1 then isnull(EmpShiftInOut.POverSecondsIn,0) else isnull(EmpShiftInOut.PShortSecondsIn,0) end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=1 then case when @ValueType=1 then isnull(EmpShiftInOut.POverSecondsOut,0) else isnull(EmpShiftInOut.PShortSecondsOut,0) end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=2 then case when @ValueType=1 then isnull(EmpShiftInOut.POverSecondsIn,0) else isnull(EmpShiftInOut.PShortSecondsIn,0) end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=2 then case when @ValueType=1 then isnull(EmpShiftInOut.POverSecondsOut,0) else isnull(EmpShiftInOut.PShortSecondsOut,0) end else 0 end*1.000)/3600, 
        SUM(case when ShiftTimeNo<=1 then case when @ValueType=1 then isnull(EmpShiftInOut.POverSeconds,0) else isnull(EmpShiftInOut.PShortSeconds,0) end else 0 end*1.000)/3600,
        SUM(case when ShiftTimeNo=2 then case when @ValueType=1 then isnull(EmpShiftInOut.POverSeconds,0) else isnull(EmpShiftInOut.PShortSeconds,0) end else 0 end*1.000)/3600
      FROM  EmpShiftInOut  INNER JOIN  EmpShift 
       ON EmpShiftInOut.EmpId = EmpShift.EmpId AND EmpShiftInOut.EntryDate = EmpShift.ShiftDate 
      WHERE EmpShiftInOut.empid=@EmpId and EmpShiftInOut.EntryDate between @FromDate and @ToDate
      GROUP BY EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate, EmpShift.ShiftNo
    end
    else
    begin
      insert @TempOverShort1 
      SELECT EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate, EmpShift.ShiftNo,
        SUM(case when @ValueType=1 then EmpShiftInOut.OverSecondsIn else EmpShiftInOut.ShortSecondsIn end*1.000)/3600,
        SUM(case when @ValueType=1 then EmpShiftInOut.OverSecondsOut else EmpShiftInOut.ShortSecondsOut end*1.000)/3600,
        0,0,
        SUM(case when @ValueType=1 then EmpShiftInOut.OverSeconds else EmpShiftInOut.ShortSeconds end*1.000)/3600,
        0,
        SUM(EmpShiftInOut.ShiftSeconds*1.000)/3600, SUM(EmpShiftInOut.WorkSeconds*1.000)/3600,
        SUM(case when @ValueType=1 then isnull(EmpShiftInOut.POverSecondsIn,0) else isnull(EmpShiftInOut.PShortSecondsIn,0) end*1.000)/3600,
        SUM(case when @ValueType=1 then isnull(EmpShiftInOut.POverSecondsOut,0) else isnull(EmpShiftInOut.PShortSecondsOut,0) end*1.000)/3600,
        0,0,
        SUM(case when @ValueType=1 then isnull(EmpShiftInOut.POverSeconds,0) else isnull(EmpShiftInOut.PShortSeconds,0) end*1.000)/3600,
        0
      FROM  EmpShiftInOut  INNER JOIN  EmpShift 
       ON EmpShiftInOut.EmpId = EmpShift.EmpId AND EmpShiftInOut.EntryDate = EmpShift.ShiftDate 
      WHERE EmpShiftInOut.empid=@EmpId and EmpShiftInOut.EntryDate between @FromDate and @ToDate
      GROUP BY EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate, EmpShift.ShiftNo
    end
    if @FixedHours=1
     SELECT @returnvalue=
        sum(case when @ValueType=1 and WorkHours>ShiftHours then  
       dbo.GetOverShortValue (ShiftNo, @AccumulateRanges, 0, 0,(WorkHours-ShiftHours), @ValueType,0, 0,case when @UsePermissionOver=0 then (WorkHours-ShiftHours) else (PHoursTotal1+PHoursTotal2) END,0,0,0,0,0,0,isnull(VacHours,0)) 
        when @ValueType=2 and WorkHours<ShiftHours then 
          dbo.GetOverShortValue (ShiftNo, @AccumulateRanges, 0, 0,(ShiftHours-WorkHours), @ValueType,0, 0,case when @UsePermissionShort=0 then 0 else (PHoursTotal1+PHoursTotal2) END,0,0,0,0,0,0,isnull(VacHours,0)) 
        else 0 end)  
     from @TempOverShort1 t
     LEFT JOIN @TempVac TV ON t.EmpId=TV.EmpId AND t.EntryDate between TV.FromDate AND TV.ToDate AND t.EntryDate=ShiftDate
      where WorkHours<>0  OR @HourlyPayroll=1
    else 
      SELECT @returnvalue=case when @ValueType=1 then 
        sum(dbo.GetOverShortValue (ShiftNo, @AccumulateRanges, HoursIn1, HoursOut1, HoursTotal1, @ValueType,
             case when @UsePermissionOver=0 then HoursIn1 else PHoursIn1 end, case when @UsePermissionOver=0 then HoursOut1 else PHoursOut1 end, 
             case when @UsePermissionOver=0 then HoursTotal1 else PHoursTotal1 end,HoursIn2,HoursOut2,HoursTotal2,case when @UsePermissionOver=0 then HoursIn2 else PHoursIn2 end, case when @UsePermissionOver=0 then HoursOut2 else PHoursOut2 end, 
             case when @UsePermissionOver=0 then HoursTotal2 else PHoursTotal2 end,isnull(VacHours,0)))
       else
         sum(dbo.GetOverShortValue (ShiftNo, @AccumulateRanges, HoursIn1,HoursOut1 , HoursTotal1, @ValueType, 
             case when @UsePermissionShort=0 then 0 else PHoursIn1 end, case when @UsePermissionShort=0 then 0 else PHoursOut1 end, 
             case when @UsePermissionShort=0 then 0 else PHoursTotal1 END,HoursIn2,HoursOut2,HoursTotal2,case when @UsePermissionShort=0 then 0 else PHoursIn2 END,case when @UsePermissionShort=0 then 0 else PHoursOut2 END,case when @UsePermissionShort=0 then 0 else PHoursTotal2 END,isnull(VacHours,0))
    ) 
       end
      from @TempOverShort1 t
     LEFT JOIN @TempVac TV ON t.EmpId=TV.EmpId AND t.EntryDate between TV.FromDate AND TV.ToDate AND t.EntryDate=ShiftDate
      where WorkHours<>0  OR @HourlyPayroll=1
  END
  
  

end
return ISNULL(@returnvalue,0)
END

GO

