
CREATE               FUNCTION [dbo].[GetOverShortValue]
( @ShiftNo smallint, @AccumulateRanges as bit, @HoursIn as numeric(18,3), @HoursOut as numeric(18,3),
    @HoursTotal as numeric(18,3), @ValueType as smallint, @PHoursIn as numeric(18,3), @PHoursOut as numeric(18,3),
    @PHoursTotal as numeric(18,3),@HoursIn1 as numeric(18,3), @HoursOut1 as numeric(18,3),@HoursTotal1 as numeric(18,3),
    @PHoursIn1 as numeric(18,3), @PHoursOut1 as numeric(18,3),@PHoursTotal1 as numeric(18,3),@VacHours AS numeric(18,3))
 RETURNS numeric(18,3)
 AS 
BEGIN
    	
    
   -- OverShort	OverShortName
-- 1	Over [Early In]                         
-- 2	Over [Late Out]                         
-- 3	Over [Working Out of working hours] 
-- 4    Over [Total]    
-- 5	Short [Late In]                         
-- 6	Short [Early Out]                       
-- 7	Short [Exit during working hours]       
-- 8    Short [Total]
	
declare @OverValue numeric(18,3),  @Hours as numeric(18,3),@VacHoursTemp AS numeric(18,3)

SET @VacHoursTemp=@VacHours

DECLARE @shortValuetemp  as numeric(18,3)
select @OverValue=0,  @Hours=0
declare @FromHours as numeric(9,3), @ToHours as numeric(9,3),
   @RoundTo as numeric(9,3), @RoundMethod as smallint, @HourFactor as numeric(9,3),
   @HoursMid as numeric(9,3), @PHoursMid as numeric(9,3)
   
--parameter to decide the vacation with which side
--to be used when consideraing the vacation with the short part
--possible values : 1.in , 2.out , 3.during
DECLARE @VacHoursType AS SMALLINT
SET @VacHoursType = 0
   
select @HoursMid=@HoursTotal-@HoursIn-@HoursOut

if @valuetype=1 --over

  select @HoursTotal=case when @HoursTotal>@PHoursTotal then @PHoursTotal else @HoursTotal end,
         @HoursIn=case when @HoursIn>@PHoursIn then @PHoursIn else @HoursIn end,
         @HoursOut=case when @HoursOut>@PHoursOut then @PHoursOut else @HoursOut end,
         @HoursMid=case when @HoursMid>(@PHoursTotal-@PHoursIn-@PHoursOut) then(@PHoursTotal-@PHoursIn-@PHoursOut) else @HoursMid end
ELSE
BEGIN	
  --short
  select @HoursTotal=case when @HoursTotal>@PHoursTotal then @HoursTotal-@PHoursTotal else 0 end,
         @HoursIn=case when @HoursIn>@PHoursIn then @HoursIn-@PHoursIn else 0 end,
         @HoursOut=case when @HoursOut>@PHoursOut then @HoursOut-@PHoursOut else 0 end,
         @HoursMid=case when @HoursMid>(@PHoursTotal-@PHoursIn-@PHoursOut) then @HoursMid-(@PHoursTotal-@PHoursIn-@PHoursOut) else 0 END
       
   --decide which part is the biggest one -- > vacation will be considered with it
   SELECT @VacHoursType = ( CASE
                            WHEN @HoursIn >= @HoursOut AND @HoursIn >= @HoursMid THEN 1
                            WHEN @HoursOut >= @HoursIn AND @HoursOut >= @HoursMid THEN 2
                            WHEN @HoursMid >= @HoursIn AND @HoursMid >= @HoursOut THEN 3
                            ELSE 1 END )  
                            
   --in case we need to work with the normal old logic[vacation will be considered in all cases]
   --SET @VacHoursType = 0                             	
END

if  exists(select shiftno FROM TimeShiftTimes where shiftno=@shiftno and 
      overshort=case when @ValueType=1 then 4 else 8 end)
BEGIN
	--over or short total
	if @HoursTotal<>0 
	 begin 
	 	IF @valuetype=2
		BEGIN
			
			SET @shortValuetemp=0.0
			if @AccumulateRanges=0
  
				select @shortValuetemp=isnull(max(@HoursTotal),0)
				from TimeShiftTimes 
				where shiftno=@shiftno and (@HoursTotal between FromHours and ToHours) and @HoursTotal>MinHours
				and overshort=case when @valuetype=1 then 4 else 8 end 
				--AND HourFactor<>0
			ELSE
				--isnull(sum((case when @HoursTotal>ToHours then ToHours else @HoursTotal end)-FromHours),0)
				select @shortValuetemp=isnull(max(@HoursTotal),0)
				from TimeShiftTimes 
				where shiftno=@shiftno and (@HoursTotal>=FromHours) and @HoursTotal>MinHours 
				and overshort=case when @valuetype=1 then 4 else 8 end 
				--AND HourFactor<>0
      
			select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
			SELECT @VacHoursTemp=case when @VacHoursTemp>@shortValuetemp THEN @VacHoursTemp-@shortValuetemp ELSE 0 end
	END
	ELSE
	BEGIN
		select @Hours=@HoursTotal
	END
  
  if @AccumulateRanges=0
  
			select @OverValue=@OverValue+isnull(max(dbo.roundto(@Hours,RoundMethod,RoundTo)*HourFactor),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@Hours between FromHours and ToHours) and @Hours>MinHours
			and overshort=case when @valuetype=1 then 4 else 8 end 
      
  else
			select @OverValue=@OverValue+isnull(sum(dbo.roundto((case when @Hours>ToHours then ToHours else @Hours end)-FromHours,RoundMethod,RoundTo)*HourFactor),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@Hours>=FromHours) and @Hours>MinHours 
			and overshort=case when @valuetype=1 then 4 else 8 end 
  end
end
else
begin
 if @HoursIn<>0
 BEGIN
 	--[over or short in]
 	IF @valuetype=2 AND exists(select shiftno FROM TimeShiftTimes where shiftno=@shiftno and overshort=5)
	BEGIN
		--[short in]
		SET @shortValuetemp=0.0
		if @AccumulateRanges=0
   
		    select @shortValuetemp=isnull(max(@HoursIn),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@HoursIn between FromHours and ToHours) and @HoursIn>MinHours
			and overshort=case when @valuetype=1 then 1 else 5 end 
			--AND HourFactor<>0
             	
      ELSE
      	--isnull(sum((case when @HoursIn>ToHours then ToHours else @HoursIn end)-FromHours),0)
			select @shortValuetemp=isnull(max(@HoursIn),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@HoursIn>=FromHours) and @HoursIn>MinHours 
			and overshort=case when @valuetype=1 then 1 else 5 end 
			--AND HourFactor<>0
      
       --after calculating the short part -- > will try to take the vacation into consideration upon the parameter[@VacHoursType]
		IF (@VacHoursType =1)
		BEGIN
			--case vacation should be considered from [in] side only
			select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
		    SELECT @VacHoursTemp=0
		END
		ELSE IF (@VacHoursType = 0)
		BEGIN
			-- case vacation should be considered from all sides
			select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
		    SELECT @VacHoursTemp=case when @VacHoursTemp>@shortValuetemp THEN @VacHoursTemp-@shortValuetemp ELSE 0 end
		END
		ELSE
		BEGIN
			SET @Hours = @shortValuetemp
		END
		
	END
	ELSE
	BEGIN
		--[over in]
		select @Hours=@HoursIn
	END
		    
   if @AccumulateRanges=0
        --go to certain slice directly
		select @OverValue=@OverValue+isnull(max(dbo.roundto(@Hours,RoundMethod,RoundTo)*HourFactor),0)
		from	TimeShiftTimes 
		where shiftno=@shiftno and (@Hours between FromHours and ToHours) and @Hours>MinHours
		and overshort=case when @valuetype=1 then 1 else 5 end AND HourFactor<>0
               	
   ELSE
   	    --accumulate data upon different slices
		select @OverValue=@OverValue+isnull(sum(dbo.roundto((case when @Hours>ToHours then ToHours else @Hours end)-FromHours,
		RoundMethod,RoundTo)*HourFactor),0)
		from TimeShiftTimes 
		where shiftno=@shiftno and (@Hours>=FromHours) and @Hours>MinHours 
		and overshort=case when @valuetype=1 then 1 else 5 end AND HourFactor<>0
           
   end
 
 if @HoursOut<>0
 BEGIN
 	-- [over or short out] 
  	IF @valuetype=2 AND exists(select shiftno FROM TimeShiftTimes where shiftno=@shiftno and overshort=6)
	BEGIN
		--short out
		SET @shortValuetemp=0.0
		if @AccumulateRanges=0
			select @shortValuetemp=isnull(max(@HoursOut),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@HoursOut between FromHours and ToHours) and @HoursOut>MinHours
			and overshort=case when @valuetype=1 then 2 else 6 end 
			--AND HourFactor<>0
		ELSE
			--isnull(sum((case when @HoursOut>ToHours then ToHours else @HoursOut end)-FromHours),0)
			select @shortValuetemp=isnull(max(@HoursOut),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@HoursOut>=FromHours) and @HoursOut>MinHours       
			and overshort=case when @valuetype=1 then 2 else 6 end 
			--AND HourFactor<>0
      
        --after calculating the short part -- > will try to take the vacation into consideration upon the parameter[@VacHoursType]
		IF (@VacHoursType =2)
		BEGIN
			--case vacation should be considered from [out] side only
		  select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
		  SELECT @VacHoursTemp=0
		END
		ELSE IF (@VacHoursType = 0)
		BEGIN
			-- case vacation should be considered from all sides
			select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
		    SELECT @VacHoursTemp=case when @VacHoursTemp>@shortValuetemp THEN @VacHoursTemp-@shortValuetemp ELSE 0 end
		END
		ELSE
		BEGIN
			select @Hours=@shortValuetemp
		END
	END
	ELSE
	BEGIN
		--over out
		select @Hours=@HoursOut
	END
	 
  if @AccumulateRanges=0
  --go to certain slice directly
    select @OverValue=@OverValue+isnull(max(dbo.roundto(@Hours,RoundMethod,RoundTo)*HourFactor),0)
    from TimeShiftTimes 
    where shiftno=@shiftno and (@Hours between FromHours and ToHours) and @Hours>MinHours
      and overshort=case when @valuetype=1 then 2 else 6 end AND HourFactor<>0
   ELSE
   	--accumulate data upon different slices
    select @OverValue=@OverValue+isnull(sum(dbo.roundto((case when @Hours>ToHours then 
    	ToHours else @Hours end)-FromHours,RoundMethod,RoundTo)*HourFactor),0)
    from TimeShiftTimes 
    where shiftno=@shiftno and (@Hours>=FromHours) and @Hours>MinHours       
      and overshort=case when @valuetype=1 then 2 else 6 end AND HourFactor<>0
 end

 if @HoursMid<>0
 BEGIN
 	-- [over or short during] 
 	IF @valuetype=2 AND exists(select shiftno FROM TimeShiftTimes where shiftno=@shiftno and overshort=7)
	BEGIN
		--short during
		SET @shortValuetemp=0.0
		 if @AccumulateRanges=0
  
			select @shortValuetemp=isnull(max(@HoursMid),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@HoursMid between FromHours and ToHours) and @HoursMid>MinHours
			and overshort=case when @valuetype=1 then 3 else 7 end 
			--AND HourFactor<>0
		ELSE
			--isnull(sum((case when @HoursMid>ToHours then ToHours else @HoursMid end)-FromHours),0)
			select @shortValuetemp=isnull(max(@HoursMid),0)
			from TimeShiftTimes 
			where shiftno=@shiftno and (@HoursMid>=FromHours) and @HoursMid>MinHours 
			and overshort=case when @valuetype=1 then 3 else 7 END 
			--AND HourFactor<>0
      
       --after calculating the short part -- > will try to take the vacation into consideration upon the parameter[@VacHoursType]
	   IF (@VacHoursType =3)
		BEGIN
			--case vacation should be considered from [mid] side only
	       select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
		   SELECT @VacHoursTemp=0
		END
		ELSE IF (@VacHoursType = 0)
		BEGIN
			-- case vacation should be considered from all sides
			select @Hours=case when @VacHoursTemp>@shortValuetemp THEN 0 ELSE @shortValuetemp-@VacHoursTemp end
	        SELECT @VacHoursTemp=case when @VacHoursTemp>@shortValuetemp THEN @VacHoursTemp-@shortValuetemp ELSE 0 end
		END
		ELSE
	    BEGIN
	    	select @Hours = @shortValuetemp
	    END
	END
	ELSE
	BEGIN
		--over during
		select @Hours=@HoursMid
	END
	
  if @AccumulateRanges=0
  --go to certain slice directly
		select @OverValue=@OverValue+isnull(max(dbo.roundto(@Hours,RoundMethod,RoundTo)*HourFactor),0)
		from TimeShiftTimes 
		where shiftno=@shiftno and (@Hours between FromHours and ToHours) and @Hours>MinHours
		and overshort=case when @valuetype=1 then 3 else 7 end AND HourFactor<>0
   ELSE
   	--accumulate data upon different slices
		select @OverValue=@OverValue+isnull(sum(dbo.roundto((case when @Hours>ToHours then ToHours else @Hours end)-FromHours,RoundMethod,RoundTo)*HourFactor),0)
		from TimeShiftTimes 
		where shiftno=@shiftno and (@Hours>=FromHours) and @Hours>MinHours 
		and overshort=case when @valuetype=1 then 3 else 7 end AND HourFactor<>0
  end
END

IF @HoursIn1<>0 OR @HoursOut1 <>0 or @HoursTotal1 <>0
SELECT @OverValue=isnull(@OverValue,0)+isnull(dbo.[GetOverShortValue](@ShiftNo, @AccumulateRanges, @HoursIn1 , @HoursOut1 ,@HoursTotal1, 
@ValueType , @PHoursIn1 , @PHoursOut1 ,@PHoursTotal1 ,0,0,0,0,0,0,@VacHoursTemp),0)
---------------------------16/07/2007---------------------------------
RETURN  isnull(@OverValue,0)
----------------------------------------------------------------------------------
end

GO

