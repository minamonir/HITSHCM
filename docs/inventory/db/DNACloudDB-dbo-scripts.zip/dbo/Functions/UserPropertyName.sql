CREATE function [dbo].[UserPropertyName] (@logonname nvarchar(80), @auditDateTime datetime , @lang as char(1) , @order smallint , @option smallint) 
returns nvarchar(MAX)
AS
BEGIN
Declare @prop1 nvarchar(MAX)='' ,  @prop2 nvarchar(Max)=''

select @prop1 = case when @lang = 'A' then  ARepPropertyName1 else RepPropertyName1 end ,
@prop2=case when @lang = 'A' then  ARepPropertyName2 else RepPropertyName2 end 
from NasUsers where logonname =@logonname




IF ltrim(rtrim( @prop1)) = '' and ltrim(rtrim( @prop2)) = '' 
Begin
DECLARE @userOrganization as nvarchar(max), @org as int 
select @userOrganization = UserOrganization from NasUsers where LogonName = @logonname
IF @userOrganization <>''
BEGIN

declare Org_Cursor Cursor for select * from [dbo].[HitsStringSplit](@userOrganization,'#')
open Org_Cursor
fetch next from Org_Cursor into @org
while @@FETCH_STATUS=0
begin
   select @prop1= case when @lang = 'A' then  Areppropertyname1 else reppropertyname1 end 
   , @prop2= case when @lang = 'A' then  Areppropertyname2 else reppropertyname2 end 
   from organization where organization=@org

   if ltrim(rtrim( @prop1))<>'' or  ltrim(rtrim( @prop2))<>''
   break 
fetch next from Org_Cursor into @org
end 
close Org_Cursor
deallocate Org_Cursor
END
end 
IF ltrim(rtrim( @prop1)) = '' and ltrim(rtrim( @prop2)) = ''
begin
  select @prop1= case when @lang = 'A' then  sysparam.Apropname else  sysparam.propname end  from sysparam
end 

return @Prop1+ case when  ltrim(rtrim( @prop1))<>'' and  ltrim(rtrim( @prop2))<>'' then '<br/>' ELSE '' END + ltrim(rtrim( @prop2)) 

--RETURN  'Property Name one - Property Name two - Property Name 3 - Property Name 4 - Property Name 5 - Property Name 6 ' 

End

GO

