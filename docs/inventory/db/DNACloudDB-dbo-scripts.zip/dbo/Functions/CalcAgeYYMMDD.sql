

CREATE FUNCTION [dbo].[CalcAgeYYMMDD]
(
	-- Add the parameters for the function here
	 @birthdate AS SMALLDATETIME , @empid AS INT 
)
RETURNS NVARCHAR(10) 
AS
BEGIN
DECLARE @age AS NVARCHAR(10)

DECLARE  @tmpdate datetime, @years int, @months int, @days int

set @tmpdate = @birthdate

SET @years = DATEDIFF(yy, @tmpdate, GETDATE()) - CASE WHEN (MONTH(@birthdate) > MONTH(GETDATE())) OR (MONTH(@birthdate) = MONTH(GETDATE()) AND DAY(@birthdate) > DAY(GETDATE())) THEN 1 ELSE 0 END
SET @tmpdate = DATEADD(yy, @years, @tmpdate)
set @months = DATEDIFF(m, @tmpdate, GETDATE()) - CASE WHEN DAY(@birthdate) > DAY(GETDATE()) THEN 1 ELSE 0 END
SET @tmpdate = DATEADD(m, @months, @tmpdate)
SET @days = DATEDIFF(d, @tmpdate, GETDATE())

set @age = CAST (CAST (@years AS NVARCHAR(2)) + '.'+ cast (@months AS NVARCHAR(2)) + '.' +cast ( @days AS NVARCHAR(2)) AS NVARCHAR(10))  

RETURN @age 
END

GO

