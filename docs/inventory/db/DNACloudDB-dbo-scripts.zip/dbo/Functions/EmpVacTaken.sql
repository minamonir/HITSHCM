CREATE FUNCTION [dbo].[EmpVacTaken] (@empid int, @date1 smalldatetime,@date2 smalldatetime,@VacType as int) 
RETURNS numeric(18,3)
AS
BEGIN
  Declare @Taken as numeric (18,3)
  
  SELECT @date1=CASE WHEN HireDate<@date1 THEN @date1 ELSE hiredate END
  FROM EmpAssignment WHERE EmpId=@empid
  
  Select 
@Taken=Case When @date1 > @date2 
 Then -1*dbo.get_vactaken(EmpAssignment.EmpId, dateadd(dd,1,@date2) ,@date1-1,@VacType) 
 Else dbo.get_vactaken(EmpAssignment.EmpId,@date1, @date2, @VacType) End 

  From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
  Where EmpAssignment.EmpId=@empid



  RETURN @Taken
--select @Balance as Bal,@PrevBal as prevbal,@Due as due,@Taken as taken
END

GO

