
--------------------------------OTA Tax calculating function


CREATE    FUNCTION IRG2008 (@mnt FLOAT)
 RETURNS INT
BEGIN 
 DECLARE @w_months INT
 SET @w_months=1
 RETURN 
  (case when floor((floor((@mnt) )-cast(floor((@mnt) )as int )%10) )-cast(floor((floor((@mnt) )-cast(floor((@mnt) )as int )%10) )as int )%10< 15000 * @w_months 
        then 0 
        else
         case when floor((floor((@mnt) )-cast(floor((@mnt) )as int )%10) )-cast(floor((floor((@mnt) )-cast(floor((@mnt) )as int )%10) )as int )%10 < 30000 * @w_months 
              then ((floor((@mnt) )-cast(floor((@mnt) )as int )%10) - 10000 * @w_months)*.2 
              else
               case when floor((floor((@mnt) )-cast(floor((@mnt) )as int )%10) )-cast(floor((floor((@mnt) )-cast(floor((@mnt) )as int )%10) )as int )%10 < 120000 * @w_months 
                    then 4000 * @w_months +((floor((@mnt) )-cast(floor((@mnt) )as int )%10) - 30000 * @w_months)*.3 
                    else  
                     31000 * @w_months + ((floor((@mnt) )-cast(floor((@mnt) )as int )%10) - 120000 * @w_months)*.35  
                    end 
              end 
        end) 
  - 
 (case when (floor((@mnt) )-cast(floor((@mnt) )as int )%10) < 15000 * @w_months 
       then 0 
       else 
        case when (floor((@mnt) )-cast(floor((@mnt) )as int )%10) < 22500 * @w_months 
             then 1000 * @w_months 
             else 
              case when (floor((@mnt) )-cast(floor((@mnt) )as int )%10) > 28750 * @w_months 
                   then 1500 * @w_months 
                   else 
                     ((floor((@mnt) )-cast(floor((@mnt) )as int )%10) - 10000 * @w_months) * 0.2 * 0.4 
                   end 
             end 
       end)
END

GO

