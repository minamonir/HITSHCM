
CREATE FUNCTION MC_CheckIfMCIsEnabled
(
	@ItemNo int
)
RETURNS CHAR
AS
BEGIN
Declare @ReturnValue as CHAR='0'
	
if @ItemNo = 20090
Begin
SET @ReturnValue= ISNULL((SELECT ConfigValue FROM dbo.SysParamConfig WHERE ConfigID='MC_Payroll'),'0')

End

Return @ReturnValue
END

GO

