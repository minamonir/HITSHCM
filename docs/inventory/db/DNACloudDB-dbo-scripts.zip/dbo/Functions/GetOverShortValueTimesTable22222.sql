


create              FUNCTION [dbo].[GetOverShortValueTimesTable22222]
( @Empid INT,@FromDate smalldatetime, @ToDate smalldatetime,@ShiftNo smallint, @ValueType as smallint,@OverShort SMALLINT,@HourFactor decimal(9,3),@CalFactor BIT,@Paycode smallint,@VacHours AS numeric(18,3),@UsePermissionOver bit,  @UsePermissionShort bit)
RETURNS @Temp2 TABLE (empid INT,entrydate SMALLDATETIME,Paycode smallint,OverValue numeric(18,3),overshort smallint,FromHours decimal(9,3),FromTime nvarchar(5) )
 AS 

--DECLARE @Empid INT,@FromDate smalldatetime, @ToDate smalldatetime,@ShiftNo smallint, @ValueType as smallint,@OverShort SMALLINT,@HourFactor decimal(9,3),@CalFactor BIT,@Paycode smallint,@UsePermissionOver bit,  @UsePermissionShort BIT
----233,   @FromDate ='2018-07-01 00:00:00', @ToDate ='2018-07-31 00:00:00'
--SELECT @Empid =233,@FromDate ='2018-07-01 00:00:00', @ToDate='2018-07-31 00:00:00',@ShiftNo =902, @ValueType =1,@OverShort=0,@HourFactor =0,@CalFactor =1,@Paycode =0,@UsePermissionOver =0,  @UsePermissionShort =0
--declare @Temp2 TABLE (empid INT,paycode smallint,OverValue numeric(18,3))
BEGIN  
--declare @Temp TABLE (empid INT,paycode smallint,OverValue numeric(18,3))
-- OverShort	OverShortName
-- 1	Over [Early In]                         
-- 2	Over [Late Out]                         
-- 3	Over [Working Out of working hours] 
-- 4    Over [Total]    
-- 5	Short [Late In]                         
-- 6	Short [Early Out]                       
-- 7	Short [Exit during working hours]       
-- 8    Short [Total]
	
declare @OverValue numeric(18,3),  @Hours as numeric(18,3),@TimeRulePaycode AS smallint,@VacHoursType as smallint

--SET @VacHoursTemp=@VacHours

DECLARE @shortValuetemp  as numeric(18,3)
--, @ShiftOut1 as DATETIME, @ShiftOut2 as DATETIME
,@EmpPermExist AS SMALLINT=0

   --in case we need to work with the normal old logic[vacation will be considered in all cases]
   --SET @VacHoursType = 0   




--------SET @VacHours=@VacHours*3600.00
--------select @OverValue=0
   
 IF @ValueType=2   -- short time and vacation with fraction less than 1 (ex. 1/2 day  vacation)
  BEGIN
  	
 DECLARE @TempVac TABLE (EmpId int, FromDate datetime, ToDate datetime,ShiftDate DATETIME,VacTaken numeric(18,3) ,TempShiftHours numeric(18,3),VacHours numeric(18,3))
      
       INSERT INTO @TempVac
		SELECT EmpVacat.empid,FromDate,todate,EmpShift.ShiftDate,sum(isnull(dbo.vactakendays(EmpVacat.empid, case when EmpShift.ShiftDate <@FromDate then
		@FromDate else EmpShift.ShiftDate  end,case when EmpShift.ShiftDate >@ToDate then @ToDate else EmpShift.ShiftDate  end, EmpVacat.VacCode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo),0)),
		max((datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120), 
		case when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120)>convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120) THEN convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)+1 ELSE convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)end)
		+ case when FromTime1='00:00' or ltrim(FromTime1)='' or FromTime1='  :  ' or TOTime1='00:00' or ltrim(TOTime1)='' or TOTime1='  :  ' then 0 else isnull(datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120) ,CASE when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120)  > convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)THEN  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)+1 ELSE  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)  end),0)end
		)/3600.0 ),0
		
		FROM EmpVacat 
		LEFT JOIN Vacation ON  Vacation.vaccode = EmpVacat.VacCode
		inner JOIN EmpShift ON EmpShift.EmpId = EmpVacat.EmpId AND EmpShift.empid=@EmpId
		
		AND (
			(EmpShift.ShiftDate between EmpVacat.FromDate AND  EmpVacat.todate AND (Vacation.DayFactor<1 and Vacation.DayFactor >0 ) )
		or
			(EmpShift.ShiftDate = EmpVacat.FromDate AND EmpVacat.PartDayFrom=1 )
		
		OR  (EmpShift.ShiftDate = EmpVacat.todate AND EmpVacat.PartDayTo=1  )
		
		)
		
		LEFT JOIN TimeShifts ON EmpShift.ShiftNo = TimeShifts.ShiftNo
		
		WHERE Vacation.UseDayFactor=1 AND  EmpVacat.empid=@EmpId AND 
		(EmpVacat.FromDate BETWEEN @FromDate AND @ToDate 
		OR EmpVacat.todate BETWEEN @FromDate AND @ToDate
		OR  @FromDate BETWEEN EmpVacat.FromDate AND EmpVacat.todate
		OR @ToDate BETWEEN EmpVacat.FromDate AND EmpVacat.todate) AND EmpVacat.VacStatus=1	
		AND shiftdate BETWEEN @FromDate AND @ToDate
		GROUP BY EmpVacat.empid,FromDate,todate,EmpShift.ShiftDate
		
		delete from @TempVac where VacTaken >=1 or VacTaken<=0
		
		update @TempVac set VacHours=VacTaken*tempShiftHours *3600.00
  	 	
  END
  -------------------------------------------

Select @TimeRulePaycode=CASE when @ValueType=2 THEN TimeRules.payshort WHEN @ValueType=1 THEN TimeRules.payover ELSE 0 end
from  EmpAssignment INNER JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
where EmpAssignment.empid=@EmpId

SET @TimeRulePaycode=ISNULL(@TimeRulePaycode,0)


declare  @EmpShiftInOut TABLE(Empid INT,entrydate smallDATETIME,timein DATETIME,timeout DATETIME,shiftin DATETIME,shiftout DATETIME,entryno smallint,ShiftTimeNo smallint)

INSERT INTO @EmpShiftInOut
SELECT EmpShiftInOut.empid,EntryDate,TimeIn,TimeOut,ShiftIn,ShiftOut,EntryNo,ShiftTimeNo FROM dbo.EmpShiftInOut
WHERE EmpShiftInOut.empid=@empid and EntryDate between @FromDate and @ToDate

declare  @EmpTimePermission TABLE(Empid INT,DocumentNo INT,PermissionNo SMALLINT,Overshort SMALLINT,PermissionFrom SMALLDATETIME,PermissionTo smallDATETIME)

insert INTO @EmpTimePermission
SELECT  EmpTimePermission.empid,EmpTimePermission.DocumentNo,EmpTimePermission.PermissionNo,Overshort,EmpTimePermission.PermissionFrom,EmpTimePermission.PermissionTo
FROM  EmpTimePermission INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
		inner join @EmpShiftInOut t  ON t.empid= EmpTimePermission.Empid AND DocumentStatus=1 AND ((ShiftIn between PermissionFrom and PermissionTo) 
		OR  (ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between TimeIn and TimeOut) 
		or (PermissionTo between TimeIn and TimeOut) or (TimeIn between PermissionFrom and PermissionTo) 
		OR (TimeOut between PermissionFrom and PermissionTo)
		or (PermissionFrom between ShiftIn and ShiftOut) or (PermissionTo between ShiftIn and ShiftOut))
		AND ((OverShort IN (1,2,3,4) AND @ValueType=1) OR ((OverShort IN (5,6,7,8) AND @ValueType=2) ))






		DECLARE @TempEmpShift TABLE (EmpId int, Shiftdate datetime, ShiftNo SMALLINT,shifttype SMALLINT,ShiftOut1 datetime,ShiftOut2 datetime,OverShortTotalExist smallint,HoursIn numeric(18,3),HoursOut numeric(18,3),HoursMid numeric(18,3),VacHoursType smallint)
      
		INSERT INTO @TempEmpShift
		SELECT  EmpShift.EmpId,Shiftdate,EmpShift.ShiftNo,shifttype,MAX(CASE WHEN ShiftTimeNo=1 THEN shiftout ELSE NULL end),
		ISNULL(MAX(CASE WHEN ShiftTimeNo=2 THEN shiftout ELSE NULL end),'') as ShiftOut2
		,0,0,0,0,0
		FROM EmpShift
		inner join TimeShifts on EmpShift.ShiftNo=TimeShifts.ShiftNo
		inner join @EmpShiftInOut t on t.empid=EmpShift.empid and t.entrydate=EmpShift.Shiftdate
		WHERE EmpShift.EmpId=@EmpId AND EmpShift.Shiftdate between @FromDate and @ToDate
		group by EmpShift.EmpId,Shiftdate,EmpShift.ShiftNo,shifttype


SELECT @EmpPermExist=COUNT(*) FROM @EmpTimePermission

SET @EmpPermExist=ISNULL(@EmpPermExist,0)

	declare  @TimeShiftTimes TABLE(ShiftNo  SMALLINT,
	shiftdate SMALLDATETIME,
	OverShort SMALLINT,
	RoundTo DECIMAL(9, 3) ,
	RoundMethod SMALLINT ,
	HourFactor DECIMAL(9, 3) ,
	MinHours NUMERIC(9, 3) ,
	FromTime NVARCHAR(5) ,
	ToTime NVARCHAR(5) ,
	FromDate DATETIME,
	ToDate DATETIME,
	Paycode SMALLINT)


	INSERT INTO @TimeShiftTimes
	        (ShiftNo, 
			shiftdate,
			OverShort ,
	          RoundTo ,
	          RoundMethod ,
	          HourFactor ,
	          MinHours ,
	          FromTime ,
	          ToTime ,
	         FromDate,
			 ToDate,
	          Paycode
	        )
	SELECT TimeShiftTimes.ShiftNo,T.Shiftdate,OverShort ,
	          RoundTo*3600.00 ,
	          RoundMethod ,
	          HourFactor ,
	          MinHours*3600.00  ,
	          TimeShiftTimes.FromTime ,
	          TimeShiftTimes.ToTime ,
	          convert(smalldatetime, CONVERT( NVARCHAR(10) , T.Shiftdate ,120) + ' '+ TimeShiftTimes.Fromtime, 120),
			   convert(smalldatetime, CONVERT( NVARCHAR(10) , T.Shiftdate ,120) + ' '+ TimeShiftTimes.Totime, 120),
	          isnull(Paycode,@TimeRulePaycode) 
			  FROM TimeShiftTimes
			   LEFT JOIN dbo.TimeShifts ON TimeShifts.ShiftNo = TimeShiftTimes.ShiftNo
			   inner join @tempempshift t on t.ShiftNo=TimeShiftTimes.ShiftNo
			   WHERE FromHours=0 AND ToHours=0 AND (TimeShiftTimes.FromTime<>'00:00' or TimeShiftTimes.ToTime<>'00:00')
			   ORDER BY T.Shiftdate,overshort,TimeShiftTimes.FromTime

IF EXISTS(SELECT * FROM @TimeShiftTimes WHERE ((OverShort IN (1,2,3,4) AND @ValueType=1 ) OR (OverShort IN (5,6,7,8) AND @ValueType=2 )))
begin
 
	   

DELETE FROM @TimeShiftTimes FROM @TimeShiftTimes TST WHERE OverShort IN(5,6,7) 
and shiftno in (select t.shiftno from @TimeShiftTimes t where t.ShiftNo=tst.shiftno and t.OverShort=8  )

DELETE FROM @TimeShiftTimes FROM @TimeShiftTimes TST WHERE OverShort IN(1,2,3) 
and shiftno in (select t.shiftno from @TimeShiftTimes t where t.ShiftNo=tst.shiftno and t.OverShort=4  )


DELETE FROM @TimeShiftTimes WHERE ((OverShort IN(1,2,3,4) AND @ValueType=2) OR (OverShort IN(5,6,7,8) AND @ValueType=1))

--SELECT '@TimeShiftTimes',* from @TimeShiftTimes



update @TempEmpShift set OverShortTotalExist=(select COUNT(*) FROM @TimeShiftTimes t WHERE t.OverShort=CASE WHEN @ValueType=1 THEN 4 ELSE 8 END and tes.ShiftNo=t.ShiftNo ) from @TempEmpShift TES

INSERT INTO @TimeShiftTimes
        (ShiftNo,OverShort,RoundTo,RoundMethod,HourFactor,MinHours,FromTime,ToTime,FromDate,ToDate,Paycode)
SELECT  ShiftNo,OverShort,RoundTo,RoundMethod,HourFactor,MinHours,FromTime,ToTime,shiftdate,CONVERT(smalldatetime, CONVERT( NVARCHAR(10) , shiftdate ,120) + ' '+ ToTime, 120),Paycode 
FROM @TimeShiftTimes t1
--inner join @tempempshift t on t.ShiftNo=t1.ShiftNo
WHERE Fromdate>Todate

UPDATE @TimeShiftTimes SET todate=CONVERT(DATETIME, Shiftdate + ' '+ '23:59:59:999', 120) 
--FROM @TempEmpShift t1
--INNER JOIN @TimeShiftTimes T ON t.ShiftNo=t1.ShiftNo
WHERE Fromdate>Todate



--parameter to decide the vacation with which side
--to be used when consideraing the vacation with the short part
--possible values : 1.in , 2.out , 3.during



  --SELECT @ShiftOut1 AS '@ShiftOut1',@ShiftOut2 AS '@ShiftOut2'
---------------------------------------------------------
   declare  @OverShortPermTimes TABLE(
	[EntryDate] [SMALLDATETIME] ,
	[EntryNo] [SMALLINT] ,
	[Documentno] [INT] IDENTITY(1,1) ,
	[OverShort] [SMALLINT] ,
	[ShortOverFrom] [DATETIME] ,
	[ShortOverTo] [DATETIME] ,
	[PermissionFrom] [DATETIME] ,
	[PermissionTo] [DATETIME] )

---------------------------------------
IF @usepermissionshort=1 AND @ValueType=2 AND @EmpPermExist>0
begin

  INSERT INTO @OverShortPermTimes
		           ( 
		             EntryDate ,
		             EntryNo ,
		             OverShort ,
		             ShortOverFrom ,
		             ShortOverTo ,
		             PermissionFrom ,
		             PermissionTo  )

		SELECT EmpShiftInOut.EntryDate,EntryNo,
		   CASE WHEN overshort IN (5,6,7) THEN overshort ELSE 
			 CASE when TimeIn is null or TimeOut is null then 8
                else case when PermissionFrom<TimeIn and TimeIn>ShiftIn then 
               5 else null end  end
			END,
		--OverShort,

		CASE WHEN OverShort=5 THEN 
			case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn
			then shiftin else null	END
        WHEN OverShort=6 THEN 
			case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut AND ((shiftout= ShiftOut1) OR (shiftout= ShiftOut2))
			then timeout ELSE NULL end
		WHEN OverShort IN(8) THEN 
			case when TimeIn is null or TimeOut is null THEN timein
			else case when PermissionFrom<TimeIn and TimeIn>ShiftIn THEN shiftin else null end  end
		ELSE NULL 
		END
		,
		CASE WHEN OverShort=5 THEN 
			case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn
			then timein else null	END
        WHEN OverShort=6 THEN 
			case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut AND ((shiftout= ShiftOut1) OR (shiftout= ShiftOut2))
			then shiftout ELSE NULL end
		WHEN OverShort IN(8) THEN 
			case when TimeIn is null or TimeOut is null THEN timeout
			else case when PermissionFrom<TimeIn and TimeIn>ShiftIn THEN timein else null end  end
		ELSE NULL 
		END
		,
		CASE WHEN OverShort=5 THEN 
			case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn
			then case when PermissionFrom<ShiftIn then ShiftIn else PermissionFrom END else null	END
        WHEN OverShort=6 THEN 
			case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut AND ((shiftout= ShiftOut1) OR (shiftout= ShiftOut2))
			then case when PermissionFrom<TimeOut then TimeOut else PermissionFrom END ELSE NULL end
		WHEN OverShort IN(8) THEN 
			case when TimeIn is null or TimeOut is null THEN CASE when PermissionFrom<ShiftIn then ShiftIn else PermissionFrom end
			else case when PermissionFrom<TimeIn and TimeIn>ShiftIn THEN CASE when PermissionFrom<ShiftIn then ShiftIn else PermissionFrom end else null end  end
		ELSE NULL 
		END,

        CASE WHEN OverShort=5 THEN 
			case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn THEN
			case when PermissionTo>TimeIn then TimeIn else PermissionTo end else null end
		WHEN OverShort=6 THEN 
			case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut AND ((shiftout= ShiftOut1) OR (shiftout= ShiftOut2))
			then case when PermissionTo>ShiftOut then ShiftOut else PermissionTo end ELSE NULL end
		WHEN overshort IN (8) THEN
			case when TimeIn is null or TimeOut is null then case when PermissionTo>ShiftOut then ShiftOut else PermissionTo end
			else case when PermissionFrom<TimeIn and TimeIn>ShiftIn then 
			case when PermissionTo>TimeIn then TimeIn else PermissionTo end else null end  end
            
		ELSE  NULL 
		END

		FROM  @EmpTimePermission EmpTimePermission
		inner join @EmpShiftInOut EmpShiftInOut ON ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) or  (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
		or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo)
		or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))
		inner join @TempEmpShift t on t.Shiftdate=EmpShiftInOut.entrydate and t.empid=EmpShiftInOut.empid
     	where  (OverShort in (5,6,7) OR OverShort=CASE WHEN OverShortTotalExist>0 THEN 8 ELSE 0 end)
		and ((PermissionFrom between ShiftIn and ShiftOut) or (PermissionTo between ShiftIn and ShiftOut) 
		or (ShiftIn between PermissionFrom and PermissionTo) or (ShiftOut between PermissionFrom and PermissionTo)) 

		ORDER BY EmpShiftInOut.entrydate,PermissionFrom
	-----------------------------------------------------------------------

	 INSERT INTO @OverShortPermTimes
		           ( 
		             EntryDate ,
		             EntryNo ,
		             OverShort ,
		             ShortOverFrom ,
		             ShortOverTo ,
		             PermissionFrom ,
		             PermissionTo  )

		SELECT EmpShiftInOut.EntryDate,EntryNo,
		    CASE WHEN OverShort IN(7,8) THEN 
                case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
                case when PermissionTo>TimeOut and TimeOut<ShiftOut  THEN CASE WHEN  shiftout<> ShiftOut1 and shiftout<> ShiftOut2 THEN 7 ELSE 6 end  else null end end
           ELSE NULL 
           END,
		--OverShort,

		CASE WHEN OverShort IN(7,8) THEN 
			case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
			case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> ShiftOut1 and shiftout<> ShiftOut2) OR (OverShort=8)) THEN TimeOut else null end end
		ELSE NULL 
		END

		,CASE WHEN OverShort IN(7,8) THEN 
			case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
			case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> ShiftOut1 and shiftout<> ShiftOut2) OR (OverShort=8)) THEN ShiftOut else null end end
		ELSE NULL 
		END,

		CASE WHEN OverShort IN(7,8) THEN 
			case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
			case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> ShiftOut1 and shiftout<> ShiftOut2) OR (OverShort=8)) THEN case when PermissionFrom<TimeOut then TimeOut else PermissionFrom end else null end end
		ELSE NULL 
		END,

       	CASE WHEN OverShort IN(7,8) THEN 
			case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
			case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> ShiftOut1 and shiftout<> ShiftOut2) OR (OverShort=8)) THEN 
			case when PermissionTo>ShiftOut then ShiftOut else PermissionTo end else null end end
		ELSE NULL 
		END


        FROM @EmpTimePermission EmpTimePermission 
		inner join @EmpShiftInOut EmpShiftInOut on  ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) or  (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
		or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo)
		or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))
			inner join @TempEmpShift t on t.Shiftdate=EmpShiftInOut.entrydate and t.empid=EmpShiftInOut.empid
        WHERE (OverShort in (7) OR OverShort=CASE WHEN OverShortTotalExist>0 THEN 8 ELSE 0 end)
		and ((PermissionFrom between ShiftIn and ShiftOut) or (PermissionTo between ShiftIn and ShiftOut) 
		or (ShiftIn between PermissionFrom and PermissionTo) or (ShiftOut between PermissionFrom and PermissionTo)) 
		ORDER BY EmpShiftInOut.entrydate,PermissionFrom
END
    -----------------------------------------------------------------------
IF @usepermissionover=1  AND @ValueType=1 AND  @EmpPermExist>0
begin
		INSERT INTO @OverShortPermTimes
		( 
		EntryDate ,
		EntryNo ,
		OverShort ,
		ShortOverFrom ,
		ShortOverTo ,
		PermissionFrom ,
		PermissionTo  )

		SELECT EntryDate,EntryNo,OverShort,
		CASE WHEN OverShort=1 THEN
			case when OverShort in (1) and isnull(TimeIn,ShiftIn)<ShiftIn and PermissionFrom<ShiftIn then Timein else null end
        WHEN OverShort=2 THEN 
			case when OverShort in (2) and isnull(TimeOut,ShiftOut)>ShiftOut and PermissionTo>ShiftOut then 
			shiftout else null end 
		WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then timein
			else case when PermissionFrom<ShiftIn and isnull(TimeIn,ShiftIn)<ShiftIn AND OverShort=8 THEN timein else null end  end
		ELSE NULL END

		,CASE WHEN OverShort=1 THEN
			case when OverShort in (1) and isnull(TimeIn,ShiftIn)<ShiftIn and PermissionFrom<ShiftIn then shiftin else null end
        WHEN OverShort=2 THEN 
			case when OverShort in (2) and isnull(TimeOut,ShiftOut)>ShiftOut and PermissionTo>ShiftOut then 
			timeout else null end 
		WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then timeout
			else case when PermissionFrom<ShiftIn and isnull(TimeIn,ShiftIn)<ShiftIn AND OverShort=8 THEN shiftin else null end  end
		ELSE NULL END,

		CASE WHEN OverShort=1 THEN
			case when OverShort in (1) and isnull(TimeIn,ShiftIn)<ShiftIn and PermissionFrom<ShiftIn then 
			case when PermissionFrom<TimeIn then TimeIn else PermissionFrom end else null end
        WHEN OverShort=2 THEN 
			case when OverShort in (2) and isnull(TimeOut,ShiftOut)>ShiftOut and PermissionTo>ShiftOut then 
			case when PermissionFrom<ShiftOut then ShiftOut else PermissionFrom end else null end 
		WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then case when PermissionFrom<TimeIn then TimeIn else PermissionFrom end
			else case when PermissionFrom<ShiftIn and isnull(TimeIn,ShiftIn)<ShiftIn AND OverShort=8  THEN CASE when PermissionFrom<TimeIn then TimeIn else PermissionFrom end else null end  end
		ELSE NULL END
        ,
		CASE WHEN OverShort=1 THEN
			case when OverShort in (1) and isnull(TimeIn,ShiftIn)<ShiftIn and PermissionFrom<ShiftIn then 
			case when ShiftIn<PermissionTo then ShiftIn else PermissionTo end else null end
        WHEN OverShort=2 THEN 
			case when OverShort in (2) and isnull(TimeOut,ShiftOut)>ShiftOut and PermissionTo>ShiftOut then 
			case when PermissionTo<TimeOut then PermissionTo else TimeOut end else null end 
		WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then case when PermissionTo>TimeOut then TimeOut else PermissionTo end
			else case when PermissionFrom<ShiftIn and isnull(TimeIn,ShiftIn)<ShiftIn AND OverShort=8  THEN case when PermissionTo>ShiftIn then ShiftIn else PermissionTo end else null end  end
		ELSE NULL END
         FROM  @EmpTimePermission EmpTimePermission 
		inner join @EmpShiftInOut EmpShiftInOut on  ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) or  (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
		or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo)
		or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))
		inner join @TempEmpShift t on t.Shiftdate=EmpShiftInOut.entrydate and t.empid=EmpShiftInOut.empid
		where  (OverShort in (1,2,3) OR OverShort=CASE WHEN OverShortTotalExist>0 THEN 4 ELSE 0 end)
		ORDER BY EmpShiftInOut.entrydate,PermissionFrom



		 ----------------------------------------------

		INSERT INTO @OverShortPermTimes
		( 
		EntryDate ,
		EntryNo ,
		OverShort ,
		ShortOverFrom ,
		ShortOverTo ,
		PermissionFrom ,
		PermissionTo  )


		SELECT EntryDate,EntryNo,OverShort,
		CASE WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then null
			else case when PermissionTo>ShiftOut and isnull(TimeOut,ShiftOut)>ShiftOut AND OverShort=8  THEN shiftout else null end  end
		ELSE NULL END

		,CASE WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then null
			else case when PermissionTo>ShiftOut and isnull(TimeOut,ShiftOut)>ShiftOut AND OverShort=8  THEN timeout else null end  end
		ELSE NULL END
		,
		CASE WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then null
			else case when PermissionTo>ShiftOut and isnull(TimeOut,ShiftOut)>ShiftOut AND OverShort=8  THEN case when PermissionFrom<ShiftOut then ShiftOut else PermissionFrom end else null end  end
		ELSE NULL END
        ,
		CASE WHEN OverShort in (3,4) THEN
			case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then null
			else case when PermissionTo>ShiftOut and isnull(TimeOut,ShiftOut)>ShiftOut AND OverShort=8  THEN case when PermissionTo>TimeOut then TimeOut else PermissionTo end else null end  end
		ELSE NULL END
        
	    FROM  @EmpTimePermission EmpTimePermission 
		inner join @EmpShiftInOut EmpShiftInOut on ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) or  (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
		or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo)
		or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))
			inner join @TempEmpShift t on t.Shiftdate=EmpShiftInOut.entrydate and t.empid=EmpShiftInOut.empid
		where (OverShort in (3) OR OverShort=CASE WHEN OverShortTotalExist>0 THEN 4 ELSE 0 end)
		ORDER BY EmpShiftInOut.entrydate,PermissionFrom
end
-----------------------------------------------------------------------------------------------------------

INSERT INTO @OverShortPermTimes
( 
EntryDate ,
EntryNo ,
OverShort ,
ShortOverFrom ,
ShortOverTo )
       
SELECT EmpShiftInOut.EntryDate,EntryNo,

CASE WHEN timein >ISNULL(shiftin,timein) THEN 5 
    WHEN  timein <ISNULL(shiftin,timein) THEN 1 
	WHEN  timeout <ISNULL(shiftout,timeout) THEN CASE WHEN (shiftout= ShiftOut1) OR (shiftout= ShiftOut2) THEN 6 ELSE 7 end
	WHEN  timeout >ISNULL(shiftout,timeout) THEN 2 
	WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN 3
	END 
,
CASE WHEN timein >ISNULL(shiftin,timein) THEN shiftin 
    WHEN  timein <ISNULL(shiftin,timein) THEN timein 
	WHEN  timeout <ISNULL(shiftout,timeout) THEN timeout 
	WHEN  timeout >ISNULL(shiftout,timeout) THEN shiftout  
	WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN timein END
    
,CASE WHEN timein >ISNULL(shiftin,timein) THEN timein 
    WHEN  timein <ISNULL(shiftin,timein) THEN shiftin 
	WHEN  timeout <ISNULL(shiftout,timeout) THEN shiftout 
	WHEN  timeout >ISNULL(shiftout,timeout) THEN timeout  
	WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN timeout END
FROM @EmpShiftInOut EmpShiftInOut 
	inner join @TempEmpShift t on t.Shiftdate=EmpShiftInOut.entrydate and t.empid=EmpShiftInOut.empid
WHERE  timein IS NOT NULL AND timeout IS NOT null
AND CASE WHEN timein >ISNULL(shiftin,timein) THEN shiftin 
    WHEN  timein <ISNULL(shiftin,timein) THEN timein 
	WHEN  timeout <ISNULL(shiftout,timeout) THEN timeout 
	WHEN  timeout >ISNULL(shiftout,timeout) THEN shiftout  
	WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN timein END NOT IN (SELECT ISNULL(t.ShortOverFrom,'') FROM @OverShortPermTimes t)
ORDER BY EmpShiftInOut.entrydate
-------------------------------------------------------
INSERT INTO @OverShortPermTimes
( 
EntryDate ,
EntryNo ,
OverShort ,
ShortOverFrom ,
ShortOverTo  )

SELECT EmpShiftInOut.EntryDate,EntryNo,

CASE WHEN timein >=ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN CASE WHEN (shiftout= ShiftOut1) OR (shiftout= ShiftOut2) THEN 6 ELSE 7 end 
     WHEN timein >=ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN 2
	 WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN CASE WHEN (shiftout= ShiftOut1) OR (shiftout= ShiftOut2) THEN 6 ELSE 7 end  
     WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN 2
 END
,
CASE WHEN timein >=ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN timein >=ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
	 WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
 END
    
,CASE WHEN timein >=ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN shiftout 
     WHEN timein >=ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN timeout
	 WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN shiftout 
     WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN timeout
 END
FROM @EmpShiftInOut EmpShiftInOut
	inner join @TempEmpShift t on t.Shiftdate=EmpShiftInOut.entrydate and t.empid=EmpShiftInOut.empid

WHERE timein IS NOT NULL AND timeout IS NOT null
AND CASE WHEN timein >=ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN timein >=ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
	 WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN  timein <=ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
 END NOT IN (SELECT isnull(t.ShortOverFrom,'') FROM @OverShortPermTimes t)
ORDER BY EmpShiftInOut.entrydate

	--------------------------------------


DELETE FROM @OverShortPermTimes WHERE ShortOverFrom IS NULL AND ShortOverTo IS NULL
DELETE FROM @OverShortPermTimes WHERE (@ValueType=1 AND OverShort IN (5,6,7,8)) OR ( @ValueType=2 AND OverShort IN (1,2,3,4))

---the below update statement to cover the case of shortovertime is intersected with two permissions
--ex:short time 09:00 to 11:00
---perm1 09:00 to  09:30
--perm2  10:00 to 10:30
---then the output
-- EntryDate	ShortOverFrom			ShortOverTo				PermissionFrom	   PermissionTo			
-- 2020-08-15 	2020-08-15 09:00      2020-08-15 10:00	        2020-08-15 09:00	2020-08-15 09:30	
-- 2020-08-15 	2020-08-15 10:00      2020-08-15 11:00	        2020-08-15 10:00	2020-08-15 10:30	


UPDATE @OverShortPermTimes SET ShortOverTo=
ISNULL((SELECT TOp 1 t.PermissionFrom FROM @OverShortPermTimes t 
WHERE OSPT.EntryDate=t.EntryDate AND OSPT.ShortOverFrom=t.ShortOverFrom AND OSPT.ShortOverTo=t.ShortOverTo AND OSPT.documentno<t.documentno ORDER BY t.Documentno),ShortOverTo)

,ShortOverFrom=iSNULL((SELECT TOp 1 OSPT.PermissionFrom FROM @OverShortPermTimes t 
WHERE OSPT.EntryDate=t.EntryDate AND OSPT.ShortOverFrom=t.ShortOverFrom AND OSPT.ShortOverTo=t.ShortOverTo AND OSPT.documentno>t.documentno ORDER BY t.Documentno desc),ShortOverFrom)
FROM @OverShortPermTimes OSPT

---------------------------------------------------------------------------------------
    DECLARE  @EmpShiftInOutWH TABLE(
	EntryDate SMALLDATETIME ,
	EntryNo SMALLINT ,
	Documentno INT  ,
	OverShort SMALLINT ,
	ShortOverFrom DATETIME ,
	ShortOverTo DATETIME ,
	PermissionFrom DATETIME ,
	PermissionTo DATETIME,
	From1Intersected  DATETIME,
	TO1Intersected  DATETIME,
    From1NotIntersected  DATETIME,
	TO1NotIntersected  DATETIME,
	From2NotIntersected  DATETIME,
	TO2NotIntersected  DATETIME,
	ShortHours1 NUMERIC(18,3),
	ShortHours2 NUMERIC(18,3),
	VacConsumed1 NUMERIC(18,3),
	VacConsumed2 NUMERIC(18,3)
	 )


	declare  @EmpShiftInOutWHSlices TABLE(
	EntryDate SMALLDATETIME ,
	SerialNo INT IDENTITY(1,1) ,
	EntryNo SMALLINT ,
	Documentno INT  ,
	OverShort SMALLINT ,
	ShortOverFrom DATETIME ,
	ShortOverTo DATETIME ,
	PermissionFrom DATETIME ,
	PermissionTo DATETIME,
	From1Intersected  DATETIME,
	TO1Intersected  DATETIME,
    From1NotIntersected  DATETIME,
	TO1NotIntersected  DATETIME,
	ShortHours1 NUMERIC(18,3),
	VacHours NUMERIC(18,3),
	VacConsumed1 NUMERIC(18,3),
	OverShortSlice SMALLINT,
	RoundTo DECIMAL(9, 3) ,
	RoundMethod SMALLINT ,
	HourFactor DECIMAL(9, 3) ,
	MinHours NUMERIC(9, 3) ,
	FromTime NVARCHAR(5) ,
	ToTime NVARCHAR(5) ,
	FromDate DATETIME,
	ToDate DATETIME,
	Paycode SMALLINT
	 )

			   

   INSERT INTO @EmpShiftInOutWH (EntryDate,EntryNo,Documentno,OverShort,ShortOverFrom ,ShortOverTo,PermissionFrom,PermissionTo)
   SELECT EntryDate,EntryNo,Documentno,OverShort,t.ShortOverFrom ,t.ShortOverTo,
   CASE WHEN (OverShort IN (1,2,3,4) AND @UsePermissionOver=1) OR (OverShort IN (5,6,7,8) AND @UsePermissionshort=1)  THEN  t.PermissionFrom ELSE NULL end ,
      CASE WHEN (OverShort IN (1,2,3,4) AND @UsePermissionOver=1) OR (OverShort IN (5,6,7,8) AND @UsePermissionshort=1)  THEN  t.PermissionTo ELSE NULL END
   FROM @OverShortPermTimes t 
   ORDER BY OverShort

   DELETE FROM @EmpShiftInOutWH WHERE (OverShort IN (1,2,3,4) AND @UsePermissionOver=1) AND PermissionFrom IS NULL 

   IF EXISTS(SELECT * FROM @EmpShiftInOutWH)
   begin
   -------------intersected periods
   UPDATE @EmpShiftInOutWH 
   SET From1Intersected=CASE WHEN PermissionFrom IS NOT NULL THEN CASE WHEN PermissionFrom > [ShortOverFrom] THEN PermissionFrom ELSE [ShortOverFrom] END ELSE NULL end
   ,TO1Intersected=CASE WHEN PermissionFrom IS NOT NULL THEN CASE WHEN PermissionTo > ShortOverTo THEN ShortOverTo ELSE PermissionTo END ELSE NULL end
   WHERE  PermissionFrom IS NOT NULL AND PermissionTo IS NOT null

   IF @ValueType=2
   begin
  ------------not intersected periods
    UPDATE @EmpShiftInOutWH 
   SET From1NotIntersected = CASE WHEN PermissionFrom > ShortOverFrom THEN ShortOverFrom ELSE null END
   ,TO2NotIntersected=CASE WHEN PermissionTo > ShortOverTo THEN null ELSE ShortOverTo END
   WHERE OverShort IN (5,6,7,8) 
   --to be sure that the short period and the permission period are not identical
   AND ((ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom=ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')=[ShortOverTo]))
   AND PermissionFrom IS NOT NULL AND PermissionTo IS NOT null

    UPDATE @EmpShiftInOutWH 
   SET TO1NotIntersected= CASE WHEN From1NotIntersected IS NOT NULL THEN From1Intersected ELSE NULL END
   ,From2NotIntersected =CASE WHEN TO2NotIntersected IS NOT NULL THEN  TO1Intersected ELSE NULL end
   WHERE OverShort IN (5,6,7,8) 
   --to be sure that the short period and the permission period are not identical
   AND ((ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom=ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')=[ShortOverTo]))
   AND PermissionFrom IS NOT NULL AND PermissionTo IS NOT NULL 

   UPDATE @EmpShiftInOutWH 
   SET From1NotIntersected= ShortOverFrom
   ,TO1NotIntersected =ShortOverTo
   WHERE OverShort IN (5,6,7,8) AND From1NotIntersected IS NULL AND TO1NotIntersected IS  NULL AND From2NotIntersected IS  NULL AND TO2NotIntersected IS  NULL  
   AND PermissionFrom IS NULL AND PermissionTo IS NULL
   end
   ----------------------------------------------------------------------------------------------------
  

  
  --------------------------------------------------------------------
  --SELECT '11', * FROM @EmpShiftInOutWH
  IF @ValueType=2
  begin
  INSERT INTO @EmpShiftInOutWH
 ( EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,From1Intersected,TO1Intersected,From1NotIntersected,
   TO1NotIntersected,From2NotIntersected,TO2NotIntersected,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2)
 SELECT EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,null,null,EntryDate,
 CONVERT(DATETIME, EntryDate + ' '+ TO1NotIntersected , 120),null,null,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2 
 FROM @EmpShiftInOutWH
 WHERE  From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT NULL and DATEDIFF(dd,From1NotIntersected,TO1NotIntersected)=1 


 UPDATE @EmpShiftInOutWH SET From1NotIntersected=CONVERT(DATETIME, EntryDate + ' '+ From1NotIntersected , 120),
 TO1NotIntersected=CASE WHEN DATEDIFF(dd,From1NotIntersected,TO1NotIntersected)=1  THEN CONVERT(DATETIME, EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(DATETIME, EntryDate + ' '+ TO1NotIntersected , 120) end
 WHERE  From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT NULL 


   INSERT INTO @EmpShiftInOutWH
 ( EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,From1Intersected,TO1Intersected,From1NotIntersected,
   TO1NotIntersected,From2NotIntersected,TO2NotIntersected,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2)
 SELECT EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,null,null,null,
 null,EntryDate,CONVERT(DATETIME, EntryDate + ' '+ TO2NotIntersected , 120),ShortHours1,ShortHours2,VacConsumed1,VacConsumed2 
 FROM @EmpShiftInOutWH
 WHERE  From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT NULL and DATEDIFF(dd,From2NotIntersected,TO2NotIntersected)=1 


 UPDATE @EmpShiftInOutWH SET From2NotIntersected=CONVERT(DATETIME, EntryDate + ' '+ From2NotIntersected , 120),
 TO2NotIntersected=CASE WHEN DATEDIFF(dd,From2NotIntersected,TO2NotIntersected)=1  THEN CONVERT(DATETIME, EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(DATETIME, EntryDate + ' '+ TO2NotIntersected , 120) end
 WHERE  From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT NULL 
 end

 IF @ValueType=1
 begin
    INSERT INTO @EmpShiftInOutWH
 ( EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,From1Intersected,TO1Intersected,From1NotIntersected,
   TO1NotIntersected,From2NotIntersected,TO2NotIntersected,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2)
 SELECT EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,EntryDate,CONVERT(DATETIME, EntryDate + ' '+ ISNULL(TO1Intersected,ShortOverTo) , 120),null,
 null,null,null,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2 
 FROM @EmpShiftInOutWH
 WHERE  ISNULL(From1Intersected,ShortOverFrom) IS NOT NULL AND ISNULL(TO1Intersected,ShortOverTo) IS NOT NULL and DATEDIFF(dd,ISNULL(From1Intersected,ShortOverFrom),ISNULL(TO1Intersected,ShortOverTo))=1 AND OverShort IN (1,2,3,4)

 UPDATE @EmpShiftInOutWH SET From1Intersected=CONVERT(DATETIME, EntryDate + ' '+ ISNULL(From1Intersected,ShortOverFrom) , 120),
 TO1Intersected=CASE WHEN  DATEDIFF(dd,From1Intersected,TO1Intersected)=1   THEN CONVERT(DATETIME, EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(DATETIME, EntryDate + ' '+ ISNULL(TO1Intersected,ShortOverTo) , 120) end
 WHERE  ISNULL(From1Intersected,ShortOverFrom) IS NOT NULL AND ISNULL(TO1Intersected,ShortOverTo) IS NOT NULL AND OverShort IN (1,2,3,4)

 end

--SELECT '22', * FROM @EmpShiftInOutWH
  -------------------------------------------------------


  IF @ValueType=2
  BEGIN
    
	  INSERT INTO @EmpShiftInOutWHSlices
          ( EntryDate ,
            EntryNo ,
            Documentno ,
            OverShort ,
            ShortOverFrom ,
            ShortOverTo ,
            PermissionFrom ,
            PermissionTo ,
            From1Intersected ,
            TO1Intersected ,
            From1NotIntersected ,
            TO1NotIntersected ,
            ShortHours1 ,
            VacConsumed1 ,
            OverShortSlice ,
            RoundTo ,
            RoundMethod ,
            HourFactor ,
            MinHours ,
            FromTime ,
            ToTime ,
            FromDate ,
            ToDate ,
            Paycode
          )

SELECT  EntryDate ,
            EntryNo ,
            Documentno ,
            ESIOWH.OverShort ,
            ShortOverFrom ,
            ShortOverTo ,
            PermissionFrom ,
            PermissionTo ,
            From1Intersected ,
            TO1Intersected ,
            From1NotIntersected ,
            TO1NotIntersected ,
            ShortHours1 ,VacConsumed1, TST.OverShort AS OverShortSlice ,
            RoundTo ,
            RoundMethod ,
            HourFactor ,
            MinHours ,
            FromTime ,
            ToTime ,
            FromDate ,
            ToDate ,
            Paycode	FROM  @EmpShiftInOutWH ESIOWH
			inner join @TempEmpShift TES on TES.Shiftdate=ESIOWH.entrydate  
			INNER JOIN @TimeShiftTimes TST ON TES.ShiftNo=TST.shiftno and ESIOWH.EntryDate=TES.shiftdate AND  ESIOWH.OverShort=CASE WHEN TST.OverShort =8 THEN ESIOWH.OverShort ELSE TST.OverShort end
			where   DATEDIFF (second ,CASE WHEN Fromdate > From1NotIntersected THEN Fromdate ELSE From1NotIntersected  End
			,CASE WHEN  Todate < TO1NotIntersected THEN  Todate ELSE TO1NotIntersected END)>MinHours
			and TST.overshort IN (5,6,7,8) AND ESIOWH.OverShort IN  (5,6,7,8) 
			AND From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT null
			AND (Fromdate   BETWEEN From1NotIntersected and TO1NotIntersected
			or  Todate    between From1NotIntersected  and  TO1NotIntersected
			OR  From1NotIntersected between Fromdate  and  Todate 
	or  TO1NotIntersected  between Fromdate and  Todate) 
	
	UNION ALL
    
	SELECT EntryDate,EntryNo,Documentno,ESIOWH.OverShort,ShortOverFrom,ShortOverTo,
            PermissionFrom ,
            PermissionTo ,
            From1Intersected ,
            TO1Intersected ,
            From2NotIntersected ,
            TO2NotIntersected ,
            ShortHours1 ,VacConsumed1, TST.OverShort AS OverShortSlice ,
            RoundTo ,
            RoundMethod ,
            HourFactor ,
            MinHours ,
            FromTime ,
            ToTime ,
            FromDate ,
            ToDate ,
            Paycode  
			FROM  @EmpShiftInOutWH ESIOWH
			inner join @TempEmpShift TES on TES.Shiftdate=ESIOWH.entrydate  
			INNER JOIN @TimeShiftTimes TST ON TES.ShiftNo=TST.shiftno and ESIOWH.EntryDate=TES.shiftdate AND ESIOWH.OverShort=CASE WHEN TST.OverShort =8 THEN ESIOWH.OverShort ELSE TST.OverShort end
			where   DATEDIFF (second ,CASE WHEN Fromdate > From2NotIntersected THEN Fromdate ELSE From2NotIntersected  End
			,CASE WHEN  Todate < TO2NotIntersected THEN  Todate ELSE TO2NotIntersected END)>MinHours
			  and TST.overshort IN (5,6,7,8)  AND ESIOWH.OverShort IN  (5,6,7,8) 
			AND From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT null
			AND (Fromdate   BETWEEN From2NotIntersected and TO2NotIntersected
			or  Todate    between From2NotIntersected  and  TO2NotIntersected
			OR  From2NotIntersected between Fromdate  and  Todate 
			or  TO2NotIntersected  between Fromdate and  Todate) 

	ORDER BY 1,4,15


	
  ------------------------------------------------------------------------

   UPDATE @EmpShiftInOutWHSlices SET ShortHours1=DATEDIFF (second ,CASE WHEN ESIO.Fromdate > From1NotIntersected THEN ESIO.Fromdate ELSE From1NotIntersected  End
    ,CASE WHEN  ESIO.Todate < TO1NotIntersected THEN  ESIO.Todate ELSE TO1NotIntersected END)
	,VacHours=tv.VacHours
	FROM @EmpShiftInOutWHSlices ESIO
	LEFT JOIN @TempVac TV ON tv.ShiftDate=ESIO.EntryDate


	update @TempEmpShift set HoursIn=(select SUM(CASE WHEN t.OverShort=5 THEN ISNULL(t.ShortHours1,0) ELSE 0 END) FROM @EmpShiftInOutWHSlices t where t.EntryDate=TES.Shiftdate)
	, HoursOut=(select SUM(CASE WHEN OverShort=6 THEN ISNULL(ShortHours1,0) ELSE 0 END) FROM @EmpShiftInOutWHSlices t where t.EntryDate=TES.Shiftdate)
	, HoursMid=(select SUM(CASE WHEN OverShort=7 THEN ISNULL(ShortHours1,0) ELSE 0 END) FROM @EmpShiftInOutWHSlices t where t.EntryDate=TES.Shiftdate)
	from @TempEmpShift TES


 SELECT @VacHoursType=0
	if @VacHoursType=0
	BEGIN
	  update @TempEmpShift set VacHoursType=0
    END
    else
	begin
	  update @TempEmpShift set VacHoursType=( CASE
                            WHEN HoursIn >= HoursOut AND HoursIn >= HoursMid THEN 1
                            WHEN HoursOut >= HoursIn AND HoursOut >= HoursMid THEN 2
                            WHEN HoursMid >= HoursIn AND HoursMid >= HoursOut THEN 3
                            ELSE 1 END )  
     end      
 
;      


 
	------------------------------------------------------------------------

	
WITH EmpShiftInOutWHSlices AS  
(  
SELECT ESW.EntryDate,ESW.SerialNo,CAST(SUM(ISNULL(ESW2.ShortHours1,0))+MIN(ISNULL(ESW.ShortHours1,0)) AS NUMERIC(18,3)) AS AcmulatedShort,MIN(ISNULL(ESW.VacHours,0)) AS vachours
FROM @EmpShiftInOutWHSlices ESW 
LEFT JOIN @TempEmpShift TES ON TES.Shiftdate=ESW.EntryDate
LEFT JOIN @EmpShiftInOutWHSlices ESW2  ON ESW.EntryDate=ESW2.EntryDate AND ESW.SerialNo>ESW2.SerialNo
AND  ESW2.overshort =CASE WHEN TES.VacHoursType=1 THEN 5 WHEN TES.VacHoursType=2 THEN 6 WHEN TES.VacHoursType=3 THEN 7 ELSE ESW2.overshort END
WHERE ESW.overshort =CASE WHEN TES.VacHoursType=1 THEN 5 WHEN TES.VacHoursType=2 THEN 6 WHEN TES.VacHoursType=3 THEN 7 ELSE ESW.overshort END
GROUP BY ESW.EntryDate,ESW.SerialNo
)


--SELECT 'EmpShiftInOutWHSlices11',* FROM EmpShiftInOutWHSlices

UPDATE @EmpShiftInOutWHSlices 
SET VacConsumed1=
ISNULL(CASE WHEN AcmulatedShort<=t1.VacHours THEN ISNULL(t.ShortHours1,0) ELSE CASE WHEN ISNULL(t.ShortHours1,0)-(AcmulatedShort-t1.VacHours) <0 THEN 0 ELSE ISNULL(t.ShortHours1,0)-(AcmulatedShort-t1.VacHours) END END,0)
FROM @EmpShiftInOutWHSlices t
inner JOIN EmpShiftInOutWHSlices  t1 ON t.EntryDate=t1.EntryDate AND t.SerialNo=t1.SerialNo



 
  -------------------------------------------------------------------------
  END


--  SELECT '@TimeShiftTimes',* FROM @TimeShiftTimes
  
--SELECT '22@EmpShiftInOutWHSlices', * FROM @EmpShiftInOutWHSlices

------  -------------------------------------------------------

--  SELECT '@EmpShiftInOutWH',* FROM @EmpShiftInOutWH
--    SELECT '@tempempshift',* FROM @tempempshift

--	    SELECT '@@TempVac',* FROM @TempVac

  -------------------------------------------------------





  ---------------calc over only-------------------------------
  IF @valuetype=1 
  begin



  INSERT INTO @Temp2
   	select distinct @empid,ESIOWH.EntryDate,paycode,isnull(sum(dbo.roundto(DATEDIFF (second ,CASE WHEN Fromdate > ISNULL(From1Intersected,ShortOverFrom) THEN Fromdate ELSE ISNULL(From1Intersected,ShortOverFrom)  End
    ,CASE WHEN  Todate < ISNULL(TO1Intersected,ShortOverTo) THEN  Todate ELSE ISNULL(TO1Intersected,ShortOverTo) END),RoundMethod,RoundTo)*CASE WHEN @CalFactor=1 THEN HourFactor  else 1.0 end),0)
	,TST.OverShort,0,TST.FromTime
	from @EmpShiftInOutWH ESIOWH
	inner join @TempEmpShift TES on TES.Shiftdate=ESIOWH.EntryDate
	INNER JOIN @TimeShiftTimes TST ON  TST.shiftno= TES.shiftno and ESIOWH.EntryDate=TES.shiftdate AND TST.OverShort = case when OverShortTotalExist>0 then CASE WHEN ESIOWH.OverShort IN (1,2,3,4) THEN 4 ELSE 8 end else ESIOWH.OverShort end 
    
	where   DATEDIFF (second ,CASE WHEN Fromdate > ISNULL(From1Intersected,ShortOverFrom) THEN Fromdate ELSE ISNULL(From1Intersected,ShortOverFrom)  End
   ,CASE WHEN  Todate < ISNULL(TO1Intersected,ShortOverTo) THEN  Todate ELSE ISNULL(TO1Intersected,ShortOverTo) END)>MinHours

  	AND TST.overshort=CASE WHEN @OverShort=0 THEN TST.overshort ELSE @OverShort END 
	AND HourFactor=CASE WHEN @HourFactor=0 THEN HourFactor ELSE @HourFactor END
	AND ISNULL(paycode,@TimeRulePaycode)=CASE WHEN @Paycode=0 THEN ISNULL(paycode,@TimeRulePaycode) ELSE @Paycode END
	AND (Fromdate   BETWEEN ISNULL(From1Intersected,ShortOverFrom)  and ISNULL(TO1Intersected,ShortOverTo)
	or  Todate    between ISNULL(From1Intersected,ShortOverFrom)  and  ISNULL(TO1Intersected,ShortOverTo) 
	OR  ISNULL(From1Intersected,ShortOverFrom) between Fromdate  and  Todate 
	or  ISNULL(TO1Intersected,ShortOverTo)  between Fromdate and  Todate)
	group by ESIOWH.EntryDate,paycode,TST.OverShort,TST.FromTime
 END
	 ---------------calc short-------------------------------
  IF @valuetype=2
  BEGIN

  INSERT INTO @Temp2
	select distinct @empid,ESIOWH.EntryDate,paycode,isnull(sum(dbo.roundto(ISNULL(DATEDIFF (second ,CASE WHEN Fromdate > From1NotIntersected THEN Fromdate ELSE From1NotIntersected  End
    ,CASE WHEN  Todate < TO1NotIntersected THEN  Todate ELSE TO1NotIntersected END),0)-ISNULL(VacConsumed1,0),RoundMethod,RoundTo)*CASE WHEN @CalFactor=1 THEN HourFactor  else 1.0 end),0)
	,OverShortSlice,0,ESIOWH.FromTime
	FROM @EmpShiftInOutWHSlices ESIOWH
	inner join @TempEmpShift TES on TES.Shiftdate=ESIOWH.EntryDate
	WHERE  OverShortSlice= case when OverShortTotalExist>0 then 8 else OverShortSlice end 
	AND OverShort IN (5,6,7,8) AND ISNULL(ShortHours1,0)-ISNULL(VacConsumed1,0)>MinHours
	AND OverShortSlice=CASE WHEN @OverShort=0 THEN OverShortSlice ELSE @OverShort END 
	AND HourFactor=CASE WHEN @HourFactor=0 THEN HourFactor ELSE @HourFactor END
	AND ISNULL(paycode,@TimeRulePaycode)=CASE WHEN @Paycode=0 THEN ISNULL(paycode,@TimeRulePaycode) ELSE @Paycode END
	group by ESIOWH.EntryDate,paycode,OverShortSlice,ESIOWH.FromTime

	
end

 end
 end
---------------------------16/07/2007---------------------------------
--return isnull(@OverValue,0)


SET @OverValue=ISNULL(@OverValue/3600.00,0)
update @Temp2 set OverValue=ISNULL(OverValue/3600.00,0)
delete @Temp2 where paycode is null
--select * from @Temp2
----------------------------------------------------------------------------------

return

END

GO

