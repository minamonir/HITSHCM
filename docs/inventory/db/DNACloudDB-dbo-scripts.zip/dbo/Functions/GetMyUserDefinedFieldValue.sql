
CREATE FUNCTION [dbo].[GetMyUserDefinedFieldValue] (@Empid INT
, @DocumentNo INT, @FormNo SMALLINT, @FieldNo SMALLINT, @Lang Nchar(1)='E')
 RETURNS NVARCHAR(120)
AS

BEGIN
    DECLARE @ReturnTxt AS NVARCHAR(120)
    IF @Lang='E'
    BEGIN 
	SELECT @ReturnTxt=
		(CASE   WHEN UserFieldsNames.FieldType=1 THEN UserFieldsValues.FieldValue 
				WHEN UserFieldsNames.FieldType=3 THEN Convert(nvarchar,round(UserFieldsValues.FieldValue,DecimalScale))
				WHEN UserFieldsNames.FieldType=4 THEN CASE WHEN rtrim(ltrim(UserFieldsValues.FieldValue)) <>'' then
				CASE	WHEN sysparam.DateFormat=0 --yyyy/mm/dd
      						THEN substring(str(UserFieldsValues.FieldValue,8),1,4)+'/'+substring(str(UserFieldsValues.FieldValue,8),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,8),7,2) 
						WHEN sysparam.DateFormat=1 --dd/mm/yyyy
							THEN substring(STR(UserFieldsValues.FieldValue,8),7,2)+'/'+substring(str(UserFieldsValues.FieldValue,8),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,8),1,4)
						ELSE /*sysparam.DateFormat=2 mm/dd/yyyy*/
								 substring(str(UserFieldsValues.FieldValue,8),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,8),7,2)+'/'+substring(str(UserFieldsValues.FieldValue,8),1,4)
      			END ELSE N'' END
                WHEN UserFieldsNames.FieldType=5 THEN 
				CASE	WHEN sysparam.DateFormat=0 --yyyy/mm/dd
							THEN substring(str(UserFieldsValues.FieldValue,12),1,4)+'/'+substring(str(UserFieldsValues.FieldValue,12),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),7,2)+' '+ substring(str(UserFieldsValues.FieldValue,12),9,2)+':'+substring(str(UserFieldsValues.FieldValue,12),11,2)
						WHEN sysparam.DateFormat=1 --dd/mm/yyyy
							THEN substring(STR(UserFieldsValues.FieldValue,12),7,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),1,4)+' '+ substring(str(UserFieldsValues.FieldValue,12),9,2)+':'+substring(str(UserFieldsValues.FieldValue,12),11,2)
						ELSE /*sysparam.DateFormat=2 mm/dd/yyyy*/
							SUBSTRING(str(UserFieldsValues.FieldValue,12),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),7,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),1,4)+' '+ substring(str(UserFieldsValues.FieldValue,12),9,2)+':'+substring(str(UserFieldsValues.FieldValue,12),11,2)	  
				END
              	ELSE UserFieldsItems.FieldItemValue END )  
	FROM UserFieldsValues
	LEFT JOIN UserFieldsItems ON UserFieldsValues.FormNo = UserFieldsItems.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsItems.FieldNo 
	And UserFieldsValues.FieldValue = (cast(UserFieldsItems.FieldItemNo as nchar(254))) 
	INNER JOIN UserFieldsNames ON UserFieldsValues.FormNo = UserFieldsNames.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsNames.FieldNo 
	CROSS JOIN Sysparam
	WHERE UserFieldsValues.ProfileId = @EmpId
	AND UserFieldsValues.DocumentNo = @DocumentNo
	AND UserFieldsValues.FormNo = @FormNo
	AND UserFieldsValues.FieldNo = @FieldNo
	END 
	ELSE 
	BEGIN 
	SELECT @ReturnTxt=
	(CASE   WHEN UserFieldsNames.FieldType=1 THEN UserFieldsValues.FieldAValue 
          	WHEN UserFieldsNames.FieldType=3 THEN Convert(nvarchar,round(UserFieldsValues.FieldAValue,DecimalScale))
			WHEN UserFieldsNames.FieldType=4 THEN CASE WHEN rtrim(ltrim(UserFieldsValues.FieldAValue)) <>'' then
			CASE	WHEN sysparam.DateFormat=1 --yyyy/mm/dd
  						THEN substring(str(UserFieldsValues.FieldAValue,8),1,4)+'/'+substring(str(UserFieldsValues.FieldAValue,8),5,2)+'/'+substring(str(UserFieldsValues.FieldAValue,8),7,2) 
					WHEN sysparam.DateFormat=0 --dd/mm/yyyy
						THEN substring(STR(UserFieldsValues.FieldAValue,8),7,2)+'/'+substring(str(UserFieldsValues.FieldAValue,8),5,2)+'/'+substring(str(UserFieldsValues.FieldAValue,8),1,4)
					ELSE /*sysparam.DateFormat=2 yyyy/dd/mm*/
							 substring(str(UserFieldsValues.FieldAValue,8),1,4)+'/'+substring(str(UserFieldsValues.FieldAValue,8),7,2)+'/'+substring(str(UserFieldsValues.FieldAValue,8),5,2) 
  			END ELSE N'' END
            WHEN UserFieldsNames.FieldType=5 THEN
			CASE	WHEN sysparam.DateFormat=1 --yyyy/mm/dd
						THEN substring(str(UserFieldsValues.FieldValue,12),9,2)+':'+substring(str(UserFieldsValues.FieldValue,12),11,2)+' '+ substring(str(UserFieldsValues.FieldValue,12),1,4)+'/'+substring(str(UserFieldsValues.FieldValue,12),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),7,2) 
					WHEN sysparam.DateFormat=0 --dd/mm/yyyy
						THEN substring(str(UserFieldsValues.FieldValue,12),9,2)+':'+substring(str(UserFieldsValues.FieldValue,12),11,2)+' '+substring(STR(UserFieldsValues.FieldValue,12),7,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),5,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),1,4)
					ELSE /*@Dateformat=2 yyyy/dd/mm*/
						 substring(str(UserFieldsValues.FieldValue,12),9,2)+':'+substring(str(UserFieldsValues.FieldValue,12),11,2)+' '+substring(str(UserFieldsValues.FieldValue,12),1,4)+'/'+substring(str(UserFieldsValues.FieldValue,12),7,2)+'/'+substring(str(UserFieldsValues.FieldValue,12),5,2) 
			END 
        	ELSE UserFieldsItems.FieldItemAValue END )  
	FROM UserFieldsValues 
	LEFT JOIN UserFieldsItems ON UserFieldsValues.FormNo = UserFieldsItems.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsItems.FieldNo 
	And UserFieldsValues.FieldAValue = (cast(UserFieldsItems.FieldItemNo as nchar(254))) 
	INNER JOIN UserFieldsNames ON UserFieldsValues.FormNo = UserFieldsNames.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsNames.FieldNo 
	CROSS JOIN Sysparam
	WHERE UserFieldsValues.ProfileId = @EmpId
	AND UserFieldsValues.DocumentNo = @DocumentNo
	AND UserFieldsValues.FormNo = @FormNo
	AND UserFieldsValues.FieldNo = @FieldNo
	END 
    RETURN ISNULL(@ReturnTxt, N'')
END

GO

