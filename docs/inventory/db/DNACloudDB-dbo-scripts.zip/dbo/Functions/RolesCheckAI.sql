

CREATE FUNCTION [dbo].[RolesCheckAI] 
	(@ViewName AS NVARCHAR(100)='', @UserName nchar(50), @Str NVARCHAR(max)) RETURNS NVARCHAR(max)
AS

BEGIN

	DECLARE @UserId AS int 

	SELECT @UserId = EmpId FROM NasUsers WHERE LogonName = @UserName;
	

	DECLARE @Where AS NVARCHAR(max)
	SET @Where=''		
	IF (SELECT SysParam.EnableRoleValidation FROM SysParam ) = 1
	BEGIN
		

		DECLARE @RoleFields AS NVARCHAR(max),@SSGroupField AS NVARCHAR(max)='EmpAssignment.SSGroup'
		DECLARE @Roles TABLE (RoleId SMALLINT)
		

		SELECT @SSGroupField = CASE WHEN CHARINDEX('AppAssignment', @Str) > 0 THEN 'AppAssignment.SSGroup'
									WHEN CHARINDEX('EmpAssignment', @Str) > 0 THEN 'EmpAssignment.SSGroup'
									ELSE '0' END

		DECLARE @ViewRoles TABLE
		(
			ViewName NVARCHAR(100),
			RoleFields NVARCHAR(MAX)
		)

		INSERT INTO @ViewRoles VALUES
		('[AIProfile]', 'JobsRoles,PositionsRoles,organizationroles,HrstatusRoles,GradesRoles,LocationRoles'),
		('[AIVacations]', 'VacationRoles'),
		('[AIMisconduct]','MscondctRoles'),
		('[AIChangeOfStatus]', 'ChngStatRoles'),
		('[AICompetencies]', 'CompetenciesRoles'),
		('[AIDocuments]', 'DocumentRoles'),
		('[AITimeKeeping]', 'TimeShiftsRoles'),
		('[AITraining]',' TrainingActivitiesRoles,TrainingEnrollStatusRoles,TrainingEventsRoles,CurrencyRoles,TrainingPlansRoles,TrainingMethodsRoles,PositionsRoles,JobsRoles,SupplierRoles,TrainingCategoriesRoles,TrainingEventStatusRoles,HrStatusRoles,OrganizationRoles,TrainingActivitiesRoles,GradesRoles,LocationRoles,TrainingCentersRoles'),
		('[AIMedical]','MedicalCategoriesRoles, CurrencyRoles, MedicalItemsRoles, MedicalItemsRoles, ServiceRoles, SupplierRoles, JobsRoles, PositionsRoles, OrganizationRoles, LocationRoles, GradesRoles, HrstatusRoles'),
		('[AIStaffHousing]','HKItemsRoles,HkItemTypesRoles,StaffBuildingsRoles, StaffRoomsRoles, StaffRoomTypesRoles'),
		('[AIBenefits]','BenefitPlansRoles,currencyRoles,BenefitOptionsRoles,BenefitItemsRoles,SupplierRoles,ServiceRoles,JobsRoles,PositionsRoles,organizationroles,HrstatusRoles,GradesRoles,LocationRoles'),
		('[AIRecruitment]','PositionsRoles,JobsRoles,OrganizationRoles,VacanciesRoles,RecruitmentActivitiesRoles,ApplicationStatusRoles,ApplicationSourceRoles,LocationRoles,CurrencyRoles,CitiesRoles,GraduateRoles,GradesRoles'),
		('[AIFinancialHistory]','PayrollGroupRoles,PayCodeRoles,CurrencyRoles,PaycdGrpRoles,JobsRoles,GradesRoles,PositionsRoles,organizationroles,LocationRoles'),
		('[AIFinancialMonthly]','PayrollGroupRoles,PayCodeRoles,CurrencyRoles,PaycdGrpRoles,JobsRoles,GradesRoles,PositionsRoles,organizationroles,LocationRoles'),
		('[AIFinancialPaymentHistory]','PayrollGroupRoles,PayCodeRoles,CurrencyRoles,PaycdGrpRoles,PaymentTypesRoles,BanksRoles,PayrollGroupRoles,JobsRoles,GradesRoles,PositionsRoles,organizationroles,Locationroles'),
		('[AIFinancialPaymentMonthly]','PayrollGroupRoles,CurrencyRoles,PaymentTypesRoles,BanksRoles'),
		('[AIPerformance]','AppraisalsRoles,AppraisalTypesRoles,CompetenciesRoles,RatingScalesRoles,AppraisalActionsRoles,JobsRoles,PositionsRoles,organizationroles,HrstatusRoles,GradesRoles,LocationRoles')

		SELECT @RoleFields = RoleFields
		FROM @ViewRoles
		WHERE ViewName = @ViewName

		IF @RoleFields <>''
		BEGIN
			INSERT INTO @Roles SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId=@UserId
			DECLARE @RoleID AS NVARCHAR(max)
			SET @RoleID = '#'
			SELECT @RoleID = @RoleID + CAST(RoleId AS NVARCHAR(5))+'#'
			FROM  @Roles
			 -------------modified by suzie 2023/10/16-------------
			IF  @RoleID = '#' SET @RoleId='' -- to handle the case user is @apply ssgroup=1 and he has no roles (it is called from hits_buildreportquery) 
			----------------------------------------------------
		END

		IF @ViewName = '[AIProfile]'
		BEGIN
			SELECT @Where = ' INNER JOIN Jobs ON Jobs.Job = [AIProfile].[Job Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON Positions.PositionNo = [AIProfile].[Position Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON Organization.Organization = [AIProfile].[Organization Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(organizationroles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON Grades.Grade = [AIProfile].[Grade Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON Location.LocationNo = [AIProfile].[Location No] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN HrStatus ON HrStatus.HrStatus = [AIProfile].[HR Status Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(HrstatusRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END 


		IF @ViewName = '[AIVacations]'
		BEGIN
			SELECT @Where += '  
							   INNER JOIN Vacation ON [AIVacations].[Vacation Code] = Vacation.vaccode AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(VacationRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)'
		END

		IF @ViewName = '[AIChangeOfStatus]'
		BEGIN
			SELECT @Where += ' INNER JOIN ChngStat ON [AIChangeOfStatus].[Change Code] = ChngStat.chgcode AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(ChngStatRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIMisconduct]'
		BEGIN
			SELECT @RoleFields = '  MscondctRoles'
			SELECT @Where += ' INNER JOIN Mscondct ON Mscondct.mscode = [AIMisconduct].[Misconduct Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(MscondctRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)  '
		END

		IF @ViewName = '[AICompetencies]'
		BEGIN
			SELECT @Where += ' INNER JOIN Competencies on [AICompetencies].[Competence Code] = Competencies.Competence AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CompetenciesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIDocuments'
		BEGIN
			SELECT @Where += ' INNER JOIN Document on [AIDocuments].[Document Id] = Document.docid AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(DocumentRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AITimeKeeping]'
		BEGIN
			SELECT @Where += ' INNER JOIN TimeShifts ON [AITimeKeeping].[Shift No] = TimeShifts.ShiftNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TimeShiftsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AITraining]'
		BEGIN
			SELECT @Where += ' INNER JOIN TrainingActivities ON [AITraining].[Training Activity Code] = TrainingActivities.TrainingActivity AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TrainingActivitiesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) 
			INNER JOIN TrainingEnrollStatus ON [AITraining].[Enroll Status Code] = TrainingEnrollStatus.EnrollStatus AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TrainingEnrollStatusRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN TrainingEvents ON [AITraining].[Training Event Code] = TrainingEvents.TrainingEvent AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TrainingEventsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN TrainingPlans ON [AITraining].[Additional Training Plan] = TrainingPlans.TrainingPlan AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TrainingPlansRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON [AITraining].[Position Code] = Positions.PositionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON [AITraining].[Job Code] = Jobs.job AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN TrainingEventStatus ON [AITraining].[Event Status Code] = TrainingEventStatus.EventStatus AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TrainingEventStatusRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON [AITraining].[Organization Code] = Organization.Organization AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON [AITraining].[Grade Code] = Grades.Grade AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON [AITraining].[Location No] = Location.LocationNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN TrainingCenters ON [AITraining].[Training Center Code] = TrainingCenters.TrainingCenter AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(TrainingCentersRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)'
		END


		IF @ViewName = '[AIMedical]'
		BEGIN
			SELECT @Where += ' INNER JOIN MedicalCategories ON [AIMedical].[Medical Category Code] = MedicalCategories.MedicalCategory AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(MedicalCategoriesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Currency ON [AIMedical].[Currency Code]= Currency.cur AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CurrencyRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN MedicalItems ON [AIMedical].[Medical Item] = MedicalItems.MedicalItem AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(MedicalItemsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Service ON [AIMedical].[Service No] = Service.ServiceNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(ServiceRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Supplier ON [AIMedical].[Supplier No] = Supplier.SupplierNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(SupplierRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON Jobs.Job = [AIMedical].[Job Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON Positions.PositionNo = [AIMedical].[Position Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON Organization.Organization = [AIMedical].[Organization Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(organizationroles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON Grades.Grade = [AIMedical].[Grade Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON Location.LocationNo = [AIMedical].[Location No] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END


		IF @ViewName = '[AIStaffHousing]'
		BEGIN
			SELECT @Where += ' INNER JOIN HKItems ON [AIStaffHousing].[Item Code] = HKItems.HKItem AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(HKItemsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) 
			INNER JOIN HkItemTypes ON [AIStaffHousing].[Item Type Code] = HkItemTypes.HkItemType AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(HkItemTypesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN StaffBuildings ON [AIStaffHousing].[Building No] = StaffBuildings.BuildingNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(StaffBuildingsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN StaffRooms ON [AIStaffHousing].[Room No] = StaffRooms.RoomNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(StaffRoomsRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1)
			INNER JOIN StaffRoomTypes ON [AIStaffHousing].[Room Type] = StaffRoomTypes.RoomType AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(StaffRoomTypesRoles, '''') + ''$'', '+@SSGroupField+', ' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIBenefits]'
		BEGIN
			SELECT @Where += ' INNER JOIN BenefitPlans ON [AIBenefits].[Plan No] = BenefitPlans.PlanNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(BenefitPlansRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Currency ON [AIBenefits].[Currency Code] = Currency.Cur AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CurrencyRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN BenefitOptions ON [AIBenefits].[Option No] = BenefitOptions.OptionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(BenefitOptionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN BenefitItems ON [AIBenefits].[Item No] = BenefitItems.ItemNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(BenefitItemsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Supplier ON [AIBenefits].[Supplier No] = Supplier.SupplierNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(SupplierRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Service ON [AIBenefits].[Service No] = Service.ServiceNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(ServiceRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON [AIBenefits].[Job Code] = Jobs.Job AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON [AIBenefits].[Position Code] = Positions.PositionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON [AIBenefits].[Organization Code] = Organization.Organization AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON [AIBenefits].[Grade Code] = Grades.Grade AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON [AIBenefits].[Location No] = Location.LocationNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIRecruitment]'
		BEGIN
			SELECT @Where += ' INNER JOIN Positions ON [AIRecruitment].[Position Code] = Positions.PositionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON [AIRecruitment].[Job Code] = Jobs.Job AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON [AIRecruitment].[Organization Code] = Organization.Organization AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Vacancies ON [AIRecruitment].[Vacancy No] = Vacancies.VacancyNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(VacanciesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN RecruitmentActivities ON [AIRecruitment].[Recruitment Activity Code] = RecruitmentActivities.RecruitmentActivity AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(RecruitmentActivitiesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN ApplicationStatus ON [AIRecruitment].[Application Status Code] = ApplicationStatus.ApplicationStatus AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(ApplicationStatusRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN ApplicationSource ON [AIRecruitment].[Application Source] = ApplicationSource.ApplicationSource AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(ApplicationSourceRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON [AIRecruitment].[Location No] = Location.LocationNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Currency ON [AIRecruitment].[Currency] = Currency.Cur AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CurrencyRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Cities ON [AIRecruitment].[City Id] = Cities.CityID AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CitiesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Graduate ON [AIRecruitment].[Graduate Code] = Graduate.Graduate AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GraduateRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON [AIRecruitment].[Grade Code] = Grades.Grade AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END

		

		IF @ViewName = '[AIFinancialHistory]'
		BEGIN
			SELECT @Where += ' INNER JOIN PayrollGroup ON [AIFinancialHistory].[Payroll GroupCode] = PayrollGroup.PayrollGroup AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PayrollGroupRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Paycode ON [AIFinancialHistory].[Paycode] = Paycode.Code AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PayCodeRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Currency ON [AIFinancialHistory].[Currency Code] = Currency.Cur AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CurrencyRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN PaycdGrp ON [AIFinancialHistory].[Paycode Group Code] = PaycdGrp.GrpCode AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PaycdGrpRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON [AIFinancialHistory].[Job Code] = Jobs.Job AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON [AIFinancialHistory].[Grade Code] = Grades.Grade AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON [AIFinancialHistory].[Position Code] = Positions.PositionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON [AIFinancialHistory].[Organization Code] = Organization.Organization AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON [AIFinancialHistory].[Location No] = Location.LocationNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIFinancialMonthly]'
		BEGIN
			SELECT @Where += ' INNER JOIN PayrollGroup ON [AIFinancialMonthly].[Payroll Group Code] = PayrollGroup.PayrollGroup AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PayrollGroupRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Paycode ON [AIFinancialMonthly].Paycode = Paycode.Code AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PayCodeRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Currency ON [AIFinancialMonthly].[Payroll GROUP Currency Code] = Currency.Cur AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CurrencyRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN PaycdGrp ON [AIFinancialMonthly].[Paycode Group] = PaycdGrp.GrpCode AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PaycdGrpRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON [AIFinancialMonthly].[Job Code] = Jobs.Job AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON [AIFinancialMonthly].[Grade Code] = Grades.Grade AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON [AIFinancialMonthly].[Position Code] = Positions.PositionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON [AIFinancialMonthly].[Organization Code] = Organization.Organization AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIFinancialPaymentHistory ]'
		BEGIN
			SELECT @Where += ' INNER JOIN PayrollGroup ON [AIFinancialPaymentHistory ].[Payroll Group Code] = PayrollGroup.PayrollGroup AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PayrollGroupRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON [AIFinancialPaymentHistory ].[Job Code] = Jobs.Job AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON [AIFinancialPaymentHistory ].[Grade Code] = Grades.Grade AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON [AIFinancialPaymentHistory ].[Position Code] = Positions.PositionNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON [AIFinancialPaymentHistory ].[Organization Code] = Organization.Organization AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON [AIFinancialPaymentHistory ].[Location No] = Location.LocationNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIFinancialPaymentMonthly]'
		BEGIN
			SELECT @Where += ' INNER JOIN PayrollGroup ON [AIFinancialPaymentMonthly].[Payroll Group Code] = PayrollGroup.PayrollGroup AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PayrollGroupRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END

		IF @ViewName = '[AIPerformance]'
		BEGIN
			SELECT @Where += ' INNER JOIN Appraisals ON [AIPerformance].[Appraisal No] = Appraisals.AppraisalNo AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(AppraisalsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Competencies ON [AIPerformance].[Competence Code] = Competencies.Competence AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(CompetenciesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Jobs ON Jobs.Job = [AIPerformance].[Job Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(JobsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Positions ON Positions.PositionNo = [AIPerformance].[Position Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(PositionsRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Organization ON Organization.Organization = [AIPerformance].[Organization Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(OrganizationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Grades ON Grades.Grade = [AIPerformance].[Grade Code] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(GradesRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1)
			INNER JOIN Location ON Location.LocationNo = [AIPerformance].[Location No] AND (dbo.RolesExist(''' + @RoleID + ''',''$'' + ISNULL(LocationRoles, '''') + ''$'',' + @SSGroupField + ',' + LTRIM(@UserId) + ') = 1) '
		END
	
		
	END
RETURN @Where

END

GO

