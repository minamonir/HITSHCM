
CREATE FUNCTION [dbo].[WebAPI2ApplyRoles] 
	(@RoleFields AS  NVARCHAR(MAX),@UserLogonName AS NVARCHAR(80),@EmpID AS INT=0, @ItemNo AS SMALLINT=0) RETURNS NVARCHAR(MAX)
AS

--declare @RoleFields as  NVARCHAR(max)=N'vacationroles',@UserLogonName as nvarchar(80)='1', @EmpID as int=216268, @parentno AS SMALLINT=26511
BEGIN	
	declare @Where AS NVARCHAR(max),@TableRoles AS NVARCHAR(max), @emptyRoles as nvarchar(max)=N''
	DECLARE @Roles TABLE (RoleId SMALLINT)

	----------------------Only For versions 201701 and 202001---------------------
	Declare @ItemNoEnabled as bit=0
	--DECLARE @ItemNoList TABLE (ItemNo bigint, ItemName nvarchar(max))
	--DECLARE @RolesList TABLE (Code bigint, name nvarchar(max))
	------------------------------------------------------------------------------
	DECLARE  @i AS INT
	SET @Where=''
	SET @i = 1

	DECLARE @RolesWhere AS nvarchar(max),@UserId AS INT,@ApplySSgrp AS bit,@MySelfParmExist AS INT,@EnableReportsRoles AS INT 
	SELECT @UserId=nasusers.EmpId,@ApplySSgrp=nasusers.ApplySSGroups from nasusers  where @UserLogonName=logonname

	    ----------------------Only For versions 201701 and 202001---------------------
		DECLARE @TempWhere as nvarchar(max), @count as int = 0, @J as int=0, @str as nvarchar(max)=N''

	    set @TempWhere=N' and empid='+str(@EmpID)+' and profileid='+str(@UserId)+'  '

		------------------------------------------------------------------------------

	IF (SELECT SysParam.EnableRoleValidation FROM SysParam )=1 AND (@ApplySSgrp=1)
	BEGIN 
		 --SELECT  @RoleFields = TableRoleFields FROM ReportsTables 
		 --WHERE ReportNo=@ReportNo AND TableName=@Tablename
		 --select @RoleFields = ltrim(rtrim(isnull(@RoleFields,'')))

		 
		 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'NasOptionsRoleEnabledItems') )
BEGIN
         ----------------------Only For versions 201701 and 202001---------------------
		 select  @ItemNoEnabled=NasOptionsRoleEnabledItems.Enabled
	            from NasOptionsRoleEnabledItems
	            inner join NasOptions on NasOptions.itemno = NasOptionsRoleEnabledItems.itemno where  Enabled=1 and NasOptionsRoleEnabledItems.ItemNo=@ItemNo
END

		 if @ItemNoEnabled=1
		 begin
		    INSERT INTO @Roles
			 select DISTINCT roleid from ssgrouprole 
                inner join empassignment on empassignment.ssgroup =ssgrouprole.ssgroup 
				where empid=@EmpID and profileid=@UserId
		 end
		 ELSE
		 BEGIN
		     INSERT INTO @Roles  SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId = @UserId 
		 END
		 
	
		 --------------------------------------------------------------------------

	 	  
	IF @RoleFields <>''
	BEGIN
		IF substring(@RoleFields,len(@RoleFields)-1,1) <> ',' select @RoleFields=  @RoleFields+','
	IF LEFT(@RoleFields,1) <> ',' SELECT @RoleFields=  ','+@RoleFields
	

	 --For i = 0 To RolesList.Count - 1

  --    str = str + If(Trim(str) = "", "", " or ") + "(" + Trim(RolesFields(field)) + " like '%#" + Trim(RolesList.Item(i).ToString) + "#%' )"

  --   Next
  
  ----------------------Only For versions 201701 and 202001---------------------
		 --print 'else part'
		WHILE CHARINDEX(',',@RoleFields,@i) < LEN(@RoleFields)
		BEGIN
		SET @i = CHARINDEX(',',@RoleFields,@i)
		SET @i = @i + 1
		SET @TableRoles = SUBSTRING(@RoleFields,@i,(CHARINDEX(',',@RoleFields,@i) - (CHARINDEX(',',@RoleFields,@i-1)))-1)
		--SET @Where = @Where+'AND('+ @TableRoles + '='''' OR '+@TableRoles+' IS NULL'
		SET @Where = @Where+'AND('+ @TableRoles + '='''' '
		SELECT  @Where = @Where+' OR '+@TableRoles+' LIKE''%#'+CAST(RoleId AS NVARCHAR(8))+'#%''' 
		FROM @Roles
		SELECT  @Where = @Where+')'
		CONTINUE
		END
		IF @Where <> ''
			SET @Where = 'AND'+SUBSTRING(@Where,4,LEN(@Where))+''
		END
		-- BEGIN
		-- --print 'else part'
		--WHILE CHARINDEX(',',@RoleFields,@i) < len(@RoleFields)
		--BEGIN
		--SET @i = CHARINDEX(',',@RoleFields,@i)
		--SET @i = @i + 1
		--SET @TableRoles = SUBSTRING(@RoleFields,@i,(CHARINDEX(',',@RoleFields,@i) - (CHARINDEX(',',@RoleFields,@i-1)))-1)
		----SET @Where = @Where+'AND('+ @TableRoles + '='''' OR '+@TableRoles+' IS NULL'
		--SET @emptyRoles=@emptyRoles+' OR ('+ @TableRoles + '='''' OR '+@TableRoles+' IS NULL)'

		----SELECT  @Where = @Where+' OR '+@TableRoles+' LIKE''%#'+CAST(RoleId AS NVARCHAR(4))+'#%''' 
		--SELECT  @Where = @Where+(case when ltrim(rtrim(@Where))=N'' then N'' else ' OR ' end) +@TableRoles+' LIKE''%#'+CAST(RoleId AS NVARCHAR(4))+'#%'''
		--FROM @Roles

		--SELECT  @Where = ( case when ltrim(rtrim(@Where))=N'' then N'' else ' And ( '+ ltrim(rtrim(@Where)) + ' )' end)+ @emptyRoles
		
		----SELECT  @Where = @Where+')'
		--CONTINUE
		--END
		----IF @Where <> ''
		----	SET @Where = 'AND'+SUBSTRING(@Where,4,len(@Where))+''
		--END
	END
	--END 
RETURN @Where
END

GO

