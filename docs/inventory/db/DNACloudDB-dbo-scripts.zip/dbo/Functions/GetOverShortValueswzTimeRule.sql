CREATE FUNCTION [dbo].[GetOverShortValueswzTimeRule] (@Empid INT , @FromDate smalldatetime, @ToDate smalldatetime,@UsePermission BIT , @UseVacation BIT ,
 @DayHoursType SMALLINT , @DayHours numeric(18,3) , @OverrideVacation SMALLINT , @GetPermissionWhenNoReadings SMALLINT, @OverShort SMALLINT,@HourFactor decimal(9,3),@CalFactor BIT,
 @RequiredHours AS NUMERIC(18,3))
 
 RETURNS numeric(18,3)
AS
BEGIN
 
 --SELECT @Empid = 36 , @FromDate = '2014/01/01', @ToDate='2014/01/31',@UsePermission =1 , @UseVacation =1 ,
 --@DayHoursType =3, @DayHours =8 , @OverrideVacation=0 , @GetPermissionWhenNoReadings=0,@AccumulateRanges=1, @OverShort = 8,--4
 --@HourFactor=1,@CalFactor=0,@RequiredHours=40
 
 -- @OverShort	OverShortName
-- 1	Over [Early In]                         
-- 2	Over [Late Out]                         
-- 3	Over [Working Out of working hours] 
-- 4    Over [Total]    
-- 5	Short [Late In]                         
-- 6	Short [Early Out]                       
-- 7	Short [Exit during working hours]       
-- 8    Short [Total]

-- @UsePermission               : calculate the permission hours on working hours or not
-- @UseVacation                 : calculate the vacation Hours on working hours or not
-- @DayHourType                 : calculate the DayHours from PayrollGroup Setup (0) ,Shift Hours (1) , Fixed from @DayHourFactor (2)
-- @DayHourFactor               : the fixed Day Hours ( used when @DayHourType=3)
-- @OverrideVacation            : determines whether calculate the working hours from readings  (1)  or calculate the vacation Hours (0)
-- @GetPermissionWhenNoReadings : calculate the Permission hours when there is no readings (1) or not (0)
-- @AccumulateRanges            : calculate over or short according the check of accumlate ranges in the time rules
-- @HourFactor                  : The factor if the value will be maltiplied in a factor
-- @CalFactor                   : If the value will be maltiplied in a factor or not

 
 DECLARE @ActualHours AS numeric(18,3), @OverValue as numeric(18,3), @Hours AS numeric(18,3),@HourlyPayroll AS bit
 
 
 DECLARE @TimeRule AS SMALLINT,@AccumulateRanges as BIT,@HWorkingPerDay AS NUMERIC(18,3)=0,@HMaxOverPerDayPaycode AS SMALLINT,@inputtp AS SMALLINT=0



SELECT @TimeRule=EmpAssignment.TimeRule,@AccumulateRanges=CASE WHEN @OverShort IN (1,2,3,4) then TimeRules.OverAccumulateRanges  WHEN @OverShort IN (5,6,7,8) then TimeRules.ShortAccumulateRanges end ,@HourlyPayroll=HourlyPayroll
FROM EmpAssignment
LEFT JOIN TimeRules ON TimeRules.TimeRule = EmpAssignment.TimeRule
WHERE EmpAssignment.EmpId=@Empid

--SELECT @DayType=WpType,@RequiredHours=WpRequiredHours 
--FROM TimeRules
--WHERE TimeRule=@TimeRule

--PRINT @ToDate

--PRINT 'RequiredHours: '+ str(@RequiredHours) 
 
 select @OverValue=0,  @ActualHours=0
 
 
 IF @HourlyPayroll=0
 BEGIN
 ----------------------------------------------
 IF @RequiredHours =0 ---- it means that the total required hours will be calculated according to the total shift hours in this period 
 BEGIN
	 DECLARE @RequiredHoursTemp AS NUMERIC(18,3),@FromDateTemp AS SMALLDATETIME,@HolidaysDays AS NUMERIC(18,3) 
 
	 SELECT @RequiredHoursTemp=SUM(ShiftSeconds)/3600.00 FROM dbo.EmpShiftInOut WHERE empid=@Empid AND EntryDate BETWEEN @FromDate AND @ToDate
	 
	 SELECT @FromDateTemp=@FromDate
	 	
	DECLARE @ActualDayHours AS numeric(18,3)

	SELECT @ActualDayHours= (CASE WHEN @DayHoursType=0 THEN PayrollGroup.DayHours WHEN @DayHoursType=1 THEN PayrollGroup.DayHours  WHEN @DayHoursType=3 THEN TimeRules.HWorkingPerDay ELSE @DayHours END )
	FROM EmpAssignment 
	LEFT JOIN  PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
	LEFT JOIN dbo.TimeRules ON TimeRules.TimeRule = EmpAssignment.TimeRule
	WHERE EmpAssignment.EmpId=@Empid

	IF @UseVacation =1
	begin
	 WHILE @FromDateTemp<=@ToDate
		BEGIN
		IF NOT exists(SELECT * FROM dbo.EmpShift WHERE empid=@empid AND ShiftDate=@FromDateTemp AND ShiftNo IS NOT null)
		BEGIN
				SELECT @HolidaysDays=0
				SELECT @HolidaysDays=dbo.isholiday(@Empid,@FromDateTemp,1)
				IF @HolidaysDays IN (1,3) 
				BEGIN
				 SET @RequiredHoursTemp= @RequiredHoursTemp+@ActualDayHours
				end
		END
		SET @FromDateTemp=convert(char(10),DATEadd(d,1,@FromDateTemp),111)
		END
   end
	 SELECT @RequiredHours=@RequiredHoursTemp
	  
 END

 --------------------------------------------------
 	   SELECT @ActualHours= dbo.GetActualWorkingHours(@Empid,@FromDate, @ToDate,
                                               @UsePermission, @UseVacation, @DayHoursType, @DayHours, @OverrideVacation,
                                               @GetPermissionWhenNoReadings)
                                               
	   SELECT @Hours=CASE WHEN ((@OverShort IN (1,2,3,4)) AND (@ActualHours>@RequiredHours)) THEN (@ActualHours-@RequiredHours) WHEN ((@OverShort IN (5,6,7,8)) AND (@ActualHours<@RequiredHours)) THEN (@RequiredHours-@ActualHours) ELSE 0 END
	   
		if  exists(select Timerule FROM TimeRulesTimes where TimeRule=@TimeRule and overshort=CASE WHEN @OverShort=0 THEN overshort ELSE @OverShort END)
		BEGIN
			IF @Hours<>0
			BEGIN
				if @AccumulateRanges=0
					select @OverValue=@OverValue+isnull(max(dbo.roundto(@Hours,RoundMethod,RoundTo)*CASE WHEN @CalFactor=1 THEN HourFactor  else 1.0 end),0)
					from TimeRulesTimes
					where TimeRule=@TimeRule
					and (@Hours between FromHours and ToHours) 
					and @Hours>MinHours
					--and overshort=case when @valuetype=1 then 4 else 8 end 
					AND overshort=CASE WHEN @OverShort=0 THEN overshort ELSE @OverShort END 
					AND HourFactor=CASE WHEN @HourFactor=0 THEN HourFactor ELSE @HourFactor END
				else
					select @OverValue=@OverValue+isnull(sum(dbo.roundto((case when @Hours>ToHours then ToHours else @Hours end)-FromHours,RoundMethod,RoundTo)* CASE WHEN @CalFactor=1 THEN HourFactor  else 1.0 end),0)
					from TimeRulesTimes
					where TimeRule=@TimeRule
					and (@Hours>=FromHours) 
					and @Hours>MinHours 
					--and overshort=case when @valuetype=1 then 4 else 8 end 
					AND overshort=CASE WHEN @OverShort=0 THEN overshort ELSE @OverShort END 
					AND HourFactor=CASE WHEN @HourFactor=0 THEN HourFactor ELSE @HourFactor END
			END

		END
      
 END
 ELSE
 BEGIN
 	IF @OverShort=0 ---- workin hours( wz hourly payroll=1)
 	begin
 		 SELECT @ActualHours=SUM(empshiftinout.WorkSeconds/case when timerules.HWorkingPerDay=0 then 1 else isnull(CASE WHEN Paycode.inputtp=2 THEN (timerules.HWorkingPerDay*1.00) ELSE 1.00 END,1) END )/3600.0
 		 FROM  empshiftinout
 		 inner JOIN TimeRules ON TimeRules.TimeRule=dbo.GetOldValue(@empid,28,entrydate+1,NULL) AND  empid=@empid AND entrydate BETWEEN @FromDate AND @ToDate
 		 LEFT JOIN Paycode ON Paycode.code=timerules.HWorkingPerDayPaycode
 		  WHERE empid=@empid AND entrydate BETWEEN @FromDate AND @ToDate
 		 
 		 SET @OverValue= isnull(@ActualHours,0)
 		 
 	END
 	ELSE
 	BEGIN
	    ----- over hours ( wz hourly payroll=1)
			DECLARE @TempFrom AS SMALLDATETIME,@TempOverValue AS NUMERIC(18,3)
			SET @TempFrom=@FromDate
			SET @TempOverValue=0
		
			 	
			WHILE @TempFrom<=@ToDate
			BEGIN
					SELECT @ActualHours=SUM(empshiftinout.OverSeconds)/3600.0
					FROM  empshiftinout WHERE empid=@empid AND entrydate = @TempFrom  AND @OverShort IN (4)
					
					SET @Hours=isnull(@ActualHours,0)
					SET @TempOverValue=0
					
					if  exists(select Timerule FROM TimeRulesTimes where TimeRule=@TimeRule and overshort=CASE WHEN @OverShort=0 THEN overshort ELSE @OverShort END)
					BEGIN
						IF @Hours<>0
						BEGIN
							if @AccumulateRanges=0
								select @TempOverValue=@TempOverValue+isnull(max(dbo.roundto(@Hours,RoundMethod,RoundTo)*CASE WHEN @CalFactor=1 THEN HourFactor  else 1.0 end),0)
								from TimeRulesTimes
								where TimeRule=@TimeRule
								and (@Hours between FromHours and ToHours) 
								and @Hours>MinHours
								--and overshort=case when @valuetype=1 then 4 else 8 end 
								AND overshort=CASE WHEN @OverShort=0 THEN overshort ELSE @OverShort END 
								AND HourFactor=CASE WHEN @HourFactor=0 THEN HourFactor ELSE @HourFactor END
							else
								select @TempOverValue=@TempOverValue+isnull(sum(dbo.roundto((case when @Hours>ToHours then ToHours else @Hours end)-FromHours,RoundMethod,RoundTo)* CASE WHEN @CalFactor=1 THEN HourFactor  else 1.0 end),0)
								from TimeRulesTimes
								where TimeRule=@TimeRule
								and (@Hours>=FromHours) 
								and @Hours>MinHours 
								--and overshort=case when @valuetype=1 then 4 else 8 end 
								AND overshort=CASE WHEN @OverShort=0 THEN overshort ELSE @OverShort END 
								AND HourFactor=CASE WHEN @HourFactor=0 THEN HourFactor ELSE @HourFactor END
						END

					END
					
					 SELECT @HWorkingPerDay=1,@inputtp=0
					
				     select @HWorkingPerDay =timerules.HWorkingPerDay,@HMaxOverPerDayPaycode=HMaxOverPerDayPaycode from TimeRules  where TimeRule=dbo.GetOldValue(@empid,28,@TempFrom+1,NULL) 
				     SELECT @inputtp=inputtp FROM Paycode WHERE code=@HMaxOverPerDayPaycode
					
					SET @OverValue=@OverValue+isnull(@TempOverValue,0)/case when @HWorkingPerDay=0 then 1 else isnull(CASE WHEN @inputtp=2 THEN (@HWorkingPerDay*1.00) ELSE 1.00 END,1) end
					SET @TempFrom = @TempFrom +1
			END
			--RETURN isnull(@OverValue,0)
 	END
 	

 END


                                    
                                               



RETURN isnull(@OverValue,0)

END

GO

