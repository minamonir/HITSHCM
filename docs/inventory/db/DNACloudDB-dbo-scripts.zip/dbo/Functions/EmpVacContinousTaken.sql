
CREATE FUNCTION [dbo].[EmpVacContinousTaken] (@empid int, @DateFrom smalldatetime,@DateTo smalldatetime,@VacCode As nvarchar(MAX), @MinContinousDays as int) 
RETURNS numeric(18,3)
AS
BEGIN

--DECLARE @empid int, @DateFrom smalldatetime,@DateTo smalldatetime,@VacCode as int, @MinContinousDays as int
--select  @empid = 216587, @DateFrom = '2021-01-01' , @DateTo = '2022-12-31', @VacCode = 1 , @MinContinousDays = 2

Declare @LongestPeroidTaken as numeric (18,3) = 0

DECLARE @from AS datetime
DECLARE @To AS datetime
DECLARE @VacTakenDays AS numeric(18,3) 

DECLARE @PrevToDate AS datetime
DECLARE @ContDays AS numeric(18,3) = 0

--- filter by vactakendays>= @MinContinousDays
DECLARE tempemployee cursor for
SELECT 
EmpVacat.FromDate,
EmpVacat.ToDate
,dbo.vactakendays(EmpVacat.EmpId, CASE WHEN @DateFrom > EmpVacat.FromDate THEN @DateFrom ELSE EmpVacat.FromDate END , CASE WHEN @DateTo < Empvacat.ToDate THEN @DateTo ELSE EmpVacat.ToDate END
,Empvacat.VacCode, empvacat.DocumentNo, empvacat.PartDayFrom, empvacat.PartDayTo)
FROM EmpVacat 
LEFT JOIN Empassignment on EmpVacat.Empid = EmpAssignment.Empid
where EmpVacat.VacStatus=1 
AND EmpVacat.EmpId = @empid 
--AND EmpVacat.VacCode = @VacCode
--and ( @VacCode like '%' + ','+ltrim(rtrim(EmpVacat.VacCode ))+',' + '%')
and ( @VacCode like '%' + ltrim(rtrim(EmpVacat.VacCode )) + '%')
AND ((EmpVacat.FromDate Between @DateFrom And @DateTo)
Or (EmpVacat.ToDate Between @DateFrom AND @DateTo)
Or (@DateFrom Between EmpVacat.FromDate And EmpVacat.ToDate)
Or (@DateTo Between EmpVacat.FromDate And EmpVacat.ToDate)) 
Order By Empvacat.EmpId, EmpVacat.Fromdate

 -- Curser
OPEN tempemployee
FETCH NEXT FROM tempemployee
INTO  @from,@To,@VacTakenDays
WHILE @@FETCH_STATUS = 0
 BEGIN	

  		IF @from=dateadd(dd,1,@PrevToDate)
   		  BEGIN
			set @ContDays=@ContDays+@VacTakenDays
			if @ContDays>=@MinContinousDays
   			BEGIN
		      SET @LongestPeroidTaken = CASE WHEN (@ContDays > @LongestPeroidTaken) THEN @ContDays ELSE @LongestPeroidTaken  END
			  --set @ContDays=0
   			END	

	    --SET @PrevToDate=@To
   		END --  end first condition

   		ELSE
   		BEGIN
		set @ContDays=@VacTakenDays
   		  if @ContDays>=@MinContinousDays
		  begin
		  SET @LongestPeroidTaken = CASE WHEN (@ContDays > @LongestPeroidTaken) THEN @ContDays ELSE @LongestPeroidTaken  END
		  --SET @ContDays=0
		  END 
   		END  -- end else

    SET @PrevToDate  = @To 


	FETCH NEXT FROM tempemployee
	INTO @from,@To,@VacTakenDays
-- end while loop
   END
   
CLOSE tempemployee
DEALLOCATE tempemployee	


  RETURN @LongestPeroidTaken
END

GO

