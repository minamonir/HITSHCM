-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ConcatAbsentDates]
(@empId int, @trainingEvent int, @docNo int, @lang nchar(1))
RETURNS nvarchar(max)
AS
BEGIN
	DECLARE @strDate AS nvarchar(max), @dateformat AS int 
	SELECT @dateformat = DateFormat FROM sysparam
	SET @strDate = N''
	
	IF @lang = 'A'
	BEGIN
		SELECT @strDate = CASE WHEN @dateformat =1 THEN CONVERT(Nchar(10),TimeIn,111)
		WHEN @dateformat=2 THEN substring(CONVERT(Nvarchar(10), TimeIn, 111),1,4)+'/'+substring(CONVERT(Nvarchar(10), TimeIn, 111),9,2)+'/'+substring(CONVERT(Nvarchar(10), TimeIn, 111),6,2)
		ELSE CONVERT(Nchar(10),TimeIn,103) END + ', '+@strDate
		FROM EmpTrainingAttendance
		WHERE EmpTrainingAttendance.TrainingEvent = @trainingEvent 
		AND EmpTrainingAttendance.empid = @empId 
		AND EmpTrainingAttendance.DocumentNo = @docNo
		AND EmpTrainingAttendance.Attendance=0
		ORDER BY EmpTrainingAttendance.TimeIn DESC 
	END 
	ELSE
	BEGIN 
		SELECT @strDate = CASE WHEN @dateformat =1 THEN CONVERT(Nchar(10),TimeIn,103)
		WHEN @dateformat=2 THEN CONVERT(Nchar(10),TimeIn,101)
		ELSE CONVERT(Nchar(10),TimeIn,111) END + ', '+@strDate
		FROM EmpTrainingAttendance
		WHERE EmpTrainingAttendance.TrainingEvent = @trainingEvent 
		AND EmpTrainingAttendance.empid = @empId 
		AND EmpTrainingAttendance.DocumentNo = @docNo
		AND EmpTrainingAttendance.Attendance=0
		ORDER BY EmpTrainingAttendance.TimeIn DESC 
	END
	
	SET @strDate = LEFT(@strDate, Len(@strDate)-1)
	RETURN @strDate
END

GO

