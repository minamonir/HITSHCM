
CREATE  FUNCTION [dbo].[EmpQuestionsRaterScore] (@empid as int,@DocumentNo as int ,@RaterProfileid as int)  
RETURNS numeric(18,3)  AS  
begin

declare  @Score as  numeric(18,3),@totalQuestionsweight numeric(18,3)
set @totalQuestionsweight=0

--we added this condition AND Questions.QuestionType <> CASE WHEN empappraisalques.UseManualResult=1 THEN 0 ELSE 1 END 
--to consider in calculations the questions of type text  in case the  question score is calculated based on Manual Result

select  top 1   @totalQuestionsweight=sum(AppraisalQuestions.QuestionWeight) 
FROM  EmpAppraisal left OUTER JOIN
EmpAppraisalQues ON EmpAppraisalQues.empid=EmpAppraisal.empid AND EmpAppraisalQues.DocumentNo=EmpAppraisal.DocumentNo 
left OUTER JOIN AppraisalQuestions ON EmpAppraisalQues.QuestionNo = AppraisalQuestions.QuestionNo 
                AND AppraisalQuestions.AppraisalNo=EmpAppraisal.AppraisalNo 
LEFT JOIN Questions ON Questions.QuestionNo=EmpAppraisalQues.QuestionNo
where  EmpAppraisalQues.EmpId=@empid AND EmpAppraisalQues.DocumentNo=@documentno 
--AND Questions.QuestionType<>1
AND Questions.QuestionType <> CASE WHEN empappraisalques.UseManualResult=1 THEN 0 ELSE 1 END 
 and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
group by RaterProfileId

declare @QuesScore table(EmpId int,DocumentNo int,RaterProfileId int,QuesScore numeric (18,3))
--SELECT @totalQuestionsweight

------------------------------------------------------------
INSERT @QuesScore	--UseManualResult=0
SELECT EmpAppraisalQues.empid,EmpAppraisalQues.DocumentNo,
EmpAppraisalQues.RaterProfileid,
min(CASE WHEN charindex(ltrim(rtrim(str(QuestionOptions.QuestionOption)))+',',cast(EmpAppraisalQues.QuestionAnswer AS nvarchar(max))+',')>0 THEN correctflag   ELSE (CASE WHEN correctflag =1 THEN 0 ELSE 1 END) END)* AppraisalQuestions.QuestionWeight
FROM EmpAppraisalQues 
inner JOIN EmpAppraisal ON EmpAppraisal.EmpId = EmpAppraisalQues.EmpId AND EmpAppraisal.DocumentNo = EmpAppraisalQues.DocumentNo
inner JOIN Appraisals  ON Appraisals.AppraisalNo=EmpAppraisal.AppraisalNo
inner JOIN AppraisalQuestions  ON AppraisalQuestions.QuestionNo = EmpAppraisalQues.QuestionNo 
AND EmpAppraisal.AppraisalNo=AppraisalQuestions.AppraisalNo
LEFT JOIN Questions  ON Questions.QuestionNo=AppraisalQuestions.QuestionNo 
LEFT JOIN QuestionOptions ON QuestionOptions.QuestionNo= Questions.QuestionNo AND Questions.QuestionType<>1
WHERE EmpAppraisalQues.EmpId=@empid AND EmpAppraisalQues.DocumentNo=@documentno AND EmpAppraisalQues.RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
and Questions.QuestionType<>1
AND  EmpAppraisalQues.UseManualResult=0
GROUP BY EmpAppraisalQues.QuestionNo,AppraisalQuestions.QuestionWeight
,EmpAppraisalQues.empid,EmpAppraisalQues.DocumentNo,
EmpAppraisalQues.QuestionNo,
--Questions.QuestionText,AppraisalQuestions.QuestionWeight,
EmpAppraisalQues.RaterProfileid
------------------------------------------------------------
INSERT @QuesScore	--UseManualResult=1
SELECT EmpAppraisalQues.empid,
       EmpAppraisalQues.DocumentNo,
       EmpAppraisalQues.RaterProfileid,
       (EmpAppraisalQues.QuestionManualResult * AppraisalQuestions.QuestionWeight )/100 
FROM   EmpAppraisalQues
INNER JOIN EmpAppraisal ON   EmpAppraisal.EmpId = EmpAppraisalQues.EmpId AND   EmpAppraisal.DocumentNo = EmpAppraisalQues.DocumentNo
INNER JOIN AppraisalQuestions ON   AppraisalQuestions.QuestionNo = EmpAppraisalQues.QuestionNo AND   EmpAppraisal.AppraisalNo = AppraisalQuestions.AppraisalNo
WHERE  EmpAppraisalQues.EmpId = @empid
  AND  EmpAppraisalQues.DocumentNo = @documentno
  AND  EmpAppraisalQues.RaterProfileid = CASE 
                                              WHEN @RaterProfileid = 0 THEN RaterProfileid
                                              ELSE @RaterProfileid
                                         END
  AND  EmpAppraisalQues.UseManualResult=1
------------------------------------------------------------

declare @RaterScore table(RaterProfileId int,score numeric (18,3))

INSERT INTO @RaterScore
SELECT RaterProfileid,(sum(QuesScore)/case when @totalQuestionsweight=0 then 1 else @totalQuestionsweight end)*100 FROM @QuesScore GROUP BY RaterProfileid
--SELECT * FROM @RaterScore
SELECT   @Score = avg(Score) FROM @RaterScore 

return  isnull(@Score,0)
--select isnull(@Score,0)

end

GO

