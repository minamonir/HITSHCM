
--this fn converts the Amount from currency to another Currency using  exchange rate at the specified Exchange Date

CREATE  FUNCTION [dbo].[ConvertAmount]
	(@Amount numeric(18,3),  @FromCurrency smallint, @ToCurrency smallint, @ExchangeDate smalldatetime)
RETURNS  numeric(18,3)
AS
BEGIN
declare @DecimalScale as smallint
select @DecimalScale=DecimalScale from sysparam

declare @ExchangeFrom  as numeric(18,6), @ExchangeTo as numeric(18,6)

if @FromCurrency <> @ToCurrency
  begin
    select top 1 @ExchangeFrom=exrate from currencyrates where startdate<=@ExchangeDate and cur=@FromCurrency order by startdate desc
    if @ExchangeFrom is null select @ExchangeFrom=exrate from currency where  cur=@FromCurrency
    select top 1 @ExchangeTo=exrate from currencyrates where startdate<=@ExchangeDate and cur=@ToCurrency order by startdate desc
    if @ExchangeTo is null select @ExchangeTo=exrate from currency where  cur=@ToCurrency
    if @ExchangeFrom<>0 and @ExchangeTo<>0 set @Amount=round(@Amount*@ExchangeFrom/@ExchangeTo,@DecimalScale)
 end

return @Amount
END

GO

