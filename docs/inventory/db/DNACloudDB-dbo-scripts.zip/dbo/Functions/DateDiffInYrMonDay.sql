CREATE FUNCTION [dbo].[DateDiffInYrMonDay] (@datefrom DATETIME, @dateto DATETIME, @ValueType int)
RETURNS int
AS
BEGIN
    --@ValueType =1 reurn Years
	--@ValueType =2 reurn Months
	--@ValueType =3 reurn Days
   DECLARE @to datetime, @thisYearBirthDay datetime
DECLARE @years int, @months int, @days int 
SELECT @to = @dateto
SELECT @thisYearBirthDay = DATEADD(year, DATEDIFF(year, @datefrom, @to), @datefrom) 
SELECT @years = DATEDIFF(year, @datefrom, @to) - (CASE WHEN @thisYearBirthDay > @to THEN 1 ELSE 0 END) 
SELECT @months = MONTH(@to - @thisYearBirthDay) - 1 
SELECT @days = DAY(@to - @thisYearBirthDay) 

	DECLARE @Result int
    SELECT @Result=CASE @ValueType 
             when 1 THEN @years
             when 2 then @months
             else @days
           END

    RETURN @Result
END

GO

