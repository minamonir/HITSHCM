




CREATE      FUNCTION [dbo].[WFAccessEmployeeApplicant]
  (@RoleProfileid int, @Empid int ,  @Itemno as smallint,@includeapplicant int,@assignmentid AS int )
RETURNS  int
as
BEGIN
declare @accessemployee as int,@accessapplicant AS int,@count AS int
select @accessemployee = 0,@accessapplicant=0,@count=0
IF @includeapplicant=0 OR @includeapplicant=2
SELECT     @accessemployee = count(*)
FROM         SSRole INNER JOIN
         SSGroupRole ON SSRole.RoleId = SSGroupRole.RoleId INNER JOIN
         EmpAssignment ON SSGroupRole.SSGroup = EmpAssignment.SSGroup INNER JOIN
         UserGroupRights ON SSRole.UserGroup = UserGroupRights.UserGroup 
         --modification done to improve performance of SP_EmployeesGridGetList 2011/04/27
         --inner join NasUsers on NasUsers.Empid=@RoleProfileid 
WHERE    itemno = @itemno AND SSGroupRole.profileid = @RoleProfileid and empassignment.empid =@empid
  --and (empassignment.privacy between NasUsers.PrivacyLevelFrom and NasUsers.PrivacyLevelTo)

IF @includeapplicant=1 OR @includeapplicant=2
SELECT     @accessapplicant = count(*)
FROM         SSRole INNER JOIN
         SSGroupRole ON SSRole.RoleId = SSGroupRole.RoleId INNER JOIN
         AppAssignment ON SSGroupRole.SSGroup = AppAssignment.SSGroup  AND AppAssignment.AssignmentId =@assignmentid INNER JOIN
         UserGroupRights ON SSRole.UserGroup = UserGroupRights.UserGroup 
         --inner join NasUsers on NasUsers.Empid=@RoleProfileid 
WHERE    itemno = @itemno AND SSGroupRole.profileid = @RoleProfileid and Appassignment.empid =@empid
 -- and (Appassignment.privacy between NasUsers.PrivacyLevelFrom and NasUsers.PrivacyLevelTo
  AND AppAssignment.AssignmentId =@assignmentid
  --)


SET @count=@accessemployee+@accessapplicant
return isnull(@count,0)
END

GO

