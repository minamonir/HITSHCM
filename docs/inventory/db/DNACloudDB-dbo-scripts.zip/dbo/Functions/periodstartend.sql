CREATE FUNCTION [dbo].[periodstartend]
	(@PeriodStEnd INT , @MONTH int , @YEAR int )
RETURNS DATETIME
AS
BEGIN

  declare @thedate DATETIME

	--DECLARE @PeriodStEnd int=1


  SELECT @thedate =CONVERT(DATETIME, CONVERT(NVARCHAR( 12),@YEAR *10000 + @MONTH *100 + 01 ,101))

  IF @PeriodStEnd =0 SELECT @thedate = @thedate
  

 
 IF @PeriodStEnd =1 	select @thedate=dateadd(mm,1,@thedate) -1  

RETURN @thedate
END

GO

