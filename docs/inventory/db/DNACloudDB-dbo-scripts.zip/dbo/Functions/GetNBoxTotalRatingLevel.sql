--this Function is used now in report 2025 only 
CREATE FUNCTION [dbo].[GetNBoxTotalRatingLevel] ( @empid as int, @docno as smallint , @CodeNameOrder as smallint, @lang as Char)
RETURNS NVarChar(20)
AS
BEGIN
-- @CodeNameOrder =0 Code
-- @CodeNameOrder =1 Name
-- @CodeNameOrder =2 Order


	if @docno = 0
	begin
		SELECT  TOP 1 @docno = Documentno
		FROM dbo.EmpAppraisal empapp
		left join dbo.Appraisals app ON app.AppraisalNo = empapp.AppraisalNo 
		WHERE empapp.EmpId = @empid  AND app.NboxEnabled = 1 
		ORDER BY AppraisalDate DESC,empapp.DocumentNo DESC
	end

	Declare @TotalRate NVarChar(20)

	select @TotalRate= case when @CodeNameOrder=0 then ltrim(rtrim(RatingLevel)) WHEN @CodeNameOrder=1 THEN case when @lang='e' then LevelName else LevelAName end ELSE  ltrim(rtrim(LevelOrder)) end 
	from 
	(SELECT ROW_NUMBER() over(order by  PerformanceRating.RatingLevel  ASC, PotentialRating.RatingLevel ASC) as RowNumber,CASE WHEN EmpAppraisal.AutoNboxPotentialResult = PotentialRating.RatingLevel AND EmpAppraisal.AutoNboxPerformanceResult = PerformanceRating.RatingLevel THEN 1 ELSE 0 END as EmpResult, Appraisals.NboxTotalRating

	FROM  dbo.EmpAppraisal
	INNER JOIN dbo.Appraisals ON Appraisals.AppraisalNo  =  EmpAppraisal.AppraisalNo 
	CROSS JOIN dbo.RatingLevels PerformanceRating  
	CROSS JOIN dbo.RatingLevels PotentialRating  
		
	WHERE dbo.Appraisals.NboxEnabled = 1 AND  EmpId = @empid  AND EmpAppraisal.documentno = @docno  
	AND PotentialRating.RatingScale = Appraisals.NboxPotentialRating AND PerformanceRating.RatingScale = Appraisals.NboxPerformanceRating 
	) t	
	inner JOIN dbo.RatingLevels TotalRating ON    TotalRating.RatingScale = t.NboxTotalRating and t.EmpResult=1 and t.RowNumber=TotalRating.LevelOrder
	
	RETURN @TotalRate
END

GO

