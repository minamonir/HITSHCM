

CREATE        FUNCTION [dbo].[GetWFActionType2old20190822]
  (@RoleProfileid int, @DocumentNo int, @Empid int ,  @ssdocno as smallint )
RETURNS  int
as
BEGIN

DECLARE @returnValue AS SMALLINT,@FirstRequiredNotApprovedOrder AS SMALLINT,@LastApprovedOrder AS SMALLINT
,@HasApprovalStatus AS INT,@HasNoApprovalStatus AS INT,@EndDate AS SMALLDATETIME

DECLARE @WFDocApproval TABLE (empid INT,documentno INT,ApprovalStatus SMALLINT,EndDate SMALLDATETIME,RoleOrder SMALLINT,ApprovalRequired BIT
,approvalprofileid int)

SET @returnValue=-2


INSERT INTO @WFDocApproval
SELECT WFDocument.empid, WFDocument.documentno ,ApprovalStatus ,EndDate ,RoleOrder ,ApprovalRequired 
,approvalprofileid 
 FROM dbo.WFDocApproval 
inner JOIN dbo.WFDocument ON WFDocument.EmpID = WFDocApproval.EmpID
AND  WFDocument.DocumentNo = WFDocApproval.DocumentNo  AND WFDocument.SSDocNo = WFDocApproval.SSDocNo
WHERE WFDocApproval.empid=@empid AND WFDocApproval.DocumentNo=@DocumentNo AND WFDocApproval.SSDocNo=@ssdocno

SELECT   @HasApprovalStatus =MAX(CASE WHEN ApprovalStatus IS NOT NULL THEN 1 ELSE 0 end),
@HasNoApprovalStatus =MAX(CASE WHEN ApprovalStatus IS NULL THEN 1 ELSE 0 end),
@EndDate=MAX(EndDate)
--@EndDate=MAX(wfdocument.EndDate)
FROM @WFDocApproval
--inner JOIN dbo.WFDocument ON WFDocument.DocumentNo = WFDocApproval.DocumentNo 
--AND WFDocument.EmpID = WFDocApproval.EmpID AND WFDocument.SSDocNo = WFDocApproval.SSDocNo
WHERE 
--WFDocApproval.empid=@empid AND WFDocApproval.DocumentNo=@DocumentNo AND WFDocApproval.SSDocNo=@ssdocno
--AND 
approvalprofileid=@RoleProfileid

	
IF @HasNoApprovalStatus=1 AND @EndDate IS NULL   -- checking current or monitoring status
BEGIN

	SELECT TOP 1  @FirstRequiredNotApprovedOrder=RoleOrder 
	FROM @WFDocApproval 
	WHERE 
	--empid=@empid AND DocumentNo=@DocumentNo AND SSDocNo=@ssdocno
	--AND 
	ApprovalStatus IS NULL AND ApprovalRequired=1
	ORDER BY RoleOrder


	SELECT  @LastApprovedOrder=MAX(CASE WHEN ApprovalStatus IS NOT NULL THEN RoleOrder ELSE -1 END)
	FROM @WFDocApproval 
	--WHERE empid=@empid AND DocumentNo=@DocumentNo AND SSDocNo=@ssdocno

	--IF @RoleProfileid IN ( SELECT approvalprofileid	FROM dbo.WFDocApproval WHERE empid=@empid AND DocumentNo=@DocumentNo 
	--AND SSDocNo=@ssdocno AND ApprovalStatus IS NULL AND RoleOrder>=ISNULL(@LastApprovedOrder,-1)	
	--AND RoleOrder<=ISNULL(@FirstRequiredNotApprovedOrder,999))

	IF @RoleProfileid IN ( SELECT approvalprofileid	FROM @WFDocApproval WHERE 
	ApprovalStatus IS NULL AND RoleOrder>=ISNULL(@LastApprovedOrder,-1)	
	AND RoleOrder<=ISNULL(@FirstRequiredNotApprovedOrder,999))
	BEGIN

		SELECT @returnValue=1

	END
	ELSE
	BEGIN
	--IF @RoleProfileid IN ( SELECT approvalprofileid	FROM dbo.WFDocApproval WHERE empid=@empid AND DocumentNo=@DocumentNo
	-- AND SSDocNo=@ssdocno AND ApprovalStatus IS NULL AND RoleOrder>ISNULL(@LastApprovedOrder,-1))
	
	IF @RoleProfileid IN ( SELECT approvalprofileid	FROM @WFDocApproval WHERE ApprovalStatus IS NULL
	 AND RoleOrder>ISNULL(@LastApprovedOrder,-1))
		
		SELECT @returnValue=0

	END
END


IF @HasApprovalStatus=1 AND @returnValue NOT IN (0,1) --checking history status
BEGIN
	SELECT @returnValue=-1
END


RETURN @returnValue
END

GO

