

CREATE function [dbo].[GetFirstEmptyEmployeeId]
(
@EmployeeFrom nvarchar(50) , @EmployeeTo nvarchar(50)
)
RETURNS int
as
begin
set @EmployeeFrom = case when isnull(@EmployeeFrom, 0) = 0  then  1 else @EmployeeFrom end
declare @EmpResult as int=0 ;

with GetFirstEmpty(EmployeeId,nextEmployeeId)
as (
select cast (EmployeeId as int)EmployeeId, 
lead(cast (EmployeeId as int)) over (order by cast (EmployeeId as int)) as nextEmployeeId
from EmpAssignment where cast (EmployeeId as int) between @EmployeeFrom  and @EmployeeTo
)
select @EmpResult=[FirstValue] from(
select  top 1  case when  (select  top 1 EmployeeId from  GetFirstEmpty order by cast(EmployeeId as int)) =@EmployeeFrom   
then EmployeeId+1 else @EmployeeFrom end as FirstValue 
from GetFirstEmpty
where EmployeeId+1 != isnull(nextEmployeeId,0) and isnull(EmployeeId,0) between @EmployeeFrom  and @EmployeeTo
UNION all
SELECT @EmployeeFrom  as FirstValue  WHERE NOT EXISTS (SELECT * FROM GetFirstEmpty)
) as q1



if @EmpResult  > @EmployeeTo
    set  @EmpResult =0

return @EmpResult;

end

GO

