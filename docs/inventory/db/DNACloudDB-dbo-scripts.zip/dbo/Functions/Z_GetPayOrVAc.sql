
CREATE FUNCTION [dbo].[Z_GetPayOrVAc]
	(@Type INT ,@EmpId int,  @From SMALLDATETIME, @To SMALLDATETIME, @codeORCons as SMALLINT , @setup NVARCHAR(Max),@considerSign BIT =1 )
 RETURNS numeric(18,3)
AS
BEGIN

--@Type
---*1 To Return Paycode Amount
---*2 to Return Paycode InputAmount
---*3 to Return total days for Approved Vac
---*4 to return TotalSalary from payroll

/*@setup must be provided as #code##code#... */

--@codeORCons
---*0 to consider @setup as codes 
---*1 to consider @setup as Consolidation

DECLARE @query NVARCHAR(Max)

declare @returnvalue numeric(18,3)



IF @Type = 1
BEGIN

IF @codeORCons = 0
BEGIN 
--Monthly
SELECT @returnvalue =  isnull(SUM(CASE WHEN Paycode = 100 Or Type=1 or @considerSign = 0 THEN 1 ELSE -1 END * Amount) ,0) 
FROM dbo.MonthlyTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = MonthlyTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.Paycode ON Paycode.code = MonthlyTransaction.Paycode
WHERE 1=1
and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.code)+'#%'
AND TransactionInactive <> 1
AND CYear*100+CMonth BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)

--History
SELECT @returnvalue =  @returnvalue + isnull(SUM(CASE WHEN Paycode = 100 Or Type=1 or @considerSign = 0 THEN 1 ELSE -1 END * dbo.ConvertAmount(HistoryTransaction.Amount, HistoryPayroll.PayrollCurrency, PayrollGroup.Currency,
 dbo.periodend(HistoryPayroll.PayrollGroup, HistoryPayroll.Month, HistoryPayroll.Year)) ) ,0) 
 
 FROM dbo.HistoryTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = HistoryTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.HistoryPayroll ON HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.Month = HistoryTransaction.Month 
	AND HistoryPayroll.EmpId = HistoryTransaction.EmpId AND HistoryPayroll.RunNo = HistoryTransaction.RunNo
INNER JOIN dbo.Paycode ON Paycode.code = HistoryTransaction.Paycode
WHERE 1=1

and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.code)+'#%'
AND HistoryTransaction.Year*100+HistoryTransaction.Month BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)



END  -- CodeOrCons = 0 -- @Type = 1

ELSE -- CodeOrCons = 1 
BEGIN 


--Monthly
SELECT @returnvalue =  isnull(SUM(CASE WHEN Paycode = 100 Or Type=1 or @considerSign = 0 THEN 1 ELSE -1 END * Amount) ,0) 
FROM dbo.MonthlyTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = MonthlyTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.Paycode ON Paycode.code = MonthlyTransaction.Paycode
WHERE 1=1
and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.PaycodeCons)+'#%'
AND TransactionInactive <> 1
AND CYear*100+CMonth BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)

--History
SELECT @returnvalue =  @returnvalue + isnull(SUM(CASE WHEN Paycode = 100 Or Type=1 or @considerSign = 0 THEN 1 ELSE -1 END * dbo.ConvertAmount(HistoryTransaction.Amount, HistoryPayroll.PayrollCurrency, PayrollGroup.Currency,
 dbo.periodend(HistoryPayroll.PayrollGroup, HistoryPayroll.Month, HistoryPayroll.Year)) ) ,0) 
 
 FROM dbo.HistoryTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = HistoryTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.HistoryPayroll ON HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.Month = HistoryTransaction.Month 
	AND HistoryPayroll.EmpId = HistoryTransaction.EmpId AND HistoryPayroll.RunNo = HistoryTransaction.RunNo
INNER JOIN dbo.Paycode ON Paycode.code = HistoryTransaction.Paycode
WHERE 1=1

and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.PaycodeCons)+'#%'
AND HistoryTransaction.Year*100+HistoryTransaction.Month BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)


END  -- CodeOrCons = 1  -- @Type = 1


END -- @Type = 1


ELSE IF @Type = 2

BEGIN

IF @codeORCons = 0
BEGIN 
--Monthly
SELECT @returnvalue =  isnull(SUM(InputAmnt) ,0) 
FROM dbo.MonthlyTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = MonthlyTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.Paycode ON Paycode.code = MonthlyTransaction.Paycode
WHERE 1=1
and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.code)+'#%'
AND TransactionInactive <> 1
AND CYear*100+CMonth BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)

--History
SELECT @returnvalue =  @returnvalue + isnull(SUM(InputAmnt ),0) 
 
 FROM dbo.HistoryTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = HistoryTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.HistoryPayroll ON HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.Month = HistoryTransaction.Month 
	AND HistoryPayroll.EmpId = HistoryTransaction.EmpId AND HistoryPayroll.RunNo = HistoryTransaction.RunNo
INNER JOIN dbo.Paycode ON Paycode.code = HistoryTransaction.Paycode
WHERE 1=1

and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.code)+'#%'
AND HistoryTransaction.Year*100+HistoryTransaction.Month BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)



END  -- CodeOrCons = 0 -- @Type = 2

ELSE -- CodeOrCons = 1 
BEGIN 


--Monthly
SELECT @returnvalue =  isnull(SUM( InputAmnt) ,0) 
FROM dbo.MonthlyTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = MonthlyTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.Paycode ON Paycode.code = MonthlyTransaction.Paycode
WHERE 1=1
and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.PaycodeCons)+'#%'
AND TransactionInactive <> 1
AND CYear*100+CMonth BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)

--History
SELECT @returnvalue =  @returnvalue + isnull(SUM(InputAmnt ) ,0) 
 
 FROM dbo.HistoryTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = HistoryTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.HistoryPayroll ON HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.Month = HistoryTransaction.Month 
	AND HistoryPayroll.EmpId = HistoryTransaction.EmpId AND HistoryPayroll.RunNo = HistoryTransaction.RunNo
INNER JOIN dbo.Paycode ON Paycode.code = HistoryTransaction.Paycode
WHERE 1=1

and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.PaycodeCons)+'#%'
AND HistoryTransaction.Year*100+HistoryTransaction.Month BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)


END  -- CodeOrCons = 1  -- @Type = 2


END -- @Type = 2




ELSE IF @Type = 3

BEGIN 

IF @codeORCons = 0
BEGIN

SELECT @returnvalue = SUM( CASE WHEN temp.NEwFROM > temp.fromdate THEN CASE WHEN ( temp.NewTakenDays - DATEDIFF(DAY,fromdate , temp.NEwFROM)) <0 THEN 0 ELSE  temp.NewTakenDays - DATEDIFF(DAY,fromdate , temp.NEwFROM)
END ELSE NewTakenDays END  ) 
FROM 
(
SELECT V_EmpVacat.empid,V_EmpVacat.FromDate,V_EmpVacat.ToDate,
CASE WHEN V_EmpVacat.FromDate < @from THEN @from ELSE V_EmpVacat.fromdate END AS NEwFROM,
CASE WHEN V_EmpVacat.ToDate > @to THEN @to ELSE V_EmpVacat.ToDate END AS NewTo   ,
VacTakenDays,
CASE WHEN V_EmpVacat.ToDate > @to THEN VacTakenDays - DATEDIFF(DAY,@to,V_EmpVacat.ToDate) ELSE VacTakenDays END AS NewTakenDays
FROM dbo.V_EmpVacat 
INNER JOIN dbo.EmpVacat ON EmpVacat.EmpId = V_EmpVacat.EmpId AND EmpVacat.DocumentNo = V_EmpVacat.DocumentNo
INNER JOIN dbo.Vacation ON Vacation.vaccode = V_EmpVacat.VacCode
WHERE 1=1 
AND V_EmpVacat.VacStatus = 1
AND V_EmpVacat.empid =  @EmpId
AND @setup LIKE  '%#'+LTRIM(Vacation.VacCode)+'#%'

AND (

(V_EmpVacat.FromDate BETWEEN @from AND @to )OR(V_EmpVacat.ToDate BETWEEN  @from AND @to ) 
OR (@from>=dbo.V_EmpVacat.FromDate AND @to <= dbo.V_EmpVacat.ToDate)
) 

) 
AS temp 

END
ELSE 
BEGIN

SELECT @returnvalue = SUM( CASE WHEN temp.NEwFROM > temp.fromdate THEN CASE WHEN ( temp.NewTakenDays - DATEDIFF(DAY,fromdate , temp.NEwFROM)) <0 THEN 0 ELSE  temp.NewTakenDays - DATEDIFF(DAY,fromdate , temp.NEwFROM)
END ELSE NewTakenDays END  ) 
FROM 
(
SELECT V_EmpVacat.empid,V_EmpVacat.FromDate,V_EmpVacat.ToDate,
CASE WHEN V_EmpVacat.FromDate < @from THEN @from ELSE V_EmpVacat.fromdate END AS NEwFROM,
CASE WHEN V_EmpVacat.ToDate > @to THEN @to ELSE V_EmpVacat.ToDate END AS NewTo   ,
VacTakenDays,
CASE WHEN V_EmpVacat.ToDate > @to THEN VacTakenDays - DATEDIFF(DAY,@to,V_EmpVacat.ToDate) ELSE VacTakenDays END AS NewTakenDays
FROM dbo.V_EmpVacat 
INNER JOIN dbo.EmpVacat ON EmpVacat.EmpId = V_EmpVacat.EmpId AND EmpVacat.DocumentNo = V_EmpVacat.DocumentNo
INNER JOIN dbo.Vacation ON Vacation.vaccode = V_EmpVacat.VacCode
WHERE 1=1 
AND V_EmpVacat.VacStatus = 1
AND V_EmpVacat.empid =  @EmpId
AND @setup LIKE  '%#'+LTRIM(Vacation.VacCodeCons)+'#%'

AND (

(V_EmpVacat.FromDate BETWEEN @from AND @to )OR(V_EmpVacat.ToDate BETWEEN  @from AND @to )  
OR (@from>=dbo.V_EmpVacat.FromDate AND @to <= dbo.V_EmpVacat.ToDate)
)
) 
AS temp 


END

END





ELSE IF @Type = 4
BEGIN

 
--Monthly
SELECT @returnvalue =  isnull(SUM(CASE WHEN Paycode = 100 Or Type=1 or @considerSign = 0 THEN 1 ELSE -1 END * Amount) ,0) 
FROM dbo.MonthlyTransaction 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = MonthlyTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.Paycode ON Paycode.code = MonthlyTransaction.Paycode
WHERE 1=1
AND paycode.addtotsal=1
and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.code)+'#%'
AND TransactionInactive <> 1
AND CYear*100+CMonth BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)

--History
SELECT @returnvalue =  @returnvalue + isnull(SUM(CASE WHEN Paycode = 100 Or Type=1 or @considerSign = 0 THEN 1 ELSE -1 END * dbo.ConvertAmount(HistoryTransaction.Amount, HistoryPayroll.PayrollCurrency, PayrollGroup.Currency,
 dbo.periodend(HistoryPayroll.PayrollGroup, HistoryPayroll.Month, HistoryPayroll.Year)) ) ,0) 
 
 FROM dbo.HistoryTransaction 

INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = HistoryTransaction.EmpId
INNER JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
INNER JOIN dbo.HistoryPayroll ON HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.Month = HistoryTransaction.Month 
	AND HistoryPayroll.EmpId = HistoryTransaction.EmpId AND HistoryPayroll.RunNo = HistoryTransaction.RunNo
INNER JOIN dbo.Paycode ON Paycode.code = HistoryTransaction.Paycode
WHERE 1=1
AND paycode.addtotsal=1
and EmpAssignment.empid=@EmpId
AND @setup LIKE  '%#'+LTRIM(Paycode.code)+'#%'
AND HistoryTransaction.Year*100+HistoryTransaction.Month BETWEEN YEAR(@from)*100+MONTH(@From) AND YEAR(@To)*100+MONTH(@To)



END  -- CodeOrCons = 0,1 -- @Type = 4







RETURN ISNULL(@returnvalue,0) ;


END

GO

