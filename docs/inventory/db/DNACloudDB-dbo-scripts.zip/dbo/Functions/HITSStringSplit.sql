CREATE FUNCTION [dbo].[HITSStringSplit](@Str NVARCHAR(MAX), @Delimiter NCHAR(1))
RETURNS @TempTable TABLE([value] NVARCHAR(MAX))
AS
BEGIN
	IF EXISTS(SELECT * FROM sys.databases WHERE databases.name=DB_NAME() AND databases.compatibility_level>=130)-- SQL2016+
	BEGIN
		INSERT INTO @TempTable
		SELECT t.value FROM		STRING_SPLIT(@Str, @Delimiter) AS t WHERE  t.value <> ''
	END
	ELSE
	BEGIN
		DECLARE @xml AS XML
		SELECT	@xml = CAST(('<X>' + REPLACE(@Str, @Delimiter, '</X><X>') + '</X>') AS XML)
		INSERT INTO @TempTable
		SELECT	N.value('.', 'NVARCHAR(MAX)') AS value
		FROM	@xml.nodes('X') AS T(N)
		WHERE	N.value('.', 'NVARCHAR(MAX)') <> ''
	END
	RETURN
END

GO

