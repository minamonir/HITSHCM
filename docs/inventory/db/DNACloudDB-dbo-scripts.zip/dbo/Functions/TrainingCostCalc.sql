/*** Sum Cost Items Amount For an Employee OR for an Event ****/
CREATE  FUNCTION [dbo].[TrainingCostCalc](@event as bigint,@empId as int,@resource INT,@r_Category INT ,@from DATETIME,@to DATETIME,@currency as SMALLINT,@actual AS BIT,@confirmed BIT)   
RETURNS numeric (18,3) AS  
BEGIN
declare @EmpCostItemsAmount as numeric(18,3)
DECLARE @TrainingResourceCost AS numeric(18,3)
DECLARE @TotalAmount AS numeric(18,3)
DECLARE @EmpCount AS INT


IF @from IS NULL
SET @to=NULL
----------------------------------------------------


DECLARE @Temp TABLE (T_Event INT ,EmpCount INT )
DECLARE @TempTotal TABLE (Total NUMERIC(18,3))

/* Count Number of Employees Attended or Placed The Event */

INSERT INTO @Temp
SELECT  TrainingEvents.TrainingEvent, CASE WHEN (@empId IS NULL OR Exists
										(SELECT * FROM EmpTraining empt
												 LEFT JOIN TrainingEvents te ON te.TrainingEvent = empt.TrainingEvent
												 LEFT JOIN  TrainingEnrollStatus tes ON empt.EnrollStatus=tes.EnrollStatus
											   WHERE (@EmpId IS NULL or EmpId=@EmpId) AND tes.SystemEnrollStatus IN (2,4) 
												 AND te.TrainingEvent= TrainingEvents.TrainingEvent)) 
									  THEN count(Distinct EmpTraining.EmpId)
									  ELSE 0 end
FROM EmpTraining
	LEFT JOIN  TrainingEnrollStatus ON EmpTraining.EnrollStatus=TrainingEnrollStatus.EnrollStatus
	LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
	INNER JOIN TrainingResourcesBooking ON EmpTraining.TrainingEvent=TrainingResourcesBooking.TrainingEvent
		AND EmpTraining.TrainingEvent=isnull (@Event, EmpTraining.TrainingEvent)
		AND TrainingResourcesBooking.TrainingResource=ISNULL(@resource,TrainingResourcesBooking.TrainingResource)
		AND TrainingResourcesBooking.ResourceCategory  =ISNULL(@r_Category,TrainingResourcesBooking.ResourceCategory)
WHERE TrainingEnrollStatus.SystemEnrollStatus IN (2,4) /* Placed, Attended */
and (@from IS NULL OR ((@from BETWEEN TrainingEvents.EventFromDate AND TrainingEvents.EventToDate) 
	       OR (@to BETWEEN TrainingEvents.EventFromDate AND TrainingEvents.EventToDate) 
	       OR (TrainingEvents.EventFromDate BETWEEN @from AND @to)
	       OR (TrainingEvents.EventToDate BETWEEN @from AND @to)))
GROUP BY TrainingEvents.TrainingEvent

-------------------------------------------
INSERT INTO @TempTotal	--Totals Per Event

SELECT CASE WHEN EmpCount=0 AND @empId IS NOT NULL
	THEN 0 --No One attended even this Emp R-Cost=0
	ELSE	--Event Resources Cost	
		SUM( dbo.Resource_Utilization(TrainingResources.TrainingResource,TrainingResources.ResourceCategory,	
			  TrainingEvents.EventFromDate,TrainingEvents.EventToDate,TrainingEvents.TrainingEvent,
			  @Actual,1,@Currency,@Confirmed))/ CASE WHEN @empId IS NOT NULL 
													 THEN EmpCount   
													 ELSE 1 END --Divid Only When Get Cost Per Employee Attended
		  END 
	FROM TrainingResourcesBooking
	LEFT JOIN TrainingEvents on TrainingEvents.TrainingEvent=TrainingResourcesBooking.TrainingEvent
		LEFT JOIN TrainingResources ON TrainingResources.TrainingResource = TrainingResourcesBooking.TrainingResource 
		AND TrainingResources.ResourceCategory = TrainingResourcesBooking.ResourceCategory AND TrainingResourcesBooking.BookStatus = 1  AND TrainingResourcesBooking.BlockReason IS NULL
		AND TrainingResourcesBooking.TrainingResource=ISNULL(@resource, TrainingResourcesBooking.TrainingResource)
		AND TrainingResourcesBooking.ResourceCategory=ISNULL(@r_Category,TrainingResourcesBooking.ResourceCategory)
		INNER JOIN @Temp ON  TrainingEvents.TrainingEvent=T_Event
	WHERE (@from IS NULL OR ((@from BETWEEN TrainingEvents.EventFromDate AND TrainingEvents.EventToDate) 
	       OR (@to BETWEEN TrainingEvents.EventFromDate AND TrainingEvents.EventToDate) 
	       OR (TrainingEvents.EventFromDate BETWEEN @from AND @to)
	       OR (TrainingEvents.EventToDate BETWEEN @from AND @to)))
	GROUP BY EmpCount,T_Event

SELECT @TrainingResourceCost=SUM(Total)FROM @TempTotal

	Select @EmpCostItemsAmount=SUM(CASE WHEN TrainingCostItems.TrainingCostItemType =1 
	THEN 
		dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount,EmpTrainingCostItems.CostItemCurrency,@Currency,EmpTrainingCostItems.CostItemDate)   
	ELSE 
		-1*dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount,EmpTrainingCostItems.CostItemCurrency,@Currency,EmpTrainingCostItems.CostItemDate)  END  )

	From EmpTraining
	INNER JOIN EmpTrainingCostItems ON EmpTrainingCostItems.EmpId = EmpTraining.EmpId
		AND EmpTrainingCostItems.DocumentNo=EmpTraining.DocumentNo 
		AND EmpTraining.TrainingEvent=ISNULL(@Event,EmpTraining.TrainingEvent)
		AND EmpTraining.EmpId=ISNULL(@EmpId,EmpTraining.EmpId)
	LEFT JOIN TrainingCostItems ON  TrainingCostItems.TrainingCostItem=EmpTrainingCostItems.TrainingCostItem
	LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
		
	WHERE (@from IS NULL OR ((@from BETWEEN TrainingEvents.EventFromDate AND TrainingEvents.EventToDate) 
			OR (@to BETWEEN TrainingEvents.EventFromDate AND TrainingEvents.EventToDate) 
			OR (TrainingEvents.EventFromDate BETWEEN @from AND @to)
			OR (TrainingEvents.EventToDate BETWEEN @from AND @to)))


--Get Total Amount
SET @TotalAmount=ISNULL(@EmpCostItemsAmount,0)+@TrainingResourceCost

return ISNULL(@TotalAmount,0)
END

/* Assume Parameter "@Currency" is not Null */

GO

