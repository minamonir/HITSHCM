CREATE FUNCTION [dbo].[GetDocumentStatus](@Empid int ,@DocumentNo int,@ssdocno as smallint )

RETURNS  INT 
AS 
BEGIN
--Training Status=1 (Requested) ==>5(Submitted)
--Vacancy Status=3 (User Implementation) ==>5(Submitted)
--used in workflow alert 1190

DECLARE @SSDocType as SMALLINT,@SSDocStatus AS SMALLINT

select @SSDocType = SSDocType  from SSDocument where ssdocno = @ssdocno

IF  @SSDocType   = 1  -- Change Of Status 
	SELECT @SSDocStatus = DocumentStatus FROM EmpStatusHdr WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 2  -- Misconducts
	SELECT @SSDocStatus = misstatus FROM EmpMscon WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 3  -- Vacation 
	SELECT @SSDocStatus = VacStatus FROM EmpVacat WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 6  -- Appraisal 
	SELECT @SSDocStatus = AppraisalStatus FROM EmpAppraisal WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 7  -- Benefit 
	SELECT @SSDocStatus = BenefitStatus FROM EmpBenefit WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 8  -- Vacation Due Adjustment
	SELECT @SSDocStatus = VacDueStatus FROM EmpVacationDue WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 9  -- Training 
	SELECT @SSDocStatus = CASE WHEN SystemEnrollStatus=1 THEN 5 ELSE 0 END FROM EmpTraining 
	INNER JOIN TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus
	WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 10 -- Objectives
	SELECT @SSDocStatus = ObjectiveStatus FROM EmpObjectives WHERE ObjectiveId=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 11 -- Vacancies
	SELECT @SSDocStatus = CASE WHEN VacancyStatus=3 THEN 5 ELSE 0 END FROM Vacancies WHERE VacancyNo=@DocumentNo 

IF  @SSDocType   = 12 -- Time permission
	SELECT @SSDocStatus = DocumentStatus FROM EmpTimePermission WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 20 -- NasUsersUncommitted
	SELECT @SSDocStatus = DocumentStatus FROM NasUsersUncommitted WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 23 -- EmpTimeReadingsUncommitted
	SELECT @SSDocStatus = EmpTimeReadingsUncommitted.DocumentStatus FROM EmpTimeReadingsUncommitted WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

IF  @SSDocType   = 24 -- HR Request
	SELECT @SSDocStatus = HRReqStatus FROM EMpHRRequest WHERE DocumentNo=@DocumentNo AND EmpID = @Empid 

RETURN @SSDocStatus
END

GO

