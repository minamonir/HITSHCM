

CREATE FUNCTION [dbo].[PermissionTotalTakenWithStatus] (@EmpID AS INT,@DocNo AS INT, @PeriodStart AS DATETIME,@PeriodEnd AS DATETIME,@PermissionFrom AS DATETIME,@PermissionTo AS DATETIME,
@PolicyOverShortType AS INT,@permissionNo AS SMALLINT,@MaxTotalPermCodes AS NVARCHAR(MAX), @Status As nvarchar(MAX) ) 

RETURNS INT 
AS
BEGIN
	
-- This function will return the total value in seconds

-----------------------------------------------------------------------------------------------
----[dbo].[PermissionLength](EmpTimePermission.empid, EmpTimePermission.documentno,EmpTimePermission.PermissionNo , EmpTimePermission.FromDate ,EmpTimePermission.FromDate )
DECLARE @TotalValue AS INT 
SET @TotalValue=0

DECLARE @PermissionOverShortType AS INT
SET @PermissionOverShortType = (SELECT OverShort FROM TimePermission WHERE PermissionNo = @permissionNo)

SELECT @TotalValue = SUM(isnull([dbo].[PermissionLength](EmpTimePermission.empid, EmpTimePermission.documentno,EmpTimePermission.PermissionNo , (case when EmpTimePermission.PermissionFrom > @PeriodStart then EmpTimePermission.PermissionFrom else @PeriodStart end) ,(case when EmpTimePermission.PermissionTo < @PeriodEnd then EmpTimePermission.PermissionTo else @PeriodEnd end )),0))

FROM  EmpTimePermission 
INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
where EmpTimePermission.Empid=@Empid 
and ( @Status like '%' + ','+ltrim(rtrim(documentstatus ))+',' + '%')
AND TimePermission.OverShort = (CASE WHEN ltrim(rtrim(@MaxTotalPermCodes)) = '' THEN  @PolicyOverShortType ELSE TimePermission.OverShort END ) 
AND ((@PeriodStart BETWEEN PermissionFrom AND PermissionTo)
OR (@PeriodEnd BETWEEN PermissionFrom AND PermissionTo)
OR (PermissionFrom BETWEEN @PeriodStart AND @PeriodEnd)
OR (PermissionTo BETWEEN @PeriodStart AND @PeriodEnd))
AND EmpTimePermission.DocumentNo <>  @DocNo
AND  LTRIM(RTRIM(@MaxTotalPermCodes)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxTotalPermCodes)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(EmpTimePermission.PermissionNo)))+',%' END)


--SELECT @TotalValue

--Then :
-- add taken hours of the current requested TimePermission OverShort Type to total hours calculated above only in the following cases:
-- 1. if the [MaxTotalPermCodes] is empty -- > the permission over/short type must be = the policy over/short type
-- 2. if the [MaxTotalPermCodes] is not empty -- > the codes in [MaxTotalPermCodes] must contain the permission no

IF ((LTRIM(RTRIM(@MaxTotalPermCodes)) = '') AND(@PermissionOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxTotalPermCodes)) <> '') AND (LTRIM(RTRIM(@MaxTotalPermCodes)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
BEGIN
	
SET @TotalValue = isnull(@TotalValue,0) + ISNULL(DATEDIFF(s,(CASE WHEN @PermissionFrom < @PeriodStart THEN @PeriodStart ELSE @PermissionFrom END),(CASE WHEN @PermissionTo > @PeriodEnd THEN @PeriodEnd ELSE @PermissionTo END)),0)		
       	
END


RETURN @TotalValue   	

END

GO

