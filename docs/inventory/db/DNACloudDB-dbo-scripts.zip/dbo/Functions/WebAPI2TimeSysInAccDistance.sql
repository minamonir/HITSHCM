CREATE FUNCTION [dbo].[WebAPI2TimeSysInAccDistance] (@Lat FLOAT, @Long FLOAT,@SingleTimeSystem BIT)
RETURNS NVARCHAR(MAX) 
AS
BEGIN
	
DECLARE @point1Geo AS GEOGRAPHY, @TimeSystem AS NVARCHAR(MAX)

SELECT @point1Geo = GEOGRAPHY::STPointFromText('POINT (' + STR(@Long,10,6) + ' ' + STR(@Lat,10,6) + ')', 4326)

IF @SingleTimeSystem = 0
BEGIN
	SELECT @TimeSystem = COALESCE(@TimeSystem + ', ', '') + LTRIM(TimeSystem)
	FROM TimeSystems 
	WHERE Locationgeo IS NOT NULL 
	AND Locationgeo.STBuffer(geoAcceptedDistc).STIntersects(@point1Geo)=1
END
ELSE
BEGIN
		SELECT TOP 1 @TimeSystem = TimeSystem 
		FROM TimeSystems 
		WHERE Locationgeo IS NOT NULL 
		AND Locationgeo.STBuffer(geoAcceptedDistc).STIntersects(@point1Geo)=1
END

RETURN @TimeSystem 

END

GO

