

CREATE  FUNCTION [dbo].[EmpCompetenceRaterScore] (@empid as int,@DocumentNo as int ,@RaterProfileid as int)  
RETURNS numeric(18,3)  AS  
BEGIN
	
declare @Competence As   smallint ,@PerformaceLevel As   smallint ,@RatingLevel As   smallint
declare  @RatingScale as int , @RatingMethod as int , @LevelPercent as  numeric(18,3), @PLevelPercent as  numeric(18,3), @WieghtPercent as  numeric(18,3)
declare  @Score as  numeric(18,3),@Performancecount as int , @Proficiencycount as int ,@SWieght as  numeric(18,3) , @PScore as  numeric(18,3)


declare @Appraisalno as int

SELECT     @Appraisalno= Appraisals.Appraisalno , @RatingScale=Appraisals.RatingScale, @RatingMethod = Appraisals.RatingMethod  
FROM Appraisals inner join EmpAppraisal on Appraisals.AppraisalNo=EmpAppraisal.AppraisalNo
WHERE     (EmpAppraisal.EmpId = @EmpId) AND (EmpAppraisal.DocumentNo = @DocumentNo)


declare InsertRows cursor for 
select   EmpAppraisalComp.Competence ,EmpAppraisalComp.PerformaceLevel , EmpAppraisalComp.RatingLevel  
from EmpAppraisalComp 
left JOIN  dbo.AppraisalCompetencies  ON dbo.AppraisalCompetencies.Competence = dbo.EmpAppraisalComp.Competence
where EmpId = @EmpId and DocumentNo=@DocumentNo  and RaterProfileid =  case when @RaterProfileid = 0
then RaterProfileid else @RaterProfileid end  and (dbo.AppraisalCompetencies.AppraisalNo = @Appraisalno) 

--select   Competence ,PerformaceLevel , RatingLevel  
--from EmpAppraisalComp 
--where EmpId = @EmpId and DocumentNo=@DocumentNo  and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
--

/*SELECT @SWieght = sum(isnull(AppraisalCompetencies.Weight,1))  
FROM  AppraisalCompetencies where Appraisalno=@Appraisalno  */

if @RatingMethod = 1 or @RatingMethod =3

SELECT  @SWieght = sum(isnull(dbo.AppraisalCompetencies.Weight,1)) 
FROM  dbo.AppraisalCompetencies INNER JOIN
      dbo.EmpAppraisalComp ON dbo.AppraisalCompetencies.Competence = dbo.EmpAppraisalComp.Competence INNER JOIN
      dbo.LevelsCompetence ON dbo.EmpAppraisalComp.Competence = dbo.LevelsCompetence.Competence AND 
      dbo.EmpAppraisalComp.RatingLevel = dbo.LevelsCompetence.RatingLevel
WHERE     (dbo.AppraisalCompetencies.AppraisalNo = @Appraisalno) 
AND (dbo.EmpAppraisalComp.EmpId = @EmpId) AND (dbo.EmpAppraisalComp.DocumentNo = @DocumentNo) AND 
                      (dbo.LevelsCompetence.LevelPercent >=0)
                       and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end

if @RatingMethod = 2 or @RatingMethod =4 or @RatingMethod =5

SELECT  @SWieght = sum(isnull(dbo.AppraisalCompetencies.Weight,1)) 
FROM         dbo.AppraisalCompetencies INNER JOIN
                      dbo.EmpAppraisalComp ON dbo.AppraisalCompetencies.Competence = dbo.EmpAppraisalComp.Competence INNER JOIN
                      dbo.LevelsCompetence ON dbo.EmpAppraisalComp.Competence = dbo.LevelsCompetence.Competence AND 
                      dbo.EmpAppraisalComp.PerformaceLevel = dbo.LevelsCompetence.RatingLevel
WHERE     (dbo.AppraisalCompetencies.AppraisalNo = @Appraisalno) 
AND (dbo.EmpAppraisalComp.EmpId = @EmpId) AND (dbo.EmpAppraisalComp.DocumentNo = @DocumentNo) AND 
                      (dbo.LevelsCompetence.LevelPercent >=0)
 and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid END
 
if @SWieght = 0 set @SWieght = 1 

set @Score = 0

set @PScore = 0

--------------------------------------

DECLARE @calcCompBasedonCategory AS NVARCHAR(MAX)='0'
IF @RatingMethod =6
BEGIN 
SELECT @calcCompBasedonCategory =configvalue FROM SysParamConfig WHERE ConfigID ='calcCompBasedonCategory '
DECLARE  @CompetenceScores TABLE (Competence SMALLINT ,CompetenceCategory SMALLINT , score NUMERIC (18,3) DEFAULT 0)
DECLARE  @ComCategoryScores TABLE (CompetenceCategory SMALLINT , score NUMERIC (18,3) DEFAULT 0)
DECLARE @CompetenceCategory AS SMALLINT =0
END 
--------------------------------------

OPEN InsertRows
FETCH NEXT FROM InsertRows INTO  @Competence ,@PerformaceLevel ,@RatingLevel
WHILE @@FETCH_STATUS = 0
 BEGIN
	SELECT @LevelPercent = isnull(LevelPercent,0)   
	FROM LevelsCompetence where Competence=@Competence and RatingLevel = @RatingLevel
	
	SELECT @pLevelPercent = isnull(LevelPercent,0)   FROM RatingLevels where 
        RatingScale=@RatingScale and RatingLevel = @PerformaceLevel
	SELECT @WieghtPercent = isnull(AppraisalCompetencies.Weight,1)  FROM  AppraisalCompetencies where Appraisalno=@Appraisalno  and Competence=@Competence
 if @WieghtPercent = 0 set @WieghtPercent = 1

--changed 27-09-2007 to ignore level percent <0
--print @pLevelPercent
if  @RatingMethod = 1 or @RatingMethod = 6
BEGIN
	
	IF @RatingMethod=6 AND @calcCompBasedonCategory='1' 
	BEGIN
		
		SELECT @CompetenceCategory =competencecategory FROM competencies WHERE Competence=@Competence
		INSERT into  @CompetenceScores  (Competence,CompetenceCategory  , score)
		SELECT @Competence, @CompetenceCategory , case when @LevelPercent>0 then (@LevelPercent)else 0 end

	END
	ELSE
	BEGIN
		set @Score = @Score+ case when @LevelPercent>0 then (@LevelPercent)else 0 end
	END

END


if  @RatingMethod = 2 or @RatingMethod = 7
set @Score = @Score+ case when @pLevelPercent>0 then (@pLevelPercent)else 0 end

if  @RatingMethod = 3
set @Score = @Score+ case when @LevelPercent>0 then(@LevelPercent*@WieghtPercent)else 0 end

if  @RatingMethod = 4
set @Score = @Score+ case when @pLevelPercent>0 then(@pLevelPercent*@WieghtPercent)else 0 end

if  @RatingMethod = 5
set @Score = @Score+ case when @LevelPercent>0 then (@LevelPercent*@WieghtPercent)else 0 end
set @PScore = @PScore+ case when @pLevelPercent>0 then (@pLevelPercent*@WieghtPercent)else 0 end


/*
if  @RatingMethod = 1
set @Score = @Score+ (@LevelPercent)

if  @RatingMethod = 2
set @Score = @Score+ (@pLevelPercent)

if  @RatingMethod = 3
set @Score = @Score+ (@LevelPercent*(@WieghtPercent/ @SWieght))

if  @RatingMethod = 4
set @Score = @Score+ (@pLevelPercent*(@WieghtPercent/ @SWieght))

if  @RatingMethod = 5
set @Score = @Score+ (@LevelPercent*(@WieghtPercent/ @SWieght))
set @PScore = @PScore+ (@pLevelPercent*(@WieghtPercent/ @SWieght))
*/
--print @score
FETCH NEXT FROM InsertRows INTO  @Competence ,@PerformaceLevel ,@RatingLevel
 End
CLOSE InsertRows
DEALLOCATE InsertRows
--print @count

if @RatingMethod IN (3,4,5)
set @Score = @Score/ @SWieght
set @PScore = @PScore/ @SWieght

if @RatingMethod =6
BEGIN
	IF @RatingMethod=6 AND @calcCompBasedonCategory='1' 
		BEGIN
			INSERT INTO @ComCategoryScores 
			SELECT CompetenceCategory,AVG(score) 
			FROM @CompetenceScores
			GROUP BY CompetenceCategory
		
			SELECT @Score =AVG(score ) FROM @ComCategoryScores
		END

	ELSE 
		BEGIN 
			select  @Proficiencycount= count(*)
			from EmpAppraisalComp 
			left join levelscompetence on levelscompetence.competence=EmpAppraisalComp.competence and levelscompetence.RatingLevel = EmpAppraisalComp.RatingLevel
			where EmpId = @EmpId and DocumentNo=@DocumentNo
			 and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
			and levelscompetence.levelpercent>=0 

			if @Proficiencycount >=1
			set @Score =  @Score / @Proficiencycount
    END 
END 


if  @RatingMethod=7
BEGIN

select  @Performancecount= count(*)
from EmpAppraisalComp 
left join RatingLevels on RatingLevels.RatingScale=@RatingScale and RatingLevels.RatingLevel = EmpAppraisalComp.PerformaceLevel
where EmpId = @EmpId and DocumentNo=@DocumentNo
 and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
and  RatingLevels.levelpercent>=0

if @Performancecount >=1
set @Score =  @Score / @Performancecount
end


if  @RatingMethod = 5  
begin
/*if @count >=1 set @PScore =  @PScore / @count
else set @PScore =  @PScore / 1*/
 set @Score =  (@Score+@PScore) / 2

end

set @Score =  round(@Score ,2,1) 
return  isnull(@Score,0)
end

GO

