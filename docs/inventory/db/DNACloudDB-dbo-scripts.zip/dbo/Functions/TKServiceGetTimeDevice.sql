
CREATE  FUNCTION [dbo].[TKServiceGetTimeDevice]()
RETURNS  SMALLINT 
as
BEGIN 
	
  declare @TimeDevice as INT =0
  select top 1 @TimeDevice=TimeDevice FROM TimeSystemDevices order by TimeDevice desc
  SELECT @TimeDevice=@TimeDevice +1

  return @TimeDevice
END

GO

