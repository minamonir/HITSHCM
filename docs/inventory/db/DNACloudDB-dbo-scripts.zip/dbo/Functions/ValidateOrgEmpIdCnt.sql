CREATE FUNCTION [dbo].[ValidateOrgEmpIdCnt]
(
   @Start_ID nvarchar(50),
   @EmpIdFrom nvarchar(50),
   @EmpIdTo nvarchar(50),
   @lang AS nchar(1),
   @LogonName nchar(80),
   @type int
)
-- type=1 for @Start_ID and type=2 for valid @EmpIdFrom,@EmpIdTo
RETURNS nvarchar(max) -- or whatever length you need
AS
BEGIN
    Declare @retMSG nvarchar(max)
	declare @actualStartindex nvarchar(50)
	select @actualStartindex =dbo.[DecrementString](@EmpIdFrom)
	if (@type=1)
	begin

  IF(dbo.CompareTwoStrings(@Start_ID,@EmpIdTo) = 1)
	BEGIN
	set @retMSG=isnull(dbo.Hits_GetDCCaptionWzLogon('OrganizationSysParam','grtStartId',@lang,@LogonName),(case when @lang='A' then N'الرقم المبدئى أكبر من رقم موظف الي' ELSE N'Start Id Is greater than Emp.ID To'  end))  
	end
	ELSE IF(dbo.CompareTwoStrings(@actualStartindex,@Start_ID) = 1)
			BEGIN
				 set @retMSG=isnull(dbo.Hits_GetDCCaptionWzLogon('OrganizationSysParam','grtEmpIdFrom',@lang,@LogonName),(case when @lang='A' then N'رقم موظف من أكبر من الرقم المبدئى' ELSE N'Emp.ID From Is greater than Start Id'  end))  			 
			END
 end
	
	
	ELSE 
	begin
	IF(dbo.CompareTwoStrings(@EmpIdFrom,@EmpIdTo) = 1)
			BEGIN
				 set @retMSG=isnull(dbo.Hits_GetDCCaptionWzLogon('OrganizationSysParam','grtEmpIdTo',@lang,@LogonName),(case when @lang='A' then N'رقم موظف من أكبر من  رقم موظف الي' ELSE N'Emp.ID From Is greater than Emp.ID To'  end))  			 
			END
			
 
 end
    RETURN  @retMSG

END

GO

