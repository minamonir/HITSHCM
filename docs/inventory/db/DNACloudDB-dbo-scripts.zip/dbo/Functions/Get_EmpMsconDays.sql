CREATE FUNCTION [dbo].[Get_EmpMsconDays]
( @Empid AS INT,@Fromdate AS SMALLDATETIME,@Todate AS SMALLDATETIME,@UseMisconModification AS SMALLINT)
RETURNS NUMERIC(18,3)
AS

BEGIN
  DECLARE @MisconductDays AS NUMERIC(18,3) 
    
	IF @UseMisconModification=1---------- get the misconduct days take in consideration the misconduct modification. 
		BEGIN
	SELECT @MisconductDays = SUM(CASE WHEN EmpMsconModifications.fineamnt IS NULL THEN EmpMscon.fineamnt ELSE 
								CASE WHEN EmpMsconModifications.MisModType=3 AND EmpMsconModifications.misaction =2 AND EmpMsconModifications.finetype  != 1 then EmpMsconModifications.fineamnt ELSE 0 end	END) FROM EmpAssignment 
		LEFT Join Profile On EmpAssignment.EmpId=Profile.ProfileId
		LEFT Join EmpMscon On EmpMscon.EmpId = EmpAssignment.EmpId
		LEFT JOIN dbo.EmpMsconModifications ON EmpMsconModifications.EmpId = EmpMscon.EmpId AND EmpMsconModifications.DocumentNo = EmpMscon.DocumentNo AND EmpMsconModifications.MisModStatus=1 --AND EmpMsconModifications.misaction =2 AND EmpMsconModifications.finetype  != 1
		Where EmpAssignment.EmpId= @Empid AND
		misstatus =1 AND (EmpMscon.misaction =2 OR EmpMsconModifications.misaction =2) AND (EmpMscon.finetype  != 1 OR EmpMsconModifications.finetype != 1) AND misdate BETWEEN @Fromdate AND @Todate
		
	END
    ELSE
	BEGIN
		select @MisconductDays = SUM(fineamnt) FROM EmpAssignment 
		LEFT Join Profile On EmpAssignment.EmpId=Profile.ProfileId
		LEFT Join EmpMscon On EmpMscon.EmpId = EmpAssignment.EmpId
		Where EmpAssignment.EmpId= @Empid AND
		misstatus =1 AND misaction =2 AND finetype  != 1 AND misdate BETWEEN @Fromdate AND @Todate
	END
    
 return @MisconductDays
 END

GO

