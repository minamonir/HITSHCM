CREATE FUNCTION [dbo].[GetNewValue]
	(@ProfileId int, @DocumentNo int, @TableName nchar(30), @FieldName nchar(30),
	 @ChangedDate datetime)
	
RETURNS nchar(100)
AS
	BEGIN
            declare @returnval nchar(100)
		/* sql statement ... */
           select top 1 @returnval=OldValue from ChangesLog where @ProfileId=ProfileId and 
	  @DocumentNo=DocumentNo and upper(@TableName)=upper(TableName) and upper(@FieldName)=upper(FieldName) and
	  ChangedDate>@ChangedDate  order by ChangedDate 
           set @returnval=isnull(@returnval, 'Current Value' )
	RETURN @returnval
	END

GO

