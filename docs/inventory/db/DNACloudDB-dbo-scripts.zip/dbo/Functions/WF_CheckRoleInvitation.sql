CREATE FUNCTION [dbo].[WF_CheckRoleInvitation] (@LogonName as nvarchar(80)='' ,@RoleProfileid as int, @EmpID as int, @DocumentNo as int , @SSDocNo as SMALLINT, @action as INT)
RETURNS SMALLINT
AS
BEGIN

	DECLARE @result AS SMALLINT=0

	-- @result = 0		==> Invitation Closed & Can save
	-- @result = 1		==> Invitation Opened & Cannot save
	-- @result = 2		==> Invitation Opened & Can save

	DECLARE @rowNo INT,@WFRoleId as INT, @WFApprovalRequired as bit, @WFApprovalstatus as INT, @WFRoleOrder as int, @SSProfileId as INT, @WFDelegated as INT
    
    DECLARE @LastApprovedRoleOrder AS int
	SELECT TOP 1 @LastApprovedRoleOrder=roleorder
	FROM dbo.WFDocApproval WHERE empid=@Empid  AND SSDocNo=@SSDocNo AND DocumentNo=@DocumentNo AND ApprovalStatus IS NOT null
	ORDER BY roleorder  DESC
	SELECT @LastApprovedRoleOrder = ISNULL(@LastApprovedRoleOrder,0)
	
	DECLARE @WFDocApprovalTemp TABLE (WFRoleOrder INT, DocumentNo  int,Empid int, SSDocNo smallint ,RoleId smallint ,RoleOrder smallint, InvitedRoleid smallint, RoleName  nvarchar(60),RoleAName  nvarchar(60),RoleInvitedName  nvarchar(60),RoleInvitedAName  nvarchar(60), RowNo INT IDENTITY(1,1), InvitationRequired  SMALLINT, InvitedProfileId  int , InvitedProfileName NVARCHAR(88),InvitedProfileAName NVARCHAR(88), BtnAddNewPerson bit , WFDocInvitationID NVARCHAR(MAX), canInsert BIT)
	
	IF @action = 1
	BEGIN


	DECLARE @WFDocApproval TABLE(RowNo INT,RoleId SMALLINT,ApprovalRequired SMALLINT,RoleOrder SMALLINT,ApprovalStatus SMALLINT,ApprovalProfileId INT,Delegated SMALLINT)

	INSERT into @WFDocApproval
	select ROW_NUMBER() OVER(ORDER BY WFDocApproval.RoleOrder,WFDocApproval.Delegated) AS RowNO,WFDocApproval.RoleId,
	 WFDocApproval.ApprovalRequired, WFDocApproval.RoleOrder,
	WFDocApproval.ApprovalStatus, WFDocApproval.ApprovalProfileId, WFDocApproval.Delegated
	 FROM   WFDocApproval
	INNER JOIN WFDocument ON WFDocApproval.DocumentNo = WFDocument.DocumentNo AND WFDocApproval.EmpID = WFDocument.EmpID AND WFDocApproval.SSDocNo = WFDocument.SSDocNo
	WHERE WFDocApproval.ApprovalStatus IS NULL 
	AND  (WFDocApproval.DocumentNo =@DocumentNo) 
	AND  WFDocApproval.EmpID = @EmpId 
	AND WFDocApproval.RoleOrder>=@LastApprovedRoleOrder
	and WFDocApproval.SSDocNo=@SSDocNo 
	AND (Delegated<>1 OR ( Delegated=1 AND cast( GETDATE() AS date)  between WFDocApproval.Delegatefrom and WFDocApproval.Delegateto))
	ORDER BY WFDocApproval.RoleOrder 


	    DECLARE docapprovals1 cursor for 
		SELECT * FROM @WFDocApproval ORDER BY roleorder
		--select ROW_NUMBER() OVER(ORDER BY WFDocApproval.RoleOrder,WFDocApproval.Delegated),WFDocApproval.RoleId, WFDocApproval.ApprovalRequired, WFDocApproval.RoleOrder,
		--WFDocApproval.ApprovalStatus, WFDocApproval.ApprovalProfileId, WFDocApproval.Delegated
		--FROM   WFDocApproval
		--INNER JOIN WFDocument ON WFDocApproval.DocumentNo = WFDocument.DocumentNo AND WFDocApproval.EmpID = WFDocument.EmpID AND WFDocApproval.SSDocNo = WFDocument.SSDocNo
		--WHERE WFDocApproval.ApprovalStatus IS NULL 
		--AND  (WFDocApproval.DocumentNo =@DocumentNo) 
		--AND  WFDocApproval.EmpID = @EmpId 
		--AND WFDocApproval.RoleOrder>=@LastApprovedRoleOrder
		--and WFDocApproval.SSDocNo=@SSDocNo 
		--AND (Delegated<>1 OR ( Delegated=1 AND cast( GETDATE() AS date)  between WFDocApproval.Delegatefrom and WFDocApproval.Delegateto))
		--ORDER BY WFDocApproval.RoleOrder 

		OPEN docapprovals1
		FETCH NEXT FROM docapprovals1 INTO @rowNo, @WFRoleId, @WFApprovalRequired, @WFRoleOrder, @WFApprovalstatus, @SSProfileId, @WFDelegated

		WHILE @@FETCH_STATUS = 0
		BEGIN	
			
	IF EXISTS(SELECT * FROM @WFDocApproval WHERE RoleId = @WFRoleId AND ApprovalProfileId = @SSProfileId AND RoleOrder = @WFRoleOrder)
			BEGIN
				--if  @SSProfileId <> @RoleProfileid and @WFApprovalRequired = 1 
				--AND @RoleProfileid NOT IN (SELECT approvalprofileid FROM dbo.WFDocApproval WHERE  WFDocApproval.ApprovalStatus IS NULL 
				--AND WFDocApproval.DocumentNo =@DocumentNo AND  WFDocApproval.EmpID = @EmpId AND SSDocNo=@SSDocNo
				--AND dbo.WFDocApproval.RoleOrder=@WFRoleOrder)
 	            IF  @SSProfileId <> @RoleProfileid and @WFApprovalRequired = 1 
				AND @RoleProfileid NOT IN (SELECT approvalprofileid FROM @WFDocApproval WHERE  ApprovalStatus IS NULL 
				AND RoleOrder=@WFRoleOrder)
				OR
		       (@SSProfileId = @RoleProfileid  AND  EXISTS(SELECT approvalprofileid FROM @WFDocApproval WHERE 
		       ApprovalStatus IS NULL AND RoleOrder<@WFRoleOrder AND ApprovalRequired=1))

					BREAK 

				IF @SSProfileId = @RoleProfileid
				BEGIN
				
				UPDATE @WFDocApproval SET ApprovalStatus=1 WHERE ApprovalProfileId=@RoleProfileid AND RoleId=@WFRoleId
				AND ApprovalStatus IS NULL AND RoleOrder=@WFRoleOrder

				DELETE @WFDocApproval WHERE  Roleid = @WFRoleId 
				AND ApprovalProfileId <> @RoleProfileid AND RoleOrder=@WFRoleOrder AND ApprovalStatus IS NULL


			IF @WFDelegated NOT IN (2,3)
			BEGIN
					insert into  @WFDocApprovalTemp (WFRoleOrder ,DocumentNo ,Empid , SSDocNo  ,RoleId  ,RoleOrder,InvitedRoleid,RoleName ,RoleAName ,RoleInvitedName ,RoleInvitedAName, InvitationRequired, 
					InvitedProfileId, InvitedProfileName,InvitedProfileAName,BtnAddNewPerson,WFDocInvitationID, canInsert)
				
					SELECT DISTINCT @rowNo, ISNULL(WFDocInvitation.DocumentNo,@DocumentNo) AS DocumentNo ,ISNULL(WFDocInvitation.Empid,@EmpID) AS Empid ,SSDocumentInvitation.SSDocNo, @WFRoleId,
					@WFRoleOrder, SSDocumentInvitation.InvitedRoleid, SSrole.RoleName, SSrole.RoleAName, SSInvitedRole.RoleName, SSInvitedRole.RoleAName,SSDocumentInvitation.InvitationRequired,
					ISNULL(WFDocInvitation.InvitedRoleProfileid,0), profile.Name, Profile.AName, 1, ISNULL(CONVERT(NVARCHAR(max), WFDocInvitation.WFDocInvitationID ),'') AS WFDocInvitationID
					,CASE WHEN ISNULL(WFDocInvitation.InvitedRoleProfileid,0) = 0 AND SSDocumentInvitation.InvitationRequired = 2 THEN 0 ELSE 1 END
					FROM SSDocumentInvitation
					LEFT JOIN WFDocInvitation ON SSDocumentInvitation.SSDocNo = WFDocInvitation.SSDocNo AND SSDocumentInvitation.RoleId = WFDocInvitation.RoleId 
					AND SSDocumentInvitation.InvitedRoleid = WFDocInvitation.InvitedRoleid
					AND WFDocInvitation.DocumentNo = @documentno AND WFDocInvitation.EmpID = @Empid AND WFDocInvitation.SSDocNo = @ssdocno
					AND WFDocInvitation.RoleProfileId=@RoleProfileid------------
					left join SSrole on SSrole.RoleId = @WFRoleId
					LEFT join SSrole SSInvitedRole on SSInvitedRole.RoleId = SSDocumentInvitation.InvitedRoleid
					LEFT JOIN dbo.Profile ON Profile.ProfileId = WFDocInvitation.InvitedRoleProfileid
					WHERE SSDocumentInvitation.SSDocNo = @ssdocno AND SSDocumentInvitation.RoleId = @WFRoleId
					AND SSDocumentInvitation.InvitationRequired<>0 

				END
				END
			END
			FETCH NEXT FROM docapprovals1 INTO  @rowNo, @WFRoleId, @WFApprovalRequired, @WFRoleOrder, @WFApprovalstatus, @SSProfileId, @WFDelegated
		END
		CLOSE docapprovals1
		DEALLOCATE docapprovals1

		
	END
	ELSE
	BEGIN
	    insert into  @WFDocApprovalTemp (WFRoleOrder ,DocumentNo ,Empid , SSDocNo  ,RoleId  ,RoleOrder,InvitedRoleid,RoleName ,RoleAName ,RoleInvitedName ,RoleInvitedAName, InvitationRequired, 
					InvitedProfileId, InvitedProfileName,InvitedProfileAName,BtnAddNewPerson,WFDocInvitationID, canInsert)
				
		SELECT DISTINCT WFDocApproval.roleorder, ISNULL(WFDocInvitation.DocumentNo,@DocumentNo) AS DocumentNo ,ISNULL(WFDocInvitation.Empid,@EmpID) AS Empid ,SSDocumentInvitation.SSDocNo, SSDocumentInvitation.RoleId,
		WFDocApproval.roleorder, SSDocumentInvitation.InvitedRoleid, SSrole.RoleName, SSrole.RoleAName, SSInvitedRole.RoleName, SSInvitedRole.RoleAName,SSDocumentInvitation.InvitationRequired,
		ISNULL(WFDocInvitation.InvitedRoleProfileid,0), profile.Name, Profile.AName, 1, ISNULL(CONVERT(NVARCHAR(max), WFDocInvitation.WFDocInvitationID ),'') AS WFDocInvitationID,1
	FROM SSDocumentInvitation
INNER JOIN dbo.WFDocApproval ON  WFDocApproval.DocumentNo = @DocumentNo AND WFDocApproval.EmpID = @EmpID
AND WFDocApproval.SSDocNo = @SSDocNo AND ApprovalProfileId=@RoleProfileid 
AND WFDocApproval.RoleId = SSDocumentInvitation.RoleId AND WFDocApproval.SSDocNo = SSDocumentInvitation.SSDocNo  AND ApprovalStatus IS NOT null
LEFT JOIN dbo.WFDocInvitation ON WFDocInvitation.DocumentNo = WFDocApproval.DocumentNo AND WFDocInvitation.EmpID = WFDocApproval.EmpID 
AND WFDocInvitation.SSDocNo = SSDocumentInvitation.SSDocNo
AND WFDocInvitation.RoleId = WFDocApproval.RoleId 
left join SSrole on SSrole.RoleId = SSDocumentInvitation.RoleId
LEFT join SSrole SSInvitedRole on SSInvitedRole.RoleId = SSDocumentInvitation.InvitedRoleid
LEFT JOIN dbo.Profile ON Profile.ProfileId = WFDocInvitation.InvitedRoleProfileid
WHERE  SSDocumentInvitation.RequestedBy<>0 AND SSDocumentInvitation.SSDocNo=@SSDocNo
and Delegated  IN (0,1)
		--FROM SSDocumentInvitation
		--LEFT JOIN WFDocInvitation ON SSDocumentInvitation.SSDocNo = WFDocInvitation.SSDocNo 
		--AND ISNULL(SSDocumentInvitation.RoleId,0) = WFDocInvitation.RoleId AND SSDocumentInvitation.InvitedRoleid = WFDocInvitation.InvitedRoleid
		--AND WFDocInvitation.DocumentNo = @documentno AND WFDocInvitation.EmpID = @Empid
		--AND WFDocInvitation.SSDocNo = @ssdocno AND WFDocInvitation.RoleProfileId = @RoleProfileid
		--left join SSrole on SSrole.RoleId = SSDocumentInvitation.RoleId
		--LEFT join SSrole SSInvitedRole on SSInvitedRole.RoleId = SSDocumentInvitation.InvitedRoleid
		--LEFT JOIN dbo.Profile ON Profile.ProfileId = WFDocInvitation.InvitedRoleProfileid
		--LEFT JOIN dbo.EmpAssignment ON EmpAssignment.EmpId=@Empid
		--WHERE SSDocumentInvitation.SSDocNo = @ssdocno AND SSDocumentInvitation.RequestedBy =1
		--AND( WFDocInvitation.RoleProfileId = @RoleProfileid OR @RoleProfileid IN (SELECT SSGroupRole.ProfileId FROM SSGroupRole WHERE SSGroupRole.RoleId = SSDocumentInvitation.RoleId 
		--AND SSGroup=EmpAssignment.SSGroup ) )
	END

	IF NOT EXISTS(select * from @WFDocApprovalTemp)
	BEGIN
		SELECT @result = 0
	END
	ELSE IF EXISTS(select * from @WFDocApprovalTemp WHERE canInsert=0)
	BEGIN
		SELECT @result = 1
	END
	ELSE
	BEGIN
		SELECT @result = 2
	END

	RETURN @result 	
    
END

GO

