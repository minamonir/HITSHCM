

create FUNCTION [dbo].[hits_PermissionRestrictionOld]
(
	 @empid as int, @permissionno as smallint, @fromdate as datetime,@todate as datetime,@lang as nchar(1), @DocNo AS int
)
RETURNS nvarchar(MAX)
AS
BEGIN
	
--@MaxTotalSince=1      hiredate 
--@MaxTotalSince=2      probdate 
--@MaxTotalSince=3      calendar year start
--@MaxTotalSince=4      ContStart
--@MaxTotalSince=5      RevisedHireDate
--@MaxTotalSince=6      WorkReceivingDate
--@MaxTotalSince=7      PayrollGroup Year Start

declare @Latinlang as nchar(1)
set @Latinlang=@lang 
declare @reason as nvarchar(MAX)
set @reason =''

declare @PermPolicyExist as SMALLINT, @PolicyOverShortType as smallint,  @PolicyAction as smallint, @PermissionPeriod AS bit, @MinHours as numeric(9, 3), 
@MaxHours as numeric(9, 3), @MaxTotal as bit, @MaxTotalNo as numeric(9, 3), @MaxTotalEvery as numeric(9, 3), @MaxTotalEveryUnit as smallint, @MaxTotalPermCodes AS NVARCHAR(MAX),
@MaxTotalSince as smallint, @MaxOccurance as bit, @MaxOccuranceNo as smallint, @MaxOccuranceEvery as numeric(9, 3),
@MaxOccEveryUnit as smallint, @MaxOccuranceSince as SMALLINT,@MaxOccurancePermCodes AS NVARCHAR(MAX), @HiringProratedHours as numeric(9, 3),@HireDate AS SMALLDATETIME
,@ProratedMaxTotalNo AS numeric(9, 3),@proratedMaxOccuranceNo AS SMALLINT

-- Parameter to know prevent or warning -- initial value : warning
-- 1 : prevent , 2 : warning
DECLARE @PreventWarning AS SMALLINT
SET @PreventWarning = 2

	declare @enablehijri as bit,@payrollgroup as smallint,@year as smallint,@h_Yearfrom as nchar(4),@h_Yearto as nchar(4)
    ,@h_MonthFrom as nchar(4),@h_MonthTo as nchar(4), @PermRqstOverShortType as smallint,@date1 as datetime,@date2 as DATETIME
    ,@totalhours as numeric(9, 3),@DecimalScale AS SMALLINT
    
	select @PermRqstOverShortType=OverShort ,@enablehijri=enablehijri from TimePermission cross join sysparam where PermissionNo=@permissionno
	
	select @payrollgroup=EmpAssignment.PayrollGroup,@Year=Cyear, @HireDate=EmpAssignment.HireDate
	from EmpAssignment inner join PayrollGroup on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup where EmpId=@empid

	-- getting the decimal scale
SELECT @DecimalScale = DecimalScale FROM SysParam
-- param. for the min-max hours (requested permission value)
declare @PermRqstOverShortValue as numeric(9, 3),@UsefulPart AS NUMERIC(9,3)

-- Employee TimeRule (Fixed Hours or not ? )
---------------------------------------------
DECLARE @FixedHours AS BIT
SELECT @FixedHours = (SELECT tr.FixedHours
                      FROM EmpAssignment ea INNER JOIN TimeRules tr ON tr.TimeRule = ea.TimeRule
                      WHERE ea.EmpId = @EmpId)
---------------------------------------------------------------------------------------------------------------------
------------------------- To know if there is any policy for this perm. or not---------------------------------------
--get the count of the policies on the requested permission ..
---- if this count = 0 --> return by '001' (accepted permission)
---- if this count <> 0 --> go through a cursor to loop on the perm. policies..
DECLARE @PermPolicyCount AS INT
SELECT @PermPolicyCount = COUNT(*)
FROM [TimePermissionPolicy]
INNER JOIN EmpAssignment ON EmpAssignment.TimeRule=TimePermissionPolicy.TimeRule
WHERE PermissionNo=@PermissionNo AND empid=@empid
 
IF (@PermPolicyCount = 0)
BEGIN
	-- policies count = 0
	SET @reason = ''
END
ELSE
BEGIN
	-- policies count <> 0
------------------------- looping on the different OverShort policy records for this PermissionNo -------------------

declare OverShortCursor CURSOR for 
SELECT TimePermissionPolicy.[OverShort],[PolicyAction],[PermissionPeriod],[MinHours],[MaxHours] ,[MaxTotal],[MaxTotalNo],[MaxTotalEvery]
      ,[MaxTotalEveryUnit] ,[MaxTotalSince],[MaxTotalPermCodes],[MaxOccurance],[MaxOccuranceNo],[MaxOccuranceEvery],[MaxOccEveryUnit],[MaxOccuranceSince],[MaxOccurancePermCodes]
  FROM [TimePermissionPolicy]
  INNER JOIN EmpAssignment ON EmpAssignment.TimeRule=TimePermissionPolicy.TimeRule
WHERE PermissionNo=@PermissionNo AND empid=@empid

open OverShortCursor 
-------- in case no policy exists for this permission
------IF @@CURSOR_ROWS=0
------BEGIN
------	RETURN '001'
------END

Fetch next from OverShortCursor
into @PolicyOverShortType,@PolicyAction,@PermissionPeriod,@MinHours,@MaxHours,@MaxTotal,@MaxTotalNo,@MaxTotalEvery,
	@MaxTotalEveryUnit,@MaxTotalSince,@MaxTotalPermCodes,@MaxOccurance,@MaxOccuranceNo,@MaxOccuranceEvery,@MaxOccEveryUnit,@MaxOccuranceSince,@MaxOccurancePermCodes
while @@fetch_status =0
BEGIN
	
	---------------------------------------------------MinHours and MaxHours---------------------------------------------------------
	if @PermissionPeriod=1
	BEGIN
		--calc the duration of the time permission requested[to - from] & check that it is between min & max hours required
		-- And if it is not between min & max required -- > we will calculate the useful part of this permission and if it is between the min & max allowed 
		-- --> will put a notification for our user about that in the error msg
		--SELECT @PermRqstOverShortValue = isnull(DATEDIFF(s,@fromdate,@todate),0)/3600.00
		SELECT @PermRqstOverShortValue = dbo.PermissionTotalTaken(@empid,@DocNo,@fromdate,@todate,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		SELECT @UsefulPart = dbo.PermissionTotalTaken(@empid,@DocNo,@fromdate,@todate,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		DECLARE @usefulpartstring AS NVARCHAR(100)
		DECLARE @usefulH AS SMALLINT,@usefulM AS SMALLINT 
		SET @usefulH = @UsefulPart
		SET @usefulM = CEILING((cast(@UsefulPart AS NUMERIC(9,3)) - cast(@usefulH AS NUMERIC(9,3))) * 60.00)
		SELECT @UsefulPart = (@usefulH * 1.00) + (@usefulM / 60.00)
		if (@PermRqstOverShortValue not between @MinHours and @MaxHours) OR ((@PermRqstOverShortValue BETWEEN @MinHours AND @MaxHours) AND (@UsefulPart < @PermRqstOverShortValue) AND (@UsefulPart BETWEEN @MinHours AND @MaxHours))  
			BEGIN
				SET @PolicyAction = (CASE WHEN (@PolicyAction = 1) AND (@PermRqstOverShortValue BETWEEN @MinHours AND @MaxHours) AND (@UsefulPart < @PermRqstOverShortValue) AND (@UsefulPart BETWEEN @MinHours AND @MaxHours) THEN 2 ELSE @PolicyAction END)
				SELECT @usefulpartstring =  ' [ ' + CONVERT(NVARCHAR(9),@usefulH) + ' ] ' + (CASE WHEN @usefulH > 1 THEN ISNULL(LTRIM(RTRIM(dbo.hits_GetDCCaption('PermissionRestriction','Hours',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'hours and ' ELSE N'ساعة و ' END)) ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','hour',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'hour and ' ELSE N'ساعة و ' END)) END ) 
				                          + ' [ ' + convert(NVARCHAR(9),@usefulM) + ' ] ' + (CASE WHEN @usefulM > 1 THEN ISNULL(LTRIM(RTRIM(dbo.hits_GetDCCaption('PermissionRestriction','Minutes',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'minutes ' ELSE N' دقيقة ' END)) ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minute',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'minute ' ELSE N' دقيقة ' END)) END )
				----SELECT  @usefulpartstring = CASE WHEN @latinlang = 'E' THEN  ' [ ' + CONVERT(NVARCHAR(9),@usefulH) + ' ] '+ CASE WHEN @usefulH > 1 THEN ISNULL(LTRIM(RTRIM(dbo.hits_GetDCCaption('PermissionRestriction','Hours','E'))),'hours')+' and ' ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','hour','E'))),'hour')+' and [ ' END +convert(NVARCHAR(9),@usefulM) + ' ] ' + CASE WHEN @usefulM > 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minutes','E'))),'minutes ') ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minute','E'))),'minute ') END
				----                                                       ELSE   ' [ ' + CONVERT(NVARCHAR(9),@usefulH) + ' ] ' + ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Hour','A'))), N'ساعة ') + N' و [ ' +convert(NVARCHAR(9),@usefulM) + ' ] '  + ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minute','A'))), N'دقيقة ') END 
				
				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END	
				set @reason= @reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + 
				
				     CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
					       ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
					       +'002'+rtrim(ltrim(str(@PolicyAction)))+' - '
					       
			        + (CASE WHEN @PermRqstOverShortValue NOT BETWEEN @MinHours AND @MaxHours THEN  
					    	isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','MinMaxHours',@latinlang))),(case when @latinlang='E' THEN 'Time permission length is not between min and max hours' ELSE ' مدة الإذن ليست فى الفترة المسموح بها ' end))+' .. '
					        ELSE '' END)
					               
					+ (CASE WHEN (@UsefulPart < @PermRqstOverShortValue) AND (@UsefulPart BETWEEN @MinHours AND @MaxHours) THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','UsefulPart',@Latinlang))), (CASE WHEN @Latinlang ='E' THEN 'Note : The useful part of this permission is ' ELSE N'ملاحظة : الجزء المستفاد به من هذا الأذن هو'  END)) +@usefulpartstring ELSE '' END)
					  
		            -- set the PreventWarning Param depending on the policy
					 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
			end
	end
		
	-------------------------------------------------------Total Hours-------------------------------------------------------------

	if @MaxTotal=1 AND @MaxTotalEvery<>0		
	-- @MaxTotalEvery should not equal zero to prevent an endless loop --> if @MaxTotalEvery = 0 means it is accepted perm
	BEGIN
	IF @MaxTotalNo = 0
	BEGIN
		-- setting the reason directly if the max total hours number = 0
		SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
		set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						 -- set the PreventWarning Param depending on the policy
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
	END
	ELSE
		BEGIN
	-- select the start date for calculations (@date1) depending on the user's choice
		select @date1=case when @MaxTotalSince=1 then hiredate 
						   when @MaxTotalSince=2 then isnull(probdate,hiredate) 
						   WHEN @MaxTotalSince=3 THEN CONVERT(smalldatetime,'01/01/'+ltrim(str(year(@fromdate))),111) 
						   WHEN @MaxTotalSince=4 THEN ContStart
						   WHEN @MaxTotalSince=5 THEN isnull(RevisedHireDate,hiredate)
						   WHEN @MaxTotalSince=6 THEN isnull(WorkReceivingDate,hiredate)
						   WHEN @MaxTotalSince=7 THEN (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) END)
					   end 
					  from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
	
	---@date2= @date1 + @MaxTotalEvery
	--@MaxTotalEveryUnit : determines whether @MaxTotalEvery is day, month or year
	--@MaxTotalEvery: the parameter at which max total days 'll reset
	-- increment the values of @date1 and @date2 by the chosen period until @fromdate is within their range
		if @enablehijri=1 and @year<1900 -- in case of hijri
		begin
			set @date2=case
			when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1) -- months
			when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)  -- years
			else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)END						  -- days
			
			while (@fromdate not between @date1 and @date2)
			begin
				set @date1=@date2
				set @date2=case
				when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)
				else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)END
			end
		
		end
		ELSE    -- in case of gregorian
		begin
			set @date2=case
			when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
			else dateadd(d,@MaxTotalEvery,@date1)END
			while (@fromdate not between @date1 and @date2)
			begin
				set @date1=@date2
				set @date2=case
				when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
				else dateadd(d,@MaxTotalEvery,@date1)END
			end	
		END
		-- calculate total permissions length in current period & the part of the new permission inside this period
		 ----SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
		 set @totalhours = dbo.PermissionTotalTaken(@empid,@DocNo,@date1,@date2,0,@PolicyOverShortType,@fromdate,@todate)/3600.00
		 if (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		 begin
		   set @totalhours = @totalhours + dbo.PermissionTotalTaken(@empid,@DocNo,case  when @fromdate > @date1 then @fromdate else @date1 end,case when @todate > @date2 then @date2 else @todate end ,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		 end
		 

		--compare the calculated total hours with Max Total Allowed
		-------------------------------------
		--@MaxOccEveryUnit=1 day  --@MaxOccEveryUnit=2 month  --@MaxOccEveryUnit=3 year  
		
		-- In case the hiredate is between @date1 & @date2 then :
		-- find the @ProratedMaxTotalNo - the part of the MaxTotalNo - from his hiring date till @date2
		SET @HiringProratedHours = 0.00
		IF (@MaxTotalSince=3 OR @MaxTotalSince=7) AND (@HireDate BETWEEN @date1 AND @date2) AND @HireDate <> @date1
		BEGIN
			SELECT @HiringProratedhours=(datediff(mi,@date1,@HireDate))/60.00
		end
		IF @HiringProratedHours<>0
			SET @ProratedMaxTotalNo=(@MaxTotalNo/(((datediff(mi,@date1,@date2)/60.00))*1.00))*((datediff(mi,@date1,@date2)/60.00)-@HiringProratedHours)
		ELSE 
			SET @ProratedMaxTotalNo=@MaxTotalNo

		if @ProratedMaxTotalNo< isnull(@totalhours,0) 
		begin
		    SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
		end

		-- if the @todate falls within another period:
		-- reset the ranges for @date1 and @date2 with the new period start and end dates
		while  (@todate not between @date1 and @date2 ) 
		begin

			set @date1=@date2
			if @enablehijri=1 and @year<1900	-- in case of hijri
			begin
				set @date2=case
				when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)	-- month
				when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)	-- year
				else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)END							-- days

			end
			ELSE		-- in case of gregorian
			begin
				set @date2=case
				when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
				else dateadd(d,@MaxTotalEvery,@date1)END
			end
			
			--calc. totalhours for the 2nd period
			--SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
			  set @totalhours = dbo.PermissionTotalTaken(@empid,@DocNo,@date1,@date2,0,@PolicyOverShortType,@fromdate,@todate)/3600.00
		 if (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		 begin
		   set @totalhours = @totalhours + dbo.PermissionTotalTaken(@empid,@DocNo,case  when @fromdate > @date1 then @fromdate else @date1 end,case when @todate > @date2 then @date2 else @todate end ,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		 end

			SET @ProratedMaxTotalNo=@MaxTotalNo
			if @ProratedMaxTotalNo< isnull(@totalhours,0)
			begin
				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
				set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
							ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
							CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
							+'007'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
							
							 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
			end

		END
-- end of the else block of condition (maxtotalno = 0)		
		END
-- end of the maxtotalhours block
	end
		---------------------------------------------Occurance------------------------------------------------------------------------

	if @MaxOccurance=1 AND @MaxOccuranceEvery<>0
	BEGIN
		IF @MaxOccuranceNo = 0
		BEGIN
			-- setting the reason dircetly if the max occ number = 0
			SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances' else 'عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		END	
		ELSE
			BEGIN
			-- select the start date for calculations (@date1) depending on the user's choice
		declare @count as int
		set @count=0
		select @date1=case when @MaxOccuranceSince=1 then hiredate 
						   when @MaxOccuranceSince=2 then isnull(probdate,hiredate) 
						   WHEN @MaxOccuranceSince=3 THEN CONVERT(smalldatetime,'01/01/'+ltrim(str(year(@fromdate))),111) 
						   WHEN @MaxOccuranceSince=4 THEN ContStart
						   WHEN @MaxOccuranceSince=5 THEN isnull(RevisedHireDate,hiredate)
						   WHEN @MaxOccuranceSince=6 THEN isnull(WorkReceivingDate,hiredate)
						   WHEN @MaxOccuranceSince=7 THEN (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) END)
					   end 
					  from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
		
		--@date2= @date1 + @@MaxOccuranceEvery
		--@MaxOccEveryUnit : determines whether @MaxOccuranceEvery is day, month or year
		--@MaxOccuranceEvery: the parameter at which max occurance 'll reset
		-- increment the values of @date1 and @date2 by the chosen period until @fromdate is within their range
		if @enablehijri=1 and @year<1900		-- in case of hijri
			begin
				set @date2=case
				when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)	-- month
				when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)	-- year
				else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)END   					-- day
				
				while (@fromdate not between @date1 and @date2)
				begin
					set @date1=@date2
					set @date2=case
					when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)
					when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)
					else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)END
				end
			end
			
		ELSE			-- in case of gregorian
			begin
				set @date2=case
				when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
				else dateadd(d,@MaxOccuranceEvery,@date1)END
				
				while (@fromdate not between @date1 and @date2)
				begin
				set @date1=@date2
				set @date2=case
				when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
				else dateadd(d,@MaxOccuranceEvery,@date1)END

				end
			end

		--calc how many times this OverShort type was taken by the employee within @date1 and @date2
		--------------------------------------------------------------------------------------------
		-- If OverShortType is 4 (Over [Total]: get total count of (1,2,3,4)   
		-- If OverShortType is 8 (Short [Total]: get total count of (5,6,7,8)  
		-- Else, get total count of that OverShortType only
		select @count=sum(case when (DATEDIFF(s,CASE WHEN e.PermissionFrom < @date1 THEN @date1 ELSE e.PermissionFrom END,CASE WHEN e.PermissionTo > @date2 THEN @date2 ELSE e.PermissionTo END)) = 0 THEN 0 ELSE 1 END)
		 from EmpTimePermission e
		 LEFT JOIN TimePermission tp ON tp.PermissionNo = e.PermissionNo
		where e.DocumentStatus=1 and e.empid=@empid AND e.DocumentNo<>@DocNo  
		AND tp.OverShort = (CASE WHEN ltrim(rtrim(@MaxOccurancePermCodes)) = '' THEN @PolicyOverShortType ELSE tp.OverShort END)
		--AND ((@PolicyOverShortType=4 AND tp.OverShort IN (1,2,3,4)) OR (@PolicyOverShortType=8 AND tp.OverShort IN (5,6,7,8)) OR (@PolicyOverShortType=tp.OverShort))
		AND LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxOccurancePermCodes)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(tp.PermissionNo)))+',%' END)
		and ((e.PermissionFrom between @date1 and @date2) or 
		     (e.PermissionTo between @date1 and @date2) or 
		     (@date1 between e.PermissionFrom and e.PermissionTo) or 
		     (@date2 between e.PermissionFrom  and e.PermissionTo))
		 
		--add the current requested TimePermission to the above count calculated only in the following cases:
		-- 1. if the [MaxOccurancePermCode] is empty -- >  the permission over/short type must be = policy over/short type
		-- 2. if the [MaxOccurancePermCode] is not empty -- > This codes [MaxOccurancePermCode] : must contain the permission no 
		
		----IF (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		IF ((LTRIM(RTRIM(@MaxOccurancePermCodes)) = '') AND(@PermRqstOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxOccurancePermCodes)) <> '') AND (LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
		set @count=@count+1
		
		
		--compare the Calculated Count above with Max Occurance allowed
		---------------------------------------------------------------
		-- In case the hiredate is between @date1 and @date2, 
		-- find the @ProratedMaxOccuranceNo - the part of MaxOccuranceNo - from his hiring date till @date2
		SET @HiringProratedHours = 0.00
		IF (@MaxOccuranceSince=3 OR @MaxOccuranceSince=7) AND (@HireDate BETWEEN @date1 AND @date2) AND (@HireDate<>@date1)
		BEGIN
			SELECT @HiringProratedHours=(datediff(mi,@date1,@HireDate))/60.00
		END

		IF @HiringProratedHours<>0				---OR @VacAffectDueDays<>0
			SET @proratedMaxOccuranceNo= (SELECT dbo.roundto((@MaxOccuranceNo/(((datediff(mi,@date1,@date2)/60.00))*1.00))*((datediff(mi,@date1,@date2)/60.00)-@HiringProratedHours),1,1))  
		ELSE 
			SET 	@proratedMaxOccuranceNo=@MaxOccuranceNo
		
		if @proratedMaxOccuranceNo<@count 
		BEGIN
			SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances' else 'عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		end

		-- if the @todate falls within the next period, reset the ranges for @date1 and @date2 with the new period start and end dates
		-------------------------------
		while  (@todate not between @date1 and @date2 ) 
		begin

			set @date1=@date2
			if @enablehijri=1 and @year<1900	-- case of hijri
			begin
				set @date2=case
				when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)		-- month
				when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)		-- year
				else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)END								-- day

			end
			else
			begin
				set @date2=CASE					-- case of gregorian
				when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
				else dateadd(d,@MaxOccuranceEvery,@date1)END
			end
			
		set @count=0
		select @count=sum(case when (DATEDIFF(s,CASE WHEN e.PermissionFrom < @date1 THEN @date1 ELSE e.PermissionFrom END,CASE WHEN e.PermissionTo > @date2 THEN @date2 ELSE e.PermissionTo END)) = 0 THEN 0 ELSE 1 END) 
		from EmpTimePermission e
		 LEFT JOIN TimePermission tp ON tp.PermissionNo = e.PermissionNo
		where e.DocumentStatus=1 and e.empid=@empid AND e.DocumentNo<>@DocNo  
		AND tp.OverShort = (CASE WHEN ltrim(rtrim(@MaxOccurancePermCodes)) = '' THEN @PolicyOverShortType ELSE tp.OverShort END)
		--AND ((@PolicyOverShortType=4 AND tp.OverShort IN (1,2,3,4)) OR (@PolicyOverShortType=8 AND tp.OverShort IN (5,6,7,8)) OR (@PolicyOverShortType=tp.OverShort))
		AND LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxOccurancePermCodes)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(tp.PermissionNo)))+',%' END)
		and ((e.PermissionFrom between @date1 and @date2) or 
		     (e.PermissionTo between @date1 and @date2) or 
		     (@date1 between e.PermissionFrom and e.PermissionTo) or 
		     (@date2 between e.PermissionFrom  and e.PermissionTo))
		

		----IF (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		IF ((LTRIM(RTRIM(@MaxOccurancePermCodes)) = '') AND(@PermRqstOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxOccurancePermCodes)) <> '') AND (LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
			set @count=@count+1

		SET @proratedMaxOccuranceNo=@MaxOccuranceNo
		if @proratedMaxOccuranceNo<@count 
		begin
		    SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'009'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances' else 'عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		end

		end
		-----------------------------
-- end of the else block (if condition : maxoccNo = 0)
			END
-- end of the occno block			
END
	
----------------------------------------------------------------------------

FETCH NEXT FROM OverShortCursor 
INTO @PolicyOverShortType,@PolicyAction,@PermissionPeriod,@MinHours,@MaxHours,@MaxTotal,@MaxTotalNo,@MaxTotalEvery,
	@MaxTotalEveryUnit,@MaxTotalSince,@MaxTotalPermCodes,@MaxOccurance,@MaxOccuranceNo,@MaxOccuranceEvery,@MaxOccEveryUnit,@MaxOccuranceSince,@MaxOccurancePermCodes

	end
close OverShortCursor 
DEALLOCATE OverShortCursor
----------------------------------------------------------------------------------------end of looping through the perm. policies
END 	

-----------------------------------------------------------------
SET @reason = CASE WHEN @reason = '' THEN '001'
                  ELSE ltrim(rtrim(str(@PreventWarning))) + rtrim(ltrim(@reason)) + '.' END

RETURN @reason
end

GO

