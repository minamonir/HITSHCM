CREATE FUNCTION [dbo].[CalcExperience](@fromdate AS DATETIME , @todate AS DATETIME , @Lang AS CHAR(1) , @Empid AS INT,@TotalExp AS INT,@Format AS int)
RETURNS NVARCHAR(MAX) 
AS
BEGIN
	DECLARE @TotalMonths AS NUMERIC(18,3),@FormatedExp AS NVARCHAR(100)

-----------------------------getting date diff in months (for two dates)---------------
IF @Empid = 0 AND @fromdate   IS NOT NULL AND @todate IS NOT NULL
BEGIN 
     SET @TotalMonths =  [dbo].[vac_datediff](@fromdate,@todate)   
END 
---------------------------------------------------------------------------------------
--------------------------- calculating the total previous experience per each employee-------------------------------------
ELSE IF @Empid <> 0 AND @fromdate   IS NOT NULL AND @todate IS NOT NULL
BEGIN 

    IF @Format=5
	BEGIN
	 SELECT @TotalMonths = SUM(datediff(DAY,EmpQualification.AttendFromDate, EmpQualification.AttendToDate)+1)
     FROM EmpQualification 
     LEFT JOIN Qualification ON Qualification.QualificationNo = EmpQualification.QualificationNo
     LEFT JOIN QualificationType ON QualificationType.QualificationType = Qualification.QualificationType 
     WHERE EmpId = @Empid AND QualificationType.SystemQualificationType = 1 AND EmpQualification.AttendFromDate   IS NOT NULL AND EmpQualification.AttendToDate IS NOT NULL    

	 IF @TotalExp=1
      BEGIN

       SELECT @TotalMonths = ISNULL(@TotalMonths,0)+(
	   CASE WHEN hiredate>GETDATE() THEN 0 ELSE 
	  datediff(DAY,hiredate,CASE WHEN TermDate IS NULL OR TermDate>GETDATE() THEN GETDATE() ELSE termdate END )+1 END )
       FROM dbo.EmpAssignment
       WHERE empid=@empid
      END
	END 

	ELSE 
	BEGIN 
	  SELECT @TotalMonths = SUM([dbo].[vac_datediff](EmpQualification.AttendFromDate, EmpQualification.AttendToDate))
     FROM EmpQualification 
     LEFT JOIN Qualification ON Qualification.QualificationNo = EmpQualification.QualificationNo
     LEFT JOIN QualificationType ON QualificationType.QualificationType = Qualification.QualificationType 
     WHERE EmpId = @Empid AND QualificationType.SystemQualificationType = 1 AND EmpQualification.AttendFromDate   IS NOT NULL AND EmpQualification.AttendToDate IS NOT NULL
	
-------------------------- calculating the experience till current date if employee doesn't have termdate------------------------------
    IF @TotalExp=1
      BEGIN

       SELECT @TotalMonths = ISNULL(@TotalMonths,0)+(
	   CASE WHEN hiredate>GETDATE() THEN 0 ELSE 
	   [dbo].[vac_datediff](hiredate,CASE WHEN TermDate IS NULL OR TermDate>GETDATE() THEN GETDATE() ELSE termdate END ) END )
       FROM dbo.EmpAssignment
       WHERE empid=@empid
      END
	 END 
----------------------------------------------------------------------------------------------------------------------------------------    
END
---------------------------/ calculating the total previous experience per each employee-------------------------------------


------------------- Getting No of days----------------------------------
DECLARE @days INT  , @tempMonths INT

SET @tempMonths = CAST(@TotalMonths AS int)
SET @days =CAST( CAST( (@TotalMonths - @tempMonths) AS NUMERIC(18,3)) * 30 AS INT)

------------------------------------------------------------------------

IF @Format=0 ----------------- Total As MM
SET @FormatedExp=cast(@TotalMonths AS NUMERIC(18,3))
IF @Format=1 ----------------- Total As YY
SET @FormatedExp=cast(@TotalMonths/12 AS int)
IF  @Format=2 ----------------- Total As YY-MM
SET @FormatedExp=RTRIM(cast(@TotalMonths/12 AS int))+'-'+RTRIM(cast(@TotalMonths%12 AS int))
IF  @Format=3 ----------------- Total As YY-MM-DD
SET @FormatedExp=RTRIM(cast(@TotalMonths/12 AS int))+'-'+RTRIM(cast(@TotalMonths%12 AS int))+'-'+RTRIM(cast(@days AS int))
IF  @Format=4 ----------------- Total As DD-MM-YY
SET @FormatedExp=RTRIM(cast(@days AS int))+'-'+RTRIM(cast(@TotalMonths%12 AS int))+'-'+RTRIM(cast(@TotalMonths/12 AS int))
IF @Format=5 ----------------- Total As dd
SET @FormatedExp=@TotalMonths
RETURN @FormatedExp
END

GO

