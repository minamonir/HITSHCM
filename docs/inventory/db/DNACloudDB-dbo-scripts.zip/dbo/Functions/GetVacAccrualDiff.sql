CREATE FUNCTION [dbo].[GetVacAccrualDiff] (@empid int, @payperiod smallint, 
  @startdate smalldatetime, @enddate  smalldatetime, @VacType smallint, @AccrualOption smallint )
RETURNS numeric(18,3) AS  
begin
  --@AccrualOption=6 basicsal
  --@AccrualOption=7 totalsal
  declare @ReturnVal as numeric(18,3), @BasicSal as numeric(18,3), @BasicSalOld as numeric(18,3),
      @TotalSal as numeric(18,3), @TotalSalOld as numeric(18,3)
      
  set @ReturnVal=0
  
  if @BasicSal<>@BasicSalOld and @AccrualOption=6
  begin
    set @ReturnVal=0
  end
  if @TotalSal<>@TotalSalOld and @AccrualOption=7
  begin
    set @ReturnVal=0
  end

RETURN @ReturnVal
end

GO

