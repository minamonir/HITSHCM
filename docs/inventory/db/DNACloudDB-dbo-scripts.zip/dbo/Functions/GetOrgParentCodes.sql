

--this fn calculate the amount for certain paycode

CREATE FUNCTION [dbo].[GetOrgParentCodes](@Org int)

RETURNS nvarchar(max) AS  

begin

IF NOT exists(SELECT * FROM OrganizationStructure 
WHERE OrganizationStructure.Organization=@org)
RETURN N'' 

DECLARE @orgparent  AS int,@desc AS nvarchar(max)
sET @orgparent=@org

SET @desc=N''

WHILE @orgparent IS NOT NULL
begin
SELECT @desc= isnull(rtrim(ltrim(str(organization.organization)))+'\','')+@desc 
,@orgparent=organizationparent
FROM Organizationstructure 
LEFT JOIN organization ON Organizationstructure.Organizationparent = Organization.Organization
WHERE Organizationstructure.Organization=@orgparent

END

SELECT @desc=@desc+rtrim(ltrim(str(organization.organization)))
FROM Organization 
WHERE Organization=@org

RETURN @desc
end

GO

