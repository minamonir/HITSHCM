CREATE FUNCTION [dbo].[HideMaxRatingLevel] (@empid AS INT ,@date AS NVARCHAR(MAX))
RETURNS BIT 
AS
BEGIN
DECLARE @return_val AS BIT =0
--DECLARE @date AS SMALLDATETIME 
DECLARE @yearstart AS SMALLDATETIME , @yearend AS SMALLDATETIME

DECLARE @CustomAppraisalRatingLevels AS SMALLINT =0
SELECT @CustomAppraisalRatingLevels=configvalue FROM sysparamconfig WHERE ConfigID='CustomAppraisalRatingLevels'
IF ISNULL(@CustomAppraisalRatingLevels,0)=1
BEGIN 



select @yearstart =dbo.periodstart(empassignment.payrollgroup,1, YEAR(@date) ),@yearend=dbo.periodend(empassignment.payrollgroup,12,YEAR(@date))
FROM empassignment 
WHERE empid=@empid

IF @date NOT BETWEEN @yearstart AND @yearend 
select @yearstart=DATEADD(YEAR ,1,@yearstart) ,@yearend =DATEADD(YEAR ,1,@yearend)

IF EXISTS (SELECT * 
           FROM EmpTraining
           INNER JOIN trainingevents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
		  WHERE  emptraining.empid =@empid 
		  AND  (@yearstart BETWEEN trainingevents.EventFromDate AND trainingevents.EventToDate 
		      OR @yearend BETWEEN trainingevents.EventFromDate AND trainingevents.EventToDate 
		      OR trainingevents.EventFromDate  BETWEEN @yearstart AND @yearend 
		      OR trainingevents.EventToDate BETWEEN @yearstart AND @yearend)
		  AND emptraining.EnrollStatus IN (SELECT Trainingenrollstatus.EnrollStatus FROM trainingenrollstatus WHERE SystemEnrollStatus=6)) 
OR EXISTS(SELECT * 
          FROM dbo.EmpMscon
		  WHERE empmscon.empid =@empid AND empmscon.misstatus=1 AND misdate BETWEEN @yearstart AND @yearend)

SET @return_val= 1
ELSE
SET @return_val =0
END 

RETURN @return_val
END

GO

