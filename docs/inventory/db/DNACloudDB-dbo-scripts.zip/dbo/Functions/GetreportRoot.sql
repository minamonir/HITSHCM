CREATE FUNCTION dbo.GetreportRoot
  (@ProfileId smallint)
RETURNS  smallint
as
BEGIN 
  declare @returntype as smallint, @rootint as smallint
  set  @returntype=@ProfileId
  set @rootint=0
  while 1=1
    begin  
       select @rootint=parentno  from reports where reportno=@returntype
       if  @rootint is not null set @returntype=@rootint else break         
   end
  return @returntype
END

GO

