Create FUNCTION [dbo].[GetValidCodeText](@TableName  nvarchar(120),  @Value  nvarchar(120),@Date datetime) RETURNS  nvarchar(40) as BEGIN
  declare @ReturnTxt as nvarchar(40)
  
  DECLARE @EnableDateValidation AS bit
  SELECT @EnableDateValidation=EnableDateValidation FROM SysParam 
  -- --change of status
  -- if @SSDocType=1  
  -- select top 1 @DocumentNo=DocumentNo from EmpStatusHdr where Empid=@ProfileId order by Empid, DocumentNo desc
  ----misconduct
  -- if @SSDocType=2  
  -- select top 1 @DocumentNo=DocumentNo from empmscon where Empid=@ProfileId order by Empid, DocumentNo desc
  ----vacation
   IF @EnableDateValidation=1
BEGIN 
	SElect @Date=isnull(@date,convert(smalldatetime,convert(nchar(12),todaydate),103))
	FROM Today
   if @TableName='[vacation]'  
   select @ReturnTxt =  N''
   from vacation where 
   @Date between isnull([vacationFromDate],@Date )  and isnull([vacationToDate] , @Date ) 
   and vaccode = @Value
 
   if @TableName='[Mscondct]'  
   select @ReturnTxt =  N''
   from Mscondct where 
   @Date between isnull([MscondctFromDate],@Date )  and isnull([MscondctToDate] , @Date ) 
   and mscode = @Value
   
   if @TableName='[MedicalItems]'  
   select @ReturnTxt =  N''
   FROM MedicalItems where 
   @Date between isnull([MedicalItemFromDate],@Date )  and isnull([MedicalItemToDate] , @Date ) 
   AND MedicalItem = @Value
 
    if @TableName='[ChngStat]'  
   select @ReturnTxt =  N''
   FROM ChngStat where 
   @Date between isnull([ChngStatFromDate],@Date )  and isnull([ChngStatToDate] , @Date ) 
   AND ChgCode = @Value
   
   if @TableName='[BenefitPlans]'  
   select @ReturnTxt =  N''
   FROM BenefitPlans where 
   @Date between isnull([BenefitPlanFromDate],@Date )  and isnull([BenefitPlanToDate] , @Date ) 
   AND PlanNo = @Value
   
   IF @TableName='[Appraisals]'
   select @ReturnTxt =  N''
   FROM Appraisals where 
   @Date between isnull([AppraisalFromDate],@Date )  and isnull([AppraisalToDate] , @Date ) 
   AND AppraisalNo = @Value
 
    IF @TableName='[HKItems]'
   select @ReturnTxt =  N''
   FROM HKItems where 
   @Date between isnull([HKItemFromDate],@Date )  and isnull([HKItemToDate] , @Date ) 
   AND HKItem = @Value
   
       IF @TableName='[StaffRooms]'
   select @ReturnTxt =  N''
   FROM StaffRooms where 
   @Date between isnull([StaffRoomFromDate],@Date )  and isnull([StaffRoomToDate] , @Date ) 
   AND RoomNo = @Value
   
   IF @TableName='[TimePermission]'
   select @ReturnTxt =  N''
   FROM TimePermission where 
   @Date between isnull([TimePermissionFromDate],@Date )  and isnull([TimePermissionToDate] , @Date ) 
   AND PermissionNo = @Value  
   
   IF @TableName='[Objectives]'
   select @ReturnTxt =  N''
   FROM Objectives where 
   @Date between isnull([ObjectiveStartDate],@Date )  and isnull([ObjectiveEndDate] , @Date ) 
   AND ObjectiveId = @Value  
   
    IF @TableName='[Competencies]'
   select @ReturnTxt =  N''
   FROM Competencies where 
   @Date between isnull([CompetenceFromDate],@Date )  and isnull([CompetenceToDate] , @Date ) 
   AND Competence = @Value  
   
    IF @TableName='[Document]'
   select @ReturnTxt =  N''
   FROM Document where 
   @Date between isnull([DocumentFromDate],@Date )  and isnull([DocumentToDate] , @Date ) 
   AND docid = @Value
   
    IF @TableName='[BenefitItems]'
   select @ReturnTxt =  N''
   FROM BenefitItems where 
   @Date between isnull([BenefitItemFromDate],@Date )  and isnull([BenefitItemToDate] , @Date ) 
   AND ItemNo = @Value
   
    IF @TableName='[VacationDue]'
   select @ReturnTxt =  N''
   FROM VacationDue where 
   @Date between isnull([VacDueFromDate],@Date )  and isnull([VacDueToDate] , @Date ) 
   AND VacDueCode = @Value
   
    if @TableName='[Jobs]'  
   select @ReturnTxt =  N''
   from Jobs where 
   @Date between isnull([JobFromDate],@Date )  and isnull([JobToDate] , @Date ) 
   and Job = @Value
 
  if @TableName='[Positions]'  
   select @ReturnTxt =  N''
   from Positions where 
   @Date between isnull([PositionFromDate],@Date )  and isnull([PositionToDate] , @Date ) 
   and PositionNo = @Value
   
   if @TableName='[Grades]'  
   select @ReturnTxt =  N''
   from Grades where 
   @Date between isnull([GradeFromDate],@Date )  and isnull([GradeToDate] , @Date ) 
   and Grade = @Value
   
      if @TableName='[Location]'  
   select @ReturnTxt =  N''
   from Location where 
   @Date between isnull([LocationFromDate],@Date )  and isnull([LocationToDate] , @Date ) 
   and LocationNo = @Value
 
   if @TableName='[Organization]'  
   select @ReturnTxt =  N''
   from Organization where 
   @Date between isnull([OrganizationFromDate],@Date )  and isnull([OrganizationToDate] , @Date ) 
   and Organization = @Value
   
   if @TableName='[AppraisalActions]'  
   select @ReturnTxt =  N''
   from AppraisalActions where 
   @Date between isnull([AppraisalActionFromDate],@Date )  and isnull([AppraisalActionToDate] , @Date ) 
   and AppraisalAction = @Value
   
   if @TableName='[Activities]'  
   select @ReturnTxt =  N''
   from Activities where 
   @Date between isnull([ActivityFromDate],@Date )  and isnull([ActivityToDate] , @Date ) 
   and ActivityNo = @Value
   
   if @TableName='[TrainingEvals]'  
   select @ReturnTxt =  N''
   from TrainingEvals where 
   @Date between isnull([TrainingEvalStartDate],@Date )  and isnull([TrainingEvalEndDate] , @Date ) 
   and TrainingEval = @Value
   
   IF @TableName='[TimeShifts]'
   SELECT @ReturnTxt = N''
   FROM TimeShifts WHERE 
   @Date BETWEEN	ISNULL([TimeShiftFromDate],@Date) AND ISNULL([TimeShiftToDate],@Date)
   AND ShiftNo =@Value

   IF @TableName='[HRRequest]'
   SELECT @ReturnTxt = N''
   FROM HRRequest WHERE 
   @Date BETWEEN	ISNULL([Hrreqfromdate],@Date) AND ISNULL([HRReqToDate],@Date)
   AND HRReqCode =@Value

   IF @TableName='[TaskCat]'
   SELECT @ReturnTxt = N''
   FROM TaskCat WHERE 
   @Date BETWEEN	ISNULL([TaskCatFromDate],@Date) AND ISNULL([TaskCatToDate],@Date)
   AND TaskCat =@Value

 -- --application  
 --  if @SSDocType=4  select top 1 @DocumentNo=AssignmentId from appassignment where Empid=@ProfileId order by Empid, AssignmentId desc
 ----medical 
 -- if @SSDocType=5  select top 1 @DocumentNo=DocumentNo from empmedical where Empid=@ProfileId order by Empid, DocumentNo desc 
 ----Appraisal  
 -- if @SSDocType=6  select top 1 @DocumentNo=DocumentNo from empappraisal where Empid=@ProfileId order by Empid, DocumentNo desc
 -- --benefit  
 --  if @SSDocType=7  select top 1 @DocumentNo=DocumentNo from empbenefit where Empid=@ProfileId order by Empid, DocumentNo desc
 -- --vacation due adjustment  
 --  if @SSDocType=8  select top 1 @DocumentNo=DocumentNo from EmpVacationDue where Empid=@ProfileId order by Empid, DocumentNo desc
 -- --training  
 --  if @SSDocType=9  select top 1 @DocumentNo=DocumentNo from emptraining where Empid=@ProfileId order by Empid, DocumentNo desc
 -- --staffhousing
 --  if @SSDocType=10  select top 1 @DocumentNo=DocumentNo from emphkitems where Empid=@ProfileId order by Empid, DocumentNo desc
 -- --Profilettachment
 --  if @SSDocType=11  select top 1 @DocumentNo=DocumentNo from Profileattachment where profileid=@ProfileId order by profileid, DocumentNo desc
 -- --EmpTimePermission
 --  if @SSDocType=12 select top 1 @DocumentNo=DocumentNo from EmpTimePermission where Empid=@ProfileId order by Empid, DocumentNo desc
END
ELSE
	BEGIN
		SET @ReturnTxt=N''
	END
  return isnull(@ReturnTxt,N'*')
END

GO

