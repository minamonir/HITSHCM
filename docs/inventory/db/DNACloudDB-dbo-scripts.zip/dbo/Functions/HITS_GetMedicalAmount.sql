
CREATE      FUNCTION dbo.HITS_GetMedicalAmount
  (@empid int, @DocumentNo int)
	
RETURNS numeric(18,3)
AS
 BEGIN
 declare @amount numeric(18,3)
  select @amount=sum(isnull(amount,0)) from empmedicaldetail where empid=@empid and documentno=@documentno
set @amount=isnull(@amount,0)
return @amount
END

GO

