--select dbo.h_DATEADD('month',999,'2005-01-01')



CREATE    FUNCTION [dbo].[h_dateadd]
	(@datepart nvarchar(5),  @number smallint, @date datetime)
RETURNS  datetime
AS
BEGIN
declare @l_returndate as datetime
declare @l_day As smallint
declare @l_year As smallint
declare @l_month As smallint
declare @l_hijridate As nchar(10)
declare @l_dateformat as smallint
declare @l_endday as smallint

if upper(@datepart)=N'DAY' or upper(@datepart)=N'DD' 
  set  @l_returndate=dateadd(dd, @number, @date) 
else
   begin
         select @l_dateformat=dateformat from sysparam
         set @l_hijridate=dbo.Greg2Hijri(@date,N'O')
        --yyyy/mm/dd
         set @l_year=cast(substring(@l_hijridate,1,4) as smallint)
         set @l_month=cast(substring(@l_hijridate,6,2) as smallint)
         set @l_day=cast(substring(@l_hijridate,9,2) as smallint)
        if upper(@datepart)=N'YEAR' or upper(@datepart)=N'YY'   set @l_year= @l_year+@number 
        else 
           begin 
                if upper(@datepart)=N'MONTH' or upper(@datepart)=N'MM' 
                    begin
                          if @number>0
                             begin
                                  while  @number>0
                                      begin
                                          if @l_month=12 
                                             begin    
                                                  set @l_month=1 
                                                  set @l_year=   @l_year+1
                                             end         
                                           else set @l_month= @l_month+1
                                          set  @number=@number-1                             
                                      end
                              end
                          else
                             begin
                                 while  @number<0
                                      begin
                                          if @l_month=1 
                                             begin    
                                                  set @l_month=12 
                                                  set @l_year=   @l_year-1
                                             end         
                                           else set @l_month= @l_month-1
                                          set  @number=@number+1                             
                                      end
                            end   
                    end        
           end              
  select @l_endday=hijridays from hijribase where hijrimonth=@l_month
  select @l_endday=@l_endday+isnull(adjustment,0) from hijriadjustment where hijriyear=@l_year and hijrimonth=@l_month
  if @l_day<=@l_endday set @l_day=@l_day else set @l_day=@l_endday
  set @l_hijridate= CASE when @l_dateformat=0 then str(@l_year,4)+N'/'+str(@l_month,2)+N'/'+str(@l_day,2)
                         when @l_dateformat=1 then str(@l_day,2)+N'/'+str(@l_month,2)+N'/'+str(@l_year,4)
                         when @l_dateformat=2 then str(@l_month,2)+N'/'+str(@l_day,2)+N'/'+str(@l_year,4) end
  set @l_returndate=dbo.Hijri2Greg(@l_hijridate)
 end

return @l_returndate
END

GO

