
CREATE FUNCTION [dbo].[WP_OnBoardingOrNot](@EmpId INT,@Date DATETIME,@Lang AS CHAR(1))
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @result AS NVARCHAR(max)=''

--SELECT  @result= CASE empvacat.documentno WHEN NULL THEN 2 ELSE 1 end
--FROM empassignment 
--INNER JOIN empvacat ON empassignment.empid = empvacat.empid AND CONVERT(varchar, @Date, 103) 
--BETWEEN CONVERT(varchar, FromDate, 103) AND CONVERT(varchar, ToDate, 103) AND empvacat.empid = @empid

--SELECT @result = ISNULL(@result,2)



--SET @result=''
--IF EXISTS(SELECT * FROM dbo.EmpVacat WHERE EmpId=@EmpId AND CONVERT(varchar, @Date, 103) 
--BETWEEN CONVERT(varchar, FromDate, 103) AND CONVERT(varchar, ToDate, 103) AND VacStatus=1)

SELECT  @result= CASE WHEN @Lang='A' THEN LTRIM(RTRIM(VacationAName)) ELSE  LTRIM(RTRIM(VacationName)) END + ' - '+ CONVERT(NVARCHAR(10),FromDate,103) + ' - ' + CONVERT(NVARCHAR(10),ToDate,103) 
FROM dbo.EmpVacat
INNER JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
 WHERE EmpId=@EmpId AND @Date BETWEEN  FromDate AND  ToDate AND VacStatus=1

SET @result=ISNULL(@result,'')



RETURN @result
END

GO

