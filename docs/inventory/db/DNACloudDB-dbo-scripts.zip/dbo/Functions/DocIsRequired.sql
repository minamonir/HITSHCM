



--This fn returns 1 if a document is required for an employee and 0 if not required
CREATE  FUNCTION [dbo].[DocIsRequired]  
  (@ProfileId int, @DocId smallint)
RETURNS bit
AS  
BEGIN
declare  @AllHRStatus as bit ,  @AllJob as bit ,  
@AllOrganization as bit ,  @AllPosition as bit ,  @AllLocation as bit ,  
@AllGender as bit ,  @AllForeigner as bit ,  @AllMilStatus as bit ,  
@AllSocStatus as bit ,  @AllEmployer as bit ,  @AllGrade as bit ,  
@AllGraduation as bit ,  @OrHRStatus as smallint ,  @OrJob as smallint ,  
@OrOrganization as smallint ,  @OrPosition as smallint ,  @OrLocation as smallint ,  
@OrGender as smallint ,  @OrForeigner as smallint ,  @OrMilStatus as smallint ,  
@OrSocStatus as smallint ,  @OrEmployer as smallint ,  @OrGrade as smallint ,  
@OrGraduation as smallint

IF @ProfileId > 0
BEGIN 
SELECT @AllHRStatus=AllHRStatus, @AllJob=AllJob, 
@AllOrganization=AllOrganization, @AllPosition=AllPosition, 
@AllLocation=AllLocation, @AllGender=AllGender,
@AllForeigner=AllForeigner, @AllMilStatus=AllMilStatus, 
@AllSocStatus=AllSocStatus, @AllEmployer=AllEmployer,
@AllGrade=AllGrade, @AllGraduation=AllGraduation,
@OrHRStatus=OrHRStatus, @OrJob=OrJob, 
@OrOrganization=OrOrganization, @OrPosition=OrPosition, 
@OrLocation=OrLocation, @OrGender=OrGender, 
@OrForeigner=OrForeigner, @OrMilStatus=OrMilStatus, 
@OrSocStatus=OrSocStatus, @OrEmployer=OrEmployer, 
@OrGrade=OrGrade, @OrGraduation=OrGraduation
FROM Document
Where Document.docid = @DocId

declare @ANDReq as bit,@ORreq as bit,@ItemReq as bit

set @ANDReq=case when @OrHRStatus =0 and  @OrJob =0 and @OrOrganization=0 
and @OrPosition=0 and  @OrLocation=0 and
@OrGender=0 and @OrForeigner =0 and @OrMilStatus=0 and @OrSocStatus =0 and @OrEmployer =0
and @OrGrade=0 and @OrGraduation =0 then 0 else 1 end

set @ORreq=0
set @ItemReq=0

-----------------------------------------------hrstatus----------------------------------------------------
if @AllHRStatus = 0 and @OrHRStatus = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and hrstatus in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='HRSTATUS')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllHRStatus = 1 and @OrHRStatus = 0   
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllHRStatus = 0 and @OrHRStatus = 1   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and hrstatus in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='HRSTATUS')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllHRStatus = 1 and @OrHRStatus = 1   
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Job----------------------------------------------------

if @AllJob = 0 and @OrJob = 0    
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and JOB in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='JOB')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllJob = 1 and @OrJob = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllJob = 0 and @OrJob = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and JOB in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='JOB')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0
end
if @AllJob = 1 and @OrJob = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Organization----------------------------------------------------

if @AllOrganization = 0 and @OrOrganization = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and ORGANIZATION in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='ORGANIZATION')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllOrganization = 1 and @OrOrganization = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllOrganization = 0 and @OrOrganization = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and ORGANIZATION in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='ORGANIZATION')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0  
end
if @AllOrganization = 1 and @OrOrganization = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Position----------------------------------------------------

if @AllPosition = 0 and @OrPosition = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and isnull(POSITIONNO,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='POSITIONNO')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllPosition = 1 and @OrPosition = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllPosition = 0 and @OrPosition = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and isnull(POSITIONNO,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='POSITIONNO')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllPosition = 1 and @OrPosition = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Location----------------------------------------------------

if @AllLocation = 0 and @OrLocation = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and isnull(LOCATIONNO,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='LOCATIONNO')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllLocation = 1 and @OrLocation = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllLocation = 0 and @OrLocation = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from empassignment where empid=@ProfileId and isnull(LOCATIONNO,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='LOCATIONNO')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllLocation = 1 and @OrLocation = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Gender----------------------------------------------------

if @AllGender = 0 and @OrGender = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(GENDER,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='GENDER')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllGender = 1 and @OrGender = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllGender = 0 and @OrGender = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(GENDER,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='GENDER')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllGender = 1 and @OrGender = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Foreigner----------------------------------------------------

if @AllForeigner = 0 and @OrForeigner = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(FOREIGNER,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='FOREIGNER')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllForeigner = 1 and @OrForeigner = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllForeigner = 0 and @OrForeigner = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(FOREIGNER,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='FOREIGNER')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllForeigner = 1 and @OrForeigner = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------MilStatus----------------------------------------------------

if @AllMilStatus = 0 and @OrMilStatus = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(MILSTATUS,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='MILSTATUS')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllMilStatus = 1 and @OrMilStatus = 0
begin
select @ItemReq =1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllMilStatus = 0 and @OrMilStatus = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(MILSTATUS,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='MILSTATUS')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0  
end
if @AllMilStatus = 1 and @OrMilStatus = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------SocStatus----------------------------------------------------

if @AllSocStatus = 0 and @OrSocStatus = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(SOCSTATUS,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='SOCSTATUS')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllSocStatus = 1 and @OrSocStatus = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllSocStatus = 0 and @OrSocStatus = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(SOCSTATUS,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='SOCSTATUS')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllSocStatus = 1 and @OrSocStatus = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
-----------------------------------------------Employer----------------------------------------------------

if @AllEmployer = 0 and @OrEmployer = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from Empassignment where empid=@ProfileId and isnull(EMPLOYERID,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='EMPLOYERID')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllEmployer = 1 and @OrEmployer = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllEmployer = 0 and @OrEmployer = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from Empassignment where empid=@ProfileId and isnull(EMPLOYERID,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='EMPLOYERID')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllEmployer = 1 and @OrEmployer = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end

-----------------------------------------------Grade----------------------------------------------------

if @AllGrade  = 0 and @OrGrade = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from Empassignment where empid=@ProfileId and isnull(GRADE,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='GRADE')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllGrade = 1 and @OrGrade = 0
begin
select @ItemReq =1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllGrade = 0 and @OrGrade = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from Empassignment where empid=@ProfileId and isnull(GRADE,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='GRADE')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllGrade = 1 and @OrGrade = 1
begin
select @ItemReq =1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end

-----------------------------------------------Graduate----------------------------------------------------

if @AllGraduation = 0 and @OrGraduation = 0   
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(GRADUATE,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='GRADUATE')
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllGraduation = 1 and @OrGraduation = 0
begin
select @ItemReq = 1
set @ORreq= @ORreq | @ItemReq
set @ItemReq = 0 
end
if @AllGraduation = 0 and @OrGraduation = 1
begin
select @ItemReq = case when count(*)>0 then 1 else 0 end from profile where profileid=@ProfileId and isnull(GRADUATE,0) in (select requiredbyvalue from DocRequiredBy where docid=@docid and RequiredByField='GRADUATE')
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
if @AllGraduation = 1 and @OrGraduation = 1
begin
select @ItemReq = 1
set @ANDReq= @ANDReq & @ItemReq
set @ItemReq = 0 
end
------------------------------------------------------------
END 
ELSE
	BEGIN
		SET @ANDReq=0
		SET @ORreq=0
	END
return @ANDReq | @ORreq

END

GO

