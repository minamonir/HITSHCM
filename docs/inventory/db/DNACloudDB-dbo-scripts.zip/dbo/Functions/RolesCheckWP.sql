
CREATE FUNCTION [dbo].[RolesCheckWP] 
	(@RoleId as smallint,@RoleFields as nvarchar(max),@SSGroupField AS NVARCHAR(max),@LogonName AS nvarchar(80),@ItemNo as int) RETURNS NVARCHAR(max)
AS
BEGIN
	DECLARE @Where AS NVARCHAR(max),@UserId as int,@ApplySSGroupRoles as bit
	select @UserId = empid,@ApplySSGroupRoles=ApplySSGroups from nasusers where logonname = @LogonName
	SET @Where=''		

	IF (SELECT SysParam.EnableRoleValidation FROM SysParam ) = 1 and isnull((select enabled from NasOptionsRoleEnabledItems where itemno = @ItemNo ),0) = 1 and @ApplySSGroupRoles=1
	BEGIN
		DECLARE @Roles TABLE (RoleId SMALLINT)
		IF @RoleFields <>''
		BEGIN
			if @RoleId = 0
			begin
				INSERT INTO @Roles SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId=@UserId
			end
			else
			begin
				INSERT INTO @Roles SELECT @RoleId
			end

			DECLARE @RoleIDStr AS NVARCHAR(max)
			SET @RoleIDStr = '#'
			SELECT @RoleIDStr = @RoleIDStr + CAST(RoleId AS NVARCHAR(5))+'#'
			FROM  @Roles
			IF @RoleIDStr <> '#'
			--SET @Where = 'AND(dbo.RolesExist('''+@RoleID+''',''$''+ISNULL('+REPLACE(@RoleFields,',',','''')+''$''+ISNULL(')+','''')+''$'')=1)'
			SET @Where = 'AND(dbo.RolesExist('''+@RoleIDStr+''',''$''+ISNULL('+REPLACE(@RoleFields,',',','''')+''$''+ISNULL(')+','''')+''$'','+@SSGroupField+','+ltrim(@UserId)+')=1)'
		END
	END
RETURN @Where
END

GO

