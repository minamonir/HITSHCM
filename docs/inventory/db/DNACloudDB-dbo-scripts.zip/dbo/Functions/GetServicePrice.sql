
CREATE FUNCTION [dbo].[GetServicePrice] (@SupplierNo as int,@ServiceNo AS INT , @PriceDate AS DATETIME , @Currency INT )   
RETURNS numeric (18,3) AS  
--This fn return Cost of supplier service in given date 


BEGIN 
DECLARE @ReturnCost AS NUMERIC(18,3)
DECLARE @LastServicepricedate AS DATETIME

SELECT top 1 @LastServicepricedate =StartDate FROM SupplierService
WHERE StartDate <= @pricedate  AND  SupplierNo=@SupplierNo AND ServiceNo=@ServiceNo ORDER BY StartDate DESC



SELECT @ReturnCost =  dbo.ConvertAmount(SupplierService.Cost,SupplierService.CostCur,@currency,ISNULL(@LastServicepricedate,@pricedate))
 FROM SupplierService 
WHERE SupplierNo=@SupplierNo AND ServiceNo=@ServiceNo AND StartDate=ISNULL(@LastServicepricedate,@pricedate)

return isnull(@ReturnCost,0)
END

GO

