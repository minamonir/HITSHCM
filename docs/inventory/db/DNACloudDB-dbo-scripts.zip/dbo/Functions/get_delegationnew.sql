--USE [DNACloudDB]
--GO
--/****** Object:  UserDefinedFunction [dbo].[get_delegation]    Script Date: 10/19/2016 9:25:58 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

--calculate the no of vacation days for specific vacation category in a certain period 

CREATE    FUNCTION [dbo].[get_delegationnew] (@requesterprofileid as int , @delegatedprofileid as int , @ssdocno as int,@lang as nchar(1),@DocumentNo AS int=0)
 
RETURNS nvarchar(max)
AS

--DECLARE @requesterprofileid as INT=1 , @delegatedprofileid as INT=404 , @ssdocno as INT=1,@lang as nchar(1)='e',@DocumentNo AS int=5

	BEGIN
	declare @name as nvarchar(max),@aname as nvarchar(max) ,@result as nvarchar(max)

declare @assignmentid as int 
declare @SSDocType as int
DECLARE @GetDate AS SMALLDATETIME,@ssgroup AS int

SELECT @GetDate= HitsGetDate.todate FROM HitsGetDate
SET @GetDate=CONVERT(nchar(10), @GetDate, 111)
SELECT @ssgroup=  ssgroup from empassignment where empid = @requesterprofileid

set @assignmentid = 0
select @SSDocType=SSDocType from ssdocument where SSDocNo = @SSDocNo

if @SSDocType = 6 
select @assignmentid = isnull(assignmentid,0) from empappraisal  where empid = @requesterprofileid and documentno = @DocumentNo

set @result = N' '
IF @assignmentid=0
	BEGIN
		--declare delegation cursor  for 
	SELECT  @result = @result +CASE WHEN @lang='e' 
								    THEN  rtrim(ltrim(employeeid + N' ' + rtrim(Name) + N' : ' + rolename ))
								    ELSE rtrim(ltrim(employeeid+ N' ' + rtrim(aName)  + N'  :  ' + roleaname )) END
							  + nchar(13)+nchar(10)
	FROM  WFDelegate 
	INNER JOIN SSGroupRole ON WFDelegate.RoleId = SSGroupRole.RoleId AND WFDelegate.ProfileId = SSGroupRole.ProfileId 
	inner join profile on WFDelegate.ProfileId = profile.profileid 
	inner join empassignment on profile.profileid = empassignment.empid
	inner join ssrole on ssrole.roleid = WFDelegate.RoleId 	  	
	WHERE  WFDelegate.DelegatedProfileId =  @delegatedprofileid 
	   AND WFDelegate.ssdocno = @ssdocno 
	   AND SSGroupRole.SSGroup = @ssgroup 
	   AND (@GetDate BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo)
	   AND WFDelegate.ApprovalStatus = 1
	END
ELSE
	BEGIN
		--declare delegation cursor  for 
	SELECT  @result = @result + CASE WHEN @lang='e' 
									 THEN  rtrim(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(Name) COLLATE database_default + N' : ' + rolename COLLATE database_default ))
									 ELSE rtrim(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(aName) COLLATE database_default + N'  :  ' + roleaname COLLATE database_default )) END
							  + nchar(13)+nchar(10)
	FROM WFDelegate 
	INNER JOIN SSGroupRole ON WFDelegate.RoleId = SSGroupRole.RoleId AND WFDelegate.ProfileId = SSGroupRole.ProfileId 
	INNER JOIN SSDocument ON WFDelegate.SSDocNo = SSDocument.SSDocNo	
	INNER join profile on WFDelegate.ProfileId = profile.profileid 	
	INNER join empassignment on profile.profileid = empassignment.empid	
	INNER join ssrole on ssrole.roleid = WFDelegate.RoleId 
	WHERE WFDelegate.DelegatedProfileId = @delegatedprofileid
	  AND WFDelegate.ssdocno = @ssdocno
	  AND SSGroupRole.SSGroup = ( SELECT  ssgroup FROM Appassignment WHERE empid = @requesterprofileid AND Appassignment.AssignmentId=@assignmentid)
	  AND (CONVERT(nchar(10), @GetDate, 111) BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo)
	  AND WFDelegate.ApprovalStatus = 1
	END


--OPEN delegation

--FETCH NEXT FROM delegation 
--INTO  @name,@aname

--WHILE @@FETCH_STATUS = 0
--BEGIN
--if @lang= N'E'
--set @result = @result + @name+nchar(13)+nchar(10)
--else
--set @result = @result + @aname+nchar(13)+nchar(10)

  -- FETCH NEXT FROM delegation 
  -- INTO  @name,@aname
--END

--CLOSE delegation
--DEALLOCATE delegation

return substring(@result,2,4000)

--SELECT substring(@result,2,4000)

end

GO

