CREATE      FUNCTION [dbo].[HITS_CalcVarIns]
  (@empid int, @year int)
	
RETURNS numeric(18,3)
AS
 BEGIN
 declare @VarAmount numeric(18,3), @Months as smallint
 set @Months=0
set @VarAmount=0
if @year=0  select @Months=1,  @VarAmount= sum(case when paycode.ssvarappl=1 and paycode.type<>3 then
  ((case when paycode.type=1 then 1  else  -1 end) *(case when paycode.inputtp=1 then hrpcodes.inputamnt else 
  dbo.ConvertAmount(dbo.CalcPaycode(hrpcodes.empid, hrpcodes.paycode, hrpcodes.inputamnt,0),payrollgroup.Currency,EmpAssignment.HrCurrency,dbo.periodend(Payrollgroup.payrollgroup,Payrollgroup.cmonth,Payrollgroup.cyear)) end)) else 0.00 end) 
  from hrpcodes 
  INNER join paycode on hrpcodes.paycode=paycode.code
  INNER JOIN EmpAssignment ON EmpAssignment.EmpId = HrPCodes.empid
  INNER JOIN PayrollGroup ON EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
  where hrpcodes.empid=@empid  group by hrpcodes.empid
else   select @Months=count(distinct historytransaction.month),
	 @VarAmount= sum(case when paycode.ssvarappl=1 and paycode.type<>3 then
	(case when paycode.type=1 then 1 else  -1 end) * 
	dbo.ConvertAmount(historytransaction.Amount,HistoryPayroll.PayrollCurrency,EmpAssignment.HrCurrency,dbo.periodend(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year))
	 else 0.00 end) 
	from historytransaction 
	INNER JOIN EmpAssignment ON EmpAssignment.EmpId = historytransaction.empid
	INNER JOIN HistoryPayroll ON HistoryPayroll.Year = HistoryTransaction.Year 
	AND HistoryPayroll.Month = HistoryTransaction.Month 
	AND HistoryPayroll.EmpId = HistoryTransaction.EmpId 
	AND HistoryPayroll.RunNo = HistoryTransaction.RunNo
	INNER join paycode on historytransaction.paycode=paycode.code
    where historytransaction.empid=@empid and historytransaction.year=@year group by historytransaction.empid
  set @VarAmount=case when @Months=0 then 0.00 else @VarAmount/ @Months end

return @VarAmount

END

GO

