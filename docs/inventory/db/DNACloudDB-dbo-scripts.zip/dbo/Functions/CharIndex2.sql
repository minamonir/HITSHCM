
CREATE FUNCTION [dbo].[CharIndex2]
(
@TargetStr nvarchar(max), 
@SearchedStr nvarchar(max), 
@Occurrence int
)
 
RETURNS int
 
as
begin
 
 
--declare @TargetStr varchar(8000)='-', 
--@SearchedStr varchar(8000)='113101-111--222-444-55', 
--@Occurrence int=2
 
 --if 
 declare @NumberofOccurTargetStr as int
 SELECT @NumberofOccurTargetStr=LEN(@SearchedStr) - LEN(REPLACE(@SearchedStr, @TargetStr, '')) 
 
 --select @NumberofOccurTargetStr as '@NumberofOccurTargetStr'

 --select @Occurrence=@Occurrence-1

 if @Occurrence <= @NumberofOccurTargetStr and @Occurrence>0
 begin
declare @pos int, @counter int, @ret int
 
set @pos = CHARINDEX(@TargetStr, @SearchedStr)
set @counter = 1
 
if @Occurrence = 1 set @ret = @pos
 
else
begin
 
while (@counter < @Occurrence)
begin
 
select @ret = CHARINDEX(@TargetStr, @SearchedStr, @pos + 1)
 
set @counter = @counter + 1
 
set @pos = @ret
 
end
 
end
 
 end
 else
 begin
 select @ret=0
 end
--select @ret

--select STUFF(@SearchedStr, @ret,1, '-'+'xyz')

RETURN(@ret)
 
end
--113101---xyz--

GO

