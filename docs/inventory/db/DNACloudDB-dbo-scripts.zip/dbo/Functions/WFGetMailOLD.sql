create  FUNCTION [dbo].[WFGetMailOLD] (@RoleProfileid  as INT,@Empid  as int, @documentno AS INT,@SSDocNo as INT, @action as INT
,@SSNewStatus as int  ,@ActionResaon as Nvarchar(max) ,
@ProfileID as int , @EMailAction as INT,
  @Latinlang as nchar(1),@SMSorMail AS int)
	RETURNS    NVARCHAR(max)

AS
BEGIN
declare @propname as nvarchar(150) 
select @propname=propname  from SysParam

	--@SMSorMail=0  --> for sms , @SMSorMail=1 --> for mail 
declare @English as nchar(1)='E',@Foreign AS NCHAR(1)='F',@Switchlang AS NCHAR(1)
-- for Merck turkey use  SELECT @English='F' , @Foreign='E'
SELECT @English=SysParamConfig.ConfigValue  FROM SysParamConfig WHERE SysParamConfig.ConfigID='WFenglishlang'
SELECT @Foreign=SysParamConfig.ConfigValue  FROM SysParamConfig WHERE SysParamConfig.ConfigID='WFforiegnlang'
SELECT @Switchlang =case WHEN @Latinlang ='F' THEN (CASE WHEN @Foreign='E' THEN 'E' ELSE 'F' END )
                         WHEN @Latinlang ='E'  THEN (CASE WHEN @English='E' THEN 'E' ELSE 'F' END )
                         ELSE  'A' END
-----------------------------------------------------------------
declare @SSDocType as int,@BG_NAME AS NVARCHAR(max),@sswebsite as nvarchar(250)
select @SSDocType=SSDocType from ssdocument where SSDocNo = @SSDocNo 
SELECT @BG_NAME = ISNULL(ConfigValue,'') FROM dbo.SysParamConfig WHERE ConfigID='WorkflowApprovalRedirectBG'

IF @BG_NAME <> ''
BEGIN
	DECLARE @adal AS BIT 
	,@url_ltr AS NVARCHAR(max)='logon.aspx?ReturnUrl=NasAgenda%2fAgendaPageGeneral.aspx%3fnodeselected%3d%26nodepage%3d26102%26navbar%3d10002%26iconitemno%3d26102%26ssdoctype%3d'
	,@url_rtl AS NVARCHAR(max)='logon_ar.aspx?ReturnUrl=NasAgenda%2fAgendaPageGeneral_ar.aspx%3fnodeselected%3d%26nodepage%3d26102%26navbar%3d10002%26iconitemno%3d26102%26ssdoctype%3d'
	SELECT TOP 1 @adal= ISNULL(WindowsOnly,0) FROM dbo.NasUsers WHERE EmpId=@ProfileID
	select @sswebsite ='<a href="'+CASE WHEN RIGHT(sswebsite,1) = '/' THEN  sswebsite ELSE sswebsite +'/' END +CASE WHEN @Latinlang='A' THEN @url_rtl ELSE @url_ltr END+LTRIM(@SSDocType)+CASE WHEN @adal=1 THEN '&adal=1&tenantid=' ELSE '&tenantid=' END +@BG_NAME+'' +'">'+sswebsite+'</a>'
	from SysParam
END
ELSE
BEGIN
	select @sswebsite =sswebsite from SysParam
END 

declare @assignmentid as int 
select @assignmentid = 0

if @SSDocType = 6 
BEGIN
	select @assignmentid = isnull(assignmentid,0)  from empappraisal  where empid = @empid and documentno = @DocumentNo
	
END
DECLARE @ID NVARCHAR(50)
SELECT @ID = ISNULL((SELECT EmployeeId FROM EmpAssignment WHERE EmpId=@Empid),@Empid)



  

  declare @body as Nvarchar(max), @Tempbody as Nvarchar(max) , @TempMsg AS NVARCHAR (MAX),@SMSbody as nvarchar(max),@EMailbody as nvarchar(max)
 declare @TempbodySMS as Nvarchar(max),@TempBodyMail AS NVARCHAR(max)
 SELECT  @Tempbody='',@TempbodySMS='' ,@TempBodyMail =''
	 DECLARE @Msg2 AS nvarchar(max),@Msg3 AS nvarchar(max),@Msg4 AS nvarchar(max),@Msg5 AS nvarchar(max)
	 ,@Msg8 AS nvarchar(max),@ModuleMsg1 AS nvarchar(max),@ModuleMsg2 AS nvarchar(max),
	 @ModuleMsg3 AS nvarchar(max),@ModuleMsg4 AS nvarchar(max) ,@ModuleMsg5 AS nvarchar(max), @msg9 AS NVARCHAR(MAX) , @msg10  AS NVARCHAR(MAX)
	 ,@msg11  AS NVARCHAR(MAX), @msg12  AS NVARCHAR(MAX) , @msg13  AS NVARCHAR(MAX),  @msg14  AS NVARCHAR(MAX) , @msg15  AS NVARCHAR(MAX)
	 ,@msg16  AS NVARCHAR(MAX),  @msg17  AS NVARCHAR(MAX) , @msg18  AS NVARCHAR(MAX) ,@msg19  AS NVARCHAR(MAX),  @msg20  AS NVARCHAR(MAX) , @msg21  AS NVARCHAR(MAX)
	 , @msg22  AS NVARCHAR(MAX) ,@SeparatorEnter AS NVARCHAR(max),@SeparatorEnter2 AS NVARCHAR(max)
	 ,@MsgH AS nvarchar(max) ,@MsgSeparator AS NVARCHAR(MAX)
	 ,@ModuleMsg12 AS nvarchar(max),@TempMsgRole AS NVARCHAR(max),@TempMsgAction AS NVARCHAR(max)
	 ,@Recipient AS NVARCHAR(MAX) ,@days AS NVARCHAR(max),@MsgF AS nvarchar(max),@Msg6 AS nvarchar(max),@Msg7 AS nvarchar(max)
	 
	 SELECT @MsgSeparator=rtrim(ltrim(isnull(dbo.Hits_GetDCCaption('WFAction','separator',@latinlang),':')))    
	 ,@MsgH= isnull(dbo.Hits_GetDCCaption('WFAction','Header',@latinlang),'')
	 ,@MsgF=isnull(dbo.Hits_GetDCCaption('WFAction','Footer',@latinlang),'')
	 ,@Recipient=''
	 
	 SELECT  @Msg2= isnull(dbo.Hits_GetDCCaption('WFAction','2',@latinlang),(case when @latinlang='E' then 'request for employee'+@MsgSeparator else N'للموظف '+@MsgSeparator end))                          
	 , @Msg3= isnull(dbo.Hits_GetDCCaption('WFAction','3',@latinlang),(case when @latinlang='E' then 'has been approved by'+@MsgSeparator else N'قد تم الموافقة عليها بواسطة '+@MsgSeparator end))                          
	 , @Msg4= isnull(dbo.Hits_GetDCCaption('WFAction','4',@latinlang),(case when @latinlang='E' then 'has been rejected by'+@MsgSeparator else N'قد تم رفضها بواسطة '+@MsgSeparator end))                          
	 , @Msg5= isnull(dbo.Hits_GetDCCaption('WFAction','5',@latinlang),(case when @latinlang='E' then 'has been changed by'+@MsgSeparator else N'قد تم تغييرها بواسطة '+@MsgSeparator end))                          
	 SELECT @Msg6=  (SELECT  LookupSelect FROM DataDictionary  WHERE TableName = 'WFAction' AND FieldName='6')
     SELECT @Msg7=  (SELECT  LookupSelect FROM DataDictionary  WHERE TableName = 'WFAction' AND FieldName='7')                     
     SELECT @Msg8= isnull(dbo.Hits_GetDCCaption('WFAction','8',@latinlang),(case when @latinlang='E' then 'The reason is '+@MsgSeparator else N'السبب هو '+@MsgSeparator end))
     , @msg9 = ''
		 ,@SeparatorEnter=isnull(dbo.Hits_GetDCCaption('WFAction','SeparatorEnter' ,@latinlang),'<br>')
        ,@SeparatorEnter2=isnull(dbo.Hits_GetDCCaption('WFAction','SeparatorEnter2',@latinlang),'')  --enter for merck
        ,@days = isnull(dbo.Hits_GetDCCaption('WFAction','Days',@latinlang),(case when @latinlang='e' then 'Days' else N'ايام' end))
      
	
    SELECT @Msg6=CASE WHEN isnull(ltrim(rtrim(@Msg6)),'')=''  THEN (select dbo.Hits_GetDCCaption('WFAction','6',@latinlang))  ELSE ltrim(rtrim(@Msg6)) END 
    SELECT @Msg6= CASE WHEN isnull(ltrim(rtrim(@Msg6)),'')='' then (case when @latinlang='E' then 'Waiting for your action' else N'فى انتظار موافقتك على هذا الطلب' END) ELSE ltrim(rtrim(@Msg6)) END                           	   
    --  SELECT @Msg7=CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')=''  THEN (select dbo.Hits_GetDCCaption('WFAction','7',@latinlang) )  ELSE ltrim(rtrim(@Msg7)) END 
	--SELECT  @Msg7= CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')='' then (case when @latinlang='E' then 'Please visit the following site to check this request' else N'برجاء زيارة هذا الموقع لمراجعة هذا الطلب' end) ELSE ltrim(rtrim(@Msg7)) END                           	   
	 
    SELECT @Msg7=CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')=''  THEN ( dbo.Hits_GetDCCaption('WFAction','7',@latinlang)+' '+ CASE WHEN isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('WFAction','7',@latinlang))),'')<>'' AND @SSDocType<>20 THEN  ltrim(rtrim(@sswebsite)) ELSE '' end  )  ELSE ltrim(rtrim(@Msg7)) END 
    SELECT @Msg7= CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')='' then (case when @latinlang='E' then 'Please visit the following site to check this request'+' '+ ltrim(rtrim(@sswebsite)) else N'برجاء زيارة هذا الموقع لمراجعة هذا الطلب' +' '+ CASE WHEN @SSDocType<>20 THEN  ltrim(rtrim(@sswebsite))ELSE '' END  end) ELSE ltrim(rtrim(@Msg7)) END                           	   


	--SELECT @subject =''
 --   SELECT @subject = (select LookupSelect FROM DataDictionary  WHERE TableName LIKE '%WFActionSubject%' AND FieldName=ltrim(@SSDocType))
 --   SELECT @subject = REPLACE (@subject , '@latinlang', ''''+@latinlang+'''' )  
 --   SELECT @subject = REPLACE (@subject , '@Empid',  @Empid  ) 
 --   SELECT @subject = REPLACE (@subject , '@documentno',  @documentno )
    --
    --declare @TempSubject TABLE ([Subject] NVARCHAR(MAX))
    --INSERT INTO @TempSubject
    --EXEC(@subject)
    --SELECT @subject=SUBJECT FROM @TempSubject
    
    
    --
--    DECLARE @sql AS NVARCHAR(MAX),@cmd AS NVARCHAR(MAX)
--    SELECT @sql = '    CREATE TABLE #Subject( [Subject] NVARCHAR(MAX))
--    INSERT INTO #Subject 
--    EXEC(@subject)
--    SELECT @subject=SUBJECT FROM #Subject
--	DROP TABLE #Subject '
--SELECT @cmd = 'sqlcmd -S ' + @@servername +
--              ' -d ' + db_name() + ' -Q "' + @sql + '"'
--EXEC master..xp_cmdshell @cmd, 'no_output'


    --
 --   CREATE TABLE #Subject( [Subject] NVARCHAR(MAX))
 --   INSERT INTO #Subject 
 --   EXEC(@subject)
 --   SELECT @subject=SUBJECT FROM #Subject
	--DROP TABLE #Subject
	
	
	--DECLARE @str AS NVARCHAR(max)
	--SET @str = '
	--    CREATE TABLE #Subject( [Subject] NVARCHAR(MAX))
 --   INSERT INTO #Subject 
 --   EXEC('+ltrim(@subject)+')
 --   SELECT @subject=SUBJECT FROM #Subject
	--DROP TABLE #Subject
 --  '


 --  EXECUTE sys.sp_executesql @str,N' @subject as nvarchar(max) output', @subject OUTPUT

  if @SSDocType=3 --vacation
  BEGIN
  	
  	 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Vacation',@latinlang),(case when @latinlang='E' then 'Vacation' else N'اجازة' end))                                 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','VacationFromDate',@latinlang),(case when @latinlang='E' then 'From Date' else N'من' end))                                 
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','VacationToDate',@latinlang),(case when @latinlang='E' then 'To Date' else N'إلى' end))                                 
  	        ,@ModuleMsg12=isnull(dbo.Hits_GetDCCaption('WFAction','Vacation2',@latinlang),(case when @latinlang='E' then 'Vacation' else N'اجازة' end))

  	        -- for customer "merck"
  	        , @msg9 =isnull(dbo.Hits_GetDCCaption('WFAction','Dear',@latinlang),'')
  	        , @msg10=ISNULL(dbo.Hits_GetDCCaption('WFAction','Message1',@latinlang),'')  
	        , @msg11= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message2',@latinlang),'')
	        , @msg12 =ISNULL(dbo.Hits_GetDCCaption('WFAction','Message3',@latinlang),'')
	        , @msg13= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message4',@latinlang),'')
	        , @msg14 =ISNULL(dbo.Hits_GetDCCaption('WFAction','KindRegards',@latinlang),'')
	        , @msg15= ISNULL(dbo.Hits_GetDCCaption('WFAction','TheMEHRteam',@latinlang),'')
	       
	       SELECT @msg16 =replace(LookupSelect,'@@syswebsite',@sswebsite) FROM DataDictionary WHERE TableName ='WFAction' AND FieldName ='Message7'
	        --, @msg16 =isnull(dbo.Hits_GetDCCaption('WFAction','Message7',@latinlang),'')
  	      --  , @msg17=ISNULL(dbo.Hits_GetDCCaption('WFAction','Message8',@latinlang),'')  
	        --, @msg18= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message9',@latinlang),'')
	        --, @msg19 =ISNULL(dbo.Hits_GetDCCaption('WFAction','Message10',@latinlang),'')
	        --, @msg20= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message11',@latinlang),'')
	        --, @msg21 =ISNULL(dbo.Hits_GetDCCaption('WFAction','Message12',@latinlang),'')
	        --, @msg22= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message13',@latinlang),'')
	        
	        
	if isnull(ltrim(rtrim(@propname)),'')='Delta Marketing Co'
	begin		
		select @body=ltrim(RTRIM(@MsgH))+' '
		+CASE WHEN @latinlang='A' THEN ltrim(rtrim(vacation.vacationaname)) ELSE ltrim(rtrim(vacation.vacationname)) END 
		+' '+RTRIM(@Msg2)+' '
		+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END 
		+' '+LTRIM(EmpAssignment.EmployeeId)+nchar(13)+nchar(10)
		+rtrim(@ModuleMsg2)+' '+CONVERT(nchar(11), empvacat.FromDate,CASE WHEN @Latinlang='A' THEN 103 ELSE 100 end)
		+' '+rtrim(@ModuleMsg3)+' '+CONVERT(nchar(11), empvacat.ToDate, CASE WHEN @Latinlang='A' THEN 103 ELSE 100 end)
		from profile inner join empvacat on profile.profileid=empvacat.empid 
		inner join vacation on vacation.vaccode=empvacat.vaccode 
		INNER JOIN EmpAssignment ON EmpAssignment.EmpId = Profile.ProfileId
		where profileid = @Empid and empvacat.documentno=@documentno

	END 
	else 
	begin
		
		select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +
		rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
		CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(vacation.vacationaname )) WHEN @Switchlang='F' THEN  ltrim(rtrim(vacation.vacationFname )) ELSE  ltrim(rtrim(vacation.vacationname))  END +
		CASE WHEN @msg9 ='' THEN ' ' ELSE   CHAR(13)+CHAR(10) END +rtrim(@ModuleMsg2)+' '+
		CASE WHEN @Latinlang='A' THEN CONVERT(char(11), empvacat.FromDate,103) ELSE LTRIM(RTRIM(DAY(empvacat.FromDate)))+' '+
		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.FromDate),@Latinlang))),left(DATENAME(month,empvacat.FromDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.FromDate)))
		end +' '+rtrim(@ModuleMsg3)+' '+
		CASE WHEN @Latinlang='A' THEN CONVERT(char(11), empvacat.ToDate,103) ELSE LTRIM(RTRIM(DAY(empvacat.ToDate)))+' '+
		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.ToDate),@Latinlang))),left(DATENAME(month,empvacat.ToDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.ToDate)))
		end
		+  LTRIM('('+RTRIM(CAST(dbo.VacTakenDays(dbo.EmpVacat.EmpId, dbo.EmpVacat.FromDate, dbo.EmpVacat.ToDate, dbo.EmpVacat.VacCode, dbo.EmpVacat.DocumentNo, dbo.EmpVacat.PartDayFrom, 
		dbo.EmpVacat.PartDayTo)AS FLOAT))+' ' +@days+')')
		from profile inner join empvacat on profile.profileid=empvacat.empid 
		inner join vacation on vacation.vaccode=empvacat.vaccode 
		where profileid = @Empid and empvacat.documentno=@documentno
		
    END
	IF  @msg9 ='' -- condition to check customer is not "merck" 
	BEGIN
      
		SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
		,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       
		SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN @tempMsgRole +replace(@TempMsgAction,'@RoleName','') ELSE  @TempMsgAction + @tempMsgRole END
	END 
  end

if  @SSDocType   = 1 -- change of status 
  BEGIN
  	  	 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','ChangeofStatus',@latinlang),(case when @latinlang='E' then 'change of status' else N'تغير الحالة' end))                                 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','Changeofstatusdate',@latinlang),(case when @latinlang='E' then 'As Of Date' else N'بتاريخ' end))                                 
  			,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','ChangeofStatus2',@latinlang),(case when @latinlang='E' then 'Change of status' else N'تغير الحالة' end))
  			
  
		
     DECLARE @ChangeStatusDetails AS SMALLINT=0,@DetailsStmt as nvarchar(max)='', @enablerolevalidation as bit
	 SELECT  @ChangeStatusDetails=isnull(ConfigValue,'0') FROM dbo.SysParamConfig  WHERE ConfigID=LTRIM(RTRIM('ChangeOfStatusNotificationDetails'))

    IF ISNULL(ltrim(rtrim(@propname)),'')='Delta Marketing Co'
	  BEGIN	  
	             DECLARE  @ChangeFields table(fieldname nvarchar(60), OldValue nvarchar(60),NewValue nvarchar(60))
            IF  @ProfileID=@Empid
             BEGIN  
                   --PRINT 'emp'
				   			 DELETE FROM @ChangeFields
                  INSERT into @ChangeFields
				 SELECT case when empstatusdtl.fieldno >1000  then 
					CASE when @Latinlang='e' then Paycodename else paycodeaname end 
					ELSE   case when @Latinlang='E' then chgfield.edesc else chgfield.adesc end 
					END 
					, case when isnull(chngstatfields.hideoldvalue,0)=0 
					THEN dbo.getoldvaluetxt(empstatusdtl.fieldno,dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency),@Latinlang) else '' end 
				,case when isnull(chngstatfields.acceptnewvalue,1)=1 then dbo.getoldvaluetxt(empstatusdtl.fieldno,NewValue,@Latinlang) else '' end  
				  from empstatushdr
				  left join empstatusdtl on empstatushdr.empid =empstatusdtl.empid and empstatushdr.documentno=empstatusdtl.documentno
				  left join chngstatfields on chngstatfields.chgcode= empstatushdr.chgcode and chngstatfields.fieldno=empstatusdtl.fieldno
				  left join empassignment on empassignment.empid=empstatushdr.empid
				  left join nasarrays chgfield on chgfield.itemno=empstatusdtl.fieldno and chgfield.arrayname='chngstatus'
				  left join Paycode on Paycode.code=empstatusdtl.fieldno-1000 and empstatusdtl.fieldno>1000	  
				  where empstatushdr.empid =@Empid and empstatushdr.documentno=@documentno
				  and not (isnull(chngstatfields.hideoldvalue,0)=1 and isnull(chngstatfields.acceptnewvalue,1)=0)
	              DELETE from @ChangeFields where oldvalue='' and newvalue=''
              END
             ELSE  	  
              BEGIN  

	  select @enablerolevalidation=sysparam.enablerolevalidation from sysparam
	  declare @roles as nvarchar(max)='#'
	  DECLARE @RolesT TABLE (RoleId SMALLINT)
		INSERT INTO @RolesT SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId=@ProfileID 
		SELECT @roles = @roles + ltrim(RoleId)+'#'
		FROM  @RolesT

	  --declare @roles as nvarchar(max)=''
	  --select @roles =@roles+'#'+ltrim(rtrim(str(roleid)))
	  --from ssgrouprole
	  ----inner join empassignment on empassignment.ssgroup=ssgrouprole.ssgroup 
	  --where profileid= @ProfileID --and empassignment.empid=@empid
	  ----SELECT @roles
	  --select @roles =@roles+'#'   

       INSERT into @ChangeFields
	     SELECT case when empstatusdtl.fieldno >1000  then 
	        CASE when @latinlang='e' then Paycodename else paycodeaname end 
	        ELSE   case when @Latinlang='E' then chgfield.edesc else chgfield.adesc end 
			END 
			, case when isnull(chngstatfields.hideoldvalue,0)=0 and (
			 (@enablerolevalidation=1 and dbo.rolesexist(@roles,'$'+ISNULL(case when empstatusdtl.fieldno=1 then OldHrStatus.HrStatusRoles 
			                                when empstatusdtl.fieldno=5 then OldJob.JobsRoles 
											when empstatusdtl.fieldno=6 then OldOrganization.OrganizationRoles
											when empstatusdtl.fieldno=7 then OldGrade.GradesRoles
											when empstatusdtl.fieldno=8 then OldPosition.PositionsRoles
											when empstatusdtl.fieldno=9 then OldLocation.LocationRoles
											when empstatusdtl.fieldno=10 then OldEmployer.EmployerRoles
											when empstatusdtl.fieldno=19 then OldVacPack.VacPackRoles
											when empstatusdtl.fieldno=22 then OldSalaryScale.SalaryScalesRoles
											when empstatusdtl.fieldno=23 then OldContractType.ContractTypeRoles
											when empstatusdtl.fieldno=28 then OldTimeRule.TimeRulesRoles
											when empstatusdtl.fieldno>1000 then Paycode.PaycodeRoles
											else ''
											end ,'')+'$',0,0)=1) or @enablerolevalidation=0 ) then dbo.getoldvaluetxt(empstatusdtl.fieldno,dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency),@Latinlang) else '' end 
	    ,case when isnull(chngstatfields.acceptnewvalue,1)=1 and (
		(@enablerolevalidation=1 and dbo.rolesexist(@roles,'$'+ISNULL(case when empstatusdtl.fieldno=1 then NewHrStatus.HrStatusRoles 
			                                when empstatusdtl.fieldno=5 then NewJob.JobsRoles 
											when empstatusdtl.fieldno=6 then NewOrganization.OrganizationRoles
											when empstatusdtl.fieldno=7 then NewGrade.GradesRoles
											when empstatusdtl.fieldno=8 then NewPosition.PositionsRoles
											when empstatusdtl.fieldno=9 then NewLocation.LocationRoles
											when empstatusdtl.fieldno=10 then NewEmployer.EmployerRoles
											when empstatusdtl.fieldno=19 then NewVacPack.VacPackRoles
											when empstatusdtl.fieldno=22 then NewSalaryScale.SalaryScalesRoles
											when empstatusdtl.fieldno=23 then NewContractType.ContractTypeRoles
											when empstatusdtl.fieldno=28 then NewTimeRule.TimeRulesRoles
											when empstatusdtl.fieldno>1000 then Paycode.PaycodeRoles
											else ''
											end ,'')+'$',0,0)=1) or @enablerolevalidation=0 ) then dbo.getoldvaluetxt(empstatusdtl.fieldno,NewValue,@Latinlang) else '' end  
	  from empstatushdr
	  left join empstatusdtl on empstatushdr.empid =empstatusdtl.empid and empstatushdr.documentno=empstatusdtl.documentno
	  left join chngstatfields on chngstatfields.chgcode= empstatushdr.chgcode and chngstatfields.fieldno=empstatusdtl.fieldno
	  left join empassignment on empassignment.empid=empstatushdr.empid
	  left join nasarrays chgfield on chgfield.itemno=empstatusdtl.fieldno and chgfield.arrayname='chngstatus'
	  left join Paycode on Paycode.code=empstatusdtl.fieldno-1000 and empstatusdtl.fieldno>1000
	  left join hrstatus NewHrStatus on NewHrStatus.hrstatus=empstatusdtl.newvalue and empstatusdtl.fieldno=1 
	  left join hrstatus oldHrStatus on oldHrStatus.hrstatus=case when empstatusdtl.fieldno=1 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=1 
	  left join Jobs NewJob on NewJob.Job=empstatusdtl.newvalue and empstatusdtl.fieldno=5 
	  left join Jobs oldJob on oldJob.Job=case when empstatusdtl.fieldno=5 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end  and empstatusdtl.fieldno=5 
	  left join Organization NewOrganization on NewOrganization.Organization=empstatusdtl.newvalue and empstatusdtl.fieldno=6 
	  left join Organization oldOrganization on oldOrganization.Organization= case when empstatusdtl.fieldno=6 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end and empstatusdtl.fieldno=6 
	  left join Grades NewGrade on NewGrade.Grade=empstatusdtl.newvalue and empstatusdtl.fieldno=7 
	  left join Grades oldGrade on oldGrade.Grade=case when empstatusdtl.fieldno=7 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end and empstatusdtl.fieldno=7 
	  left join Positions NewPosition on NewPosition.positionno=empstatusdtl.newvalue and empstatusdtl.fieldno=8 
	  left join Positions oldPosition on oldPosition.positionno=case when empstatusdtl.fieldno=8 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=8 
	  left join Location NewLocation  on  NewLocation.Locationno=empstatusdtl.newvalue and empstatusdtl.fieldno=9 
	  left join Location oldLocation on oldLocation.Locationno=case when empstatusdtl.fieldno=9 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end  and empstatusdtl.fieldno=9 
	  left join Employer NewEmployer  on  NewEmployer.EmployerId=empstatusdtl.newvalue and empstatusdtl.fieldno=10 
	  left join Employer oldEmployer on oldEmployer.EmployerId=case when empstatusdtl.fieldno=10 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=10 
	  left join VacPack NewVacPack  on  NewVacPack.VacPack=empstatusdtl.newvalue and empstatusdtl.fieldno=19 
	  left join VacPack oldVacPack on oldVacPack.VacPack=case when empstatusdtl.fieldno=22 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end and empstatusdtl.fieldno=19 
	  left join SalaryScales NewSalaryScale  on  NewSalaryScale.SalaryScaleId=empstatusdtl.newvalue and empstatusdtl.fieldno=22 
	  left join SalaryScales oldSalaryScale on oldSalaryScale.SalaryScaleId= case when empstatusdtl.fieldno=22 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end  and empstatusdtl.fieldno=22 
	  left join ContractType NewContractType on  NewContractType.ContractType=case when empstatusdtl.fieldno=23 and @enablerolevalidation=1 then empstatusdtl.newvalue else 0 end  and empstatusdtl.fieldno=23 
	  left join ContractType oldContractType on oldContractType.ContractType=dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) and empstatusdtl.fieldno=23 
	  left join TimeRules NewTimeRule on  NewTimeRule.TimeRule=empstatusdtl.newvalue and empstatusdtl.fieldno=28 
	  left join TimeRules oldTimeRule on oldTimeRule.TimeRule= case when empstatusdtl.fieldno=28 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=28 
	  
	  where empstatushdr.empid =@Empid and empstatushdr.documentno=@documentno
	  and not (isnull(chngstatfields.hideoldvalue,0)=1 and isnull(chngstatfields.acceptnewvalue,1)=0)
       --SELECT *FROM @ChangeFields       
	   DELETE from @ChangeFields where oldvalue='' and newvalue=''
	   END 
	  select @DetailsStmt=ISNULL(@DetailsStmt,'')+' '+ltrim(rtrim(ISNULL([@ChangeFields].fieldname,'')))+' '+ case when ltrim(rtrim(ISNULL([@ChangeFields].oldvalue,''))) <>'' then isnull(dbo.Hits_GetDCCaption('WFAction','OldValue',@latinlang)  ,case when @latinlang='e' then 'OldValue' else N'القيمة القديمة' end )+':' else '' end +ltrim(rtrim(ISNULL([@ChangeFields].oldvalue,'')))
	  +case when ltrim(rtrim(ISNULL([@ChangeFields].oldvalue,''))) <>''  AND  ltrim(rtrim(ISNULL([@ChangeFields].newvalue,''))) <>''THEN ' , ' ELSE '' END + case when ltrim(rtrim(ISNULL([@ChangeFields].newvalue,''))) <>'' then isnull(dbo.Hits_GetDCCaption('WFAction','NewValue',@latinlang)  ,case when @latinlang='e' then 'NewValue' else N'القيمة الجديدة' end )+':' else '' end +ltrim(rtrim(ISNULL([@ChangeFields].Newvalue,''))) +@SeparatorEnter
	  from @ChangeFields

	   SELECT @DetailsStmt='('+substring(@DetailsStmt,1,len(@DetailsStmt))+')'
       --DROP table [@ChangeFields]
	   END

	   SELECT @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+ CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) end+
		 CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
		 CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(ChngStat.ChgAname )) WHEN @Switchlang='F' THEN  ltrim(rtrim(ChngStat.ChgFname )) ELSE  ltrim(rtrim(ChngStat.Chgname))  END 
		 +' '+ISNULL(@DetailsStmt,'')+' '+
		 ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 		CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpStatusHdr.EffectiveDate,103) ELSE LTRIM(RTRIM(DAY(EmpStatusHdr.EffectiveDate)))+' '+
		    ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpStatusHdr.EffectiveDate),@Latinlang))),left(DATENAME(month,EmpStatusHdr.EffectiveDate),3))+' '+LTRIM(RTRIM(YEAR(EmpStatusHdr.EffectiveDate))) end
		FROM  EmpStatusHdr
		INNER JOIN ChngStat ON EmpStatusHdr.ChgCode = ChngStat.chgcode 
		INNER JOIN Profile ON EmpStatusHdr.EmpId = Profile.ProfileId
		   where profileid = @Empid and EmpStatusHdr.documentno=@documentno
    select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then  ' '+rtrim(@Msg5)+' 'END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid 
  end


if  @SSDocType   = 7 -- Benefit
BEGIN
	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Benefit',@latinlang),(case when @latinlang='E' then 'Benefit' else N'خطة المزايا' end))    
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','BenefitEnrollDate',@latinlang),(case when @latinlang='E' then 'Enroll Date' else N'تاريخ التقديم' end))    
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','BenefitOption',@latinlang),(case when @latinlang='E' then 'Option' else N'الإختيار' end))    
  	       ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Benefit2',@latinlang),(case when @latinlang='E' then 'Benefit' else N'خطة المزايا' end))
  	
  	
		 
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +
     rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
    CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(BenefitPlans.PlanaName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(BenefitPlans.PlanFName )) ELSE  ltrim(rtrim(BenefitPlans.PlanName))  END +
     ' '+rtrim(@ModuleMsg2)+' '+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpBenefit.EnrollDate,103) ELSE LTRIM(RTRIM(DAY(EmpBenefit.EnrollDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.EnrollDate),@Latinlang))),left(DATENAME(month,EmpBenefit.EnrollDate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.EnrollDate)))
	   end
     +isnull('-'+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpBenefit.enddate,103) ELSE LTRIM(RTRIM(DAY(EmpBenefit.enddate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.enddate),@Latinlang))),left(DATENAME(month,EmpBenefit.enddate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.enddate)))
	   end
     ,'') +' '+rtrim(@ModuleMsg3)+' '+rtrim(ltrim(@MsgSeparator))+' '+
    CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(BenefitOptions.OptionAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(BenefitOptions.OptionFName )) ELSE  ltrim(rtrim(BenefitOptions.OptionName))  END 
	FROM         EmpBenefit INNER JOIN
                      BenefitPlans ON EmpBenefit.PlanNo = BenefitPlans.PlanNo INNER JOIN
                      Profile ON EmpBenefit.EmpId = Profile.ProfileId INNER JOIN
                      BenefitOptions ON EmpBenefit.OptionNo = BenefitOptions.OptionNo
       where profileid = @Empid and EmpBenefit.documentno=@documentno
       SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (  select @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid )
END
   -- select @body =@body+' '+ case @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid 
END

if  @SSDocType   = 2 -- Misconduct
BEGIN
  	  	 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Misconduct',@latinlang),(case when @latinlang='E' then 'Misconduct' else N'مخالفة' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','MisconductDate',@latinlang),(case when @latinlang='E' then 'Misconduct Date' else N'بتاريخ' end))
	         ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Misconduct2',@latinlang),(case when @latinlang='E' then 'Misconduct' else N'مخالفة' end))
	
	
		
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Mscondct.MiscondAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Mscondct.MiscondFName )) ELSE  ltrim(rtrim(Mscondct.MiscondName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpMscon.MisDate,103) ELSE LTRIM(RTRIM(DAY(EmpMscon.MisDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpMscon.MisDate),@Latinlang))),left(DATENAME(month,EmpMscon.MisDate),3))+' '+LTRIM(RTRIM(YEAR(EmpMscon.MisDate)))
	   end
      FROM EmpMscon
	left join EmpAssignment on EmpAssignment.empid=EmpMscon.empid
	LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
	left JOIN WFDocument on EmpMscon.DocumentNo = WFDocument.DocumentNo AND EmpMscon.EmpId = WFDocument.EmpID 
	LEFT JOIN EmpMsDtl ON EmpMscon.EmpId = EmpMsDtl.EmpId AND EmpMscon.DocumentNo = EmpMsDtl.DocumentNo 
	LEFT JOIN Mscondct ON EmpMsDtl.MsCode = Mscondct.MsCode 
       where profileid = @Empid and EmpMscon.documentno=@documentno
       
       select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid 
  end

if  @SSDocType   = 10 -- Objectives 
BEGIN
	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Objective',@latinlang),(case when @latinlang='E' then 'Objective' else N'الهدف' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','ObjectiveDate',@latinlang),(case when @latinlang='E' then 'Assign Start Date' else N'بتاريخ' end))
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','ObjectiveWeight',@latinlang),(case when @latinlang='E' then 'Weight' else N'الثقل' end))
  	        ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Objective2',@latinlang),(case when @latinlang='E' then 'Objective' else N'الهدف' end))
  	
  	
		
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+ 
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Objectives.ObjectiveAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Objectives.ObjectiveFName )) ELSE  ltrim(rtrim(Objectives.ObjectiveName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpObjectives.AssignStartDate,103) ELSE LTRIM(RTRIM(DAY(EmpObjectives.AssignStartDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpObjectives.AssignStartDate),@Latinlang))),left(DATENAME(month,EmpObjectives.AssignStartDate),3))+' '+LTRIM(RTRIM(YEAR(EmpObjectives.AssignStartDate)))
	   end
     +' ' +rtrim(@ModuleMsg3)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(str(EmpObjectives.ObjectiveWeight)))
	FROM         EmpObjectives INNER JOIN
                      Objectives ON EmpObjectives.ObjectiveId = Objectives.ObjectiveId INNER JOIN
                      Profile ON EmpObjectives.EmpId = Profile.ProfileId

       where profileid = @Empid and EmpObjectives.ObjectiveId =@documentno
    select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then  ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang='A' THEN rtrim(ltrim(Aname)) ELSE rtrim(ltrim(name)) END  from profile where profileid = @RoleProfileid 
  end


if  @SSDocType   = 6 -- Appraisal 
BEGIN
		SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Appraisal',@latinlang),(case when @latinlang='E' then 'Appraisal' else N'التقييم' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','AppraisalDate',@latinlang),(case when @latinlang='E' then 'Appraisal Date' else N'بتاريخ' end))
  	         ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Appraisal2',@latinlang),(case when @latinlang='E' then 'Appraisal' else N'التقييم' end))
  	
  	
    
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN rtrim(rtrim(Profile.AName)) ELSE rtrim(rtrim(Profile.Name)) END +
       rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
       CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Appraisals.AppraisalAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Appraisals.AppraisalFName )) ELSE  ltrim(rtrim(Appraisals.AppraisalName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpAppraisal.AppraisalDate,103) ELSE LTRIM(RTRIM(DAY(EmpAppraisal.AppraisalDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpAppraisal.AppraisalDate),@Latinlang))),left(DATENAME(month,EmpAppraisal.AppraisalDate),3))+' '+LTRIM(RTRIM(YEAR(EmpAppraisal.AppraisalDate)))
	   end
	FROM         EmpAppraisal INNER JOIN
                      Appraisals ON EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo INNER JOIN
                      Profile ON EmpAppraisal.EmpId = Profile.ProfileId

       where profileid = @Empid and EmpAppraisal.DocumentNo  =@documentno AND isnull(EmpAppraisal.AssignmentId,0)=@assignmentid

          SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (  select @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid )
END

  end

if  @SSDocType   = 8 -- Vacation Due Adjustment  
BEGIN
			SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','VacDueAdjustment',@latinlang),(case when @latinlang='E' then 'Vacation Due Adjustment' else N'تعديل مستحق الأجازات' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','VacDueAdjusDate',@latinlang),(case when @latinlang='E' then 'Due Adjustment Date' else N'بتاريخ' end))
  	        ,@ModuleMsg12=isnull(dbo.Hits_GetDCCaption('WFAction','VacDueAdjustment2',@latinlang),(case when @latinlang='E' then 'Vacation Due Adjustment' else N'تعديل مستحق الأجازات' end))
  	
  	
		
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
      CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(VacationDue.VacDueAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(VacationDue.VacDueFName )) ELSE  ltrim(rtrim(VacationDue.VacDueName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpVacationDue.VacDueDate,103) ELSE LTRIM(RTRIM(DAY(EmpVacationDue.VacDueDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpVacationDue.VacDueDate),@Latinlang))),left(DATENAME(month,EmpVacationDue.VacDueDate),3))+' '+LTRIM(RTRIM(YEAR(EmpVacationDue.VacDueDate)))
	   end
	FROM         EmpVacationDue INNER JOIN
                      VacationDue ON EmpVacationDue.VacDueCode = VacationDue.VacDueCode INNER JOIN
                      Profile ON EmpVacationDue.EmpId = Profile.ProfileId

       where profileid = @Empid and EmpVacationDue.DocumentNo  =@documentno
    select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END + CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) END  from profile where profileid = @RoleProfileid 
  end



if  @SSDocType   = 9 -- Training 
BEGIN
	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEvent',@latinlang),(case when @latinlang='E' then 'Training Event' else N'التدريب المجدول' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEventFrom',@latinlang),(case when @latinlang='E' then 'From Date' else N'من' end))
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEventTo',@latinlang),(case when @latinlang='E' then 'To Date' else N'إلى' end))
  			,@ModuleMsg4 =isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEventLocation',@latinlang),(case when @latinlang='E' then 'Location' else N'المكان' end))
  	        ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEvent2',@latinlang),(case when @latinlang='E' then 'Training Event' else N'التدريب المجدول' end))

  		     -- for customer "merck"
  		    ,@msg9 =isnull(dbo.Hits_GetDCCaption('WFAction','Dear',@latinlang),'')
	        ,@msg10=ISNULL(dbo.Hits_GetDCCaption('WFAction','Message5',@latinlang),'')  
	        ,@msg11= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message6',@latinlang),'')
	        ,@msg14 =ISNULL(dbo.Hits_GetDCCaption('WFAction','KindRegards',@latinlang),'')
	        ,@msg15= ISNULL(dbo.Hits_GetDCCaption('WFAction','HRIS',@latinlang),'')
  			
  	
		
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) END +
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
    CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(TrainingEvents.TrainingEventAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(TrainingEvents.TrainingEventFName )) ELSE  ltrim(rtrim(TrainingEvents.TrainingEventName))  END 
+' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),TrainingEvents.EventFromDate,103) ELSE 
	 	 	 	 	 	 		LTRIM(RTRIM(DAY(TrainingEvents.EventFromDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(TrainingEvents.EventFromDate),@Latinlang))),left(DATENAME(month,TrainingEvents.EventFromDate),3))+' '+LTRIM(RTRIM(YEAR(TrainingEvents.EventFromDate)))
	   end
+' '+rtrim(@ModuleMsg3)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),TrainingEvents.EventToDate,103) ELSE 
	 	 	 	 	 	 		LTRIM(RTRIM(DAY(TrainingEvents.EventToDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(TrainingEvents.EventToDate),@Latinlang))),left(DATENAME(month,TrainingEvents.EventToDate),3))+' '+LTRIM(RTRIM(YEAR(TrainingEvents.EventToDate)))
	   end
+' '+rtrim(@ModuleMsg4)+rtrim(ltrim(@MsgSeparator))+' '+
CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(TrainingEvents.EventALocation )) WHEN @Switchlang='F' THEN  ltrim(rtrim(TrainingEvents.EventFLocation )) ELSE  ltrim(rtrim(TrainingEvents.EventLocation))  END
	FROM         EmpTraining INNER JOIN
                      TrainingEvents ON EmpTraining.TrainingEvent = TrainingEvents.TrainingEvent INNER JOIN
                      Profile ON EmpTraining.EmpId = Profile.ProfileId
       where profileid = @Empid and EmpTraining.DocumentNo  =@documentno
     	-- condition to check customer is not "merck" 
     IF  @msg9 =''
       BEGIN
       	select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname))ELSE rtrim(ltrim(name)) END  from profile where profileid = @RoleProfileid
       	END     
  end

if  @SSDocType   = 11 -- vacancy
BEGIN
	
				SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','JobRequisition',@latinlang),(case when @latinlang='E' then 'Job Requisition' else N'الوظيفة الشاغرة' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','JobRequisitionDate',@latinlang),(case when @latinlang='E' then 'Vacancy Start Date' else N'تاريخ البداية' end))
  	        ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','JobRequisition2',@latinlang),(case when @latinlang='E' then 'Job Requisition' else N'الوظيفة الشاغرة' end))
  	
  	
    
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
   CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Vacancies.VacancyAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Vacancies.VacancyFName )) ELSE  ltrim(rtrim(Vacancies.VacancyName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),Vacancies.VacancyStartDate,103) ELSE 
	 	 	 	 	 	 	 		LTRIM(RTRIM(DAY(Vacancies.VacancyStartDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Vacancies.VacancyStartDate),@Latinlang))),left(DATENAME(month,Vacancies.VacancyStartDate),3))+' '+LTRIM(RTRIM(YEAR(Vacancies.VacancyStartDate)))
	   end
	FROM         Vacancies INNER JOIN
                      Profile ON Vacancies.EnterBy = Profile.ProfileId
       where profileid = @Empid and Vacancies.VacancyNo  =@documentno
    select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(Aname)) ELSE rtrim(ltrim(name)) END  from profile where profileid = @RoleProfileid 
  end

if  @SSDocType   = 12 -- Time Permission
BEGIN
		SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TimePermission',@latinlang),(case when @latinlang='E' then 'Time Permission' else N'اذن حضور و انصراف' end))
		,@ModuleMsg2 =isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionat',@latinlang),(case when @latinlang='E' then 'at' else N'بتاريخ' end))
  		,@ModuleMsg3= isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionFrom',@latinlang),(case when @latinlang='E' then 'From' else N'من' end))
  		,@ModuleMsg4 =isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionTo',@latinlang),(case when @latinlang='E' then 'To' else N'إلى' end))
  		,@ModuleMsg5 =isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionHours',@latinlang),(case when @latinlang='E' then 'Permission Hours' else N'فترة الأذن' end))
  		,@ModuleMsg12=isnull(dbo.Hits_GetDCCaption('WFAction','TimePermission2',@latinlang),(case when @latinlang='E' then 'Time Permission' else N'اذن حضور و انصراف' end))	
  			
  	
		 
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) END +
     rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
   CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(timepermission.permissionAname )) WHEN @Switchlang='F' THEN  ltrim(rtrim(timepermission.permissionFname )) ELSE  ltrim(rtrim(timepermission.permissionname))  END +
     ' '+rtrim(@ModuleMsg2)+' '+
	 	 	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),Emptimepermission.permissionFrom,103) ELSE 
	 	 	 	 	 	 	 	 		LTRIM(RTRIM(DAY(Emptimepermission.permissionFrom)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Emptimepermission.permissionFrom),@Latinlang))),left(DATENAME(month,Emptimepermission.permissionFrom),3))+' '+LTRIM(RTRIM(YEAR(Emptimepermission.permissionFrom)))
	   end
	+' '+rtrim(@ModuleMsg3)+' '+
	ltrim(rtrim(convert(char(17),permissionfrom,108))) 
	+' '+rtrim(@ModuleMsg4)+' '+
	ltrim(rtrim(convert(char(17),permissionTo,108)))
+' '+rtrim(@ModuleMsg5)+' '+
Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)/60,2,0),' ','0')+':'+
Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)%60,2,0),' ','0')
	FROM Emptimepermission INNER JOIN
                      timepermission ON Emptimepermission.permissionno=timepermission.permissionno INNER JOIN
                      Profile ON Emptimepermission.EmpId = Profile.ProfileId
       where profileid = @Empid and Emptimepermission.DocumentNo  =@documentno

       SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (  select @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid )
END
END

if  @SSDocType   = 20 -- NasUsersUncomitted
BEGIN
	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommitted1',@latinlang),(case when @latinlang='E' then 'User Registration' else N'تسجيل مستخدم' end))
	SELECT @ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommitted2',@latinlang),(case when @latinlang='E' then 'User Modification' else N'تعديل مستخدم' end))
	SELECT @ModuleMsg3= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommitted3',@latinlang),(case when @latinlang='E' then 'User Deletion' else N'مسح مستخدم' end))
	SELECT @ModuleMsg4= LTRIM(RTRIM(isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedURL',@latinlang),(case when @latinlang='E' then 'You can log onto your account using the following URL' else N'يمكنك الدخول إلى حسابك باستخدام الرابط التالي' end))))
	+@MsgSeparator+ CHAR(13)+CHAR(10)+@sswebsite
	,@ModuleMsg5= LTRIM(RTRIM(isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedPass',@latinlang),(case when @latinlang='E' then 'Your generated Password is' else N'كلمة المرور التي تم إنشاؤها الخاص بك هي' end))))
	+@MsgSeparator+ CHAR(13)+CHAR(10)+LTRIM(RTRIM(NasUsersUncommitted.UserInfo))
	FROM NasUsersUncommitted 
	where NasUsersUncommitted.EmpId = @Empid and NasUsersUncommitted.documentno=@documentno AND NasUsersUncommitted.DocumentStatus=1 AND NasUsersUncommitted.RequestedAction=1
	SELECT @ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedUserName',@latinlang),(case when @latinlang='E' then 'with username' else N'ب اسم المستخدم' end))

	
	--Registration request for employee x x x
	--Dear Folan,
	--User Registration request for x x x with username xxx@hitssolutions.com
	--User Modification request for x x x  with username xxx@hitssolutions.com
	--User Deletion request for x x x  with username xxx@hitssolutions.com
	--Folan Waiting for your approval
	--has been approved/rejected by Folan
	--You can log onto your account using the following URL
	--Your generated Password is

	select @body=ltrim(RTRIM(@MsgH))
	+' '+ltrim(rtrim(CASE WHEN NasUsersUncommitted.RequestedAction = 1 THEN @ModuleMsg1 WHEN NasUsersUncommitted.RequestedAction = 2 THEN @ModuleMsg2 ELSE @ModuleMsg3 END))+' '+ ltrim(rtrim(@Msg2))+' '+ CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END
	+' '+ltrim(rtrim(@ModuleMsg12))+rtrim(ltrim(@MsgSeparator))+' '+LTRIM(RTRIM(NasUsersUncommitted.LogonName))
	FROM NasUsersUncommitted 
	INNER JOIN Profile ON NasUsersUncommitted.EmpId = Profile.ProfileId
	where Profile.profileid = @Empid and NasUsersUncommitted.documentno=@documentno

	select @body=@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then  ' '+rtrim(@Msg5)+' 'END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid 
END


 if @SSDocType=23 --EmpReadingsUncommited
  BEGIN
  	
		 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TimeKeeping',@latinlang),(case when @latinlang='E' then 'Time Keeping' else N'قراءة السجلات' end)) 
			SELECT @ModuleMsg2 = 	isnull(dbo.Hits_GetDCCaption('WFAction','TkTimeIn',@latinlang),(case when @latinlang='E' then 'Time In' else N'تسجيل الدخول' end)) 	
			SELECT @ModuleMsg3 = 	isnull(dbo.Hits_GetDCCaption('WFAction','TkTimeOut',@latinlang),(case when @latinlang='E' then 'Time Out' else N'تسجيل خروج' end)) 	
	
	   	select @body=ltrim(RTRIM(@MsgH)) + ' '+rtrim(@ModuleMsg1)+' ' + rtrim(@Msg2)+' '+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +' ' 
	+RTRIM(ltrim(@SeparatorEnter))+' ' + 
	CASE WHEN TimeSystemLines.TimeLineType=1 THEN  RTRIM(@ModuleMsg2) ELSE RTRIM(@ModuleMsg3) END+ ' ' + 
	rtrim(ltrim(@SeparatorEnter2)) + rtrim(ltrim(@MsgSeparator))+' ' + CONVERT(NVARCHAR, EmpTimeReadingsUncommitted.AttendTime)
	 
	FROM profile 
	INNER join EmpTimeReadingsUncommitted on profile.profileid=EmpTimeReadingsUncommitted.empid 
	INNER JOIN TimeSystems ON TimeSystems.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
	INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = TimeSystems.TimeSystem AND 
	TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsUncommitted.ReaderValue ELSE EmpTimeReadingsUncommitted.FlagValue END   
       where profileid = @Empid and EmpTimeReadingsUncommitted.documentno=@documentno


       	-- condition to check customer is not "merck" 
       IF  @msg9 =''
       BEGIN
      
       SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
	   ,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       
	   SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN @tempMsgRole +replace(@TempMsgAction,'@RoleName','') ELSE  @TempMsgAction + @tempMsgRole END

       END
  end

 if @SSDocType=24 --EMpHrRequest
  BEGIN
  	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','HRRequest',@latinlang),(case when @latinlang='E' then 'HR' else N'طلب عام من الموارد البشرية' end))
 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','HRReqDate',@latinlang),(case when @latinlang='E' then 'with Date' else N'بتاريخ' end))
  			
  			 ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','HRRequest2',@latinlang),(case when @latinlang='E' then 'Request' else N'طلب' end))
  			
		
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
    	rtrim(ltrim(@SeparatorEnter))+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(HRRequest.HRReqAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(HRRequest.HRReqfName )) ELSE  ltrim(rtrim(HRRequest.HRReqName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpHRRequest.HRReqDate,103) ELSE LTRIM(RTRIM(DAY(EmpHRRequest.HRReqDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpHRRequest.HRReqDate),@Latinlang))),left(DATENAME(month,EmpHRRequest.HRReqDate),3))+' '+LTRIM(RTRIM(YEAR(EmpHRRequest.HRReqDate)))
	   end
      FROM EmpHRRequest
	left join EmpAssignment on EmpAssignment.empid=EmpHRRequest.empid
	LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
	LEFT JOIN HRRequest ON EmpHRRequest.HRReqCode = HRRequest.HRReqCode 
       where profileid = @Empid and EmpHRRequest.documentno=@documentno
       
  SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       
       SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN  @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') 
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END 
                                        +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid )

                                   END
  END 


   if @SSDocType=25 --EmpTask
  BEGIN
  	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Tasks',@latinlang),(case when @latinlang='E' then 'Tasks' else N'المهام' end))
 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','TaskDate',@latinlang),(case when @latinlang='E' then 'with Date' else N'بتاريخ' end))
  			
  			 ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Tasks2',@latinlang),(case when @latinlang='E' then 'Request' else N'طلب' end))
  			
		
    select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
    	rtrim(ltrim(@SeparatorEnter))+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(EmpTask.TaskAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(EmpTask.TaskFName )) ELSE  ltrim(rtrim(EmpTask.TaskName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpTask.startdate,103) ELSE LTRIM(RTRIM(DAY(Emptask.startdate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Emptask.startdate),@Latinlang))),left(DATENAME(month,Emptask.startdate),3))+' '+LTRIM(RTRIM(YEAR(Emptask.startdate)))
	   end
      FROM Emptask
	left join EmpAssignment on EmpAssignment.empid=Emptask.empid
	LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
    where profileid = @Empid and Emptask.documentno=@documentno
       
  SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       
       SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN  @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') 
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END 
                                        +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid )

                                   END
  END 

--sms or mail part
	
		SET @Tempbody=''

  	
   	-- for customer merck 
  	IF  @msg9 <> '' 
  	BEGIN
  	  	
  		SELECT @TempMsg = rtrim(ltrim(@msg9)) +' '+ CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(FirstAName)) ELSE rtrim(ltrim(FirstName)) END  from profile where profileid =@ProfileID 
  		SELECT @TempMsg = @TempMsg +','+ CHAR(13)+CHAR(10) + CHAR(13)+CHAR(10)
  		
  		IF @SSNewStatus IN (1,2) AND @SSDocType = 3       --vacation 
  		BEGIN
			SELECT @msg12 = CASE WHEN @SSNewStatus=2 THEN REPLACE(@msg12,'approved','rejected') ELSE @msg12 END
			SELECT @msg12 = CASE WHEN @ProfileID <> @Empid  THEN REPLACE(@msg12,'your','employee') ELSE @msg12 END

  		   	SET @EMailbody= @TempMsg +rtrim(ltrim(@msg12))+ nchar(13)+nchar(10)+ @body +nchar(13)+nchar(10)+nchar(13)+nchar(10) + +rtrim(ltrim(@msg13)) + nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
  		END
  		ELSE IF  @SSNewStatus = 0  AND @ProfileID <> @Empid   AND @RoleProfileid <> @ProfileID AND @SSDocType = 3 -- status not approved and manager and vacation 
		BEGIN 
  		    SET @EMailbody=@TempMsg + rtrim(ltrim(@msg10))+ nchar(13)+nchar(10)+ nchar(13)+nchar(10)+@body +nchar(13)+nchar(10) +nchar(13)+nchar(10)+rtrim(ltrim(@msg16))+nchar(13)+nchar(10)+nchar(13)+nchar(10)+rtrim(ltrim(@msg11)) + nchar(13)+nchar(10) +nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
		END
  		ELSE IF  @SSNewStatus = 2  AND @ProfileID <> @Empid AND @SSDocType = 9   -- status placed and manager and training 
  		BEGIN
  		    SET @EMailbody=@TempMsg +rtrim(ltrim(@msg10))+ nchar(13)+nchar(10)+@body +nchar(13)+nchar(10) + rtrim(ltrim(@msg11)) + nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
  		END
  		ELSE  
		BEGIN
  	        SET @EMailbody=@body
  		END
  	END
  	ELSE
  	BEGIN  			
  		SET @EMailbody=@body
  	END


if @SSNewStatus = 1 and  @profileid = @empid 
BEGIN
	set @EMailbody = @EMailbody + '. '
	IF @SSDocType=20
	BEGIN
		SET @EMailbody = @EMailbody + CHAR(13)+CHAR(10)+ISNULL(@ModuleMsg4,'') + CHAR(13)+CHAR(10)+ISNULL(@ModuleMsg5,'')
	END

END
       
       
--if @EMailAction = 4
--       set @EMailbody = @EMailbody + '. '+@Msg6
       
IF @EMailAction IN (1,4,5) AND (SELECT dbo.GetWFActionType2(@ProfileID,@DocumentNo,@Empid,@SSDocNo)) =1      
BEGIN
-- for customer is not merck 
	IF  @msg9 = ''
	BEGIN
		set @EMailbody = @EMailbody+@SeparatorEnter+@Msg6
	END

END
   --=======================================================  
IF @EMailAction =6
BEGIN
		set @EMailbody = @EMailbody+CHAR(13)+CHAR(10)
END       
       
--print @allemailto





SET @Tempbody=@EMailbody

 -- for customer is not merck 
if @msg9 = '' 
BEGIN
	IF  @SSDocType <> 20 OR (@SSDocType = 20 and  @profileid <> @empid )
	BEGIN

		if @ActionResaon<>'' 
		begin
			SET @Tempbody=@EMailbody+CHAR(13)+CHAR(10)+rtrim(ltrim(@Msg8))+' '+rtrim(ltrim(@ActionResaon))
			SET @Tempbody=@Tempbody+CHAR(13)+CHAR(10)+@Msg7
		END
		else
		begin
			SET @Tempbody=@EMailbody+CHAR(13)+CHAR(10)+@Msg7
		end

		SET @Tempbody=@Tempbody+CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)+@MsgF
		SELECT @Recipient = '' 
		SELECT @Recipient = LTRIM(RTRIM( CASE WHEN @latinlang ='A' THEN Profile.AName ELSE Profile.Name END )) FROM Profile WHERE Profile.ProfileId = @ProfileID
		SELECT @Tempbody = REPLACE(@Tempbody,'@Recipient',@Recipient)
		SELECT @Tempbody = REPLACE(@Tempbody,'@EmployeeID',@ID)
	END 
end	 
   







 
--end sms or mail part
--SELECT @body=CASE WHEN @SmsOrMail=0 THEN @tempBodySMS ELSE @tempBodyMail end
SELECT @body=@tempBody
	RETURN  @body  
END

GO

