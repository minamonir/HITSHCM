


create  FUNCTION [dbo].[V_YearStart]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS

--DECLARE @payrollgroup INT=1,@period INT=12,@year INT=2019
BEGIN
  
  declare @thedate smalldatetime,@VSMonth smallint,@VSDay as smallint,@yearstart as smalldatetime

  
  declare @date SMALLDATETIME
  


--  if @year=0  select @year=cyear, @period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
   if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
   if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup	
 
   select @VSMonth=vsmonth,@VSDay=Vsday from payrollgroup where payrollgroup=@payrollgroup	

 
   if @VSMonth=0 or @VSDay=0

   begin
    --set  @thedate =dbo.periodstart(@payrollgroup,1,@year+1)-1
	 set  @thedate =dbo.periodstart(@payrollgroup,1,@year)
   end 
   else

   begin  
   
			set @yearstart=dbo.v_periodstart(@payrollgroup,@VSMonth,@year)

			set @date=dbo.v_periodstart(@payrollgroup,@Period,@year)

	        set @thedate=case when @date<@yearstart then  dbo.v_periodstart(@payrollgroup,@VSMonth,@year-1)  else @yearstart end

   end
		   	
 
return  @thedate

END

GO

