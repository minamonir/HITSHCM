
CREATE FUNCTION GetFirstEmptyCustomReportNo()
RETURNS SMALLINT
AS
BEGIN
	DECLARE @RepNo SMALLINT 
    SET @RepNo = 5001
    WHILE @RepNo IN(SELECT reportno FROM reports WHERE reportno =  @RepNo)
         BEGIN
             set @RepNo = @RepNo + 1
         END
	RETURN @RepNo

END

GO

