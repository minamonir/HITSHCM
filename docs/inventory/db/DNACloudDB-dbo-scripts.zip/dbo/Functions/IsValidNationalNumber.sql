CREATE FUNCTION [dbo].[IsValidNationalNumber](
@NationalId NVARCHAR(max)
) 
RETURNS int
BEGIN
    DECLARE @birthdate datetime;
    DECLARE @gender smallint;
	DECLARE @birthdateProfile datetime;
    DECLARE @genderProfile smallint;
	DECLARE @centuryAD as int ,@year AS int , @month AS int , @day AS int
    DECLARE @valid int;


	--@genderProfile = 1 male
	--@genderProfile = 2 female
   SELECT top 1  @birthdateProfile = BirthDate, @genderProfile=Gender FROM profile where ltrim(rtrim(natnlno))=ltrim(rtrim(@NationalId))

    SELECT @valid = 0;
	SELECT @gender = SUBSTRING(ltrim(rtrim(@NationalId)), 13, 1)
	
	-- check for length
    IF len(ltrim(rtrim(@NationalId))) <> 14 
	begin 
        RETURN @valid;
    END 
	-- check for gender
	if NOT((@genderProfile = 1 AND @gender% 2 != 0) OR ( @genderProfile = 2 AND @gender % 2 = 0)) 
	 begin
	    RETURN @valid;
	 end
    -- Check if the birthdate is valid

	set @centuryAD =SUBSTRING(ltrim(rtrim(@NationalId)), 1,1)
	set @year =case when @centuryAD= 2 then 1900 + SUBSTRING(ltrim(rtrim(@NationalId)), 2,2)
					when @centuryAD= 3 then 2000 + SUBSTRING(ltrim(rtrim(@NationalId)), 2,2)
					else 0 end 
	set @month=SUBSTRING(ltrim(rtrim(@NationalId)), 4,2)
	set @day=SUBSTRING(ltrim(rtrim(@NationalId)), 6,2)

     if ( @centuryAD NOT IN ('2', '3')) OR (SUBSTRING(ltrim(rtrim(@NationalId)), 2,2) NOT BETWEEN 0 AND 99) 
	 begin
	 		RETURN @valid;
	 end

	  if (ISDATE(CAST(@year as char(4)) + RIGHT('00' + LTRIM(@month),2) + RIGHT('00' + LTRIM(@day),2))=0)
	  begin
		RETURN @valid;
	  end
	  if(CAST(@year as char(4)) + RIGHT('00' + LTRIM(@month),2) + RIGHT('00' + LTRIM(@day),2) > GETDATE())
	  begin
	   RETURN @valid;
	  end
	SET @birthdate = CAST(CAST(@year as char(4)) + RIGHT('00' + LTRIM(@month),2) + RIGHT('00' + LTRIM(@day),2) AS datetime);
		
    IF @birthdate <> @birthdateProfile and @birthdateProfile is not null
    BEGIN
       RETURN @valid;
    END;

	 -- check for provience
	 if(SUBSTRING(ltrim(rtrim(@NationalId)), 8,2) NOT IN ('01','02','03','04','11','12','13','14','15','16','17','18','19','21','22','23','24','25','26','27','28','29','31','32','33','34','35','88'))
	 begin
	  RETURN @valid;
	 end

	 -- All conditions passed , then set @valid is true
    SELECT @valid = 1;
    RETURN @valid;
END

GO

