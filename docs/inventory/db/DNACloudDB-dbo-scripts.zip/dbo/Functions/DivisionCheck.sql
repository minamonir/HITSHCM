create  FUNCTION [dbo].[DivisionCheck] (@x NUMERIC(18,3))
RETURNS numeric(18,3) AS  
begin
SET @x=CASE WHEN @x=0 THEN 1 ELSE @x end


RETURN @x
END

GO

