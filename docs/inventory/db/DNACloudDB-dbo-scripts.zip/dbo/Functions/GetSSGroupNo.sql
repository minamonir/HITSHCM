


CREATE  FUNCTION [dbo].[GetSSGroupNo]()
RETURNS  int
as
BEGIN 
DECLARE @SSGroup AS INT =0
        SELECT @SSGroup =MAX(SSGroup) FROM dbo.SSGroup
		SET @SSGroup=ISNULL(@SSGroup,0)+1 
  return @SSGroup
END

GO

