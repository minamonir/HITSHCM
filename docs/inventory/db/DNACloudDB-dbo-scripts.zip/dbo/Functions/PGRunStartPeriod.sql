CREATE  FUNCTION [dbo].[PGRunStartPeriod] (@PayrollGroup Smallint,@Year int ,@period INT,@runno SMALLINT,@StartOREnd AS int)
RETURNS datetime as

BEGIN
	
	--@StartOREnd =1   start period
	--@StartOREnd =2   End period
declare @periodStartEndDate as DATETIME,@CurrenPeriod AS BIT,@RunOrder AS smallint,@ID AS int

SET @CurrenPeriod=0

SELECT @CurrenPeriod=1 FROM PayrollGroup WHERE  cyear=@Year AND cmonth=@period AND PayrollGroup.PayrollGroup=@PayrollGroup

SELECT @CurrenPeriod=ISNULL(@CurrenPeriod,0)
---------------------------------------------------------
declare  @PayrollgroupRuns TABLE (ID int IDENTITY(1,1),RunNo SMALLINT,RunOrder SMALLINT,RunEndDate SMALLDATETIME)

IF @CurrenPeriod=1
BEGIN
	
	SELECT @RunOrder=RunOrder
	FROM PayrollGroupRuns
	where PayrollGroupRuns.PayrollGroup=@PayrollGroup and  runno=@runno
	

	INSERT INTO @PayrollgroupRuns(RunNo,RunOrder,RunEndDate) 
	SELECT PayrollGroupRuns.RunNo,RunOrder,RunEndDate
	FROM PayrollGroupRuns
	where PayrollGroupRuns.PayrollGroup=@PayrollGroup and  PayrollGroupRuns.runorder<=@RunOrder 
	ORDER BY runorder,runno
END
ELSE
BEGIN
	SELECT @RunOrder=RunOrder
	FROM PayrollGroupRunsHistory
	where PayrollGroupRunsHistory.PayrollGroup = @PayrollGroup   AND YEAR=@Year AND [Month]=@period and  runno=@runno
	
	
	INSERT INTO @PayrollgroupRuns(RunNo,RunOrder,RunEndDate) 
	SELECT RunNo,RunOrder,RunEndDate
	FROM PayrollGroupRunsHistory
	where PayrollGroupRunsHistory.PayrollGroup = @PayrollGroup   AND YEAR=@Year AND [Month]=@period
	and RunOrder<=@RunOrder ORDER BY runorder,runno
end
	

 SELECT @ID=ID
 FROM @PayrollgroupRuns WHERE runno=@runno
 
 DELETE FROM @PayrollgroupRuns WHERE id>@ID
 
 -----------------------------------------------------

IF @StartOREnd=1
BEGIN
				 
			select top 1  @periodStartEndDate =RunEndDate+1  from @PayrollgroupRuns
			where RunEndDate IS NOT null   and runno<>@runno
			order BY  RunEndDate desc
			
END
ELSE
BEGIN
			select top 1  @periodStartEndDate =RunEndDate  from @PayrollgroupRuns
			where  runno=@runno
END
		
	
	


IF @periodStartEndDate IS null
select  @periodStartEndDate = case when @StartOREnd=1 then dbo.periodstart(@PayrollGroup,@period,@Year) ELSE dbo.periodEnd(@PayrollGroup,@period,@Year) END 

return @periodStartEndDate

end

GO

