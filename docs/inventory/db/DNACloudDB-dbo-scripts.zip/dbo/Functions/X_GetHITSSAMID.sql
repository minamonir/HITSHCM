CREATE FUNCTION [dbo].[X_GetHITSSAMID] (@email NVARCHAR(80),@logonname NVARCHAR(80),@empid AS INT )
RETURNS INT
BEGIN 

	DECLARE
	 @emailtemp	  NVARCHAR(80) = N''
	,@ReturnEmpid AS INT	   = 0
	
	SELECT	@emailtemp = SUBSTRING(@email, 1, CHARINDEX('@', @email) - 1)
	WHERE	CHARINDEX('@', @email) > 1
	
	IF @email = '' RETURN @empid
	
	SELECT	TOP 1 @ReturnEmpid = EmpId
	FROM	NasUsers
	WHERE	CHARINDEX('@', NasUsers.LogonName) > 1 AND SUBSTRING(NasUsers.LogonName, 1, CHARINDEX('@', NasUsers.LogonName) - 1) = @emailtemp
	
	IF @ReturnEmpid <> 0 RETURN @ReturnEmpid
	ELSE
		SELECT TOP 1	@ReturnEmpid = Profile.ProfileId
		FROM	Profile
		INNER JOIN EmpAssignment ON EmpAssignment.EmpId = Profile.ProfileId
		WHERE CHARINDEX('@', CompanyEmail) > 1 AND SUBSTRING(CompanyEmail, 1, CHARINDEX('@', CompanyEmail) - 1) = @emailtemp 
		ORDER BY ProfileId
	
	RETURN @ReturnEmpid
	
	/*DECLARE @user NVARCHAR(80)=''
	SELECT @logonname = ISNULL(@logonname,'')
	SELECT  @user = SUBSTRING(@email,1,CHARINDEX('@',@email)-1) WHERE CHARINDEX('@',@email)>1
	
	IF @user = '' RETURN ''
	
	IF EXISTS(SELECT * FROM NasUsers WHERE CHARINDEX('@',NasUsers.LogonName)>1 
			AND SUBSTRING(NasUsers.LogonName,1,CHARINDEX('@',NasUsers.LogonName)-1) = @user 
			AND NasUsers.LogonName=@logonname) 
	RETURN @user
	IF NOT EXISTS(SELECT *  FROM NasUsers WHERE CHARINDEX('@',NasUsers.LogonName)>1 
			AND SUBSTRING(NasUsers.LogonName,1,CHARINDEX('@',NasUsers.LogonName)-1) = @user 
			AND NasUsers.LogonName<>@logonname AND NasUsers.WindowsOnly = 1)
	RETURN @user
	
	RETURN ''*/
END

GO

