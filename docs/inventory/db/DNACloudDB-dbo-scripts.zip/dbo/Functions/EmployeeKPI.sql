
/*This fn calculates the KPI number  as
@emp is the number of the employee
@posorJob in [0,1,2] then the calc is based on [Job,Position,organization]competencies respectively
@code is the code no for specific job or position or organization
@level [low or high]
*/
CREATE FUNCTION [dbo].[EmployeeKPI] (@empid as int,@posorjob as int ,@code as smallint,@level as nchar)  
RETURNS numeric(9,3)  AS  
begin
if @code is null return 0
declare @weight as numeric(9,3)
declare @KPI as numeric(9,3)
set @KPI=0
declare @EmpPercent as numeric(9,3)
declare @CompPercent as numeric(9,3)
declare @CompWeight as numeric(9,3)
declare @empweight as numeric(9,3)
declare @codeweight as numeric(9,3)
set @empweight=0
set @codeweight=0

--for job
if @posorjob=0
begin
select @empweight=isnull(sum(isnull(finalcompetencies.Levelpercent ,0.0)*isnull(jobCompetence.weight,0.0)),0.0)
,@codeweight=isnull(sum(isnull(LevelsCompetence.LevelPercent,0.0)*isnull(jobCompetence.weight,0.0)),0.0)
from jobCompetence 
left join LevelsCompetence on LevelsCompetence.Competence=jobCompetence.Competence 
and LevelsCompetence.ratinglevel=case when @level=N'L' then jobCompetence.LowLevel else jobCompetence.HighLevel END
left join finalcompetencies on finalcompetencies.EmpId=@empid AND jobCompetence.Competence=finalcompetencies.Competence   
where jobCompetence.Job=@code
end
--for position
else
if @posorjob=1
begin
select @empweight=isnull(sum(isnull(finalcompetencies.Levelpercent ,0.0)*isnull(PositionCompetence.weight,0.0)),0.0)
,@codeweight=isnull(sum(isnull(LevelsCompetence.LevelPercent,0.0)*isnull(PositionCompetence.weight,0.0)),0.0)
from PositionCompetence 
left join LevelsCompetence on LevelsCompetence.Competence=PositionCompetence.Competence 
and LevelsCompetence.ratinglevel=case when @level=N'L' then PositionCompetence.LowLevel else PositionCompetence.HighLevel end
left join finalcompetencies on  finalcompetencies.EmpId=@empid AND PositionCompetence.Competence=finalcompetencies.Competence  
where PositionCompetence.PositionNo=@code
end

--for organization
else
if @posorjob=2
begin

select @empweight=isnull(sum(isnull(finalcompetencies.Levelpercent ,0.0)*isnull(OrgCompetence.weight,0.0)),0.0)
,@codeweight=isnull(sum(isnull(LevelsCompetence.LevelPercent,0.0)*isnull(OrgCompetence.weight,0.0)),0.0)
from OrgCompetence 
left join LevelsCompetence on LevelsCompetence.Competence=OrgCompetence.Competence 
and LevelsCompetence.ratinglevel=case when @level=N'L' then OrgCompetence.LowLevel else OrgCompetence.HighLevel end
left join finalcompetencies on  finalcompetencies.EmpId=@empid AND OrgCompetence.Competence=finalcompetencies.Competence  
where OrgCompetence.organization=@code
end
else
return 0

--declare @EmpPercent as numeric(9,3)
--declare @CompPercent as numeric(9,3)
--declare @CompWeight as numeric(9,3)
--declare @empweight as numeric(9,3)
--declare @codeweight as numeric(9,3)
--set @empweight=0
--set @codeweight=0
--open EmpComp
--
--Fetch next from EmpComp 
--into @EmpPercent,@CompPercent,@CompWeight
--if @@fetch_status <> 0 return 0
--while @@fetch_status =0
--begin
--
--set @empweight=@empweight+(@EmpPercent*@CompWeight)
--set @codeweight=@codeweight+(@CompPercent*@CompWeight)
--FETCH NEXT FROM EmpComp 
--INTO @EmpPercent,@CompPercent,@CompWeight 
--
--end
--close EmpComp 
--deallocate EmpComp 
if @codeweight=0.0 return @KPI

set @KPI=@empweight/@codeweight
return @KPI
--End

end

GO

