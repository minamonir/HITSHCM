-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[allSubTree]
(
	-- Add the parameters for the function here
	@parentOrg smallint,@organization smallint
)
RETURNS bit
AS
BEGIN
	--test 123
	-- Declare the return variable here
	DECLARE @ischild AS bit
	SET @ischild=1
	RETURN @ischild

END

GO

