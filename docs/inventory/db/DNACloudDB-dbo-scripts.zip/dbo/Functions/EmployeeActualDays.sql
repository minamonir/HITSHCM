
CREATE FUNCTION [dbo].[EmployeeActualDays] (@empid as int,@From smalldatetime,@To smalldatetime,@EntryDate smalldatetime,@flag as int)  
RETURNS numeric(18,3) 
AS  
BEGIN 
  Declare @Days as numeric(18,3)
if @flag=1             --MinWork
Begin
select @Days= Min(EmpShiftInOut.WorkSeconds)
from EmpShiftInOut 
where  EmpShiftInOut.EmpId=@empid and EmpShiftInOut.EntryDate between @From and @To
and EmpShiftInOut.TimeIn is not null and EmpShiftInOut.TimeOut is not null
and MONTH ( EmpShiftInOut.EntryDate)=month(@EntryDate)
and Year(EmpShiftInOut.EntryDate)=Year(@EntryDate)
and EmpShiftInOut.ShiftTimeNo<>0
End
else if @flag=2   --ActualDays
Begin
select @Days= count( EmpShiftInOut.EmpId)
from EmpShiftInOut 
where  EmpShiftInOut.EmpId=@empid and EmpShiftInOut.EntryDate between @From and @To
and EmpShiftInOut.TimeIn is not null and EmpShiftInOut.TimeOut is not null
and MONTH ( EmpShiftInOut.EntryDate)=month(@EntryDate)
and Year(EmpShiftInOut.EntryDate)=Year(@EntryDate)
and EmpShiftInOut.ShiftTimeNo<>0
End
else if @flag=3  --AvrageWork
Begin
select @Days= Sum(EmpShiftInOut.WorkSeconds)/count( EmpShiftInOut.EmpId)
from EmpShiftInOut 
where  EmpShiftInOut.EmpId=@empid and EmpShiftInOut.EntryDate between @From and @To
and EmpShiftInOut.TimeIn is not null and EmpShiftInOut.TimeOut is not null
and MONTH ( EmpShiftInOut.EntryDate)=month(@EntryDate)
and Year(EmpShiftInOut.EntryDate)=Year(@EntryDate) 
and EmpShiftInOut.ShiftTimeNo<>0
End
else if @flag=4  --MaxWork
Begin
select @Days= Max(EmpShiftInOut.WorkSeconds)
from EmpShiftInOut 
where  EmpShiftInOut.EmpId=@empid and EmpShiftInOut.EntryDate between @From and @To
and EmpShiftInOut.TimeIn is not null and EmpShiftInOut.TimeOut is not null
and MONTH ( EmpShiftInOut.EntryDate)=month(@EntryDate)
and Year(EmpShiftInOut.EntryDate)=Year(@EntryDate)
and EmpShiftInOut.ShiftTimeNo<>0
End

else if @flag=5  ---ActualExpectedDays
Begin
select @Days= Sum(EmpShiftInOut.ShiftSeconds)
from EmpShiftInOut 
where  EmpShiftInOut.EmpId=@empid and EmpShiftInOut.EntryDate between @From and @To
and (EmpShiftInOut.TimeIn is null or EmpShiftInOut.TimeOut is null)
and MONTH ( EmpShiftInOut.EntryDate)=month(@EntryDate)
and Year(EmpShiftInOut.EntryDate)=Year(@EntryDate)
and EmpShiftInOut.ShiftTimeNo<>0
End


Return @Days
END

GO

