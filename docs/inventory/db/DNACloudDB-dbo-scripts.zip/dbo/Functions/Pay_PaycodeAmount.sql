
--- for mantrac Reports 396,397
-- getting exempted amount or taxable amount for this paycode (@Paycode) according to @Type (@type=0 report 396 (exempted amount) ,@type=1 report 397 (taxaple amount))
-- for the current month or the hole year  according to @month (@month=0 hole year , @month<>0 current month)

CREATE    FUNCTION [dbo].[Pay_PaycodeAmount] (@Empid Int,@payrollgroup smallint, @year  smallint,@month  smallint,@From as smallint,@To as smallint,@TaxCode as smallint, @Paycode as smallint,@Type as smallint)
RETURNS numeric(18,3) AS 
begin

DECLARE @w_months as smallint, @ExemptAmount as numeric(18,3), 
   @TaxAmount as numeric(18,3), @BasicSal as numeric(18,3), @taxempexmp as numeric(18,3),@PayCodeamount as numeric(18,3),
@taxcmpexmp as numeric(18,3), @MaxMonth as smallint,@PayGroupCur as smallint
set @PayCodeamount=0.0
DECLARE @ytd_table TABLE (paycode smallint, amount numeric(18,3))

if @month=0
begin
  select @w_months=count(distinct HistoryPayroll.Month) from HistoryPayroll 
   where HistoryPayroll.empid=@empid and HistoryPayroll.Year=@year 
	and  (HistoryPayroll.Month between left(@From,2) and left(@To,2)) and
    HistoryPayroll.payrollgroup=@payrollgroup
  select @BasicSal=sum(case when HistoryTransaction.paycode=100 then HistoryTransaction.amount else 0 end) 
    from  HistoryTransaction inner join HistoryPayroll on HistoryTransaction.Empid=HistoryPayroll.Empid and 
    HistoryTransaction.Year=HistoryPayroll.Year and HistoryTransaction.Month=HistoryPayroll.Month and
    HistoryTransaction.Runno=HistoryPayroll.Runno  where HistoryPayroll.empid=@empid and HistoryPayroll.Year=@year and 
    HistoryPayroll.payrollgroup=@payrollgroup 
    and (HistoryPayroll.Month between @From and @To)

  if @paycode=0
  begin
    insert @ytd_table
    select max(paycode.code) as paycode, sum(h.amount) as amount
    from historytransaction h inner join paycode on h.paycode=paycode.code 
      inner join historypayroll p on p.empid=h.empid and p.year=h.year and p.month=h.month and p.runno=h.runno 
    where (paycode.type=3 or paycode.taxappl=1) and h.empid=@empid and h.year=@year and p.payrollgroup=@payrollgroup
	and (P.Month between @From and @To)
    group by paycode.code
  end
  else
  begin
    insert @ytd_table
    select max(paycode.code) as paycode, sum(h.amount) as amount
    from historytransaction h inner join paycode on h.paycode=paycode.code 
      inner join historypayroll p on p.empid=h.empid and p.year=h.year and p.month=h.month and p.runno=h.runno 
    where h.empid=@empid and h.year=@year
      and p.payrollgroup=@payrollgroup and paycode=@paycode 
      and (P.Month between @From and @To)
    group by paycode.code
  end

select @maxmonth=max(HistoryPayroll.Month),@paygroupCur=max(HistoryPayroll.PayrollCurrency)
from HistoryPayroll where HistoryPayroll.empid=@empid and HistoryPayroll.Year=@year and HistoryPayroll.payrollgroup=@payrollgroup 
and (HistoryPayroll.Month between @From and @To)
end

else
-------------------monthly------------------------------------------------
begin
  select @w_months=1
  select @BasicSal=sum(case when MonthlyTransaction.paycode=100 then MonthlyTransaction.amount else 0 end)
    from  MonthlyTransaction where MonthlyTransaction.empid=@empid 
  if @paycode=0
  begin
    insert @ytd_table
    select max(paycode.code) as paycode, sum(M.amount) as amount
    from MonthlyTransaction M inner join paycode on M.paycode=paycode.code 
     where (paycode.type=3 or paycode.taxappl=1) and M.empid=@empid 
    group by paycode.code
  end
  else
  begin
    insert @ytd_table
    select max(paycode.code) as paycode, sum(M.amount) as amount
    from MonthlyTransaction M inner join paycode on M.paycode=paycode.code 
    where M.empid=@empid and paycode=@paycode
    group by paycode.code
  end
select @maxmonth=CMonth,@paygroupCur=Currency
from PayrollGroup where PayrollGroup.payrollgroup=@payrollgroup

end


select @TaxAmount=sum(case when paycode.taxappl=1  and (paycode.type<>3 or paycode.code=100) then 
               case when paycode.maxexmp<>0 then 
                 case when paycode.percentyn=1 then 
                   case when paycode.maxexmp<100 then (YTD.amount*(100-paycode.maxexmp)/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end 
                 else
                   case when paycode.maxexmp*@w_months<YTD.amount then (YTD.amount-paycode.maxexmp*@w_months)*(case when paycode.type=2 then -1 else 1 end) else 0 end 
                 end                 
               else
                 case when paycode.prcexmp<>0 then 
                   case when paycode.prcexmp*@BasicSal/100<YTD.amount then (YTD.amount-paycode.prcexmp*@BasicSal/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end
                 else
                   YTD.amount*(case when paycode.type=2 then -1 else 1 end)
                 end
               end                               
             else
               0
             end),
       @taxempexmp=sum(case when paycode.taxappl=1 and paycode.partcomp=1 and (paycode.type<>3 or paycode.code=100) then 
               case when paycode.maxexmp<>0 then 
                 case when paycode.percentyn=1 then 
                   case when paycode.maxexmp<100 then (YTD.amount*paycode.maxexmp/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end 
                 else
                   case when paycode.maxexmp*@w_months<YTD.amount then (paycode.maxexmp*@w_months)*(case when paycode.type=2 then -1 else 1 end) else (YTD.amount)*(case when paycode.type=2 then -1 else 1 end) end 
                 end                 
               else
                 case when paycode.prcexmp<>0 then 
                   case when paycode.prcexmp*@BasicSal/100<YTD.amount then (paycode.prcexmp*@BasicSal/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end
                 else
                   0
                 end
               end                               
             else
               0
             end),       
      @taxcmpexmp=max(taxrules.taxcmpexmp)/12*@w_months
from  @ytd_table ytd inner join paycode on ytd.paycode=paycode.code 
   inner join empassignment on empassignment.empid=@empid 
   inner join taxrules on taxrules.taxcode=case when @TaxCode=0 then empassignment.taxcode else @TaxCode end
group by empassignment.empid




if @Type=0 and @paycode<>0 select @PayCodeamount=isnull(sum(isnull(amount,0))-isnull(@TaxAmount,0),0) from @ytd_table
if @Type=1 and @paycode<>0 select @PayCodeamount=isnull(max(@TaxAmount),0)from @ytd_table
if @paycode=0 select @PayCodeamount=case when @taxempexmp>@taxcmpexmp then @taxempexmp-@taxcmpexmp else 0 end from @ytd_table
select @PayCodeamount=dbo.convertamount(@PayCodeamount,@paygroupCur,SysCur,dbo.periodend(@payrollgroup,@maxmonth,@year)) from sysparam


return @PayCodeamount

END

GO

