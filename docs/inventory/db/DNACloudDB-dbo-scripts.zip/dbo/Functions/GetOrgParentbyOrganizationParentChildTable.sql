create    FUNCTION [dbo].[GetOrgParentbyOrganizationParentChildTable]
  (@Organization smallint, @OrganizationType smallint,@versionno  smallint,@corn  smallint , @lang  nchar(1))
RETURNS  nvarchar(250)
as
BEGIN 
declare @returntype as smallint, @returnorg as smallint  , @returnname as nvarchar(250)  
  select @returntype=organizationtype from organization where organization=@organization 
  
  set @returnorg=0
  if @returntype<@OrganizationType set @returnorg=0

  if @returntype=@OrganizationType set @returnorg=@Organization

  if @returntype>@OrganizationType  
    begin
   
	
	select top 1 @returnorg=OrganizationParentOrChild
from OrganizationParentChild
LEFT JOIN organization ON OrganizationParentChild.OrganizationParentOrChild = Organization.Organization
where OrgRelation in (1) and OrganizationParentChild.Organization=@Organization and Organization.OrganizationType=@OrganizationType
--order by Organizationtype desc

     end
  
if @corn = 0 return @returnorg
if @corn = 1  
if @lang = N'E'  select @returnname= organizationname from organization where organization =  @returnorg
else select @returnname= organizationaname from organization where organization =  @returnorg
return isnull(@returnname,N'')

END

GO

