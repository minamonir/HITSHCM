
-- get the total no of days taken in this vacation (@VacCode) between @fromdate and @todate for this employee (@empid)
CREATE     FUNCTION [dbo].[VacTotalTaken]
(@empid int,@fromdate datetime,@todate datetime,@vaccode as int)
RETURNS numeric(18,3)
AS
BEGIN
declare @DecimalScale as smallint, @days numeric(18,3)
select @DecimalScale=DecimalScale from sysparam
select @days= SUM(dbo.VacTakenDays(EmpVacat.EmpId, 
   case when EmpVacat.FromDate<@fromdate then @fromdate else EmpVacat.FromDate end , 
   case when EmpVacat.ToDate>@todate then @todate else EmpVacat.ToDate end,
   EmpVacat.VacCode,EmpVacat.DocumentNo,EmpVacat.PartDayFrom,EmpVacat.PartDayTo))
from EmpVacat where EmpVacat.empid=@empid and EmpVacat.vaccode=CASE WHEN @vaccode=0 THEN EmpVacat.vaccode ELSE @vaccode end and 
  EmpVacat.VacStatus=1 and ((@fromdate between EmpVacat.FromDate and EmpVacat.ToDate) or
  (@todate between EmpVacat.FromDate and EmpVacat.ToDate) or
  (EmpVacat.FromDate between @fromdate and @todate) or
  (EmpVacat.ToDate between @fromdate and @todate))

set @days=round(isnull(@days,0),@DecimalScale)
RETURN @days 
END

GO

