
CREATE FUNCTION [dbo].[GetTakenPeriod] (@empid int,@date2 as smalldatetime,@vaccode as smallint) 
RETURNS numeric(18,3)

---get the vac taken within 3 years Aniversaly from the hire date
-- ex: hiredate='2000-05-15' and @date2='2007-02-10'
--this function calculates the vac taken from '2006-05-15' to '2009-05-15'

AS


BEGIN
  
  Declare @Taken as numeric (18,3),@from as smalldatetime,@to as smalldatetime
  
select @to=cast(cast(year(@date2)+(3-case when ((year(@date2)-year(hiredate))%3) =0 then 3 else ((year(@date2)-year(hiredate))%3) end)
as nchar(4))+'/'+cast(month(hiredate) as nchar(2))+'/'+cast(case when day(empassignment.hiredate)=29 and month(empassignment.hiredate)=2 then
28 else day(empassignment.hiredate)end as nchar(2)) as smalldatetime)--day(hiredate) as nchar(2)) as smalldatetime)
from EmpAssignment
where empid=@empid
select @from=dateadd(yy,-3,@to),@TO=@TO-1

if @date2 not between @from and @to 
begin 
set @from =@to+1
set @to=dateadd(yy,3,@from)-1
end
--select @from,@to
select @Taken=sum(case when ((e.fromdate between @from and @to) or 
 (e.todate between @from and @to) or (@from between e.fromdate and e.todate) or 
(@to between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@from then
 @from else e.fromdate end,case when e.todate>@to then @to else e.todate end, e.vaccode,e.DocumentNo,e.PartDayFrom,e.PartDayTo) else 0 end) 
from empvacat e  
where e.vacstatus=1 and e.empid=@empid and e.vaccode=@vaccode


  RETURN isnull(@Taken,0)
--select @Balance as Bal,@PrevBal as prevbal,@Due as due,@Taken as taken
END

GO

