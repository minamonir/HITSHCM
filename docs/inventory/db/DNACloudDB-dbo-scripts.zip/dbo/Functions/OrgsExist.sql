
CREATE FUNCTION [dbo].[OrgsExist] 
	(@LinqTable as nvarchar(max), @userOrgs AS NVARCHAR(MAX)='', @code as nvarchar(max)) RETURNS BIT

AS

--declare @LinqTable as nvarchar(max), @userOrgs AS NVARCHAR(MAX)='', @code as nvarchar(max)

--select @LinqTable=N'Grades', @userOrgs=N'#52##53##51#', @code=N'2'

--,@logonname as nvarchar(80)
--,@userOrgs as NVARCHAR(max)
BEGIN	
	DECLARE @enableorgsetup AS BIT =0 , @OrgsField as NVARCHAR(max)=N'', @table as nvarchar(max)=N'', @CodeField as nvarchar(max)=N''
	,@rowcnt INT=0
	--, @cnt as INT=0,@OrgsExists as NVARCHAR(max) = N''
 
   
    SELECT @enableorgsetup =sysparam.EnableOrgSetup 
	FROM sysparam 

	select @OrgsField = ltrim(rtrim(OrgsField)), @table=ltrim(rtrim(TableName)), @CodeField=CodeField
	from v_TablesOrgsList where ltrim(rtrim(LinqTable))=ltrim(rtrim(@LinqTable))

	IF @enableorgsetup=1 AND ltrim(rtrim(@userOrgs)) <>'' and ltrim(rtrim(@OrgsField)) <> ''
	BEGIN
		Declare @OrgTree Table (VOrganization INT) 

		INSERT INTO @OrgTree
		select distinct OrganizationParentOrChild from OrganizationParentChild o 
		where @userOrgs LIKE '%#'+ltrim(rtrim(o.organization))+'#%' and o.OrgRelation in (2,3)

		----select @OrgsField
		----select * from @OrgTree

	    IF  EXISTS  (select * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @table AND COLUMN_NAME =@OrgsField  ) 
		BEGIN
		 
		 if ltrim(rtrim(@table))=N'Activities'
		 Begin
		    select @rowcnt =Count(*) from Activities where ActivityNo=@code and (exists ( select * from @OrgTree where ActivitiesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivitiesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'ActivityCostItems'
		 Begin
		    select @rowcnt =Count(*) from ActivityCostItems where ActivityCostItem=@code and (exists ( select * from @OrgTree where ActivityCostItemsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivityCostItemsOrgs ='' ))
		 End

		 --ELSE if ltrim(rtrim(@table))=N'ActivityEvents'
		 --Begin
		 --   select @rowcnt =Count(*) from ActivityEvents where trim(str(ActivityNo))+'-'+trim(str(ActivityEvent))=@code and (exists ( select * from @OrgTree where ActivityEventsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivityEventsOrgs ='' ))
		 --End

		  ELSE if ltrim(rtrim(@table))=N'ActivityResourceTypes'
		 Begin
		    select @rowcnt =Count(*) from ActivityResourceTypes where ActivityResourceType=@code and (exists ( select * from @OrgTree where ActivityResourceTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivityResourceTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'ActivityResources'
		 Begin
		    select @rowcnt =Count(*) from ActivityResources where ActivityResource=@code and (exists ( select * from @OrgTree where ActivityResourcesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivityResourcesOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'ActivityRoles'
		 Begin
		    select @rowcnt =Count(*) from ActivityRoles where ActivityRole=@code and (exists ( select * from @OrgTree where ActivityRolesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivityRolesOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'ActivityTypes'
		 Begin
		    select @rowcnt =Count(*) from ActivityTypes where ActivityType=@code and (exists ( select * from @OrgTree where ActivityTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ActivityTypesOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'ApplicationSource'
		 Begin
		    select @rowcnt =Count(*) from ApplicationSource where ApplicationSource=@code and (exists ( select * from @OrgTree where ApplicationSourceOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ApplicationSourceOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'ApplicationStatus'
		 Begin
		    select @rowcnt =Count(*) from ApplicationStatus where ApplicationStatus=@code and (exists ( select * from @OrgTree where ApplicationStatusOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ApplicationStatusOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Appraisals'
		 Begin
		    select @rowcnt =Count(*) from Appraisals where AppraisalNo=@code and (exists ( select * from @OrgTree where AppraisalsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or AppraisalsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'AppraisalActions'
		 Begin
		    select @rowcnt =Count(*) from AppraisalActions where AppraisalAction=@code and (exists ( select * from @OrgTree where AppraisalActionsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or AppraisalActionsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'AppraisalTypes'
		 Begin
		    select @rowcnt =Count(*) from AppraisalTypes where AppraisalType=@code and (exists ( select * from @OrgTree where AppraisalTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or AppraisalTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Areas'
		 Begin
		    select @rowcnt =Count(*) from Areas where Areaid=@code and (exists ( select * from @OrgTree where AreasOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or AreasOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HKItemTypes'
		 Begin
		    select @rowcnt =Count(*) from HKItemTypes where HKItemType=@code and (exists ( select * from @OrgTree where HKItemTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HKItemTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HKItems'
		 Begin
		    select @rowcnt =Count(*) from HKItems where HKItem=@code and (exists ( select * from @OrgTree where HKItemsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HKItemsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Banks'
		 Begin
		    select @rowcnt =Count(*) from Banks where bankno=@code and (exists ( select * from @OrgTree where BanksOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or BanksOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'BenefitItems'
		 Begin
		    select @rowcnt =Count(*) from BenefitItems where ItemNo=@code and (exists ( select * from @OrgTree where BenefitItemsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or BenefitItemsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'BenefitPlanTypes'
		 Begin
		    select @rowcnt =Count(*) from BenefitPlanTypes where PlanType=@code and (exists ( select * from @OrgTree where BenefitPlanTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or BenefitPlanTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'BenefitPlans'
		 Begin
		    select @rowcnt =Count(*) from BenefitPlans where PlanNo=@code and (exists ( select * from @OrgTree where BenefitPlansOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or BenefitPlansOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'CareerPaths'
		 Begin
		    select @rowcnt =Count(*) from CareerPaths where CareerPath=@code and (exists ( select * from @OrgTree where CareerPathsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CareerPathsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'ChngStat'
		 Begin
		    select @rowcnt =Count(*) from ChngStat where chgcode=@code and (exists ( select * from @OrgTree where ChngStatOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ChngStatOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Cities'
		 Begin
		    select @rowcnt =Count(*) from Cities where cityid=@code and (exists ( select * from @OrgTree where CitiesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CitiesOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'CompetenceCategories'
		 Begin
		    select @rowcnt =Count(*) from CompetenceCategories where CompetenceCategory=@code and (exists ( select * from @OrgTree where CompetenceCategoriesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CompetenceCategoriesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'CompetenceTypes'
		 Begin
		    select @rowcnt =Count(*) from CompetenceTypes where CompetenceType=@code and (exists ( select * from @OrgTree where CompetenceTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CompetenceTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Competencies'
		 Begin
		    select @rowcnt =Count(*) from Competencies where Competence=@code and (exists ( select * from @OrgTree where CompetenciesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CompetenciesOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'ContractType'
		 Begin
		    select @rowcnt =Count(*) from ContractType where ContractType=@code and (exists ( select * from @OrgTree where ContractTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ContractTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'CostCGrp'
		 Begin
		    select @rowcnt =Count(*) from CostCGrp where centergrp=@code and (exists ( select * from @OrgTree where CostCGrpOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CostCGrpOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'CostCntr'
		 Begin
		    select @rowcnt =Count(*) from CostCntr where center=@code and (exists ( select * from @OrgTree where CostCntrOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CostCntrOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Countries'
		 Begin
		    select @rowcnt =Count(*) from Countries where Countryid=@code and (exists ( select * from @OrgTree where CountriesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CountriesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Currency'
		 Begin
		    select @rowcnt =Count(*) from Currency where cur=@code and (exists ( select * from @OrgTree where CurrencyOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or CurrencyOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Document'
		 Begin
		    select @rowcnt =Count(*) from Document where docid=@code and (exists ( select * from @OrgTree where DocumentOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or DocumentOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'DocCateg'
		 Begin
		    select @rowcnt =Count(*) from DocCateg where catid=@code and (exists ( select * from @OrgTree where DocCategOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or DocCategOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Duties'
		 Begin
		    select @rowcnt =Count(*) from Duties where DutyId=@code and (exists ( select * from @OrgTree where DutiesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or DutiesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'DutyTypes'
		 Begin
		    select @rowcnt =Count(*) from DutyTypes where DutyType=@code and (exists ( select * from @OrgTree where DutyTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or DutyTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HrStatus'
		 Begin
		    select @rowcnt =Count(*) from HrStatus where HrStatus=@code and (exists ( select * from @OrgTree where HrStatusOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HrStatusOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Employer'
		 Begin
		    select @rowcnt =Count(*) from Employer where EmployerId=@code and (exists ( select * from @OrgTree where EmployerOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or EmployerOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'EstablishmentType'
		 Begin
		    select @rowcnt =Count(*) from EstablishmentType where EstablishmentType=@code and (exists ( select * from @OrgTree where EstablishmentTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or EstablishmentTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Establishment'
		 Begin
		    select @rowcnt =Count(*) from Establishment where Establishment=@code and (exists ( select * from @OrgTree where EstablishmentOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or EstablishmentOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'GradeGroups'
		 Begin
		    select @rowcnt =Count(*) from GradeGroups where GradeGroup=@code and (exists ( select * from @OrgTree where GradeGroupsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or GradeGroupsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Grades'
		 Begin
		    select @rowcnt =Count(*) from Grades where Grade=@code and (exists ( select * from @OrgTree where GradesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or GradesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'GraduateType'
		 Begin
		    select @rowcnt =Count(*) from GraduateType where GradType=@code and (exists ( select * from @OrgTree where GraduateTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or GraduateTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Graduate'
		 Begin
		    select @rowcnt =Count(*) from Graduate where Graduate=@code and (exists ( select * from @OrgTree where GraduateOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or GraduateOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Groups'
		 Begin
		    select @rowcnt =Count(*) from Groups where GroupNo=@code and (exists ( select * from @OrgTree where GroupsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or GroupsOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'HRBudget'
		 Begin
		    select @rowcnt =Count(*) from HRBudget where BudgetNo=@code and (exists ( select * from @OrgTree where HRBudgetOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRBudgetOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRCalendar'
		 Begin
		    select @rowcnt =Count(*) from HRCalendar where CalendarNo=@code and (exists ( select * from @OrgTree where HRCalendarOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRCalendarOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevInterventionTypes'
		 Begin
		    select @rowcnt =Count(*) from HRDevInterventionTypes where InterventionTypeNo=@code and (exists ( select * from @OrgTree where HRDevInterventionTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevInterventionTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevPlanStages'
		 Begin
		    select @rowcnt =Count(*) from HRDevPlanStages where PlanStageNo=@code and (exists ( select * from @OrgTree where HRDevPlanStagesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevPlanStagesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevPlans'
		 Begin
		    select @rowcnt =Count(*) from HRDevPlans where PlanNo=@code and (exists ( select * from @OrgTree where HRDevPlansOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevPlansOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevSkillElements'
		 Begin
		    select @rowcnt =Count(*) from HRDevSkillElements where SkillElementNo=@code and (exists ( select * from @OrgTree where HRDevSkillElementsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevSkillElementsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevSkillGroups'
		 Begin
		    select @rowcnt =Count(*) from HRDevSkillGroups where SkillGroupNo=@code and (exists ( select * from @OrgTree where HRDevSkillGroupsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevSkillGroupsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevSkills'
		 Begin
		    select @rowcnt =Count(*) from HRDevSkills where SkillNo=@code and (exists ( select * from @OrgTree where HRDevSkillsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevSkillsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevStageElementInterventions'
		 Begin
		    select @rowcnt =Count(*) from HRDevStageElementInterventions where InterventionNo=@code and (exists ( select * from @OrgTree where HRDevStageElementInterventionsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevStageElementInterventionsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevStageElementKPIS'
		 Begin
		    select @rowcnt =Count(*) from HRDevStageElementKPIS where KPINo=@code and (exists ( select * from @OrgTree where HRDevStageElementKPISOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevStageElementKPISOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRDevSubSkills'
		 Begin
		    select @rowcnt =Count(*) from HRDevSubSkills where SubSkillNo=@code and (exists ( select * from @OrgTree where HRDevSubSkillsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRDevSubSkillsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'OrganizationType'
		 Begin
		    select @rowcnt =Count(*) from OrganizationType where OrganizationType=@code and (exists ( select * from @OrgTree where OrganizationTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or OrganizationTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'HRRequest'
		 Begin
		    select @rowcnt =Count(*) from HRRequest where HRReqCode=@code and (exists ( select * from @OrgTree where HRRequestOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or HRRequestOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'InterviewTypes'
		 Begin
		    select @rowcnt =Count(*) from InterviewTypes where InterviewType=@code and (exists ( select * from @OrgTree where InterviewTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or InterviewTypesOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'JobCat'
		 Begin
		    select @rowcnt =Count(*) from JobCat where jobcat=@code and (exists ( select * from @OrgTree where JobCatOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or JobCatOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'JobCatGrp'
		 Begin
		    select @rowcnt =Count(*) from JobCatGrp where JobCatGrp=@code and (exists ( select * from @OrgTree where JobCatGrpOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or JobCatGrpOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'Jobs'
		 Begin
		    select @rowcnt =Count(*) from Jobs where Job=@code and (exists ( select * from @OrgTree where JobsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or JobsOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'KPIElementGroups'
		 Begin
		    select @rowcnt =Count(*) from KPIElementGroups where KPIElementGroup=@code and (exists ( select * from @OrgTree where KPIElementGroupsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or KPIElementGroupsOrgs ='' ))
		 End

		  ELSE if ltrim(rtrim(@table))=N'KPIElementItems'
		 Begin
		    select @rowcnt =Count(*) from KPIElementItems where KPIElementItem=@code and (exists ( select * from @OrgTree where KPIElementItemsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or KPIElementItemsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'KPIElementTypes'
		 Begin
		    select @rowcnt =Count(*) from KPIElementTypes where KPIElementType=@code and (exists ( select * from @OrgTree where KPIElementTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or KPIElementTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'KPIGroups'
		 Begin
		    select @rowcnt =Count(*) from KPIGroups where KPIGroup=@code and (exists ( select * from @OrgTree where KPIGroupsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or KPIGroupsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'KPIs'
		 Begin
		    select @rowcnt =Count(*) from KPIs where KPI=@code and (exists ( select * from @OrgTree where KPIsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or KPIsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Location'
		 Begin
		    select @rowcnt =Count(*) from Location where LocationNo=@code and (exists ( select * from @OrgTree where LocationOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or LocationOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'MedicalCategories'
		 Begin
		    select @rowcnt =Count(*) from MedicalCategories where MedicalCategory=@code and (exists ( select * from @OrgTree where MedicalCategoriesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or MedicalCategoriesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'MedicalItems'
		 Begin
		    select @rowcnt =Count(*) from MedicalItems where MedicalItem=@code and (exists ( select * from @OrgTree where MedicalItemsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or MedicalItemsOrgs ='' ))
		 End

		    ELSE if ltrim(rtrim(@table))=N'Mscondct'
		 Begin
		    select @rowcnt =Count(*) from Mscondct where mscode=@code and (exists ( select * from @OrgTree where MscondctOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or MscondctOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Nations'
		 Begin
		    select @rowcnt =Count(*) from Nations where nationid=@code and (exists ( select * from @OrgTree where NationsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or NationsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'OrganizationDuties'
		 Begin
		    select @rowcnt =Count(*) from OrganizationDuties where DutyId=@code and (exists ( select * from @OrgTree where OrganizationDutiesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or OrganizationDutiesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'PaycdGrp'
		 Begin
		    select @rowcnt =Count(*) from PaycdGrp where grpcode=@code and (exists ( select * from @OrgTree where PaycdGrpOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or PaycdGrpOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Paycode'
		 Begin
		    select @rowcnt =Count(*) from Paycode where code=@code and (exists ( select * from @OrgTree where PaycodeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or PaycodeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'PaymentTypes'
		 Begin
		    select @rowcnt =Count(*) from PaymentTypes where PaymentType=@code and (exists ( select * from @OrgTree where PaymentTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or PaymentTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'PayrollGroup'
		 Begin
		    select @rowcnt =Count(*) from PayrollGroup where PayrollGroup=@code and (exists ( select * from @OrgTree where PayrollGroupOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or PayrollGroupOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'BenefitOptions'
		 Begin
		    select @rowcnt =Count(*) from BenefitOptions where OptionNo=@code and (exists ( select * from @OrgTree where BenefitOptionsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or BenefitOptionsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'PoliceStations'
		 Begin
		    select @rowcnt =Count(*) from PoliceStations where PoliceStationid=@code and (exists ( select * from @OrgTree where PoliceStationsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or PoliceStationsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Positions'
		 Begin
		    select @rowcnt =Count(*) from Positions where PositionNo=@code and (exists ( select * from @OrgTree where PositionsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or PositionsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Provinces'
		 Begin
		    select @rowcnt =Count(*) from Provinces where Provinceid=@code and (exists ( select * from @OrgTree where ProvincesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ProvincesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'QualificationGradeType'
		 Begin
		    select @rowcnt =Count(*) from QualificationGradeType where QualificationGradeType=@code and (exists ( select * from @OrgTree where QualificationGradeTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or QualificationGradeTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'QualificationGrade'
		 Begin
		    select @rowcnt =Count(*) from QualificationGrade where QualificationGrade=@code and (exists ( select * from @OrgTree where QualificationGradeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or QualificationGradeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'QualificationMajor'
		 Begin
		    select @rowcnt =Count(*) from QualificationMajor where QualificationMajor=@code and (exists ( select * from @OrgTree where QualificationMajorOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or QualificationMajorOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'QualificationMajorType'
		 Begin
		    select @rowcnt =Count(*) from QualificationMajorType where QualificationMajorType=@code and (exists ( select * from @OrgTree where QualificationMajorTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or QualificationMajorTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'QualificationType'
		 Begin
		    select @rowcnt =Count(*) from QualificationType where QualificationType=@code and (exists ( select * from @OrgTree where QualificationTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or QualificationTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Qualification'
		 Begin
		    select @rowcnt =Count(*) from Qualification where QualificationNo=@code and (exists ( select * from @OrgTree where QualificationOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or QualificationOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'RatingScales'
		 Begin
		    select @rowcnt =Count(*) from RatingScales where RatingScale=@code and (exists ( select * from @OrgTree where RatingScalesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or RatingScalesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'RecruitmentActivities'
		 Begin
		    select @rowcnt =Count(*) from RecruitmentActivities where RecruitmentActivity=@code and (exists ( select * from @OrgTree where RecruitmentActivitiesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or RecruitmentActivitiesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'RecruitmentTypes'
		 Begin
		    select @rowcnt =Count(*) from RecruitmentTypes where RecruitmentType=@code and (exists ( select * from @OrgTree where RecruitmentTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or RecruitmentTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'RelationType'
		 Begin
		    select @rowcnt =Count(*) from RelationType where RelationType=@code and (exists ( select * from @OrgTree where RelationTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or RelationTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingBlockReasons'
		 Begin
		    select @rowcnt =Count(*) from TrainingBlockReasons where BlockReason=@code and (exists ( select * from @OrgTree where TrainingBlockReasonsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingBlockReasonsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'StaffRoomTypes'
		 Begin
		    select @rowcnt =Count(*) from StaffRoomTypes where RoomType=@code and (exists ( select * from @OrgTree where StaffRoomTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or StaffRoomTypesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'SalaryScales'
		 Begin
		    select @rowcnt =Count(*) from SalaryScales where SalaryScaleid=@code and (exists ( select * from @OrgTree where SalaryScalesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or SalaryScalesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'SsRules'
		 Begin
		    select @rowcnt =Count(*) from SsRules where sscode=@code and (exists ( select * from @OrgTree where SsRulesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or SsRulesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'ServiceType'
		 Begin
		    select @rowcnt =Count(*) from ServiceType where ServiceType=@code and (exists ( select * from @OrgTree where ServiceTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ServiceTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Service'
		 Begin
		    select @rowcnt =Count(*) from [Service] where ServiceNo=@code and (exists ( select * from @OrgTree where ServiceOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or ServiceOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'StaffBuildings'
		 Begin
		    select @rowcnt =Count(*) from StaffBuildings where BuildingNo=@code and (exists ( select * from @OrgTree where StaffBuildingsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or StaffBuildingsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'StaffRooms'
		 Begin
		    select @rowcnt =Count(*) from StaffRooms where RoomIdentity=@code and (exists ( select * from @OrgTree where StaffRoomsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or StaffRoomsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'SupplierType'
		 Begin
		    select @rowcnt =Count(*) from SupplierType where SupplierType=@code and (exists ( select * from @OrgTree where SupplierTypeOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or SupplierTypeOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Supplier'
		 Begin
		    select @rowcnt =Count(*) from Supplier where SupplierNo=@code and (exists ( select * from @OrgTree where SupplierOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or SupplierOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TaskCat'
		 Begin
		    select @rowcnt =Count(*) from TaskCat where TaskCat=@code and (exists ( select * from @OrgTree where TaskCatOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TaskCatOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TaxAgencies'
		 Begin
		    select @rowcnt =Count(*) from TaxAgencies where TaxAgency=@code and (exists ( select * from @OrgTree where TaxAgenciesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TaxAgenciesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TaxRules'
		 Begin
		    select @rowcnt =Count(*) from TaxRules where taxcode=@code and (exists ( select * from @OrgTree where TaxRulesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TaxRulesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TimePermission'
		 Begin
		    select @rowcnt =Count(*) from TimePermission where PermissionNo=@code and (exists ( select * from @OrgTree where TimePermissionOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TimePermissionOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TimeRules'
		 Begin
		    select @rowcnt =Count(*) from TimeRules where TimeRule=@code and (exists ( select * from @OrgTree where TimeRulesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TimeRulesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TimeShifts'
		 Begin
		    select @rowcnt =Count(*) from TimeShifts where ShiftNo=@code and (exists ( select * from @OrgTree where TimeShiftsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TimeShiftsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingActivities'
		 Begin
		    select @rowcnt =Count(*) from TrainingActivities where TrainingActivity=@code and (exists ( select * from @OrgTree where TrainingActivitiesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingActivitiesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingCategories'
		 Begin
		    select @rowcnt =Count(*) from TrainingCategories where TrainingCategory=@code and (exists ( select * from @OrgTree where TrainingCategoriesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingCategoriesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingCenters'
		 Begin
		    select @rowcnt =Count(*) from TrainingCenters where TrainingCenter=@code and (exists ( select * from @OrgTree where TrainingCentersOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingCentersOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingCostItems'
		 Begin
		    select @rowcnt =Count(*) from TrainingCostItems where TrainingCostItem=@code and (exists ( select * from @OrgTree where TrainingCostItemsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingCostItemsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingEnrollStatus'
		 Begin
		    select @rowcnt =Count(*) from TrainingEnrollStatus where EnrollStatus=@code and (exists ( select * from @OrgTree where TrainingEnrollStatusOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingEnrollStatusOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingEvals'
		 Begin
		    select @rowcnt =Count(*) from TrainingEvals where TrainingEval=@code and (exists ( select * from @OrgTree where TrainingEvalsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingEvalsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingEventStatus'
		 Begin
		    select @rowcnt =Count(*) from TrainingEventStatus where EventStatus=@code and (exists ( select * from @OrgTree where TrainingEventStatusOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingEventStatusOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingEvents'
		 Begin
		    select @rowcnt =Count(*) from TrainingEvents where TrainingEvent=@code and (exists ( select * from @OrgTree where TrainingEventsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingEventsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingMethods'
		 Begin
		    select @rowcnt =Count(*) from TrainingMethods where TrainingMethod=@code and (exists ( select * from @OrgTree where TrainingMethodsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingMethodsOrgs ='' ))
		 End

		 --ELSE if ltrim(rtrim(@table))=N'TrainingPlanBudgets'
		 --Begin
		 --   select @rowcnt =Count(*) from TrainingPlanBudgets where trim(str(TrainingPlan))+'-'+trim(str(BudgetNo))=@code and (exists ( select * from @OrgTree where TrainingPlanBudgetsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingPlanBudgetsOrgs ='' ))
		 --End

		 ELSE if ltrim(rtrim(@table))=N'TrainingPlans'
		 Begin
		    select @rowcnt =Count(*) from TrainingPlans where TrainingPlan=@code and (exists ( select * from @OrgTree where TrainingPlansOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingPlansOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingResourceTypes'
		 Begin
		    select @rowcnt =Count(*) from TrainingResourceTypes where TrainingResourceType=@code and (exists ( select * from @OrgTree where TrainingResourceTypesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingResourceTypesOrgs ='' ))
		 End

		 --ELSE if ltrim(rtrim(@table))=N'TrainingResources'
		 --Begin
		 --   select @rowcnt =Count(*) from TrainingResources where trim(str(TrainingResource))+'-'+trim(str(resourcecategory))=@code and (exists ( select * from @OrgTree where TrainingResourcesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingResourcesOrgs ='' ))
		 --End

		 ELSE if ltrim(rtrim(@table))=N'TrainingSessions'
		 Begin
		    select @rowcnt =Count(*) from TrainingSessions where TrainingSession=@code and (exists ( select * from @OrgTree where TrainingSessionsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingSessionsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingSubjectCategories'
		 Begin
		    select @rowcnt =Count(*) from TrainingSubjectCategories where TrainingSubjectCategory=@code and (exists ( select * from @OrgTree where TrainingSubjectCategoriesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingSubjectCategoriesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'TrainingSubjects'
		 Begin
		    select @rowcnt =Count(*) from TrainingSubjects where TrainingSubject=@code and (exists ( select * from @OrgTree where TrainingSubjectsOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or TrainingSubjectsOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Vacancies'
		 Begin
		    select @rowcnt =Count(*) from Vacancies where VacancyNo=@code and (exists ( select * from @OrgTree where VacanciesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or VacanciesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'VacancyCategories'
		 Begin
		    select @rowcnt =Count(*) from VacancyCategories where VacancyCategory=@code and (exists ( select * from @OrgTree where VacancyCategoriesOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or VacancyCategoriesOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'VacancyStatus'
		 Begin
		    select @rowcnt =Count(*) from VacancyStatus where VacancyStatus=@code and (exists ( select * from @OrgTree where VacancyStatusOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or VacancyStatusOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'VacationDue'
		 Begin
		    select @rowcnt =Count(*) from VacationDue where VacDueCode=@code and (exists ( select * from @OrgTree where VacationDueOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or VacationDueOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'VacPack'
		 Begin
		    select @rowcnt =Count(*) from VacPack where vacpack=@code and (exists ( select * from @OrgTree where VacPackOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or VacPackOrgs ='' ))
		 End

		 ELSE if ltrim(rtrim(@table))=N'Vacation'
		 Begin
		    select @rowcnt =Count(*) from Vacation where vaccode=@code and (exists ( select * from @OrgTree where VacationOrgs LIKE '%#'+ltrim(rtrim(VOrganization))+'#%' or VacationOrgs ='' ))
		 End

		--	  select @OrgsExists=' DECLARE @OrgTree TABLE (VOrganization INT)
  --                      INSERT INTO @OrgTree
		--select distinct OrganizationParentOrChild from OrganizationParentChild o 
		--where '''+@userOrgs+''' LIKE ''%#''+ltrim(rtrim(o.organization))+''#%'' and o.OrgRelation in (2,3)

		--	  select Count(*) from '+ @table+' where '+@CodeField+'='+@code+' and (exists ( select * from @OrgTree where '+@OrgsField+' LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or '+@OrgsField+' ='''' ))'
		--	  EXEC sp_executesql @OrgsExists,N'@cnt int out' ,@cnt=@rowcnt output


			  if @rowcnt<>0
			  return 1
			  else
			  return 0


		END    
END
return 1
END

GO

