create FUNCTION [dbo].[CheckAppraisalCompRating]
(
	@Empid as int,@Documentno as int,@AppraisalNo as SMALLINT, @Competence as SMALLINT,@Perflevel as SMALLINT, @Proflevel as SMALLINT
)
RETURNS smallint
AS
BEGIN
declare @PerfLevelPercent as numeric(18,3),@CompProfPercent as numeric(18,3),@MinPercent as numeric(18,3)=0,@MaxPercent as numeric(18,3)=0
, @checkRatingLevel SMALLINT=0
SELECT @MinPercent= ConfigValue FROM dbo.SysParamConfig WHERE ConfigID = 'MinProficiencyRating'
SELECT @MaxPercent= ConfigValue FROM dbo.SysParamConfig WHERE ConfigID = 'MaxProficiencyRating'

IF @AppraisalNo<>0
BEGIN

	SELECT @PerfLevelPercent=LevelPercent from RatingLevels
	LEFT JOIN dbo.Appraisals ON Appraisals.RatingScale = RatingLevels.RatingScale
	WHERE AppraisalNo=@AppraisalNo AND RatingLevel=@Perflevel

	IF @PerfLevelPercent<@MinPercent OR @PerfLevelPercent>=@MaxPercent
	SET @checkRatingLevel=1
END

IF @Competence<>0
BEGIN

	SELECT @CompProfPercent=LevelPercent FROM dbo.LevelsCompetence
	WHERE Competence=@Competence AND RatingLevel=@Proflevel

	IF @CompProfPercent<@MinPercent OR @CompProfPercent>=@MaxPercent
	SET @checkRatingLevel=1

END
return @checkRatingLevel


	

END

GO

