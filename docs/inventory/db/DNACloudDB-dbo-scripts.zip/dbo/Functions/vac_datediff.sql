-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION vac_datediff 
(
	@vac_startdate1 AS smalldatetime,@vac_enddate1 AS smalldatetime
)
RETURNS numeric(18,3)
AS
BEGIN
declare  @vac_tempdate as smalldatetime, @months as numeric(18,3)
--select @vac_startdate1='20110216', @vac_enddate1='20110315'
declare @mm as smallint
set @mm=0
while 1=1
begin
set @mm=@mm+1
set @vac_tempdate=dateadd(mm,@mm,@vac_startdate1)-1
if @vac_tempdate>@vac_enddate1 break
end 
set @months=(@mm-1)+datediff(dd,dateadd(mm,@mm-1,@vac_startdate1),@vac_enddate1+1)*1.000/30.000
return @months


END

GO

