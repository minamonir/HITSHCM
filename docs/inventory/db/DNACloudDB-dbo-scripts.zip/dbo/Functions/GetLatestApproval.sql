
--this fn selects one of role for profiles who have more than one role from WFDocApproval
CREATE FUNCTION [dbo].[GetLatestApproval]  (@EmpId int,@DocumentNo int,@SSDocType smallint,@RoleProfileID int)
RETURNS INT AS  
BEGIN
	
	DECLARE @RoleID AS smallint--, @MaxDate AS DATETIME

	SELECT TOP 1 @RoleID = RoleID 
	FROM WFDocApproval
	INNER JOIN SSDocument
	ON SSDocument.SSDocNo = WFDocApproval.SSDocNo 
	WHERE ApprovalProfileId = @RoleProfileID
	AND SSDocument.SSDocType = @SSDocType
	AND WFDocApproval.DocumentNo = @DocumentNo
	AND WFDocApproval.EmpID = @EmpId
	ORDER BY ApprovalDate Desc


	--SELECT @RoleID = WFDocApproval.RoleID, @MaxDate = MAX(WFDocApproval.ApprovalDate) 
	--FROM WFDocApproval
	--INNER JOIN SSDocument ON SSDocument.SSDocNo = WFDocApproval.SSDocNo 
	--WHERE WFDocApproval.ApprovalProfileId = @RoleProfileID
	--AND SSDocument.SSDocType = @SSDocType
	--GROUP BY WFDocApproval.RoleId, WFDocApproval.SSDocNo, SSDocument.SSDocType


RETURN @RoleID
END

GO

