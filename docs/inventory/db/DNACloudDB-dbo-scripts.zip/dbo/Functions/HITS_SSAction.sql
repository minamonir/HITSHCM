


CREATE    FUNCTION HITS_SSAction (@doctype as int = null , @empid as int  = null , @docno as int  = null, @ssgroup as int = null ,@roleid as int  = null)
RETURNS BIT AS  
BEGIN 
declare @lastoprovalorder as int
declare @lastrolestatus as int
declare @myorder as int
declare @ApprovalRequired bit

declare @firstorder as int
declare @firstorderapproval as bit


--SELECT     @myorder=RoleOrder-
--FROM         SSDocumentRole
--WHERE     (SSDocNo = @doctype) AND (RoleId = @roleid)

--SELECT    top 1 @firstorder=RoleOrder , @firstorderapproval = ApprovalRequired
--FROM         SSDocumentRole
--WHERE     (SSDocNo = @doctype)  
--order by RoleOrder  

--if    @doctype = 2
--SELECT      TOP 1 @lastoprovalorder = SSDocumentRole.RoleOrder, @lastrolestatus = EmpVacatApproval.ApprovalStatus,@ApprovalRequired = SSDocumentRole.ApprovalRequired
--FROM         EmpVacatApproval INNER JOIN
--                      EmpAssignment ON EmpVacatApproval.EmpId = EmpAssignment.EmpId INNER JOIN
 --                     SSDocumentRole ON EmpVacatApproval.RoleId = SSDocumentRole.RoleId
--WHERE     (EmpAssignment.SSGroup = @ssgroup) AND (SSDocumentRole.SSDocNo = @doctype)  and EmpVacatApproval.EmpId = @empid and  EmpVacatApproval.DocumentNo=@docno
--ORDER BY SSDocumentRole.RoleOrder DESC

--set @lastoprovalorder = isnull(@lastoprovalorder , @firstorder)
--set @lastrolestatus   = isnull(@lastrolestatus , 0)
--set @ApprovalRequired = isnull(@ApprovalRequired , @firstorderapproval)

--if (@firstorder =  @myorder and @lastoprovalorder = @firstorder and @lastrolestatus= 0 )  return 1
--( (@lastoprovalorder <  @myorder)      and     ( @ApprovalRequired =0) ) or
--if   ( (@lastoprovalorder <  @myorder)      and     ( @lastrolestatus = 1 and @ApprovalRequired =1) )    return 1




SELECT     @myorder=RoleOrder
FROM         SSDocumentRole
WHERE     (SSDocNo = @doctype) AND (RoleId = @roleid)

SELECT    top 1 @firstorder=RoleOrder , @firstorderapproval = ApprovalRequired
FROM         SSDocumentRole
WHERE     (SSDocNo = @doctype) and ApprovalRequired = 1  
order by RoleOrder  

if    @doctype = 2

SELECT      TOP 1 @lastoprovalorder = SSDocumentRole.RoleOrder, 
                  @lastrolestatus   = EmpVacatApproval.ApprovalStatus,
                  @ApprovalRequired = SSDocumentRole.ApprovalRequired
FROM         EmpVacatApproval INNER JOIN
                      EmpAssignment ON EmpVacatApproval.EmpId = EmpAssignment.EmpId INNER JOIN
                      SSDocumentRole ON EmpVacatApproval.RoleId = SSDocumentRole.RoleId
WHERE     (EmpAssignment.SSGroup = @ssgroup) AND (SSDocumentRole.SSDocNo = @doctype)  and EmpVacatApproval.EmpId = @empid and  EmpVacatApproval.DocumentNo=@docno
ORDER BY SSDocumentRole.RoleOrder DESC


set @lastoprovalorder = isnull(@lastoprovalorder , @firstorder)
set @lastrolestatus   = isnull(@lastrolestatus , 0)
set @ApprovalRequired = isnull(@ApprovalRequired , @firstorderapproval)

if (@myorder <= @firstorder and  @lastrolestatus = 0  )  return 1
if    ( (@lastoprovalorder <  @myorder)      and    (  @ApprovalRequired =0 or ( @lastrolestatus = 1 and @ApprovalRequired =1)  )  )     return 1

--if    ( (@lastoprovalorder <  @myorder)      and    (  @ApprovalRequired =0 or ( @lastrolestatus = 1 and @ApprovalRequired =1)  )  )     return 1



return 0 

END

GO

