CREATE        FUNCTION [dbo].[GetWFActionReason]
  (@RoleProfileid int, @DocumentNo int, @Empid int ,  @ssdocno as smallint )
RETURNS  nvarchar(max)
as
BEGIN

DECLARE @ActionReason AS nvarchar(max)=''
declare @LastApprovedOrder AS SMALLINT



SELECT  
@LastApprovedOrder=MAX(CASE WHEN ApprovalStatus IS NOT NULL THEN RoleOrder ELSE -1 END)
 FROM   dbo.WFDocApproval WITH (NOLOCK) where
  WFDocApproval.EmpID =@empid and WFDocApproval.DocumentNo =@DocumentNo  AND WFDocApproval.SSDocNo=@ssdocno




SET @LastApprovedOrder=ISNULL(@LastApprovedOrder,-1)	

select top 1  @ActionReason=CASE WHEN wfdocapproval.ApprovalDate is null THEN 
                                  case when (ltrim(rtrim(isnull(actionresaon,''))) = ''  and  ltrim(rtrim(isnull(InvitationMessage,''))) <>  '' )
								         or (ltrim(rtrim(isnull(actionresaon,''))) <> '' and ltrim(rtrim(isnull(InvitationMessage,''))) = '')
										 or (ltrim(rtrim(isnull(actionresaon,''))) = '' and ltrim(rtrim(isnull(InvitationMessage,''))) = '') then   ltrim(rtrim(isnull(actionresaon,''))) +ltrim(rtrim(isnull(InvitationMessage,'')))  
								  else  ltrim(rtrim(isnull(actionresaon,''))) +' - '+ltrim(rtrim(isnull(InvitationMessage,''))) end ELSE actionresaon END  

--CASE WHEN wfdocapproval.ApprovalDate is null THEN  ltrim(rtrim(isnull(actionresaon,''))) +' - '+ltrim(rtrim(isnull(InvitationMessage,'')))  ELSE actionresaon END   

from wfdocapproval WITH (NOLOCK) 
left join WFDocInvitation on wfdocapproval.SSDocNo=WFDocInvitation.SSDocNo
						 and wfdocapproval.DocumentNo=WFDocInvitation.DocumentNo		
					 	 and wfdocapproval.EmpID=WFDocInvitation.EmpID
						 AND WFDocApproval.roleid=WFDocInvitation.InvitedRoleid 
						 AND WFDocApproval.ApprovalProfileId=WFDocInvitation.InvitedRoleProfileid 
                         AND  ISNULL(WFDocApproval.InvitedByRole,0) =WFDocInvitation.RoleId
						 and WFDocApproval.delegated in(2,3) and WFDocApproval.delegatedby=WFDocInvitation.roleprofileid
						 --AND WFDocInvitation.RoleId = @Roleid

where  wfdocapproval.empid=@empid and wfdocapproval.documentno=@DocumentNo and wfdocapproval.ssdocno=@ssdocno and approvalprofileid=@RoleProfileid
and approvalstatus is null and roleorder>=@LastApprovedOrder order by roleorder 



RETURN isnull(@ActionReason,'') 
END

GO

