--USE [DNACloudDB]
--GO
--/****** Object:  UserDefinedFunction [dbo].[Z_CustomAnnualSalary]    Script Date: 7/14/2019 9:33:46 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
CREATE FUNCTION [dbo].[emphiretermdaysnew](@empid as INT,@fromdate SMALLDATETIME,@todate AS SMALLDATETIME,@type AS SMALLINT)
RETURNS NUMERIC(18,3)
AS
BEGIN
DECLARE @Count AS SMALLINT=0  ,@dayoff1 AS SMALLINT=0 , @dayoff2 AS SMALLINT =0
SELECT @dayoff1=1
,@dayoff2=0

FROM EmpAssignment WHERE empid=@EmpId

WHILE @fromDate<=@toDate and @type<>3
BEGIN
	IF DATEPART(dw,@fromDate)=@dayoff1 OR DATEPART(dw,@fromDate)=@dayoff2
	BEGIN
		SET @Count=@Count+1
	END
	SET @fromDate=DATEADD(DAY,1,@fromDate)
END


if @type=3
begin
declare @noofmonth as numeric (18,3)=0.0,@nonwoking as smallint,@historynonwoking as smallint

select @noofmonth= cmonth from PayrollGroup inner join EmpAssignment on EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup where empid=@empid

select @nonwoking=  MonthlyTransaction.InputAmnt from MonthlyTransaction where paycode in (select code from paycode where HireAppl=1 or TermAppl=1) and empid=@empid
 
select @historynonwoking=HistoryTransaction.InputAmnt from HistoryTransaction 
 inner join EmpAssignment on EmpAssignment.empid=HistoryTransaction.empid
 inner join PayrollGroup on EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
where paycode in (select code from paycode where HireAppl=1 or TermAppl=1)
and EmpAssignment.empid=@empid and year*100+month between cyear*100+1 and cyear*100 + cmonth
set @count=0.0
set @count=isnull(@noofmonth,0)-isnull(@nonwoking,0)/30.0
end

RETURN @count 
END

GO

