CREATE FUNCTION [dbo].[Z_CustomAnnualSalary](@empid as INT ,@value as NUMERIC(18,3),@Type AS smallint )
RETURNS NUMERIC(18,3)
AS
BEGIN
DECLARE @customAnnual AS SMALLINT =0
DECLARE @noofperiods AS SMALLINT ,@annualvalue AS NUMERIC(18,3)
SELECT @customAnnual=isnull(configvalue,0) FROM sysparamconfig WHERE ConfigID='CustomAnnual'

IF @empid=0
BEGIN

IF @Type=0
	SELECT @annualvalue=@value * 12  
	ELSE 
	SELECT @annualvalue=@value / 12  
	RETURN @annualvalue
end

IF @customAnnual=0
BEGIN
	select @noofperiods=noofperiods 
	FROM empassignment 
	LEFT JOIN payrollgroup ON payrollgroup.PayrollGroup = empassignment.PayrollGroup
	WHERE empid=@empid
	IF @Type=0
	SELECT @annualvalue=@value * CASE WHEN @noofperiods=0 THEN 12 ELSE @noofperiods END 
	ELSE 
	SELECT @annualvalue=@value / CASE WHEN @noofperiods=0 THEN 12 ELSE @noofperiods END 
END
ELSE IF @customAnnual=1
BEGIN
		select @noofperiods=CASE WHEN empassignment.HrScStatus=2 THEN  12 
		                         WHEN empassignment.HrScStatus=3 THEN  13 
		                         WHEN empassignment.HrScStatus=4 THEN  14
		                     ELSE 12 END     
	FROM empassignment 
	WHERE empid=@empid
	IF @Type=0
	SELECT @annualvalue=@value * @noofperiods  
	ELSE 
	SELECT @annualvalue=@value / @noofperiods  
END


RETURN @annualvalue
END

GO

