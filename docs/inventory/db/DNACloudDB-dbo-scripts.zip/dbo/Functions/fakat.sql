CREATE FUNCTION [dbo].[fakat] (@n numeric(18,3),@lang nchar(1),@cur smallint)
returns nvarchar(max) as 
begin

if @n <= 0
   return 'zero'

declare @Only as nchar(20)
select @only=case when @lang='E' OR @lang='F' then only else aonly end  from currency where currency.cur=@cur


declare   @THOUSAND TABLE (num int,  enwrd nvarchar(80) collate database_default ,arwrd nvarchar(80) collate database_default)
INSERT INTO @THOUSAND VALUES (0,N'',N'')  
INSERT INTO @THOUSAND VALUES (1,CASE WHEN @lang='F' THEN 'Un' 
                                     WHEN @lang='E' THEN 'One' END ,N'واحد')
INSERT INTO @THOUSAND VALUES (2,CASE WHEN @lang='F' THEN 'Deux'
                                     WHEN @lang='E' THEN 'Two' END ,N'اثنان')
INSERT INTO @THOUSAND VALUES (3,CASE WHEN @lang='F' then 'Trois'
                                     WHEN @lang='E' THEN 'Three' END,N'ثلاثة')
INSERT INTO @THOUSAND VALUES (4,CASE WHEN @lang='F' then 'Quatre'
                                     WHEN @lang='E' then 'Four' END,N'اربعة')
INSERT INTO @THOUSAND VALUES (5,CASE WHEN @lang='F' THEN 'Cinq'
                                     WHEN @lang='E' THEN 'Five' END,N'خمسة')
INSERT INTO @THOUSAND VALUES (6,CASE WHEN @lang='F' THEN 'Six'
                                     WHEN @lang='E' THEN 'Six' END,N'ستة')
INSERT INTO @THOUSAND VALUES (7,CASE WHEN @lang='F' THEN 'Sept'
                                     WHEN @lang='E' THEN 'Seven' END,N'سبعة')
INSERT INTO @THOUSAND VALUES (8,CASE WHEN @lang='F' THEN 'Huit'
                                     WHEN @lang='E' THEN 'Eight' END,N'ثمانية')
INSERT INTO @THOUSAND VALUES (9,CASE WHEN @lang='F' THEN 'Neuf'
                                     WHEN @lang='E' THEN 'Nine' END,N'تسعة')
INSERT INTO @THOUSAND VALUES (10,CASE WHEN @lang='F'THEN 'Dix'
                                      WHEN @lang='E' THEN 'Ten' END,N'عشرة')
INSERT INTO @THOUSAND VALUES (11,CASE WHEN @lang='F' THEN 'Onze'
                                      WHEN @lang='E' THEN 'Eleven' END,N'احدى عشر')
INSERT INTO @THOUSAND VALUES (12,CASE WHEN @lang='F' THEN 'Douze'
                                      WHEN @lang='E' THEN 'Twelve' END,N'اثنى عشر')
INSERT INTO @THOUSAND VALUES (13,CASE WHEN @lang='F' THEN 'Treize'
                                      WHEN @lang='E' THEN 'Thirteen' END,N'ثلاثة عشر')
INSERT INTO @THOUSAND VALUES (14,CASE WHEN @lang='F' THEN 'Quatorze'
                                      WHEN @lang='E' THEN 'Fourteen' END,N'اربعة عشر')
INSERT INTO @THOUSAND VALUES (15,CASE WHEN @lang='F' THEN 'Quinze' 
                                      WHEN @lang='E' THEN 'Fifteen' END,N'خمسة عشر')
INSERT INTO @THOUSAND VALUES (16,CASE WHEN @lang='F' THEN 'Seize'
                                      WHEN @lang='E' THEN 'Sixteen' END,N'ستة عشر')
INSERT INTO @THOUSAND VALUES (17,CASE WHEN @lang='F' THEN 'Dix-sept'
                                      WHEN @lang='E' THEN 'Seventeen' END,N'سبعة عشر')
INSERT INTO @THOUSAND VALUES (18,CASE WHEN @lang='F' THEN 'Dix-huit'
                                      WHEN @lang='E' THEN 'Eighteen' END,N'ثمانية عشر')
INSERT INTO @THOUSAND VALUES (19,CASE WHEN @lang='F' THEN 'Dix-neuf'
                                      WHEN @lang='E' THEN 'Nineteen' END,N'تسعة عشر')
INSERT INTO @THOUSAND VALUES (20,CASE WHEN @lang='F' THEN 'Vingt'
                                      WHEN @lang='E' THEN 'Twenty' END,N'عشرون')
INSERT INTO @THOUSAND VALUES (30,CASE WHEN @lang='F' THEN 'Trente'
                                      WHEN @lang='E' THEN 'Thirty' END,N'ثلاثون')
INSERT INTO @THOUSAND VALUES (40,CASE WHEN @lang='F' THEN 'Quarante'
                                      WHEN @lang='E' THEN 'Forty' END ,N'اربعون')
INSERT INTO @THOUSAND VALUES (50,CASE WHEN @lang='F' THEN 'Cinquante'
                                      WHEN @lang='E' THEN 'Fifty' END,N'خمسون')
INSERT INTO @THOUSAND VALUES (60,CASE WHEN @lang='F' THEN 'Soixante'
                                      WHEN @lang='E' THEN 'Sixty' END,N'ستون')
INSERT INTO @THOUSAND VALUES (70, CASE WHEN @lang='F' THEN 'Soixante-dix'
                                       WHEN @lang='E' THEN 'Seventy' END ,N'سبعون')
INSERT INTO @THOUSAND VALUES (80,CASE WHEN @lang='F' THEN 'Quatre-Vingts'
                                      WHEN @lang='E' THEN 'Eighty' End,N'ثمانون')                                     
INSERT INTO @THOUSAND VALUES (90,CASE WHEN @lang='F' THEN 'Quatre-Vingt-dix' 
                                      WHEN @lang='E' THEN 'Ninety' END ,N'تسعون')	                                                                            
INSERT INTO @THOUSAND VALUES (100,CASE WHEN @lang='F' THEN 'Cent'
                                       WHEN @lang='E' THEN 'One Hundred,' End,N'مئة')
INSERT INTO @THOUSAND VALUES (200,CASE WHEN @lang='F' THEN 'Deux Cents'
                                       WHEN @lang='E' THEN 'Two Hundred,' End,N'مائتان')
INSERT INTO @THOUSAND VALUES (300,CASE WHEN @lang='F' THEN 'Trois Cents' 
                                       WHEN @lang='E' THEN 'Three Hundred,' End,N'ثلاثمائة')
INSERT INTO @THOUSAND VALUES (400,CASE WHEN @lang='F' THEN  'Quatre Cents' 
                                       WHEN @lang='E' THEN 'Four Hundred,' END ,N'أربعمائة')
INSERT INTO @THOUSAND VALUES (500,CASE WHEN @lang='F' THEN  'Cinq Cents'
                                       WHEN @lang='E' THEN 'Five Hundred,' END ,N'خمسمائة')
INSERT INTO @THOUSAND VALUES (600,CASE WHEN @lang='F' THEN  'Six Cents'
                                       WHEN @lang='E' then 'Six Hundred,' End,N'ستمائة')
INSERT INTO @THOUSAND VALUES (700,CASE WHEN @lang='F' THEN 'Sept Cents'
                                       WHEN @lang='E' THEN 'Seven Hundred,' End,N'سبعمائة')
INSERT INTO @THOUSAND VALUES (800,CASE WHEN @lang='F' THEN  'Huit Cents' 
                                       WHEN @lang='E' THEN 'Eight Hundred,' END ,N'ثمانمائة')
INSERT INTO @THOUSAND VALUES (900, CASE WHEN @lang='F' THEN  'Neuf Cents' 
                                       WHEN @lang='E' THEN 'Nine Hundreds,'End,N'تسعمائة')

IF (@lang = 'F')
begin
INSERT INTO @THOUSAND
  SELECT A.num+B.num, CASE WHEN A.num = 80 THEN  substring(ltrim(rtrim(A.enwrd)),0,LEN(LTRIM(RTRIM(A.enwrd)))) ELSE  A.enwrd END 
  +'-'+(case when (B.enwrd= 'Un') AND A.num <> 80 THEN 'et-Un' ELSE B.enwrd END),B.arwrd+N' و '+A.arwrd
  FROM (SELECT * FROM @THOUSAND WHERE (num BETWEEN 20 AND 60 OR num =80)) A
  CROSS JOIN (SELECT * FROM @THOUSAND WHERE num BETWEEN 1 AND 9) B


INSERT INTO @THOUSAND

  SELECT A.num+B.num,CASE WHEN A.num = 80 THEN  substring(ltrim(rtrim(A.enwrd)),0,LEN(LTRIM(RTRIM(A.enwrd)))) ELSE  A.enwrd END 
  + case when A.num=60 and B.num = 11 then '-et-' else '-' END + B.enwrd,A.arwrd+N' و '+B.arwrd
  FROM (SELECT * FROM @THOUSAND WHERE (num IN (60,80)))A
  CROSS JOIN (SELECT * FROM @THOUSAND WHERE num BETWEEN 11 AND 19)B
  
  INSERT INTO @THOUSAND
  SELECT A.num+B.num,
  case when A.num <> 100 then substring(ltrim(rtrim(A.enwrd)),0,LEN(LTRIM(RTRIM(A.enwrd)))) ELSE A.enwrd END
  +N' ' + B.enwrd,A.arwrd+N' و '+B.arwrd
  FROM (SELECT * FROM @THOUSAND WHERE num BETWEEN 100 AND 900) A
  CROSS JOIN (SELECT * FROM @THOUSAND WHERE num BETWEEN 1 AND 99) B


END 

IF (@lang <>'F')
BEGIN
	INSERT INTO @THOUSAND
  SELECT A.num+B.num, A.enwrd+N' '+B.enwrd,B.arwrd+N' و '+A.arwrd
  FROM (SELECT * FROM @THOUSAND WHERE num BETWEEN 20 AND 90) A
  CROSS JOIN (SELECT * FROM @THOUSAND WHERE num BETWEEN 1 AND 9) B
  
  INSERT INTO @THOUSAND
  SELECT A.num+B.num,A.enwrd+N' ' + B.enwrd,A.arwrd+N' و '+B.arwrd
  FROM (SELECT * FROM @THOUSAND WHERE num BETWEEN 100 AND 900) A
  CROSS JOIN (SELECT * FROM @THOUSAND WHERE num BETWEEN 1 AND 99) B

END








  declare @s nvarchar(15)
  set @s = right(replicate('0',15)+cast(floor(@n) as nvarchar(15)),15)
 declare @w nvarchar(max)
 declare @decimalvalue as nvarchar(400),@temp as INT

 set @temp=0

  set @w = case when @lang='A' then N' فقط ' WHEN @lang='E' THEN 'Only ' when @lang ='F' then '' end
  if left(@s,3) > 0
  BEGIN 
    set @w = @w + (select case when @lang='A' then arwrd else enwrd end  from @THOUSAND where num=left(@s,3))
      +  case when @lang='A' then N' ترليون ' 
               when @lang ='E' then  ' Trillion, '
               WHEN @lang='F'  AND left(@s,3) <> '001' THEN ' Trillions ' else ' Trillion ' end 
               
    END         
  if left(right(@s,12),3) > 0
  BEGIN 
    set @w = @w + (select case when @lang='A' then arwrd else enwrd end from @THOUSAND where num=left(right(@s,12),3))
      + case when @lang='A' then N' بليون '
             WHEN @lang='E' THEN  ' Billion, ' 
             when @lang ='F' AND left(right(@s,12),3) <> '001' then ' Milliards ' ELSE ' Milliard ' END
             
         
   END 
  if left(right(@s,9),3) > 0
BEGIN

    set @w=@w+ case  when @n>999000000 and @lang='A' then N' و ' else N'' end 
   set @temp=left(right(@s,9),3)
        set @w = @w + (select case when @lang='A' and @temp>2 then arwrd when @lang='E' or @lang='F' then enwrd else N'' end from @THOUSAND where num=left(right(@s,9),3))
      + case when @lang='A' and @temp=2 then N' مليونان ' when @lang='A'and @temp between 3 and 10 then N' ملايين '
       when @lang='E' then ' Million, '
       WHEN @lang='A' THEN  N' مليون ' 
       WHEN @lang='F' AND left(right(@s,9),3) <> '001'  THEN ' Millions '  ELSE ' Million ' end
end

if left(right(@s,6),3) > 0
BEGIN

    set @w=@w+ case  when @n>999000 and @lang='A' then N' و ' else N'' end 
    set @temp=left(right(@s,6),3)
    set @w = @w + (select case when @lang='A'and @temp>2 then arwrd 
                               when @lang='E' then enwrd  
                               WHEN @lang='F' THEN CASE WHEN (right(@temp,2)='00' AND LEFT(@temp,1)<>1) OR ((right(@temp,2))='80')    THEN  substring(ltrim(rtrim(enwrd)),0,LEN(LTRIM(RTRIM(enwrd)))) 
                                                        WHEN @temp=1  THEN N''
                                                        ELSE enwrd end
                               else N'' end from @THOUSAND where num=left(right(@s,6),3))
      + case when @lang='A'and @temp=2 then N' الفان ' when @lang='A'and @temp between 3 and 10 then N'الاف' 
      when @lang='E' then ' Thousand, ' 
       WHEN @lang='A' THEN  N' الف ' 
       when @lang ='F'  THEN ' Mille '  end 
end

  if right(@s,3) > 0
  begin
    set @w=@w+ case  when @n>999 and @lang='A' then N' و ' else N'' end 
  end
    set @w = @w + (select case when @lang='A' then arwrd else enwrd end from @THOUSAND where num=right(@s,3))

if right(rtrim(@w),1)=',' set @w=substring(@w,1,len(@w)-1)

SET @w= case when @lang ='f' then  @w +' '+ LTRIM(RTRIM(@Only)) ELSE @w end

 if  right(@n,len(@n)-charindex('.',@n)) >0 and charindex('.',@n)<>0
	begin
		--select @decimalvalue= case when @lang='A' then N' و ' else ' and ' end+case when @lang='A' then arwrd else enwrd end from @THOUSAND where num=left(right(round(@n,2),3),2)
		--set @w=@w+@decimalvalue+case when @lang ='A' then N' قرشاُ' else' Piasters' end
		DECLARE @centimes AS NVARCHAR(200)
		declare @decimalScale as smallint
		select @decimalScale=decimalScale from sysparam
		SELECT @centimes= ' et ' + enwrd FROM @THOUSAND WHERE num=left(right(rtrim(round(@n,2)),3),2)
		set @w=@w+ case when @decimalscale=0 then N'' else case when @lang='A' then N' و '  +'#'+left(right(round(@n,@decimalScale),3),@decimalScale)+'/'+ltrim(rtrim(str(power(10,@decimalScale )))) +'#'
		                                                        WHEN @lang ='E' THEN ' and '  +'#'+left(right(round(@n,@decimalScale),3),@decimalScale)+'/'+ltrim(rtrim(str(power(10,@decimalScale )))) +'#' 
		                                                   when @lang='F' THEN +N' '+  @centimes  END end
		                                                
		--set @w=@w+ case when @lang='A' then ' و ' else ' and ' end+'#'+left(right(round(@n,@decimalScale),3),@decimalScale)+'/'+case when @decimalScale=2 then '100' when @decimalScale=3 then '1000' else '10' end+'#'
	end
set @w=
case when @lang='E' OR @lang='A'  then
@w+N' '+ ltrim(rtrim(@only))+case when @lang ='A' then N' لا غير ' else N' '   END
ELSE @w END 
return  rtrim(@w)  collate database_default

end

GO

