

CREATE FUNCTION [dbo].[Z_MorningAndNightIntersectionPeriod](@StartDateTime AS SMALLDATETIME , @EndDateTime AS SMALLDATETIME , @MorningOrNightHours SMALLINT )
RETURNS NUMERIC(18,3)
AS 
BEGIN
	

--DECLARE @StartDateTime AS SMALLDATETIME , @EndDateTime AS SMALLDATETIME , @MorningOrNightHours SMALLINT 

--SELECT @StartDatetime = '2022/03/20 09:00' , @enddatetime='2022/03/21 04:00' , @MorningOrNightHours =1

DECLARE @OverHours AS NUMERIC(18,3)=0
--MorningOrNightHours =0 , Morning
--MorningOrNightHours =1,  Night

DECLARE @BoundaryDate AS SMALLDATETIME 
WHILE @StartDateTime <@EndDateTime 
BEGIN 
    SELECT @BoundaryDate =CASE WHEN @StartDateTime >= convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '06:00') and @StartDateTime < convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '18:00') THEN 
              	                    CASE WHEN @EndDateTime < convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '18:00') THEN @EndDateTime ELSE convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '18:00') END 
                            ELSE 
                                CASE WHEN @EndDateTime >=convert(smalldatetime ,CONVERT(CHAR(10),dateadd(day,1,@StartDateTime) ,111)+ ' '+ '00:00') THEN  convert(smalldatetime ,CONVERT(CHAR(10),dateadd(day,1,@StartDateTime) ,111)+ ' '+ '00:00') 
                                ELSE 
                                CASE when @StartDateTime >=convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '18:00') AND  @StartDateTime <convert(smalldatetime ,CONVERT(CHAR(10),dateadd(day,1,@StartDateTime) ,111)+ ' '+ '00:00') THEN @EndDateTime
                                ELSE CASE WHEN @EndDateTime >convert(smalldatetime ,CONVERT(CHAR(10),@EndDateTime ,111)+ ' '+ '06:00') THEN convert(smalldatetime ,CONVERT(CHAR(10),@EndDateTime ,111)+ ' '+ '06:00') ELSE @EndDateTime END 
                                END 
                                END 
                            END                       
    IF @MorningOrNightHours=0
		BEGIN
    		   SELECT @OverHours= @OverHours+ CASE WHEN @BoundaryDate > convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '06:00') AND @BoundaryDate <= convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '18:00') THEN DATEDIFF(second,@StartDateTime,@BoundaryDate)  ELSE 0 END  
		END      
    ELSE
    	BEGIN
    		SELECT  @OverHours= @OverHours+  CASE WHEN @BoundaryDate > convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '06:00') AND @BoundaryDate <= convert(smalldatetime ,CONVERT(CHAR(10),@StartDateTime ,111)+ ' '+ '18:00') THEN 0  ELSE DATEDIFF(second,@StartDateTime,@BoundaryDate)  END 
    	END
 
    SELECT @StartDateTime=@BoundaryDate
END

 return @OverHours/3600.00
 END

GO

