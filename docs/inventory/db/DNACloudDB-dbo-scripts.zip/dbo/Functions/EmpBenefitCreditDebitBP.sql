


--This fn calculate the credit/debit at a specific date for a certain benefit plan and benefit item
CREATE  FUNCTION [dbo].[EmpBenefitCreditDebitBP](@empid as int,@PlanNo as smallint,@StartActivityDate as smalldatetime,@EndActivityDate as smalldatetime,@ItemNo as smallint)   
RETURNS numeric (18,3) AS  

--type=1 debit
--type=2 credit
BEGIN 

declare @totalamount as numeric(18,3)


select @totalamount=sum(case when EmpBenefitItems.ItemNo=@ItemNo then  activityamount else 0 end)
from EmpBenefit
LEFT JOIN EmpBenefitItems ON EmpBenefit.EmpId = EmpBenefitItems.EmpId
 AND EmpBenefit.DocumentNo = EmpBenefitItems.DocumentNo 
LEFT JOIN BenefitItems ON EmpBenefitItems.ItemNo = BenefitItems.ItemNo 
where EmpBenefit.empid=@empid and(EmpBenefitItems.Activitydate between @StartActivityDate and @EndActivityDate) and EmpBenefit.planno=@PlanNo

return isnull(@totalamount,0)
END

GO

