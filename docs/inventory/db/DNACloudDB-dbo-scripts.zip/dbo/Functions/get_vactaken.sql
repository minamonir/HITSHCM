
--calculate the no of vacation days for specific vacation category in a certain period 

CREATE   FUNCTION [dbo].[get_vactaken]
(@empid int,@startdate datetime,@enddate datetime,@vaccat as int)
RETURNS numeric(18,3)
AS
	BEGIN
	declare @days numeric(18,3)
	set @days = 0.000
	select @days = sum(dbo.VacTakenDays(@empid, 
                                           (case when empvacat.fromdate < @startdate then @startdate else empvacat.fromdate end)
                            ,( case when empvacat.todate > @enddate THEN @enddate else empvacat.todate END) ,empvacat.vaccode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo)  )     
                             from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode                         
                             INNER JOIN EmpAssignment ON EmpAssignment.EmpId=empvacat.EmpId
	where empvacat.empid=@empid  and empvacat.vacstatus=1
                        and (  (empvacat.fromdate between @startdate and @enddate) or 
                       (empvacat.todate between @startdate and @enddate) or 
                       (@startdate between empvacat.fromdate and empvacat.todate)or 
                       (@enddate between empvacat.fromdate and empvacat.todate))
                        AND(vacation.vactype = @vaccat ) AND empvacat.FromDate>=hiredate
              
	RETURN isnull(@days,0.000)

end

GO

