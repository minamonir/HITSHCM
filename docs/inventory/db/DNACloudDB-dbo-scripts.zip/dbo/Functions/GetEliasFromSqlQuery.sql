
CREATE   FUNCTION dbo.GetEliasFromSqlQuery
(
    @SqlQuery NVARCHAR(MAX)
)
RETURNS @Aliases TABLE
(
    ViewName NVARCHAR(200),
    AliasName NVARCHAR(50)
)
AS
BEGIN
    -- Normalize SQL
    SET @SqlQuery = REPLACE(@SqlQuery, CHAR(13), ' ');
    SET @SqlQuery = REPLACE(@SqlQuery, CHAR(10), ' ');
    SET @SqlQuery = REPLACE(@SqlQuery, CHAR(9),  ' ');
    
	SET @SqlQuery = REPLACE(@SqlQuery, ']', '] ');

    -- Add spaces around keywords
	SET @SqlQuery = REPLACE(@SqlQuery, ' FROM ', '  FROM  ');
	SET @SqlQuery = REPLACE(@SqlQuery, ' JOIN ', '  JOIN  ');
	SET @SqlQuery = REPLACE(@SqlQuery, ' WHERE ', '  WHERE  ');

    
    -- Remove double spaces
    WHILE CHARINDEX('  ', @SqlQuery) > 0
        SET @SqlQuery = REPLACE(@SqlQuery, '  ', ' ');
    
    -- Tokenize
    DECLARE @Tokens TABLE
    (
        Ordinal INT IDENTITY(1,1),
        Value NVARCHAR(200)
    );
    
    INSERT INTO @Tokens (Value)
    SELECT value
    FROM STRING_SPLIT(@SqlQuery, ' ')
    WHERE value <> '';
    


    DECLARE @FromPosition INT, @WherePosition INT;
    
    SELECT @FromPosition = MIN(Ordinal) 
    FROM @Tokens 
    WHERE UPPER(Value) = 'FROM';
    
    SELECT @WherePosition = MIN(Ordinal) 
    FROM @Tokens 
    WHERE UPPER(Value) = 'WHERE';
      


    DECLARE @RebuiltTokens TABLE
    (
        Ordinal INT IDENTITY(1,1),
        Value NVARCHAR(200)
    );
    

    DECLARE @i INT = @FromPosition + 1, @currentValue NVARCHAR(200), @builtValue NVARCHAR(200) = '';
    
    WHILE  @i < @WherePosition
    BEGIN
        SELECT @currentValue = Value FROM @Tokens WHERE Ordinal = @i;
              
        IF @currentValue LIKE '[[]%' AND @currentValue NOT LIKE '%]'
        BEGIN
           
            SET @builtValue = @currentValue;
            SET @i = @i + 1;
            
            WHILE  @i < @WherePosition
            BEGIN
                SELECT @currentValue = Value FROM @Tokens WHERE Ordinal = @i;
                SET @builtValue = @builtValue + ' ' + @currentValue;
                
                IF @currentValue LIKE '%]'
                    BREAK;
                    
                SET @i = @i + 1;
            END
                       
            INSERT INTO @RebuiltTokens (Value) VALUES (@builtValue);
        END
        ELSE
        BEGIN
           
            INSERT INTO @RebuiltTokens (Value) VALUES (@currentValue);
        END
        
        SET @i = @i + 1;
    END
    


    DECLARE @ViewName NVARCHAR(200), @AliasName NVARCHAR(50);
    
	SELECT TOP 1
		@ViewName  = t1.Value,
		@AliasName =
			CASE
				WHEN t2.Value IS NULL THEN NULL
				WHEN t2.Value LIKE '[[]%' THEN NULL               -- another table
				WHEN UPPER(t2.Value) IN ('JOIN','WHERE','ON','LEFT','RIGHT','INNER','OUTER')
					THEN NULL                                     -- keyword, not alias
				ELSE t2.Value                                     -- valid alias
			END
	FROM @RebuiltTokens t1
	LEFT JOIN @RebuiltTokens t2
		ON t2.Ordinal = t1.Ordinal + 1
	WHERE
		t1.Value LIKE '[[]%'     -- [TableName]
		AND t1.Value LIKE '%]'
	ORDER BY t1.Ordinal;

    

    IF @AliasName IS NULL OR @AliasName = ''
        SET @AliasName = @ViewName;
    

    INSERT INTO @Aliases VALUES (@ViewName, @AliasName);
    
    RETURN;
END;

GO

