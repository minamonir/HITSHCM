
CREATE    FUNCTION [dbo].[CalcYTDPayCodeGrp] (@Empid Int,@grpcode int)
RETURNS numeric(18,3) AS 
begin

declare @PayCodeamount as numeric(18,3)
SELECT  @PayCodeamount=
(
	
isnull((	
SELECT 
SUM((Case when paycode.grpcode is null then 1 else case when PayCdGrp.grp_type=1 then 
 case when paycode.type =1 or paycode.code=100 then 1 else -1 end else
 case when paycode.type =1 or paycode.code=100 then -1 else 1 end end end)
 *dbo.ConvertAmount(HistoryTransaction.Amount, HistoryPayroll.PayrollCurrency, PayrollGroup.Currency,
 dbo.periodend(HistoryPayroll.PayrollGroup, HistoryPayroll.Month, HistoryPayroll.Year))) AS Amount

FROM         EmpAssignment INNER JOIN
                      HistoryPayroll ON HistoryPayroll.EmpId = EmpAssignment.EmpId INNER JOIN
                      HistoryTransaction ON HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.Month = HistoryTransaction.Month AND 
                      HistoryPayroll.EmpId = HistoryTransaction.EmpId AND HistoryPayroll.RunNo = HistoryTransaction.RunNo LEFT OUTER JOIN
                      Paycode ON Paycode.code = HistoryTransaction.Paycode LEFT OUTER JOIN
                      PaycdGrp ON Paycode.grpcode = PaycdGrp.grpcode LEFT join
                      PayrollGroup ON EmpAssignment.payrollgroup=PayrollGroup.PayrollGroup
WHERE PaycdGrp.grpcode=@grpcode
AND EmpAssignment.empid=@Empid
AND HistoryTransaction.year=PayrollGroup.CYear                 
GROUP BY Paycode.grpcode ),0)


)
+
(
	
isnull((SELECT 
SUM((Case when paycode.grpcode is null then 1 else
 case when PayCdGrp.grp_type=1 then case when paycode.type =1 or paycode.code=100 then 1 else -1 end
 else case when paycode.type =1 or paycode.code=100 then -1 else 1 end end end)
*MonthlyTransaction.Amount) AS Amount

FROM         EmpAssignment left JOIN
MonthlyTransaction ON  EmpAssignment.empid=MonthlyTransaction.EmpId LEFT join
                      Paycode ON Paycode.code = MonthlyTransaction.Paycode LEFT OUTER JOIN
                      PaycdGrp ON Paycode.grpcode = PaycdGrp.grpcode 


WHERE PaycdGrp.grpcode=@grpcode
AND EmpAssignment.empid=@Empid            
GROUP BY Paycode.grpcode),0)


)

return isnull(@PayCodeamount,0.0)
END

GO

