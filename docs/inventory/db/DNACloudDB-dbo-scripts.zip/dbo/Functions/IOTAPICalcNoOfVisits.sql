
CREATE FUNCTION [dbo].[IOTAPICalcNoOfVisits] (@userlogonname AS NVARCHAR(80), @parentno AS SMALLINT, @modern AS SMALLINT, @mydate AS SMALLDATETIME, @where AS NVARCHAR(MAX) = ''
,@lang char(1)='E',@version int,@profileId INT,@DATE DATETIME,@NoHours NUMERIC(18,3),@deviceId SMALLINT=0)
RETURNS BIGINT
AS
BEGIN
	DECLARE @count BIGINT=0,@check AS SMALLINT=0
	--SELECT @check =COUNT(*) FROM dbo.ProfileTemplates WHERE ProfileId=@profileId AND TimeDevice=CASE WHEN @deviceId=0 THEN TimeDevice ELSE @deviceId END
	--AND TemplateDate <=@DATE
	--IF  @check>0
	--BEGIN
	--SELECT @count =1
	--END
	

	--DECLARE @temp TABLE(profileId INT,date DATETIME,rowNo INT IDENTITY)
	--INSERT INTO @temp
	--        ( profileId, date )
	--SELECT ProfileId,TemplateDate FROM dbo.ProfileTemplates WHERE ProfileId=@profileId AND  TemplateDate> DATEADD(HOUR,@NoHours,@Date) 

	--DELETE @temp WHERE date BETWEEN (SELECT date FROM @temp WHERE rowNo=rowNo-1) AND  (SELECT DATEADD(HOUR,@NoHours,date)  FROM @temp WHERE rowNo=rowNo-1)
	SET @DATE=DATEADD(ss,@NoHours*60*60,@DATE)
DECLARE @fDate AS DATETIME =@DATE,@timesystem AS SMALLINT=-1
	--SELECT @count=(SELECT COUNT(*) FROM @temp)
		
	--DECLARE @timesystem AS SMALLINT
	--DECLARE TScursor CURSOR FOR SELECT TimeSystemDevices.TimeSystem FROM dbo.ProfileTemplates
	--INNER JOIN dbo.TimeSystemDevices ON TimeSystemDevices.TimeDevice = ProfileTemplates.TimeDevice
	--INNER JOIN dbo.TimeSystems ON TimeSystems.TimeSystem = TimeSystemDevices.TimeSystem
	-- WHERE ProfileId=@profileId GROUP BY TimeSystemDevices.TimeSystem  
	-- OPEN TScursor
	--  FETCH NEXT FROM TScursor INTO @timesystem
	--  WHILE @@FETCH_STATUS = 0   
	--	BEGIN

	--	SET @DATE=@fDate
	--SELECT @count =@count+CASE WHEN DATEDIFF(second,TemplateDate,@DATE)/3600.00>=@NoHours THEN 1 ELSE 0 END
	--,@DATE=CASE WHEN DATEDIFF(second,TemplateDate,@DATE)/3600.00>=@NoHours THEN  TemplateDate ELSE @DATE END
	--FROM dbo.ProfileTemplates	
	--JOIN dbo.TimeSystemDevices ON TimeSystemDevices.TimeDevice = ProfileTemplates.TimeDevice
	--JOIN dbo.TimeSystems ON TimeSystems.TimeSystem = TimeSystemDevices.TimeSystem
	--WHERE ProfileId=@profileId AND TimeSystemDevices.TimeSystem=@timesystem
	--AND TemplateDate<@DATE
	--ORDER BY templatedate desc
		--FETCH next from TScursor INTO @timesystem
		--END 

		--CLOSE TScursor
		--DEALLOCATE TScursor



		SELECT @count =@count+CASE WHEN (DATEDIFF(second,TemplateDate,@DATE)/3600.00>=@NoHours) OR @timesystem<>TimeSystemDevices.TimeSystem THEN 1 ELSE 0 END
	,@DATE=CASE WHEN (DATEDIFF(second,TemplateDate,@DATE)/3600.00>=@NoHours) OR @timesystem<>TimeSystemDevices.TimeSystem  THEN  TemplateDate ELSE @DATE END,@timesystem=TimeSystemDevices.TimeSystem
	FROM dbo.ProfileTemplates	
	INNER JOIN dbo.TimeSystemDevices ON TimeSystemDevices.TimeDevice = ProfileTemplates.TimeDevice
	WHERE ProfileId=@profileId 
	AND TemplateDate<@DATE
	ORDER BY templatedate desc


	RETURN @count

END

GO

