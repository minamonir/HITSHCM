

CREATE FUNCTION [dbo].[hits_EmpVacBal]( @Empid as int,@date1 as smalldatetime,@date2 as smalldatetime)
RETURNS @EmpVacBal TABLE 
	(Empid  int, 
	Ystart   smalldatetime,
	VacPrvBal1 numeric(18,3),
	VacPrvBal2 numeric(18,3),
	VacPrvBal3 numeric(18,3),
	VacTaken1 numeric(18,3),
	VacTaken2 numeric(18,3),
	VacTaken3 numeric(18,3),
	vacdue1 numeric(18,3),
	vacdue2 numeric(18,3),
	vacdue3 numeric(18,3)
	 )
AS
BEGIN 
/*
insert into @EmpVacBal
SELECT DISTINCT EmpAssignment.EmpId,
dbo.EmpVacBal(EmpAssignment.EmpId, @date1 - 1, 1) AS VacPrvBal1, 
dbo.EmpVacBal(EmpAssignment.EmpId, @date1 - 1, 2) AS VacPrvBal2, 
dbo.EmpVacBal(EmpAssignment.EmpId, @date1 - 1, 3) AS VacPrvBal3, 
dbo.EmpVacTaken(EmpAssignment.EmpId, @date1, @date2, 1) AS VacTaken1, 
dbo.EmpVacTaken(EmpAssignment.EmpId, @date1, @date2, 2) AS VacTaken2, 
dbo.EmpVacTaken(EmpAssignment.EmpId, @date1, @date2, 3) AS VacTaken3, 
dbo.EmpVacDue(EmpAssignment.EmpId, @date1, @date2, 1) AS vacdue1,
dbo.EmpVacDue(EmpAssignment.EmpId, @date1, @date2, 2) AS vacdue2, 
dbo.EmpVacDue(EmpAssignment.EmpId, @date1, @date2, 3) AS vacdue3, 
dbo.EmpVacBal(EmpAssignment.EmpId, @date2, 1) AS VacBal1, 
dbo.EmpVacBal(EmpAssignment.EmpId, @date2, 2) AS VacBal2, 
dbo.EmpVacBal(EmpAssignment.EmpId, @date2, 3) AS VacBal3 
FROM Profile 
INNER JOIN EmpAssignment ON Profile.ProfileId = EmpAssignment.EmpId 
WHERE (EmpAssignment.EmpId = case when @empid=0 then EmpAssignment.EmpId else @empid end )
*/

insert into @EmpVacBal
SELECT DISTINCT EmpAssignment.EmpId,dbo.periodstart(EmpAssignment.PayrollGroup, 1, 0),0,0,0,0,0,0,0,0,0
FROM EmpAssignment 
Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
WHERE (EmpAssignment.EmpId = case when @empid=0 then EmpAssignment.EmpId else @empid end )


update @EmpVacBal

SET VacPrvBal1=dbo.EmpVacDue(EmpAssignment.empid,Ystart,@date1-1,1)+EmpAssignment.VacPrvBal1 -dbo.EmpVacTaken(EmpAssignment.empid,Ystart,@date1-1,1) ,

VacPrvBal2=dbo.EmpVacDue(EmpAssignment.empid,Ystart,@date1-1,2)+EmpAssignment.VacPrvBal2 -dbo.EmpVacTaken(EmpAssignment.empid,Ystart,@date1-1,2) ,

VacPrvBal3=dbo.EmpVacDue(EmpAssignment.empid,Ystart,@date1-1,3)+EmpAssignment.VacPrvBal3 -dbo.EmpVacTaken(EmpAssignment.empid,Ystart,@date1-1,3) ,


VacTaken1=Case When @date1 > @date2 
 Then -1*dbo.get_vactaken(EmpAssignment.EmpId, dateadd(dd,1,@date2) ,@date1-1,1) 
 Else dbo.get_vactaken(EmpAssignment.EmpId,@date1, @date2, 1) End ,
 
 VacTaken2=Case When @date1 > @date2 
 Then -1*dbo.get_vactaken(EmpAssignment.EmpId, dateadd(dd,1,@date2) ,@date1-1,2) 
 Else dbo.get_vactaken(EmpAssignment.EmpId,@date1, @date2, 2) End ,
 
 VacTaken3=Case When @date1 > @date2 
 Then -1*dbo.get_vactaken(EmpAssignment.EmpId, dateadd(dd,1,@date2) ,@date1-1,3) 
 Else dbo.get_vactaken(EmpAssignment.EmpId,@date1, @date2, 3) End ,
  


vacdue1=Case When @date1 > @date2 
 Then -1*dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate, dateadd(dd,1,@date2), 
@date1-1, 1, EmpAssignment.EmpId) 
 Else dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate,@date1, @date2,1, EmpAssignment.EmpId) End,

vacdue2=Case When @date1 > @date2 
 Then -1*dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate, dateadd(dd,1,@date2), 
@date1-1, 2, EmpAssignment.EmpId) 
 Else dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate,@date1, @date2,2, EmpAssignment.EmpId) End ,
 
 vacdue3=Case When @date1 > @date2 
 Then -1*dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate, dateadd(dd,1,@date2), 
@date1-1, 3, EmpAssignment.EmpId) 
 Else dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate,@date1, @date2,3, EmpAssignment.EmpId) End 
FROM EmpAssignment
inner join @EmpVacBal x on x.empid=EmpAssignment.empid
inner join profile on profile.profileid=EmpAssignment.empid

return
END

GO

