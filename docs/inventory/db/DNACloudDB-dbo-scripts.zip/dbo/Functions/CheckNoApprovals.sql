
CREATE FUNCTION CheckNoApprovals (@Empid INT,@DocumentNo INT, @CodeField INT, @TextField NVARCHAR(MAX))
RETURNS INT
AS
BEGIN
DECLARE @items AS Nvarchar(max),@SSDocType AS INT,@str NVARCHAR(max), @SSDocNo INT
	DECLARE @itemsselect AS Nvarchar(max)
	SET @SSDocType=@CodeField

	SET @items = ''
	DECLARE tempWFItemCodes CURSOR FOR 
	SELECT     replace ( cast(SSDocSelect  AS Nvarchar(max)) ,'select' , 'select ' + '''wf'+cast(ssdocno AS nvarchar(10))+'doc'' + ' )
	FROM         SSDocument
	WHERE SSDocType = @SSDocType

	OPEN tempWFItemCodes

	FETCH NEXT FROM tempWFItemCodes
	INTO  @itemsselect
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @items<> ''
			set @items= @items +' union all ' +@itemsselect
		ELSE	
			SET @items= @itemsselect
		FETCH NEXT FROM tempWFItemCodes
		INTO  @itemsselect
	END

	CLOSE tempWFItemCodes
	DEALLOCATE tempWFItemCodes


	DECLARE @WFItemCodes TABLE
	(
	item	     int,
	itemcode	 Nvarchar(max),
	itemname	 Nvarchar(max),
	itemaname	 Nvarchar(max)
	)

	if @SSDocType=9
	BEGIN
		IF @items <> ''
		BEGIN
			SELECT @str ='insert into  @WFItemCodes (itemcode, itemname, itemaname,item) '+ @items
			EXEC sp_executesql @str

		END
	END

	ELSE
	BEGIN
		IF @items <> ''
		BEGIN
			SELECT @str ='insert into  @WFItemCodes (itemcode, itemname, itemaname) '+ @items
			EXEC sp_executesql @str
					
		END
	END
		--SELECT * FROM @WFItemCodes
			
	if @SSDocType=7 AND ( @TextField Not IN ('BenefitItemName','BenefitItemAName'))
	BEGIN
	
	UPDATE @WFItemCodes
	SET	
	item =(substring(itemcode,CHARINDEX('doc',itemcode)+4,CHARINDEX('OP',itemcode)- CHARINDEX('doc',itemcode)-4))

	update @WFItemCodes set itemname =BenefitPlans.PlanName , itemaname =PlanAname
	from @WFItemCodes
	inner join BenefitPlans on BenefitPlans.PlanNo =item
	
	--SELECT * FROM @WFItemCodes
	
	END

	ELSE IF @SSDocType=7 AND ( @TextField IN ('BenefitItemName','BenefitItemAName'))
	BEGIN
	
	UPDATE @WFItemCodes
	SET	
	item =(substring(itemcode,CHARINDEX('doc',itemcode)+4,CHARINDEX('OP',itemcode)- CHARINDEX('doc',itemcode)-4))

	update @WFItemCodes set itemname =BenefitPlans.PlanName , itemaname =PlanAname
	from @WFItemCodes
	inner join BenefitPlans on BenefitPlans.PlanNo = item
	
	--SELECT * FROM @WFItemCodes
	
	END

	ELSE
	BEGIN
	UPDATE @WFItemCodes
	SET
	item = substring(itemcode,CHARINDEX('doc',itemcode)+3,CHARINDEX('mf',itemcode) - CHARINDEX('doc',itemcode)-3)
	WHERE CHARINDEX('mf',itemcode) > 0

	UPDATE @WFItemCodes
	SET
	item = substring(itemcode,CHARINDEX('doc',itemcode)+3,len(itemcode)- CHARINDEX('doc',itemcode)-2)
	WHERE CHARINDEX('mf',itemcode) <= 0	
	
	
	END
		--SELECT * FROM @WFItemCodes
				
    DECLARE @JOINS AS Nvarchar(max)
	SET @JOINS=CASE  
	WHEN @CodeField=3 then ' Left Join Vacation on Vacation.vaccode = @WFItemCodes.item '

	WHEN @CodeField=5 THEN ' LEFT JOIN MedicalItems on MedicalItems.MedicalItem=@WFItemCodes.item '

	WHEN @CodeField=1 THEN ' LEFT Join ChngStat on ChngStat.chgCode=@WFItemCodes.item ' 

	WHEN @codefield=7 THEN CASE WHEN @TextField Not IN ('BenefitItemName','BenefitItemAName') THEN 
		                       ' LEFT Join benefitplans on benefitplans.PlanNo=(@WFItemCodes.item /10000 ) '+
		                       ' Left join BenefitOptions on BenefitOptions.OptionNo=(@WFItemCodes.item %10000 )  ' 

	                             WHEN @TextField IN ('BenefitItemName','BenefitItemAName')  THEN  
	                             	' LEFT Join benefitplans on benefitplans.PlanNo=(@WFItemCodes.item) 
	                             	Left join BenefitOptions on BenefitOptions.OptionNo=(@WFItemCodes.item)'
                            END 
	WHEN @codefield=6 THEN ' LEFT Join Appraisals on Appraisals.AppraisalNo=@WFItemCodes.item '  

	WHEN @CodeField=12 THEN ' LEFT JOIN TimePermission on TimePermission.PermissionNo=@WFItemCodes.item'

	WHEN @CodeField=10 THEN ' LEFT JOIN Objectives on Objectives.ObjectiveId=@WFItemCodes.item'

	WHEN @CodeField=9 THEN ' LEFT JOIN TrainingEvents on TrainingEvents.TrainingEvent=@WFItemCodes.item'

	WHEN @CodeField=13 THEN ' LEFT JOIN competencies on competencies.competence=@WFItemCodes.item'

	WHEN @CodeField=14 THEN ' LEFT JOIN Document on Document.docid=@WFItemCodes.item'

	WHEN @CodeField=8 then ' Left Join VacationDue on VacationDue.VacDueCode = @WFItemCodes.item '

	WHEN @CodeField=2 then ' Left Join Mscondct on Mscondct.mscode = @WFItemCodes.item '

	WHEN @CodeField=18 THEN ' LEFT JOIN Activities on Activities.Activityno=@WFItemCodes.item'
	-------------heba
	WHEN @CodeField=24 THEN ' LEFT JOIN HRRequest on HRRequest.HRReqCode=@WFItemCodes.item'

	else '' 

	END
				
	
	IF @TextField='BenefitItemName'
	BEGIN
	SET @TextField='ItemName'
	SET @str= N'  create table #TempTable(Code int, name nvarchar(max))
	    insert into #TempTable select distinct item as code , '+@TextField+' as name from @WFItemCodes ' +@JOINS--+ @Where+' '+ @Sort	
	END
	ELSE IF @TextField='BenefitItemAName'  
	BEGIN
	SET @TextField='ItemAName'
	SET @str= N'  create table #TempTable(Code int, name nvarchar(max))
	    insert into #TempTable select distinct item as code , '+@TextField+' as name from @WFItemCodes ' +@JOINS--+@Where+' '+@Sort	
	END
	ELSE 
		BEGIN
			set @str= N'  create table #TempTable(Code int, name nvarchar(max))
	    insert into #TempTable select distinct item as code , '+@TextField+' as name from @WFItemCodes ' +@JOINS--+@Where+' '+@Sort
				
		END

SELECT @SSDocNo = SUBSTRING(itemcode,3,CHARINDEX('doc',itemcode)-3) FROM @WFItemCodes WHERE item = @TextField
 RETURN @SSDocNo

END

GO

