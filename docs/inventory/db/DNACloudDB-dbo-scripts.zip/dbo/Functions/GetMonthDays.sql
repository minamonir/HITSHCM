
Create FUNCTION [dbo].GetMonthDays (@empId INT,@lasPeriod Bit=0)
RETURNS SMALLINT AS
BEGIN
DECLARE @return_value SMALLINT,@type BIT=0, @PayrollGroup SMAllINT;
select @type=ConfigValue from SysParamConfig where ConfigID='MonthDayType'

 IF @type = 1
  BEGIN 
	SELECT @return_value = TimeRuleCons  FROM EmpAssignment 
							LEFT JOIN TimeRules ON  EmpAssignment.TimeRule=TimeRules.TimeRule 
							WHERE EmpAssignment.EmpId=@empId
			IF 		@return_value=0
			BEGIN
				select @return_value= PayrollGroup.MonthDays  	
									from empassignment 
									LEFT JOIN payrollgroup ON payrollgroup.PayrollGroup = empassignment.PayrollGroup 
									where  empassignment.EmpId=@empId
			END		
   END   
ELSE
	BEGIN 
			 IF @lasPeriod = 0
				BEGIN
					select @return_value= PayrollGroup.MonthDays  
										from EmpAssignment  
										left join PayrollGroup on PayrollGroup.PayrollGroup= EmpAssignment.PayrollGroup
										where  EmpAssignment.EmpId=@empId
				END
			 ELSE
				BEGIN
						select @PayrollGroup= max(ISNULL( HistoryPayroll.PayrollGroup,EmpAssignment.PayrollGroup))
						from EmpAssignment  
						left join PayrollGroup on PayrollGroup.PayrollGroup= EmpAssignment.PayrollGroup
						left join HistoryPayroll on EmpAssignment.EmpId= HistoryPayroll.EmpId 
						AND HistoryPayroll.Month=case when PayrollGroup.CMonth=1 then 12	else PayrollGroup.CMonth-1 end
						and HistoryPayroll.Year=case when PayrollGroup.CMonth=1 then PayrollGroup.CYear-1  else PayrollGroup.CYear end 
						where  EmpAssignment.EmpId=@empId
						
						select @return_value= PayrollGroup.MonthDays  	
						from PayrollGroup 
						where  PayrollGroup.PayrollGroup=@PayrollGroup
				END
	END

	IF @return_value = 0
	BEGIN
	    SELECT @return_value = 1
	END

  RETURN @return_value 

END

GO

