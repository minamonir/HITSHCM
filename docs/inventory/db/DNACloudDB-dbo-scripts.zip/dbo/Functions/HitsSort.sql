CREATE FUNCTION [dbo].[HitsSort](@EmployeeID AS NVARCHAR(50),@Type AS NVARCHAR(50))
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE
    --@EmployeeIDType AS SMALLINT,
    @EmployeeIDLength AS SMALLINT
    
	SELECT
        --@EmployeeIDType=EmployeeIDType,
        @EmployeeIDLength = EmployeeIDLength
    FROM SysParam

    --SET @EmployeeID = LTRIM(RTRIM(ISNULL(@EmployeeID, '')))
	
	--IF @EmployeeIDType <> 0 RETURN @EmployeeID
    
	--SET @EmployeeID = REPLICATE('0', @EmployeeIDLength - LEN(@EmployeeID)) + @EmployeeID
	SET @EmployeeID = RIGHT(REPLICATE('0', @EmployeeidLength) + @EmployeeId, @EmployeeidLength)

    RETURN @EmployeeID
END

GO

