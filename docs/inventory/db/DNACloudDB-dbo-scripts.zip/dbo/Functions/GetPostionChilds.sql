
--this fn gets the position childs no for the specified @parent 
--this fn is used for Hits_OLAP  SP 
CREATE FUNCTION [dbo].GetPostionChilds (@parent smallint)
RETURNS @Childs TABLE (positionno smallint)
AS
BEGIN
   DECLARE @RowsAdded int
   -- table variable to hold accumulated results
   DECLARE @temp TABLE (positionno smallint,processed smallint)
   INSERT @temp   SELECT positionno,0   FROM positionsstructure  WHERE positionparent = @parent 
   SET @RowsAdded = @@rowcount
    WHILE @RowsAdded > 0
   BEGIN
      UPDATE @temp  SET processed = 1 WHERE processed = 0
      INSERT @temp    SELECT PS.Positionno,0 FROM positionsstructure PS, @temp T WHERE PS.positionparent=T.Positionno and T.processed = 1
      SET @RowsAdded = @@rowcount
      UPDATE @temp   SET processed = 2  WHERE processed = 1
   END
   INSERT @Childs   SELECT Positionno FROM @temp 
   INSERT @Childs   SELECT @parent
   delete @temp
   RETURN
END

GO

