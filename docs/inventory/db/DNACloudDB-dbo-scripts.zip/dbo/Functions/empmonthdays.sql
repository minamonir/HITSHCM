
CREATE FUNCTION [dbo].[empmonthdays](@empid as INT, @ActionDate AS SMALLDATETIME ,@TYPE AS numeric(18,3)  ,@PeriodEndQS AS numeric(18,3) )
RETURNS numeric(18,8) 
AS
BEGIN
-- @type =0 hired employees
-- @type=1 Terminated Employees

--@PeriodEndQS = 1 date diff between term date and period end
--@PeriodEndQS = 0 30 - day part of term date
declare @PeriodStart SMALLDATETIME,@PeriodEnd AS SMALLDATETIME

select @PeriodStart= CAST(CAST(YEAR(@ActionDate) AS VARCHAR(4)) + '/' + CAST(MONTH(@ActionDate) AS VARCHAR(2)) + '/01' AS DATETIME)
select @PeriodEnd= EOMONTH(@ActionDate) 

DECLARE @CountDayoff AS numeric(18,3) =0  , @payrollgroup AS numeric(18,3) 
DECLARE @ConsiderDayoff AS BIT =0
DECLARE @noofdays AS numeric(18,8)  =0
DECLARE @fromDate AS SMALLDATETIME ,@toDate  AS SMALLDATETIME ,@hijridate AS NCHAR(10)
SELECT @ConsiderDayoff= 0
FROM sysparam

--top hits

SELECT @payrollgroup = PayrollGroup FROM empassignment WHERE empid =@empid

select @hijridate=case when payrollgroup.cyear<1900 then dbo.Greg2Hijri(@PeriodEnd,'O') else '' end
  from payrollgroup 
 where payrollgroup.payrollgroup=@payrollgroup


----------------Count Day off days -------------------------------------------------------
IF @ConsiderDayoff=1
begin

DECLARE  @dayoff1 AS numeric(18,3) =0 , @dayoff2 AS numeric(18,3)  =0
SELECT @dayoff1= case when empassignment.payrollgroup in (9,20,37,502,10,12,13,18,19,31,46) then 1 ELSE 0 END   ,@dayoff2= case when empassignment.payrollgroup in (10,12,13,18,19,31,46) then 7 else 0 END 
FROM EmpAssignment WHERE empid=@EmpId

IF @type=0 
BEGIN
SELECT @fromDate =@ActionDate ,@toDate =@PeriodEnd
END
ELSE IF @type=1
BEGIN

SELECT @fromDate =CASE WHEN @PeriodEndQS=0 THEN CONVERT(DATETIME , LTRIM(RTRIM(STR(YEAR(@PeriodEnd)))) +'/'+ LTRIM(RTRIM(STR(Month(@PeriodEnd))))+'/01') ELSE @PeriodStart END  ,@toDate =dateadd(day,-1,@ActionDate)
end

WHILE @fromDate<=@toDate
  BEGIN
	IF DATEPART(dw,@fromDate)=@dayoff1 OR DATEPART(dw,@fromDate)=@dayoff2
	BEGIN
		SET @CountDayoff=@CountDayoff+1
	END
	SET @fromDate=DATEADD(DAY,1,@fromDate)
  END

END 

----------------------Count no of days of new Hired Employees--------------------------------------------------------
IF @type=0
BEGIN
---@ActionDate as hiredate

		--IF (@hijridate <>'')
		--	BEGIN
		--	SELECT @noofdays = 31-cast(substring(dbo.Greg2Hijri(@ActionDate,'O'),9,2) as INT)
		--    END
  --     ELSE
	 --  BEGIN
	 --     IF (@ActionDate < @PeriodStart)
		--  BEGIN
		--  SELECT @noofdays = 31-datepart(dd,@ActionDate)
		--  END
  --        ELSE
  --        BEGIN
		--  SELECT @noofdays=DATEDIFF(dd, @ActionDate, @PeriodStart)
		--  End
	       
	 --  END
	 


	IF @PeriodEndQS =0
BEGIN
  	SELECT @noofdays =   DATEDIFF(dd, @ActionDate, @Periodend)+1 -@CountDayoff
	SELECT @noofdays = @noofdays - CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN 26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN 21.67 ELSE 30 END 
	FROM Empassignment 
	WHERE empid =@empid
	select @noofdays= CASE when @noofdays > 0 THEN 0 ELSE @noofdays END 
	RETURN @noofdays
end
ELSE IF @PeriodEndQS =1
BEGIN
  	SELECT @noofdays =   DATEDIFF(dd, @ActionDate, @Periodend)+1 -@CountDayoff
	SELECT @noofdays = @noofdays - CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN 26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN 21.67 ELSE 30 END 
	FROM Empassignment 
	WHERE empid =@empid
	
		SELECT @noofdays = CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN 26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN 21.67 ELSE 30 END+ @noofdays 
	FROM Empassignment 
	WHERE empid =@empid
	SELECT @noofdays =CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN @noofdays*1.00/26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN @noofdays*1.00/21.67 WHEN payrollgroup IN (6,7,8,11,14,16,17,38,39,40,41,42,43,45,47,48,3,32) THEN (DATEDIFF(DAY, @ActionDate, DATEADD(MONTH, 1, @ActionDate))+(1.00-day(@ActionDate)))*12/365.0 ELSE @noofdays*1.00/30 END
	FROM Empassignment 
	WHERE empid =@empid
	

	
	RETURN case when @noofdays > 1 then 1 else @noofdays end


END

       
END



----------------------------------------------------------------------------------------------------------------
----------------------Count no of days of Terminated Employees --------------------------------------------------

ELSE IF @type=1
BEGIN
---@ActionDate as Tirmdate
IF @PeriodEndQS =0
BEGIN
SELECT @noofdays = 30 -datepart(dd,@ActionDate)
end
ELSE IF @PeriodEndQS =1
BEGIN
 SELECT @noofdays = DATEDIFF(dd, @ActionDate, @PeriodEnd)   
END

END 




----------------------------------------------------------------------------------------------------------------

RETURN @noofdays+(@CountDayoff* CASE WHEN @type=1 THEN 1 ELSE -1 END ) 
END

GO

