
CREATE  FUNCTION [dbo].[periodend]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS

--DECLARE @payrollgroup INT=1,@period INT=26,@year INT=0
BEGIN
  declare @thedate smalldatetime
  declare @dateformat smallint
  declare @enablehijri as bit
  declare @hijridate as nchar(10)
  declare @mstartfirst bit
  declare @mstartday int
  declare @NoofPeriods as SMALLINT
  
  declare @week AS SMALLINT=0,@yearstart AS SMALLDATETIME,@firstperiodend AS SMALLDATETIME
  

--  if @year=0  select @year=cyear, @period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
   if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
   if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
  select @NoofPeriods=NoofPeriods from payrollgroup where payrollgroup=@payrollgroup
  select @thedate=enddate from payrollgroupperiods where payrollgroup=@payrollgroup and period= @period and year=@year  
 --   ---------------------------------------------------------------------

 
  if @thedate is null 
       begin
        select @dateformat=dateformat,  @enablehijri=enablehijri from sysparam
        select @mstartfirst=mstartfrst,@mstartday=mstartday from payrollgroup where payrollgroup = @payrollgroup
     -- advance the period by 1 to get next period start   
   
   IF @NoofPeriods=12
   begin
   
    if @period=12 
                begin
                   set @period=1 
                   set @year=@year+1 
               end      else set @period= @period+1
       
       if @enablehijri=1 and @year<1900
          begin
             if (@mstartfirst = 1 or @mstartday = 0 )    
                    set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(@period,2,1)+'/01'
                            when @dateformat=1 then '01/'+str(@period,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(@period,2,1)+'/01/'+str(@year,4,1) end
              else if  (@period=1)   
                              set @hijridate= CASE when @dateformat=0 then str(@year-1,4,1)+'/12/'+str(@mstartday,2,1)
                             when @dateformat=1 then str(@mstartday,2,1)+'/12/'+str(@year-1,4,1)
                                 when @dateformat=2 then '12/'+str(@mstartday,2,1)+'/'+str(@year-1,4,1) end
      
                    else set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(@period-1,2,1)+'/'+str(@mstartday,2,1)
                             when @dateformat=1 then str(@mstartday,2,1)+'/'+str(@period-1,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(@period-1,2,1)+'/'+str(@mstartday,2,1)+'/'+str(@year,4,1) end
               select  @thedate=dbo.hijri2greg(@hijridate)
           end
       else
          begin          
               if (@mstartfirst = 1 or @mstartday = 0 )  set  @thedate= convert(smalldatetime,'01/'+str(@period,2,1)+'/'+str(@year,4,1),103)
                else   if  (@period=1)   set @thedate= convert(smalldatetime,str(@mstartday,2,1)+'/'+str(12,2,1)+'/'+str(@year-1,4,1),103) 
		else    set @thedate= convert(smalldatetime,str(@mstartday,2,1)+'/'+str(@period-1,2,1)+'/'+str(@year,4,1),103)
         end
       --deduct 1 from next period start to have the end of period  
       set  @thedate=dateadd(dd,-1,@thedate)
   END
   ELSE
   	BEGIN
   		
   		SELECT @week=CASE WHEN @NoofPeriods = 13 THEN 4 WHEN @NoofPeriods = 26 Then 2 WHEN  @NoofPeriods = 52 Then 1 End 
   		 if @enablehijri=1 and @year<1900
          begin
             if (@mstartfirst = 1 or @mstartday = 0 )    
                    set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(1,2,1)+'/01'
                            when @dateformat=1 then '01/'+str(1,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(1,2,1)+'/01/'+str(@year,4,1) end
              else  
                              set @hijridate= CASE when @dateformat=0 then str(@year-1,4,1)+'/12/'+str(@mstartday,2,1)
                             when @dateformat=1 then str(@mstartday,2,1)+'/12/'+str(@year-1,4,1)
                                 when @dateformat=2 then '12/'+str(@mstartday,2,1)+'/'+str(@year-1,4,1) end
                        
               select  @yearstart=dbo.hijri2greg(@hijridate)
           end
       else
          begin          
               if (@mstartfirst = 1 or @mstartday = 0 )  set  @yearstart= convert(smalldatetime,'01/'+str(1,2,1)+'/'+str(@year,4,1),103)
                else   set @yearstart= convert(smalldatetime,str(@mstartday,2,1)+'/'+str(12,2,1)+'/'+str(@year-1,4,1),103) 
	
          END
          
          SET @firstperiodend= DateAdd(ww, @week *1, @yearstart)
   		
   		SET @thedate= DateAdd(ww, @week * (@period - 1), @firstperiodend)
   	END
end
--RETURN @thedate

RETURN  @thedate

END

GO

