CREATE FUNCTION dbo.GetUserFieldNo
  (@FormNo smallint, @FieldNo smallint, @FieldOrItem smallint)
RETURNS  smallint
as
BEGIN 
  declare @ReturnNo as smallint
   --fieldno
   if @FieldOrItem=1  select top 1 @ReturnNo =FieldNo from UserFieldsNames where FormNo=@FormNo order by  FieldNo desc
  --itemno
   if @FieldOrItem=2  select top 1 @ReturnNo=FieldItemNo from UserFieldsItems where FormNo=@FormNo and FieldNo=@FieldNo order by FieldItemNo desc

set @ReturnNo=isnull(@ReturnNo,0)
   while  1=1
    begin
     if  @ReturnNo>32768 set @ReturnNo=1 else set  @ReturnNo=@ReturnNo+1 
    --fieldno
     if  @FieldOrItem=1 and not exists (select FieldNo from UserFieldsNames where FormNo=@FormNo and FieldNo=@ReturnNo)  break
    --itemno
     if  @FieldOrItem=2 and not exists (select FieldItemNo from UserFieldsItems where FormNo=@FormNo and FieldNo=@FieldNo and FieldItemNo=@ReturnNo )  break
  end
  return @ReturnNo
END

GO

