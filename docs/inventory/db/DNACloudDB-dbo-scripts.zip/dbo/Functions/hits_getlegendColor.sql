create  FUNCTION [dbo].[hits_getlegendColor]( )
RETURNS @legendtable TABLE 
(Id int IDENTITY(1,1),
Vaccode INT,
VacationName NVARCHAR(60),
VacationAName NVARCHAR(60),
Color INT
)
AS
BEGIN

INSERT INTO @legendtable 
SELECT vaccode, VacationName, VacationAName, ColorNo FROM Vacation 

RETURN 
END

GO

