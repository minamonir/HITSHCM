-- =============================================
CREATE FUNCTION [dbo].[EmpAppraisalKPIName](
	@empid as int,@posorjob as int ,@code as smallint,@level as nchar,@docno as int,@RatingScale AS int = 1000,@Lang as nchar(1) )   
-- ignore zero level percent for the employees
RETURNS nchar(20) 

AS
BEGIN
--DECLARE @empid as int,@posorjob as int ,@code as smallint,@level as nchar,@docno as int,@RatingScale AS int
--
--SET @empid=203000
--SET @posorjob=0
--SET @code=4
--SET @level='H'
--SET @docno=12
--set	@RatingScale=1000

declare @KPIAutoResult as decimal(18,3),@lowlevel as numeric(18,3),@Highlevel as numeric(18,3),@ratinglevel as smallint,@ratinglevelName AS nchar(20),@lowpercent as numeric(18,3),@Highpercent as numeric(18,3)

SELECT @KPIAutoResult= dbo.EmpAppraisalKPI(@empid, @posorjob, @code, @level,@docno) 


if @RatingScale is null or @KPIAutoResult<0.0 set @ratinglevel= null
else
begin
select top 1  @lowlevel=ratinglevel ,@lowPercent=LevelPercent from RatingLevels where ratingscale=@ratingScale order by LevelPercent 

select top 1  @Highlevel=ratinglevel ,@HighPercent=LevelPercent from RatingLevels where ratingscale=@ratingScale order by LevelPercent desc

select top 1  @ratinglevel =ratinglevel from ratingLevels where ratingscale=@ratingScale and  LevelPercent<=@KPIAutoResult order by levelpercent desc

if @KPIAutoResult<@lowPercent   set @ratinglevel=@lowlevel
if @KPIAutoResult>@HighPercent  set @ratinglevel=@Highlevel
END

SELECT @ratinglevelName=case when @Lang='A' then RatingLevels.LevelAName else RatingLevels.LevelName end
FROM RatingLevels WHERE ratingscale=@ratingScale AND RatingLevel=@ratinglevel

--SELECT @ratinglevelName
--SELECT @ratinglevel,@autoresult,@lowlevel,@Highlevel,RatingLevels.LevelName
--FROM RatingLevels WHERE ratingscale=@ratingScale AND RatingLevel=@ratinglevel


return isnull(@ratinglevelName,N'')


	

END

GO

