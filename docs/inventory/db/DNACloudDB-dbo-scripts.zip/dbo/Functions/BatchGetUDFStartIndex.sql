
CREATE FUNCTION [dbo].[BatchGetUDFStartIndex](@PageType  NVARCHAR(254))
RETURNS SMALLINT
BEGIN

	DECLARE @enableAttachments AS BIT
	DECLARE @enableRef AS BIT
	SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 

	   DECLARE @returnVal AS smallint
	   If ltrim(rtrim(@PageType))='WP_GetExternalChangeOfStatus' Or ltrim(rtrim(@PageType))='WP_GetExternalChangeOfStatus_ar' 
            set @returnVal= 4
		Else If ltrim(rtrim(@PageType)) like'WP_GetExternalVacRecords%' Or ltrim(rtrim(@PageType)) like'WP_GetExternalVacRecords_ar%' 
            set @returnVal= 9
		Else If ltrim(rtrim(@PageType)) like'WP_GetExternalProfileUserDefinedFields%' Or ltrim(rtrim(@PageType)) like'WP_GetExternalProfileUserDefinedFields_ar%' 
            set @returnVal= 2
        Else If ltrim(rtrim(@PageType))='WP_GetExternalAppraisalWMR' Or ltrim(rtrim(@PageType))='WP_GetExternalAppraisalWMR_ar'
            set @returnVal= 11
        Else If ltrim(rtrim(@PageType))='WP_GetExternalHousingItems' Or ltrim(rtrim(@PageType))='WP_GetExternalHousingItems_ar' 
            set @returnVal= 10
        Else If ltrim(rtrim(@PageType))='WP_GetExternalDocuments' Or ltrim(rtrim(@PageType))='WP_GetExternalDocuments_ar' 
            set @returnVal= 15
        Else If ltrim(rtrim(@PageType))='WP_GetExternalHistoryPaycodes' Or ltrim(rtrim(@PageType))='WP_GetExternalHistoryPaycodes_ar'
           BEGIN
		   set @returnVal= 15
			 if @enableAttachments=1
			 BEGIN
               set @returnVal= @returnVal+2
			end 
		   if @enableRef=1
		   BEGIN
		       set  @returnVal=@returnVal+7 
			end 
		   end 
		ELSE If ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalPaycodes%' Or ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalPaycodes_ar%'
		 BEGIN
              set @returnVal=5
		  if @enableAttachments=1
			 BEGIN
               set @returnVal= @returnVal+2
			  end 
		   if @enableRef=1
		   BEGIN
		       set  @returnVal=@returnVal+7 
			end 
			  end 
		  
		Else If ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalevents%' Or ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalevents_ar%'
            set @returnVal= 17
        Else If ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalEmpSSGroupRoles%' Or ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalEmpSSGroupRoles_ar%'
            set @returnVal= 2
        Else If ltrim(rtrim(@PageType)) LIKE 'WP_ExportBenefitSalaryScales%' Or ltrim(rtrim(@PageType)) LIKE 'WP_ExportBenefitSalaryScales_ar%'
            set @returnVal= 2 --5
		Else If ltrim(rtrim(@PageType)) LIKE 'WP_ExportSalaryScalesDetails%' Or ltrim(rtrim(@PageType)) LIKE 'WP_ExportSalaryScalesDetails_ar%'
            set @returnVal= 2 --5
		Else If ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalBenefitPlan%' Or ltrim(rtrim(@PageType)) LIKE 'WP_GetExternalBenefitPlan_ar%'
            set @returnVal= 7 --5        
        Else If ltrim(rtrim(@PageType)) LIKE 'WP_getExternalMisconduct%'
            set @returnVal= 10 
        Else If ltrim(rtrim(@PageType)) like'WP_GetExternalHRRequests%' 
            set @returnVal= 8
		Else If ltrim(rtrim(@PageType)) like'WP_GetExternaltasks%' 
            set @returnVal= 10
	    Else If ltrim(rtrim(@PageType)) like'WP_GetExternalDataFile%' 
            BEGIN
            	DECLARE @progCode AS NVARCHAR(50)
            	SELECT @PageType=reverse(left(reverse(@PageType), charindex(',', reverse(@PageType)) -1))
            	SELECT @progCode=programcode FROM GetExtDataFilePrograms WHERE ProgramId= @PageType
            	IF @progCode ='AppraisalComp'
            	BEGIN
            		SET @returnVal=2
            	END
            	ELSE
            	BEGIN
            		SET @returnVal=0
            	END
            END
        Else
            set @returnVal= 0
	   
	   RETURN @returnVal
END

GO

