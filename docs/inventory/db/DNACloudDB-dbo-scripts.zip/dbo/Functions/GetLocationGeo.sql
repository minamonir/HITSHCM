
			CREATE FUNCTION [dbo].[GetLocationGeo] (@Lat FLOAT ,@Long FLOAT )  
			RETURNS GEOGRAPHY AS  
			BEGIN
			DECLARE @Locationgeo AS GEOGRAPHY

			--SELECT @Locationgeo= geography::STPointFromText ('POINT (' + CONVERT (VARCHAR(50), @long,128) + ' ' +CONVERT (VARCHAR(50), @Lat,128)+ ')', 4326) 
			SELECT @Locationgeo = geography::STPointFromText('POINT (' + STR(@Long,10,6) + ' ' + STR(@Lat,10,6) + ')', 4326)

			RETURN @Locationgeo
			END

GO

