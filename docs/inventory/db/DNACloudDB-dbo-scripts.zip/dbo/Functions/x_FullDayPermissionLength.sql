CREATE FUNCTION [dbo].[x_FullDayPermissionLength] 
(@EmpId as int, @DocNo AS INT,@PermissionNo as smallint, @FromDate as datetime,@ToDate as datetime)
RETURNS int
AS
BEGIN
DECLARE @FullDayPermissionLength AS INT 
DECLARE @TimePermission AS INT=0
declare @PermissionOverShortType as smallint
select @PermissionOverShortType=timepermission.overshort  from timepermission where PermissionNo=@PermissionNo

	
		SELECT @FullDayPermissionLength=CONVERT(INT ,ConfigValue) FROM dbo.SysParamConfig WHERE ConfigID='FullDayPermissionLength'
	
	
	IF ISNULL(@FullDayPermissionLength,0)=1
BEGIN 
DECLARE @ShiftsTable TABLE ( EntryDate SMALLDATETIME,ShiftIn DATETIME,ShiftOut DATETIME,TimeIn DATETIME,TimeOut DATETIME,PermitionFrom SMALLDATETIME,PermitionTo SMALLDATETIME,PermLenght INT)

INSERT INTO @ShiftsTable(EntryDate,ShiftIn,ShiftOut,TimeIn,TimeOut,PermitionFrom,PermitionTo)
SELECT  distinct EmpShiftInOut.EntryDate,EmpShiftInOut.ShiftIn,EmpShiftInOut.ShiftOut,EmpShiftInOut.TimeIn,EmpShiftInOut.TimeOut
,CASE WHEN @FromDate <= EmpShiftInOut.ShiftIn THEN EmpShiftInOut.ShiftIn ELSE @FromDate END
,CASE WHEN @ToDate <= EmpShiftInOut.ShiftOut THEN @ToDate ELSE EmpShiftInOut.ShiftOut end
FROM  EmpShiftInOut WHERE Empid=@Empid  
 AND ((EmpShiftInOut.ShiftIn between @FromDate and @ToDate)
 or  (EmpShiftInOut.ShiftOut between @FromDate and @ToDate)
 or (@FromDate between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (@ToDate between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (EmpShiftInOut.TimeIn between @FromDate and @ToDate) 
or (EmpShiftInOut.TimeOut between @FromDate and @ToDate)
or (@FromDate between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
or (@ToDate between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))

UPDATE @ShiftsTable
SET PermLenght = dbo.PermissionTotalTaken(@empid,@DocNo,PermitionFrom,PermitionTo,1,@PermissionOverShortType,PermitionFrom,PermitionTo) 
SELECT  @TimePermission+=(CASE WHEN SUM(PermLenght) = 28800 THEN  27000  ELSE  SUM(PermLenght) END )   FROM @ShiftsTable GROUP BY EntryDate 
	IF @TimePermission<0 
	SET @TimePermission=0

	END 
	ELSE 
	BEGIN 
		select @TimePermission = dbo.PermissionTotalTaken(@empid,@DocNo,@FromDate,@ToDate,1,@PermissionOverShortType,@FromDate,@ToDate) 
	END 
	
	RETURN @TimePermission 
END

GO

