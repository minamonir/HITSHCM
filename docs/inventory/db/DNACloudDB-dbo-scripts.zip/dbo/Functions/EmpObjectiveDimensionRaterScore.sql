
Create  FUNCTION [dbo].[EmpObjectiveDimensionRaterScore] (@empid as int,@DocumentNo as int ,@RaterProfileid as int)  
RETURNS numeric(18,3)  AS  
begin
--declare  @Score as  numeric(18,3),@totalobjectiveweight numeric(18,3)
--set @totalobjectiveweight=0
--declare @RaterScore table(RaterProfileId int,score numeric (18,3))

--select  top 1   @totalobjectiveweight=sum(EmpObjectives.ObjectiveWeight) 
--FROM EmpAppraisalObjDimensions 
--LEFT JOIN EmpObjectives ON EmpAppraisalObjDimensions.ObjectiveId = EmpObjectives.ObjectiveId 
--AND EmpAppraisalObjDimensions.EmpId = EmpObjectives.EmpId
--where  EmpAppraisalObjDimensions.EmpId=@empid AND EmpAppraisalObjDimensions.DocumentNo=@documentno
-- and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
--group by RaterProfileId

--insert into @RaterScore
--SELECT   EmpAppraisalObjDimensions.RaterProfileId, 
--SUM( RatingLevels.LevelPercent * (case when @totalobjectiveweight=0 then 1 else EmpObjectives.ObjectiveWeight end))/case when @totalobjectiveweight=0 then 1 else @totalobjectiveweight end
--FROM EmpAppraisalObjDimensions 
--LEFT JOIN EmpObjectives ON EmpAppraisalObjDimensions.ObjectiveId = EmpObjectives.ObjectiveId AND EmpAppraisalObjDimensions.EmpId = EmpObjectives.EmpId
--LEFT JOIN ObjectiveDimensions ON ObjectiveDimensions.ObjectiveDimensionsId=EmpAppraisalObjDimensions.ObjectiveDimensionId
--LEFT JOIN RatingScales ON RatingScales.RatingScale = ObjectiveDimensions.RatingScale
--LEFT JOIN RatingLevels ON RatingLevels.RatingScale = RatingScales.RatingScale
	

--where  EmpAppraisalObjDimensions.EmpId=@empid AND EmpAppraisalObjDimensions.DocumentNo=@documentno and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
--group by EmpAppraisalObjDimensions.RaterProfileId

--select  @Score =  avg(score) from @RaterScore
--return  isnull(@Score,0)

declare @Score as  numeric(18,3)
declare @DimensionCategoryScore table(RaterProfileId int,DimensionCategoryId smallint,score numeric (18,3))

INSERT INTO @DimensionCategoryScore
SELECT EmpAppraisalObjDimensions.RaterProfileId,ObjectiveDimensions.ObjectiveDimenssionCategory,AVG(RatingLevels.LevelPercent)
FROM EmpAppraisalObjDimensions 
LEFT JOIN EmpObjectives ON EmpAppraisalObjDimensions.ObjectiveId = EmpObjectives.ObjectiveId AND EmpAppraisalObjDimensions.EmpId = EmpObjectives.EmpId
LEFT JOIN ObjectiveDimensions ON ObjectiveDimensions.ObjectiveDimensionsId=EmpAppraisalObjDimensions.ObjectiveDimensionId
LEFT JOIN RatingScales ON RatingScales.RatingScale = ObjectiveDimensions.RatingScale
LEFT JOIN RatingLevels ON RatingLevels.RatingScale = RatingScales.RatingScale AND RatingLevels.RatingLevel=EmpAppraisalObjDimensions.RatingLevel

where  EmpAppraisalObjDimensions.EmpId=@empid AND EmpAppraisalObjDimensions.DocumentNo=@documentno and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
group by EmpAppraisalObjDimensions.RaterProfileId ,ObjectiveDimensions.ObjectiveDimenssionCategory

declare @RaterScore table(RaterProfileId int,score numeric (18,3))
insert into @RaterScore
SELECT RaterProfileId,AVG(score)
FROM @DimensionCategoryScore
GROUP BY RaterProfileId

select  @Score =  avg(score) from @RaterScore
return  isnull(@Score,0)
END

GO

