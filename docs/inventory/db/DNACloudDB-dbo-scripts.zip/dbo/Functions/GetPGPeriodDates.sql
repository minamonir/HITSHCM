-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE   FUNCTION  [dbo].[GetPGPeriodDates]
(
	@pg smallint ,
	@FieldName Nvarchar(max)

)

RETURNS smalldateTime
AS
BEGIN
	
	declare @Filter smalldateTime 

	select @Filter =
		Case 
			WHEN @FieldName = 'PeriodYearStart' THEN PeriodYearStart
			WHEN @FieldName = 'PeriodYearEnd' THEN PeriodYearEnd
			WHEN @FieldName = 'PeriodStart' THEN PeriodStart
			WHEN @FieldName = 'PeriodEnd' THEN PeriodEnd
			WHEN @FieldName = 'PrevPeriodYearStart' THEN PrevPeriodYearStart
			WHEN @FieldName = 'PrevPeriodYearEnd' THEN PrevPeriodYearEnd
			WHEN @FieldName = 'PrevPeriodStart' THEN PrevPeriodStart
			WHEN @FieldName = 'PrevPeriodEnd' THEN PrevPeriodEnd
			End
		from PayrollGroupPeriodDates
		where Payrollgroup = @pg

	 return @Filter

END

GO

