
CREATE FUNCTION [dbo].[ReportOrgsCheck] (@ReportNo as smallint,@Tablename as nchar(30),@LogonName AS NVARCHAR(80), @UserOrganizations AS NVARCHAR(max)) 
RETURNS NVARCHAR(max)
AS
BEGIN
	DECLARE @Where AS NVARCHAR(max)
	SET @Where=''		
	IF (SELECT SysParam.EnableOrgSetup FROM SysParam ) = 1 AND @UserOrganizations <>''
	BEGIN
		DECLARE @OrgsFields AS NVARCHAR(max), @FieldName AS NVARCHAR(MAX ) 
		SELECT @OrgsFields = ReportsTables.TableOrgFields FROM ReportsTables 
		WHERE ReportNo=@ReportNo AND TableName=@Tablename AND ltrim(rtrim(ReportsTables.TableOrgFields))<>''
		DECLARE OrgFields_Cursor CURSOR FOR SELECT * FROM dbo.HitsStringSplit(@OrgsFields,',')
		OPEN OrgFields_Cursor
		FETCH NEXT FROM OrgFields_Cursor INTO @FieldName
		WHILE @@FETCH_STATUS=0
		BEGIN
			IF ltrim(rtrim(@FieldName))='UserOrganization'
			BEGIN
				SET @where  =@where + ' '+ ' And (isnull('+@FieldName +','''')='''' or exists(select distinct OrganizationParentOrChild from #OrgTree  where '+@FieldName+' like ''%#''+trim(str(OrganizationParentOrChild))+''#%'' and #OrgTree.OrgRelation in (2,3)  ) )
				'
			END
			ELSE IF ltrim(rtrim(@FieldName)) LIKE '%OrganizationOrgs%' AND ltrim(rtrim(@FieldName)) not LIKE '%Organization1.OrganizationOrgs%'
			BEGIN
				SET @where  =@where + ' '+ ' And ( isnull(Organization.Organization,'''')='''' or exists(select distinct OrganizationParentOrChild from #OrgTree  where OrganizationParentOrChild=Organization.Organization and #OrgTree.OrgRelation in (2,3)  ) )
				'
			END
			ELSE IF ltrim(rtrim(@FieldName)) LIKE '%Organization1.OrganizationOrgs%'
			BEGIN
				SET @where  =@where + ' '+ ' And ( isnull(Organization1.Organization,'''')='''' or exists(select distinct OrganizationParentOrChild from #OrgTree  where OrganizationParentOrChild=Organization1.Organization and #OrgTree.OrgRelation in (2,3)  ) )'
			END
			ELSE
			BEGIN
				SET @where  =@where + ' '+ ' And (isnull('+@FieldName +','''')='''' or exists(select distinct OrganizationParentOrChild from #OrgTree      where '+@FieldName+' like ''%#''+trim(str(OrganizationParentOrChild))+''#%''  ) )
				'
			END
			

		FETCH NEXT FROM OrgFields_Cursor INTO @FieldName
		END
		CLOSE OrgFields_Cursor
		DEALLOCATE OrgFields_Cursor		
	END
RETURN @Where
END

GO

