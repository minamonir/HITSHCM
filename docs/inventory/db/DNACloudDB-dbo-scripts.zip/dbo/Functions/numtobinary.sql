
-- =============================================
-- Author:		<Author,,Name>
-- ALTER  date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[numtobinary] (@num int,@base AS smallint,@monthday AS bit)
RETURNS  nvarchar(31)
--as
BEGIN
	
DECLARE @result AS nvarchar(31),@x AS int,@len AS int,@bit AS bit,@days AS nvarchar(31)
SELECT @len=31,@x=0,@result=N''

--IF power(@base,@len)>=@num
--begin
WHILE @num >0 
   BEGIN
   SET @len=@len-1
    SELECT @x=POWER(@base, @len)
    
      IF @x<=@num 
      BEGIN
      SET @num=@num-@x
      SET @result=@result+N'1'
      END
      ELSE
      	SET @result=@result+N'0'
         
   END
--end
SELECT @result = REVERSE (@result+REPLICATE(N'0', 31 - LEN(@result)) )

IF @monthday=1
begin
DECLARE @index AS int
---trial-----------
SET @index=0
---trial-----------
SELECT @days=@result
SET @result=N''
begin
while charindex(N'1',@days,@index)>0
BEGIN
SET @index=charindex(N'1',@days,@index)
SELECT @result=rtrim(ltrim(str(@index)))+N','+rtrim(ltrim(@result))
SET @index=@index+1
END
end
end
RETURN @result
END

GO

