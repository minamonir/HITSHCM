CREATE FUNCTION [dbo].[EmpQuestionsEvaluation]
(
	@EmpID            AS INT,
	@DocumentNo       AS INT,
	@TrainingEval     AS INT,
	@QuestionNo       AS INT
)
RETURNS NUMERIC(18, 3)
AS
  
BEGIN
	DECLARE @Score                    AS NUMERIC(18, 3),
	        @totalQuestionsweight     NUMERIC(18, 3)
	
	SET @totalQuestionsweight = 0
	DECLARE @Sum AS NUMERIC(18, 3)
	DECLARE @QuesScore TABLE(EmpId INT, DocumentNo INT, QuesScore NUMERIC(18, 3))
	
	-- Here we get the sum of all the weights of the questions
	SELECT TOP 1 @totalQuestionsweight = SUM(ISNULL(TrainingEvalQuestions.QuestionWeight, 0))
	FROM   EmpTrainingEvalQuestions
	       LEFT OUTER JOIN TrainingEvalQuestions
	            ON  TrainingEvalQuestions.QuestionNo = EmpTrainingEvalQuestions.QuestionNo
	            AND EmpTrainingEvalQuestions.TrainingEval = 
	                TrainingEvalQuestions.TrainingEval
	       LEFT JOIN Questions
	            ON  Questions.QuestionNo = EmpTrainingEvalQuestions.QuestionNo
	WHERE  EmpTrainingEvalQuestions.EmpId = @EmpID
	       AND EmpTrainingEvalQuestions.DocumentNo = @documentno
	       AND Questions.QuestionType <> 1
	       AND EmpTrainingEvalQuestions.TrainingEval = @TrainingEval
	       AND EmpTrainingEvalQuestions.QuestionNo = CASE 
	                                                      WHEN @QuestionNo IS 
	                                                           NULL THEN 
	                                                           EmpTrainingEvalQuestions.QuestionNo
	                                                      ELSE @QuestionNo
	                                                 END
	-------------------------------------------------------------------------
	
	
	INSERT @QuesScore
	----- here we get the Questions Score of each employee for each question------------------------
	SELECT EmpTrainingEvalQuestions.empid,
	       EmpTrainingEvalQuestions.DocumentNo,
	       MIN(
	           CASE 
	                WHEN CHARINDEX(
	                         LTRIM(RTRIM(STR(QuestionOptions.QuestionOption))) + 
	                         ',',
	                         CAST(EmpTrainingEvalQuestions.QuestionAnswer AS NVARCHAR(MAX))
	                         + ','
	                     ) > 0 THEN correctflag
	                ELSE (CASE WHEN correctflag = 1 THEN 0 ELSE 1 END)
	           END
	       ) * TrainingEvalQuestions.QuestionWeight
	FROM   EmpTrainingEvalQuestions
	       INNER JOIN TrainingEvalQuestions
	            ON  TrainingEvalQuestions.QuestionNo = EmpTrainingEvalQuestions.QuestionNo
	            AND EmpTrainingEvalQuestions.TrainingEval = 
	                TrainingEvalQuestions.TrainingEval
	       LEFT JOIN Questions
	            ON  Questions.QuestionNo = TrainingEvalQuestions.QuestionNo
	       LEFT JOIN QuestionOptions
	            ON  QuestionOptions.QuestionNo = Questions.QuestionNo
	            AND Questions.QuestionType <> 1
	WHERE  EmpTrainingEvalQuestions.EmpId = @EmpID
	       AND EmpTrainingEvalQuestions.DocumentNo = @documentno
	       AND EmpTrainingEvalQuestions.TrainingEval = @TrainingEval
	       AND EmpTrainingEvalQuestions.QuestionNo = CASE 
	                                                      WHEN @QuestionNo IS 
	                                                           NULL THEN 
	                                                           EmpTrainingEvalQuestions.QuestionNo
	                                                      ELSE @QuestionNo
	                                                 END
	       AND Questions.QuestionType <> 1
	GROUP BY
	       EmpTrainingEvalQuestions.empid,
	       EmpTrainingEvalQuestions.DocumentNo,
	       TrainingEvalQuestions.QuestionWeight,
	       EmpTrainingEvalQuestions.QuestionNo
	
	--final value
	SET @Sum = (
	        SELECT SUM(QuesScore) / (
	                   CASE 
	                        WHEN @totalQuestionsweight = 0 THEN 1
	                        ELSE @totalQuestionsweight
	                   END
	               )
	        FROM   @QuesScore
	    ) * 100
	    
	    
	    RETURN ISNULL(@Sum, 0)
END

GO

