
CREATE FUNCTION [dbo].[GetPositionRoles_RecoveryPositionNo] (@PositionNo AS SMALLINT,@RoleID AS SMALLINT,@Param AS NVARCHAR(MAX))
RETURNS nvarchar(max)
AS
BEGIN
	--@positionNo : is my old position
	--@RoleID : is a role that i was playing due to my old position
	--@Param : not used paramter
	
	-- will return with the position who can recover me
 
DECLARE @ParentPositionNo AS nvarchar(max),@Recovery_ProfileID_Count AS INT,@PosStr AS nvarchar(max),@Temp_LastParentPostionNo AS NVARCHAR(MAX)
SET @ParentPositionNo=''
SET @Recovery_ProfileID_Count=0
SET @PosStr=','+rtrim(ltrim(STR(@PositionNo)))+','
SET @Temp_LastParentPostionNo = ''


WHILE @Recovery_ProfileID_Count=0 AND @PosStr<>''
BEGIN

--get my parent position
--Select @ParentPositionNo = PositionParent
--FROM PositionsStructure
--WHERE PositionsStructure.PositionNo = @PositionNo
SET @ParentPositionNo=''
Select @ParentPositionNo = @ParentPositionNo +rtrim(ltrim(str(V_PositionRoles.RolePositionNo)))+','
FROM V_PositionRoles
WHERE @PosStr like '%,'+rtrim(ltrim(STR(V_PositionRoles.PositionNo)))+',%'  AND RoleID=@RoleID
AND @Temp_LastParentPostionNo NOT LIKE '%,'+rtrim(ltrim(str(V_PositionRoles.RolePositionNo)))+',%'

SET @ParentPositionNo=CASE WHEN @ParentPositionNo='' THEN '' ELSE ','+RTRIM(LTRIM(@ParentPositionNo)) END 


--find count of ppl who are playing @roleid on me
SET @Recovery_ProfileID_Count = (select count(EmpAssignment.EmpId)
FROM EmpAssignment
INNER JOIN HrStatus ON HrStatus.hrstatus = EmpAssignment.HrStatus AND HrStatus.paystatus = 1
AND @ParentPositionNo like '%,'+rtrim(ltrim(STR(isnull(EmpAssignment.PositionNo,0))))+',%' )

set @PosStr = @ParentPositionNo
SET @Temp_LastParentPostionNo = @Temp_LastParentPostionNo +  @ParentPositionNo

SET @Recovery_ProfileID_Count=ISNULL(@Recovery_ProfileID_Count,0)

END

RETURN @ParentPositionNo
END

GO

