CREATE FUNCTION dbo.GetObjectiveId()

RETURNS int
as
BEGIN 
  declare @DocumentNo as int
  select top 1 @DocumentNo=ObjectiveId from objectives order by ObjectiveId desc
  set @DocumentNo=isnull(@DocumentNo,0)
   while  1=1
    begin
     if  @DocumentNo>2147483647    set @DocumentNo=1 else set  @DocumentNo=@DocumentNo+1    
     if  not exists (select ObjectiveId  from objectives where ObjectiveId=@DocumentNo)  break 

  end
  return @DocumentNo
END

GO

