

CREATE FUNCTION [dbo].[ItemsAmountPerEmployee]
	(@Empid int, 
	@ActivityNo int, 
	@DocNo smallint 
	,@StartDate datetime 
	,@EndDate datetime, 
	@Type smallint,
	 @Currency SMALLINT
	 ,@CostItemType SMALLINT
	 ,@BookStatus SMALLINT ,
	  @event int)
 RETURNS numeric(18,3) 
AS
BEGIN
	--@CostItemType=1 Dedit
	--@CostItemType=2 Credit
	--@CostItemType=3 ALL
	
	--@BookStatus = 1 Confirmed
	--@BookStatus = 2 Planned
	--@BookStatus = 3 ALL
	
	--@event =0 all else get amount per event
	
	DECLARE @Specific AS numeric(18,3)
	DECLARE @Shared AS numeric(18,3)
	SET @Specific=0
	SET @Shared=0
	

	IF @Type IN (1,3)
	BEGIN 
		SET @Specific = (SELECT Sum( CASE WHEN ActivityCostItems.ActivityCostItemType =1 
										THEN dbo.ConvertAmount(EmpActivityCostItems.CostItemAmount,EmpActivityCostItems.CostItemCurrency,@Currency,EmpActivityCostItems.CostItemDate) 
										ELSE -1*dbo.ConvertAmount(EmpActivityCostItems.CostItemAmount,EmpActivityCostItems.CostItemCurrency,@Currency,EmpActivityCostItems.CostItemDate)  END )
							FROM EmpActivityCostItems 
							LEFT JOIN ActivityCostItems ON ActivityCostItems.ActivityCostItem = EmpActivityCostItems.ActivityCostItem
							LEFT JOIN EmpActivities ON EmpActivities.EmpId = EmpActivityCostItems.EmpId
							                       AND EmpActivities.DocumentNo = EmpActivityCostItems.DocumentNo
							                       AND EmpActivities.ActivityNo = EmpActivityCostItems.ActivityNo
							WHERE EmpActivityCostItems.EmpId = @Empid 
							AND EmpActivityCostItems.ActivityNo=@ActivityNo
							AND EmpActivityCostItems.DocumentNo = @DocNo 
							AND EmpActivities.ActivityStatus = 1 
							AND EmpActivityCostItems.CostItemDate Between @StartDate AND @EndDate 
							
							AND ActivityCostItemType = CASE WHEN @CostItemType=3 THEN ActivityCostItemType ELSE @CostItemType END
							
		)
	END 
	
	IF @Type IN (2,3)
	BEGIN 
		declare @Temp table (amount numeric(18,3))
        INSERT INTO @Temp

		SELECT CASE WHEN ActivityCostItems.ActivityCostItemType =1 
										THEN dbo.ConvertAmount(ActivityEventResources.ActivityResourceQuantity*ActivityResources.UnitCost,ActivityResources.CostCurrency,@Currency, ActivityEvents.ActivityEventStartDate)/count(EmpActivityEvents.Empid)
										ELSE -1*(dbo.ConvertAmount(ActivityEventResources.ActivityResourceQuantity*ActivityResources.UnitCost,ActivityResources.CostCurrency,@Currency, ActivityEvents.ActivityEventStartDate)/count(EmpActivityEvents.Empid))  END AS amount
		FROM EmpActivityEvents
						LEFT JOIN EmpActivities ON EmpActivities.EmpId = EmpActivityEvents.EmpId
							  AND EmpActivities.DocumentNo = EmpActivityEvents.DocumentNo 
							  AND EmpActivities.ActivityNo = EmpActivityEvents.ActivityNo
						LEFT JOIN ActivityEvents ON EmpActivityEvents.ActivityNo = ActivityEvents.ActivityNo
							  AND EmpActivityEvents.ActivityEvent = ActivityEvents.ActivityEvent     
						LEFT JOIN ActivityEventResources ON ActivityEventResources.ActivityNo = ActivityEvents.ActivityNo
							  AND ActivityEventResources.ActivityEvent = ActivityEvents.ActivityEvent
						LEFT JOIN ActivityResources ON ActivityEventResources.ActivityResource =  ActivityResources.ActivityResource
						LEFT JOIN ActivityCostItems ON ActivityCostItems.ActivityCostItem = ActivityResources.ActivityCostItem	   
		              WHERE EmpActivityEvents.DocumentNo= @DocNo 
		              AND EmpActivityEvents.ActivityNo=@ActivityNo
		              AND ActivityEventResources.ActivityResourceQuantity<>0 
		              AND EmpActivityEvents.ActivityEventStatus=1 AND EmpActivities.ActivityStatus=1
		              AND ((ActivityEvents.ActivityEventStartDate BETWEEN @StartDate AND @EndDate )
						Or (ActivityEvents.ActivityEventEndDate   BETWEEN @StartDate AND @EndDate )
						Or ( @StartDate Between ActivityEvents.ActivityEventStartDate And ActivityEvents.ActivityEventEndDate)
						Or ( @EndDate   Between ActivityEvents.ActivityEventStartDate And ActivityEvents.ActivityEventEndDate)) 
						
						AND ActivityCostItemType = CASE WHEN @CostItemType=3 THEN ActivityCostItemType ELSE @CostItemType END
						AND ActivityEventResources.BookStatus = CASE WHEN @BookStatus=3 THEN ActivityEventResources.BookStatus ELSE @BookStatus END
						AND EmpActivityEvents.ActivityEvent= CASE WHEN @event=0 THEN EmpActivityEvents.ActivityEvent ELSE @event END
						
						AND EmpActivityEvents.ActivityEvent 
						    IN (SELECT EmpActivityEvents.ActivityEvent
							   FROM EmpActivityEvents
						LEFT JOIN EmpActivities ON EmpActivities.EmpId = EmpActivityEvents.EmpId
							  AND EmpActivities.DocumentNo = EmpActivityEvents.DocumentNo 
							  AND EmpActivities.ActivityNo = EmpActivityEvents.ActivityNo
						LEFT JOIN ActivityEvents ON EmpActivityEvents.ActivityNo = ActivityEvents.ActivityNo
							  AND EmpActivityEvents.ActivityEvent = ActivityEvents.ActivityEvent     
						WHERE EmpActivityEvents.EmpId=@Empid AND EmpActivityEvents.DocumentNo=@DocNo AND EmpActivityEvents.ActivityNo=@ActivityNo)
						GROUP BY EmpActivityEvents.ActivityNo,EmpActivityEvents.ActivityEvent,ActivityEvents.ActivityEventStartDate,ActivityResources.CostCurrency, ActivityEventResources.ActivityResource
						,ActivityEventResources.ActivityResourceQuantity,ActivityResources.UnitCost,ActivityEvents.ActivityEventName, EmpActivityEvents.DocumentNo, ActivityCostItems.ActivityCostItemType
						
	SELECT @Shared = sum(amount) FROM @Temp
	END
    
return isnull(@Specific,0) + isnull(@Shared,0)
END

GO

