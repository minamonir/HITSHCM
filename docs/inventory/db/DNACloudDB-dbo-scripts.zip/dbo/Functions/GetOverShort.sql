
CREATE               FUNCTION [dbo].[GetOverShort]
	(@EmpId int,  @FromDate smalldatetime, @ToDate smalldatetime, @ValueType as smallint)
 RETURNS numeric(18,3)
AS
BEGIN

--@ValueType=1 over, @ValueType=2 short, @ValueType=3 allowance



declare @returnvalue numeric(18,3)


DECLARE @temp TABLE(Empid INT,paycode smallint,OverValue numeric(18,3))

INSERT INTO @temp
SELECT * FROM dbo.GetOverShortTable(@empid,@FromDate,@ToDate,@valuetype,0,0,1,0,0,0)
SELECT @returnvalue=SUM(ISNULL(overvalue,0)) FROM @temp

RETURN ISNULL(@returnvalue,0)
END

GO

