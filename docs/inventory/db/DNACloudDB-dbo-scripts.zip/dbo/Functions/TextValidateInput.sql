CREATE function [dbo].[TextValidateInput] (@TableName nvarchar(MAX), @FieldName nvarchar(MAX), @FieldValue nvarchar(MAX))
RETURNS bit
AS
BEGIN

--declare @FieldName nvarchar(MAX)=N'', 
--@FieldValue nvarchar(MAX)=N'=test', 
--@TableName nvarchar(MAX)=N''

DECLARE @Valid bit=1
DECLARE @ParamBegin nvarchar(max) 
,@ParamContain nvarchar(max)
--,@ParamBegin1 nvarchar(max) 
,@ParamContain1 nvarchar(max)

select @ParamBegin=ltrim(rtrim(RegEXValue)) from SysParamRegEX 
where RegEXID = 'SQLtextbegin.ValidateInput'

select @ParamContain=ltrim(rtrim(RegEXValue)) from SysParamRegEX 
where RegEXID = 'SQLtextContain.ValidateInput'

select @ParamBegin=isnull(@ParamBegin,N'')
select @ParamContain=isnull(@ParamContain,N'')

--SELECT @ParamBegin1 = REPLICATE(@ParamBegin, LEN(LTRIM(@FieldValue)) - 1)
--SELECT @ParamBegin1 = REPLICATE(@ParamBegin,0)
SELECT @ParamContain1 = REPLICATE(@ParamContain, LEN(LTRIM(@FieldValue)) - 1)

--select @ParamBegin1 as ParamBegin1
--select @ParamContain1 as ParamContain1

SELECT @ParamBegin = @ParamBegin +  '%' 


SELECT @ParamContain = @ParamContain + @ParamContain1 + '%' 


--select @ParamBegin as ParamBegin, @ParamContain as ParamContain
if ((@ParamBegin <> N'' OR @ParamContain <> N'') and @FieldValue<>N'')
begin
IF exists (SELECT * FROM SysParamExTxtValidation  
WHERE RegFieldName=@FieldName and RegTableName=@TableName) 
BEGIN
                                  SET @Valid = 1
END
ELSE

BEGIN
IF ((LTRIM(@FieldValue) not LIKE @ParamBegin)
OR (LTRIM(@FieldValue)  not LIKE @ParamContain))

BEGIN
--print 'like'
								  SET @Valid = 0
END
ELSE
BEGIN
--print 'not like'
                                  SET @Valid = 1
END
END
END
                                  RETURN @Valid

END

GO

