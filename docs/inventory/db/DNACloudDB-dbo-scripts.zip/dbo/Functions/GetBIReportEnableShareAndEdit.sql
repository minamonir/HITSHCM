

CREATE FUNCTION [dbo].[GetBIReportEnableShareAndEdit] (@BIReport AS NVARCHAR(250),@logonname AS NVARCHAR(MAX))
RETURNS SMALLINT
AS
BEGIN

DECLARE @NasUsersBIReports_CanShare AS SMALLINT , @UserGroupBIReports_CanShare AS SMALLINT
SET @NasUsersBIReports_CanShare = -1
SET @UserGroupBIReports_CanShare = -1	
	
--check if i can share report through NasUsersReports
SET  @NasUsersBIReports_CanShare =(SELECT  MAX(CanShare)
FROM NasUsersBIReports 
WHERE BIReport = @BIReport AND ltrim(rtrim(LogonName)) = LTRIM(RTRIM(@logonname)) AND SharedStatus = 1)

IF @NasUsersBIReports_CanShare = 1
BEGIN
--i can share it through my NasUsersBIReports
return 1 
END
ELSE 
BEGIN
--check if i can share it through UserGroupBIReportsBySharing	

SET  @UserGroupBIReports_CanShare = (select MAX(CanShare)
FROM nasusers
 cross apply dbo.HitsStringSplit( OtherUserGroups+'#'+ltrim(nasusers.UserGroup)+'#','#') t
 inner join UserGroupBIReportsBySharing on  (t.value= UserGroupBIReportsBySharing.UserGroup) and t.value <>''  AND ltrim(rtrim(nasusers.LogonName)) = LTRIM(RTRIM(@LogonName))
WHERE BIReport = @BIReport AND SharedStatus = 1)






IF @UserGroupBIReports_CanShare = 1
return 1  
ELSE 
return 0  

END

--dummy return
RETURN 1
END

GO

