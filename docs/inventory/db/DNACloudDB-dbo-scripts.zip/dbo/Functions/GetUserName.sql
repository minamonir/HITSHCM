CREATE     FUNCTION [dbo].[GetUserName](@logonName nvarchar(80),@lang nvarchar(10))
RETURNS nvarchar(88)
AS
	BEGIN
		  Declare @Result nvarchar(88)
		  Select @Result=
			Case 
			 When @lang='A' Then  LTRIM(RTRIM(P.AName)) else LTRIM(RTRIM(P.Name))
			End 
		  from NasUsers NS 
		  inner join Profile P on NS.EmpId=P.ProfileId and LTRIM(RTRIM(NS.LogonName))=LTRIM(RTRIM(@logonName))
		  Return ISNULL( @Result,@logonName)
    END

GO

