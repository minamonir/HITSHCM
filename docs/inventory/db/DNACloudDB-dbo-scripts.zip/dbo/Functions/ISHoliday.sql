
CREATE FUNCTION [dbo].[ISHoliday]  (@empid AS int , @Date AS SMALLDATETIME , @HolidayOrDayoff AS SMALLINT =1 )
RETURNS SMALLINT
AS
BEGIN
--@HolidayOrDayoff = 1  -> Holiday
--@HolidayOrDayoff = 2 -> Dayoff


--if  @HolidayOrDayoff = 1  -> Holiday
		--- if  date  -> not Holiday then return 0
		--> Holiday then return 1
		--> there is an existed vacation with setup CountHoliday return 2
		--> there is an existed vacation with setup NotCountHoliday return 3

--if  @HolidayOrDayoff = 2  -> Dayoff
		--- if  date  -> not Dayoff then return 0
		--> Holiday then return 1
		--> there is an existed vacation with setup CountDayoff return 2
		--> there is an existed vacation with setup otCountDayoff return 3		


	DECLARE @VacPack AS INT,@IsHoliday AS INT=0,@vacType AS SMALLINT = 0
	
    SELECT @VacPack=ISNULL(dbo.GetOldValue(@empid,19,@Date+1,EmpAssignment.HrCurrency),vacpack)
	FROM dbo.EmpAssignment
	WHERE empid=@empid

	SELECT @IsHoliday=COUNT(*) FROM dbo.Holidays WHERE vacpack=@VacPack AND date=@date AND holiday=1 
	
	SET @IsHoliday= ISNULL(@IsHoliday,0)

	IF @IsHoliday=1
	BEGIN

	SET @vacType=1

	SELECT @vacType = CASE WHEN @HolidayOrDayoff=1 THEN 
	CASE  WHEN   DoNotCountHoliday = 0 THEN 2
		  WHEN   DoNotCountHoliday = 1 THEN 3 end
			
	
	ELSE
		CASE  WHEN   DoNotCountDayoff = 0 THEN 2
		       WHEN   DoNotCountDayoff = 1 THEN 3 end
	
	 end
				FROM EmpVacat 
				LEFT JOIN Vacation ON Vacation.vaccode = EmpVacat.VacCode
				LEFT JOIN EmpAssignment ON EmpAssignment.EmpId = EmpVacat.EmpId
				WHERE EmpVacat.EmpId = @empid AND @Date  BETWEEN  FromDate AND ToDate AND EmpVacat.VacStatus=1

	END

	
					
	
	RETURN @vacType
END

GO

