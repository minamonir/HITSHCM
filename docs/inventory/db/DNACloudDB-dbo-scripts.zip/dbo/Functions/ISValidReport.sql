CREATE FUNCTION [dbo].[ISValidReport](@SharedBY AS nvarchar(80),@ReportNo AS SMALLINT,@SharedTo AS nvarchar(80),@UserGroup AS Bit)
RETURNS INT
AS
BEGIN
	DECLARE @ISValid AS INT=0
	--DECLARE @SharedToUserGroup AS SMALLINT
	DECLARE @AllUserGroups AS NVARCHAR(max)=''
	IF @UserGroup=0
	BEGIN
		--SELECT @SharedToUserGroup = usergroup FROM NasUsers WHERE LogonName=@SharedTo
		SELECT @AllUserGroups = NasUsers.OtherUserGroups+'#'+LTRIM(NasUsers.UserGroup)+'#' FROM NasUsers WHERE LogonName=@SharedTo
	END
	ELSE
	BEGIN
		--SELECT @SharedToUserGroup=cast(@SharedTo AS INT)
		SELECT @AllUserGroups=@SharedTo
	END
	IF EXISTS(SELECT * FROM UserGroupReports WHERE UserGroupReports.ReportNo=@ReportNo AND UserGroupReports.UserGroup /*=@SharedToUserGroup*/ IN (SELECT ALLUG.value FROM dbo.HitsStringSplit(@AllUserGroups,'#') AS ALLUG) )
	OR EXISTS(SELECT * FROM nasusersreports WHERE ReportNo=@ReportNo AND LogonName=@SharedTo AND SharedStatus=1 and CanShare=1 AND sharetype=0 AND (@UserGroup=0 AND Sharedby<> @SharedBY ))
	OR EXISTS(SELECT * FROM UserGroupReportsbysharing WHERE ReportNo=@ReportNo AND UserGroup /*=@SharedToUserGroup*/ IN (SELECT ALLUG.value FROM dbo.HitsStringSplit(@AllUserGroups,'#') AS ALLUG) AND SharedStatus=1 AND CanShare=1  AND ((Sharedby<> @SharedBY AND @UserGroup<>0) OR (@UserGroup=0 AND  Sharedby<> @SharedTo) ) )
	BEGIN
		SET @ISValid=1
	END
	ELSE
	BEGIN
		set @ISValid=0
	END
	RETURN @ISValid
END

GO

