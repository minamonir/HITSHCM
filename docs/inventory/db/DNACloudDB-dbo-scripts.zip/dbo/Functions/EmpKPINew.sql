

/*This fn calculates the KPI number 
--and ignore zero level percent for the employees
@emp is the number of the employee
@posorJob in [0,1,2] then the calc is based on [Job,Position,organization]competencies respectively
@code is the code no for specific job or position or organization
@level [low or high]
*/
CREATE FUNCTION [dbo].[EmpKPINew] (@empid as int,@posorjob as int ,@code as smallint,@level as nchar,@docno as int)   
-- ignore zero level percent for the employees
RETURNS numeric(9,3)  AS  
begin
if @code is null return 0
declare @weight as numeric(9,3)
declare @KPI as numeric(9,3)
set @KPI=0
declare @EmpPercent as numeric(9,3)
declare @CompPercent as numeric(9,3)
declare @CompWeight as numeric(9,3)
declare @empweight as numeric(9,3)
declare @codeweight as numeric(9,3)
set @empweight=0
set @codeweight=0

--for job
if @posorjob=0
begin

select @empweight=isnull(sum(CASE WHEN isnull(CL.LevelPercent ,0.0)>0 THEN isnull(CL.LevelPercent ,0.0)*isnull(jobCompetence.weight,0.0) ELSE 0.0 END),0.0)
,@codeweight=isnull(sum(CASE WHEN isnull(CL.LevelPercent ,0.0)>0 THEN isnull(LevelsCompetence.LevelPercent,0.0)*isnull(jobCompetence.weight,0.0) ELSE 0.0 end),0.0)
from empappraisalcomp 
left join jobCompetence  on jobCompetence.Competence=empappraisalcomp.Competence and  empappraisalcomp.EmpId=@empid and empappraisalcomp.documentno = @docno 
left join LevelsCompetence on LevelsCompetence.Competence=jobCompetence.Competence 
and LevelsCompetence.ratinglevel=case when @level=N'L' then jobCompetence.LowLevel else jobCompetence.HighLevel end
left JOIN dbo.LevelsCompetence CL ON 
EmpAppraisalComp.Competence = CL.Competence and   EmpAppraisalComp.RatingLevel = cl.RatingLevel
where jobCompetence.Job=@code  and  empappraisalcomp.EmpId=@empid and empappraisalcomp.documentno = @docno 

end
--for position
else
if @posorjob=1
begin
select 
@empweight=isnull(sum(CASE WHEN isnull(CL.LevelPercent ,0.0) >0 THEN  isnull(CL.LevelPercent ,0.0)*isnull(PositionCompetence.weight,0.0) ELSE 0.0 END),0.0)
,@codeweight=isnull(sum(CASE WHEN isnull(CL.LevelPercent ,0.0) >0 THEN  isnull(LevelsCompetence.LevelPercent,0.0)*isnull(PositionCompetence.weight,0.0) ELSE 0.0 end),0.0)
from empappraisalcomp 
left join PositionCompetence  on PositionCompetence.Competence=empappraisalcomp.Competence and  empappraisalcomp.EmpId=@empid and empappraisalcomp.documentno = @docno 
left join LevelsCompetence on LevelsCompetence.Competence=PositionCompetence.Competence 
and LevelsCompetence.ratinglevel=case when @level=N'L' then PositionCompetence.LowLevel else PositionCompetence.HighLevel end
left JOIN dbo.LevelsCompetence CL ON 
EmpAppraisalComp.Competence = CL.Competence and   EmpAppraisalComp.RatingLevel = cl.RatingLevel
where PositionCompetence.PositionNo=@code  and  empappraisalcomp.EmpId=@empid and empappraisalcomp.documentno = @docno 

end

--for organization
else
if @posorjob=2
begin

select 
@empweight=isnull(sum(CASE WHEN isnull(CL.LevelPercent ,0.0) >0 THEN isnull(CL.LevelPercent ,0.0)*isnull(OrgCompetence.weight,0.0) ELSE 0.0 END),0.0)
,@codeweight=isnull(sum(CASE WHEN isnull(CL.LevelPercent ,0.0) >0 THEN isnull(LevelsCompetence.LevelPercent,0.0)*isnull(OrgCompetence.weight,0.0) ELSE 0.0 end),0.0)
from empappraisalcomp 
left join OrgCompetence  on OrgCompetence.Competence=empappraisalcomp.Competence and  empappraisalcomp.EmpId=@empid and empappraisalcomp.documentno = @docno 
left join LevelsCompetence on LevelsCompetence.Competence=OrgCompetence.Competence 
and LevelsCompetence.ratinglevel=case when @level=N'L' then OrgCompetence.LowLevel else OrgCompetence.HighLevel end
left JOIN dbo.LevelsCompetence CL ON 
EmpAppraisalComp.Competence = CL.Competence and   EmpAppraisalComp.RatingLevel = cl.RatingLevel
where OrgCompetence.organization=@code  and  empappraisalcomp.EmpId=@empid and empappraisalcomp.documentno = @docno 
end
else
return 0



--open EmpComp
--
--Fetch next from EmpComp 
--into @EmpPercent,@CompPercent,@CompWeight
--if @@fetch_status <> 0 return 0
--while @@fetch_status =0
--begin
--if @EmpPercent>0
--begin
--set @empweight=@empweight+(@EmpPercent*@CompWeight)
--set @codeweight=@codeweight+(@CompPercent*@CompWeight)
--end
--FETCH NEXT FROM EmpComp 
--INTO @EmpPercent,@CompPercent,@CompWeight 
--
--end
--close EmpComp 
--deallocate EmpComp 
if @codeweight=0.0 return @KPI

set @KPI=@empweight/@codeweight
return @KPI
--End

end

GO

