


CREATE   FUNCTION [dbo].[treeviewOrgWhere] (@str nvarchar(max) )
RETURNS Nvarchar(max)
BEGIN 
-- declare @str as nvarchar(max)=' and organization.organization in (select #temporg.organization from #temporg)'

--set @str= replace (@str,ltrim(rtrim(@tablename))+'.'+ltrim(rtrim(@fieldname)),'')
--set @str= replace (@str,' and ' ,'')
--set @str= replace (@str,' in' ,'')
set @str='isnull('+substring(@str,charindex('(',@str),len(@str))+','''')'

--set @str='isnull((select #temporg.organization from #temporg),'''')'
set @str=replace (@str,'select ','select ''#''+ STRING_AGG(')
set @str=replace (@str,' from ',  ', ''#'' )+''#'' from ')

  
  Return @str
  
END

GO

