






CREATE               FUNCTION [dbo].[GetShiftTimeold]
	(@EmpId int,  @EntryDate smalldatetime,  @ValueType as smallint)
 RETURNS datetime
AS
BEGIN
--@ValueType=1 TimeIn1
--@ValueType=2 TimeOut1
--@ValueType=3 TimeIn2
--@ValueType=4 TimeOut2
declare @returndate AS datetime, @shiftin1 as datetime, @shiftOut1 as datetime, 
  @shiftin2 as datetime, @shiftOut2 as datetime
select @shiftin1=null, @shiftOut1=null, @shiftin2=null, @shiftOut2=null
select @shiftin1=min(ShiftIn), @shiftout1=max(Shiftout) from EmpShiftInOut 
   where ShiftTimeNo=1 and empid=@empid and entrydate=@entrydate and ShiftIn is not null 
select @shiftin2=min(ShiftIn), @shiftout2=max(Shiftout) from EmpShiftInOut 
   where ShiftTimeNo=2 and empid=@empid and entrydate=@entrydate and ShiftIn is not null 
if @shiftin1 is null
begin
  if @ValueType=1 select @returndate=min(TimeIn) from EmpShiftInOut 
     where WorkSeconds<>0 and empid=@empid and entrydate=@entrydate and timein is not null  
  if @ValueType=1 and @returndate is null select @returndate=min(TimeIn) from EmpShiftInOut 
     where empid=@empid and entrydate=@entrydate and timein is not null  
  if @ValueType=2 select @returndate=max(TimeOut) from EmpShiftInOut 
     where WorkSeconds<>0 and empid=@empid and entrydate=@entrydate and timeout is not null 
  if @ValueType=2 and @returndate is null select @returndate=max(TimeOut) from EmpShiftInOut 
     where empid=@empid and entrydate=@entrydate and timeout is not null 
end
else
begin
  if @ValueType=1 select @returndate=min(TimeIn) from EmpShiftInOut 
     where WorkSeconds<>0 and ShiftTimeNo=1 and empid=@empid and entrydate=@entrydate and timein is not null 
  if @ValueType=1 and @returndate is null select @returndate=min(TimeIn) from EmpShiftInOut 
     where empid=@empid and entrydate=@entrydate and timein is not null and timein<@shiftout1
  if @ValueType=2 select @returndate=max(TimeOut) from EmpShiftInOut 
     where WorkSeconds<>0 and ShiftTimeNo=1 and empid=@empid and entrydate=@entrydate and timeout is not null 
  if @shiftin2 is not null
  begin
    if @ValueType=2 and @returndate is null select @returndate=max(TimeOut) from EmpShiftInOut 
       where empid=@empid and entrydate=@entrydate and timeout is not null and timeout<@shiftin2
    if @ValueType=3 select @returndate=min(TimeIn) from EmpShiftInOut 
       where WorkSeconds<>0 and ShiftTimeNo=2 and empid=@empid and entrydate=@entrydate and timein is not null 
    if @ValueType=3 and @returndate is null select @returndate=min(TimeIn) from EmpShiftInOut 
       where empid=@empid and entrydate=@entrydate and timein is not null and timein>@shiftout1
    if @ValueType=4 select @returndate=max(TimeOut) from EmpShiftInOut 
      where WorkSeconds<>0 and ShiftTimeNo=2 and empid=@empid and entrydate=@entrydate and timeout is not null 
    if @ValueType=4 and @returndate is null select @returndate=max(TimeOut) from EmpShiftInOut 
      where empid=@empid and entrydate=@entrydate and timeout is not null and TimeOut>@shiftin2
  end
  else
  begin
    if @ValueType=2 and @returndate is null select @returndate=max(TimeOut) from EmpShiftInOut 
       where empid=@empid and entrydate=@entrydate and timeout is not null 
       
	if @ValueType=1 and @returndate is null select @returndate=min(Timein) from EmpShiftInOut 
	where empid=@empid and entrydate=@entrydate and timein is not NULL

  end
end

return @returndate
END

GO

