CREATE FUNCTION [dbo].[GetValidOrgParentOld]  (@org smallint,  @date AS smalldatetime,@RoleID AS NVARCHAR(MAX))
RETURNS  smallint
AS
BEGIN 

DECLARE @orgParent AS int,@valid AS int, @RoleFields AS nvarchar(max)
DECLARE @Roles TABLE (RoleId smallint)

SET @valid =0
SELECT @RoleID=ISNULL(@RoleID,'')

WHILE @valid =0
BEGIN

	SELECT @orgParent= OrganizationParent 
	FROM Organization 
	LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization
	WHERE Organization.Organization=@org

	IF @orgParent IS NULL SET @valid =1
	ELSE
	BEGIN
		SELECT @valid=CASE WHEN 
		(CASE WHEN sysparam.EnableDateValidation=1 then (CASE WHEN convert(nchar(10),@date,111)  between (isnull([OrganizationFromDate],  convert(nchar(10),@date,111)) ) 
		and (isnull([OrganizationToDate] , convert(nchar(10),@date,111))) THEN 1 ELSE 0 END) ELSE 1 END)=1
		and (CASE WHEN sysparam.enablerolevalidation =1 AND @RoleID <> N''  THEN ((dbo.RolesExist(@RoleID,N'$'+ISNULL(organization.OrganizationRoles,N'')+N'$',0,0))) ELSE 1 END)=1
		THEN 1 ELSE 0 END 
 		FROM organization
		CROSS JOIN SysParam 
		WHERE organization.Organization=@orgParent
	END

	SET @org=@orgParent
END

RETURN @orgParent

END

GO

