CREATE FUNCTION [dbo].[getTaskRolesProfiles](@empid AS INT , @documentno AS INT )
RETURNS NVARCHAR(MAX)
AS
BEGIN 
DECLARE @TaskPrivacy AS SMALLINT,  @roles AS NVARCHAR(MAX) ,@ssgroup AS int ,@roleprofile AS NVARCHAR(max)='',@profileid AS INT ,@roleid AS SMALLINT ,@asignedfrom AS INT 
SELECT @TaskPrivacy=TaskPrivacy, @roles = TaskPrivacyRoles,@ssgroup=empassignment.SSGroup,@asignedfrom=AssignedFrom FROM emptask 
                                 left join empassignment on empassignment.empid = emptask.EmpId
                                  WHERE emptask.empid =@empid AND emptask.documentno=@documentno

IF @TaskPrivacy=2
BEGIN 
DECLARE Role_Cursor CURSOR FOR SELECT DISTINCT profileid,roleid FROM ssgrouprole WHERE ssgroup=@ssgroup
  OPEN Role_Cursor
  FETCH NEXT FROM Role_Cursor INTO   @profileid,@roleid
  WHILE @@FETCH_STATUS = 0
  BEGIN
  	IF  CHARINDEX('#'+ltrim(rtrim(str(@roleid)))+'#',@roles)>0
       SELECT @roleprofile =@roleprofile+'#'+ltrim(rtrim(str(@profileid)))+'#'

  FETCH NEXT FROM Role_Cursor INTO   @profileid,@roleid
     END
  CLOSE Role_Cursor
  DEALLOCATE Role_Cursor
  END 
  IF @TaskPrivacy <>3
   BEGIN 
	   SELECT @roleprofile = @roleprofile +'#'+ltrim(rtrim(str(@empid)))+'#'+'#'+LTRIM(RTRIM(STR(@asignedfrom)))+'#'     
   END 
   ELSE
   	BEGIN  
   		set @roleprofile=''
   	END               
RETURN @roleprofile                                  
END

GO

