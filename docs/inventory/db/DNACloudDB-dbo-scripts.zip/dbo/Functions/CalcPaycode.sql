--this fn calculate the amount for certain paycode

CREATE           FUNCTION [dbo].[CalcPaycode]  (@calc_empid int, @calc_code smallint, @calc_input numeric(18,3), @calc_balance  numeric(18,3))
RETURNS numeric(18,3) AS  
begin

--@l_basedonperiod=0 current period
--@l_basedonperiod=1 prev period
--@l_basedonperiod=2 start of year

declare @l_cmonth As smallint
declare @l_cyear As smallint
declare @l_basedon As smallint
declare @l_basedonperiod As smallint
declare @l_calcpaycd As smallint
declare @l_calcgrpcode As smallint
declare @l_inputtp As smallint
declare @l_factor As numeric(9,5)
declare @l_monthdays As smallint
declare @l_dayhours As smallint
declare @l_amount As numeric(18,3)
declare @l_formula as nvarchar(MAX)
declare @l_runno as smallint
declare @l_NetOrTotal as smallint
declare @l_NoofPeriods As smallint

DECLARE @Pay_RunNo table (RunNo smallint not null)

set @calc_empid=isnull(@calc_empid,0)
set @calc_code=isnull(@calc_code,0)
set @calc_input=isnull(@calc_input,0)
set @calc_balance=isnull(@calc_balance,0)

if @calc_empid = 0  return 0.0

select @l_basedon=basedon, @l_basedonperiod=basedonperiod, @l_NetOrTotal=NetOrTotal,
  @l_calcpaycd=case when calcpaycd=code then 0 else calcpaycd end,
  @l_calcgrpcode=case when calcgrpcode=grpcode then 0 else calcgrpcode end, 
  @l_inputtp=inputtp, @l_basedon=basedon, @l_factor=factor 
from paycode Where Code=@calc_code

set @l_factor=case when @l_factor=0 then 1 else @l_factor end

select @l_monthdays=monthdays, @l_dayhours=dayhours, @l_cmonth=cmonth, 
  @l_cyear=cyear, @l_runno=runno, @l_NoofPeriods=NoofPeriods
  from empassignment e inner join payrollgroup p on p.payrollgroup=e.payrollgroup
  where e.empid=@calc_empid



set @l_monthdays=case when @l_monthdays=0 then 30 else @l_monthdays end
set @l_dayhours=case when @l_dayhours=0 then 8 else @l_dayhours end

if @l_basedonperiod=2 --start of year
begin
  if EXISTS (SELECT ISNULL([Month], 0) FROM HistoryPayroll
             WHERE (EmpId = @calc_empid) AND ([Year] = @l_cyear)) 
  begin
    SELECT top 1 @l_cmonth=ISNULL([Month], 0) FROM HistoryPayroll
      WHERE   (EmpId = @calc_empid) AND ([Year] = @l_cyear) order by month
  end
  else set @l_basedonperiod=0
end

if @l_basedonperiod=1 --previous period
begin
  if EXISTS (SELECT [Month] FROM HistoryPayroll
       WHERE (EmpId = @calc_empid) AND 
        ([Year]*100+[Month]=(case when @l_cmonth=1 then (@l_cyear-1)*100+@l_NoofPeriods else @l_cyear*100+(@l_cmonth-1) end ) ))
  begin
   -- select @l_cmonth=case when @l_cmonth=1 then 12 else @l_cmonth-1 end, 
   --   @l_cyear=case when @l_cmonth=1 then @l_cyear-1 else @l_cyear end
   if @l_cmonth=1  select @l_cmonth=@l_NoofPeriods, @l_cyear=@l_cyear-1 else select @l_cmonth=@l_cmonth-1 
  end
  else set @l_basedonperiod=0
end

if @l_NetOrTotal=2 
begin
  if @l_basedonperiod=0 --current period
    insert into @Pay_RunNo  SELECT PayrollGroupRuns.RunNo FROM  EmpAssignment inner join PayrollGroupRuns
      on EmpAssignment.payrollgroup=PayrollGroupRuns.payrollgroup inner join PayrollGroupRuns r on
       PayrollGroupRuns.payrollgroup=r.payrollgroup and r.runno=@l_runno 
    where EmpAssignment.empid=@calc_empid and PayrollGroupRuns.runorder<=r.runorder and PayrollGroupRuns.RunNo is not null
  else
    insert into @Pay_RunNo  SELECT PayrollGroupRunsHistory.RunNo FROM  EmpAssignment inner join PayrollGroupRunsHistory
     on EmpAssignment.payrollgroup=PayrollGroupRunsHistory.payrollgroup inner join PayrollGroupRunsHistory r on
      PayrollGroupRunsHistory.payrollgroup=r.payrollgroup and r.runno=@l_runno and 
       PayrollGroupRunsHistory.year=@l_cyear and PayrollGroupRunsHistory.month=@l_cmonth 
    where EmpAssignment.empid=@calc_empid and r.year=@l_cyear and r.month=@l_cmonth and
     PayrollGroupRunsHistory.runorder<=r.runorder  and PayrollGroupRunsHistory.RunNo is not null
if not exists(select RunNo from @Pay_RunNo)
begin
  declare @n_runno as smallint
  set @n_runno=1
  while @n_runno<=@l_runno
  begin
    insert into @Pay_RunNo (runno) values (@n_runno)
    set @n_runno=@n_runno+1
  end
end 
end
else  insert into @Pay_RunNo (runno) values (@l_runno)


    
if @l_basedonperiod=0 --current period
begin
if @l_basedon=6 --based on formula
begin
   select @l_formula=formulatxt from paycode Where Code=@calc_code
   if ''<>ltrim(@l_formula)
   begin
     SELECT  @l_formula=CASE WHEN charindex('p'+REPLACE(str(paycode.code,3),' ','0'),@l_formula )>0 THEN 
        replace(@l_formula,'p'+REPLACE(str(paycode.code,3),' ','0'),CASE WHEN paycode.type =2 OR paycode.code  IN (901,902,910,911,912) 
      THEN -1 ELSE 1 END * isnull(sum(Amount * case when monthlytransaction.transactioninactive=0 then 1 else 0 end),0)) 
          ELSE @l_formula end
     FROM paycode LEFT JOIN MonthlyTransaction ON Paycode= paycode.code AND empid=@calc_empid and 
       (runno is null or runno in (select runno from @Pay_RunNo))    
     GROUP BY paycode.code,paycode.type
     --remove comment for formula calc
     SELECT @l_amount=dbo.x_FormulaEval(@l_formula,' FROM Empassignment  inner join payrollgroup on empassignment.payrollgroup = payrollgroup.payrollgroup  inner join profile on Empassignment.empid=profile.profileid WHERE Empassignment.EmpId='+LTRIM(STR(@calc_empid))) 
   end  
 end
else
begin
    select @l_amount=sum(case 
      when @l_basedon=4 and paycode.code=isnull(@l_calcpaycd,0) then monthlytransaction.amount *
         (case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
      when @l_basedon=5 and paycode.grpcode=isnull(@l_calcgrpcode,0) then monthlytransaction.amount*
         (case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end) else 0 end)
    from monthlytransaction inner join empassignment on empassignment.empid=monthlytransaction.empid 
      inner join payrollgroup on payrollgroup.payrollgroup=empassignment.payrollgroup 
      inner join paycode on paycode.code=monthlytransaction.paycode 
    where empassignment.empid=@calc_empid and monthlytransaction.transactioninactive=0 
      and monthlytransaction.runno in (select runno from @Pay_RunNo)

    select @l_amount=case when @l_basedon=1 then basicsal when @l_basedon= 2 then totalsal 
       when @l_basedon= 3 then ssbonval else @l_amount end
    from empassignment where empid=@calc_empid
  end
end
else
begin
if @l_basedon=6 --based on formula
begin
   select @l_formula=formulatxt from paycode Where Code=@calc_code
   if ''<>ltrim(@l_formula)
   begin
     SELECT  @l_formula=CASE WHEN charindex('p'+REPLACE(str(paycode.code,3),' ','0'),@l_formula )>0 THEN 
        replace(@l_formula,'p'+REPLACE(str(paycode.code,3),' ','0'),CASE WHEN paycode.type =2 OR paycode.code  IN (901,902,910,911,912) 
      THEN -1 ELSE 1 END * isnull(sum(Amount),0)) ELSE @l_formula end
      from paycode left join HistoryTransaction 
        on HistoryTransaction.paycode=paycode.code and historytransaction.year=@l_cyear and
         HistoryTransaction.month=@l_cmonth and (runno is null or runno in (select runno from @Pay_RunNo))    
      and HistoryTransaction.empid=@calc_empid 
       GROUP BY paycode.code,paycode.type
    --remove comment for formula calc
    SELECT @l_amount=dbo.x_FormulaEval(@l_formula,' FROM Empassignment inner join profile on Empassignment.empid=profile.profileid WHERE Empassignment.EmpId='+LTRIM(STR(@calc_empid)))
   end  
 end
else
begin
  select @l_amount=sum(case 
    when (@l_basedon=1 and paycode.code=100) then HistoryTransaction.amount
    when (@l_basedon=2 and paycode.addtotsal=1) then HistoryTransaction.amount 
    when (@l_basedon=4 and paycode.code=isnull(@l_calcpaycd,0)) then HistoryTransaction.amount *
       (case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
    when (@l_basedon=5 and paycode.grpcode=isnull(@l_calcgrpcode,0)) then HistoryTransaction.amount*
      (case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
    else 0 end)
  from  HistoryTransaction 
    inner join paycode on HistoryTransaction.paycode=paycode.code 
  where HistoryTransaction.empid=@calc_empid and historytransaction.year=@l_cyear and
         HistoryTransaction.month=@l_cmonth and HistoryTransaction.runno in (select runno from @Pay_RunNo)
         
  select @l_amount=case when @l_basedon=3 then empassignment.ssbonval else @l_amount end
  from empassignment where empid=@calc_empid
end
end

IF @l_basedon IN (4,5) SELECT @l_amount=isnull(@l_amount,0.0) * CASE WHEN type=2 THEN -1 ELSE 1 END FROM paycode WHERE code=@calc_code
set @l_amount = isnull(@l_amount,0.0)

set @l_amount=case @l_inputtp 
     when 1 then @calc_input 
     when 2 then @calc_input*@l_amount*@l_factor/@l_monthdays
     when 3 then @calc_input*@l_amount*@l_factor/(@l_monthdays*@l_dayhours) 
     when 4 then @calc_input*@l_amount*@l_factor/100 end


select @l_amount=round(@l_amount,decimalscale) from sysparam

RETURN @l_amount
end

GO

