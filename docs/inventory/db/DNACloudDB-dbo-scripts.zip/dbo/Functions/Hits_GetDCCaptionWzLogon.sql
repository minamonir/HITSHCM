CREATE FUNCTION [dbo].[Hits_GetDCCaptionWzLogon]
(@TableName NVARCHAR(50)
,@FieldName NVARCHAR(50)
,@Lang		NCHAR(1)
,@LogonName NVARCHAR(80))
RETURNS NVARCHAR(100)
AS
BEGIN
	DECLARE @UserOrg AS NVARCHAR(max)=''
	IF EXISTS (SELECT * FROM SysParam WHERE SysParam.EnableOrgSetup=1)
	BEGIN
		SELECT @UserOrg = NasUsers.UserOrganization FROM NasUsers WHERE NasUsers.LogonName = @LogonName 
	END
	
	IF ISNULL(@Lang, N'') = N'' SELECT @Lang  = ErrorLang FROM SysParam
	
	DECLARE @Caption AS NVARCHAR(100)

	SELECT @Caption=LTRIM(RTRIM(CASE WHEN @Lang = 'A' THEN ISNULL(OrganizationDCDifference.ACaption, DataDictionary.ACaption)
									 WHEN @Lang = 'F' THEN ISNULL(OrganizationDCDifference.FCaption, DataDictionary.FCaption)
									 ELSE ISNULL(OrganizationDCDifference.Caption, DataDictionary.Caption)END))		
	FROM DataDictionary 
	LEFT JOIN (SELECT ROW_NUMBER() OVER (PARTITION BY OrganizationDCDifference.TableName,OrganizationDCDifference.FieldName ORDER BY OrganizationDCDifference.TableName,OrganizationDCDifference.FieldName,OrganizationDCDifference.Organization) AS FirstRowNo,* 
			FROM OrganizationDCDifference WHERE OrganizationDCDifference.Organization IN (SELECT HitsStringSplit.value FROM dbo.HitsStringSplit(@UserOrg,'#'))) AS OrganizationDCDifference 
	ON DataDictionary.TableName = OrganizationDCDifference.TableName AND DataDictionary.FieldName = OrganizationDCDifference.FieldName AND FirstRowNo=1
	WHERE DataDictionary.TableName=@TableName AND DataDictionary.FieldName=@FieldName 

	RETURN @Caption
END

GO

