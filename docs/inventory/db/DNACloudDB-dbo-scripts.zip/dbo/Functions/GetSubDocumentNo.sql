

CREATE  FUNCTION [dbo].[GetSubDocumentNo] (@empid int, @assignmentId int , @interviewType smallint , @ssdoctype smallint)
RETURNS  int
as
BEGIN 
  declare @DocumentNo as int
   --AppInterviews
   if @SSDocType=29 select top 1 @DocumentNo=DocumentNo from AppInterviews where Empid=@empid and AssignmentId=@assignmentId order by Empid, DocumentNo desc
    set @DocumentNo=isnull(@DocumentNo,0)

   while  1=1
    begin
     if  @DocumentNo>2147483647    set @DocumentNo=1 else set  @DocumentNo=@DocumentNo+1 
     --AppInterviews    
     if @SSDocType=29 and not exists (select DocumentNo from AppInterviews where Empid=@empid and AssignmentId=@assignmentId  and documentno = @DocumentNo )  break
  end
  return @DocumentNo
END

GO

