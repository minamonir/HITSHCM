

CREATE FUNCTION [dbo].[hits_GetAnniversaryDate]
(@empid as int, @Date AS smalldatetime, @StartOrEnd AS bit, @number AS int)
RETURNS datetime 
AS 
BEGIN
	DECLARE @startDate AS smalldatetime, @endDate AS smalldatetime, @termdate AS smalldatetime
	DECLARE @enablehijri AS bit, @year AS smallint
	
	SELECT @startDate=HireDate,@year=Cyear, @enablehijri=EnableHijri,@termdate=EmpAssignment.TermDate
	      from EmpAssignment inner join PayrollGroup on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup CROSS JOIN SysParam where EmpId=@empid
	      
	IF @Date < @startDate RETURN @Date --invalid date, before hire date, return 0 and EXIT
	IF @Date > @termdate RETURN @Date --invalid date, after termination date, return 0 and EXIT	
	--------------------------------------------------
	IF @enablehijri=1 and @year<1900 
	BEGIN
		
		SET @endDate=(dbo.h_dateadd('YEAR',@number,@startdate))-1
	
		WHILE (@Date NOT BETWEEN @startDate AND @endDate) --looping till we find the right interval
		BEGIN
			SET @startDate=dbo.h_dateadd('DAY',1,@endDate)
			SET @endDate=(dbo.h_dateadd('YEAR',@number,@startdate))-1
		END	
	END
	--------------------------------------------------
	ELSE
		BEGIN
		SET @endDate=(dateadd(YEAR,@number,@startdate))-1
	
		--IF @Date < @startDate RETURN @Date --invalid date, before hire date, return 0 and EXIT
		--IF @Date > @termdate RETURN @Date --invalid date, after termination date, return 0 and EXIT		
			WHILE (@Date NOT BETWEEN @startDate AND @endDate) --looping till we find the right interval
			BEGIN
				SET @startDate=dateadd(DAY,1,@endDate)
				SET @endDate=(dateadd(YEAR,@number,@startdate))-1
			END	 	
		END
	
		
	--IF @StartOrEnd=0, return startdate and EXIT
	IF @StartOrEnd=0 RETURN @startDate 
	--else if @StartOrEnd=1, return enddate and EXIT
	RETURN @endDate
	
END

GO

