create   FUNCTION Z_GetDaysAndMonths (@LoopIndicator int = 0 , @Number int = 0)
Returns @Temp table (DayOrMonth nvarchar(10) )
as 
begin 

--@LoopIndicator : number of etrations 
--@Number : Number of days or months per schedule 

Declare @OldValue int  , @i int  



set @oldvalue = @Number
set @i = @LoopIndicator --days


WHILE ( @i >= 1)
BEGIN
	select @oldvalue = @Number
    select @Number  = @Number  - @i
	if(@Number  > 0) begin insert into @temp values(@i)  set @i = @i / 2  end 
	else if(@Number  = 0 ) begin insert into @temp values(@i) break; end
	else if (@Number < 0 ) begin set @i = @i / 2  set @Number = @oldvalue end

END


return

end

GO

