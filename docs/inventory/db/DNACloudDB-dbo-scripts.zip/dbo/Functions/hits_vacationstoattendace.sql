CREATE FUNCTION [dbo].[hits_vacationstoattendace]
	(@payrollgroup  int, 
	 @ssgroup int,
             @fromdate smalldatetime,
	 @todate smalldatetime)
RETURNS @vacattend TABLE 
	(EmpId int, AttendDate smalldatetime,vaccode int,  attLINENO int , legend nchar(1) , ColorNo int,vactype  int)

AS
BEGIN
	RETURN 
END

GO

