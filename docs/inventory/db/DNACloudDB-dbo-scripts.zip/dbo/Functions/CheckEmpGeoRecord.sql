
Create FUNCTION [dbo].[CheckEmpGeoRecord]  (@empid int, @GeoLocation smallint, @NewStartDate AS SMALLDATETIME,@NewEndDate AS SMALLDATETIME,@EmpGeoLocationGUID uniqueidentifier,@Lang char(1)='E')
RETURNS nvarchar(4000) AS  
begin

DECLARE @TodayDate AS DATE,@msg as nvarchar(4000)=''
SET @TodayDate =CAST(GETDATE() AS DATE)

If Exists(SELECT eg.empid
FROM empgeolocation eg
where	eg.empid=@empid and eg.GeoLocation=@GeoLocation  and eg.StartDate=@NewStartDate
and ( (eg.EmpGeoLocationGUID <> @EmpGeoLocationGUID and @EmpGeoLocationGUID is not null ) or @EmpGeoLocationGUID is  null) )
	BEGIN 
			SELECT @msg =  ISNULL(dbo.Hits_GetDCCaption('COMMON','ErrMsgDuplicateRecord',@Lang),   CASE WHEN @Lang='E' THEN N'Cannot insert duplicate record ' ELSE N' لا يمكن أدخال سجل مكرر   ' END)
	END 
	ELSE 
	BEGIN 
				If Exists(SELECT eg.empid
							 FROM empgeolocation eg
						 --INNER JOIN inserted i ON i.empid =eg.empid AND i.GeoLocation =eg.GeoLocation AND i.EmpGeoLocationGUID <>eg.EmpGeoLocationGUID 
					where
					eg.empid=@empid and eg.GeoLocation=@GeoLocation  and ( (eg.EmpGeoLocationGUID <> @EmpGeoLocationGUID and @EmpGeoLocationGUID is not null ) or @EmpGeoLocationGUID is  null) and -- =case when isnull(@EmpGeoLocationGUID,'') ='' then eg.EmpGeoLocationGUID  else @EmpGeoLocationGUID end and
					-- the below condition for records in the future but ended with getdate-1 ex startsate='2024/05/01' enddate='2024/02/01' so we will not consider this records
					 isnull(eg.EndDate,eg.StartDate)>=eg.StartDate and
					 isnull(@NewEndDate,@NewStartDate)>=@NewStartDate and
							(
							--prevent entering current record with existence of current record in the database
								(
									  @TodayDate BETWEEN @NewStartDate and ISNULL(@NewEndDate ,@TodayDate)
									  AND @TodayDate  BETWEEN eg.StartDate AND ISNULL(eg.EndDate,@TodayDate)
								)
							-- ex 	@startdate1='2024/02/01' and @enddate1 is Null and in the database there is a record with eg.StartDate='2024/03/01' and eg.EndDate='2024/03/31' so the system will prevent entering this record as it will be intersected in the future	
							OR (@NewEndDate IS NULL AND @NewStartDate <=isnull(eg.EndDate,eg.StartDate))
							-- ex  in the database there is a record with eg.StartDate='2024/02/01' and eg.EndDate is Null and @startdate1 ='2024/03/01' and @enddate1='2024/03/31' so the system will prevent entering this record as it will be intersected in the future
							OR (eg.EndDate IS NULL AND isnull(@NewEndDate,@NewStartDate) >= eg.StartDate)	
							--prevent entering any record that intersected with another record in the database
							or (
								@NewStartDate BETWEEN eg.StartDate AND eg.EndDate
								OR  @NewEndDate BETWEEN eg.StartDate AND eg.EndDate
								OR eg.StartDate BETWEEN @NewStartDate AND @NewEndDate
								OR eg.EndDate BETWEEN @NewStartDate AND @NewEndDate
								)
				
							))	

					begin
						SELECT @msg = ISNULL(dbo.Hits_GetDCCaption('ErrorEmpGeoLocation','IntersectedRecord',@Lang),  CASE WHEN @Lang='E' THEN 'There is an intersected record with this Geolocation' ELSE N'يوجد بيان متقاطع مع هذا الموقع الجغرافي' END )
					end
					else
					begin
						select @msg=''
					end
	END 


RETURN @msg
end

GO

