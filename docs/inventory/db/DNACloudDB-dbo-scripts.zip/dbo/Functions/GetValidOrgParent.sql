CREATE FUNCTION [dbo].[GetValidOrgParent]  (@org smallint,  @date AS smalldatetime,@RoleID AS NVARCHAR(MAX),@logonName as nvarchar(80)=N'',@UserOrganization as nvarchar(max)=N'',  @Type as smallint=0)
RETURNS  smallint
AS
BEGIN 
 --@Type = 0 Agenda or WF need to applied Role and date validation
 --@Type = 1 Setup
DECLARE @orgParent AS int,@valid AS int, @RoleFields AS nvarchar(max)
DECLARE @Roles TABLE (RoleId smallint)

SET @valid =0
SELECT @RoleID=ISNULL(@RoleID,'')

--declare @UserOrganization as nvarchar(max)=N''
--select @UserOrganization=UserOrganization
--       From NasUsers
--       where ltrim(rtrim(LogonName))=ltrim(rtrim(@logonName))

WHILE @valid =0
BEGIN

	SELECT @orgParent= OrganizationParent 
	FROM Organization 
	LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization
	WHERE Organization.Organization=@org

	IF @orgParent IS NULL SET @valid =1
	ELSE
	BEGIN
	if @UserOrganization<>''
	begin
		SELECT @valid=CASE WHEN 
		(CASE WHEN sysparam.EnableDateValidation=1  then 
		(CASE WHEN convert(nchar(10),@date,111)  between (isnull([OrganizationFromDate],  convert(nchar(10),@date,111)) ) 
		and (isnull([OrganizationToDate] , convert(nchar(10),@date,111))) THEN 1 ELSE 0 END) ELSE 1 END)=1
		and 
		(CASE WHEN sysparam.enablerolevalidation =1 and @Type=0 AND @RoleID <> N''  
		THEN ((dbo.RolesExist(@RoleID,N'$'+ISNULL(organization.OrganizationRoles,N'')+N'$',0,0))) ELSE 1 END)=1

		THEN 1 
		
		ELSE 0 END 

 		FROM organization
		inner join NasUsersOrgs on NasUsersOrgs.LogonName=@logonName and NasUsersOrgs.Organization=organization.organization and NasUsersOrgs.Organization=@orgParent
		CROSS JOIN SysParam 
		WHERE organization.Organization=@orgParent
	end

	else
	begin
		SELECT @valid=CASE WHEN 
		(CASE WHEN sysparam.EnableDateValidation=1  then 
		(CASE WHEN convert(nchar(10),@date,111)  between (isnull([OrganizationFromDate],  convert(nchar(10),@date,111)) ) 
		and (isnull([OrganizationToDate] , convert(nchar(10),@date,111))) THEN 1 ELSE 0 END) ELSE 1 END)=1
		and 
		(CASE WHEN sysparam.enablerolevalidation =1 and @Type=0 AND @RoleID <> N''  
		THEN ((dbo.RolesExist(@RoleID,N'$'+ISNULL(organization.OrganizationRoles,N'')+N'$',0,0))) ELSE 1 END)=1

		THEN 1 ELSE 0 END 

 		FROM organization

		CROSS JOIN SysParam 
		WHERE organization.Organization=@orgParent
	end
	END

	SET @org=@orgParent
END

RETURN @orgParent

END

GO

