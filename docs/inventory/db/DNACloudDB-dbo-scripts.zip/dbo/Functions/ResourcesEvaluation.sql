CREATE FUNCTION [dbo].[ResourcesEvaluation] (@Resource int, @Category int ,@From Smalldatetime, @To Smalldatetime, @EventNo int)  
RETURNS numeric(18,3)  AS  

BEGIN
	
	DECLARE @Count int 
	DECLARE @Result numeric (18,3)
	
	SET @Result=0
IF @Category=1

BEGIN
	SELECT  @Count =  count (DISTINCT (str(EmpTrainingEvalTrainers.EmpId)+str(EmpTrainingEvalTrainers.DocumentNo)+
	str(EmpTrainingEvalTrainers.TrainingEval)))
	FROM EmpTrainingEvalTrainers 
	LEFT JOIN EmpTrainingEval ON EmpTrainingEval.EmpId = EmpTrainingEvalTrainers.EmpId
	AND EmpTrainingEval.DocumentNo = EmpTrainingEvalTrainers.DocumentNo AND EmpTrainingEval.TrainingEval = EmpTrainingEvalTrainers.TrainingEval
	LEFT JOIN EmpTraining  ON EmpTraining.EmpId=EmpTrainingEval.EmpId AND EmpTraining.DocumentNo=EmpTrainingEval.DocumentNo
	WHERE EmpTrainingEvalTrainers.TrainingResource=@Resource AND EmpTrainingEvalTrainers.ResourceCategory=@Category
	AND  EmpTrainingEval.TrainingEvalDate BETWEEN isnull(@From,EmpTrainingEval.TrainingEvalDate) AND isnull(@To,EmpTrainingEval.TrainingEvalDate)
	AND EmpTraining.TrainingEvent=  CASE WHEN @EventNo IS NULL THEN EmpTraining.TrainingEvent ELSE @EventNo END 

IF @Count <> 0
	BEGIN 
		
	SELECT  @Result =  sum([dbo].[EmpTrainersEvaluation](EmpTrainingEval.EmpId ,EmpTrainingEval.DocumentNo ,EmpTrainingEval.TrainingEval 
	, @Resource ,@Category,NULL))/@Count
	FROM EmpTrainingEval
	LEFT JOIN EmpTraining  ON EmpTraining.EmpId=EmpTrainingEval.EmpId AND EmpTraining.DocumentNo=EmpTrainingEval.DocumentNo
	WHERE ( EmpTrainingEval.TrainingEvalDate) BETWEEN isnull(@From,EmpTrainingEval.TrainingEvalDate) AND isnull(@To,EmpTrainingEval.TrainingEvalDate)
	AND EmpTraining.TrainingEvent=  CASE WHEN @EventNo IS NULL THEN EmpTraining.TrainingEvent ELSE @EventNo END 
	END
	
END
ELSE
BEGIN
	SELECT  @Count =  count (DISTINCT (str(EmpTrainingEvalResources.EmpId)+str(EmpTrainingEvalResources.DocumentNo)+
	str(EmpTrainingEvalResources.TrainingEval)))
	FROM EmpTrainingEvalResources
	LEFT JOIN EmpTrainingEval ON EmpTrainingEval.EmpId = EmpTrainingEvalResources.EmpId
	AND EmpTrainingEval.DocumentNo = EmpTrainingEvalResources.DocumentNo AND EmpTrainingEval.TrainingEval = EmpTrainingEvalResources.TrainingEval
	LEFT JOIN EmpTraining  ON EmpTraining.EmpId=EmpTrainingEval.EmpId AND EmpTraining.DocumentNo=EmpTrainingEval.DocumentNo
	WHERE EmpTrainingEvalResources.TrainingResource=@Resource AND EmpTrainingEvalResources.ResourceCategory=@Category
	AND  EmpTrainingEval.TrainingEvalDate BETWEEN isnull(@From,EmpTrainingEval.TrainingEvalDate) AND isnull(@To,EmpTrainingEval.TrainingEvalDate)
	AND EmpTraining.TrainingEvent=  CASE WHEN @EventNo IS NULL THEN EmpTraining.TrainingEvent ELSE @EventNo END 
	IF @Count <> 0
	BEGIN 
		
	SELECT @Result= sum ([dbo].[EmpResourcesEvaluation] (EmpTrainingEval.EmpId ,EmpTrainingEval.DocumentNo ,EmpTrainingEval.TrainingEval 
	, @Resource ,@Category))/@Count
	FROM EmpTrainingEval
	LEFT JOIN EmpTraining  ON EmpTraining.EmpId=EmpTrainingEval.EmpId AND EmpTraining.DocumentNo=EmpTrainingEval.DocumentNo
	WHERE ( EmpTrainingEval.TrainingEvalDate) BETWEEN isnull(@From,EmpTrainingEval.TrainingEvalDate) AND isnull(@To,EmpTrainingEval.TrainingEvalDate)
	AND EmpTraining.TrainingEvent=  CASE WHEN @EventNo IS NULL THEN EmpTraining.TrainingEvent ELSE @EventNo END 
	END
	END
	RETURN @Result
END

GO

