

CREATE FUNCTION [dbo].[getObjEvaluation] (@EmpId AS INT, @ObJectiveId AS INT,@objactual AS NUMERIC(18,3),@objthreshold AS NUMERIC(18,3),@objtarget AS NUMERIC(18,3),@objmax AS NUMERIC(18,3) ,@calcMethod AS SMALLINT=1)
 RETURNS NUMERIC(18,3)  	
AS 
BEGIN
DECLARE @ParentMaxCompletion AS INT = 0 
	IF @objthreshold =0 AND @objmax =0
	BEGIN
		
		-- this comment is a customization in DNAGenericDemo_sales
		--DECLARE @weight AS NUMERIC (18,3)
		--SELECT @weight = ObjectiveWeight FROM EmpObjectives WHERE empid =@EmpId AND objectiveid =@ObJectiveId
		--RETURN (@objactual * @weight/@objtarget)
		
		 RETURN (@objactual / @objtarget)*100
	END
	
	DECLARE @objcompletion AS NUMERIC(18,3)  =0
IF @calcMethod=2
  BEGIN
  	
  	DECLARE @custom AS NVARCHAR(20)=''
  	SELECT @custom =configvalue FROM sysparamconfig WHERE ConfigID='ObjectiveCalculation'
  	IF @custom =1
  		BEGIN
  		 RETURN CASE WHEN @objactual<@objthreshold THEN 0
  		             WHEN @objactual>@objmax THEN (@objmax/@objtarget)*100 
  		             else  (@objactual/@objtarget)*100 END 
  		END
  	
  	ELSE
  		BEGIN 
			 If @objthreshold < @objmax 
			  BEGIN
				  If @objactual <= @objthreshold   
				  set @objcompletion = 0
				  else If (@objactual > @objthreshold) And (@objactual <= @objtarget) And (@objtarget - @objthreshold) <> 0 
				  set @objcompletion = ((@objactual - @objthreshold) / (@objtarget - @objthreshold)) * 50
				  else If (@objactual > @objtarget) And (@objactual <= @objmax) And (@objmax - @objtarget) <> 0 
				  set @objcompletion = (((@objactual - @objtarget) / (@objmax - @objtarget)) * 50) + 50
				  else If @objactual > @objmax Or @objcompletion > 100 
				  set @objcompletion = 100
			   END
			  ELSE
			   BEGIN
				  If (@objactual >= @objthreshold) 
				  set @objcompletion = 0
				  else If (@objactual < @objthreshold) And (@objactual >= @objtarget) And (@objthreshold - @objtarget) <> 0 
				  set @objcompletion = ((@objthreshold - @objactual) / (@objthreshold - @objtarget)) * 50
				  else If (@objactual < @objtarget) And (@objactual >= @objmax) And (@objmax - @objtarget) <> 0 
				  set @objcompletion = (((@objtarget - @objactual) / (@objtarget - @objmax)) * 50) + 50
				  If (@objcompletion > 100) Or (@objactual < @objmax) 
				  set @objcompletion = 100
			   END
       
       END 
END 

ELSE
BEGIN

		declare @tempactual as numeric(18,3), @temptarget as numeric(18,3)

		SELECT @Calcmethod=CalcMethod 
         ,@ParentMaxCompletion = MaxCompletion
		FROM dbo.Objectives 
		WHERE ObjectiveId IN ( SELECT ObjectiveParentId FROM dbo.Objectives WHERE ObjectiveId = @ObJectiveId )  AND ObjectiveParentId is null 

		--if @objthreshold = -1
		--begin
		--	select @tempactual = @objtarget, @temptarget = @objactual
		--	select @objtarget = @temptarget, @objactual = @tempactual
		--END
        
		IF @calcMethod=1 --Timewise
		BEGIN
			SET @tempActual=@objtarget
			SET @tempTarget=@objactual
			SET @objactual=@tempActual
			SET @objtarget=@tempTarget
		END
		

	    IF @objtarget=0
	    SET @objcompletion =0
		else IF @objactual < @objtarget
		SET @objcompletion =(@objactual/@objtarget) *100
		else IF @objactual >=@objtarget AND (@objactual <@objmax) AND (@objmax<>0)
		SET @objcompletion=100 + (((@objactual-@objtarget)/(@objmax-@objtarget))*100)
 else IF @objactual >=@objtarget AND (@objmax=0) 
              
              SET @objcompletion=100 + (((@objactual-@objtarget)/(@objtarget))*100)
		ELSE IF @objactual >=@objmax 
		SET @objcompletion=@objmax
	END

        Return CASE WHEN @objcompletion > @ParentMaxCompletion AND @ParentMaxCompletion > 0 THEN @ParentMaxCompletion ELSE  @objcompletion END    	   	
END

GO

