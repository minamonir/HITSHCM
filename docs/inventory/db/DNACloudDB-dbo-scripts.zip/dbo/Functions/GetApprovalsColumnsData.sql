
CREATE FUNCTION [dbo].[GetApprovalsColumnsData] (
	-- Add the parameters for the function here
	 @ConfigId NVARCHAR(MAX),@lang CHAR(1),@option AS INT
)
RETURNS NVARCHAR(max)
BEGIN 
DECLARE @ConfigValue AS nvarchar(max)=''
SELECT @ConfigValue= ConfigValue FROM dbo.SysParamConfig WHERE ConfigID= @ConfigId 

declare @Col1 AS SMALLINT  , @col2 AS smallint 
SELECT @Col1=CHARINDEX('1',@ConfigValue), @Col2=CHARINDEX('1',@ConfigValue,@Col1+1)

	DECLARE @Column AS NVARCHAR(MAX)=''
-- Option =0 to retrieve the two columns in the final select Statement in Procedures hits_getwfApprovalswithPaging
	IF @option=0
	BEGIN 
	SELECT @column= CASE WHEN @Col1=1 THEN ' jobs.JobName  as OrganizationName ,jobs.JobAName as OrganizationAName ,'
	                     WHEN @Col1=2 THEN ' Organization.OrganizationName as OrganizationName , Organization.OrganizationAName as OrganizationAName ,'
						 WHEN @Col1=3 THEN ' Grades.GradeName  as OrganizationName ,Grades.GradeAName as OrganizationAName , '
					     WHEN @Col1=4 THEN ' Positions.PositionName  as OrganizationName , Positions.PositionAName  as OrganizationAName, '
						 WHEN @Col1=5 THEN ' Location.LocationName as OrganizationName ,Location.LocationAName as OrganizationAName ,'
						 ELSE  'Organization.OrganizationName,Organization.OrganizationAName,'END
                       
   SELECT @column =@column + CASE WHEN @Col2=2 THEN ' Organization.OrganizationName as JobName , Organization.OrganizationAName as JobAName ,'
						 WHEN @Col2=3 THEN ' Grades.GradeName  as JobName ,Grades.GradeAName as JobAName , '
					     WHEN @Col2=4 THEN ' Positions.PositionName  as JobName , Positions.PositionAName  as JobAName , '
						 WHEN @Col2=5 THEN ' Location.LocationName as JobName ,Location.LocationAName as JobAName ,'
						 ELSE  'case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName, ' END
	END 
	ELSE
    BEGIN
    	-- Option =1 to retrieve the sort of first column instead of p_SortStr in Procedures hits_getwfApprovalswithPaging
	IF @option=1
	
     	SELECT @column= CASE WHEN @Col1=1 THEN CASE WHEN @lang='e' THEN 'JobName' ELSE 'JobAName' END 
							 WHEN @Col1=2 THEN CASE WHEN @lang='e' THEN 'OrganizationName' ELSE 'OrganizationAName' END 
							 WHEN @Col1=3 THEN CASE WHEN @lang='e' THEN 'GradeName' ELSE 'GradeAName' END 
							 WHEN @Col1=4 THEN CASE WHEN @lang='e' THEN 'PositionName' ELSE 'PositionAName' END 
							 WHEN @Col1=5 THEN CASE WHEN @lang='e' THEN 'LocationName' ELSE 'LocationAName' END 
						 ELSE  ' ' END
		-- Option =2 to retrieve the sort of second column instead of p_SortStr in Procedures hits_getwfApprovalswithPaging 
    ELSE IF @option=2 
	    SET @Column=CASE WHEN @Col2=2  THEN CASE WHEN @lang='e' THEN 'OrganizationName' ELSE 'OrganizationAName' END 
						 WHEN @Col2=3 THEN CASE WHEN @lang='e' THEN 'GradeName' ELSE 'GradeAName' END 
						 WHEN @Col2=4 THEN CASE WHEN @lang='e' THEN 'PositionName' ELSE 'PositionAName' END 
						 WHEN @Col2=5 THEN CASE WHEN @lang='e' THEN 'LocationName' ELSE 'LocationAName' END 
					ELSE  ' ' END
-- Option =3 to retrieve the the TableName,FieldName and Text of first column	
    ELSE IF @Option=3    
		SET @Column=CASE WHEN @Col1=1 THEN CASE WHEN @lang='e' THEN N'Jobs$JobName$Job' ELSE N'Jobs$JobAName$الوظيفة'  END   
						 WHEN @Col1=2 THEN CASE WHEN @lang='e' THEN N'Organization$OrganizationName$Organization' ELSE N'Organization$OrganizationAName$المنظمة' END  
						 WHEN @Col1=3 THEN CASE WHEN @lang='e' THEN N'Grades$GradeName$Grade' ELSE N'Grades$GradeAName$الدرجة' END  
						 WHEN @Col1=4 THEN CASE WHEN @lang='e' THEN N'Positions$PositionName$Position' ELSE N'Positions$PositionAName$المركز' END  
						 WHEN @Col1=5 THEN CASE WHEN @lang='e' THEN N'Location$LocationName$Location' ELSE N'Location$LocationAName$الموقع' END  
							 ELSE  ' ' END
			-- Option =4 to retrieve the the TableName,FieldName and Text of second column					 
	ELSE IF @Option=4   
		SET @Column=CASE WHEN @Col2=2 THEN CASE WHEN @lang='e' THEN N'Organization$OrganizationName$Organization' ELSE N'Organization$OrganizationAName$المنظمة' END  
						 WHEN @Col2=3 THEN CASE WHEN @lang='e' THEN N'Grades$GradeName$Grade' ELSE N'Grades$GradeAName$الدرجة' END  
						 WHEN @Col2=4 THEN CASE WHEN @lang='e' THEN N'Positions$PositionName$Position' ELSE N'Positions$PositionAName$المركز' END  
						 WHEN @Col2=5 THEN CASE WHEN @lang='e' THEN N'Location$LocationName$Location' ELSE N'Location$LocationAName$الموقع' END  
							 ELSE  ' ' END
	END 

RETURN @Column

END

GO

