CREATE FUNCTION [dbo].[WF_CheckRoleInvitationOLD]
    (@LogonName as nvarchar(80)='' ,@RoleProfileid as int, @EmpID as int, @DocumentNo as int , @SSDocNo as SMALLINT)
RETURNS SMALLINT

AS
BEGIN
	DECLARE @result AS SMALLINT=0

	-- @result = 0		==> Invitation Closed & Can save
	-- @result = 1		==> Invitation Opened & Cannot save
	-- @result = 2		==> Invitation Opened & Can save


	DECLARE @roleOrder INT ,@InvitationRequired AS SMALLINT,@RoleIdTemp AS SMALLINT
	DECLARE @WFDocApprovalTemp table(WFRoleOrder INT, DocumentNo  int,Empid int, SSDocNo smallint ,RoleId smallint ,RoleOrder smallint, InvitedRoleid SMALLINT,InvitationRequired SMALLINT,canInsert BIT)
	    
	-----------------------------
	DECLARE  @WFDocApproval TABLE(
		[WFDocID] [INT] IDENTITY NOT NULL,
		[DocumentNo] [INT] NOT NULL,
		[EmpID] [INT] NOT NULL,
		[SSDocNo] [SMALLINT] NOT NULL,
		[RoleId] [SMALLINT] NOT NULL,
		[ApprovalStatus] [SMALLINT] NULL,     
		[ApprovalProfileId] [INT] NULL,      
		[RoleOrder] [SMALLINT] NOT NULL,
		[ApprovalRequired] [BIT] NOT NULL,
		[Delegated] [SMALLINT] NOT NULL
    )
	INSERT INTO @WFDocApproval
	SELECT  DocumentNo,EmpID,SSDocNo,RoleId,ApprovalStatus,ApprovalProfileId,RoleOrder,ApprovalRequired,Delegated FROM dbo.WFDocApproval
	WHERE empid=@EmpID AND DocumentNo=@DocumentNo AND SSDocNo=@SSDocNo
	ORDER BY RoleOrder,Delegated

	SELECT TOP 1 @InvitationRequired=InvitationRequired,@RoleIdTemp=ISNULL(SSDocumentInvitation.RoleId ,0)
	FROM @WFDocApproval wda        
	left join SSDocumentInvitation on wda.RoleId = SSDocumentInvitation.RoleId and wda.SSDocNo = SSDocumentInvitation.SSDocNo      
	AND RequestedBy <> 0                                                                        
	left join SSrole   on  SSrole.RoleId = wda.RoleId
	left join SSrole  SSInvitedRole  on  SSInvitedRole.RoleId = SSDocumentInvitation.InvitedRoleid
	where 
	wda.EmpID = @EmpID
	and  wda.SSDocNo = @SSDocNo
	and wda.DocumentNo = @DocumentNo
	and wda.ApprovalProfileId=  @RoleProfileid
	 and wda.ApprovalStatus IS NULL 
	order by wda.WFDocID asc 
	-----------------------------

	IF @InvitationRequired<>0 AND ISNULL(@RoleIdTemp,0)<>0
	BEGIN
		SELECT @result = 1
		
		insert into  @WFDocApprovalTemp (WFRoleOrder,DocumentNo ,Empid , SSDocNo  ,RoleId  ,RoleOrder,InvitedRoleid  , InvitationRequired, canInsert)
		SELECT top 1 wda.WFDocID,ISNULL(wda.DocumentNo ,0) AS DocumentNo, ISNULL(wda.Empid,0) AS Empid , wda.SSDocNo  ,wda.RoleId  ,wda.RoleOrder,SSDocumentInvitation.InvitedRoleid , InvitationRequired, 0
		FROM @WFDocApproval wda         
		inner join SSDocumentInvitation on wda.RoleId = SSDocumentInvitation.RoleId and wda.SSDocNo = SSDocumentInvitation.SSDocNo      
		AND RequestedBy <> 0     


		LEFT JOIN dbo.WFDocInvitation ON  WFDocInvitation.SSDocNo = SSDocumentInvitation.SSDocNo  
		 AND  ISNULL(WFDocInvitation.InvitedRoleid,0) = ISNULL(SSDocumentInvitation.InvitedRoleid,0)   
		 AND ISNULL(WFDocInvitation.RoleId,0) =ISNULL(SSDocumentInvitation.RoleId,0)                 
		 AND  ISNULL(WFDocInvitation.EmpID,0) = ISNULL(@EmpID,0)                                                                   
		 AND  ISNULL(WFDocInvitation.DocumentNo,0) = ISNULL(@DocumentNo,0)                                                                   
		 LEFT JOIN dbo.Profile ON Profile.ProfileId = WFDocInvitation.InvitedRoleProfileid
		where 
		wda.EmpID = @EmpID
		and  wda.SSDocNo = @SSDocNo
		and wda.DocumentNo = @DocumentNo
		and wda.ApprovalProfileId=  @RoleProfileid
		--and @WFDocApproval.ApprovalDate is null 
		 and wda.ApprovalStatus IS NULL 
		 --AND SSDocumentInvitation.InvitationRequired <>  0
		--AND ISNULL(SSDocumentInvitation.RoleId ,0)  <>  0 
		--AND RequestedBy <> 0
		order by wda.WFDocID asc 
	END
	ELSE	
	BEGIN
	    SELECT @result = 0
		RETURN @result
	END

		--select '1', * from @WFDocApprovalTemp
		-------------------------------------------------

		select @roleOrder= WFRoleOrder from @WFDocApprovalTemp

		while exists (select *  
		from @WFDocApproval wda      
		left join SSDocumentInvitation on wda.RoleId = SSDocumentInvitation.RoleId and wda.SSDocNo = SSDocumentInvitation.SSDocNo     
		WHERE 
		wda.EmpID = @EmpID
		and  wda.SSDocNo = @SSDocNo
		and wda.DocumentNo = @DocumentNo 
		 and ApprovalStatus IS NULL  
		 AND((wda.ApprovalProfileId=  @RoleProfileid OR Delegated>1 OR wda.ApprovalRequired=0 ) AND wda.WFDocID = @roleOrder+1))
		BEGIN

			insert into  @WFDocApprovalTemp (WFRoleOrder ,DocumentNo ,Empid , SSDocNo  ,RoleId  ,RoleOrder,InvitedRoleid, InvitationRequired, canInsert)
			SELECT wda.WFDocID, ISNULL(wda.DocumentNo,0) AS DocumentNo ,ISNULL(wda.Empid,0) AS Empid , wda.SSDocNo ,wda.RoleId ,wda.RoleOrder,SSDocumentInvitation.InvitedRoleid , InvitationRequired, 0
			from @WFDocApproval  wda     
			inner join SSDocumentInvitation on wda.RoleId = SSDocumentInvitation.RoleId and wda.SSDocNo = SSDocumentInvitation.SSDocNo     

			LEFT JOIN dbo.WFDocInvitation ON  WFDocInvitation.SSDocNo = SSDocumentInvitation.SSDocNo  
			AND  ISNULL(WFDocInvitation.InvitedRoleid,0) = ISNULL(SSDocumentInvitation.InvitedRoleid,0)   
			AND ISNULL(WFDocInvitation.RoleId,0) =ISNULL(SSDocumentInvitation.RoleId,0)                 
			AND  ISNULL(WFDocInvitation.EmpID,0) = ISNULL(@EmpID,0)                                                                   
			AND  ISNULL(WFDocInvitation.DocumentNo,0) = ISNULL(@DocumentNo,0)                                                                   
			LEFT JOIN dbo.Profile ON Profile.ProfileId = WFDocInvitation.InvitedRoleProfileid                                         
			where 
			wda.EmpID = @EmpID
			and  wda.SSDocNo = @SSDocNo
			and wda.DocumentNo = @DocumentNo
			and wda.ApprovalProfileId=  @RoleProfileid
			--and @WFDocApproval.ApprovalDate is null 
			and isnull(wda.ApprovalStatus,0) = 0 
			and wda.WFDocID =@roleOrder+1
			AND SSDocumentInvitation.InvitationRequired <>0 -----------------
			AND ISNULL(SSDocumentInvitation.RoleId ,0)  <>  0 
			AND SSDocumentInvitation.RequestedBy =2  ------------------
			AND  Delegated IN (0,1)


			select @roleOrder=@roleOrder+1  

		END  
		
	UPDATE @WFDocApprovalTemp SET canInsert = 1
	FROM @WFDocApprovalTemp twf
	INNER JOIN WFDocApproval ON WFDocApproval.DocumentNo = twf.DocumentNo
	AND WFDocApproval.EmpID = twf.Empid 
	AND WFDocApproval.SSDocNo = twf.SSDocNo
	AND WFDocApproval.ApprovalProfileId <> @RoleProfileid
	AND WFDocApproval.RoleId <> twf.RoleId
	AND WFDocApproval.Delegated = 3 
	AND WFDocApproval.RoleOrder = twf.RoleOrder+1

	IF NOT EXISTS(
	select * from @WFDocApprovalTemp
	WHERE canInsert = 0)

	SELECT @result = 2	

	RETURN @result
END

GO

