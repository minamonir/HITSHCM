
create FUNCTION [dbo].[v_periodstart]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS
BEGIN
  declare @thedate smalldatetime
 -- if @year=0  select @year=cyear, @period=cmonth from payrollgroup where payrollgroup=@payrollgroup	
   
if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
  


  declare @vsday SMALLINT
  declare @VSMonth as SMALLINT
  declare @noofperiods as SMALLINT
  
        select @vsday=vsday ,@VSMonth=VsMonth,@noofperiods=noofperiods from payrollgroup where payrollgroup = @payrollgroup
     -- advance the period by 1 to get next period start   



  if @period=1 
    begin
		 if (@vsday=0 or @VSMonth=0)
		 begin
			 select @period=@noofperiods
		 end
		 else
		 begin
			 select @period=12
		  end
  
      set @year=@year-1
 
   end
 
 else set @period=@period-1
 

 select @thedate=dbo.V_periodend(@payrollgroup,@period,@year)
set @thedate=dateadd(dd,1,@thedate)
 
	

RETURN @thedate
END

GO

