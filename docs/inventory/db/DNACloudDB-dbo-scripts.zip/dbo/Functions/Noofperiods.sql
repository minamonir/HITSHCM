
CREATE FUNCTION [dbo].[Noofperiods](@empid as INT)
RETURNS NUMERIC(18,3)
AS
--DECLARE @empid as INT=216150 ,@Type AS SMALLINT=0
BEGIN

DECLARE @noofperiods AS SMALLINT 
DECLARE @customAnnual AS SMALLINT =0

SELECT @customAnnual=0
FROM sysparam
	--SELECT @customAnnual

declare @empperiods AS smallint=0

	select @noofperiods=CASE WHEN payrollgroup.noofperiods =0 THEN 12 ELSE noofperiods end
	FROM empassignment 
	LEFT JOIN payrollgroup ON payrollgroup.PayrollGroup = empassignment.PayrollGroup
	WHERE empid=@empid


	IF @customAnnual=0
	SELECT @empperiods=@noofperiods
	ELSE 
	SELECT @empperiods=CASE WHEN empassignment.HrScStatus=2 THEN  12 
		                         WHEN empassignment.HrScStatus=3 THEN  13 
		                         WHEN empassignment.HrScStatus=4 THEN  14
		                     ELSE 12 END 
    FROM empassignment 
	WHERE empid=@empid

return ISNULL(@empperiods,12)
END

GO

