
-- get the total taken days  for some vacations between @fromdate and @todate for this employee (@empid)
--@vaccodes paramater contains the vacation codes seperated by comma, if empty the fn will return the total vac taken days for all vacations

CREATE     FUNCTION [dbo].[VacationsTotalTaken]
(@empid int,@fromdate datetime,@todate datetime,@vaccodes as nvarchar(MAX))
RETURNS numeric(18,3)
AS
BEGIN
declare @days numeric(18,3),@vaccode AS int,@commaIndex AS int,@DecimalScale as smallint
SET @commaIndex=0
SET @days=0
select @DecimalScale=DecimalScale from sysparam
IF @vaccodes =N''
BEGIN
	SELECT @days=[dbo].[VacTotalTaken](@empid ,@fromdate ,@todate ,0)
END
ELSE
BEGIN 
	SET @vaccodes = @vaccodes+','
		WHILE charindex(',',@vaccodes,0)>0
		BEGIN 
			SET @commaIndex= charindex(',',@vaccodes,0)
			SET @vaccode=substring(@vaccodes,1,@commaIndex-1)
			SET @vaccodes=substring(@vaccodes,@commaIndex+1,len(@vaccodes)-@commaIndex)
			SELECT @days=@days+[dbo].[VacTotalTaken](@empid ,@fromdate ,@todate ,@vaccode)
		
		end
end

set @days=round(isnull(@days,0),@DecimalScale)
RETURN @days 
END

GO

