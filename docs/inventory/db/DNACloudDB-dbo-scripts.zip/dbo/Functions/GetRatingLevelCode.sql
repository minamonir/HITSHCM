CREATE FUNCTION [dbo].[GetRatingLevelCode](@RatingScale AS INT, @LevelPercent AS NUMERIC(18, 3))
RETURNS SMALLINT
AS
BEGIN
	DECLARE
	@lowlevel		 AS NUMERIC(18, 3)
   ,@Highlevel		 AS NUMERIC(18, 3)
   ,@lowpercent		 AS NUMERIC(18, 3)
   ,@Highpercent	 AS NUMERIC(18, 3)
   ,@RatingLevel	 AS NUMERIC(18, 3)
	IF @RatingScale IS NULL OR	@LevelPercent <= 0 SET @RatingLevel = 0
	ELSE
	BEGIN
		SELECT TOP 1 @lowlevel	= RatingLevel ,@lowpercent = LevelPercent FROM	RatingLevels WHERE	RatingScale = @RatingScale ORDER BY LevelPercent
		SELECT TOP 1 @Highlevel	 = RatingLevel ,@Highpercent = LevelPercent FROM	RatingLevels WHERE	RatingScale = @RatingScale ORDER BY LevelPercent DESC
		SELECT TOP 1	@RatingLevel = RatingLevel FROM	RatingLevels WHERE	RatingScale = @RatingScale AND	LevelPercent <= @LevelPercent ORDER BY LevelPercent DESC
		IF @LevelPercent < @lowpercent  SET @RatingLevel = @lowlevel
		IF @LevelPercent > @Highpercent SET @RatingLevel = @Highlevel
	END
	RETURN ISNULL(@RatingLevel, 0)
END

GO

