CREATE FUNCTION [dbo].[getfullname]
  (@firstname nvarchar(20),@secondname nvarchar(25),@thirdname nvarchar(20),@lastname nvarchar(20))  
 returns nvarchar(88)
as
BEGIN 
 declare @fullname nvarchar(88)   
declare @fullnameorder  int
select @fullnameorder=fullnameorder from sysparam

  set @fullname=rtrim(@firstname)
  if N''<>rtrim(@secondname)SET @fullname=@fullname +N' ' + rtrim(@secondname)
  if N''<>rtrim(@thirdname) SET @fullname=@fullname +N' ' + rtrim(@thirdname)
  if N''<>rtrim(@lastname)  SET @fullname=@fullname +N' ' + rtrim(@lastname)

  if @fullnameorder=2 and N''<>rtrim(@thirdname) set @fullname=rtrim(@thirdname)+N' '+rtrim(@firstname)
  if @fullnameorder=2 and N''=rtrim(@thirdname) set @fullname=rtrim(@firstname)
  if @fullnameorder=3 SET @fullname=rtrim(@firstname)+N' '+rtrim(@thirdname)  
RETURN @fullname Collate database_default

END

GO

