


CREATE  FUNCTION [dbo].[EmpObjectiveAutoScore] (@empid as int,@DocumentNo as int ,@RaterProfileid as int)  
RETURNS numeric(18,3)  AS  

--DECLARE @empid as int,@DocumentNo as int ,@RaterProfileid as int
--SELECT @empid =207895,@DocumentNo =4 ,@RaterProfileid =0
begin


declare  @Score as  numeric(18,3),@RoleWeight AS bit,@AppraisalNo AS smallint
SELECT @RoleWeight=0 ,@Score=0

SELECT @RoleWeight=RoleWeight ,@AppraisalNo=EmpAppraisal.appraisalno
FROM EmpAppraisal
LEFT JOIN Appraisals ON Appraisals.AppraisalNo=EmpAppraisal.appraisalno
WHERE EmpAppraisal.empid=@empid AND EmpAppraisal.DocumentNo=@DocumentNo

DECLARE @wf AS int

SELECT @wf=count(8) FROM WFDocApproval wa  
WHERE DocumentNo=@DocumentNo AND empid=@empid AND SSDocNo IN
                   (SELECT SSDocument.SSDocNo FROM SSDocument WHERE SSDocument.SSDocType=6)

IF @RoleWeight=1 AND @RaterProfileid=0
     begin 
	declare @temp table(empid  int , documentno  int,appraisalno  int)
	insert into @temp
	select EmpID,DocumentNo,AppraisalNo from EmpAppraisal WHERE EmpAppraisal.empid=@empid AND EmpAppraisal.DocumentNo=@DocumentNo


                   SELECT  @Score=sum(isnull(AppraisalRoles.RoleWeightObjective,0.00) *
                   dbo.[EmpObjectiveRaterScore](@empid,@DocumentNo,CASE WHEN @wf>0 AND  WFDocApproval.RoleId=AppraisalRoles.RoleId THEN
                   	isnull(WFDocApproval.ApprovalProfileId,SSGroupRole.ProfileId)
                   	WHEN @wf=0 THEN SSGroupRole.ProfileId
                   	 ELSE -1 END))/
                   (CASE WHEN sum(isnull(AppraisalRoles.RoleWeightObjective,0.00))=0 THEN 1 ELSE sum(isnull(AppraisalRoles.RoleWeightObjective,0.00)) end )
                   FROM @temp as EmpAppraisal
                   left JOIN WFDocApproval  ON EmpAppraisal.DocumentNo = WFDocApproval.DocumentNo
                   AND EmpAppraisal.EmpID = WFDocApproval.EmpID AND EmpAppraisal.EmpID=@empid 
                   AND EmpAppraisal.DocumentNo=@DocumentNo AND WFDocApproval.SSDocNo IN
                   (SELECT SSDocument.SSDocNo FROM SSDocument WHERE SSDocument.SSDocType=6)
                   full  JOIN AppraisalRoles  ON AppraisalRoles.AppraisalNo=EmpAppraisal.AppraisalNo AND 
                   AppraisalRoles.RoleId=WFDocApproval.RoleId 
                   LEFT JOIN EmpAssignment ON EmpAssignment.EmpId=@EmpID
                   LEFT JOIN SSGroupRole ON SSGroupRole.SSGroup=EmpAssignment.SSGroup
                   AND SSGroupRole.RoleId=isnull(WFDocApproval.RoleId, AppraisalRoles.RoleId)
                   WHERE isnull(EmpAppraisal.AppraisalNo,AppraisalRoles.AppraisalNo)=@appraisalno
                   AND isnull(EmpAppraisal.DocumentNo,@DocumentNo)=@DocumentNo
                   AND isnull(EmpAppraisal.empid,@empid)=@empid
     END
     ELSE
     BEGIN
                   SELECT @Score=[dbo].[EmpObjectiveRaterScore] (@empid ,@DocumentNo,@RaterProfileid) 
     END

     
set @Score =  round(@Score ,2,1) 
return  isnull(@Score,0)

end

GO

