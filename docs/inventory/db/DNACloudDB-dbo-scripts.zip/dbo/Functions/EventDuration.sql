
CREATE   FUNCTION [dbo].[EventDuration] (@eventNo BIGINT,@From datetime ,@to datetime ,@IncludeVacation BIT,@unit NCHAR(1))
RETURNS float
BEGIN 
	DECLARE @days AS float,@vactype as SMALLINT, @TrainFrom DATETIME, @TrainTo DATETIME
		Select @TrainFrom = Case WHEN TrainingEvents.EventFromDate > @From THEN TrainingEvents.EventFromDate ELSE @From END,
			   @TrainTo = Case WHEN Trainingevents.EventToDate < @to THEN Trainingevents.EventToDate ELSE @to END
		FROM TrainingEvents WHERE TrainingEvent=@eventNo

   IF  not exists(SELECT TrainingEvent FROM TrainingSessions WHERE TrainingEvent=@eventNo)
	BEGIN	--if Event has no sessions then get duration between Event from&to excluding weekends&holidays
	   
	    SELECT @vactype=defvacpack FROM SysParam
		
   		SELECT @days= CASE WHEN @IncludeVacation=0 
   		THEN DATEDIFF(dd,@TrainFrom,@TrainTo)+1
   		ELSE (DATEDIFF(dd,@TrainFrom,@TrainTo)+1)-dbo.ExcludeWeekends(convert(Nvarchar(10),@TrainFrom,110),
   		convert(Nvarchar(10),@TrainTo,110),CASE WHEN @vactype IS NULL THEN 0 ELSE @vactype end) END 
   		   		
   		SELECT @days=@days*( CASE WHEN Lower(@unit)='d' THEN 1 ELSE 8 END ) --we supposed that the training day is 8 hours	
	END
   ELSE IF Lower(@unit)='d'
   	BEGIN	--if Event has sessions and unit is days then get the count of distinct session days
   		SELECT @days= COUNT( DISTINCT(CONVERT(nVARCHAR(10),TrainingSessionFrom ,111)  ))
		FROM TrainingSessions WHERE TrainingEvent=@eventNo
		AND CONVERT(nVARCHAR(10),TrainingSessionFrom,111) BETWEEN CONVERT(nVARCHAR(10),@TrainFrom,111)  AND CONVERT(nVARCHAR(10),@TrainTo,111) 
		AND CONVERT(nVARCHAR(10),TrainingSessionTo,111) BETWEEN CONVERT(nVARCHAR(10),@TrainFrom,111)  AND CONVERT(nVARCHAR(10),@TrainTo,111) 

   	END
   ELSE
   	BEGIN	--if Event has sessions and unit is hours then get the sum of total sessions hours
   		SELECT @days=sum(DATEDIFF(ss,TrainingSessions.trainingsessionfrom,TrainingSessions.trainingsessionto)/60.0/60.0)
		FROM TrainingSessions WHERE TrainingEvent=@eventNo
		AND CONVERT(nVARCHAR(10),TrainingSessionFrom,111) BETWEEN CONVERT(nVARCHAR(10),@TrainFrom,111)  AND CONVERT(nVARCHAR(10),@TrainTo,111) 
		AND CONVERT(nVARCHAR(10),TrainingSessionTo,111) BETWEEN CONVERT(nVARCHAR(10),@TrainFrom,111)  AND CONVERT(nVARCHAR(10),@TrainTo,111) 

   	END
   RETURN @days
END

GO

