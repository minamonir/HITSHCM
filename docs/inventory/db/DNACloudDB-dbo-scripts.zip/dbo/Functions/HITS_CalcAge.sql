CREATE     FUNCTION [dbo].[HITS_CalcAge]
  (@Birthdate smalldatetime, @EffectiveDate smalldatetime)
	
RETURNS nchar(10)
AS
 BEGIN
 declare @Age nchar(10)
 SET @Age=
 CASE WHEN DB_NAME()='CL000059' THEN  
 CASE when datediff(yy,@Birthdate,@EffectiveDate)<20 then '..-19'
		when datediff(yy,@Birthdate,@EffectiveDate)<=29 then '20-29'
		when datediff(yy,@Birthdate,@EffectiveDate)<=39 then '30-39'
		when datediff(yy,@Birthdate,@EffectiveDate)<=49 then '40-49'
		when datediff(yy,@Birthdate,@EffectiveDate)<=59 then '50-59'
		when datediff(yy,@Birthdate,@EffectiveDate)>=60 then '60-..'
		ELSE ''
 END
 ELSE 
 CASE when datediff(yy,@Birthdate,@EffectiveDate)<=20 then '..-20'
		when datediff(yy,@Birthdate,@EffectiveDate)<=25 then '21-25'
		when datediff(yy,@Birthdate,@EffectiveDate)<=30 then '26-30'
		when datediff(yy,@Birthdate,@EffectiveDate)<=35 then '31-35'
		when datediff(yy,@Birthdate,@EffectiveDate)<=40 then '36-40'
		when datediff(yy,@Birthdate,@EffectiveDate)<=45 then '41-45'
		when datediff(yy,@Birthdate,@EffectiveDate)<=50 then '46-50'
		when datediff(yy,@Birthdate,@EffectiveDate)<=55 then '51-55'
		when datediff(yy,@Birthdate,@EffectiveDate)<=60 then '56-60'	
		when datediff(yy,@Birthdate,@EffectiveDate)>60 then '60-..'
		ELSE ''
 END
 END
 
return @Age

END

GO

