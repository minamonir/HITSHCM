
CREATE FUNCTION [dbo].GetDocumentNoLevel2 (@ProfileId int, @SSDocType smallint, @DocumentNo int)
RETURNS  int 
AS 
BEGIN 
  DECLARE @RecomendationId AS int 
	---EmpAppraisalRec
   IF @SSDocType=1 SELECT TOP 1 @RecomendationId=RecommendationID FROM EmpAppraisalRec WHERE Empid=@ProfileId AND DocumentNo=@DocumentNo ORDER BY Empid, DocumentNo, RecommendationID DESC   
   
SET @RecomendationId=isnull(@RecomendationId,0)
   WHILE  1=1
    BEGIN
     if  @RecomendationId>2147483647 SET @RecomendationId=1 ELSE SET @RecomendationId=@RecomendationId+1 
	--EmpAppraisalRec
   IF @SSDocType=1 AND NOT EXISTS (SELECT RecommendationID FROM EmpAppraisalRec WHERE EmpId=@ProfileId AND DocumentNo=@DocumentNo AND RecommendationID=@RecomendationId)  BREAK  
  END 
  RETURN @RecomendationId
END

GO

