
CREATE FUNCTION [dbo].[hits_PermissionRestriction]
(
	 @empid as int, @permissionno as smallint, @fromdate as datetime,@todate as datetime,@lang as nchar(1), @DocNo AS INT
    
)
RETURNS nvarchar(MAX)
AS
BEGIN
	
--@MaxTotalSince=1      hiredate 
--@MaxTotalSince=2      probdate 
--@MaxTotalSince=3      calendar year start
--@MaxTotalSince=4      ContStart
--@MaxTotalSince=5      RevisedHireDate
--@MaxTotalSince=6      WorkReceivingDate
--@MaxTotalSince=7      PayrollGroup Year Start

IF DB_NAME() LIKE '%Cl000059%'
BEGIN
	IF EXISTS (SELECT EmpShiftInOut.EntryDate FROM EmpShiftInOut INNER JOIN TimePermission ON TimePermission.PermissionNo = @permissionno
	WHERE  EmpShiftInOut.EmpId = @empid 
	AND TimePermission.OverShort = 2
	AND ((DATEDIFF(MINUTE,EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn)>30 AND EmpShiftInOut.TimeIn IS NOT NULL AND EmpShiftInOut.ShiftSeconds<>0)
	OR (EmpShiftInOut.TimeIn IS NULL) OR (ShiftSeconds = 0)	)
	AND EmpShiftInOut.EntryDate = CAST(@fromdate AS DATE)
	AND EmpShiftInOut.EntryDate = CAST(@todate AS DATE)
	AND TimePermission.PermissionNoCons <> 1000 )
	BEGIN
	    RETURN '1You can not submit overtime permission because you were late or don''t have a TimeIn record.'
	END
   
END
-------------------------------------------------   That the permission must be requested in the same day  ---------------------------
IF ( (select PropName from SysParam) like N'%Egyptian International Motors%')
BEGIN
IF (cast(@fromdate as Date) != cast(@todate as Date) and (select PermissionNoCons from TimePermission where permissionno=@permissionno) = 1)
BEGIN
	RETURN isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','SameDay',@lang))),(case when @lang='E' THEN N'1Permission From & To dates must be on same date.' ELSE N'1تاريخي الإذن من و إلى يجب ان يكونوا ف نفس اليوم.' end))
end
END
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------   That the permission must be requested before 1 day  ---------------------------
IF ( (select PropName from SysParam) like N'%Misr Life insurance%' )


BEGIN
IF   convert (Date,@fromdate) <=   convert (Date,GETDATE())  
BEGIN
	RETURN isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','beforeoneday',@lang))),(case when @lang='E' THEN N'1the permission must be requested before 1 day from the permission date .' ELSE N'1يجب طلب الإذن قبل يوم واحد من تاريخ الإذن .' end))
   end
END
 --------------------------------------------------end  That the permission must be requested before 1 day  -----------------------------------------


declare @Latinlang as nchar(1)
set @Latinlang=@lang 
declare @reason as nvarchar(MAX)
set @reason =''

---------2017-01-26-------
declare @CalcActualPermLength as int=1
select @CalcActualPermLength=configvalue from sysparamconfig where configid='CalcActualPermLength'
-----------------------------------------------

declare @PermPolicyExist as SMALLINT, @PolicyOverShortType as smallint,  @PolicyAction as smallint, @PermissionPeriod AS bit, @MinHours as numeric(9, 3), 
@MaxHours as numeric(9, 3), @MaxTotal as bit, @MaxTotalNo as numeric(9, 3), @MaxTotalEvery as numeric(9, 3), @MaxTotalEveryUnit as smallint, @MaxTotalPermCodes AS NVARCHAR(MAX),
@MaxTotalSince as smallint, @MaxOccurance as bit, @MaxOccuranceNo as smallint, @MaxOccuranceEvery as numeric(9, 3),
@MaxOccEveryUnit as smallint, @MaxOccuranceSince as SMALLINT,@MaxOccurancePermCodes AS NVARCHAR(MAX), @HiringProratedHours as numeric(9, 3),@HireDate AS SMALLDATETIME,
@ProratedMaxTotalNo AS numeric(9, 3),@proratedMaxOccuranceNo AS SMALLINT,@MaxTotal1 AS bit,@MaxTotalNo1 AS numeric(9, 3),@MaxTotalEvery1 AS numeric(9, 3),
@MaxTotalEveryUnit1 AS SMALLINT,@MaxTotalSince1 AS SMALLINT,@MaxTotalPermCodes1 AS NVARCHAR(max),
@MaxOccurance1 AS BIT,@MaxOccuranceNo1 AS SMALLINT,@MaxOccuranceEvery1 AS numeric(9, 3),@MaxOccEveryUnit1 AS SMALLINT,
@MaxOccuranceSince1 AS SMALLINT,@MaxOccurancePermCodes1 AS NVARCHAR(max),@RequestFromValid BIT , @RequestFromNo INT , @RequestFromUnit SMALLINT   
, @MaxTotalIncludeSubmittedPerm as bit =0
, @MaxTotalIncludeSubmittedPerm1 as bit =0
, @MaxOccuranceIncludeSubmittedPerm as bit =0
, @MaxOccuranceIncludeSubmittedPerm1 as bit =0
, @MaxTotalIgnoreHireDate bit
, @MaxOccIgnoreHireDate bit
, @MaxTotalIgnoreHireDate1 bit
, @MaxOccIgnoreHireDate1 bit
,@dayoff as smallint,
 @DayPart AS smallint,
 @starWeekIndex as smallint,
 @diff as smallint

DECLARE @PolicyActionTemp SMALLINT


-- Parameter to know prevent or warning -- initial value : warning
-- 1 : prevent , 2 : warning
DECLARE @PreventWarning AS SMALLINT
SET @PreventWarning = 2

	declare @enablehijri as bit,@payrollgroup as smallint,@year as smallint,@h_Yearfrom as nchar(4),@h_Yearto as nchar(4)
    ,@h_MonthFrom as nchar(4),@h_MonthTo as nchar(4), @PermRqstOverShortType as smallint,@date1 as datetime,@date2 as DATETIME
    ,@totalhours as numeric(9, 3),@DecimalScale AS SMALLINT
    
	select @PermRqstOverShortType=OverShort ,@enablehijri=enablehijri from TimePermission cross join sysparam where PermissionNo=@permissionno
	
	select @payrollgroup=EmpAssignment.PayrollGroup,@Year=Cyear, @HireDate=EmpAssignment.HireDate
	from EmpAssignment inner join PayrollGroup on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup where EmpId=@empid

	-- getting the decimal scale
SELECT @DecimalScale = DecimalScale FROM SysParam
-- param. for the min-max hours (requested permission value)
declare @PermRqstOverShortValue as numeric(9, 3),@UsefulPart AS NUMERIC(9,3)

-- Employee TimeRule (Fixed Hours or not ? )
---------------------------------------------
DECLARE @FixedHours AS BIT
SELECT @FixedHours = (SELECT tr.FixedHours
                      FROM EmpAssignment ea INNER JOIN TimeRules tr ON tr.TimeRule = ea.TimeRule
                      WHERE ea.EmpId = @EmpId)
---------------------------------------------------------------------------------------------------------------------
------------------------- To know if there is any policy for this perm. or not---------------------------------------
--get the count of the policies on the requested permission ..
---- if this count = 0 --> return by '001' (accepted permission)
---- if this count <> 0 --> go through a cursor to loop on the perm. policies..
DECLARE @PermPolicyCount AS INT
SELECT @PermPolicyCount = COUNT(*)
FROM [TimePermissionPolicy]
INNER JOIN EmpAssignment ON EmpAssignment.TimeRule=TimePermissionPolicy.TimeRule
WHERE PermissionNo=@PermissionNo AND empid=@empid
 
IF (@PermPolicyCount = 0)
BEGIN
	-- policies count = 0
	SET @reason = ''
END
ELSE
BEGIN
	-- policies count <> 0
------------------------- looping on the different OverShort policy records for this PermissionNo -------------------

declare OverShortCursor CURSOR for 
SELECT TimePermissionPolicy.[OverShort],[PolicyAction],[PermissionPeriod],[MinHours],[MaxHours] ,[MaxTotal],[MaxTotalNo],[MaxTotalEvery]
      ,[MaxTotalEveryUnit] ,[MaxTotalSince],[MaxTotalPermCodes],[MaxOccurance],[MaxOccuranceNo],[MaxOccuranceEvery],
	  [MaxOccEveryUnit],[MaxOccuranceSince],[MaxOccurancePermCodes],
	  [MaxTotal1],[MaxTotalNo1],[MaxTotalEvery1],[MaxTotalEveryUnit1],[MaxTotalSince1],
	  [MaxTotalPermCodes1],[MaxOccurance1],[MaxOccuranceNo1],[MaxOccuranceEvery1],[MaxOccEveryUnit1],
	  [MaxOccuranceSince1],[MaxOccurancePermCodes1],TimePermissionPolicy.RequestFromValidity,TimePermissionPolicy.RequestFromNo,TimePermissionPolicy.RequestFromUnit
      ,[MaxTotalIncludeSubmittedPerm],[MaxTotalIncludeSubmittedPerm1]
      ,[MaxOccuranceIncludeSubmittedPerm],[MaxOccuranceIncludeSubmittedPerm1],[MaxTotalIgnoreHireDate],[MaxOccIgnoreHireDate],[MaxTotalIgnoreHireDate1],[MaxOccIgnoreHireDate1]
	  ,case when doffday2<> 0 then doffday2 when doffday1<>0 then doffday1 else 7 end
 
 FROM [TimePermissionPolicy]
  INNER JOIN EmpAssignment ON EmpAssignment.TimeRule=TimePermissionPolicy.TimeRule
  inner join vacpack on vacpack.vacpack=empassignment.VacPack
WHERE PermissionNo=@PermissionNo AND empid=@empid

open OverShortCursor 
-------- in case no policy exists for this permission
------IF @@CURSOR_ROWS=0
------BEGIN
------	RETURN '001'
------END

Fetch next from OverShortCursor
into @PolicyOverShortType,@PolicyAction,@PermissionPeriod,@MinHours,@MaxHours,@MaxTotal,@MaxTotalNo,@MaxTotalEvery,
	@MaxTotalEveryUnit,@MaxTotalSince,@MaxTotalPermCodes,@MaxOccurance,@MaxOccuranceNo,@MaxOccuranceEvery,@MaxOccEveryUnit,@MaxOccuranceSince,@MaxOccurancePermCodes,
	@MaxTotal1 ,@MaxTotalNo1,@MaxTotalEvery1,
	@MaxTotalEveryUnit1,@MaxTotalSince1,@MaxTotalPermCodes1,
	@MaxOccurance1 ,@MaxOccuranceNo1 ,@MaxOccuranceEvery1 ,@MaxOccEveryUnit1,
	@MaxOccuranceSince1,@MaxOccurancePermCodes1
	,@RequestFromValid  , @RequestFromNo  , @RequestFromUnit  
	,@MaxTotalIncludeSubmittedPerm, @MaxTotalIncludeSubmittedPerm1
	,@MaxOccuranceIncludeSubmittedPerm, @MaxOccuranceIncludeSubmittedPerm1,@MaxTotalIgnoreHireDate,@MaxOccIgnoreHireDate,@MaxTotalIgnoreHireDate1,@MaxOccIgnoreHireDate1
	,@dayoff

while @@fetch_status =0
BEGIN
	
	---------------------------------------------------MinHours and MaxHours---------------------------------------------------------
	if @PermissionPeriod=1
	BEGIN
		--calc the duration of the time permission requested[to - from] & check that it is between min & max hours required
		-- And if it is not between min & max required -- > we will calculate the useful part of this permission and if it is between the min & max allowed 
		-- --> will put a notification for our user about that in the error msg

		----------------2017-01-26----------
		--if @CalcActualPermLength = 1 
		--begin
		--   SELECT @PermRqstOverShortValue = isnull(DATEDIFF(s,@fromdate,@todate),0)/3600.00
		--end
		--else
		--begin 
		--  SELECT @PermRqstOverShortValue = dbo.PermissionTotalTaken(@empid,@DocNo,@fromdate,@todate,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		--end
		select @PermRqstOverShortValue = dbo.PermissionLength(@empid,@DocNo,@permissionno, @fromdate,@todate)/3600.00
		
		------------------------------		
		SELECT @UsefulPart = dbo.PermissionTotalTaken(@empid,@DocNo,@fromdate,@todate,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		DECLARE @usefulpartstring AS NVARCHAR(100)
		DECLARE @usefulH AS SMALLINT,@usefulM AS SMALLINT 
		SET @usefulH = @UsefulPart
		SET @usefulM = CEILING((cast(@UsefulPart AS NUMERIC(9,3)) - cast(@usefulH AS NUMERIC(9,3))) * 60.00)
		SELECT @UsefulPart = (@usefulH * 1.00) + (@usefulM / 60.00)
		if (@PermRqstOverShortValue not between @MinHours and @MaxHours) OR ((@PermRqstOverShortValue BETWEEN @MinHours AND @MaxHours) AND (@UsefulPart < @PermRqstOverShortValue) AND (@UsefulPart BETWEEN @MinHours AND @MaxHours))  
			BEGIN
				SET @PolicyActionTemp = (CASE WHEN (@PolicyAction = 1) AND (@PermRqstOverShortValue BETWEEN @MinHours AND @MaxHours) AND (@UsefulPart < @PermRqstOverShortValue) AND (@UsefulPart BETWEEN @MinHours AND @MaxHours) THEN 2 ELSE @PolicyAction END)
				SELECT @usefulpartstring =  ' [ ' + CONVERT(NVARCHAR(9),@usefulH) + ' ] ' + (CASE WHEN @usefulH > 1 THEN ISNULL(LTRIM(RTRIM(dbo.hits_GetDCCaption('PermissionRestriction','Hours',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'hours and ' ELSE N'ساعة و ' END)) ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','hour',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'hour and ' ELSE N'ساعة و ' END)) END ) 
				                          + ' [ ' + convert(NVARCHAR(9),@usefulM) + ' ] ' + (CASE WHEN @usefulM > 1 THEN ISNULL(LTRIM(RTRIM(dbo.hits_GetDCCaption('PermissionRestriction','Minutes',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'minutes ' ELSE N' دقيقة ' END)) ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minute',@Latinlang))),(CASE WHEN @Latinlang = 'E' THEN 'minute ' ELSE N' دقيقة ' END)) END )
				----SELECT  @usefulpartstring = CASE WHEN @latinlang = 'E' THEN  ' [ ' + CONVERT(NVARCHAR(9),@usefulH) + ' ] '+ CASE WHEN @usefulH > 1 THEN ISNULL(LTRIM(RTRIM(dbo.hits_GetDCCaption('PermissionRestriction','Hours','E'))),'hours')+' and ' ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','hour','E'))),'hour')+' and [ ' END +convert(NVARCHAR(9),@usefulM) + ' ] ' + CASE WHEN @usefulM > 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minutes','E'))),'minutes ') ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minute','E'))),'minute ') END
				----                                                       ELSE   ' [ ' + CONVERT(NVARCHAR(9),@usefulH) + ' ] ' + ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Hour','A'))), N'ساعة ') + N' و [ ' +convert(NVARCHAR(9),@usefulM) + ' ] '  + ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Minute','A'))), N'دقيقة ') END 
				
				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END	
				set @reason= @reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + 
				
				     CASE WHEN @PolicyActionTemp = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
					       ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
					       +'002'+rtrim(ltrim(str(@PolicyActionTemp)))+' - '
					       
			        + (CASE WHEN @PermRqstOverShortValue NOT BETWEEN @MinHours AND @MaxHours THEN  
					    	isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','MinMaxHours',@latinlang))),(case when @latinlang='E' THEN 'Time permission length is not between min and max hours' ELSE ' مدة الإذن ليست فى الفترة المسموح بها ' end))+' .. '
					        ELSE '' END)
					               
					+ (CASE WHEN (@UsefulPart < @PermRqstOverShortValue) AND (@UsefulPart BETWEEN @MinHours AND @MaxHours) THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','UsefulPart',@Latinlang))), (CASE WHEN @Latinlang ='E' THEN 'Note : The useful part of this permission is ' ELSE N'ملاحظة : الجزء المستفاد به من هذا الأذن هو'  END)) +@usefulpartstring ELSE '' END)
					  
		            -- set the PreventWarning Param depending on the policy
					 SET @PreventWarning = CASE WHEN @PolicyActionTemp = 1 THEN 1 ELSE @PreventWarning END
			end
	end
		
	-------------------------------------------------------Total Hours-------------------------------------------------------------

	if @MaxTotal=1 AND @MaxTotalEvery<>0
	-- @MaxTotalEvery should not equal zero to prevent an endless loop --> if @MaxTotalEvery = 0 means it is accepted perm
	BEGIN
	IF @MaxTotalNo = 0
	BEGIN
		-- setting the reason directly if the max total hours number = 0
		SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
		set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						 -- set the PreventWarning Param depending on the policy
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
	END
	ELSE
		BEGIN
	-- select the start date for calculations (@date1) depending on the user's choice
		select @date1=case when @MaxTotalSince=1 then hiredate 
						   when @MaxTotalSince=2 then isnull(probdate,hiredate) 
						   WHEN @MaxTotalSince=3 THEN CONVERT(smalldatetime,'01/01/'+ltrim(str(year(@fromdate))),111) 
						   WHEN @MaxTotalSince=4 THEN ContStart
						   WHEN @MaxTotalSince=5 THEN isnull(RevisedHireDate,hiredate)
						   WHEN @MaxTotalSince=6 THEN isnull(WorkReceivingDate,hiredate)
						   WHEN @MaxTotalSince=7 THEN (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) END)
					   end 
					  from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
	
	---@date2= @date1 + @MaxTotalEvery
	--@MaxTotalEveryUnit : determines whether @MaxTotalEvery is day, month or year
	--@MaxTotalEvery: the parameter at which max total days 'll reset
	-- increment the values of @date1 and @date2 by the chosen period until @fromdate is within their range
		if @MaxTotalEveryUnit=4
   begin
 
       set @starWeekIndex=case when @dayoff=7 then 1 else @dayoff+1 end
	   set @DayPart=DATEPART(WEEKDAY,@date1)
	   

	   set @diff=case when @DayPart>=@starWeekIndex then @starWeekIndex-@DayPart else (7- (@starWeekIndex-@DayPart))*-1 end
	
		set  @date1= dateadd(dd,@diff,@date1)
		
    end
----------------------add week above-------------------------------------------
		if @enablehijri=1 and @year<1900 -- in case of hijri
		begin
			set @date2=case
			when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1) -- months
			when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)  -- years
			when @MaxTotalEveryUnit=4 then dbo.h_dateadd('WW',@MaxTotalEvery,@date1)  --weeks
			else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)END						  -- days
			
			while (@fromdate not between @date1 and @date2)
			begin
				set @date1=@date2
				set @date2=case
				when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=4 then dbo.h_dateadd('WW',@MaxTotalEvery,@date1)
				else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)END
			end
		
		end
		ELSE    -- in case of gregorian
		begin
			set @date2=case
			when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=4 then dateadd(WW,@MaxTotalEvery,@date1)
			else dateadd(d,@MaxTotalEvery,@date1)END
			while (@fromdate not between @date1 and @date2)
			begin
				set @date1=@date2
				set @date2=case
				when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=4 then dateadd(WW,@MaxTotalEvery,@date1)
				else dateadd(d,@MaxTotalEvery,@date1)END
			end	
		END
		-- calculate total permissions length in current period & the part of the new permission inside this period
		------------2017-01-26---------------
		--if isnull(@CalcActualPermLength,0) = 1
		--begin
		--  SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
		--end
		--else
		--begin
		--  set @totalhours = dbo.PermissionTotalTaken(@empid,@DocNo,@date1,@date2,0,@PolicyOverShortType,@fromdate,@todate)/3600.00

		-- if (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		-- begin
		--   set @totalhours = @totalhours + dbo.PermissionTotalTaken(@empid,@DocNo,case  when @fromdate > @date1 then @fromdate else @date1 end,case when @todate > @date2 then @date2 else @todate end ,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		-- end
		 
		--end
		
		if isnull(@MaxTotalIncludeSubmittedPerm ,0)= 1
		  begin 
			SET @totalhours =dbo.PermissionTotalTakenWithStatus(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes, N',5,1,') /3600.00
		 end 
		 else 
		 begin 
			SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
		 end 
		 ------------------------------------

		--compare the calculated total hours with Max Total Allowed
		-------------------------------------
		--@MaxOccEveryUnit=1 day  --@MaxOccEveryUnit=2 month  --@MaxOccEveryUnit=3 year  
		
		-- In case the hiredate is between @date1 & @date2 then :
		-- find the @ProratedMaxTotalNo - the part of the MaxTotalNo - from his hiring date till @date2
		SET @HiringProratedHours = 0.00
		IF (@MaxTotalSince=3 OR @MaxTotalSince=7) AND (@HireDate BETWEEN @date1 AND @date2) AND @HireDate <> @date1 AND @MaxTotalIgnoreHireDate = 0
		BEGIN
			SELECT @HiringProratedhours=(datediff(mi,@date1,@HireDate))/60.00
		end
		IF @HiringProratedHours<>0
			SET @ProratedMaxTotalNo=(@MaxTotalNo/(((datediff(mi,@date1,@date2)/60.00))*1.00))*((datediff(mi,@date1,@date2)/60.00)-@HiringProratedHours)
		ELSE 
			SET @ProratedMaxTotalNo=@MaxTotalNo

		if @ProratedMaxTotalNo< isnull(@totalhours,0) 
		begin
		    SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
		END
        
		----------------------------- custom policy for customer CAF that  Employee should not exceed the overtime per month more than 30 hours -----------------
		--IF DB_NAME() LIKE '%Cl000122%' -- CAF 
		--BEGIN
		--IF(@permissionno = 1)
		--BEGIN
		--DECLARE @periodstart AS SMALLDATETIME , @periodend AS SMALLDATETIME, @totalhoursInMonth AS INT  , @maxHoursAllowed AS INT = 30
		 
		-- IF(@MaxTotalSince = 3)
		-- BEGIN
		--	SELECT @periodstart = CONVERT(SMALLDATETIME, LTRIM(str(year(@fromdate)))+ '-'+LTRIM(str(MONTH(@fromdate))) + '-'+'01'),
		--	@periodend = DATEADD( MONTH,1,@periodstart) -1  
		-- END
		-- ELSE
		-- BEGIN  
		--     IF ( @fromdate BETWEEN dbo.periodstart(@PayrollGroup, MONTH(@fromdate), year(@fromdate)) AND dbo.periodend(@payrollgroup, MONTH(@fromdate), year(@fromdate)) )
		--	 BEGIN
		--	    SELECT @periodstart = dbo.periodstart(@PayrollGroup, MONTH(@fromdate), year(@fromdate)) , @periodend = dbo.periodend(@payrollgroup, MONTH(@fromdate), year(@fromdate))
		--	 END
		--	 ELSE  
		--	 BEGIN 
		--			DECLARE  @mydate AS SMALLDATETIME =  DATEADD(MONTH,1, @fromdate )
		--	      SELECT @periodstart = dbo.periodstart(@PayrollGroup, MONTH(@mydate), year(@mydate)) , @periodend = dbo.periodend(@payrollgroup, MONTH(@mydate), year(@mydate))
		--	 END
		-- END 
		--     SET @totalhoursInMonth = dbo.PermissionTotalTakenActual(@empid,@DocNo,@periodstart,@periodend,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
		 		 
		--		IF  @maxHoursAllowed  < isnull(@totalhoursInMonth,0) 
		--		BEGIN  
		--				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
		--				SET @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
		--				CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
		--				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
		--				CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
		--				+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						
		--				 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
		--		END
		--	END
		--END
		----------------------------- end custom policy for customer CAF that  Employee should not exceed the overtime per month more than 30 hours -----------------

		-- if the @todate falls within another period:
		-- reset the ranges for @date1 and @date2 with the new period start and end dates
		while  (@todate not between @date1 and @date2 ) 
		begin

			set @date1=@date2
			if @enablehijri=1 and @year<1900	-- in case of hijri
			begin
				set @date2=case
				when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)	-- month
				when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)	-- year
				when @MaxTotalEveryUnit=4 then dbo.h_dateadd('WW',@MaxTotalEvery,@date1)   --weeks
				else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)END							-- days

			end
			ELSE		-- in case of gregorian
			begin
				set @date2=case
				when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
				when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
               	when @MaxTotalEveryUnit=4 then dateadd(WW,@MaxTotalEvery,@date1)
				else dateadd(d,@MaxTotalEvery,@date1)END
			end
			
			--calc. totalhours for the 2nd period
			------------2017-01-26---------------
		--if isnull(@CalcActualPermLength,0) = 1
		--begin
		-- SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
		--end
		--else
		--begin
		--  set @totalhours = dbo.PermissionTotalTaken(@empid,@DocNo,@date1,@date2,0,@PolicyOverShortType,@fromdate,@todate)/3600.00
		-- if (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		-- begin
		--   set @totalhours = @totalhours + dbo.PermissionTotalTaken(@empid,@DocNo,case  when @fromdate > @date1 then @fromdate else @date1 end,case when @todate > @date2 then @date2 else @todate end ,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		-- end
	
		--end

		 if isnull(@MaxTotalIncludeSubmittedPerm ,0)= 1
		  begin 
			SET @totalhours =dbo.PermissionTotalTakenWithStatus(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes, N',5,1,') /3600.00
		 end 
		 else 
		 begin 
			SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes)/3600.00
		 end 
		 ------------------------------------
			

			SET @ProratedMaxTotalNo=@MaxTotalNo
			if @ProratedMaxTotalNo< isnull(@totalhours,0)
			begin
				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
				set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
							ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
							CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
							+'007'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours' else ' الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
							
							 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
			end

		END
-- end of the else block of condition (maxtotalno = 0)		
		END
-- end of the maxtotalhours block
	END
	-------------------------------------------------------Total Hours1-------------------------------------------------------------

	
	if @MaxTotal1=1 AND @MaxTotalEvery1<>0		
	-- @MaxTotalEvery1 should not equal zero to prevent an endless loop --> if @MaxTotalEvery1 = 0 means it is accepted perm
	BEGIN
	IF @MaxTotalNo1 = 0
	BEGIN
	IF CHARINDEX('006',@reason) <=0
	BEGIN
	    -- setting the reason directly if the max total hours number = 0
		SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
		set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours1',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours 1' else '1 الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						 -- set the PreventWarning Param depending on the policy
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END
	END
		
	END
	ELSE
		BEGIN
	-- select the start date for calculations (@date1) depending on the user's choice
		select @date1=case when @MaxTotalSince1=1 then hiredate 
						   when @MaxTotalSince1=2 then isnull(probdate,hiredate) 
						   WHEN @MaxTotalSince1=3 THEN CONVERT(smalldatetime,'01/01/'+ltrim(str(year(@fromdate))),111) 
						   WHEN @MaxTotalSince1=4 THEN ContStart
						   WHEN @MaxTotalSince1=5 THEN isnull(RevisedHireDate,hiredate)
						   WHEN @MaxTotalSince1=6 THEN isnull(WorkReceivingDate,hiredate)
						   WHEN @MaxTotalSince1=7 THEN (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) END)
					   end 
					  from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
	
	---@date2= @date1 + @MaxTotalEvery1
	--@MaxTotalEveryUnit1 : determines whether @MaxTotalEvery1 is day, month or year
	--@MaxTotalEvery1: the parameter at which max total days 'll reset
	-- increment the values of @date1 and @date2 by the chosen period until @fromdate is within their range
		if @MaxTotalEveryUnit1=4
   begin
 
       set @starWeekIndex=case when @dayoff=7 then 1 else @dayoff+1 end
	   set @DayPart=DATEPART(WEEKDAY,@date1)
	   

	   set @diff=case when @DayPart>=@starWeekIndex then @starWeekIndex-@DayPart else (7- (@starWeekIndex-@DayPart))*-1 end
	
		set  @date1= dateadd(dd,@diff,@date1)
		
    end
	----------------------add week above-------------------------------------------




		if @enablehijri=1 and @year<1900 -- in case of hijri
		begin
			set @date2=case
			when @MaxTotalEveryUnit1=2 then dbo.h_dateadd('MM', @MaxTotalEvery1,@date1) -- months
			when @MaxTotalEveryUnit1=3 then dbo.h_dateadd('YY',@MaxTotalEvery1,@date1)  -- years
			when @MaxTotalEveryUnit1=4 then dbo.h_dateadd('WW',@MaxTotalEvery1,@date1)  --weeks
			else dbo.h_dateadd('DD',@MaxTotalEvery1,@date1)END						  -- days
			
			while (@fromdate not between @date1 and @date2)
			begin
				set @date1=@date2
				set @date2=case
				when @MaxTotalEveryUnit1=2 then dbo.h_dateadd('MM', @MaxTotalEvery1,@date1)
				when @MaxTotalEveryUnit1=3 then dbo.h_dateadd('YY',@MaxTotalEvery1,@date1)
				when @MaxTotalEveryUnit1=4 then dbo.h_dateadd('WW',@MaxTotalEvery1,@date1)
				else dbo.h_dateadd('DD',@MaxTotalEvery1,@date1)END
			end
		
		end
		ELSE    -- in case of gregorian
		begin
			set @date2=case
			when @MaxTotalEveryUnit1=2 then dateadd(m,@MaxTotalEvery1,@date1)
			when @MaxTotalEveryUnit1=3 then dateadd(yy,@MaxTotalEvery1,@date1)
			when @MaxTotalEveryUnit1=4 then dateadd(WW,@MaxTotalEvery1,@date1)
			else dateadd(d,@MaxTotalEvery1,@date1)END
			while (@fromdate not between @date1 and @date2)
			begin
				set @date1=@date2
				set @date2=case
				when @MaxTotalEveryUnit1=2 then dateadd(m,@MaxTotalEvery1,@date1)
				when @MaxTotalEveryUnit1=3 then dateadd(yy,@MaxTotalEvery1,@date1)
				when @MaxTotalEveryUnit1=4 then dateadd(WW,@MaxTotalEvery1,@date1)

				else dateadd(d,@MaxTotalEvery1,@date1)END
			end	
		END
		-- calculate total permissions length in current period & the part of the new permission inside this period
		------------2017-01-26---------------
		--if isnull(@CalcActualPermLength,0) = 1
		--begin
		--  SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes1)/3600.00
		--end
		--else
		--begin
		--  set @totalhours = dbo.PermissionTotalTaken(@empid,@DocNo,@date1,@date2,0,@PolicyOverShortType,@fromdate,@todate)/3600.00

		-- if (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		-- begin
		--   set @totalhours = @totalhours + dbo.PermissionTotalTaken(@empid,@DocNo,case  when @fromdate > @date1 then @fromdate else @date1 end,case when @todate > @date2 then @date2 else @todate end ,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		-- end
		 
		--end
		
		 if isnull(@MaxTotalIncludeSubmittedPerm1 ,0)= 1
		  begin 
			SET @totalhours =dbo.PermissionTotalTakenWithStatus(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes1, N',5,1,') /3600.00
		 end 
		 else 
		 begin 
			SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@fromdate,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes1)/3600.00
		 end 
		 ------------------------------------

		--compare the calculated total hours with Max Total Allowed
		-------------------------------------
		--@MaxOccEveryUnit=1 day  --@MaxOccEveryUnit=2 month  --@MaxOccEveryUnit=3 year  
		
		-- In case the hiredate is between @date1 & @date2 then :
		-- find the @ProratedMaxTotalNo - the part of the MaxTotalNo - from his hiring date till @date2
		SET @HiringProratedHours = 0.00
		IF (@MaxTotalSince1=3 OR @MaxTotalSince1=7) AND (@HireDate BETWEEN @date1 AND @date2) AND @HireDate <> @date1 AND @MaxTotalIgnoreHireDate1 = 0
		BEGIN
			SELECT @HiringProratedhours=(datediff(mi,@date1,@HireDate))/60.00
		end
		IF @HiringProratedHours<>0
			SET @ProratedMaxTotalNo=(@MaxTotalNo1/(((datediff(mi,@date1,@date2)/60.00))*1.00))*((datediff(mi,@date1,@date2)/60.00)-@HiringProratedHours)
		ELSE 
			SET @ProratedMaxTotalNo=@MaxTotalNo1

		if @ProratedMaxTotalNo< isnull(@totalhours,0) 
		BEGIN
			IF CHARINDEX('006',@reason) <=0
			BEGIN
			    		    SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+ '006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours1',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours 1' else '1 الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END

			END
		END
       
		-- if the @todate falls within another period:
		-- reset the ranges for @date1 and @date2 with the new period start and end dates
		while  (@todate not between @date1 and @date2 ) 
		begin

			set @date1=@date2
			if @enablehijri=1 and @year<1900	-- in case of hijri
			begin
				set @date2=case
				when @MaxTotalEveryUnit1=2 then dbo.h_dateadd('MM', @MaxTotalEvery1,@date1)	-- month
				when @MaxTotalEveryUnit1=3 then dbo.h_dateadd('YY',@MaxTotalEvery1,@date1)	-- year
				when @MaxTotalEveryUnit1=4 then dbo.h_dateadd('WW',@MaxTotalEvery1,@date1)   --weeks
				else dbo.h_dateadd('DD',@MaxTotalEvery1,@date1)END							-- days

			end
			ELSE		-- in case of gregorian
			begin
				set @date2=case
				when @MaxTotalEveryUnit1=2 then dateadd(m,@MaxTotalEvery1,@date1)
				when @MaxTotalEveryUnit1=3 then dateadd(yy,@MaxTotalEvery1,@date1)
				when @MaxTotalEveryUnit1=4 then dateadd(WW,@MaxTotalEvery1,@date1)
				else dateadd(d,@MaxTotalEvery1,@date1)END
			end
			
			--calc. totalhours for the 2nd period
			------------2017-01-26---------------
		--if isnull(@CalcActualPermLength,0) = 1
		--begin
		-- SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes1)/3600.00
		--end
		--else
		--begin
		--  set @totalhours = dbo.PermissionTotalTaken(@empid,@DocNo,@date1,@date2,0,@PolicyOverShortType,@fromdate,@todate)/3600.00
		-- if (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		-- begin
		--   set @totalhours = @totalhours + dbo.PermissionTotalTaken(@empid,@DocNo,case  when @fromdate > @date1 then @fromdate else @date1 end,case when @todate > @date2 then @date2 else @todate end ,1,@PermRqstOverShortType,@fromdate,@todate)/3600.00
		-- end
	
		--end

		if isnull(@MaxTotalIncludeSubmittedPerm1 ,0)= 1
		  begin 
			SET @totalhours =dbo.PermissionTotalTakenWithStatus(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes1, N',5,1,') /3600.00
		 end 
		 else 
		 begin 
			SET @totalhours = dbo.PermissionTotalTakenActual(@empid,@DocNo,@date1,@date2,@date1,@todate,@PolicyOverShortType,@permissionno,@MaxTotalPermCodes1)/3600.00
		 end 
		 ------------------------------------
			

			SET @ProratedMaxTotalNo=@MaxTotalNo1
			if @ProratedMaxTotalNo< isnull(@totalhours,0)
			BEGIN
            IF CHARINDEX('007',@reason) <=0
			BEGIN
			    				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
				set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
							ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
							CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
							+'007'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','TotalHours1',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max total hours 1' else '1 الإذن يتعدى الحد الاقصى للساعات المسموح بها' end))
							
							 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END

			END
			end

		END
-- end of the else block of condition (maxtotalno = 0)		
		END
-- end of the maxtotalhours block
	end

    

		---------------------------------------------Occurance------------------------------------------------------------------------

	if @MaxOccurance=1 AND @MaxOccuranceEvery<>0 
	BEGIN
		IF @MaxOccuranceNo = 0
		BEGIN
			-- setting the reason dircetly if the max occ number = 0
			SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances' else 'عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		END	
		ELSE
			BEGIN
			-- select the start date for calculations (@date1) depending on the user's choice
		declare @count as int
		set @count=0
		select @date1=case when @MaxOccuranceSince=1 then hiredate 
						   when @MaxOccuranceSince=2 then isnull(probdate,hiredate) 
						   WHEN @MaxOccuranceSince=3 THEN CONVERT(smalldatetime,'01/01/'+ltrim(str(year(@fromdate))),111) 
						   WHEN @MaxOccuranceSince=4 THEN ContStart
						   WHEN @MaxOccuranceSince=5 THEN isnull(RevisedHireDate,hiredate)
						   WHEN @MaxOccuranceSince=6 THEN isnull(WorkReceivingDate,hiredate)
						   WHEN @MaxOccuranceSince=7 THEN (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) END)
					   end 
					  from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
		
		--@date2= @date1 + @@MaxOccuranceEvery
		--@MaxOccEveryUnit : determines whether @MaxOccuranceEvery is day, month or year
		--@MaxOccuranceEvery: the parameter at which max occurance 'll reset
		-- increment the values of @date1 and @date2 by the chosen period until @fromdate is within their range

		
		if @MaxOccEveryUnit=4
   begin

       set @starWeekIndex=case when @dayoff=7 then 1 else @dayoff+1 end
	   set @DayPart=DATEPART(WEEKDAY,@date1)
	   

	   set @diff=case when @DayPart>=@starWeekIndex then @starWeekIndex-@DayPart else (7- (@starWeekIndex-@DayPart))*-1 end
	   
		set  @date1= dateadd(dd,@diff,@date1)
		
    end

		-------------------------add week above----------------------------------------------
		if @enablehijri=1 and @year<1900		-- in case of hijri
			begin
				set @date2=case
				when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)	-- month
				when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)	-- year
				when @MaxOccEveryUnit=4 then dbo.h_dateadd('WW',@MaxOccuranceEvery,@date1)  --weeks
				else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)END   					-- day
				
				while (@fromdate not between @date1 and @date2)
				begin
					set @date1=@date2
					set @date2=case
					when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)
					when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)
					when @MaxOccEveryUnit=4 then dbo.h_dateadd(N'WW',@MaxOccuranceEvery,@date1)
					else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)END
				end
			end
			
		ELSE			-- in case of gregorian
			begin
				set @date2=case
				when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=4 then dateadd(WW,@MaxOccuranceEvery,@date1)
				else dateadd(d,@MaxOccuranceEvery,@date1)END
				
				while (@fromdate not between @date1 and @date2)
				begin
				set @date1=@date2
				set @date2=case
				when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=4 then dateadd(WW,@MaxOccuranceEvery,@date1)
				else dateadd(d,@MaxOccuranceEvery,@date1)END

				end
			end

		--calc how many times this OverShort type was taken by the employee within @date1 and @date2
		--------------------------------------------------------------------------------------------
		-- If OverShortType is 4 (Over [Total]: get total count of (1,2,3,4)   
		-- If OverShortType is 8 (Short [Total]: get total count of (5,6,7,8)  
		-- Else, get total count of that OverShortType only
		select @count=sum(case when (DATEDIFF(s,CASE WHEN e.PermissionFrom < @date1 THEN @date1 ELSE e.PermissionFrom END,CASE WHEN e.PermissionTo > @date2 THEN @date2 ELSE e.PermissionTo END)) = 0 THEN 0 ELSE 1 END)
		 from EmpTimePermission e
		 LEFT JOIN TimePermission tp ON tp.PermissionNo = e.PermissionNo

		where (e.DocumentStatus=1 or e.DocumentStatus = case when @MaxOccuranceIncludeSubmittedPerm = 1 then 5 else 1 end)
		and e.empid=@empid AND e.DocumentNo<>@DocNo  
		AND tp.OverShort = (CASE WHEN ltrim(rtrim(@MaxOccurancePermCodes)) = '' THEN @PolicyOverShortType ELSE tp.OverShort END)
		--AND ((@PolicyOverShortType=4 AND tp.OverShort IN (1,2,3,4)) OR (@PolicyOverShortType=8 AND tp.OverShort IN (5,6,7,8)) OR (@PolicyOverShortType=tp.OverShort))
		AND LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxOccurancePermCodes)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(tp.PermissionNo)))+',%' END)
		and ((e.PermissionFrom between @date1 and @date2) or 
		     (e.PermissionTo between @date1 and @date2) or 
		     (@date1 between e.PermissionFrom and e.PermissionTo) or 
		     (@date2 between e.PermissionFrom  and e.PermissionTo))
		 
		--add the current requested TimePermission to the above count calculated only in the following cases:
		-- 1. if the [MaxOccurancePermCode] is empty -- >  the permission over/short type must be = policy over/short type
		-- 2. if the [MaxOccurancePermCode] is not empty -- > This codes [MaxOccurancePermCode] : must contain the permission no 
		
		----IF (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		IF ((LTRIM(RTRIM(@MaxOccurancePermCodes)) = '') AND(@PermRqstOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxOccurancePermCodes)) <> '') AND (LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
		set @count=@count+1
		
		
		--compare the Calculated Count above with Max Occurance allowed
		---------------------------------------------------------------
		-- In case the hiredate is between @date1 and @date2, 
		-- find the @ProratedMaxOccuranceNo - the part of MaxOccuranceNo - from his hiring date till @date2
		SET @HiringProratedHours = 0.00
		IF (@MaxOccuranceSince=3 OR @MaxOccuranceSince=7) AND (@HireDate BETWEEN @date1 AND @date2) AND (@HireDate<>@date1) AND @MaxOccIgnoreHireDate = 0
		BEGIN
			SELECT @HiringProratedHours=(datediff(mi,@date1,@HireDate))/60.00
		END

		IF @HiringProratedHours<>0				---OR @VacAffectDueDays<>0
			SET @proratedMaxOccuranceNo= (SELECT dbo.roundto((@MaxOccuranceNo/(((datediff(mi,@date1,@date2)/60.00))*1.00))*((datediff(mi,@date1,@date2)/60.00)-@HiringProratedHours),1,1))  
		ELSE 
			SET 	@proratedMaxOccuranceNo=@MaxOccuranceNo
		
		if @proratedMaxOccuranceNo<@count 
		BEGIN
			SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances' else 'عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		end

		-- if the @todate falls within the next period, reset the ranges for @date1 and @date2 with the new period start and end dates
		-------------------------------
		while  (@todate not between @date1 and @date2 ) 
		begin

			set @date1=@date2
			if @enablehijri=1 and @year<1900	-- case of hijri
			begin
				set @date2=case
				when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)		-- month
				when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)		-- year
				when @MaxOccEveryUnit=4 then dbo.h_dateadd('WW',@MaxOccuranceEvery,@date1)      --weeks
				else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)END								-- day

			end
			else
			begin
				set @date2=CASE					-- case of gregorian
				when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
				when @MaxOccEveryUnit=4 then dateadd(WW,@MaxOccuranceEvery,@date1)
				else dateadd(d,@MaxOccuranceEvery,@date1)END
			end
			
		set @count=0
		select @count=sum(case when (DATEDIFF(s,CASE WHEN e.PermissionFrom < @date1 THEN @date1 ELSE e.PermissionFrom END,CASE WHEN e.PermissionTo > @date2 THEN @date2 ELSE e.PermissionTo END)) = 0 THEN 0 ELSE 1 END) 
		from EmpTimePermission e
		 LEFT JOIN TimePermission tp ON tp.PermissionNo = e.PermissionNo
		
		where (e.DocumentStatus=1 or e.DocumentStatus = case when @MaxOccuranceIncludeSubmittedPerm = 1 then 5 else 1 end)
		and e.empid=@empid AND e.DocumentNo<>@DocNo  
		AND tp.OverShort = (CASE WHEN ltrim(rtrim(@MaxOccurancePermCodes)) = '' THEN @PolicyOverShortType ELSE tp.OverShort END)
		--AND ((@PolicyOverShortType=4 AND tp.OverShort IN (1,2,3,4)) OR (@PolicyOverShortType=8 AND tp.OverShort IN (5,6,7,8)) OR (@PolicyOverShortType=tp.OverShort))
		AND LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxOccurancePermCodes)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(tp.PermissionNo)))+',%' END)
		and ((e.PermissionFrom between @date1 and @date2) or 
		     (e.PermissionTo between @date1 and @date2) or 
		     (@date1 between e.PermissionFrom and e.PermissionTo) or 
		     (@date2 between e.PermissionFrom  and e.PermissionTo))
		

		----IF (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		IF ((LTRIM(RTRIM(@MaxOccurancePermCodes)) = '') AND(@PermRqstOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxOccurancePermCodes)) <> '') AND (LTRIM(RTRIM(@MaxOccurancePermCodes)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
			set @count=@count+1

		SET @proratedMaxOccuranceNo=@MaxOccuranceNo
		if @proratedMaxOccuranceNo<@count 
		begin
		    SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'009'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances' else 'عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		end

		end
		-----------------------------
-- end of the else block (if condition : maxoccNo = 0)
			END
-- end of the occno block			
END
-------------------------------------------------Occurance1-----------------------------------------------------------------------
	if @MaxOccurance1=1 AND @MaxOccuranceEvery1<>0
	BEGIN
		IF @MaxOccuranceNo1 = 0
		BEGIN

			IF CHARINDEX('008',@reason)<=0
			  BEGIN
        		-- setting the reason dircetly if the max occ number = 0
				SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
				set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
							ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
							CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
							+'008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance1',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances 1' else '1 عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
							 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
			END 
		
		END	
		ELSE
			BEGIN
			-- select the start date for calculations (@date1) depending on the user's choice
		declare @count1 as int
		set @count1=0
		select @date1=case when @MaxOccuranceSince1=1 then hiredate 
						   when @MaxOccuranceSince1=2 then isnull(probdate,hiredate) 
						   WHEN @MaxOccuranceSince1=3 THEN CONVERT(smalldatetime,'01/01/'+ltrim(str(year(@fromdate))),111) 
						   WHEN @MaxOccuranceSince1=4 THEN ContStart
						   WHEN @MaxOccuranceSince1=5 THEN isnull(RevisedHireDate,hiredate)
						   WHEN @MaxOccuranceSince1=6 THEN isnull(WorkReceivingDate,hiredate)
						   WHEN @MaxOccuranceSince1=7 THEN (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) END)
					   end 
					  from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
		
		--@date2= @date1 + @@MaxOccuranceEvery1
		--@MaxOccEveryUnit1 : determines whether @MaxOccuranceEvery1 is day, month or year
		--@MaxOccuranceEvery1: the parameter at which max occurance 'll reset
		-- increment the values of @date1 and @date2 by the chosen period until @fromdate is within their range

			
		if @MaxOccEveryUnit1=4
   begin

       set @starWeekIndex=case when @dayoff=7 then 1 else @dayoff+1 end
	   set @DayPart=DATEPART(WEEKDAY,@date1)
	   

	   set @diff=case when @DayPart>=@starWeekIndex then @starWeekIndex-@DayPart else (7- (@starWeekIndex-@DayPart))*-1 end
	   
		set  @date1= dateadd(dd,@diff,@date1)
		
    end

		-------------------------add week above----------------------------------------------


		if @enablehijri=1 and @year<1900		-- in case of hijri
			begin
				set @date2=case
				when @MaxOccEveryUnit1=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery1,@date1)	-- month
				when @MaxOccEveryUnit1=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery1,@date1)	-- year
				when @MaxOccEveryUnit1=4 then dbo.h_dateadd('WW',@MaxOccuranceEvery1,@date1)  --weeks
				else dbo.h_dateadd('DD',@MaxOccuranceEvery1,@date1)END   					-- day
				
				while (@fromdate not between @date1 and @date2)
				begin
					set @date1=@date2
					set @date2=case
					when @MaxOccEveryUnit1=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery1,@date1)
					when @MaxOccEveryUnit1=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery1,@date1)
					when @MaxOccEveryUnit1=4 then dbo.h_dateadd(N'WW',@MaxOccuranceEvery1,@date1)
					else dbo.h_dateadd('DD',@MaxOccuranceEvery1,@date1)END
				end
			end
			
		ELSE			-- in case of gregorian
			begin
				set @date2=case
				when @MaxOccEveryUnit1=2 then dateadd(m,@MaxOccuranceEvery1,@date1)
				when @MaxOccEveryUnit1=3 then dateadd(yy,@MaxOccuranceEvery1,@date1)
				when @MaxOccEveryUnit1=4 then dateadd(WW,@MaxOccuranceEvery1,@date1)
				else dateadd(d,@MaxOccuranceEvery1,@date1)END
				
				while (@fromdate not between @date1 and @date2)
				begin
				set @date1=@date2
				set @date2=case
				when @MaxOccEveryUnit1=2 then dateadd(m,@MaxOccuranceEvery1,@date1)
				when @MaxOccEveryUnit1=3 then dateadd(yy,@MaxOccuranceEvery1,@date1)
				when @MaxOccEveryUnit1=4 then dateadd(WW,@MaxOccuranceEvery1,@date1)
				else dateadd(d,@MaxOccuranceEvery1,@date1)END

				end
			end

		--calc how many times this OverShort type was taken by the employee within @date1 and @date2
		--------------------------------------------------------------------------------------------
		-- If OverShortType is 4 (Over [Total]: get total count of (1,2,3,4)   
		-- If OverShortType is 8 (Short [Total]: get total count of (5,6,7,8)  
		-- Else, get total count of that OverShortType only
		select @count1=sum(case when (DATEDIFF(s,CASE WHEN e.PermissionFrom < @date1 THEN @date1 ELSE e.PermissionFrom END,CASE WHEN e.PermissionTo > @date2 THEN @date2 ELSE e.PermissionTo END)) = 0 THEN 0 ELSE 1 END)
		 from EmpTimePermission e
		 LEFT JOIN TimePermission tp ON tp.PermissionNo = e.PermissionNo
		
		where (e.DocumentStatus=1 or e.DocumentStatus = case when @MaxOccuranceIncludeSubmittedPerm1 = 1 then 5 else 1 end)
		and e.empid=@empid AND e.DocumentNo<>@DocNo  
		AND tp.OverShort = (CASE WHEN ltrim(rtrim(@MaxOccurancePermCodes1)) = '' THEN @PolicyOverShortType ELSE tp.OverShort END)
		--AND ((@PolicyOverShortType=4 AND tp.OverShort IN (1,2,3,4)) OR (@PolicyOverShortType=8 AND tp.OverShort IN (5,6,7,8)) OR (@PolicyOverShortType=tp.OverShort))
		AND LTRIM(RTRIM(@MaxOccurancePermCodes1)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxOccurancePermCodes1)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(tp.PermissionNo)))+',%' END)
		and ((e.PermissionFrom between @date1 and @date2) or 
		     (e.PermissionTo between @date1 and @date2) or 
		     (@date1 between e.PermissionFrom and e.PermissionTo) or 
		     (@date2 between e.PermissionFrom  and e.PermissionTo))
		 
		--add the current requested TimePermission to the above count calculated only in the following cases:
		-- 1. if the [MaxOccurancePermCode] is empty -- >  the permission over/short type must be = policy over/short type
		-- 2. if the [MaxOccurancePermCode] is not empty -- > This codes [MaxOccurancePermCode] : must contain the permission no 
		
		----IF (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		IF ((LTRIM(RTRIM(@MaxOccurancePermCodes1)) = '') AND(@PermRqstOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxOccurancePermCodes1)) <> '') AND (LTRIM(RTRIM(@MaxOccurancePermCodes1)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
		set @count1=@count1+1
		
		
		--compare the Calculated Count above with Max Occurance allowed
		---------------------------------------------------------------
		-- In case the hiredate is between @date1 and @date2, 
		-- find the @ProratedMaxOccuranceNo - the part of MaxOccuranceNo - from his hiring date till @date2
		SET @HiringProratedHours = 0.00
		IF (@MaxOccuranceSince1=3 OR @MaxOccuranceSince1=7) AND (@HireDate BETWEEN @date1 AND @date2) AND (@HireDate<>@date1) AND @MaxOccIgnoreHireDate1 = 0
		BEGIN
			SELECT @HiringProratedHours=(datediff(mi,@date1,@HireDate))/60.00
		END

		IF @HiringProratedHours<>0				---OR @VacAffectDueDays<>0
			SET @proratedMaxOccuranceNo= (SELECT dbo.roundto((@MaxOccuranceNo1/(((datediff(mi,@date1,@date2)/60.00))*1.00))*((datediff(mi,@date1,@date2)/60.00)-@HiringProratedHours),1,1))  
		ELSE 
			SET 	@proratedMaxOccuranceNo=@MaxOccuranceNo1
		
		if @proratedMaxOccuranceNo<@count1 
		BEGIN

		IF CHARINDEX('008',@reason)<=0
		begin
			SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance1',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances 1' else '1 عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
			end
		end

		-- if the @todate falls within the next period, reset the ranges for @date1 and @date2 with the new period start and end dates
		-------------------------------
		while  (@todate not between @date1 and @date2 ) 
		begin

			set @date1=@date2
			if @enablehijri=1 and @year<1900	-- case of hijri
			begin
				set @date2=case
				when @MaxOccEveryUnit1=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery1,@date1)		-- month
				when @MaxOccEveryUnit1=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery1,@date1)		-- year
				when @MaxOccEveryUnit1=4 then dbo.h_dateadd('WW',@MaxOccuranceEvery1,@date1)      --weeks
				else dbo.h_dateadd('DD',@MaxOccuranceEvery1,@date1)END								-- day

			end
			else
			begin
				set @date2=CASE					-- case of gregorian
				when @MaxOccEveryUnit1=2 then dateadd(m,@MaxOccuranceEvery1,@date1)
				when @MaxOccEveryUnit1=3 then dateadd(yy,@MaxOccuranceEvery1,@date1)
				when @MaxOccEveryUnit1=4 then dateadd(WW,@MaxOccuranceEvery1,@date1)
				else dateadd(d,@MaxOccuranceEvery1,@date1)END
			end
			
		set @count1=0
		select @count1=sum(case when (DATEDIFF(s,CASE WHEN e.PermissionFrom < @date1 THEN @date1 ELSE e.PermissionFrom END,CASE WHEN e.PermissionTo > @date2 THEN @date2 ELSE e.PermissionTo END)) = 0 THEN 0 ELSE 1 END) 
		from EmpTimePermission e
		 LEFT JOIN TimePermission tp ON tp.PermissionNo = e.PermissionNo
         
		where (e.DocumentStatus=1 or e.DocumentStatus = case when @MaxOccuranceIncludeSubmittedPerm1 = 1 then 5 else 1 end)		and e.empid=@empid AND e.DocumentNo<>@DocNo  
		AND tp.OverShort = (CASE WHEN ltrim(rtrim(@MaxOccurancePermCodes1)) = '' THEN @PolicyOverShortType ELSE tp.OverShort END)
		--AND ((@PolicyOverShortType=4 AND tp.OverShort IN (1,2,3,4)) OR (@PolicyOverShortType=8 AND tp.OverShort IN (5,6,7,8)) OR (@PolicyOverShortType=tp.OverShort))
		AND LTRIM(RTRIM(@MaxOccurancePermCodes1)) LIKE (CASE WHEN LTRIM(RTRIM(@MaxOccurancePermCodes1)) = '' THEN '' ELSE '%,'+LTRIM(RTRIM(STR(tp.PermissionNo)))+',%' END)
		and ((e.PermissionFrom between @date1 and @date2) or 
		     (e.PermissionTo between @date1 and @date2) or 
		     (@date1 between e.PermissionFrom and e.PermissionTo) or 
		     (@date2 between e.PermissionFrom  and e.PermissionTo))
		

		----IF (@PermRqstOverShortType=@PolicyOverShortType OR (@PolicyOverShortType=4 AND (@PermRqstOverShortType=1 OR @PermRqstOverShortType=2 OR @PermRqstOverShortType=3 OR @PermRqstOverShortType=4)) OR (@PolicyOverShortType=8 AND (@PermRqstOverShortType=5 OR @PermRqstOverShortType=6 OR @PermRqstOverShortType=7 OR @PermRqstOverShortType=8))) OR @FixedHours = 1
		IF ((LTRIM(RTRIM(@MaxOccurancePermCodes1)) = '') AND(@PermRqstOverShortType = @PolicyOverShortType))  OR ((LTRIM(RTRIM(@MaxOccurancePermCodes1)) <> '') AND (LTRIM(RTRIM(@MaxOccurancePermCodes1)) LIKE '%,'+LTRIM(RTRIM(STR(@permissionNo)))+',%'))
			set @count1=@count1+1

		SET @proratedMaxOccuranceNo=@MaxOccuranceNo1
		if @proratedMaxOccuranceNo<@count1 
		BEGIN
        
		  IF CHARINDEX('009',@reason)<=0
		  begin
		    SELECT @reason = CASE WHEN @reason = '' THEN '' ELSE @reason + ' , ' END
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
					CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE 'عدم سماح : ' END ) 
						ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Warning',@lang))),
						CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE 'تحذير : ' END) end 
						+'009'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('PermissionRestriction','Occurance1',@latinlang))),(case when @latinlang='E' then 'The permission will exceed max no of occurances 1' else '1عدد مرات تكرار الإذن قد تعدى الحد المسموح به ' end))
						
						 SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		 END 
		end

		end
		-----------------------------
-- end of the else block (if condition : maxoccNo = 0)
			END
-- end of the occno block			
	END
	
--======================================================================================================================================================================================================	
-- ======= Range Restriction
--======================================================================================================================================================================================================	

IF @RequestFromValid=1 

BEGIN

  IF NOT EXISTS (SELECT * FROM EmpTimePermission WHERE EmpId = @empid AND DocumentNo = @DocNo AND EmpTimePermission.PermissionNo = @permissionno AND EmpTimePermission.PermissionFrom = @fromdate AND EmpTimePermission.PermissionTo = @todate AND EmpTimePermission.DocumentStatus IN (1,5,6)) OR (@DocNo = 0)
	 BEGIN
	DECLARE @getdate AS smalldatetime
	
	select @getdate=ToDate
	FROM dbo.[HitsGetDate]
	
	select @date1=@fromdate
	
	 SET @date2=CASE 
	 WHEN @RequestFromUnit=2 THEN dateadd(m,@RequestFromNo*-1,@date1) 
	 WHEN @RequestFromUnit=3 THEN dateadd(yy,@RequestFromNo*-1,@date1) 
	 ELSE dateadd(d,@RequestFromNo*-1,@date1)END
		IF @getdate > CONVERT(DATE,@date2)
		BEGIN
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('PermissionRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
			ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'PermissionRestriction',N'Warning',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
			+N'011'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'PermissionRestriction',N'ValidityRequestFrom',@latinlang))),(case when @latinlang=N'E' then N'Invalid to request a time permission exceeding ' else N' غير صالح لطلب إذن الوقت يتجاوز' end)) 
			+N' '+ltrim(rtrim(str(@RequestFromNo)))+ N' '
			+ case when @RequestFromUnit=2 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'4',@latinlang))),(case when @latinlang=N'E' then N'Months' else N'شهور' end))  
			when @RequestFromUnit=3 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'6',@latinlang))),(case when @latinlang=N'E' then N'Years' else N'سنين' end)) 
			else isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType','2',@latinlang))),(case when @latinlang=N'E' then N'Days' else N'أيام' end))  end 

			SET @PreventWarning = CASE WHEN @PolicyAction = 1 THEN 1 ELSE @PreventWarning END 
		END
	END
		
END
--======================================================================================================================================================================================================	
--======================================================================================================================================================================================================	
--======================================================================================================================================================================================================	

----------------------------------------------------------------------------

FETCH NEXT FROM OverShortCursor 
INTO @PolicyOverShortType,@PolicyAction,@PermissionPeriod,@MinHours,@MaxHours,@MaxTotal,@MaxTotalNo,@MaxTotalEvery,
	@MaxTotalEveryUnit,@MaxTotalSince,@MaxTotalPermCodes,@MaxOccurance,@MaxOccuranceNo,@MaxOccuranceEvery,@MaxOccEveryUnit,
	@MaxOccuranceSince,@MaxOccurancePermCodes,@MaxTotal1 ,@MaxTotalNo1,@MaxTotalEvery1,
	@MaxTotalEveryUnit1,@MaxTotalSince1,@MaxTotalPermCodes1,
	@MaxOccurance1 ,@MaxOccuranceNo1 ,@MaxOccuranceEvery1 ,@MaxOccEveryUnit1,
	@MaxOccuranceSince1,@MaxOccurancePermCodes1	,@RequestFromValid  , @RequestFromNo  , @RequestFromUnit    
	,@MaxTotalIncludeSubmittedPerm, @MaxTotalIncludeSubmittedPerm1
	,@MaxOccuranceIncludeSubmittedPerm, @MaxOccuranceIncludeSubmittedPerm1,@MaxTotalIgnoreHireDate,@MaxOccIgnoreHireDate,@MaxTotalIgnoreHireDate1,@MaxOccIgnoreHireDate1
	,@dayoff



	end
close OverShortCursor 
DEALLOCATE OverShortCursor
----------------------------------------------------------------------------------------end of looping through the perm. policies
END 	

-----------------------------------------------------------------








SET @reason = CASE WHEN @reason = '' THEN '001'
                  ELSE ltrim(rtrim(str(@PreventWarning))) + rtrim(ltrim(@reason)) + '.' END

RETURN @reason
END

GO

