
CREATE FUNCTION [dbo].[ReplaceDatesInSavedFilter] (
    
    @LogonName NVARCHAR(80), @Lang Nvarchar(1) ,@filterStr NVARCHAR(MAX) , @EnglishLike int 
)
RETURNS NVARCHAR(MAX)
AS

--declare @LogonName NVARCHAR(80) = '1',@filterStr NVARCHAR(MAX)=
--'AND ( EMPASSIGNMENT.HIREDATE Between ''@SFPayrollYearStartDate'' and ''@SFPayrollYearEndDate'')',@Lang Nvarchar(1) = 'E' ,@EnglishLike int =1

BEGIN

IF ISNULL(@filterStr,'')<>'' 
BEGIN
	IF @EnglishLike = 1
	BEGIN
		SET @filterStr = REPLACE(@filterStr, '@SFToday', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFToday', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFYesterday', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFYesterday', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarMonthStartDate',[dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarMonthStartDate', @Lang) );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarYearEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollMonthStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollMonthStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollYearEndDate', @Lang));
		---previous
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousMonthStartDate',[dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarPreviousMonthStartDate', @Lang) );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarPreviousMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarPreviousYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFCalendarPreviousYearEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollPreviousMonthStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollPreviousMonthStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollPreviousMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollPreviousMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollPreviousYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollPreviousYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@SFPayrollPreviousYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@SFPayrollPreviousYearEndDate', @Lang));

	END
	Else If @EnglishLike = 2 
	Begin
		SET @filterStr = REPLACE(@filterStr, '@SFToday', FORMAT(GETDATE(), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFYesterday', FORMAT(DATEADD(day, -1, GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarMonthEndDate', FORMAT(EOMONTH(GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 1, 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 12, 31), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollMonthStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodStart'')')
 		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollMonthEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodEnd'')')
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollYearStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodYearStart'')')
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollYearEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodYearEnd'')')
		---previous
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(DATEADD(MONTH, -1, GETDATE())), MONTH(DATEADD(MONTH, -1, GETDATE())), 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousMonthEndDate', FORMAT(EOMONTH(DATEADD(MONTH, -1, GETDATE())), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 1, 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 12, 31), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousMonthStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodStart'')')
 		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousMonthEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodEnd'')')
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousYearStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodYearStart'')')
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousYearEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodYearEnd'')')

	End 
	ELSE
	BEGIN
		SET @filterStr = REPLACE(@filterStr, '@SFToday', FORMAT(GETDATE(), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFYesterday', FORMAT(DATEADD(day, -1, GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarMonthEndDate', FORMAT(EOMONTH(GETDATE()), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 1, 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 12, 31), 'yyyyMMdd')) ;
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollMonthStartDate''', 'PeriodStart');
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollMonthEndDate''', 'PeriodEnd');
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollYearStartDate''', 'PeriodYearStart');
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollYearEndDate''', 'PeriodYearEnd');
		---previous
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(DATEADD(MONTH, -1, GETDATE())), MONTH(DATEADD(MONTH, -1, GETDATE())), 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousMonthEndDate', FORMAT(EOMONTH(DATEADD(MONTH, -1, GETDATE())), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 1, 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@SFCalendarPreviousYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 12, 31), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousMonthStartDate''', 'PrevPeriodStart');
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousMonthEndDate''', 'PrevPeriodEnd');
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousYearStartDate''', 'PrevPeriodYearStart');
		SET @filterStr = REPLACE(@filterStr, '''@SFPayrollPreviousYearEndDate''', 'PrevPeriodYearEnd');
	END
	END
    return @filterStr
END

GO

