CREATE   FUNCTION [dbo].[TimeSysInAccDistance]
( @Long FLOAT,@Lat FLOAT 	)
RETURNS SMALLINT 
AS
BEGIN
	
DECLARE @point1Geo AS geography, @timeSystem AS SMALLINT

--select @point1Geo = geography::STPointFromText ('POINT (' + CAST (@Long AS VARCHAR (20)) + ' ' +CAST (@Lat AS VARCHAR (20)) + ')', 4326) 
SELECT @point1Geo = geography::STPointFromText('POINT (' + STR(@Long,10,6) + ' ' + STR(@Lat,10,6) + ')', 4326)

--SELECT @timeSystem= timesystem  FROM TimeSystems WHERE @point1Geo.STDistance(Locationgeo) <= geoAcceptedDistc
SELECT TOP 1 @timeSystem = TimeSystem 
FROM TimeSystems 
WHERE Locationgeo IS NOT NULL 
AND Locationgeo.STBuffer(geoAcceptedDistc).STIntersects(@point1Geo)=1

RETURN @timeSystem 
	 

END

GO

