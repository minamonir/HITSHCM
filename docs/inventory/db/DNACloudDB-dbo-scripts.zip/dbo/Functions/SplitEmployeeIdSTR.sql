
create FUNCTION [dbo].[SplitEmployeeIdSTR]
(	
	@employeeid as nvarchar(50)
)

RETURNS @Temp2 TABLE (EmployeeIdStr NVARCHAR(50),EmployeeIdNum NVARCHAR(50))
AS

begin

 declare @patern as nvarchar(max)=N'%[ء-يa-z .,;:\-@\@.''"?:/,#$@+*%&();_-]%'

 INSERT INTO @Temp2
SELECT case when PATINDEX(@patern,@employeeid)>0 then substring(@employeeid,0,len(@employeeid)-PATINDEX(@patern,REVERSE(@employeeid))+2) else '' end as STRPart1,
case when PATINDEX(@patern,@employeeid)>0 then substring(@employeeid,len(@employeeid)-PATINDEX(@patern,REVERSE(@employeeid))+2 ,len(@employeeid)) else @employeeid end as STRPart2

RETURN

end

GO

