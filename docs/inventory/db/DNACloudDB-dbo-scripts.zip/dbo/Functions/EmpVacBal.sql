


CREATE FUNCTION [dbo].[EmpVacBal] (@empid int, @date2 smalldatetime,@VacType as int) 
RETURNS numeric(18,3)
AS
--declare @empid int=1, @date2 smalldatetime='2017-06-30',@VacType as int=1

BEGIN
  Declare @Due numeric(18,3),@Taken as numeric (18,3) , @PrevBal as numeric(18,3), @Balance as numeric(18,3),@date1 as smalldatetime 

 declare @DecimalScale as smallint
 select @DecimalScale=DecimalScale from sysparam

 select @date1=dbo.V_YearStart(EmpAssignment.PayrollGroup, 0, 0) 
  From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
  Where EmpAssignment.EmpId=@empid
  -- select @date1

  Select @Due=dbo.EmpVacDue(@empid,@date1,@date2,@VacType)
,@PrevBal=case when @VacType=1 then EmpAssignment.VacPrvBal1 when @VacType=2 then EmpAssignment.VacPrvBal2 else EmpAssignment.VacPrvBal3 end
,@Taken=dbo.EmpVacTaken(@empid,@date1,@date2,@VacType)
  From EmpAssignment
  Where EmpAssignment.EmpId=@empid


--set @Balance=round(@PrevBal,3)+round(@Due,3)-round(@Taken,3)
--set @Balance=round(@PrevBal,2)+round(@Due,2)-round(@Taken,2)
set @Balance=round(@PrevBal,@DecimalScale)+round(@Due,@DecimalScale)-round(@Taken,@DecimalScale)

  return @Balance
--select @Balance as Bal,@PrevBal as prevbal,@Due as due,@Taken as taken
END

GO

