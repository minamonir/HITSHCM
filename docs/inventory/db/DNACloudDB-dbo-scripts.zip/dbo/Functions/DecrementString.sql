Create FUNCTION [dbo].[DecrementString](@EmployeeId NVARCHAR(50))
RETURNS NVARCHAR(50)
AS
--declare @EmployeeId NVARCHAR(50)=N'0'
BEGIN
     
              
              DECLARE @strNumeric NVARCHAR(400) = @EmployeeId
              DECLARE @strNew NVARCHAR(400) = @EmployeeId
              DECLARE @strNumericlen AS INT -- length of the numeric value ,, with left zeros if exist
			  DECLARE @strNumericlenInteger INT -- length of the numeric value without left zeros
			  
              DECLARE @expresAhpha  NVARCHAR(50) = '%[a-z .,;:\-@\@.''"?:/,+&();_-]%'
              

              DECLARE @EmployeeIdLength INT  -- maximum length allowed to employeeid
              SELECT @EmployeeIdLength = EmployeeidLength FROM SysParam
              
              --------- gets numeric value out of alphanumeric string
                     WHILE PATINDEX( @expresAhpha, @strNumeric ) > 0 
                     BEGIN
                                  SET @strNumeric =REPLACE( @strNumeric, SUBSTRING( @strNumeric, PATINDEX( @expresAhpha, @strNumeric ), 1 ),'')
                     END---
                     --SELECT @strNumeric 
                     SET @strNumericlen = LEN(@strNumeric)
                     SET @strNumericlenInteger = LEN(cast (@strNumeric AS INT))
                     --------------------------------
                     --------- if numeric is full (all is 9) return back to 0 from the beginning ,,, if not full -> add 1
					 --select @strNumericlen - len(replace(@strNumeric, '9', '')),@strNumeric,@strNumericlen , LEN(@EmployeeId)  , @EmployeeIdLength
                     IF(@strNumericlen - len(replace(@strNumeric, '9', '')) = @strNumericlen AND LEN(@EmployeeId)  =  @EmployeeIdLength )  
                                  BEGIN
                                         set @strNumeric = REPLACE(@strNumeric , '9' , '0')
                                         --SELECT @strNumeric
                                  END
                     ELSE
                                  BEGIN
								   -- select @strNumeric,@strNumericlen
								   if  cast (@strNumeric AS INT) - 1>=0
								   begin
                                         SELECT @strNumeric  = cast (@strNumeric AS INT) - 1
                                         IF (LEN(@strNumeric) < @strNumericlen)--@strNumericlenInteger)
										 begin
										--select 1
                                                              SELECT @strNumeric =REPLICATE('0',@strNumericlen -LEN(@strNumeric))+@strNumeric      
										end
                                  END    
								  end
                     --------------------------------

                     -- Replace the old numeric value with the new value in the alphanumeric string

                     declare @i INT , @AlphaOrNumeric CHAR
                     select @i = 0

                     while @i < len(@strNew) 
                     BEGIN
                                  select @i = @i + 1
                                  SELECT @AlphaOrNumeric = substring(@strNew, @i, 1)
                                  IF(ISNUMERIC(@AlphaOrNumeric) = 1) and @AlphaOrNumeric<>'-'
                                  BEGIN
                                                select @strNew = STUFF(@strNew, @i, 1, SUBSTRING(@strNumeric ,1,1))
                                                select @strNumeric = STUFF(@strNumeric, 1, 1, '')
                                  END
                     END
                     --If there is a value incremented like 999 --> 1000 , add the last integer to the string
                     IF @strNumeric IS NOT NULL
                     BEGIN
                                  SET @strNew = @strNew + @strNumeric
                     END
                     return @strNew  
					 
              
       RETURN ''
END

GO

