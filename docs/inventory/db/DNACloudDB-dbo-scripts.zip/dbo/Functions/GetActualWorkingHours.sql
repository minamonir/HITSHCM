
CREATE FUNCTION [dbo].[GetActualWorkingHours] (@Empid INT , @FromDate smalldatetime, @ToDate smalldatetime,@UsePermission BIT , @UseVacation BIT ,
 @DayHoursType SMALLINT , @DayHours numeric(18,3) , @OverrideVacation SMALLINT , @GetPermissionWhenNoReadings SMALLINT)
 RETURNS numeric(18,3)
AS
BEGIN

-- @UsePermission               : calculate the permission hours on working hours or not
-- @UseVacation                 : calculate the vacation Hours on working hours or not
-- @DayHoursType                : calculate the DayHours from PayrollGroup Setup (0) ,Shift Hours (1) , Fixed from @DayHourFactor (2)
-- @DayHourFactor               : the fixed Day Hours ( used when @DayHourType=2)
-- @OverrideVacation            : determines whether calculate the working hours from readings  (1)  or calculate the vacation Hours (0)
-- @GetPermissionWhenNoReadings : calculate the Permission hours when there is no readings (1) or not (0)


 -- if this @IgnoreIncompeteRecordsInCalc=1,it will consider the incomplete records as complete working day
 -- this case for CICapital as the incomplete record will be deducted from another sql job there and they don't need to be deducted again from the vacation due 
  --as the required hours will consider this day(incomplete record) so we will add this day hours( shift hours or any hours according to the @DayHourType paramater ) to the working hours 
  --by this modification the incomplete record will not affect in getting short time
  DECLARE @IgnoreIncompeteRecordsInCalc AS SMALLINT=0
  SET @IgnoreIncompeteRecordsInCalc=0


DECLARE @PayrollGroupDaysHour AS numeric(18,3)

----- Calculate the Day Hours --------
DECLARE @ActualDayHours AS numeric(18,3), @daydate AS SMALLDATETIME
SELECT @ActualDayHours= (CASE WHEN @DayHoursType=0 THEN PayrollGroup.DayHours WHEN @DayHoursType=1 THEN 1 WHEN @DayHoursType=3 THEN TimeRules.HWorkingPerDay ELSE @DayHours END ),
@PayrollGroupDaysHour=case when @DayHoursType <> 1 then PayrollGroup.DayHours else 0 end
FROM EmpAssignment 
LEFT JOIN  PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
LEFT JOIN dbo.TimeRules ON TimeRules.TimeRule = EmpAssignment.TimeRule
WHERE EmpAssignment.EmpId=@Empid

SET @daydate=@FromDate

DECLARE @Date TABLE ([Date]  DATETIME)--,h_Date  NCHAR(12)

WHILE @ToDate >= @daydate
    BEGIN
        INSERT INTO @Date([Date])
        VALUES(@daydate)
        SET @daydate = DATEADD(d, 1, @daydate)
    END
    
   --SELECT * FROM @Date
---- 
DECLARE  @ActualWorkingHours AS numeric(18,3)


------ Calculate the Vacations Hours ------
  	   declare  @TempDays TABLE(EntryDate DATETIME, VacDays numeric(18,3),VacHours numeric(18,3),PshortHours numeric(18,3),PoverHours numeric(18,3),WHours numeric(18,3),DayHour NUMERIC(18,3))
      
       INSERT INTO @TempDays(EntryDate , VacHours ,PshortHours ,PoverHours,WHours ,DayHour)
		SELECT d.[Date],
		------ Calculate Vacations Hours ------
				ISNULL((Case when @UseVacation =1 then max(isnull(dbo.vacTotalTaken(@empid, case when d.[Date] <@FromDate then
		@FromDate else d.[Date]  end,case when d.[Date] >@ToDate then @ToDate else d.[Date]  end, 0),0)) ELSE 0 END ),0)+ Case when @UseVacation =1 THEN ISNULL(max(CASE WHEN dbo.isholiday(@Empid,d.date,1) IN (1,3) THEN 1 ELSE 0 END),0) ELSE 0 END , 


		--*(CASE WHEN @DayHoursType<>1 THEN @ActualDayHours ELSE (CASE WHEN EmpShift.EmpId IS NULL THEN @PayrollGroupDaysHour ELSE 
		--(datediff(s,convert(datetime,convert(char(10),shiftdate,120)+' '+FromTime,120), 
		--case when convert(datetime,convert(char(10),shiftdate,120)+' '+FromTime,120)>convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime,120) THEN convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime,120)+1 ELSE convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime,120)end)
		--+ case when FromTime1='00:00' or ltrim(FromTime1)='' or FromTime1='  :  ' or TOTime1='00:00' or ltrim(TOTime1)='' or TOTime1='  :  ' then 0 else isnull(datediff(s,convert(datetime,convert(char(10),shiftdate,120)+' '+FromTime1,120) ,CASE when convert(datetime,convert(char(10),shiftdate,120)+' '+FromTime1,120)  > convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime1,120)THEN  convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime1,120)+1 ELSE  convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime1,120)  end),0)end
		--)/3600.0 END ) END )
		------ Calculate permissions Hours ------
		isnull(SUM(EmpShiftInOut.PShortSeconds/3600.0),0),isnull(SUM(EmpShiftInOut.POverSeconds /3600.0),0),
		
		------ Calculate Working Hours ------
		isnull(SUM(EmpShiftInOut.WorkSeconds/3600.0),0),
		
		------calculate day hours ------------
		ISNULL((CASE WHEN @DayHoursType<>1 THEN @ActualDayHours ELSE (CASE WHEN EmpShift.EmpId IS NULL THEN @PayrollGroupDaysHour ELSE 
		(datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120), 
		case when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120)>convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120) THEN convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)+1 ELSE convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)end)
		+ case when FromTime1='00:00' or ltrim(FromTime1)='' or FromTime1='  :  ' or TOTime1='00:00' or ltrim(TOTime1)='' or TOTime1='  :  ' then 0 else isnull(datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120) ,CASE when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120)  > convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)THEN  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)+1 ELSE  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)  end),0)end
		)/3600.0 END ) END ),0)
		FROM @Date d
	    LEFT JOIN  EmpShiftInOut ON EmpShiftInOut.EntryDate= d.[Date] AND EmpShiftInOut.EmpId=@Empid
		LEFT JOIN EmpShift ON EmpShift.EmpId = EmpShiftInOut.EmpId AND EmpShift.ShiftDate=EmpShiftInOut.EntryDate
		LEFT JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo
		--WHERE EmpShiftInOut.EmpId=@Empid AND EmpShiftInOut.EntryDate BETWEEN @FromDate AND @ToDate
		GROUP BY d.[Date],EmpShift.EmpId,shiftdate,FromTime,FromTime1,TOTime,TOTime1 --EmpShiftInOut.EntryDate

UPDATE @TempDays
SET 
VacDays=ISNULL(VacHours,0),
VacHours = (ISNULL(VacHours,0)*ISNULL(DayHour,0))
,WHours=CASE WHEN @IgnoreIncompeteRecordsInCalc=1 AND dbo.EmpVacOrNot(@Empid,EntryDate)=2 THEN ISNULL(DayHour,0) ELSE WHours END 

--SELECT @ActualWorkingHours=SUM((CASE WHEN @UsePermission=1 THEN (CASE WHEN @GetPermissionWhenNoReadings=1 AND WHours=0 THEN (isnull(PshortHours,0)+isnull(PoverHours,0)) WHEN WHours<>0 THEN isnull(PshortHours,0) ELSE 0 END) ELSE 0 END)
--                           +WHours+(CASE WHEN @UseVacation=1 THEN (CASE WHEN ((@OverrideVacation=1 AND WHours<>0 AND VacHours>=DayHour) OR (WHours=0 OR VacHours<DayHour)) THEN isnull(VacHours,0) ELSE 0  END) ELSE 0 END ))

-----------------------------new modifiacation for CICapital   2018/05/16 by samah-------------------------------------
SELECT @ActualWorkingHours=SUM((CASE WHEN @UsePermission=1 THEN (CASE WHEN @GetPermissionWhenNoReadings=1 AND WHours=0 THEN (isnull(PshortHours,0)+isnull(PoverHours,0)) WHEN WHours<>0 THEN isnull(PshortHours,0) ELSE 0 END) ELSE 0 END)    
+ CASE WHEN @OverrideVacation=1 AND WHours<>0 and VacHours<>0 AND (vacdays >=1 or vacdays<=0) THEN 0 ELSE WHours END +		
			   (CASE WHEN @UseVacation=1 THEN (CASE WHEN ((@OverrideVacation=1 AND WHours<>0 and VacHours<>0 AND (vacdays >=1 or vacdays<=0)  ) OR (WHours=0) OR (WHours<>0 and VacHours<>0 AND (vacdays >=0 and vacdays<1)  ) ) THEN isnull(VacHours,0) ELSE 0  END) ELSE 0 END ))
   -------------------------------------------------

--SELECT @ActualWorkingHours=SUM((CASE WHEN @GetPermissionWhenNoReadings=1 AND WHours=0 THEN (isnull(PshortHours,0)-isnull(PoverHours,0)) WHEN @UsePermission=1 THEN (isnull(PshortHours,0)-isnull(PoverHours,0)) ELSE 0 END)
--                           +WHours+(CASE WHEN @UseVacation=1 THEN (CASE WHEN ((@OverrideVacation=1 AND WHours<>0) OR WHours=0) THEN isnull(VacHours,0) ELSE 0  END) ELSE 0 END ))




FROM @TempDays 
RETURN isnull(@ActualWorkingHours ,0) 
END

GO

