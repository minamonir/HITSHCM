
CREATE FUNCTION [dbo].[GetUserFieldValue] (@Empid INT, @DocumentNo INT, @FormNo SMALLINT, @FieldNo SMALLINT) RETURNS NVARCHAR(120)
AS

BEGIN
    DECLARE @ReturnTxt AS NVARCHAR(120)
	SELECT @ReturnTxt=
		(CASE   WHEN UserFieldsNames.FieldType=1 THEN UserFieldsValues.FieldValue 
				WHEN UserFieldsNames.FieldType=3 THEN Convert(nvarchar,round(UserFieldsValues.FieldValue,DecimalScale))
				WHEN UserFieldsNames.FieldType=4 THEN 
				CASE	WHEN sysparam.DateFormat=0 --yyyy/mm/dd
      					THEN substring(str(UserFieldsValues.FieldValue,8),1,4)+N'/'+substring(str(UserFieldsValues.FieldValue,8),5,2)+N'/'+substring(str(UserFieldsValues.FieldValue,8),7,2) 
						WHEN sysparam.DateFormat=1 --dd/mm/yyyy
						THEN substring(STR(UserFieldsValues.FieldValue,8),7,2)+N'/'+substring(str(UserFieldsValues.FieldValue,8),5,2)+N'/'+substring(str(UserFieldsValues.FieldValue,8),1,4)
						ELSE /*sysparam.DateFormat=2 mm/dd/yyyy*/
							 substring(str(UserFieldsValues.FieldValue,8),5,2)+N'/'+substring(str(UserFieldsValues.FieldValue,8),7,2)+N'/'+substring(str(UserFieldsValues.FieldValue,8),1,4)
      			END 
              	ELSE UserFieldsItems.FieldItemValue END )  
	FROM UserFieldsValues 
	LEFT JOIN UserFieldsItems ON UserFieldsValues.FormNo = UserFieldsItems.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsItems.FieldNo 
	And UserFieldsValues.FieldValue = (cast(UserFieldsItems.FieldItemNo as nchar(254))) 
	INNER JOIN UserFieldsNames ON UserFieldsValues.FormNo = UserFieldsNames.FormNo 
	AND UserFieldsValues.FieldNo = UserFieldsNames.FieldNo --and UserFieldsNames.FormNo = 1
	CROSS JOIN Sysparam
	
    WHERE UserFieldsValues.ProfileId = @EmpId
    AND UserFieldsValues.DocumentNo = @DocumentNo
    AND UserFieldsValues.FormNo = @FormNo
    AND UserFieldsValues.FieldNo = @FieldNo

    RETURN ISNULL(@ReturnTxt, N'')
END

GO

