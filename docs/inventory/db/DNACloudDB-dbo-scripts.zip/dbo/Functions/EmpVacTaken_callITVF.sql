create   FUNCTION [dbo].[EmpVacTaken_callITVF]
(
    @empid INT,
    @date1 SMALLDATETIME,
    @date2 SMALLDATETIME,
    @VacType INT
)
RETURNS NUMERIC(18,3)
AS
BEGIN
    DECLARE @Taken NUMERIC(18,3);

    -- Do not calculate before employee hire date
    SELECT
        @date1 = CASE
                    WHEN HireDate < @date1 THEN @date1
                    ELSE HireDate
                 END
    FROM EmpAssignment
    WHERE EmpId = @empid;

    IF @date1 > @date2
    BEGIN
        SELECT
            @Taken = -ISNULL(days, 0)
        FROM dbo.itvf_GetVacTaken
        (
            @empid,
            DATEADD(DAY, 1, @date2),
            DATEADD(DAY, -1, @date1),
            @VacType
        );
    END
    ELSE
    BEGIN
        SELECT
            @Taken = ISNULL(days, 0)
        FROM dbo.itvf_GetVacTaken
        (
            @empid,
            @date1,
            @date2,
            @VacType
        );
    END

    RETURN @Taken;
END

GO

