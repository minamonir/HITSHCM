CREATE        FUNCTION [dbo].[GetVacationDates] (@mpid int,   @periodfrom NVARCHAR(max) ,@periodto NVARCHAR(max), @VacCode  NVARCHAR(max),@type int)  
RETURNS NVARCHAR(max) AS  
begin


declare @DatesStr NVARCHAR(max)=''
DECLARE @periodst NVARCHAR(max) ='', @periodEnd NVARCHAR(max)=''
	--SELECT @periodfrom=  CONVERT(nchar(12),convert(smalldatetime,@periodfrom,120),120) , @periodto= CONVERT(nchar(10),convert(smalldatetime,@periodto,103),120)	
--select @periodfrom='2018-09-01', @periodto='2018-09-30'
	
	 select TOP 1   @periodst=@periodst + CASE WHEN @periodst <>'' THEN  CHAR(13)+CHAR(10) ELSE '' END +  CASE WHEN convert(nchar(10),@periodfrom,120)< convert(nchar(10), empvacat.fromdate,120)
	  THEN convert(nchar(10), empvacat.fromdate,120) 
 ELSE convert(nchar(12),@periodfrom,120) END 

			 , @periodEnd= 
			 @periodEnd  + CASE WHEN @periodEnd <>'' THEN  CHAR(13)+CHAR(10) ELSE '' END + CASE WHEN convert(nchar(10),@periodto,120)<convert(nchar(10), empvacat.todate,120)
			 THEN convert(nchar(10),@periodto,120) ELSE convert(nchar(10), empvacat.todate,120) END 
			
			from empvacat 
			INNER JOIN EmpAssignment ON EmpAssignment.EmpId = empvacat.EmpId and empvacat.vaccode=@VacCode
			 where   EmpAssignment.EmpId =@mpid AND VacStatus=1 
			 and			 ( (convert(nchar(10), empvacat.fromdate,120)  between convert(nchar(10),@periodfrom,120) and   convert(nchar(10),@periodto,120))
			  or (convert(nchar(10), empvacat.todate,120) between  convert(nchar(10),@periodfrom,120) and  convert(nchar(10),@periodto,120)) 
			  or ( convert(nchar(10),@periodfrom,120)  between convert(nchar(10), empvacat.fromdate,120) and convert(nchar(10), empvacat.todate,120))
			  or (convert(nchar(10),@periodto,120) between convert(nchar(10), empvacat.fromdate,120) and convert(nchar(10), empvacat.todate,120)))
		ORDER BY empvacat.FromDate DESC 
--SELECT @periodfrom,@periodto, SUBSTRING (@periodfrom,CHARINDEX( CHAR(13)+CHAR(10),@periodfrom),LEN(@periodfrom)), SUBSTRING (@periodto,CHARINDEX( CHAR(13)+CHAR(10),@periodto),LEN(@periodto))

if @type=1 set @DatesStr= CASE WHEN @periodst = '' THEN @periodfrom ELSE @periodst END--SUBSTRING (ltrim(rtrim(@periodfrom)),CHARINDEX( CHAR(13)+CHAR(10),ltrim(rtrim(@periodfrom))),LEN(@periodfrom))
 else set 	@DatesStr= CASE WHEN @periodEnd = '' THEN @periodto ELSE @periodEnd END--SUBSTRING (@periodto,CHARINDEX( CHAR(13)+CHAR(10),@periodto),LEN(@periodto))	
RETURN LTRIM(RTRIM( @DatesStr))
END

GO

