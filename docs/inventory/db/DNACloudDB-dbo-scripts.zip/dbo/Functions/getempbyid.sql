create function getempbyid(@id int)
returns table
as return 
( select * from EmpStatusDtl p where  p.EmpId=@id
)

GO

