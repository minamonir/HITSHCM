
CREATE FUNCTION [dbo].[GetIntersectionPeriod]( @Empid INT,@Entrydate DATETIME,@ShiftNo smallint,@Usevaction BIT, @UsePermission BIT,@FromTime NVarCHAR(5),@ToTime NvarCHAR(5))

RETURNS int
AS
BEGIN 


-- OverShort    OverShortName
-- 1 Over [Early In]                         
-- 2 Over [Late Out]                         
-- 3 Over [Working Out of working hours] 
-- 4    Over [Total]    
-- 5 Short [Late In]                         
-- 6 Short [Early Out]                       
-- 7 Short [Exit during working hours]       
-- 8    Short [Total]
     

declare @OverValue numeric(18,3),  @Hours as numeric(18,3),@VacHoursTemp AS numeric(18,3),@TimeRulePaycode AS SMALLINT,
@OverShortTotalExist AS SMALLINT=0,@VacHours AS numeric(18,3),@ShiftHours NUMERIC(18,3)

DECLARE @shortValuetemp  as numeric(18,3), @ShiftOut1 as DATETIME, @ShiftOut2 as DATETIME

select top 1 
    @ShiftOut1=MAX(CASE WHEN ShiftTimeNo=1 THEN shiftout ELSE NULL end),
    @ShiftOut2=ISNULL(MAX(CASE WHEN ShiftTimeNo=2 THEN shiftout ELSE NULL end),'')
  from EmpShiftinout 
  where  empid=@empid AND EntryDate =@entrydate

   

DECLARE @Fromdate AS datetime ,@Todate AS datetime,@Fromdate1 AS datetime ,@Todate1 AS datetime

SELECT @Fromdate = CONVERT(datetime, CONVERT( NVARCHAR(10) , @entrydate ,120) + ' '+ @Fromtime, 120)
SELECT @Todate =   CONVERT(datetime, CONVERT( NVARCHAR(10) , @entrydate ,120) + ' '+ @ToTime, 120)


IF @Fromdate>@Todate
begin
SELECT @Fromdate1=@EntryDate
SELECT @Todate1= CONVERT(datetime, CONVERT( NVARCHAR(10) , @entrydate ,120) + ' '+ @ToTime, 120)
SELECT @Todate = CONVERT(DATETIME, @EntryDate + ' '+ '23:59:59:999', 120) 

END

--SELECT @Fromdate AS '@Fromdate',@Todate AS '@Todate',@Fromdate1 AS '@Fromdate1',@Todate1 AS '@Todate1'
   DECLARE @shiftType AS SMALLINT,@CoreCheck AS SMALLINT=0,@FILO AS SMALLINT

   SELECT @FILO=FirstInLastOut FROM dbo.TimeRules WHERE TimeRule=dbo.GetOldValue(@empid,28,@Entrydate+1,NULL)
   IF @shiftno<=0
   BEGIN
	   if @shiftno<0
	   BEGIN
		   SELECT @CoreCheck=1
	   END
       
	   SELECT @shiftno =EmpShift.shiftno ,@shiftType =shifttype FROM dbo.EmpShift LEFT JOIN dbo.TimeShifts ON  dbo.EmpShift.shiftno=EmpShift.shiftno WHERE empid=@Empid AND shiftdate=@Entrydate
   END
   ELSE
   BEGIN
		SELECT @shiftType =shifttype FROM dbo.EmpShift LEFT JOIN dbo.TimeShifts ON  dbo.EmpShift.shiftno=EmpShift.shiftno WHERE empid=@Empid AND shiftdate=@Entrydate
   END
   
   -----------
      declare  @EmpShiftInOutTemp TABLE(empid INT,
     [EntryDate] [datetime] ,
     [EntryNo] [SMALLINT] ,
	 TimeIn SMALLDATETIME,
	 Timeout SMALLDATETIME,
	 Shiftin SMALLDATETIME,
	 ShiftOut SMALLDATETIME)

	-- SELECT @CoreCheck, @shiftType, @FILO

   IF @CoreCheck=1 AND @shiftType=6 AND @FILO=1
   BEGIN
       INSERT INTO @EmpShiftInOutTemp SELECT empid,EntryDate ,EntryNo ,TimeIn ,Timeout 
	  ,CASE WHEN @Fromdate < Shiftin THEN @Fromdate ELSE shiftin END
	 , CASE WHEN ISNULL(@Todate1,@Todate) > ShiftOut THEN ISNULL(@Todate1,@Todate) ELSE ShiftOut END  FROM empshiftinout  where  empid=@empid AND EntryDate =@entrydate

	  select    @ShiftOut1=MAX(shiftout),@ShiftOut2=NULL FROM @EmpShiftInOutTemp
      
   END
   ELSE
   BEGIN
     INSERT INTO @EmpShiftInOutTemp SELECT empid,EntryDate ,EntryNo ,TimeIn ,Timeout ,Shiftin , ShiftOut 
	 FROM empshiftinout  where  empid=@empid AND EntryDate =@entrydate
   END

 -- SELECT '@EmpShiftInOutTemp',* FROM @EmpShiftInOutTemp

  SET @VacHours=0
--------------------------------------------
IF @Usevaction=1 
BEGIN
           SELECT @VacHours=ISNULL(dbo.vactakendays(EmpVacat.empid,EmpShift.ShiftDate,ShiftDate,EmpVacat.VacCode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo),0)
           --     ,@ShiftHours =(datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120), 
           --case when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime,120)>convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120) THEN convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)+1 ELSE convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime,120)end)
           --+ case when FromTime1='00:00' or ltrim(FromTime1)='' or FromTime1='  :  ' or TOTime1='00:00' or ltrim(TOTime1)='' or TOTime1='  :  ' then 0 else isnull(datediff(s,convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120) ,CASE when convert(datetime,convert(nchar(10),shiftdate,120)+' '+FromTime1,120)  > convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)THEN  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)+1 ELSE  convert(datetime,convert(nchar(10),shiftdate,120)+' '+ToTime1,120)  end),0)end
           --)/3600.0 
		     ,@ShiftHours =(
			 ISNULL(DATEDIFF(s,[dbo].[ShiftStartEnd] (empshift.empid  ,shiftdate,1,1  ),[dbo].[ShiftStartEnd] (empshift.empid  ,shiftdate,2,1  )),0)
			 + ISNULL(DATEDIFF(s,[dbo].[ShiftStartEnd] (empshift.empid  ,shiftdate,1,2  ),[dbo].[ShiftStartEnd] (empshift.empid  ,shiftdate,2,2  )),0)
			 )/3600.0 
     FROM EmpVacat 
           LEFT JOIN Vacation ON  Vacation.vaccode = EmpVacat.VacCode
           inner JOIN EmpShift ON EmpShift.EmpId = EmpVacat.EmpId AND EmpShift.shiftdate = @Entrydate
           
           AND (
                (EmpShift.ShiftDate between EmpVacat.FromDate AND  EmpVacat.todate AND (Vacation.DayFactor<1 and Vacation.DayFactor >0 ) )
           or
                (EmpShift.ShiftDate = EmpVacat.FromDate AND EmpVacat.PartDayFrom=1 )
          
           OR  (EmpShift.ShiftDate = EmpVacat.todate AND EmpVacat.PartDayTo=1  )
           
           )
           
           LEFT JOIN TimeShifts ON EmpShift.ShiftNo = TimeShifts.ShiftNo
           
           WHERE Vacation.UseDayFactor=1 AND  EmpVacat.empid=@EmpId  
           AND EmpShift.shiftdate = @Entrydate
           AND @entrydate BETWEEN FromDate AND todate AND EmpVacat.VacStatus=1     
           
           
     IF @VacHours>=1 or @VacHours<=0 SET @VacHours=0.0
     SELECT  @VacHours=@VacHours*@ShiftHours

           
   --  SELECT @VacHours AS '@VacHours'
     --SELECT @VacHours=3
--------------------------------------------
SET @VacHoursTemp=ISNULL(@VacHours,0)


SET @VacHours=@VacHours*3600.00

end 


select @OverValue=0
   

 
    SELECT @OverShortTotalExist= COUNT(*) FROM TimeShiftTimes WHERE ShiftNo=@ShiftNo and OverShort=8

     



--SELECT @Fromdate,@Todate,@Fromdate1,@Todate1


--parameter to decide the vacation with which side
--to be used when consideraing the vacation with the short part
--possible values : 1.in , 2.out , 3.during
DECLARE @VacHoursType AS SMALLINT
SET @VacHoursType = 0

------------------------------------------------------------------------------------------

  
  --SELECT @ShiftOut1 AS '@ShiftOut1',@ShiftOut2 AS '@ShiftOut2'
---------------------------------------------------------
   declare  @OverShortPermTimes TABLE(
     [EntryDate] [datetime] ,
     [EntryNo] [SMALLINT] ,
     [Documentno] [INT] IDENTITY(1,1) ,
     [OverShort] [SMALLINT] ,
     [ShortOverFrom] [DATETIME] ,
     [ShortOverTo] [DATETIME] ,
     [PermissionFrom] [DATETIME] ,
     [PermissionTo] [DATETIME] )

---------------------------------------
IF @UsePermission=1 
begin

  INSERT INTO @OverShortPermTimes
                      ( 
                        EntryDate ,
                        EntryNo ,
                        OverShort ,
                        ShortOverFrom ,
                        ShortOverTo ,
                        PermissionFrom ,
                        PermissionTo  )

           SELECT EntryDate,EntryNo,

               CASE WHEN overshort IN (5,6,7) THEN overshort ELSE 
                 CASE when TimeIn is null or TimeOut is null then 8
                else case when PermissionFrom<TimeIn and TimeIn>ShiftIn then 
               5 else null end  end
                END,
              --OverShort,

           CASE WHEN OverShort=5 THEN 
                case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn
                then shiftin else null     END
        WHEN OverShort=6 THEN 
                case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut AND( (shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2))
                then timeout ELSE NULL end
           WHEN OverShort IN(8) THEN 
                case when TimeIn is null or TimeOut is null THEN timein
                else case when PermissionFrom<TimeIn and TimeIn>ShiftIn THEN shiftin else null end  end
           ELSE NULL 
           END
           ,
           CASE WHEN OverShort=5 THEN 
                case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn
                then timein else null END
        WHEN OverShort=6 THEN 
                case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut AND ((shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2) )
                then shiftout ELSE NULL end
           WHEN OverShort IN(8) THEN 
                case when TimeIn is null or TimeOut is null THEN timeout
                else case when PermissionFrom<TimeIn and TimeIn>ShiftIn THEN timein else null end  end
           ELSE NULL 
           END
           ,
           CASE WHEN OverShort=5 THEN 
                case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn
                then case when PermissionFrom<ShiftIn then ShiftIn else PermissionFrom END else null     END
        WHEN OverShort=6 THEN 
                case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut  AND ((shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2) )
                then case when PermissionFrom<TimeOut then TimeOut else PermissionFrom END ELSE NULL end
           WHEN OverShort IN(8) THEN 
                case when TimeIn is null or TimeOut is null THEN CASE when PermissionFrom<ShiftIn then ShiftIn else PermissionFrom end
                else case when PermissionFrom<TimeIn and TimeIn>ShiftIn THEN CASE when PermissionFrom<ShiftIn then ShiftIn else PermissionFrom end else null end  end
           ELSE NULL 
           END,

        CASE WHEN OverShort=5 THEN 
                case when OverShort in (5) and PermissionFrom<isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn)>ShiftIn THEN
                case when PermissionTo>TimeIn then TimeIn else PermissionTo end else null end
           WHEN OverShort=6 THEN 
                case when OverShort in (6) and  PermissionTo>isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut  AND ((shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2) )
                then case when PermissionTo>ShiftOut then ShiftOut else PermissionTo end ELSE NULL end
           WHEN overshort IN (8) THEN
                case when TimeIn is null or TimeOut is null then case when PermissionTo>ShiftOut then ShiftOut else PermissionTo end
                else case when PermissionFrom<TimeIn and TimeIn>ShiftIn then 
                case when PermissionTo>TimeIn then TimeIn else PermissionTo end else null end  end
            
           ELSE  NULL 
           END

           FROM  EmpTimePermission INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
           inner join @EmpShiftInOutTemp  EmpShiftInOut ON EmpShiftInOut.empid= EmpTimePermission.Empid 
           AND ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) or  (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
           or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo)
           or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))
           where EmpTimePermission.Empid=@Empid  AND EntryDate =@entrydate AND documentstatus=1 AND (OverShort in (5,6,7) OR OverShort=CASE WHEN @OverShortTotalExist>0 THEN 8 ELSE 0 end)
           and ((PermissionFrom between ShiftIn and ShiftOut) or (PermissionTo between ShiftIn and ShiftOut) 
           or (ShiftIn between PermissionFrom and PermissionTo) or (ShiftOut between PermissionFrom and PermissionTo)) 

           ORDER BY PermissionFrom



		       -----------------------------------------------------------------------

     INSERT INTO @OverShortPermTimes
                      ( 
                        EntryDate ,
                        EntryNo ,
                        OverShort ,
                        ShortOverFrom ,
                        ShortOverTo ,
                        PermissionFrom ,
                        PermissionTo  )

           SELECT EntryDate,EntryNo,
                   CASE WHEN OverShort IN(7,8) THEN 
                case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
                case when PermissionTo>TimeOut and TimeOut<ShiftOut  THEN CASE WHEN  shiftout<> @ShiftOut1 and shiftout<> @ShiftOut2 THEN 7 ELSE 6 end  else null end end
           ELSE NULL 
           END,
              --OverShort,

           CASE WHEN OverShort IN(7,8) THEN 
                case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
                case when PermissionTo>TimeOut and TimeOut<ShiftOut AND ((OverShort=7 AND shiftout<> @ShiftOut1 and shiftout<> @ShiftOut2) OR (OverShort=8)) THEN TimeOut else null end end
           ELSE NULL 
           END

           ,CASE WHEN OverShort IN(7,8) THEN 
                case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
                case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> @ShiftOut1 and shiftout<> @ShiftOut2) OR (OverShort=8)) THEN ShiftOut else null end end
           ELSE NULL 
           END,

           CASE WHEN OverShort IN(7,8) THEN 
                case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
                case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> @ShiftOut1 and shiftout<> @ShiftOut2) OR (OverShort=8)) THEN case when PermissionFrom<TimeOut then TimeOut else PermissionFrom end else null end end
           ELSE NULL 
           END,

           CASE WHEN OverShort IN(7,8) THEN 
                case when TimeIn is NOT NULL and TimeOut is NOT NULL then 
                case when PermissionTo>TimeOut and TimeOut<ShiftOut  AND ((OverShort=7 AND shiftout<> @ShiftOut1 and shiftout<> @ShiftOut2) OR (OverShort=8)) THEN 
                case when PermissionTo>ShiftOut then ShiftOut else PermissionTo end else null end end
           ELSE NULL 
           END


        FROM  EmpTimePermission INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
           inner JOIN @EmpShiftInOutTemp  EmpShiftInOut on EmpShiftInOut.empid= EmpTimePermission.Empid AND ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) or  (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
           or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo)
           or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut))
           where EmpTimePermission.Empid=@Empid  AND EntryDate =@entrydate AND documentstatus=1 AND (OverShort in (7) OR OverShort=CASE WHEN @OverShortTotalExist>0 THEN 8 ELSE 0 end)
           and ((PermissionFrom between ShiftIn and ShiftOut) or (PermissionTo between ShiftIn and ShiftOut) 
           or (ShiftIn between PermissionFrom and PermissionTo) or (ShiftOut between PermissionFrom and PermissionTo)) 
           ORDER BY PermissionFrom



END
    -----------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
--SELECT '@OverShortPermTimes33333333333',* FROM @OverShortPermTimes
IF @Usevaction=1
begin
INSERT INTO @OverShortPermTimes
( 
EntryDate ,
EntryNo ,
OverShort ,
ShortOverFrom ,
ShortOverTo )
       
SELECT EntryDate,EntryNo,

CASE WHEN timein >ISNULL(shiftin,timein) THEN 5 
    WHEN  timein <ISNULL(shiftin,timein) THEN 1 
     WHEN  timeout <ISNULL(shiftout,timeout) THEN CASE WHEN (shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2) THEN 6 ELSE 7 end
     WHEN  timeout >ISNULL(shiftout,timeout) THEN 2 
     WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN 3
     END 
,
CASE WHEN timein >ISNULL(shiftin,timein) THEN shiftin 
    WHEN  timein <ISNULL(shiftin,timein) THEN timein 
     WHEN  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN  timeout >ISNULL(shiftout,timeout) THEN shiftout  
     WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN timein END
    
,CASE WHEN timein >ISNULL(shiftin,timein) THEN timein 
    WHEN  timein <ISNULL(shiftin,timein) THEN shiftin 
     WHEN  timeout <ISNULL(shiftout,timeout) THEN shiftout 
     WHEN  timeout >ISNULL(shiftout,timeout) THEN timeout  
     WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN timeout END
FROM @EmpShiftInOutTemp AS EmpShiftInOut
WHERE Empid=@Empid  AND EntryDate =@entrydate  AND timein IS NOT NULL AND timeout IS NOT null
AND CASE WHEN timein >ISNULL(shiftin,timein) THEN shiftin 
    WHEN  timein <ISNULL(shiftin,timein) THEN timein 
     WHEN  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN  timeout >ISNULL(shiftout,timeout) THEN shiftout  
     WHEN ShiftIn IS NULL AND ShiftOut IS NULL THEN timein END NOT IN (SELECT ISNULL(t.ShortOverFrom,'') FROM @OverShortPermTimes t)
-------------------------------------------------------
INSERT INTO @OverShortPermTimes
( 
EntryDate ,
EntryNo ,
OverShort ,
ShortOverFrom ,
ShortOverTo  )

SELECT EntryDate,EntryNo,

CASE WHEN timein >= ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN CASE WHEN (shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2) THEN 6 ELSE 7 end 
     WHEN timein >= ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN 2
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN CASE WHEN (shiftout= @ShiftOut1) OR (shiftout= @ShiftOut2) THEN 6 ELSE 7 end  
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN 2
END
,
CASE WHEN timein >= ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN timein >= ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
END
    
,CASE WHEN timein >= ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN shiftout 
     WHEN timein >= ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN timeout
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN shiftout 
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN timeout
END
FROM @EmpShiftInOutTemp AS EmpShiftInOut
WHERE Empid=@Empid  AND EntryDate =@entrydate  AND timein IS NOT NULL AND timeout IS NOT null
AND CASE WHEN timein >= ISNULL(shiftin,timein) AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN timein >= ISNULL(shiftin,timein) AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout <ISNULL(shiftout,timeout) THEN timeout 
     WHEN  timein <= ISNULL(shiftin,timein)  AND  timeout >ISNULL(shiftout,timeout) THEN shiftout
END NOT IN (SELECT isnull(t.ShortOverFrom,'') FROM @OverShortPermTimes t)
end  
     --------------------------------------

DELETE FROM @OverShortPermTimes WHERE OVERshort IN (1,2,3,4)

DELETE FROM @OverShortPermTimes WHERE ShortOverFrom IS NULL AND ShortOverTo IS NULL

UPDATE @OverShortPermTimes SET ShortOverTo=
ISNULL((SELECT TOp 1 t.PermissionFrom FROM @OverShortPermTimes t 
WHERE OSPT.EntryDate=t.EntryDate AND OSPT.ShortOverFrom=t.ShortOverFrom AND OSPT.ShortOverTo=t.ShortOverTo AND OSPT.documentno<t.documentno ORDER BY t.Documentno),ShortOverTo)

,ShortOverFrom=iSNULL((SELECT TOp 1 OSPT.PermissionFrom FROM @OverShortPermTimes t 
WHERE OSPT.EntryDate=t.EntryDate AND OSPT.ShortOverFrom=t.ShortOverFrom AND OSPT.ShortOverTo=t.ShortOverTo AND OSPT.documentno>t.documentno ORDER BY t.Documentno desc),ShortOverFrom)
FROM @OverShortPermTimes OSPT

-----------------------------------------------------------------------------------------
declare  @EmpShiftInOutWH TABLE(
     EntryDate datetime ,
     EntryNo SMALLINT ,
     Documentno INT  ,
     OverShort SMALLINT ,
     ShortOverFrom DATETIME ,
     ShortOverTo DATETIME ,
     PermissionFrom DATETIME ,
     PermissionTo DATETIME,
     From1Intersected  datetime,
     TO1Intersected  datetime,
     From1NotIntersected  datetime,
     TO1NotIntersected  datetime,
     From2NotIntersected  datetime,
     TO2NotIntersected  datetime,
     ShortHours1 NUMERIC(18,3),
     ShortHours2 NUMERIC(18,3),
     VacConsumed1 NUMERIC(18,3),
     VacConsumed2 NUMERIC(18,3) )
             

   INSERT INTO @EmpShiftInOutWH (EntryDate,EntryNo,Documentno,OverShort,ShortOverFrom ,ShortOverTo,PermissionFrom,PermissionTo)
   --SELECT EntryDate,EntryNo,Documentno,OverShort,t.VirtualTimeIn ,t.VirtualTimeOut,
   --CASE WHEN (OverShort IN (1,2,3,4) AND @UsePermissionOver=1) OR (OverShort IN (5,6,7,8) AND @UsePermission=1)  THEN  t.VirtualPermissionFrom ELSE NULL end ,
   --   CASE WHEN (OverShort IN (1,2,3,4) AND @UsePermissionOver=1) OR (OverShort IN (5,6,7,8) AND @UsePermission=1)  THEN  t.VirtualPermissionTo ELSE NULL END
       --FROM dbo.EmpShiftInOutWH t  WHERE t.empid=@Empid AND t.EntryDate=@Entrydate
   --ORDER BY OverShort
      SELECT EntryDate,EntryNo,Documentno,OverShort,t.ShortOverFrom ,t.ShortOverTo,
   CASE WHEN (OverShort IN (5,6,7,8) AND @UsePermission=1)  THEN  t.PermissionFrom ELSE NULL end ,
      CASE WHEN (OverShort IN (5,6,7,8) AND @UsePermission=1)  THEN  t.PermissionTo ELSE NULL END
   FROM @OverShortPermTimes t 
   ORDER BY OverShort

   DELETE FROM @EmpShiftInOutWH WHERE OverShort IN (1,2,3,4)

   IF EXISTS(SELECT * FROM @EmpShiftInOutWH)
   begin
   -------------intersected periods
   UPDATE @EmpShiftInOutWH 
   SET From1Intersected=CASE WHEN PermissionFrom IS NOT NULL THEN CASE WHEN PermissionFrom > [ShortOverFrom] THEN PermissionFrom ELSE [ShortOverFrom] END ELSE NULL end
   ,TO1Intersected=CASE WHEN PermissionFrom IS NOT NULL THEN CASE WHEN PermissionTo > ShortOverTo THEN ShortOverTo ELSE PermissionTo END ELSE NULL end
   WHERE  PermissionFrom IS NOT NULL AND PermissionTo IS NOT null

   ------------not intersected periods
    UPDATE @EmpShiftInOutWH 
   SET From1NotIntersected = CASE WHEN PermissionFrom > ShortOverFrom THEN ShortOverFrom ELSE null END
   ,TO2NotIntersected=CASE WHEN PermissionTo > ShortOverTo THEN null ELSE ShortOverTo END
   WHERE OverShort IN (5,6,7,8) 
   --to be sure that the short period and the permission period are not identical
   AND ((ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom=ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')=[ShortOverTo]))
   AND PermissionFrom IS NOT NULL AND PermissionTo IS NOT null

    UPDATE @EmpShiftInOutWH 
   SET TO1NotIntersected= CASE WHEN From1NotIntersected IS NOT NULL THEN From1Intersected ELSE NULL END
   ,From2NotIntersected =CASE WHEN TO2NotIntersected IS NOT NULL THEN  TO1Intersected ELSE NULL end
   WHERE OverShort IN (5,6,7,8) 
   --to be sure that the short period and the permission period are not identical
   AND ((ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom=ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')<>[ShortOverTo]) OR (ShortOverFrom<>ISNULL(PermissionFrom,'') AND ISNULL(PermissionTo,'')=[ShortOverTo]))
   AND PermissionFrom IS NOT NULL AND PermissionTo IS NOT NULL 

   UPDATE @EmpShiftInOutWH 
   SET From1NotIntersected= ShortOverFrom
   ,TO1NotIntersected =ShortOverTo
   WHERE OverShort IN (5,6,7,8) 
   AND From1NotIntersected IS NULL AND TO1NotIntersected IS  NULL AND From2NotIntersected IS  NULL AND TO2NotIntersected IS  NULL
   AND PermissionFrom IS  NULL    AND PermissionTo IS  NULL 
   ----------------------------------------------------------------------------------------------------
  
  --SELECT '@EmpShiftInOutWH12222',* FROM @EmpShiftInOutWH
   INSERT INTO @EmpShiftInOutWH
( EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,From1Intersected,TO1Intersected,From1NotIntersected,
   TO1NotIntersected,From2NotIntersected,TO2NotIntersected,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2)
SELECT EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,null,null,@EntryDate,
CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), TO1NotIntersected, 108) , 120),null,null,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2 
 FROM @EmpShiftInOutWH
WHERE  From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT NULL and DATEDIFF(dd,From1NotIntersected,TO1NotIntersected)=1 


UPDATE @EmpShiftInOutWH SET From1NotIntersected=CONVERT(DATETIME, @EntryDate + ' '+CONVERT(char(8), From1NotIntersected, 108) , 120),
TO1NotIntersected=CASE WHEN DATEDIFF(dd,From1NotIntersected,TO1NotIntersected)=1  THEN CONVERT(DATETIME, @EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), TO1NotIntersected, 108) , 120) end
WHERE  From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT NULL 


   INSERT INTO @EmpShiftInOutWH
( EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,From1Intersected,TO1Intersected,From1NotIntersected,
   TO1NotIntersected,From2NotIntersected,TO2NotIntersected,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2)
SELECT EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,null,null,null,
null,@EntryDate,CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), TO2NotIntersected, 108), 120),ShortHours1,ShortHours2,VacConsumed1,VacConsumed2 
 FROM @EmpShiftInOutWH
WHERE  From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT NULL and DATEDIFF(dd,From2NotIntersected,TO2NotIntersected)=1 


UPDATE @EmpShiftInOutWH SET From2NotIntersected=CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), From2NotIntersected, 108) , 120),
TO2NotIntersected=CASE WHEN DATEDIFF(dd,From2NotIntersected,TO2NotIntersected)=1  THEN CONVERT(DATETIME, @EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), TO2NotIntersected, 108) , 120) end
WHERE  From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT NULL 


    INSERT INTO @EmpShiftInOutWH
( EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,From1Intersected,TO1Intersected,From1NotIntersected,
   TO1NotIntersected,From2NotIntersected,TO2NotIntersected,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2)
SELECT EntryDate, EntryNo,Documentno,OverShort,ShortOverFrom,ShortOverTo,PermissionFrom,PermissionTo,@EntryDate,CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), TO1Intersected, 108) , 120),null,
null,null,null,ShortHours1,ShortHours2,VacConsumed1,VacConsumed2 
 FROM @EmpShiftInOutWH
WHERE  From1Intersected IS NOT NULL AND TO1Intersected IS NOT NULL and DATEDIFF(dd,From1Intersected,TO1Intersected)=1-- AND OverShort IN (1,2,3,4)

UPDATE @EmpShiftInOutWH SET From1Intersected=CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), ISNULL(From1Intersected,ShortOverFrom), 108) , 120),
TO1Intersected=CASE WHEN  DATEDIFF(dd,From1Intersected,TO1Intersected)=1   THEN CONVERT(DATETIME, @EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(DATETIME, @EntryDate + ' '+ CONVERT(char(8), ISNULL(TO1Intersected,ShortOverTo), 108), 120) end
WHERE  From1Intersected IS NOT NULL AND TO1Intersected IS NOT NULL --AND OverShort IN (1,2,3,4)

  -------------------------------------------------------
 -- SELECT '@EmpShiftInOutWH',* FROM @EmpShiftInOutWH
  ------------------------------------------------------------------------

  UPDATE @EmpShiftInOutWH SET ShortHours1=DATEDIFF (second ,From1NotIntersected,TO1NotIntersected)
     from @EmpShiftInOutWH ESIOWH 
      WHERE  From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT null
     



  UPDATE @EmpShiftInOutWH SET ShortHours2=DATEDIFF (second ,From2NotIntersected,TO2NotIntersected)
    from @EmpShiftInOutWH ESIOWH
     WHERE From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT null


     --decide which part is the biggest one -- > vacation will be considered with it
     DECLARE @HoursIn AS NUMERIC(18,3),@HoursOut AS NUMERIC(18,3),@HoursMid AS NUMERIC(18,3)
     SELECT @HoursIn =SUM(CASE WHEN OverShort=5 THEN ISNULL(ShortHours1,0)+ISNULL(ShortHours2,0) ELSE 0 END),
     @HoursOut=SUM(CASE WHEN OverShort=6 THEN ISNULL(ShortHours1,0)+ISNULL(ShortHours2,0) ELSE 0 END),
     @HoursMid=SUM(CASE WHEN OverShort=7 THEN ISNULL(ShortHours1,0)+ISNULL(ShortHours2,0) ELSE 0 END)
     FROM @EmpShiftInOutWH

   SELECT @VacHoursType = ( CASE
                            WHEN @HoursIn >= @HoursOut AND @HoursIn >= @HoursMid THEN 1
                            WHEN @HoursOut >= @HoursIn AND @HoursOut >= @HoursMid THEN 2
                            WHEN @HoursMid >= @HoursIn AND @HoursMid >= @HoursOut THEN 3
                            ELSE 1 END )  
                            
   --in case we need to work with the normal old logic[vacation will be considered in all cases]
    SET @VacHoursType = 0          

   --SELECT '@EmpShiftInOutWH1122345',* FROM @EmpShiftInOutWH
     ------------------------------------------------------------------------
     DECLARE @VacHourstemp1  AS numeric(18,3),@VacHourstemp2 AS numeric(18,3) ,@VacRest AS numeric(18,3)
     IF @Usevaction=1 AND @VacHours<>0
     begin
           SELECT @VacHourstemp1=0,@VacHourstemp2=0
           SET @VacRest=@VacHours
           UPDATE @EmpShiftInOutWH
           SET VacConsumed1=@VacHourstemp1
           ,VacConsumed2=@VacHourstemp2
           --,@VacRest=CASE WHEN @VacRest-@VacHourstemp1 <0 THEN 0 ELSE @VacRest-@VacHourstemp1 end
           ,@VacHourstemp1=CASE WHEN ISNULL(ShortHours1,0) >@VacRest THEN @VacRest ELSE ISNULL(ShortHours1,0) END
           ,@VacHourstemp2=CASE WHEN ISNULL(ShortHours2,0) >@VacRest-@VacHourstemp1 THEN @VacRest -@VacHourstemp1 ELSE ISNULL(ShortHours2,0) END
           ,@VacRest=CASE WHEN @VacRest-@VacHourstemp1-@VacHourstemp2 <0 THEN 0 ELSE @VacRest-@VacHourstemp1-@VacHourstemp2 END
           WHERE overshort =CASE WHEN @VacHoursType=1 THEN 5 WHEN @VacHoursType=2 THEN 6 WHEN @VacHoursType=3 THEN 7 ELSE overshort END
    ENd
  -------------------------------------------------------------------------
 -- SELECT '@EmpShiftInOutWH',* FROM @EmpShiftInOutWH

   -- SELECT '@EmpShiftInOutWH',* FROM @EmpShiftInOutWH
  --SELECT '@TimeShiftTimes',* FROM @TimeShiftTimes
  -------------------------------------------------------
  select @OverValue=0

  IF @Usevaction=1
  BEGIN
--  CASE WHEN PermissionFrom > [ShortOverFrom] THEN PermissionFrom ELSE [ShortOverFrom] END
--CASE WHEN PermissionTo > ShortOverTo THEN ShortOverTo ELSE PermissionTo END

     select @OverValue=@OverValue+
     CASE WHEN @Fromdate   BETWEEN From1NotIntersected and TO1NotIntersected
     or  @Todate    between From1NotIntersected  and  TO1NotIntersected
     OR  From1NotIntersected between @Fromdate  and  @Todate 
     or  TO1NotIntersected  between @Fromdate and  @Todate THEN DATEDIFF(ss,CASE WHEN From1NotIntersected > @Fromdate THEN From1NotIntersected ELSE @Fromdate END,CASE WHEN DATEADD(ss,VACCONSUMED1,From1NotIntersected) > @Todate THEN @Todate ELSE DATEADD(ss,VACCONSUMED1,From1NotIntersected) END) ELSE 0 end
     + CASE WHEN (@Fromdate1   BETWEEN From1NotIntersected and TO1NotIntersected
     or  @Todate1    between From1NotIntersected  and  TO1NotIntersected
     OR  From1NotIntersected between @Fromdate1  and  @Todate1
     or  TO1NotIntersected  between @Fromdate1 and  @Todate1) and @Fromdate1 IS not NULL AND @Todate1 IS NOT NULL THEN 
     DATEDIFF(ss,CASE WHEN From1NotIntersected > @Fromdate1 THEN From1NotIntersected ELSE @Fromdate1 END,CASE WHEN DATEADD(ss,VACCONSUMED1,From1NotIntersected) > @Todate1 THEN @Todate1 ELSE DATEADD(ss,VACCONSUMED1,From1NotIntersected) END)
     ELSE 0 END 
     
     from @EmpShiftInOutWH ESIOWH
     WHERE  From1NotIntersected IS NOT NULL AND TO1NotIntersected IS NOT NULL
    AND ISNULL(VacConsumed1,0)<>0
     AND (@Fromdate   BETWEEN From1NotIntersected and TO1NotIntersected
     or  @Todate    between From1NotIntersected  and  TO1NotIntersected
     OR  From1NotIntersected between @Fromdate  and  @Todate 
     or  TO1NotIntersected  between @Fromdate and  @Todate
     OR @Fromdate1   BETWEEN From1NotIntersected and TO1NotIntersected
     or  @Todate1    between From1NotIntersected  and  TO1NotIntersected
     OR  From1NotIntersected between @Fromdate1  and  @Todate1
     or  TO1NotIntersected  between @Fromdate1 and  @Todate1)


     --select @OverValue AS '@OverValue1'


     select @OverValue=@OverValue+CASE WHEN @Fromdate   BETWEEN From2NotIntersected and TO2NotIntersected
     or  @Todate    between From2NotIntersected  and  TO2NotIntersected
     OR  From2NotIntersected between @Fromdate  and  @Todate 
     or  TO2NotIntersected  between @Fromdate and  @Todate THEN DATEDIFF(ss,CASE WHEN From2NotIntersected > @Fromdate THEN From2NotIntersected ELSE @Fromdate END,CASE WHEN DATEADD(ss,VACCONSUMED2,From2NotIntersected) > @Todate THEN @Todate ELSE DATEADD(ss,VACCONSUMED2,From2NotIntersected) END) ELSE 0 end
     +
     CASE WHEN (@Fromdate1   BETWEEN From2NotIntersected and TO2NotIntersected
     or  @Todate1    between From2NotIntersected  and  TO2NotIntersected
     OR  From2NotIntersected between @Fromdate1  and  @Todate1 
     or  TO2NotIntersected  between @Fromdate1 and  @Todate1) and  @Fromdate1 IS not NULL AND @Todate1 IS NOT NULL THEN DATEDIFF(ss,CASE WHEN From2NotIntersected > @Fromdate1 THEN From2NotIntersected ELSE @Fromdate1 END,CASE WHEN DATEADD(ss,VACCONSUMED2,From2NotIntersected) > @Todate1 THEN @Todate1 ELSE DATEADD(ss,VACCONSUMED2,From2NotIntersected) END)
     ELSE 0 END 
    from @EmpShiftInOutWH ESIOWH
     where From2NotIntersected IS NOT NULL AND TO2NotIntersected IS NOT NULL
      AND ISNULL(VacConsumed2,0)<>0
     AND (@Fromdate   BETWEEN From2NotIntersected and TO2NotIntersected
     or  @Todate    between From2NotIntersected  and  TO2NotIntersected
     OR  From2NotIntersected between @Fromdate  and  @Todate 
     or  TO2NotIntersected  between @Fromdate and  @Todate
     OR @Fromdate1   BETWEEN From2NotIntersected and TO2NotIntersected
     or  @Todate1    between From2NotIntersected  and  TO2NotIntersected
     OR  From2NotIntersected between @Fromdate1  and  @Todate1 
     or  TO2NotIntersected  between @Fromdate1 and  @Todate1     )

     
       --select @OverValue AS '@OverValue2'
     
END
     
     SELECT @OverValue=ISNULL(@OverValue,0)+ISNULL(SUM(ISNULL(DATEDIFF(ss,CASE WHEN From1Intersected >@Fromdate THEN From1Intersected ELSE @Fromdate END,
     CASE WHEN TO1Intersected > @Todate THEN @Todate ELSE TO1Intersected END),0)),0)
    from @EmpShiftInOutWH ESIOWH
     where From1Intersected IS NOT NULL AND TO1Intersected IS NOT NULL
    AND ESIOWH.PermissionFrom IS NOT NULL AND ESIOWH.PermissionTo IS NOT null
     AND (@Fromdate   BETWEEN From1Intersected and TO1Intersected
     or  @Todate    between From1Intersected  and  TO1Intersected
     OR  From1Intersected between @Fromdate  and  @Todate 
     or  TO1Intersected  between @Fromdate and  @Todate)


     SELECT @OverValue=ISNULL(@OverValue,0)+ISNULL(SUM(ISNULL(DATEDIFF(ss,CASE WHEN From1Intersected >@Fromdate1 THEN From1Intersected ELSE @Fromdate1 END,
     CASE WHEN TO1Intersected > @Todate1 THEN @Todate1 ELSE TO1Intersected END),0)),0)
    from @EmpShiftInOutWH ESIOWH
     where From1Intersected IS NOT NULL AND TO1Intersected IS NOT NULL
     AND @Fromdate1 IS NOT NULL AND @Todate1 IS NOT null
    AND ESIOWH.PermissionFrom IS NOT NULL AND ESIOWH.PermissionTo IS NOT null
     AND (@Fromdate1   BETWEEN From1Intersected and TO1Intersected
     or  @Todate1    between From1Intersected  and  TO1Intersected
     OR  From1Intersected between @Fromdate1  and  @Todate1 
     or  TO1Intersected  between @Fromdate1 and  @Todate1)

     

END


---------------------------16/07/2007---------------------------------
--return isnull(@OverValue,0)
SET @OverValue=ISNULL(@OverValue,0)
--SELECT @OverValue AS '@OverValue'
----------------------------------------------------------------------------------
--return @OverValue
DECLARE @PeriodSeconds AS  INT 
--DROP TABLE #EmpShiftInOut
  DECLARE  @EmpShiftInOut AS TABLE(empid int,entrydate smalldatetime,timein smalldatetime,TIMEOUT smalldatetime)

INSERT INTO @EmpShiftInOut
SELECT empid,EntryDate,CONVERT(SMALLDATETIME, @EntryDate + ' '+CONVERT(char(8), timein, 108) , 120)
,CASE WHEN DATEDIFF(dd,timein,TimeOut)=1 THEN CONVERT(DATETIME, @EntryDate + ' '+ '23:59:59:999', 120) ELSE CONVERT(SMALLDATETIME, @EntryDate + ' '+CONVERT(char(8), timeout, 108), 120) end
FROM EmpShiftInOut 
WHERE EmpId =@Empid AND EntryDate=@EntryDate
AND TimeIn IS NOT NULL AND timeout IS NOT null
union
SELECT empid,EntryDate,@EntryDate
,CONVERT(SMALLDATETIME, @EntryDate + ' '+CONVERT(char(8), timeout, 108) , 120)
FROM EmpShiftInOut 
WHERE EmpId =@Empid AND EntryDate=@EntryDate
AND TimeIn IS NOT NULL AND timeout IS NOT NULL
AND  DATEDIFF(dd,timein,TimeOut)=1 

--  SELECT @Fromdate,@Todate
-- get intersection period 
SELECT @PeriodSeconds = ISNULL(SUM (DATEDIFF (second ,CASE WHEN @Fromdate > timein THEN @Fromdate ELSE timein  End
,CASE WHEN  @Todate < TIMEOUT THEN  @Todate ELSE TIMEOUT END)),0)
FROM @EmpShiftInOut  
WHERE TimeIn IS NOT NULL AND timeout IS NOT null
AND(@Fromdate   BETWEEN timein  and timeout 
OR  @Todate    between timein  and  TIMEOUT 
OR  timein    between @Fromdate  and  @Todate 
or  TIMEOUT  between @Fromdate and  @Todate)



SELECT @PeriodSeconds = @PeriodSeconds+ISNULL(SUM (DATEDIFF (second ,CASE WHEN @Fromdate1 > timein THEN @Fromdate1 ELSE timein  End
,CASE WHEN  @Todate1 < TIMEOUT THEN  @Todate1 ELSE TIMEOUT END)),0)
FROM @EmpShiftInOut  
WHERE TimeIn IS NOT NULL AND timeout IS NOT null
AND(@Fromdate1   BETWEEN timein  and timeout 
OR  @Todate1    between timein  and  TIMEOUT 
OR  timein    between @Fromdate1  and  @Todate1 
or  TIMEOUT  between @Fromdate1 and  @Todate1)
AND @Fromdate1 IS NOT NULL AND @Todate1 IS NOT null

    
     --  SELECT @PeriodSeconds/3600.00 AS '@PeriodSeconds',@OverValue AS '@OverValue'
     --  SELECT @PeriodSeconds AS '@PeriodSeconds'
       return ISNULL(@PeriodSeconds,0)+@OverValue

END

GO

