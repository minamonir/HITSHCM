

CREATE    FUNCTION [dbo].[Hits_IsEventRestricted]
	(@event as bigint,@empid as int)
RETURNS bit
AS
BEGIN
declare @restricted as bit
declare @currentrestricted as int
set @restricted = 0

declare @EmpOrganization as smallint,@EmpJob as smallint,@EmpGrade as smallint,@EmpLocationNo as smallint, @EmpPositionNo as smallint,@RestrictEvent as bit
select @EmpOrganization=Organization,@EmpJob=Job,@EmpGrade=Grade,@EmpLocationNo=LocationNo,@EmpPositionNo=PositionNo 
from empassignment where empid = @empid

select @RestrictEvent=RestrictEvent from   TrainingEvents where   TrainingEvent = @event
if @RestrictEvent = 0 return 1


declare event cursor for 
SELECT TrainingEventRestriction.TrainingRestriction, 
       TrainingEventRestriction.Organization,TrainingEventRestriction.Job, TrainingEventRestriction.Grade, 
        TrainingEventRestriction.LocationNo, TrainingEventRestriction.PositionNo, TrainingEventRestriction.Profileid
FROM   TrainingEventRestriction 
where TrainingEventRestriction.TrainingEvent = @event
declare @TrainingRestriction as smallint,@Organization as smallint,@Job as smallint,@Grade as smallint,@LocationNo as smallint, @PositionNo as smallint , @Profileid as int
declare @OrganizationF as bit,@JobF as bit,@GradeF as bit,@LocationNoF as bit, @PositionNoF as bit , @ProfileidF as bit

OPEN event
FETCH NEXT FROM event
into   @TrainingRestriction,@Organization,@Job,@Grade,@LocationNo,@PositionNo , @profileid
WHILE @@FETCH_STATUS = 0
BEGIN
select  @OrganizationF = 0,@JobF = 0,@GradeF = 0,@LocationNoF = 0, @PositionNoF = 0 ,  @profileidF=0

if (@Organization is null) or (@Organization= @empOrganization) set @OrganizationF = 1
if (@Job is null) or (@Job= @EmpJob) set @JobF = 1
if (@Grade is null) or (@Grade= @EmpGrade) set @GradeF = 1
if (@LocationNo is null) or (@LocationNo= @EmpLocationNo) set @LocationNoF = 1
if (@PositionNo is null) or (@PositionNo= @EmpPositionNo) set @PositionNoF = 1
if (@profileid is null) or (@profileid= @empid) set @ProfileidF = 1
if  @OrganizationF = 1 and @JobF = 1 and @GradeF = 1 and @LocationNoF = 1 and  @PositionNoF =1 and  @ProfileidF =1 set @restricted = @restricted | 1
FETCH NEXT FROM event
into   @TrainingRestriction,@Organization,@Job,@Grade,@LocationNo,@PositionNo , @profileid
END
CLOSE event
DEALLOCATE event

return @restricted
END

GO

