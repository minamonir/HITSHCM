

CREATE  FUNCTION IsValiadHijriDate 
( @Day INT,@Month INT,@Year INT )
RETURNS bit
AS
BEGIN

       If @Year < 9999 And @Year > 0 
           BEGIN
				If @Month < 13 And @Month > 0 
				BEGIN
					IF @Day>0
					BEGIN
						DECLARE @actualdays AS INT
						SELECT @actualdays =HijriDays FROM HijriBase WHERE HijriMonth=@Month
							
							IF EXISTS(SELECT * FROM HijriAdjustment WHERE HijriYear=@Year AND HijriMonth=@Month)
							BEGIN
								SELECT @actualdays = @actualdays+Adjustment FROM HijriAdjustment  WHERE HijriYear=@Year AND HijriMonth=@Month
							END 
					   IF @Day <= @actualdays RETURN 1
					END 
				End 
		   END 
        Return 0


END

GO

