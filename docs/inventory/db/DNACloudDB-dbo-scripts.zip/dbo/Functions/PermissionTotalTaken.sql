


CREATE FUNCTION [dbo].[PermissionTotalTaken]
(@EmpId as int, @DocNo AS INT, @FromDate as datetime,@ToDate as datetime,@ChkNewRecord AS BIT, @OverShortType AS INT,@ActualFromDate AS DATETIME,@ActualToDate AS DATETIME)
RETURNS INT
AS
BEGIN
	
--@ChkNewRecord :
-- 1 : calculate the new permission period
-- 0 : calculate pervious data 

--overshort
--1	Over [Early In]                                             
--2	Over [Late Out]                                             
--3	Over [Out of working hours]                                 
--4	Over [Total]                                                
--5	Short [Late In]                                             
--6	Short [Early Out]                                           
--7	Short [During working hours]                                
--8	Short [Total]      
 
--Parameters for the cursor
---------------------------
DECLARE @OverShort_Cursor AS SMALLINT , @PermissionFrom_Cursor AS SMALLDATETIME , @PermissionTo_Cursor AS SMALLDATETIME,
@PermissionSeconds_Cursor AS INT , @EntryDateTemp_Cursor AS SMALLDATETIME,@PermissionSeconds AS INT , @PermID_Cursor as SMALLINT,
@WorkingSeconds AS INT , @ShiftSeconds AS INT,@PermissionPeriod AS INT,@PermOverTotal_Cursor AS INT , @PermShortTotal_Cursor AS INT,
@ActualPermFrom_Cursor AS SMALLDATETIME,@ActualPermTo_Cursor AS SMALLDATETIME,@Perm_AnotherPeriodFirst AS INT,@Perm_AnotherPeriodLast AS INT,@PermissionPeriod_First AS INT,@PermissionPeriod_Last AS INT

SET @PermissionSeconds_Cursor = 0
SET @PermOverTotal_Cursor = 0
SET @PermShortTotal_Cursor = 0

-- Employee TimeRule (Fixed Hours or not ? )
---------------------------------------------
DECLARE @FixedHours AS BIT
SELECT @FixedHours = (SELECT tr.FixedHours
                      FROM EmpAssignment ea INNER JOIN TimeRules tr ON tr.TimeRule = ea.TimeRule
                      WHERE ea.EmpId = @EmpId)

-- Permissions TempTable
------------------------
-- in case of NOT fixed hours .. we use cols. (overshort,permfrom,permto,actualpermissionfrom,actualpermissionto) only
-- in case of fixed hours .. we use all the table cols : 
---- the OvershortValue col. : will be updated in the fixed cursor .. by the useful part of the permission for our customer
---- the perm_ID col. : 
-------- In case of New Permission : 
-----------------Perm_ID will equal '1' for the new permission record & will equal '0' for the old permissions that affects [the shift intersects with the new permission]
-------- In case of calc. old data :
-----------------Perm_ID will equal '1' for the current period permissions record & will equal '0' for the previous period permissions that affects [the shift intersects with the permission in the current period]
-- Can select the useful value -at the last of the function- from this temp table as the summation of the 'OverShortValue' where perm_ID = 1
DECLARE @PermTable TABLE (OverShort SMALLINT,PermissionFrom SMALLDATETIME,PermissionTo SMALLDATETIME,EntryDate SMALLDATETIME,OverShortValue INT,Perm_ID SMALLINT,ActualPermissionFrom SMALLDATETIME,ActualPermissionTo SMALLDATETIME )
--temp table for overtime records(not fixed)
--------------------------------------------
--prepare temp table to be used directly instead of EmpShiftInOut table
    	------RowID : identity col.
    	------TimeIn,TimeOut,ShiftIn,ShiftOut : cols from EmpShiftInOut in case there is intersection with @permissionFrom or @permissionto values
    	------ and the (shiftin&ShiftOut) or (timeIn&TimeOut)
    	------MinShift_TimeIn : the min. value between (ShiftIn & TimeIn) in each row
    	------MaxShift_TimeOut : the max. value between (ShiftOut & TimeOut) in each row
    	------AfterMe : the min. value between (ShiftIn & TimeIn) in the next row
    	------BeforeMe : The max. value between (ShiftOut & TimeOut) in the previous row
    	------PermFrom & PermTo : will have the permission limits for each row
    	------FirstRow : an indicator for the first row in the table (if the row is the 1st one -- > '1' ... else '0')
    	------LastRow : an indicator for the last row in the table (if the row is the last one -- > '1' ... else '0')
DECLARE @EmpShiftInOutRecords TABLE (RowID INT IDENTITY(1,1),TimeIn SMALLDATETIME,TIMEOUT SMALLDATETIME,ShiftIn SMALLDATETIME,ShiftOut SMALLDATETIME,MinShift_TimeIn SMALLDATETIME,MaxShift_TimeOut SMALLDATETIME,AfterMe SMALLDATETIME,BeforeMe SMALLDATETIME,PermFrom SMALLDATETIME,PermTo SMALLDATETIME,EntryDate SMALLDATETIME,First_Row BIT,Last_Row BIT )
--@EmpShifts table : will contain data about the shift that are between the @FromDate & @ToDate for our employee
DECLARE @EmpShifts TABLE (EntryDate SMALLDATETIME,ShiftType SMALLINT,FromTime SMALLDATETIME,ToTime SMALLDATETIME,FromTime1 SMALLDATETIME,ToTime1 SMALLDATETIME,ToTimeFinal SMALLDATETIME)
---------------------------------------------------------------------------------------------------------------------------------------------------------
--insert data into @EmpShifts temp table
-----------------------------------------
INSERT INTO @EmpShifts
SELECT DISTINCT EmpShift.ShiftDate,TimeShifts.ShiftType,
convert(datetime,convert(char(10),shiftdate,120)+' '+FromTime,120),
convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime,120),
case when FromTime1='00:00' or ltrim(FromTime1)='' or FromTime1='  :  ' then null else convert(datetime,convert(char(10),shiftdate,120)+' '+FromTime1,120) end,
case when ToTime1='00:00' or ltrim(ToTime1)='' or ToTime1='  :  ' then null else convert(datetime,convert(char(10),shiftdate,120)+' '+ToTime1,120) END,null
FROM EmpShift 
LEFT JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo
WHERE EmpShift.EmpId = @EmpId
AND EmpShift.ShiftDate BETWEEN convert(char(10),@FromDate,111)+' 00:00:00' AND convert(char(10),@ToDate,111)+' 00:00:00'

UPDATE @EmpShifts
SET ToTime = CASE WHEN FromTime IS NOT NULL AND ToTime < FromTime THEN dateadd(dd,1,ToTime) ELSE ToTime END 

UPDATE @EmpShifts
SET FromTime1 = CASE WHEN FromTime1 < ToTime THEN dateadd(dd,1,FromTime1) ELSE FromTime1 END

UPDATE @EmpShifts
SET ToTime1 = CASE WHEN ToTime1 < FromTime1 THEN dateadd(dd,1,ToTime1) ELSE ToTime1 END

UPDATE @EmpShifts
SET ToTimeFinal = CASE WHEN ShiftType IN (1,5) THEN ToTime ELSE ToTime1 END
-- Insert Data into Temp Table
------------------------------
IF @FixedHours = 0
BEGIN
	--Start Fixed Hours = false: 
	--"Refer to section 2.1.2" --
	----------------------------- 
	--in this case we insert the entry date = null , overShortValue = null in our temp table
IF ( @ChkNewRecord = 0)
BEGIN
-- in case of calculate prev data : insert the previous permissions into the temp table	
-- taking into consideration :
-- if @overshortType = 1 --> take the overin only (1)
-- if @overshortType = 2 --> take the overout only (2)
-- if @overshortType = 3 --> take the over out of working hours only (3)
-- if @OverShortType = 4 --> take all overtime perms types (1,2,3,4)
-- if @overshortType = 5 --> take the shortin only (5)
-- if @overshortType = 6 --> take the shortout only (6)
-- if @overshortType = 7 --> take the short during only (7)
-- if @OverShortType = 8 --> take all shorttime perms types (5,6,7,8)
INSERT INTO @PermTable 
SELECT  distinct TimePermission.OverShort, 
(case when EmpTimePermission.PermissionFrom > @FromDate then EmpTimePermission.PermissionFrom else @FromDate end) as  PermissionFrom,
case when EmpTimePermission.PermissionTo < @ToDate then EmpTimePermission.PermissionTo else @ToDate end as PermissionTo,NULL,NULL,0,EmpTimePermission.PermissionFrom,EmpTimePermission.PermissionTo
FROM  EmpTimePermission 
INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
where EmpTimePermission.Empid=@Empid and documentstatus=1 
AND TimePermission.OverShort BETWEEN (CASE @OverShortType WHEN 4 THEN 1
                                                          WHEN 8 THEN 5
                                                          ELSE @OverShortType END ) AND @OverShortType
AND ((@FromDate BETWEEN PermissionFrom AND PermissionTo)
OR (@ToDate BETWEEN PermissionFrom AND PermissionTo)
OR (PermissionFrom BETWEEN @FromDate AND @ToDate)
OR (PermissionTo BETWEEN @FromDate AND @ToDate))
AND EmpTimePermission.DocumentNo <>  @DocNo
END
ELSE IF ( @ChkNewRecord = 1)
BEGIN
-- in case of calculate new permission period : 
---- insert the function (fromdate & todate) parameters in the temp table directly
INSERT INTO @PermTable
SELECT @OverShortType,@FromDate,@ToDate,NULL,NULL,0,@ActualFromDate,@ActualToDate

END
------------------------------------------------------------------------------------end of the fixedhours = 0 temp table block
END
ELSE
BEGIN
--start fixedhours = true
--"Refer to section 3.1" --
---------------------------
IF ( @ChkNewRecord = 0)
BEGIN
-- in case of calculate old data : insert the old permissions -in current period- into the temp table	
-- taking into consideration :
-- if @OverShortType in (1,2,3,4) --> take all overtime perms types (1,2,3,4)
-- if @OverShortType in (5,6,7,8) --> take all shorttime perms types (5,6,7,8)
INSERT INTO @PermTable 
SELECT  distinct TimePermission.OverShort, 
(case when EmpTimePermission.PermissionFrom > @FromDate then EmpTimePermission.PermissionFrom else @FromDate end) as  PermissionFrom,
case when EmpTimePermission.PermissionTo < @ToDate then EmpTimePermission.PermissionTo else @ToDate end as PermissionTo,
EmpShiftInOut.EntryDate,0,1,EmpTimePermission.PermissionFrom,EmpTimePermission.PermissionTo
FROM  EmpTimePermission 
INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
LEFT join EmpShiftInOut ON EmpShiftInOut.EmpId = EmpTimePermission.EmpId
AND ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) 
or (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) 
or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) 
or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo))
where EmpTimePermission.Empid=@Empid and documentstatus=1 
AND TimePermission.OverShort BETWEEN (CASE WHEN @OverShortType IN (1,2,3,4) THEN 1 ELSE 5 END ) AND
                                     (CASE WHEN @OverShortType IN (1,2,3,4) THEN 4 ELSE 8 END ) 
AND ((@FromDate BETWEEN PermissionFrom AND PermissionTo)
OR (@ToDate BETWEEN PermissionFrom AND PermissionTo)
OR (PermissionFrom BETWEEN @FromDate AND @ToDate)
OR (PermissionTo BETWEEN @FromDate AND @ToDate))
AND EmpTimePermission.DocumentNo <>  @DocNo

-------------------
--here, we want to check if the shift that intersect with our permission .. can be affected by any other permission in previous period..
--and if yes .. we will add them in the temp table with Perm_ID = 0 .. to calculate the useful parts from them first before
--calculating the useful parts from the permission inside our current period
IF EXISTS(SELECT EntryDate FROM @PermTable)
BEGIN
INSERT INTO @PermTable 
SELECT  distinct tp.OverShort, etp.PermissionFrom as  PermissionFrom,
case when etp.PermissionTo < @FromDate then etp.PermissionTo else @FromDate end as PermissionTo,
esio.EntryDate,0,0,etp.PermissionFrom,etp.PermissionTo
FROM EmpShiftInOut esio 
INNER JOIN @PermTable PT ON esio.EmpId = @EmpId 
AND PT.EntryDate = esio.EntryDate
INNER JOIN EmpTimePermission etp ON esio.EmpId = etp.EmpId 
AND ((esio.ShiftIn BETWEEN etp.PermissionFrom AND etp.PermissionTo)
OR (esio.ShiftOut BETWEEN etp.PermissionFrom AND etp.PermissionTo)
OR (etp.PermissionFrom BETWEEN esio.ShiftIn AND esio.ShiftOut)
OR (etp.PermissionTo BETWEEN esio.ShiftIn AND esio.ShiftOut)
OR (esio.TimeIn BETWEEN etp.PermissionFrom AND etp.PermissionTo)
OR (esio.[TimeOut] BETWEEN etp.PermissionFrom AND etp.PermissionTo)
OR (etp.PermissionFrom BETWEEN esio.TimeIn AND esio.[TimeOut])
OR (etp.PermissionTo BETWEEN esio.TimeIn AND esio.[TimeOut]))
LEFT JOIN TimePermission tp ON tp.PermissionNo = etp.PermissionNo
WHERE etp.EmpId = @EmpId 
AND etp.PermissionFrom < @FromDate
AND etp.DocumentNo <>  @DocNo
AND etp.DocumentStatus = 1
AND tp.OverShort BETWEEN (CASE WHEN @OverShortType IN (1,2,3,4) THEN 1 ELSE 5 END ) AND
                         (CASE WHEN @OverShortType IN (1,2,3,4) THEN 4 ELSE 8 END ) 
                             
	
END
-------------------
END
ELSE IF ( @ChkNewRecord = 1)
BEGIN
-- in case of calculate new permission period : 
---- insert the function parameters in the temp table ,
---- put the Perm_ID = 1 ..
INSERT INTO @PermTable
SELECT distinct @OverShortType,@FromDate,@ToDate,EntryDate,0,1,@ActualFromDate,@ActualToDate
FROM EmpShiftInOut 
WHERE ((EmpShiftInOut.ShiftIn between @ActualFromDate and @ActualToDate) 
or (EmpShiftInOut.ShiftOut between @ActualFromDate and @ActualToDate) 
or (@ActualFromDate between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
or (@ActualToDate between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
or (@ActualFromDate between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (@ActualToDate between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (EmpShiftInOut.TimeIn between @ActualFromDate and @ActualToDate) 
or (EmpShiftInOut.TimeOut between @ActualFromDate and @ActualToDate))
AND EmpShiftInOut.Empid=@Empid
IF (@FromDate <> @ActualFromDate AND @ToDate <= @ActualToDate)
BEGIN
INSERT INTO @PermTable
SELECT distinct @OverShortType,@ActualFromDate,@FromDate,pt.EntryDate,0,0,@ActualFromDate,@ActualToDate
FROM @PermTable pt		
END
----------------------------------------------------------------------------------------------------
--calc. prev perm. that intersect with this entry date
IF EXISTS(SELECT EntryDate FROM @PermTable)
BEGIN
	--if TimeRule is fixed & i'm asking for a new permission :
	-----------------------------------------------------------
	---- we need to calc. the previous perm. that our user had -that affects the same entry date(short or over)-
	---- to allow us to calc. the part that our user will gain from this new permission
	---- Taking into consideration :
	---- if the overshorttype is in(1,2,3,4) --> calc. all the over perm.
	---- if the overshorttype is in(5,6,7,8) --> calc. all the short perm.
	----
	---- in case of prev. perm : put the Perm_ID = 0 ..
INSERT INTO @PermTable
SELECT distinct TimePermission.OverShort,EmpTimePermission.PermissionFrom,EmpTimePermission.PermissionTo,EmpShiftInOut.EntryDate,0,0,EmpTimePermission.PermissionFrom,EmpTimePermission.PermissionTo
from EmpTimePermission 
INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
INNER join EmpShiftInOut ON EmpShiftInOut.EmpId = EmpTimePermission.EmpId
AND EmpShiftInOut.EntryDate IN (SELECT EntryDate FROM @PermTable)
AND ((EmpShiftInOut.ShiftIn between PermissionFrom and PermissionTo) 
or (EmpShiftInOut.ShiftOut between PermissionFrom and PermissionTo) 
or (PermissionFrom between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
or (PermissionTo between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
or (PermissionFrom between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (PermissionTo between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
or (EmpShiftInOut.TimeIn between PermissionFrom and PermissionTo) 
or (EmpShiftInOut.TimeOut between PermissionFrom and PermissionTo))
where EmpTimePermission.Empid=@Empid and documentstatus=1 
AND TimePermission.OverShort BETWEEN (CASE WHEN @OverShortType IN (1,2,3,4) THEN 1 ELSE 5 END ) AND
                                     (CASE WHEN @OverShortType IN (1,2,3,4) THEN 4 ELSE 8 END ) 
                                                          
AND EmpTimePermission.DocumentNo <>  @DocNo

END
----------------------------------------------------------------------------------------------------

END	
------------------------------------------------------------------------------------end of the fixedhours = 1 tempTable block
END	
----------------------------------------------------------------------------------------------------------------------------------------
-- cursor for the inserted data to calc. the wanted period
----------------------------------------------------------
IF @FixedHours = 0
BEGIN
------------------------------------------------------------------------------------Start of the fixedHours = 0 permission calc. block
declare TimePermission CURSOR for
SELECT OverShort,PermissionFrom,PermissionTo,ActualPermissionFrom,ActualPermissionTo    
FROM @PermTable

OPEN TimePermission
FETCH NEXT FROM TimePermission
INTO @OverShort_Cursor,@PermissionFrom_Cursor,@PermissionTo_Cursor,@ActualPermFrom_Cursor,@ActualPermTo_Cursor
WHILE @@FETCH_STATUS = 0
BEGIN
	--"Refer to section 2.2"--
	--------------------------
	--Parameter for the permission lenght
     	SET @PermissionPeriod = isnull(DATEDIFF(s,@PermissionFrom_Cursor,@PermissionTo_Cursor),0)
  	-- Case to calc. only the useful part of the permission :
  	------ Short : if the permission 'has' intersection with a shift 
  	------ Over : if the permission intersects with a [Shift] or [TimeIn & TimeOut] or [Shift ,TimeIn & TimeOut]
  	----------- note .. 'overtotal'
  	-----------  ..if the permission will intersect with more than 1 row & one of the rows has a shift but does not have times..
  	-----------  ex.: if we have splitted shift [9am - 1pm , 2pm - 6pm] and our employee timeIn/Out are [9am - 1:30pm , x - x]
  	-----------  and he has a permission [1pm - 2pm] So, we will calc. the permission in this case = one hour)
	IF NOT EXISTS( SELECT distinct EmpShiftinout.EmpId
	               from EmpShiftinout 
	               WHERE EmpId = @EmpId 
		           AND (
		           	(((EmpShiftInOut.ShiftIn between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
                   or (@PermissionFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@PermissionTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           ) AND @OverShort_Cursor IN (5,6,7,8))
		           OR 
		            (((EmpShiftInOut.ShiftIn between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
                   or (@PermissionFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@PermissionTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@PermissionFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@PermissionTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @PermissionFrom_Cursor AND @PermissionTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @PermissionFrom_Cursor AND @PermissionTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
		           AND ( @OverShort_Cursor IN (1,2,3,4)))
		           
		           ))
		           
     BEGIN
     	-- As the previous condition result is true ..
     	-- we now need to check if the Actual permission period intersects with [Shifts] , [Times] in other period.. 
     	-- with the same condition for short & over
     if  (NOT EXISTS( SELECT EmpShiftInOut.EmpId
     	           FROM EmpShiftInOut 
        	       WHERE EmpShiftInOut.EmpId = @EmpId AND
        	        (((((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND @OverShort_Cursor IN (1,2,3,4))
        	       OR 
        	       (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           ) AND @OverShort_Cursor IN (5,6,7,8))
        	       )
     	
     	    ))     
           BEGIN
           	-- Here, we are sure that our permission does not intersect with anything in our database -- > calculate whole the permission length
           	select @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + (DATEDIFF(s,@PermissionFrom_Cursor,@PermissionTo_Cursor))
           
           END
           ELSE
           BEGIN
           	-- Here, We are sure that the permission actual period intersect with Shift [in case of short],
           	-- 'Shift or TimeIn&TimeOut or Shift&TimeIn&TimeOut'[in case of over] in another period - Previous or Next period - ..
           	IF (@OverShort_Cursor IN (5,6,7,8))
           	BEGIN
           		-- In case of Short .. we will calculate zero .. as to have a short -- > it must be inside our shift .. not outside
           		SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 0
           	
           	END
           	ELSE
           	BEGIN
           		-- "Refer to section 2.2.2"--
           		-----------------------------
           		-- In case of over .. we will calculate whole the part of the permission inside our current period 
           		-- only if we found a shift with [TimeIn or TimeOut missed] .. taking into consideration the permission type [in , out , total , outOfWorking]
           		SET @Perm_AnotherPeriodFirst = 0
           	SET @Perm_AnotherPeriodLast = 0
           	SELECT @Perm_AnotherPeriodFirst = @Perm_AnotherPeriodFirst +
        	      ISNULL( CASE WHEN (EmpShiftInOut.TimeIn IS NULL OR EmpShiftInOut.[TimeOut] IS NULL) AND EmpShiftInOut.ShiftIn IS NOT NULL THEN
        	      	            ISNULL(DATEDIFF(s,@PermissionFrom_Cursor,@PermissionTo_Cursor),0)
        	      	           ELSE 0 END,0)
        	       FROM EmpShiftInOut 
        	       WHERE EmpShiftInOut.EmpId = @EmpId AND
        	        (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND ISNULL(EmpShiftInOut.ShiftOut,EmpShiftInOut.[TimeOut]) < @FromDate
        	       AND @OverShort_Cursor IN (2,3,4)
        	       ORDER BY ISNULL(EmpShiftInOut.ShiftOut,EmpShiftInOut.[TimeOut]) DESC
               
            select @Perm_AnotherPeriodLast = @Perm_AnotherPeriodLast +
        	 	  ISNULL( CASE WHEN (EmpShiftInOut.TimeIn IS NULL OR EmpShiftInOut.[TimeOut] IS NULL) AND EmpShiftInOut.ShiftIn IS NOT NULL THEN
        	      	            ISNULL(DATEDIFF(s,@PermissionFrom_Cursor,@PermissionTo_Cursor),0)
        	      	           ELSE 0 END,0)
        	 	   FROM EmpShiftInOut
        	 	   WHERE EmpShiftInOut.EmpId = @EmpId AND
        	 	   (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND ISNULL(EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn) > @ToDate
        	       AND @OverShort_Cursor IN (1,3,4)
        	       ORDER BY ISNULL(EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn) ASC
        	       
                    	       
        	 SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @Perm_AnotherPeriodFirst+@Perm_AnotherPeriodLast > @PermissionPeriod  THEN @PermissionPeriod ELSE @Perm_AnotherPeriodFirst+@Perm_AnotherPeriodLast END

           	END
          END
     END
     ELSE
     BEGIN
     --"Refer to section 2.2.3.1"--
     ------------------------------     	
     -- Short ( Total or During) : [Here .. we always have Shift in short]
     ------ case when (TimeIn or TimeOut is null) --> calc. the intersection between Perm. & Shift
     ------ else, calc. intersection between Perm. , Shift & Times
    IF @OverShort_Cursor IN (7,8)
	BEGIN
		SET @PermShortTotal_Cursor = 0
		select @PermShortTotal_Cursor = @PermShortTotal_Cursor + 
          CASE   when TimeIn is null OR TimeOut is null then isnull(datediff(s,case when @PermissionFrom_Cursor > ShiftIn then @PermissionFrom_Cursor   ELSE ShiftIn   end,
                       case when @PermissionTo_Cursor < ShiftOut THEN @PermissionTo_Cursor  ELSE ShiftOut end),0)
          else (case when @PermissionFrom_Cursor<TimeIn and TimeIn>ShiftIn then datediff(s,case when @PermissionFrom_Cursor<ShiftIn then ShiftIn else @PermissionFrom_Cursor end,
                       case when @PermissionTo_Cursor>TimeIn then TimeIn else @PermissionTo_Cursor end) else 0 END) +
               (case when @PermissionTo_Cursor>TimeOut and TimeOut<ShiftOut then datediff(s,case when @PermissionFrom_Cursor<TimeOut then TimeOut else @PermissionFrom_Cursor end,
                    case when @PermissionTo_Cursor>ShiftOut then ShiftOut else @PermissionTo_Cursor end) else 0 END) END
		FROM EmpShiftInOut 
		WHERE EmpId = @EmpId 
		AND ((EmpShiftInOut.ShiftIn between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (EmpShiftInOut.ShiftOut between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (@PermissionFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
          or (@PermissionTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		)
		
		--Check if permission period < the shorttotalParameter :
          SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @PermShortTotal_Cursor > @PermissionPeriod  THEN @PermissionPeriod ELSE @PermShortTotal_Cursor END
	END
	--"Refer to section 2.2.3.2"--
	------------------------------ 
	-- ShortIn : [Here .. we always have Shift in short]
	------ case when (TimeIn or TimeOut) is null & ShiftIn intersects with the permission --> calc. the intersection between Perm. & Shift
	------ else calc. the intersection between Perm. , Shift & Times from the [in] side
    IF @OverShort_Cursor IN (5)
    BEGIN
    	SET @PermShortTotal_Cursor = 0
		select @PermShortTotal_Cursor = @PermShortTotal_Cursor + 
    	CASE  WHEN  (TimeIn IS NULL OR TIMEOUT IS NULL) AND ShiftIn IS NOT NULL THEN
    	   	     DATEDIFF(s,(CASE WHEN @PermissionFrom_Cursor < ShiftIn THEN ShiftIn ELSE @PermissionFrom_Cursor END),
    	   	                (CASE WHEN @PermissionTo_Cursor < ShiftIn THEN ShiftIn ELSE (CASE WHEN @PermissionTo_Cursor < ShiftOut THEN @PermissionTo_Cursor ELSE ShiftOut END) END)) 
    	   	               
    	ELSE 
    	  case when @PermissionFrom_Cursor < isnull(TimeIn,ShiftIn) and isnull(TimeIn,ShiftIn) > ShiftIn
               then datediff(s,case when @PermissionFrom_Cursor < ShiftIn then ShiftIn else @PermissionFrom_Cursor end,
                               case when @PermissionTo_Cursor > TimeIn then TimeIn else @PermissionTo_Cursor end) 
          else 0 END END
    	FROM EmpShiftInOut
    	WHERE EmpId = @EmpId 
		AND ((EmpShiftInOut.ShiftIn between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (EmpShiftInOut.ShiftOut between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (@PermissionFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
          or (@PermissionTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		)
		
		--Check if permission period < the shorttotalParameter :
          SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @PermShortTotal_Cursor > @PermissionPeriod  THEN @PermissionPeriod ELSE @PermShortTotal_Cursor END
    END
    --"Refer to section 2.2.3.3"--
    ------------------------------ 
    -- ShortOut : [Here .. we always have Shift in short]
    ------ case when (TimeIn or TimeOut) is null & ShiftOut intersects with the permission --> calc. the intersection between Perm. & Shift
    ------ else calc. the intersection between Perm. , Shift  & Times from the [out] side
    IF @OverShort_Cursor IN (6)
    BEGIN
    	SET @PermShortTotal_Cursor = 0
		select @PermShortTotal_Cursor = @PermShortTotal_Cursor + 
    	CASE WHEN (TIMEOUT IS NULL OR TimeIn IS NULL) AND ShiftOut IS NOT NULL  THEN  
    	    	 DATEDIFF(s,(CASE WHEN @PermissionFrom_Cursor > ShiftOut THEN ShiftOut ELSE (CASE WHEN @PermissionFrom_Cursor < ShiftIn THEN ShiftIn ELSE @PermissionFrom_Cursor END) END),
    	    	            (CASE WHEN @PermissionTo_Cursor > ShiftOut THEN ShiftOut ELSE  @PermissionTo_Cursor  END)) 
    	     
        ELSE 
    	   case when @OverShort_Cursor in (6) and  @PermissionTo_Cursor > isnull(TimeOut,ShiftOut) and isnull(TimeOut,ShiftOut)<ShiftOut
                then datediff(s,case when @PermissionFrom_Cursor<TimeOut then TimeOut else @PermissionFrom_Cursor end,
                                case when @PermissionTo_Cursor>ShiftOut then ShiftOut else @PermissionTo_Cursor end) 
           else 0 end END
    	FROM EmpShiftInOut 
    	WHERE EmpId = @EmpId 
		AND ((EmpShiftInOut.ShiftIn between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (EmpShiftInOut.ShiftOut between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (@PermissionFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
          or (@PermissionTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		)
		
		--Check if permission period < the shorttotalParameter :
          SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @PermShortTotal_Cursor > @PermissionPeriod  THEN @PermissionPeriod ELSE @PermShortTotal_Cursor END
    END
    --"Refer to section 2.2.3.4"--
    ------------------------------ 
   IF @OverShort_Cursor IN (1,2,3,4)
    BEGIN
    	--start of the over time block(temp table idea)
    	------------------------------------------------
    	DELETE FROM @EmpShiftInOutRecords
    	--insert main data from EmpShiftInOut table(TimeIn,TimeOut,ShiftIn,ShiftOut) and
    	--MinShiftTimeIn col : choose it to be (TimeIn or ShiftIn) depending on which of them is the min.
    	--MaxShift_TimeOut col : choose it to be (TimeOut or ShiftOut) depending on which of them is the max.
    	INSERT INTO @EmpShiftInOutRecords(TimeIn,[TIMEOUT],ShiftIn,ShiftOut,MinShift_TimeIn,MaxShift_TimeOut,EntryDate)
        SELECT TimeIn,[TimeOut],ShiftIn,ShiftOut,(CASE WHEN TimeIn IS NULL OR TIMEOUT IS NULL THEN ShiftIn ELSE (CASE WHEN TimeIn < ShiftIn THEN TimeIn ELSE isnull(ShiftIn,TimeIn) END) END),
        (CASE WHEN TimeIn IS NULL OR TIMEOUT IS NULL THEN ShiftOut ELSE (CASE WHEN TimeOut > ShiftOut THEN TimeOut ELSE isnull(ShiftOut,TimeOut) END) END)
        ,EntryDate
        FROM EmpShiftInOut
    	WHERE EmpId = @EmpId 
		AND  (((EmpShiftInOut.ShiftIn between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (EmpShiftInOut.ShiftOut between @PermissionFrom_Cursor and @PermissionTo_Cursor) 
          or (@PermissionFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
          or (@PermissionTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		  OR (@PermissionFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		  OR (@PermissionTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		  OR ((EmpShiftInOut.TimeIn BETWEEN @PermissionFrom_Cursor AND @PermissionTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL))
		  OR ((EmpShiftInOut.TimeOut BETWEEN @PermissionFrom_Cursor AND @PermissionTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL)))
		  )
        ORDER BY entrydate,Entryno
        
        --update the AfterMe col.: by the value of MinShift_TimeIn of the next row 
        --Last_Row : is an indicator for the last row in the temptable
        UPDATE @EmpShiftInOutRecords 
        SET AfterMe = CASE WHEN @OverShort_Cursor IN (2,3,4) THEN ISNULL((SELECT t1.MinShift_TimeIn
                       FROM @EmpShiftInOutRecords t1 WHERE t1.RowID  = t.RowID + 1 ),@PermissionTo_Cursor) ELSE NULL END,
            Last_Row = CASE WHEN (SELECT t1.MinShift_TimeIn FROM @EmpShiftInOutRecords t1 WHERE t1.RowID  = t.RowID + 1 ) IS NULL THEN 1 ELSE 0 END                       
        FROM @EmpShiftInOutRecords t
        
        --update the BeforeMe col. : by the value of the MaxShift_TimeOut of the previous row
        --First_Row : is an indicator for the first row in the temptable
        UPDATE @EmpShiftInOutRecords
        SET BeforeMe = CASE WHEN @OverShort_Cursor IN (2,3,4) THEN NULL ELSE  ISNULL((SELECT t1.MaxShift_TimeOut
              FROM @EmpShiftInOutRecords t1 WHERE t1.RowID  = t.RowID - 1 ),@PermissionFrom_Cursor) END,
            First_Row = CASE WHEN  (SELECT t1.MaxShift_TimeOut FROM @EmpShiftInOutRecords t1 WHERE t1.RowID  = t.RowID - 1 ) IS NULL THEN 1 ELSE 0 END 
        FROM @EmpShiftInOutRecords t                            
        --update the PermTo col. : 
        ------case when ShiftIn is null(I have TimeIn&TimeOut) .. choose between TimeOut and @permissionTo values
        ------case when TimeIn or TimeOut = null(I have ShiftIn&ShiftOut) .. choose between ShiftOut and @permissionTo values taking into consideration
        ----------------that the value must be < AfterMe col.
        ------else (I have TimeIn,TimeOut,ShiftIn&ShiftOut) .. choose between TimeOut and ShiftOut taking into consideration that the value must be < @permissionTo
        IF @OverShort_Cursor in (2,3,4)
        BEGIN
         UPDATE @EmpShiftInOutRecords
         SET PermTo =  (CASE WHEN ShiftIn IS NULL THEN (CASE WHEN t1.[TIMEOUT] <= t2.FromTime AND @OverShortType = 2  THEN
         	                                                 	        (CASE WHEN TimeIn < @PermissionFrom_Cursor THEN @PermissionFrom_Cursor ELSE TimeIn END)
         	                                                 ELSE (CASE WHEN TIMEOUT < @PermissionTo_Cursor THEN TIMEOUT ELSE @PermissionTo_Cursor END) END )
	                         when TimeIn is null or TimeOut is null THEN 
	            	              (CASE WHEN ShiftOut < @PermissionTo_Cursor THEN (CASE WHEN AfterMe < @PermissionTo_Cursor THEN AfterMe ELSE @PermissionTo_Cursor END) ELSE ShiftOut END) 
	                         ELSE (CASE WHEN TIMEOUT > ShiftOut THEN (CASE WHEN TIMEOUT < @PermissionTo_Cursor THEN TIMEOUT ELSE @PermissionTo_Cursor END) ELSE (case when ShiftOut < @PermissionTo_Cursor THEN ShiftOut ELSE @PermissionTo_Cursor END) END)  END)
         FROM @EmpShiftInOutRecords t1  
         LEFT JOIN @EmpShifts t2 ON t1.EntryDate = t2.EntryDate 
        END
        ELSE
        BEGIN
        -- in case of overin :
        --update the PermFrom col. : 
        ------case when ShiftIn is null(I have TimeIn&TimeOut) .. choose between TimeIn and @permissionFrom values
        ------case when TimeIn or TimeOut = null(I have ShiftIn&ShiftOut) .. choose between ShiftIn and @permissionFrom values taking into consideration
        ----------------that the value must be > BeforeMe col.
        ------else (I have TimeIn,TimeOut,ShiftIn&ShiftOut) .. choose between TimeIn and ShiftIn taking into consideration that the value must be > @permissionFrom
         UPDATE @EmpShiftInOutRecords
         SET PermFrom = (CASE WHEN ShiftIn IS NULL THEN (CASE WHEN t1.TimeIn >= t2.ToTimeFinal  THEN
         	                                              	          (CASE WHEN TIMEOUT > @PermissionTo_Cursor THEN @PermissionTo_Cursor ELSE TIMEOUT END) 
         	                                                  ELSE (CASE WHEN TimeIn < @PermissionFrom_Cursor THEN @PermissionFrom_Cursor ELSE TimeIn END)  END )   
	                          WHEN TimeIn IS NULL OR TIMEOUT IS NULL THEN 
	                            	(CASE WHEN ShiftIn > @PermissionFrom_Cursor THEN (CASE WHEN @PermissionFrom_Cursor > BeforeMe THEN @PermissionFrom_Cursor ELSE BeforeMe END) ELSE ShiftIn END)
	                          ELSE (CASE WHEN TimeIn < ShiftIn THEN (CASE WHEN TimeIn > @PermissionFrom_Cursor THEN TimeIn ELSE @PermissionFrom_Cursor END) ELSE ShiftIn END) END)
         FROM @EmpShiftInOutRecords t1 	
         LEFT JOIN @EmpShifts t2 ON t1.EntryDate = t2.EntryDate
        END
        

        --update the PermFrom col. : by the value of the PermTo col of the previous row
        --------taking into consideration : if I'm in the first row then put the @permissionFrom value
        IF @OverShort_Cursor in (2,3,4)
        BEGIN
         UPDATE @EmpShiftInOutRecords
         SET PermFrom = ISNULL((SELECT t2.PermTo FROM @EmpShiftInOutRecords t2 WHERE t2.RowID = t1.RowID - 1 ),@PermissionFrom_Cursor)
         FROM @EmpShiftInOutRecords t1  
        END
        ELSE
        BEGIN
        --update the PermTo col. : by the value of the PermFrom col of the next row
        --------taking into consideration : if I'm in the last row then put the @permissionTo value
         UPDATE @EmpShiftInOutRecords
         SET PermTo =  ISNULL((SELECT t2.PermFrom FROM @EmpShiftInOutRecords t2 
                               WHERE t2.RowID = t1.RowID + 1),@PermissionTo_Cursor)
         FROM @EmpShiftInOutRecords t1  	
        END
        
        SET @PermissionPeriod_First = isnull(DATEDIFF(s,@PermissionFrom_Cursor,(SELECT (CASE WHEN t.MinShift_TimeIn < @PermissionFrom_Cursor THEN @PermissionFrom_Cursor ELSE t.MinShift_TimeIn END) FROM @EmpShiftInOutRecords t WHERE t.First_Row = 1)),0)
        SET @PermissionPeriod_Last = isnull(DATEDIFF(s,(SELECT (CASE WHEN @PermissionTo_Cursor < t1.MaxShift_TimeOut THEN @PermissionTo_Cursor ELSE t1.MaxShift_TimeOut END) FROM @EmpShiftInOutRecords t1 WHERE t1.Last_Row = 1),@PermissionTo_Cursor),0)
        SET @Perm_AnotherPeriodFirst = 0
        SET @Perm_AnotherPeriodLast = 0
        
    --"Refer to section 2.2.3.4 - B.1"--
    ------------------------------------         
    -- OverTotal & OverOutOfWorkingHours	
    IF @OverShort_Cursor IN (3,4)
    BEGIN    
    -- [Here .. we always have Shift or (TimeIn&TimeOut)]
    ------ case when Shift is null --> calc. the intersection between Perm. & Times
    ------ case when (TimeIn or TimeOut) is null --> calc. the intersection with the Shift
    ------ else calc. the intersection between the Perm.,Shift & Time
    	SET @PermOverTotal_Cursor = 0
        SET @Perm_AnotherPeriodFirst = 0
    	SET @Perm_AnotherPeriodLast = 0
    	SELECT @PermOverTotal_Cursor = @PermOverTotal_Cursor + 
        case when ShiftIn is null and (TimeIn is not null) and (timeout is not null) then datediff(s,case when PermFrom<TimeIn then TimeIn else PermFrom end,
                         case when PermTo>TimeOut then TimeOut else PermTo end)
             WHEN TimeIn IS NULL OR TIMEOUT IS NULL THEN 
             	  isnull(DATEDIFF(s,(CASE WHEN PermFrom < ShiftIn THEN PermFrom ELSE ShiftIn END),ShiftIn),0) +
             	  ISNULL(DATEDIFF(s,ShiftOut,(CASE WHEN PermTo > ShiftOut THEN PermTo ELSE ShiftOut END)),0)
        else case when PermFrom < ShiftIn and isnull(TimeIn,ShiftIn) < ShiftIn then 
        	      datediff(s,case when PermFrom<TimeIn then TimeIn else PermFrom end,case when PermTo>ShiftIn then ShiftIn else PermTo end) 
        	      else 0 end + 
             case when PermTo>ShiftOut and isnull(TimeOut,ShiftOut)>ShiftOut then 
             	  datediff(s,case when PermFrom<ShiftOut then ShiftOut else PermFrom end,case when PermTo>TimeOut then TimeOut else PermTo end) 
             	  else 0 end 
       END, @Perm_AnotherPeriodFirst = @Perm_AnotherPeriodFirst +
        CASE WHEN First_Row = 1 THEN 
        	      ISNULL((SELECT TOP 1 CASE WHEN (EmpShiftInOut.TimeIn IS NULL OR EmpShiftInOut.[TimeOut] IS NULL) AND EmpShiftInOut.ShiftIn IS NOT NULL THEN
        	      	            ISNULL(DATEDIFF(s,@PermissionFrom_Cursor,MinShift_TimeIn),0)
        	      	            ELSE 0 END
        	       FROM EmpShiftInOut 
        	       WHERE EmpShiftInOut.EmpId = @EmpId AND
        	        (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND ISNULL(EmpShiftInOut.ShiftOut,EmpShiftInOut.[TimeOut]) < @FromDate
        	       ORDER BY ISNULL(EmpShiftInOut.ShiftOut,EmpShiftInOut.[TimeOut]) DESC),0)
        	 ELSE 0 END ,@Perm_AnotherPeriodLast = @Perm_AnotherPeriodLast +
        	 CASE WHEN Last_Row = 1 THEN 
        	 	  ISNULL((SELECT TOP 1 CASE WHEN (EmpShiftInOut.TimeIn IS NULL OR EmpShiftInOut.[TimeOut] IS NULL) AND EmpShiftInOut.ShiftIn IS NOT NULL THEN
        	      	            ISNULL(DATEDIFF(s,MaxShift_TimeOut,@PermissionTo_Cursor),0)
        	      	            ELSE 0 END
        	 	   FROM EmpShiftInOut
        	 	   WHERE EmpShiftInOut.EmpId = @EmpId AND
        	 	   (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND ISNULL(EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn) > @ToDate
        	       ORDER BY ISNULL(EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn) ASC),0)
        	 	  ELSE 0 END	  
    	FROM @EmpShiftInOutRecords 
          
          --Check if permission period > the overtotalParameter :
          SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @PermOverTotal_Cursor+@Perm_AnotherPeriodFirst+@Perm_AnotherPeriodLast > @PermissionPeriod  THEN @PermissionPeriod ELSE @PermOverTotal_Cursor+@Perm_AnotherPeriodFirst+@Perm_AnotherPeriodLast END                     
    END 
    --"Refer to section 2.2.3.4 - B.2"--
    ------------------------------------
    -- OverEarlyIn : [Here .. we always have Shift or (TimeIn&TimeOut)]
    ------ case when Shift is null --> calc. the intersection between Perm. & Times
    ------ case when (TimeIn or TimeOut) is null --> calc. the intersection with the ShiftIn
    ------ else calc. the intersection between the Perm.,ShiftIn & TimeIn
    IF @OverShort_Cursor IN (1)
    BEGIN
       SET @PermOverTotal_Cursor =0
       SET @Perm_AnotherPeriodLast = 0
       SELECT @PermOverTotal_Cursor = @PermOverTotal_Cursor + 
       CASE WHEN ShiftIn IS NULL THEN 
       	         ISNULL((DATEDIFF(s,(CASE WHEN PermFrom < TimeIn THEN TimeIn ELSE (CASE WHEN PermFrom > TIMEOUT THEN TIMEOUT  ELSE PermFrom  END) END ), (CASE WHEN PermTo > TIMEOUT THEN TIMEOUT ELSE PermTo END) )),0)
            WHEN (TimeIn IS NULL OR TIMEOUT IS NULL) AND ShiftIn IS NOT NULL THEN (DATEDIFF(s,(CASE WHEN PermFrom < ShiftIn THEN PermFrom ELSE ShiftIn END),(CASE WHEN PermTo > ShiftIn THEN ShiftIn ELSE PermTo END)))
       ELSE
           (case when isnull(TimeIn,ShiftIn) < ShiftIn and PermFrom < ShiftIn then 
           datediff(s,case when PermFrom<TimeIn then TimeIn else PermFrom end,case when ShiftIn<PermTo then ShiftIn else PermTo end) else 0 END)
       END,@Perm_AnotherPeriodLast = @Perm_AnotherPeriodLast +
        	 CASE WHEN Last_Row = 1 THEN 
        	 	  ISNULL((SELECT TOP 1 CASE WHEN (EmpShiftInOut.TimeIn IS NULL OR EmpShiftInOut.[TimeOut] IS NULL) AND EmpShiftInOut.ShiftIn IS NOT NULL THEN
        	      	            ISNULL(DATEDIFF(s,MaxShift_TimeOut,@PermissionTo_Cursor),0)
        	      	            ELSE 0 END
        	 	   FROM EmpShiftInOut
        	 	   WHERE EmpShiftInOut.EmpId = @EmpId AND
        	 	   (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND ISNULL(EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn) > @ToDate
        	       ORDER BY ISNULL(EmpShiftInOut.ShiftIn,EmpShiftInOut.TimeIn) ASC),0)
        	 	  ELSE 0 END	    
       FROM @EmpShiftInOutRecords
          
       --Check if permission period > the overtotalParameter :
          SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @PermOverTotal_Cursor+@Perm_AnotherPeriodLast > @PermissionPeriod  THEN @PermissionPeriod ELSE @PermOverTotal_Cursor+@Perm_AnotherPeriodLast END
                                	
    END 
    --"Refer to section 2.2.3.4 - B.3"--
    ------------------------------------
    -- OverLateOut : [Here .. we always have Shift or (TimeIn&TimeOut)]
    ------ case when Shift is null --> calc. the intersection between Perm. & Times
    ------ case when (TimeIn or TimeOut) is null --> calc. the intersection between the Perm. & ShiftOut
    ------ else calc. the intersection between the Perm.,ShiftOut & TimeOut
    IF @OverShort_Cursor IN (2)
    BEGIN
    	SET @PermOverTotal_Cursor = 0
        SET @Perm_AnotherPeriodFirst = 0
    	SELECT @PermOverTotal_Cursor = @PermOverTotal_Cursor +  
    	CASE WHEN ShiftOut IS NULL THEN 
    		    ISNULL((DATEDIFF(s,(CASE WHEN PermFrom < TimeIn THEN TimeIn ELSE (CASE WHEN PermFrom > TIMEOUT THEN TIMEOUT  ELSE PermFrom  END) END ),(CASE WHEN PermTo > TIMEOUT THEN TIMEOUT ELSE PermTo END) )),0)
             WHEN (TIMEOUT IS NULL OR TimeIn IS NULL) AND ShiftOut IS NOT NULL THEN 
             	DATEDIFF(s,(CASE WHEN PermFrom < ShiftOut THEN ShiftOut ELSE PermFrom END),(CASE WHEN PermTo < ShiftOut THEN ShiftOut ELSE PermTo END))    	
    	ELSE
    		  case when  isnull(TimeOut,ShiftOut)>ShiftOut and PermTo>ShiftOut then 
                datediff(s,case when PermFrom<ShiftOut then ShiftOut else PermFrom end,case when PermTo<TimeOut then PermTo else TimeOut end) 
              
              else 0 END
    	END,@Perm_AnotherPeriodFirst = @Perm_AnotherPeriodFirst +
        CASE WHEN First_Row = 1 THEN 
        	      ISNULL((SELECT TOP 1 CASE WHEN (EmpShiftInOut.TimeIn IS NULL OR EmpShiftInOut.[TimeOut] IS NULL) AND EmpShiftInOut.ShiftIn IS NOT NULL THEN
        	      	            ISNULL(DATEDIFF(s,@PermissionFrom_Cursor,MinShift_TimeIn),0)
        	      	            ELSE 0 END
        	       FROM EmpShiftInOut 
        	       WHERE EmpShiftInOut.EmpId = @EmpId AND
        	       (((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
                   or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
                   or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)
		           OR (@ActualPermFrom_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut)
		           OR (@ActualPermTo_Cursor BETWEEN EmpShiftInOut.TimeIn AND EmpShiftInOut.TimeOut )
		           OR ((EmpShiftInOut.TimeIn BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeOut IS NOT NULL ))
		           OR ((EmpShiftInOut.TimeOut BETWEEN @ActualPermFrom_Cursor AND @ActualPermTo_Cursor) AND (EmpShiftInOut.TimeIn IS NOT NULL )))
        	       ) AND ISNULL(EmpShiftInOut.ShiftOut,EmpShiftInOut.[TimeOut]) < @FromDate
        	       ORDER BY ISNULL(EmpShiftInOut.ShiftOut,EmpShiftInOut.[TimeOut]) DESC),0)
        	 ELSE 0 END       
        FROM @EmpShiftInOutRecords   
        
        --Check if permission period > the overtotalParameter :
          SELECT @PermissionSeconds_Cursor = @PermissionSeconds_Cursor + 
                 CASE WHEN @PermOverTotal_Cursor+@Perm_AnotherPeriodFirst > @PermissionPeriod  THEN @PermissionPeriod ELSE @PermOverTotal_Cursor+@Perm_AnotherPeriodFirst END    
          
    END
    --end of over time block(temp table idea)
    END
     	
    END	

FETCH NEXT FROM TimePermission
INTO @OverShort_Cursor,@PermissionFrom_Cursor,@PermissionTo_Cursor,@ActualPermFrom_Cursor,@ActualPermTo_Cursor
END

CLOSE TimePermission
DEALLOCATE TimePermission
---------------------------------------------------------------------------------------end of fixedHours = 0 permission calc. block
END
ELSE
BEGIN
---------------------------------------------------------------------------------------start of fixedHours = 1 permission calc. block
-- here, we select records from temp table into our cursor .. 
-- order by Perm_ID,EntryDate,PermissionFrom asc :

declare TimePermFixedHours cursor for
SELECT distinct OverShort,PermissionFrom,PermissionTo,EntryDate,Perm_ID,ActualPermissionFrom,ActualPermissionTo  
FROM @PermTable
ORDER BY Perm_ID,EntryDate,PermissionFrom ASC

OPEN TimePermFixedHours
IF @@CURSOR_ROWS = 0 AND @ChkNewRecord = 1
BEGIN
	
	RETURN (DATEDIFF(s,@FromDate,@ToDate))
END
FETCH NEXT FROM TimePermFixedHours
INTO @OverShort_Cursor,@PermissionFrom_Cursor,@PermissionTo_Cursor,@EntryDateTemp_Cursor,@PermID_Cursor,@ActualPermFrom_Cursor,@ActualPermTo_Cursor
WHILE @@FETCH_STATUS = 0
BEGIN
	--"Refer to section 3.2.1"--
	----------------------------
	----the below if condition to avoid the permission intersection with 2 rows with dfferent entry dates as the below ex.
	-- entrydate='2012/02/03' shiftin='2012/02/03 22:00' shiftout='2012/02/04 10:00' timein='2012/02/03 22:00' timeout='2012/02/04 22:00'
	-- entrydate='2012/02/04' shiftin='2012/02/04 22:00' shiftout='2012/02/05 10:00' timein='2012/02/04 22:10' timeout='2012/02/05 18:00'
	---- permissionfrom ='2012/02/04 10:00' permissionto='2012/02/04 22:00' and this permission will intersect with the 2 dates and the query will calc the povertotal for the 2 rows
	-- entrydate='2012/02/03' povertotal=14 hours
	--entrydate='2012/02/04' povertotal=8 hours 
	--the total permission over hours for the 2 rows=14+8=22  although the actual permmission hours=14 
	IF not exists(SELECT  distinct *
       FROM  EmpShiftInOut 
	   WHERE Empid=@Empid  
	   AND entrydate < @EntryDateTemp_Cursor
	   AND ((EmpShiftInOut.ShiftIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor)
            OR (EmpShiftInOut.ShiftOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor)
            or (@ActualPermFrom_Cursor between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
            or (@ActualPermTo_Cursor between EmpShiftInOut.TimeIn and EmpShiftInOut.TimeOut) 
            or (EmpShiftInOut.TimeIn between @ActualPermFrom_Cursor and @ActualPermTo_Cursor) 
            or (EmpShiftInOut.TimeOut between @ActualPermFrom_Cursor and @ActualPermTo_Cursor)
            or (@ActualPermFrom_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut) 
            or (@ActualPermTo_Cursor between EmpShiftInOut.ShiftIn and EmpShiftInOut.ShiftOut)))
BEGIN
 --calc. working seconds & shift seconds from empshiftinout for certain entrydate
SELECT @WorkingSeconds=sum(isnull(datediff(s,EmpShiftInOut.TimeIn, EmpShiftInOut.TimeOut),0)) 
,@ShiftSeconds=  sum(isnull(datediff(s,EmpShiftInOut.ShiftIn, EmpShiftInOut.Shiftout),0))
 FROM EmpShiftInOut  WHERE entrydate=@EntryDateTemp_Cursor AND EmpId = @EmpId
 --calc. the permissions seconds(the user can have benefit from them) from our temp table
 SET @PermissionSeconds_Cursor = (SELECT SUM(OverShortValue) FROM @PermTable WHERE EntryDate = @EntryDateTemp_Cursor ) 
 --calc. the current cursor row -permission value-
 SELECT @PermissionSeconds=isnull(datediff(s,@PermissionFrom_Cursor, @PermissionTo_Cursor),0)
 
 --"Refer to section 3.2.2"--
 ----------------------------
  if @OverShort_Cursor in (5,6,7,8)
  BEGIN
  	IF isnull(@ShiftSeconds,0) = 0
  	BEGIN  	
  		-- Short : if no shift --> calc. all the permission period	
  		UPDATE @PermTable
  		SET	OverShortValue = @PermissionSeconds 
  		WHERE PermissionFrom = @PermissionFrom_Cursor AND PermissionTo = @PermissionTo_Cursor
  		--AND isnull(EntryDate,'1990-01-01') = isnull(@EntryDateTemp_Cursor,'1900-01-01') 
  		  		AND ((EntryDate IS NULL AND @EntryDateTemp_Cursor IS null)OR (EntryDate=@EntryDateTemp_Cursor))
  		AND OverShort = @OverShort_Cursor
  	END
  	ELSE
  	BEGIN
  	 -- if we have a shift --> calc. the diff. between Shift ,Times & perm.
  	 UPDATE @PermTable
  	 SET OverShortValue = 
          (case when @PermissionSeconds <> 0 then 
          	  (CASE WHEN @WorkingSeconds < @ShiftSeconds THEN 
          		    (CASE WHEN @shiftseconds-@WorkingSeconds-@PermissionSeconds_Cursor > @PermissionSeconds THEN @PermissionSeconds 
          		          ELSE @shiftseconds-@WorkingSeconds-@PermissionSeconds_Cursor end) 
               ELSE 0 END) 
          ELSE 0 END)
  	 WHERE PermissionFrom = @PermissionFrom_Cursor AND PermissionTo = @PermissionTo_Cursor 
  	 AND EntryDate = @EntryDateTemp_Cursor AND OverShort = @OverShort_Cursor 	
  	END
  END
   
    
  if @OverShort_Cursor in (1,2,3,4)   
  BEGIN
  	IF (isnull(@WorkingSeconds,0) = 0 AND isnull(@ShiftSeconds,0) = 0) OR (ISNULL(@shiftSeconds,0) <> 0 AND ISNULL(@WorkingSeconds,0) = 0)
  	BEGIN
  		-- case no shift & no working hours --> calc. all the perm
  		-- case no working hours & there is a shift --> calc. all the perm
  		UPDATE @PermTable
  		SET	OverShortValue = @PermissionSeconds 
  		WHERE PermissionFrom = @PermissionFrom_Cursor AND PermissionTo = @PermissionTo_Cursor
  		--AND isnull(EntryDate,'1990-01-01') = isnull(@EntryDateTemp_Cursor,'1900-01-01') 
  		AND ((EntryDate IS NULL AND @EntryDateTemp_Cursor IS null)OR (EntryDate=@EntryDateTemp_Cursor))
  		AND OverShort = @OverShort_Cursor
  	END
  	ELSE
  	BEGIN
     -- if we have shift & working seconds --> calc. the diff between Shift,Times & Perm.
  	 UPDATE @PermTable
  	 SET OverShortValue = 
       (case when @PermissionSeconds <> 0 then 
       	    (CASE WHEN @WorkingSeconds>@shiftseconds THEN 
       	    	  (CASE WHEN @WorkingSeconds-@shiftseconds-@PermissionSeconds_Cursor >@PermissionSeconds THEN @PermissionSeconds 
       	    	   ELSE @WorkingSeconds-@shiftseconds-@PermissionSeconds_Cursor end) 
       	     ELSE 0 END) 
       ELSE 0 END )
       WHERE PermissionFrom = @PermissionFrom_Cursor AND PermissionTo = @PermissionTo_Cursor 
  	   AND EntryDate = @EntryDateTemp_Cursor AND OverShort = @OverShort_Cursor  
  	END
  END 
      
    end
  
FETCH NEXT FROM TimePermFixedHours
INTO @OverShort_Cursor,@PermissionFrom_Cursor,@PermissionTo_Cursor,@EntryDateTemp_Cursor,@PermID_Cursor,@ActualPermFrom_Cursor,@ActualPermTo_Cursor  
END
CLOSE TimePermFixedHours
DEALLOCATE TimePermFixedHours
 	
-------------------------------------------------------------------------------emd of fixedHours = 1 , permission calc. block
END	
--"Refer to section 4" --
-------------------------
-- To calc. the value to be returned :
---- in case of NOT fixed : take the parameter '@PermissionSeconds_Cursor' value..
---- in case of fixed : get the values from the temp table where Perm_ID = 1

DECLARE @FinalPermissionPeriod AS INT                                                                       
SET @FinalPermissionPeriod =  ISNULL((  CASE WHEN @FixedHours = 1 THEN  
	                                             (SELECT sum(t.OverShortValue) FROM @PermTable t WHERE t.Perm_ID=1)                 
                                             ELSE @PermissionSeconds_Cursor end  ),0)
-------- --------

RETURN @FinalPermissionPeriod	

END

GO

