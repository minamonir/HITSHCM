CREATE FUNCTION [dbo].[periodstart]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS
BEGIN
  declare @thedate smalldatetime
 -- if @year=0  select @year=cyear, @period=cmonth from payrollgroup where payrollgroup=@payrollgroup	
   
if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
   if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
  
 -- deduct the period by 1 to get previous period end
--  if @period=12 
--    begin
--      set @period=1
--      set @year=@year-1
 --  end
 --else set @period=@period-1

  if @period=1 
    begin
      select @period=noofperiods  from payrollgroup where payrollgroup=@payrollgroup
      set @year=@year-1
   end
 else set @period=@period-1



 select @thedate=dbo.periodend(@payrollgroup,@period,@year)
set @thedate=dateadd(dd,1,@thedate)
 
	

RETURN @thedate
END

GO

