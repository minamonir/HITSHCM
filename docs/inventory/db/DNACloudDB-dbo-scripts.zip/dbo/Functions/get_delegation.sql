
--calculate the no of vacation days for specific vacation category in a certain period 

CREATE    FUNCTION [dbo].[get_delegation]
(@requesterprofileid as int , @delegatedprofileid as int ,
 @ssdocno as int,@lang as nchar(1),@DocumentNo AS int=0)
 
RETURNS nvarchar(max)
AS
	BEGIN
	declare @name as nvarchar(max),@aname as nvarchar(max) ,@result as nvarchar(max)

--declare @assignmentid as int 
--declare @SSDocType as int
DECLARE @GetDate AS smalldatetime
SELECT @GetDate= HitsGetDate.todate FROM HitsGetDate

--set @assignmentid = 0
--select @SSDocType=SSDocType from ssdocument where SSDocNo = @SSDocNo

--if @SSDocType = 6 
--select @assignmentid = isnull(assignmentid,0) from empappraisal  where empid = @requesterprofileid and documentno = @DocumentNo

--DECLARE @ssgroup AS INT
--IF @assignmentid=0
--BEGIN
-- select  @ssgroup= ssgroup from empassignment where empid = @requesterprofileid
--END
--ELSE
--BEGIN
--select  @ssgroup=ssgroup from Appassignment where empid = @requesterprofileid AND Appassignment.AssignmentId=@assignmentid
--end

set @result = N' '

		declare delegation cursor  for 
		SELECT RTRIM(ltrim(dbo.HitsStr(ISNULL(EmployeeId,'')) COLLATE database_default + N' ' + rtrim(Name) COLLATE database_default + N' : ' + rolename COLLATE database_default )), 
	RTRIM(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(aName) COLLATE database_default + N'  :  ' + roleaname COLLATE database_default )) 
	FROM WFDocApproval
	INNER JOIN Profile ON Profile.ProfileId = ISNULL(WFDocApproval.DelegatedBy,0) AND delegated = 1
	AND WFDocApproval.empid = @requesterprofileid AND WFDocApproval.DocumentNo = @DocumentNo 
	  AND WFDocApproval.SSDocNo = @ssdocno 
	left JOIN EmpAssignment ON EmpAssignment.EmpId = Profile.ProfileId
	left JOIN ssrole ON SSRole.RoleId = WFDocApproval.RoleId
	WHERE  ISNULL(ApprovalProfileId,0) = @delegatedprofileid 	
	AND (@GetDate BETWEEN WFDocApproval.DelegateFrom AND WFDocApproval.DelegateTo)
		

--IF @assignmentid=0
--	BEGIN
--		declare delegation cursor  for 
	--SELECT RTRIM(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(Name) COLLATE database_default + N' : ' + rolename COLLATE database_default )), 
	--RTRIM(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(aName) COLLATE database_default + N'  :  ' + roleaname COLLATE database_default )) 
	--FROM WFDelegate
	--INNER JOIN WFDocApproval ON WFDelegate.RoleId = WFDocApproval.RoleId 
	--AND WFDelegate.SSDocNo = WFDocApproval.SSDocNo AND WFDelegate.DelegatedProfileId = WFDocApproval.ApprovalProfileId
	--AND WFDocApproval.empid = @requesterprofileid AND WFDocApproval.DocumentNo = @DocumentNo  AND WFDocApproval.SSDocNo = @ssdocno 
	--AND Delegated = 1 AND ApprovalProfileId = @delegatedprofileid 	AND WFDelegate.ApprovalStatus=1
	--AND (CONVERT(nchar(10), @GetDate, 111) BETWEEN WFDocApproval.DelegateFrom AND WFDocApproval.DelegateTo)
	--INNER JOIN Profile ON Profile.ProfileId = WFDelegate.ProfileId 
	--INNER JOIN EmpAssignment ON EmpAssignment.EmpId = Profile.ProfileId
	--INNER JOIN ssrole ON SSRole.RoleId = WFDocApproval.RoleId
		 
		
 


	--SELECT   rtrim(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(Name) COLLATE database_default + N' : ' + rolename COLLATE database_default )), rtrim(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(aName) COLLATE database_default + N'  :  ' + roleaname COLLATE database_default ))
	--FROM         WFDelegate INNER JOIN
	--SSGroupRole ON WFDelegate.RoleId = SSGroupRole.RoleId AND 
	--WFDelegate.ProfileId = SSGroupRole.ProfileId AND  SSGroupRole.SSGroup = @ssgroup
	--INNER JOIN SSDocument ON WFDelegate.SSDocNo = SSDocument.SSDocNo
	--inner join profile on WFDelegate.ProfileId = profile.profileid 
	--inner join empassignment on profile.profileid = empassignment.empid
	--inner join ssrole on ssrole.roleid = WFDelegate.RoleId 
	--WHERE     WFDelegate.DelegatedProfileId =        @delegatedprofileid
 --   AND WFDelegate.ApprovalStatus=1	and WFDelegate.ssdocno = @ssdocno
	--and SSGroupRole.SSGroup = @ssgroup
	----( select  ssgroup from empassignment where empid = @requesterprofileid)
	--AND (CONVERT(nchar(10), @GetDate, 111) BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo)

--	END
--ELSE
--	BEGIN
--		declare delegation cursor  for 
--	SELECT   rtrim(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(Name) COLLATE database_default + N' : ' + rolename COLLATE database_default )), rtrim(ltrim(dbo.HitsStr(employeeid) COLLATE database_default + N' ' + rtrim(aName) COLLATE database_default + N'  :  ' + roleaname COLLATE database_default ))
--	FROM         WFDelegate INNER JOIN
--	SSGroupRole ON WFDelegate.RoleId = SSGroupRole.RoleId AND 
--	WFDelegate.ProfileId = SSGroupRole.ProfileId AND  SSGroupRole.SSGroup = @ssgroup
--	INNER JOIN SSDocument ON WFDelegate.SSDocNo = SSDocument.SSDocNo
--	inner join profile on WFDelegate.ProfileId = profile.profileid 
--	inner join empassignment on profile.profileid = empassignment.empid
--	inner join ssrole on ssrole.roleid = WFDelegate.RoleId 
--	WHERE     WFDelegate.DelegatedProfileId =        @delegatedprofileid
--	AND WFDelegate.ApprovalStatus=1
--	and WFDelegate.ssdocno = @ssdocno
--	and SSGroupRole.SSGroup = @ssgroup
--	--( select  ssgroup from Appassignment where empid = @requesterprofileid AND Appassignment.AssignmentId=@assignmentid)
--	AND (CONVERT(nchar(10), @GetDate, 111) BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo)
--	END


OPEN delegation

FETCH NEXT FROM delegation 
INTO  @name,@aname

WHILE @@FETCH_STATUS = 0
BEGIN
if @lang= N'E'
set @result = @result + @name+nchar(13)+nchar(10)
else
set @result = @result + @aname+nchar(13)+nchar(10)

   FETCH NEXT FROM delegation 
   INTO  @name,@aname
END

CLOSE delegation
DEALLOCATE delegation

return substring(@result,2,4000)

end

GO

