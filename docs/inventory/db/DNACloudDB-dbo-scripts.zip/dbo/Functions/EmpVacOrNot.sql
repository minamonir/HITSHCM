
		    CREATE FUNCTION [dbo].[EmpVacOrNot](@empid AS INT,@date AS SMALLDATETIME)
			RETURNS SMALLINT  AS  
			BEGIN 
			declare @VacOrNot as smallint,@AbsentCode as smallint,@workseconds as int,@ShiftSeconds as int ,@vaccode as smallint
			,@PShortSeconds as INT,@Isholiday AS INT , @IsDayOff AS int ,@AbsentToPayCode as smallint

----this fn check if the specified date is a vacation for the employee or not
----@VacOrNot=0  absent  day without vacation record
----@vacOrNot=1 entered absent vacation in vacation module
----@VacOrNot=2 there is incomplete time keeping record
----@vacOrNot=3 complete timekeeping record
----@VacOrNot=4 this is  vacation date 
----@VacOrNot=5 complete without shift assignment
----@VacOrNot=6 absent day with permission

			set @AbsentCode =0
			set @VacOrNot=0
			set @workSeconds=0
			SET @Shiftseconds=0
			SET @AbsentToPayCode =0

			DECLARE @vacpack INT 
			SELECT @vacpack = dbo.GetOldValue(@empid,19,DATEADD(d,1,@date),0)

			--SELECT @Isholiday=ISNULL(holiday,0) FROM  EmpAssignment LEFT JOIN Holidays ON Holidays.vacpack = EmpAssignment.VacPack WHERE EmpId=@empid AND Holidays.date=@date AND holiday=1
			SELECT @Isholiday=holiday FROM  Holidays WHERE Holidays.date=@date AND holiday=1 AND Holidays.vacpack=@vacpack

			--SELECT @IsDayOff = (CASE WHEN DATEPART(dw,@date) =  v.doffday1 THEN 1 
			--			WHEN DATEPART(dw,@date) =  v.doffday2 THEN 1 ELSE 0 END) 
			--		FROM vacpack v 
			--		LEFT JOIN EmpAssignment ON EmpAssignment.VacPack = v.vacpack 
			--		WHERE EmpId=@empid AND v.dofftype=1

			SELECT @IsDayOff = (CASE WHEN DATEPART(dw,@date) =  v.doffday1 THEN 1 
			WHEN DATEPART(dw,@date) =  v.doffday2 THEN 1 ELSE 0 END) 
		     FROM  vacpack v  
	      	WHERE v.vacpack=@vacpack AND v.dofftype=1

			SELECT @AbsentCode=ISNULL(VacAbsent,0),@AbsentToPayCode=ISNULL(VacAbsentToPay,0)  FROM empassignment LEFT JOIN Timerules ON empassignment.timerule=timerules.timerule WHERE empid=@empid AND UseHoli=1

			SELECT @VacOrNot=COUNT(*) , @vaccode=ISNULL(MAX(Empvacat.vaccode),0) FROM Empvacat 
			LEFT JOIN Vacation ON Vacation.vaccode = Empvacat.VacCode

			WHERE (empid=@empid) 
			AND (@date BETWEEN CONVERT(SMALLDATETIME,CONVERT(NCHAR(12),Fromdate),103) AND CONVERT(SMALLDATETIME,CONVERT(NCHAR(12),todate),103))
			AND vacstatus=1 AND (Vacation.DayFactor>=1 OR Vacation.DayFactor<=0)--and vaccode <>@AbsentCode
			--and (@date between Fromdate and todate)and vacstatus=1 --and vaccode <>@AbsentCode
			SET @VacOrNot=CASE WHEN @vaccode NOT IN (@AbsentCode,@AbsentToPayCode) AND @VacOrNot>0 THEN 4 WHEN @VacOrNot>0 AND  @vaccode IN (@AbsentCode,@AbsentToPayCode) THEN 1 ELSE 0 END
			IF @VacOrNot=0
			BEGIN
			SELECT @WorkSeconds=SUM(workseconds),@ShiftSeconds=SUM(shiftseconds) ,@PShortSeconds=SUM(PShortSeconds) FROM empshiftinout WHERE (empid=@empid) AND (EntryDate=@date) 
			SELECT @VacOrNot=COUNT(*) FROM empshiftinout WHERE  (empid=@empid) AND (EntryDate=@date) AND ((timein IS NULL AND timeout IS NOT NULL) OR (timein IS NOT NULL AND timeout IS NULL) )
			SET @VacOrNot=CASE WHEN @VacOrNot<>0 THEN 2  WHEN @VacOrNot=0 AND ((@WorkSeconds>0  AND @Shiftseconds<>0) OR  @Shiftseconds=60) THEN 3
			WHEN @VacOrNot=0 AND @WorkSeconds>0  AND @Shiftseconds=0 THEN 5 WHEN @PShortSeconds<>0  OR @Isholiday=1 OR @IsDayOff = 1  THEN 6 ELSE 0 END
			--  when @VacOrNot=0 and @WorkSeconds>0  and @Shiftseconds=0 then 5 else 0 end
			END

			RETURN @VacOrNot
			END

GO

