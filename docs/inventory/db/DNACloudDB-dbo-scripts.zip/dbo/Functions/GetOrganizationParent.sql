
CREATE    FUNCTION [dbo].[GetOrganizationParent]
  (@Organization smallint, @OrganizationType smallint,@versionno  smallint,@corn  smallint , @lang  nchar(1))
RETURNS  nvarchar(250)
as
BEGIN 
declare @returntype as smallint, @returnorg as smallint  , @returnname as nvarchar(250)  
  select @returntype=organizationtype from organization where organization=@organization 
  
  set @returnorg=0
  if @returntype<@OrganizationType set @returnorg=0
  if @returntype=@OrganizationType set @returnorg=@Organization
  if @returntype>@OrganizationType  
    begin
      declare @Organizationparent as smallint, @parenttype as smallint, @counter as smallint, @maxcounter as smallint
      set @parenttype=@returntype
      set @Organizationparent=@Organization
      set @counter=1
      set @maxcounter =@parenttype+1
      while @counter<@maxcounter
         begin  
           select @Organizationparent=Organizationparent  from OrganizationStructure  where Organization=@Organizationparent and VersionNo=@VersionNo
           if (@Organizationparent is null) break
           select @parenttype=isnull(OrganizationType,0) from Organization where Organization=@Organizationparent
            if @parenttype=@OrganizationType set @returnorg=@Organizationparent 
            if  (@parenttype is null) or (@parenttype<@OrganizationType) or (@parenttype=1)  break
           set @counter =@counter+1
    end          
     end
  
if @corn = 0 return @returnorg
if @corn = 1  
if @lang = N'E'  select @returnname= organizationname from organization where organization =  @returnorg
else select @returnname= organizationaname from organization where organization =  @returnorg
return isnull(@returnname,N'')

END

GO

