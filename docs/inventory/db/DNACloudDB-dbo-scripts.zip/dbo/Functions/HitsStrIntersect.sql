

CREATE FUNCTION [dbo].[HitsStrIntersect](@userorgs  as nvarchar(max),@tableorgs  as nvarchar(max),@userorgsDelimeter as char(1),@tableorgsDelimeter as char(1) )
RETURNS smallint  AS  
BEGIN 
--declare @userorgs as nvarchar(max)='50,51,52,53,54,58,275,278,279,290,296',@tableorgs as nvarchar(max)='#51#52#53#'
declare @exist as smallint=0
if @userorgs='' or @tableorgs='' set @exist=1
else
begin 



--declare @version as smallint
--SELECT @Version=left(CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')),2)
--set @version=12

--if @Version>=13
IF EXISTS(SELECT * FROM sys.databases WHERE databases.name=DB_NAME() AND databases.compatibility_level>=130)-- SQL2016+
begin

select top 1  @exist=1
from  string_split(@tableorgs,@tableorgsDelimeter) t1
inner join 
string_split(@userorgs,@userorgsDelimeter) t  on   cast(t1.value as int)=cast(t.value as int)
and cast(t1.value as int)<>'' and cast(t.value as int)<>''
end

else


begin
declare @organizationTemp TABLE (Organization smallint)
 insert into @organizationTemp select * from  dbo.HitsStringSplit(@tableorgs,@tableorgsDelimeter) t1

 select  @exist=1 from @organizationTemp 
 where 
      @userorgs like '%'+@userorgsDelimeter+rtrim(ltrim(str(Organization)))+@userorgsDelimeter+'%'
end


select @exist=case when @exist>0 then 1 else 0 end
end

--select @exist
return @exist
END

GO

