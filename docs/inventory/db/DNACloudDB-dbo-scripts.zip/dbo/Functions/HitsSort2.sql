CREATE FUNCTION [dbo].[HitsSort2]
(

	@EmployeeId AS NVARCHAR(50),@Type NVARCHAR(MAX)
)
RETURNS NVARCHAR(50)
AS

--DECLARE @EmployeeId AS NVARCHAR(50)
--SET @EmployeeId='100'

BEGIN

--DECLARE @EmployeeidType AS SMALLINT,@EmployeeidLength  AS SMALLINT


--SELECT @EmployeeidType=EmployeeidType,@EmployeeidLength=EmployeeidLength FROM SysParam


--SET @EmployeeId=LTRIM(RTRIM(isnull(@EmployeeId,'')))
--SET @employeeid=CASE WHEN @EmployeeidType=0 THEN replicate('0',@EmployeeidLength-LEN(@employeeid))+@employeeid  ELSE @employeeid END 
SElecT @employeeid=replicate('0',EmployeeidLength-LEN(@employeeid))+@employeeid  
FROM SysParam


return  @EmployeeId

END

GO

