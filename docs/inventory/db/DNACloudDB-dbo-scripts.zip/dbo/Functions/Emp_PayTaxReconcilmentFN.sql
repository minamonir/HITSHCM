CREATE FUNCTION [dbo].[Emp_PayTaxReconcilmentFN] (@empid int, @NoofMonths int,@TaxCode as int) 
RETURNS numeric(18,3)
AS
BEGIN
	--DECLARE @empid int, @NoofMonths int,@TaxCode as int
	--SELECT @empid=206209 , @NoofMonths=6,@TaxCode=104
	
	
  Declare @W_Months as int,@Tax_Total AS numeric (18,3),@Tax_Exempt AS numeric(18,3)
  ,@Basic_Sal AS numeric (18,3),@C_Year AS int ,@Period_Total AS int, @Soc_Insur AS numeric (18,3)
  ,@C_Month AS int,@C_Period AS int,@Period_Total2 AS numeric (18,3),@Stmp_Amnt AS numeric (18,3)
  ,@Tax_Total2 AS numeric (18,3),@W_ActMonths AS int
  ,@TaxableEarning AS numeric (18,3),@TaxableDeduction AS numeric (18,3), @formula AS nvarchar(max)
  ,@TaxAmount AS numeric(18,3)
  SELECT @TaxableEarning= sum(isnull(Historyamount.amount,0)+isnull(MonthyAmount.amount,0))
  FROM EmpAssignment
  LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
  LEFT JOIN (SELECT EmpAssignment.empid,sum(HistoryTransaction.amount) AS amount FROM EmpAssignment
			 left JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
			 LEFT JOIN HistoryTransaction ON HistoryTransaction.EmpId = EmpAssignment.EmpId
			 LEFT JOIN paycode ON paycode.code = HistoryTransaction.Paycode
			 WHERE EmpAssignment.EmpId=@empid 
			 AND HistoryTransaction.Year=PayrollGroup.CYear
			 AND HistoryTransaction.Month BETWEEN 1 AND @NoofMonths
			 AND paycode.type=1 AND paycode.taxappl=1 OR (paycode.type=3 AND paycode.code=100 )
             GROUP BY EmpAssignment.EmpId) AS Historyamount ON empassignment.EmpId=Historyamount.empid
             
  LEFT JOIN (SELECT monthlytransaction.empid,sum(monthlytransaction.Amount)AS amount
             FROM empassignment
             LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = empassignment.PayrollGroup
             LEFT JOIN MonthlyTransaction ON MonthlyTransaction.EmpId = empassignment.EmpId
             LEFT JOIN paycode ON paycode.code = MonthlyTransaction.Paycode
             WHERE EmpAssignment.EmpId=@empid AND PayrollGroup.CMonth=@NoofMonths 
             AND paycode.type=1 AND paycode.taxappl=1 OR (paycode.type=3 AND paycode.code=100)
             GROUP BY monthlytransaction.EmpId) AS MonthyAmount ON empassignment.EmpId=MonthyAmount.empid
  WHERE EmpAssignment.EmpId=@empid
 
  SELECT @TaxableDeduction= sum(isnull(Historyamount.amount,0)+isnull(MonthyAmount.amount,0))
  FROM EmpAssignment
  LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
  LEFT JOIN (SELECT EmpAssignment.empid,sum(HistoryTransaction.amount) AS amount FROM EmpAssignment
			 LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
			 LEFT JOIN HistoryTransaction ON HistoryTransaction.EmpId = EmpAssignment.EmpId
			 LEFT JOIN paycode ON paycode.code = HistoryTransaction.Paycode
			 WHERE EmpAssignment.EmpId=@empid 
			 AND HistoryTransaction.Year=PayrollGroup.CYear
			 AND HistoryTransaction.Month BETWEEN 1 AND @NoofMonths
			  AND paycode.type=2 AND paycode.taxappl=1 OR (paycode.type=3 AND paycode.code=100)
             GROUP BY EmpAssignment.EmpId) AS Historyamount ON empassignment.EmpId=Historyamount.empid
             
  LEFT JOIN (SELECT monthlytransaction.empid,sum(monthlytransaction.Amount)AS amount
             FROM empassignment
             LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = empassignment.PayrollGroup
             LEFT JOIN MonthlyTransaction ON MonthlyTransaction.EmpId = empassignment.EmpId
             LEFT JOIN paycode ON paycode.code = MonthlyTransaction.Paycode
             WHERE EmpAssignment.EmpId=@empid AND PayrollGroup.CMonth=@NoofMonths 
              AND paycode.type=2 AND paycode.taxappl=1 OR (paycode.type=3 AND paycode.code=100)
             GROUP BY monthlytransaction.EmpId ) AS MonthyAmount ON empassignment.EmpId=MonthyAmount.empid
  WHERE EmpAssignment.EmpId=@empid
  
  SELECT @Tax_Total=@TaxableEarning-@TaxableDeduction
  
  SELECT @formula=taxequat FROM TaxRules WHERE taxcode=@TaxCode


  SET @formula=REPLACE(@formula,N'W_Months',@NoofMonths)
  SET @formula=REPLACE(@formula,N'basic_sal',isnull(@Basic_Sal,0))
  SET @formula=REPLACE(@formula,N'C_Year',isnull(@C_Year,0))
  SET @formula=REPLACE(@formula,N'Period_Total',isnull(@Period_Total,0))
  SET @formula=REPLACE(@formula,N'Soc_Insur',isnull(@Soc_Insur,0))
  SET @formula=REPLACE(@formula,N'Tax_Exempt',isnull(@Tax_Exempt,0))
  SET @formula=REPLACE(@formula,N'C_Period',isnull(@C_Period,0))
  SET @formula=REPLACE(@formula,N'Period_Total2',isnull(@Period_Total2,0))
  SET @formula=REPLACE(@formula,N'Stmp_Amnt',isnull(@Stmp_Amnt,0))
  SET @formula=REPLACE(@formula,N'Tax_Total',isnull(@Tax_Total,0))
  SET @formula=REPLACE(@formula,N'Tax_Total2',isnull(@Tax_Total2,0))
  SET @formula=REPLACE(@formula,N'W_ActMonths',isnull(@W_ActMonths,0))
  
 SET @formula=N'select @formulaOutput= '+ @formula 

--DECLARE  @int_erros AS int,@int_objSQL int,@int_objSelectCountResult int

 --EXEC @int_erros = sp_OAMethod @int_objSQL, @formula, @int_objSelectCountResult OUTPUT
 --PRINT @int_objSelectCountResult
 --EXEC @int_erros = sp_OAMethod @int_objSelectCountResult, 'GetRangeString(1, 1)', @TaxAmount OUT
 --EXEC @int_erros = sp_OADestroy @int_objSQL

--IF @int_erros <> 0 SET @TaxAmount = @int_erros

      --    RETURN @TaxAmount

exec sp_executesql @formula  , N' @formulaOutput numeric(18,3) OUTPUT ', @formulaOutput=@TaxAmount output  
RETURN @TaxAmount
END

GO

