

CREATE FUNCTION [dbo].[EmpVacStatusCheck] 
(@EmpId int, @documentno int,@Status nvarchar(MAX))
RETURNS smallint
AS
BEGIN

declare @Date1 as smalldatetime , @Date2 as smalldatetime,@VacTaken as numeric(18,3),@VacType as smallint,@InValidAction as smallint,
@vacdue as numeric(18,3) ,@currentvactaken as numeric(18,3) 

--select @VacType=VacType,@Date1= [dbo].[EndOfPeriodPerDate](Payrollgroup, fromdate, 'G',4),@Date2= [dbo].[EndOfPeriodPerDate](Payrollgroup, fromdate, 'G',5)
select @VacType=VacType,@Date1= [dbo].[V_YearStart]	(payrollgroup ,Month(Fromdate) ,Year(Fromdate)),@Date2= [dbo].[V_YearEnd]	(payrollgroup ,Month(Todate) ,Year(Todate))
from empvacat 
left join EmpAssignment on EmpAssignment.empid=empvacat.empid
inner join vacation on vacation.vaccode=empvacat.vaccode
where empvacat.empid=@EmpId and documentno=@documentno

	select	@currentvactaken=dbo.VacTakenDays(@EmpId,empvacat.fromdate,empvacat.todate,empvacat.vaccode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo)
	from  empvacat 
	where empvacat.empid=@EmpId and documentno=@documentno


select @VacTaken=[dbo].[EmpVacTakenWithStatus](@EmpId,@documentno,@Date1,@Date2,@VacType,@Status),
@vacdue=dbo.EmpVacDue(@empid,@Date1,@Date2,@VacType)

set @VacTaken=isnull(@VacTaken,0)+isnull(@currentvactaken,0)

select @InValidAction= case when @VacTaken<=@vacdue/3.0 then 0 else 1 end


RETURN @InValidAction
End

GO

