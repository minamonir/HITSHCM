
CREATE FUNCTION [dbo].[GetMisconductRoles](@EmpID int,@DocumentNo int)   
RETURNS NVARCHAR(MAX) AS  

BEGIN
	DECLARE @MsRoles NVARCHAR(MAX) 
set @MsRoles=N'' 
SELECT @MsRoles = @MsRoles + case when MscondctRoles =N'' then N'' else MscondctRoles  end 
FROM Mscondct 
LEFT JOIN EmpMsDtl emd ON emd.mscode = Mscondct.mscode

WHERE  emd.EmpId=@EmpID AND emd.DocumentNo=@DocumentNo
		
RETURN @MsRoles
END

GO

