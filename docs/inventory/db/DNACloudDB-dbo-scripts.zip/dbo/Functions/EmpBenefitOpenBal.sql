
--This fn calculate the openning balance (total debit-total credit) b4 a specific date for a certain benefit plan
CREATE FUNCTION EmpBenefitOpenBal(@empid as int,@documentno as smallint,@PlanNo as smallint,@StartActivityDate as smalldatetime)   
RETURNS numeric (18,3) AS  

BEGIN 

declare @balance as numeric(18,3),@totaldebit as numeric(18,3),@totalcredit as numeric(18,3)

select @totalcredit=sum(case when BenefitItems.Debitorcredit=2 then  activityamount else 0 end),@totaldebit=sum(case when BenefitItems.Debitorcredit=1 then  activityamount else 0 end)
from EmpBenefit
LEFT JOIN EmpBenefitItems ON EmpBenefit.EmpId = EmpBenefitItems.EmpId
 AND EmpBenefit.DocumentNo = EmpBenefitItems.DocumentNo 
LEFT JOIN BenefitItems ON EmpBenefitItems.ItemNo = BenefitItems.ItemNo 
where EmpBenefit.empid=@empid and  EmpBenefit.DocumentNo=@documentno and EmpBenefitItems.Activitydate<@StartActivityDate and EmpBenefit.planno=@PlanNo
set @balance=@totaldebit-@totalcredit
return isnull(@balance,0)
END

GO

