
CREATE FUNCTION [dbo].[EmpVacDue] (@empid int, @date1 smalldatetime,@date2 smalldatetime,@VacType as int) 
RETURNS numeric(18,3)
AS
BEGIN

--select @date1=dbo.Hijri2Greg('16/07/1437'),@date2=dbo.Hijri2Greg('15/08/1437')
  Declare @Due numeric(18,3),  @date3 as smalldatetime,  @date4  as smalldatetime, @VacCat1StartAtFirst as BIT, @calendar nchar(1),@dateformat AS smallint
  
  select @calendar=case when EnableHijri=1  then 'H' else 'G' END,@dateformat=DateFormat from sysparam
  
  select  @VacCat1StartAtFirst = VacCat1StartAtFirst,@calendar=case when @calendar='H' and payrollgroup.cyear<1900 then 'H' else 'G' end
  from EmpAssignment Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup

    Where EmpAssignment.EmpId=@empid
  
 set @Due=0
 
 
 if (@date1 > @date2) OR (@VacCat1StartAtFirst=0)
 begin
  
	 Select @Due=Case When @date1 > @date2 
		Then -1*dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate, dateadd(dd,1,@date2), 
		@date1-1, @VacType, EmpAssignment.EmpId) 
		Else dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate,@date1, @date2,@VacType, EmpAssignment.EmpId) End
		From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
		Where EmpAssignment.EmpId=@empid
  
 end
 else
 BEGIN
 	
	IF @calendar='H'
	BEGIN
			DECLARE @hdate3 AS Nchar(10),@htempdate3 AS Nchar(10),@hmonth AS SMALLINT=0,@hyear AS INT=0,@temp AS SMALLDATETIME
				
	 set @date4=@date2
    set @date3=@date1  
    
    	
		SET @hdate3=dbo.Greg2Hijri(@date3,'O')
		SElecT @hmonth=cast(substring(@hdate3,6,2) as int),@hyear=cast(substring(@hdate3,1,4) as int)
		
    if @VacType=1 
    BEGIN
    	select @hyear=@hyear +case when month(@hmonth)=12 then 1 else 0 end,@hmonth=case when @hmonth=12 then 1 else @hmonth+1 end 
    	
    SET @htempdate3=  CASE @dateformat WHEN 0 THEN STR(@hyear,4)+'-'+STR(@hmonth,2)+'-01'
										WHEN 1 THEN '01-'+STR(@hmonth,2)+'-'+STR(@hyear,4)
           											ELSE STR(@hmonth,2)+'-01-'+STR(@hyear,4) end
    set @date3=dbo.Hijri2Greg(@htempdate3)
    END
     
    while 1=1
    begin 
        SET @temp=dbo.h_dateadd('mm',1,@date3)
        if  @temp <@date2 set @date3=@temp else BREAK
       
    end
    if @date3>@date2 set @date3=@date1
    --set @date3=dateadd(mm,-1,dateadd(dd,1,@date2))
    while  @date4> @date1
    begin


      Select @Due= @Due+ dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate,case when @date3<@date1 then @date1 else @date3 end, @date4,@VacType, EmpAssignment.EmpId) 
       From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
        Where EmpAssignment.EmpId=@empid
		 --select case when @date3<@date1 then @date1 else @date3 end,@date4,dbo.Greg2Hijri(case when @date3<@date1 then @date1 else @date3 end,'O'),dbo.Greg2Hijri(@date4,'O'),@Due
     Select @date4=dbo.h_dateadd('dd',-1,@date3) , @date3=dbo.h_dateadd('mm',-1,@date3)

	
    end 

	END
	ELSE
		BEGIN
    set @date4=@date2
    set @date3=@date1  
    if @VacType=1 set @date3=CAST(str(YEAR(@date3) +case when month(@date3)=12 then 1 else 0 end,4)+'-'+str(case when month(@date3)=12 then 1 else month(@date3)+1 end ,2)+'-01' as smalldatetime)
    while 1=1
    begin
        if  dateadd(mm,1,@date3)<@date2 set @date3=dateadd(mm,1,@date3) else break
    end
    if @date3>@date2 set @date3=@date1
    --set @date3=dateadd(mm,-1,dateadd(dd,1,@date2))
    while  @date4>= @date1
    BEGIN
       set @date4=CASE WHEN DAY(@date4)=31 AND DAY(case when @date3<@date1 then @date1 else @date3 end) not in (1,31)THEN dateadd(dd,-1,@date4) ELSE @date4 end
       Select @Due= @Due+ dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate,case when @date3<@date1 then @date1 else @date3 end, @date4,@VacType, EmpAssignment.EmpId) 
       From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
       Where EmpAssignment.EmpId=@empid
     set @date4=dateadd(dd,-1,@date3)
     set @date3=dateadd(mm,-1,@date3)
    end 
 END
 End
  return @Due
--select @Balance as Bal,@PrevBal as prevbal,@Due as due,@Taken as taken
END
--dbo.EmpVacDue(EmpVacat.EmpId, '1958/05/25' , '2058/05/25' ,1)as VacMonDue1,

GO

