/*** Sum Cost Items Amount For an Employee OR for an Event ****/
CREATE  FUNCTION [dbo].[TrainingAttendance](@event as bigint,@empId as int,@type INT,@time BIT)   
RETURNS numeric (18,3) AS  
BEGIN
DECLARE @Total AS NUMERIC(18,3),@Sessions AS NUMERIC(18,3),@Attended AS NUMERIC(18,3)
IF(@type=1) --Employee
	BEGIN

			SELECT @Sessions=CASE WHEN @time=1 
			THEN -- Time
				Sum(DATEDIFF(minute,ts.TrainingSessionFrom,ts.TrainingSessionTo)*1.0)
			ELSE --Attendace 
				Count(eta.TrainingSession) END 
				FROM EmpTrainingAttendance eta
				LEFT JOIN TrainingSessions ts ON ts.TrainingEvent = eta.TrainingEvent 
				AND ts.TrainingSession = eta.TrainingSession
				WHERE eta.EmpId=@empId AND eta.TrainingEvent=@event
			
			SELECT @Attended=CASE WHEN @time=1 THEN SUM(DATEDIFF(minute,TimeIn,TimeOut)*1.0)
			ELSE Count(EmpId) END 
			FROM EmpTrainingAttendance
			WHERE EmpId=@empId AND TrainingEvent=@event	AND Attendance=1
		
	END
ELSE --Trainer
	BEGIN	
			SELECT @Sessions=CASE WHEN @time=1 THEN
					Sum(DATEDIFF(minute,ts.TrainingSessionFrom,ts.TrainingSessionTo)*1.0)
					ELSE Count(tta.TrainingSession) END 
				FROM TrainingTrainersAttendance tta
				INNER JOIN TrainingResourcesBooking trb ON trb.TrainingEvent = tta.TrainingEvent
				AND trb.TrainingSession = tta.TrainingSession
				AND tta.EmpId=trb.TrainingResource
				LEFT JOIN TrainingSessions ts ON ts.TrainingEvent = tta.TrainingEvent 
				AND ts.TrainingSession = tta.TrainingSession
				WHERE tta.EmpId=@empId AND tta.TrainingEvent=@event
				
				SELECT @Attended=CASE WHEN @time=1 THEN 
					SUM(DATEDIFF(minute,TimeIn,TimeOut)*1.0)
					ELSE Count(tta.EmpId) END 
				FROM TrainingTrainersAttendance tta
				INNER JOIN TrainingResourcesBooking trb ON trb.TrainingEvent = tta.TrainingEvent
				AND trb.TrainingSession = tta.TrainingSession
				AND tta.EmpId=trb.TrainingResource
				WHERE tta.EmpId=@empId
				AND tta.TrainingEvent=@event AND tta.Attendance=1
	END
	
SELECT @Total=CASE WHEN @Sessions=0 THEN 0 ELSE @Attended/@Sessions END 
Return ISNULL(@Total,0) 
END

GO

