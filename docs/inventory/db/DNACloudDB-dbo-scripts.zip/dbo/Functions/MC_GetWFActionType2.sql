

CREATE FUNCTION [dbo].[MC_GetWFActionType2]
  (@RoleProfileid int, @MCID UNIQUEIDENTIFIER, @Empid int ,  @MCdocno as SMALLINT  )
RETURNS  int
as
BEGIN

DECLARE @MCDocType as smallint,@SSGroup as int
SELECT @MCDocType = MCDocType FROM dbo.MCDocument WHERE MCDocNo = @MCdocno



declare @roleid as smallint
declare @myorder as smallint
declare @beforeme as smallint
declare @beforemerq as smallint
declare @lastaction as smallint
declare @lastRole as smallint
declare @lastOrder as smallint
declare @lastid as int
declare @expired as smallint
declare @enddate as smalldatetime


DECLARE @Temp TABLE (
	MCID UNIQUEIDENTIFIER,
	EmpID int,
	MCDocNo smallint,
	RoleId smallint,
	ApprovalStatus smallint,
	ActionResaon varchar(max) ,
	ApprovalProfileId int,
	ApprovalDate smalldatetime,
	RoleOrder smallint,
	ApprovalRequired BIT 
	)
	
INSERT INTO @Temp
SELECT MCDocApproval.MCID, @Empid, MCDocNo, RoleId, ApprovalStatus, ActionResaon,
       ApprovalProfileId, ApprovalDate, RoleOrder, ApprovalRequired 
FROM dbo.MCDocApproval WITH (NOLOCK) 
WHERE MCDocApproval.MCID=@MCID  


SELECT  @expired = Expired ,  @enddate = Enddate
FROM dbo.MCMonthlyTransaction WITH (NOLOCK)  
WHERE MCMonthlyTransaction.MCID=@MCID  

set @SSGroup = (SELECT SSGroup FROM dbo.EmpAssignment WHERE empid = @empid)

set @roleid=null

SELECT top 1 @roleid=t.RoleId, @myorder=t.RoleOrder     --Get Smallest RoleID (order) and its order
FROM @Temp T
WHERE t.RoleId in (SELECT ssgrouprole.roleid FROM ssgrouprole WITH (NOLOCK)  WHERE ssgroup =@SSGroup AND profileid=@RoleProfileid) 
AND  T.ApprovalProfileId is NULL
order by T.RoleOrder 

 
if @roleid is null 
BEGIN
	SELECT top 1 @roleid=t.RoleId, @myorder=t.RoleOrder   
	FROM @Temp T
	WHERE t.RoleId in (SELECT ssgrouprole.roleid FROM ssgrouprole WITH (NOLOCK) WHERE ssgroup =@SSGroup AND profileid=@RoleProfileid) 
	order by T.RoleOrder  
END




--********New part to check if there is any one have to approve before me and his approval is required  ********

 declare @ApprovalRequiredcount int   -- Get if there is required approvals before me (@RoleProfileID)
 set @ApprovalRequiredcount=0
 select @ApprovalRequiredcount=count(*) 
 from @Temp t 
 where t.ApprovalProfileId is null
  and t.ApprovalDate is null
   and (RoleOrder <  @myorder) 
   and t.ApprovalRequired=1
 --******************************************************************************
 
 
SELECT TOP 1 @beforeme=RoleOrder , @beforemerq = ApprovalRequired   -- get values of last required approval before me
FROM @Temp T
WHERE RoleOrder <  @myorder
ORDER BY T.RoleOrder DESC

set  @lastOrder = 1
 
SELECT TOP 1 @lastaction= T.ApprovalStatus ,  @lastRole = T.RoleId ,   --get last action from last order before me
@lastid=T.ApprovalProfileId  , @lastOrder=T.RoleOrder 
FROM @Temp T 
WHERE T.ApprovalProfileId is not null 
ORDER BY T.RoleOrder DESC
 -----------------------------------------------

 
--replace (@myorder =1) with (@ApprovalRequiredcount =0)
IF (@myorder IS NULL) RETURN -2

if (@lastOrder = 1) and (@lastaction is null ) and (@ApprovalRequiredcount =0) and @enddate is  null  return 1

if (@lastOrder = @beforeme and     @lastaction IS NOT null and @enddate is  null)   return 1

IF  (@lastOrder <= @beforeme  and @beforemerq = 0  and @enddate is  null and      @lastaction IS NOT NULL AND (@ApprovalRequiredcount =0) )    return 1

if ((@lastOrder <= @beforeme) and ( @enddate is  null))      return 0
if (@lastOrder > @myorder or @expired = 1 or  @enddate is not null  ) and @myorder is not null  return -1
 return -2

END

----------------------------------------------------------------------------------------------------------------------------

GO

