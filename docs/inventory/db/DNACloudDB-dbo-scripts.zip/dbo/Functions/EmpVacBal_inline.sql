
		CREATE FUNCTION [dbo].[EmpVacBal_inline] (@empid int, @date2 smalldatetime,@VacType as int) 
		RETURNS TABLE
		AS
		--declare @empid int=1, @date2 smalldatetime='2017-06-30',@VacType as int=1
 
		RETURN
		(
		select 
			Balance =
				ROUND(
					case when @VacType=1 then EmpAssignment.VacPrvBal1 when @VacType=2 then EmpAssignment.VacPrvBal2 else EmpAssignment.VacPrvBal3 end,
					sysparam.DecimalScale
				)
				+
				ROUND(
					dbo.EmpVacDue(@empid, dbo.V_YearStart(EmpAssignment.PayrollGroup, 0, 0) ,@date2,@VacType),
					sysparam.DecimalScale
				)
				-
				ROUND(
					dbo.EmpVacTaken(@empid, dbo.V_YearStart(EmpAssignment.PayrollGroup, 0, 0) ,@date2,@VacType),
					sysparam.DecimalScale
				)
		From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
		CROSS JOIN sysparam
		Where EmpAssignment.EmpId=@empid
		);

GO

