CREATE FUNCTION [dbo].[CheckItemChildren] (@ItemNo AS SMALLINT, @UserGroup SMALLINT)
RETURNS SMALLINT
AS
BEGIN
	IF (SELECT ItemEnabled FROM NasOptions WHERE ItemNo = @ItemNo) = 0 RETURN 0

	ELSE
	BEGIN
		IF @UserGroup<>0
		BEGIN
			IF NOT EXISTS(SELECT * FROM UserGroupRights WHERE ItemNo = @ItemNo AND UserGroup=@UserGroup) RETURN 0
		END
	END

	DECLARE @GetChildren AS SMALLINT 

	SELECT @GetChildren = 0

	IF EXISTS (SELECT * FROM NasOptions WHERE ParentNo = @ItemNo) SELECT @GetChildren=1  --ELSE RETURN 1
	ELSE 
	BEGIN
		IF EXISTS (SELECT * FROM NasOptions WHERE Itemno = @ItemNo AND SystemCode IN ('NavBar','tilegroup')) RETURN 0 ELSE RETURN 1
	END
		 
	IF @GetChildren = 1
	BEGIN
		DECLARE @Child_ItemNo AS SMALLINT, @Child_ItemEnabled AS BIT

		DECLARE Childs_Cursor CURSOR FOR

			SELECT ItemNo, ItemEnabled
			FROM NasOptions
			WHERE ParentNo = @ItemNo


		OPEN Childs_Cursor
		FETCH NEXT FROM Childs_Cursor INTO @Child_ItemNo,@Child_ItemEnabled

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @Child_ItemEnabled = 1
			BEGIN
				DECLARE @subchildCount AS SMALLINT = 0

				SELECT @subchildCount = COUNT(ItemNo)
				FROM NasOptions
				WHERE ParentNo = @Child_ItemNo

				IF @subchildCount = 0
				BEGIN
					IF @UserGroup=0		RETURN 1
					ELSE 
                    BEGIN
						IF EXISTS(SELECT * FROM UserGroupRights WHERE UserGroup=@UserGroup AND ItemNo=@Child_ItemNo) RETURN 1 
                    END
				END
				ELSE IF @subchildCount > 0
				BEGIN
					DECLARE @FoundChild AS SMALLINT = 0
					SELECT @FoundChild = dbo.CheckItemChildren(@Child_ItemNo,@UserGroup)
					IF @FoundChild = 1
					BEGIN
						RETURN 1
					END 
				END 
			END
			FETCH NEXT FROM Childs_Cursor INTO @Child_ItemNo,@Child_ItemEnabled
		END
		CLOSE Childs_Cursor;
		DEALLOCATE Childs_Cursor;
	END 
    RETURN 0
END

GO

