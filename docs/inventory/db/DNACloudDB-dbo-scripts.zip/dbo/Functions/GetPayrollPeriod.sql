CREATE FUNCTION [dbo].GetPayrollPeriod (@payrollgroup int,  @Calcdate smalldatetime)
RETURNS int AS  
begin

RETURN 0
end

GO

