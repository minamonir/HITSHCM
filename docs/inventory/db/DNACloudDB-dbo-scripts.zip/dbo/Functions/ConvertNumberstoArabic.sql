
CREATE FUNCTION [dbo].[ConvertNumberstoArabic]
(
	@num AS NVARCHAR (max),@type AS int
)
RETURNS NVARCHAR (max)
AS
BEGIN
	--@Type=0 Number
	--@Type=1 Month Name
	IF @type=1
		BEGIN 
			set @num=CASE WHEN @num=1 THEN N'يناير' 
				WHEN @num=2 THEN N'فبراير'
				WHEN @num=3 THEN N'مارس'
				WHEN @num=4 THEN N'ابريل'
				WHEN @num=5 THEN N'مايو'
				WHEN @num=6 THEN N'يونيو'
				WHEN @num=7 THEN N'يوليو'
				WHEN @num=8 THEN N'اغسطس'
				WHEN @num=9 THEN N'سبتمبر'
				WHEN @num=10 THEN N'اكتوبر'
				WHEN @num=11 THEN N'نوفمبر'
			ELSE N'ديسمبر'
			end
		END
	ELSE
		BEGIN
			set @num= REPLACE(@num,'1',N'۱')
			set @num= REPLACE(@num,'2',N'٢')
			set @num= REPLACE(@num,'3',N'٣')
			set @num= REPLACE(@num,'4',N'٤')
			set @num= REPLACE(@num,'5',N'٥')
			set @num= REPLACE(@num,'6',N'٦')
			set @num= REPLACE(@num,'7',N'٧')
			set @num= REPLACE(@num,'8',N'٨')
			set @num= REPLACE(@num,'9',N'٩')
			set @num= REPLACE(@num,'0',N'٠')
		END
	RETURN @num

END

GO

