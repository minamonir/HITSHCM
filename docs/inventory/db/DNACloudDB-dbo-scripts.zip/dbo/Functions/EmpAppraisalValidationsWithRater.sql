
CREATE FUNCTION [dbo].[EmpAppraisalValidationsWithRater] (@EmpId INT , @documentno INT ,@raterprofileid INT,@lang as NCHAR(1)='e')
RETURNS NVARCHAR(max) 
AS
BEGIN 
	DECLARE @notValid AS BIT =0
	DECLARE @ValidationCaption NVARCHAR(MAX) = N'' 
	
	DECLARE @ProficiencyValidation AS SMALLINT =0 , @strprog AS NVARCHAR(MAX)=''
	DECLARE  @MaxMisDays SMALLINT 
	SELECT @strprog =itemprog FROM NasOptions WHERE ItemNo=26563 
	
	 IF CHARINDEX('&ProficiencyValidation=',@strprog) <> 0
     Set @ProficiencyValidation= SUBSTRING(@strprog,CHARINDEX('&ProficiencyValidation=',@strprog)+23,CASE WHEN CHARINDEX('&',@strprog,CHARINDEX('&ProficiencyValidation=',@strprog)+23 ) <=0 THEN LEN(@strprog)+1 ELSE CHARINDEX('&',@strprog,CHARINDEX('&ProficiencyValidation=',@strprog)+23 ) END -CHARINDEX('&ProficiencyValidation=',@strprog)-23  )
     

     SELECT @MaxMisDays = CASE WHEN  LTRIM(RTRIM(ISNULL(SysParamConfig.ConfigValue,N''))) = N'' THEN 0 ELSE CONVERT(SMALLINT,SysParamConfig.ConfigValue) END 
		FROM SysParamConfig 
		WHERE SysParamConfig.ConfigID = N'AppraisalMisconductDays'
     select @MaxMisDays=isnull(@MaxMisDays,0)
    IF @MaxMisDays>0 
	BEGIN 
		DECLARE  @RatingLevel SMALLINT , @maxRatingLevel AS SMALLINT 
		
		DECLARE @appraisaldate AS SMALLDATETIME 
		SELECT @appraisaldate = appraisaldate ,@RatingLevel = dbo.EmpAppraisalRatingLevel(@empid ,@documentno) 
		FROM empappraisal 
		WHERE empid =@empid AND documentno=@documentno
		
		SELECT top 1 @maxRatingLevel = ratinglevels.RatingLevel
		FROM empappraisal 
		LEFT JOIN appraisals ON appraisals.AppraisalNo = empappraisal.AppraisalNo
		LEFT JOIN ratinglevels ON ratinglevels.RatingScale = appraisals.RatingScale
		WHERE empappraisal.empid =@empid AND  empappraisal.documentno=@documentno
		ORDER BY ratinglevels.LevelPercent DESC 
		
		if  dbo.CountMisconductDays(@empid,@appraisaldate,@appraisaldate,1,1) >=@MaxMisDays AND @RatingLevel=@maxRatingLevel
		BEGIN
			 SELECT @ValidationCaption = CASE WHEN LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaption('EmpAppraisalValidations','ValidationMsg',@lang),N''))) = N'' THEN (CASE WHEN @lang='e' THEN N'The Rating Level doesn''t match no. of Misconduct Days  ' ELSE N'مستوي االقياس لا يتناسب مع أيام الجزاءات' END) ELSE  LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaption('EmpAppraisalValidations','ValidationMsg',@lang),N''))) END 
		END
				 
	END 
     
	IF @ProficiencyValidation =1 AND EXISTS (SELECT 1  FROM EmpAppraisal 
				INNER JOIN AppraisalCompetencies ON AppraisalCompetencies.AppraisalNo = EmpAppraisal.AppraisalNo
				LEFT JOIN Appraisals ON Appraisals.AppraisalNo = EmpAppraisal.AppraisalNo
	            WHERE EmpAppraisal.EmpId=@EmpId AND EmpAppraisal .DocumentNo=@documentno
				AND Appraisals.Proficiency =1)
		BEGIN 	
			DECLARE @count AS SMALLINT =0
			DECLARE @countAll AS SMALLINT =0
			SELECT @count= sum (CASE WHEN ISNULL(EmpAppraisalComp.RatingLevel,0)=0 THEN 0 ELSE 1 END ) , @countAll=COUNT(*)
			FROM EmpAppraisalComp 
			LEFT JOIN EmpAppraisal ON EmpAppraisal.EmpId = EmpAppraisalComp.EmpId AND EmpAppraisal.DocumentNo = EmpAppraisalComp.DocumentNo
			LEFT JOIN Appraisals ON Appraisals.AppraisalNo = EmpAppraisal.AppraisalNo
			WHERE empappraisalcomp.EmpId =@EmpId AND empappraisalcomp.DocumentNo=@documentno 
			AND empappraisalcomp.RaterProfileId =CASE WHEN Appraisals.MultiRater =0 THEN @EmpId ELSE @raterprofileid END 
			SELECT @notValid = CASE when @count <>@countAll Or @countAll =0  THEN 1 ELSE 0 END 
			IF @notValid=1
			BEGIN
			 SELECT @ValidationCaption = CASE WHEN @ValidationCaption='' THEN '' ELSE @ValidationCaption + ' <br>' END + CASE WHEN LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaption('EmpAppraisalValidationsWithRater','CompetenceValidationMsg',@lang),N''))) = N'' THEN (CASE WHEN @lang='e' THEN N'Competence Profiency Levels are mandatory' ELSE N'لابد من إدخال مستويات الإتقان للكفاءة' END) ELSE  LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaption('EmpAppraisalValidationsWithRater','CompetenceValidationMsg',@lang),N''))) END 
			END
		END 

		RETURN @ValidationCaption
END

GO

