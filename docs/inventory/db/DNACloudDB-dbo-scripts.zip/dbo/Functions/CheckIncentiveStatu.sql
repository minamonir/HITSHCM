CREATE FUNCTION [dbo].[CheckIncentiveStatu] (
    @Paycode smallint, 
    @RunNo smallint, 
	@EmpId int
)
RETURNS VARCHAR(10)
AS
BEGIN
DECLARE @ScStatus SMALLINT
SELECT @ScStatus =ScStatus FROM dbo.EmpAssignment WHERE EmpId = @EmpId
IF ((SELECT COUNT(*)FROM dbo.MonthlyTransaction WHERE RunNo=@RunNo AND EmpId=@EmpId AND Paycode IN(296,298,299))>1 )
BEGIN 
	RETURN 'False'
END
IF (
   (@ScStatus= 1 AND @Paycode IN(296,298,299))
OR (@ScStatus= 2 AND @Paycode IN(298,299))
OR (@ScStatus= 3 AND @Paycode IN(296,299))
OR (@ScStatus= 4 AND @Paycode IN(296,298))
)
BEGIN
	RETURN 'False'
END
return 'True'
END

GO

