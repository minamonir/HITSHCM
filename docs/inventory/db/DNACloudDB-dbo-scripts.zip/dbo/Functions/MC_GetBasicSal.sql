create FUNCTION [dbo].[MC_GetBasicSal] 
(@empid int ,@BasicSal numeric (18,3),@runno smallint =0 )
RETURNS numeric (18,3)
AS
BEGIN
declare @Ret_BasicSal as numeric (18,3)
select @Ret_BasicSal=@BasicSal - isnull(sum (amount),0)
from MonthlyTransaction 
left join EmpAssignment on EmpAssignment.empid =MonthlyTransaction.EmpId
left join PayrollGroup on PayrollGroup.PayrollGroup=EmpAssignment.PayrollGroup
where MonthlyTransaction.empid =@empid and paycode = 100 
and MonthlyTransaction.RunNo < case when isnull(@runno,0)=0 then  PayrollGroup.RunNo 
	else @runno end  


return @Ret_BasicSal

END

GO

