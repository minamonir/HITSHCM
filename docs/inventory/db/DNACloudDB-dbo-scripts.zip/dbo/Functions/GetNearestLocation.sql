CREATE FUNCTION [dbo].[GetNearestLocation] (@CamID INT , @ObjPoints GEOGRAPHY, @Lang AS NVARCHAR(10) = '')
RETURNS nvarchar(130)

AS
BEGIN
	 DECLARE @newParent int =  (select IOTDeviceLocationParent from IOTDeviceLocations where IOTDeviceLocation = @CamID 
	 and @CamID<>0)
	 select @newParent = isnull(@newParent,0)
	 
	 DECLARE @SubLocation VARCHAR(8000) ='', @substr VARCHAR(255) = ',', @start INT=0, @occurrence INT=1 , @PointsCounter INT , @ActualLocation INT --, @ObjPoints NVARCHAR(max)
	 DECLARE @CurIOTDeviceLoc INT, @LocationType int 
	 DECLARE @CurDist float, @finalResult nvarchar(130), @curLocName nvarchar(120), @name nvarchar(120),
	 @SubLocationTemp VARCHAR(8000) ='',@OldPos as int = 0  ,@oldfound as int = 0
	 , @lat varchar (max)='' , @long as varchar(max) = ''
	 --get all sub locations
	-- SELECT @SubLocation = '0, 0, 4, 0, 4, 4, 0, 4'
	 -----SELECT @ObjPoints = LTRIM(@Objx) +' ' + LTRIM(@objy)
	 --set @ObjPoints =  geography::STGeomFromText('POINT('+ltrim(ISNULL(@ObjPoints.Lat,0))+' '+ltrim(ISNULL(@ObjPoints.Long,0))+')', 4326);

	 DECLARE @temp AS table (ObjExist BIT , DeviceLocation INT ,CurDistance float, LocName nvarchar(120),  DeviceLocationType int, Area float)

		DECLARE CurGetLocation CURSOR FOR
		    SELECT IOTDeviceLocation , LocationImagePoints, CASE WHEN @Lang = 'A' THEN IOTDeviceLocationAName ELSE IOTDeviceLocationName END 
			, IOTDeviceLocationType
			FROM dbo.IOTDeviceLocations 
			WHERE ISNULL(LocationImagePoints,'') <> '' AND
			isnull( IOTDeviceLocationParent,0) = Case When @newParent = 0 Then isnull( IOTDeviceLocationParent,0) ELSE @newParent END 

			 --IOTDeviceLocationParent = Case When @newParent = 0 Then IOTDeviceLocationParent ELSE @newParent END 
			AND IOTGeoLocation = 1
			--	AND LocationLatitude between -90 and 90
			--AND LocationLongitude between -180 and 180 
			--AND LocationLatitude > -90 AND LocationLatitude < 90
			--AND LocationLongitude > -180 AND LocationLongitude < 180
			--AND  LOWER(LTRIM(Param1)) ='location'

		OPEN CurGetLocation
		FETCH NEXT FROM CurGetLocation INTO @CurIOTDeviceLoc , @SubLocation, @name, @LocationType
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @PointsCounter = LEN(@SubLocation) - LEN(REPLACE(@SubLocation, ',', '')) 
			WHILE	 @PointsCounter > 0
			BEGIN
				SET @occurrence = @PointsCounter
				DECLARE @found INT = @occurrence,@pos INT = @start;
				WHILE 1=1 
				BEGIN
				-- Find the next occurrence
					SET @pos = CHARINDEX(@substr, @SubLocation, @pos);
 				-- The required occurrence found
					IF @found <0
					begin
						set @PointsCounter =0
						BREAK;
					end
					if (@found %2 =1)
					begin
						select @long =  SUBSTRING(@SubLocation ,@OldPos ,(@pos-@OldPos) )
					end
					else
					begin
						select @lat =  SUBSTRING(@SubLocation ,@OldPos ,(case when @pos = 0 then len (@SubLocation) else @pos-@OldPos end) )
						set @SubLocationTemp = @SubLocationTemp + ',' + ltrim(rtrim(@lat)) +'  '+ltrim(rtrim(@long))
						set @lat=''
						set @long=''
					end
				-- Prepare to find another one occurrence
					SET @found = @found - 1;
					SET @pos = @pos + 1;
					set @OldPos = @pos	
				END
				SET @PointsCounter = @PointsCounter -2
				SET  @SubLocation = STUFF(@SubLocation , @pos ,1 ,' ')
			END	
			--SET @SubLocation = @SubLocation +', '+SUBSTRING(@SubLocation , 0 , CHARINDEX(',' , @SubLocation , 0))
			SET @SubLocationTemp = SUBSTRING (@SubLocationTemp , CHARINDEX(',' , @SubLocationTemp , 0)+1 ,LEN(@SubLocationTemp)) 
			SET @SubLocationTemp = @SubLocationTemp +', '+SUBSTRING(@SubLocationTemp , 0 , CHARINDEX(',' , @SubLocationTemp , 0))
			set @SubLocation = @SubLocationTemp
			DECLARE @polygons table( name varchar(32), shape geometry , LocName nvarchar(120)) 
			INSERT into @polygons values 
			('Area', geometry::STGeomFromText('POLYGON(('+LTRIM(RTRIM(@SubLocation))+'))', 0), @name)
			DECLARE @GeoPolygons TABLE( name varchar(32), GeoShape GEOGRAPHY , LocName nvarchar(120),Area float)

			INSERT INTO @GeoPolygons(name, GeoShape, LocName, Area)
			SELECT 'Area' , shape.MakeValid().STUnion(shape.STStartPoint()).STAsText(), LocName, shape.STArea()
			FROM @polygons


			DECLARE @points table( id int identity(1,1),  position GEOGRAPHY ) 
			INSERT into @points values (@ObjPoints)
			--(geography::STGeomFromText('POINT('+LTRIM(RTRIM(@ObjPoints))+')',4326)) 

			INSERT INTO @temp
			        (DeviceLocation,ObjExist,CurDistance, LocName, DeviceLocationType, Area)
			SELECT @CurIOTDeviceLoc, 1 , GeoShape.STDistance(@ObjPoints), LocName, @LocationType, Area
			FROM @GeoPolygons  
			DELETE FROM @points 
			DELETE FROM @polygons
			DELETE FROM @GeoPolygons
			set @SubLocationTemp = ''
		FETCH NEXT FROM CurGetLocation INTO @CurIOTDeviceLoc , @SubLocation, @name, @LocationType
		END
		CLOSE CurGetLocation
		DEALLOCATE CurGetLocation
        SET @CurDist = -2
		SET @curLocName = ''
		SELECT TOP 1 @CurDist = CurDistance,
		@curLocName= LocName FROM @temp WHERE ObjExist = 1 order by CurDistance asc ,Area asc --,DeviceLocationType desc
		select @finalResult = cast(@CurDist as nvarchar(10)) + ',' + @curLocName
		RETURN @finalResult

END

GO

