CREATE FUNCTION [dbo].[GetDigitalSignatureSerial](@LogonName AS NVARCHAR(80) )
RETURNS NVARCHAR(250) 
AS
BEGIN

	DECLARE @DigitalSignatureSerial  AS NVARCHAR(50)

	SELECT TOP 1	@DigitalSignatureSerial = NasUsersDigitalSignatures.DigitalSignatureSerial
	FROM	NasUsersDigitalSignatures
	WHERE	NasUsersDigitalSignatures.LogonName = @LogonName
	AND NasUsersDigitalSignatures.Active = 1
	ORDER BY NasUsersDigitalSignatures.StartDate DESC

	RETURN @DigitalSignatureSerial

END

GO

