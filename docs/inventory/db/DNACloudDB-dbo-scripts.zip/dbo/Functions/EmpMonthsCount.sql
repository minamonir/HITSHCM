

--this fn calculates the no of times that a specific day occurs between  2 dates .This fn used in hrcolumns FN 
CREATE FUNCTION EmpMonthsCount (@datefrom as smalldatetime,@dateto as smalldatetime,@day as int)  
RETURNS int AS  
BEGIN 

declare @months as int,@calcdate as smalldatetime
set @months =0
 set @calcdate=convert(smalldatetime,str(year(@dateto),4)+'-'+str(1)+'-'+str(@day),120)
 set @calcdate=dateadd(m,month(@dateto)-1,@calcdate)
while @datefrom <=@calcdate
begin
	if @calcdate between @datefrom and @dateto 	set @months=@months+1
	set @calcdate=dateadd(m,-1,@calcdate)
end
return @months
END

GO

