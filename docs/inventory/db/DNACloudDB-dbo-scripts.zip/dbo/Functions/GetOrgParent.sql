CREATE FUNCTION dbo.GetOrgParent
  (@Organization smallint, @OrganizationType smallint, @VersionNo smallint)
RETURNS  smallint
AS
BEGIN 
  declare @returntype as smallint, @returnorg as smallint  
  select @returntype=organizationtype from organization where organization=@organization 
  
  set @returnorg=0
  if @returntype<@OrganizationType set @returnorg=0
  if @returntype=@OrganizationType set @returnorg=@Organization
  if @returntype>@OrganizationType  
    begin
      declare @Organizationparent as smallint, @parenttype as smallint, @counter as smallint
      set @parenttype=@returntype
      set @Organizationparent=@Organization
      set @counter=1
      while @counter<6
         begin  
           select @Organizationparent=Organizationparent  from OrganizationStructure  where Organization=@Organizationparent and VersionNo=@VersionNo
           if (@Organizationparent is null) break
           select @parenttype=isnull(OrganizationType,0) from Organization where Organization=@Organizationparent
            if @parenttype=@OrganizationType set @returnorg=@Organizationparent 
            if  (@parenttype is null) or (@parenttype<@OrganizationType) or (@parenttype=1)  break
           set @counter =@counter+1
    end          
     end
   return @returnorg
END

GO

