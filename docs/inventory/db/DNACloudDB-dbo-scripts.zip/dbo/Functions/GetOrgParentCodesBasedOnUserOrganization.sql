CREATE FUNCTION [dbo].[GetOrgParentCodesBasedOnUserOrganization](@Org INT,@logonname NVARCHAR(80))

RETURNS nvarchar(max) AS  

--declare @Org INT,@logonname NVARCHAR(80)
--select @Org =369,@logonname='ttss'


BEGIN 
declare @desc AS nvarchar(max)=''

DECLARE @enableOrgSetup AS BIT , @userOrganization AS NVARCHAR(MAX)=''
SELECT @enableOrgSetup=EnableOrgSetup ,@userOrganization=UserOrganization
FROM nasusers 
cross JOIN sysparam 
WHERE nasusers.LogonName=@logonname 


IF @enableOrgSetup =0 or @userOrganization='' 
BEGIN
	SET @desc=dbo.GetOrgParentCodes(@org)
END
ELSE 
	BEGIN
		SELECT  @desc=@desc+ltrim(rtrim(str(max(OrganizationParentChild.OrganizationParentOrChild ))))+'\'
		FROM OrganizationParentChild
		inner join OrganizationParentChild TempOrgParents  on TempOrgParents.OrganizationParentOrChild=OrganizationParentChild.OrganizationParentOrChild
		left join Organization on Organization.Organization=OrganizationParentChild.OrganizationParentOrChild 
		cross apply dbo.HitsStringSplit(@userOrganization,'#') t
		WHERE 
		--@userOrganization LIKE '%#'+ltrim(rtrim(STR(OrganizationParentChild.organization)))+'#%'
		t.value<>'' and t.value=OrganizationParentChild.organization

		--WHERE @userOrganization LIKE '%#'+ltrim(rtrim(STR(OrganizationParentChild.organization)))+'#%' 
		
		AND OrganizationParentChild.OrgRelation IN (2,3)
		and TempOrgParents.organization=@Org and TempOrgParents.OrgRelation in (1,2) 
		group by  Organization.OrganizationType,OrganizationParentChild.OrganizationParentOrChild 
		order by Organization.OrganizationType
		SELECT @desc= case when right(@desc,1)='\' then left (@desc,len(@desc)-1) else @desc end  	
	END

return @desc

--select @desc
END

GO

