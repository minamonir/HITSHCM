
create  FUNCTION [dbo].[GetCostItemId]
  (@ProfileId int, @AssignmentId int)
RETURNS  int
as
BEGIN 
  declare @CostItemId as int
 
   select top 1 @CostItemId=CostItemId from appcost where Empid=@ProfileId and AssignmentId=@AssignmentId order by CostItemId desc
  
set @CostItemId=isnull(@CostItemId,0)
 

   while  1=1
    begin
     if  @CostItemId>2147483647    set @CostItemId=1 else set  @CostItemId=@CostItemId+1 
     if  not exists (select CostItemId from appcost where Empid=@ProfileId and AssignmentId=@AssignmentId AND CostItemId=@CostItemId )  BREAK
    end
  return @CostItemId
END

GO

