create FUNCTION [dbo].[GreatestList]  (@Value as numeric(18,3), @ComparedValue as numeric(18,3), @Type as smallint=1)
RETURNS numeric(18,3) AS  
begin
DECLARE @FinalValue AS numeric(18,3)=0

--@Type=1 Greatest
--@Type=2 smallest

if @Type=1
BEGIN
  if @Value > @ComparedValue select @FinalValue=@Value
END
Else
BEGIN
if @Value > @ComparedValue select @FinalValue=@ComparedValue
END


RETURN @FinalValue
end

GO

