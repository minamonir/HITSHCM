CREATE    FUNCTION [dbo].[GetEmployeeManager]
  (@EmployeeId NVARCHAR(50), @Level smallint)
RETURNS  NVARCHAR(50)
as
BEGIN 

declare @ManagerID as int , @Manageremployeeid as NVARCHAR(50) 
select @ManagerID = Profileid  
from ssgrouprole where ssgroup = ( select ssgroup from empassignment where employeeid = @employeeid  ) 
and roleid = ( select roleid from ssdocumentrole where  ssdocno = 6 and roleorder = @level)
select @Manageremployeeid = employeeid from empassignment where empid = @ManagerID
return @Manageremployeeid
END

GO

