
CREATE  FUNCTION [dbo].[WFGetMail] (@RoleProfileid  as INT,@Empid  as int, @documentno AS INT,@SSDocNo as INT, @action as INT
,@SSNewStatus as int  ,@ActionResaon as Nvarchar(max) ,
@ProfileID as int , @EMailAction as INT, @Latinlang as nchar(1),@SMSorMail AS INT)
RETURNS    NVARCHAR(max)
AS
BEGIN
declare @propname as nvarchar(150) 
select @propname=propname  from SysParam
DECLARE @TaskDesc AS  NVARCHAR(max)

	--@SMSorMail=0  --> for sms , @SMSorMail=1 --> for mail  , @SMSorMail=2 --> for Task
declare @English as nchar(1)='E',@Foreign AS NCHAR(1)='F',@Switchlang AS NCHAR(1)
-- for Merck turkey use  SELECT @English='F' , @Foreign='E'
SELECT @English=SysParamConfig.ConfigValue  FROM SysParamConfig WHERE SysParamConfig.ConfigID='WFenglishlang'
SELECT @Foreign=SysParamConfig.ConfigValue  FROM SysParamConfig WHERE SysParamConfig.ConfigID='WFforiegnlang'
SELECT @Switchlang =case WHEN @Latinlang ='F' THEN (CASE WHEN @Foreign='E' THEN 'E' ELSE 'F' END )
                         WHEN @Latinlang ='E'  THEN (CASE WHEN @English='E' THEN 'E' ELSE 'F' END )
                         ELSE  'A' END
-----------------------------------------------------------------
declare @SSDocType as int,@BG_NAME AS NVARCHAR(max),@sswebsite as nvarchar(250)
select @SSDocType=SSDocType from ssdocument where SSDocNo = @SSDocNo 
SELECT @BG_NAME = ISNULL(ConfigValue,'') FROM dbo.SysParamConfig WHERE ConfigID='WorkflowApprovalRedirectBG'

IF @BG_NAME <> ''
BEGIN
	DECLARE @adal AS BIT 
	,@url_ltr AS NVARCHAR(max)='logon.aspx?ReturnUrl=NasAgenda%2fAgendaPageGeneral.aspx%3fnodeselected%3d%26nodepage%3d26102%26navbar%3d10002%26iconitemno%3d26102%26ssdoctype%3d'
	,@url_rtl AS NVARCHAR(max)='logon_ar.aspx?ReturnUrl=NasAgenda%2fAgendaPageGeneral_ar.aspx%3fnodeselected%3d%26nodepage%3d26102%26navbar%3d10002%26iconitemno%3d26102%26ssdoctype%3d'
	SELECT TOP 1 @adal= ISNULL(WindowsOnly,0) FROM dbo.NasUsers WHERE EmpId=@ProfileID
	select @sswebsite ='<a href="'+CASE WHEN RIGHT(sswebsite,1) = '/' THEN  sswebsite ELSE sswebsite +'/' END +CASE WHEN @Latinlang='A' THEN @url_rtl ELSE @url_ltr END+LTRIM(@SSDocType)+CASE WHEN @adal=1 THEN '&adal=1&tenantid=' ELSE '&tenantid=' END +@BG_NAME+'' +'">'+sswebsite+'</a>'
	from SysParam
END
ELSE
BEGIN
	select @sswebsite =sswebsite from SysParam
END 

declare @assignmentid as int 
select @assignmentid = 0

if @SSDocType = 6 
BEGIN
	select @assignmentid = isnull(assignmentid,0)  from empappraisal  where empid = @empid and documentno = @DocumentNo
	
END
DECLARE @ID NVARCHAR(50)
SELECT @ID = ISNULL((SELECT EmployeeId FROM EmpAssignment WHERE EmpId=@Empid),@Empid)



  

  declare @body as Nvarchar(max), @Tempbody as Nvarchar(max) , @TempMsg AS NVARCHAR (MAX),@SMSbody as nvarchar(max),@EMailbody as nvarchar(max)
 declare @TempbodySMS as Nvarchar(max),@TempBodyMail AS NVARCHAR(max) 
 , @notifiBody AS NVARCHAR(max) , @notifiTempbodyMail AS NVARCHAR(max) , @notifiTempbody AS NVARCHAR(max)
 ,@NotifiEMailbody as nvarchar(max)
 , @notifiBodyAR AS NVARCHAR(max) , @notifiTempbodyMailAR AS NVARCHAR(max) , @notifiTempbodyAR AS NVARCHAR(max)
 ,@NotifiEMailbodyAR as nvarchar(max)
 , @notifiBodyFR AS NVARCHAR(max) , @notifiTempbodyMailFR AS NVARCHAR(max) , @notifiTempbodyFR AS NVARCHAR(max)
 ,@NotifiEMailbodyFR as nvarchar(max)
 SELECT  @Tempbody='',@TempbodySMS='' ,@TempBodyMail ='' , @notifiTempbody='' , @notifiTempbodyMail=''
 , @notifiTempbodyAR='' , @notifiTempbodyMailAR='', @notifiTempbodyFR='' , @notifiTempbodyMailFR=''

	 DECLARE @Msg2 AS nvarchar(max),@Msg3 AS nvarchar(max),@Msg4 AS nvarchar(max),@Msg5 AS nvarchar(max)
	 ,@Msg8 AS nvarchar(max),@ModuleMsg1 AS nvarchar(max),@ModuleMsg2 AS nvarchar(max),
	 @ModuleMsg3 AS nvarchar(max),@ModuleMsg4 AS nvarchar(max) ,@ModuleMsg5 AS nvarchar(max), @msg9 AS NVARCHAR(MAX) , @msg10  AS NVARCHAR(MAX)
	 ,@msg11  AS NVARCHAR(MAX), @msg12  AS NVARCHAR(MAX) , @msg13  AS NVARCHAR(MAX),  @msg14  AS NVARCHAR(MAX) , @msg15  AS NVARCHAR(MAX)
	 ,@msg16  AS NVARCHAR(MAX),  @msg17  AS NVARCHAR(MAX) , @msg18  AS NVARCHAR(MAX) ,@msg19  AS NVARCHAR(MAX),  @msg20  AS NVARCHAR(MAX) , @msg21  AS NVARCHAR(MAX)
	 , @msg22  AS NVARCHAR(MAX) ,@SeparatorEnter AS NVARCHAR(max),@SeparatorEnter2 AS NVARCHAR(max)
	 ,@MsgH AS nvarchar(max) ,@MsgSeparator AS NVARCHAR(MAX)
	 ,@ModuleMsg12 AS nvarchar(max),@TempMsgRole AS NVARCHAR(max),@TempMsgAction AS NVARCHAR(max)='' 
	 ,@Recipient AS NVARCHAR(MAX) ,@days AS NVARCHAR(max),@MsgF AS nvarchar(max),@Msg6 AS nvarchar(max),@Msg7 AS nvarchar(max)

	 ,@NotifiTempMsgAction AS NVARCHAR(max),@NotifiTempMsgRole AS NVARCHAR(max)
	 , @NotifiMsg2 AS nvarchar(max),@NotifiMsg3 AS nvarchar(max),@NotifiMsg4 AS nvarchar(max),@NotifiMsg5 AS nvarchar(max)  
	 ,@NotifiMsg6 AS nvarchar(max),@NotifiModuleMsg1 AS nvarchar(max),@NotifiModuleMsg2 AS nvarchar(max) ,@NotifiRecipient AS NVARCHAR(MAX) ,
	 @NotifiModuleMsg3 AS nvarchar(MAX),@NotifiModuleMsg4 AS nvarchar(max) ,@NotifiModuleMsg5 AS nvarchar(max),@NotifiDays AS NVARCHAR(max)

	 ,@NotifiTempMsgActionAR AS NVARCHAR(max),@NotifiTempMsgRoleAR AS NVARCHAR(max)
	 , @NotifiMsg2AR AS nvarchar(max),@NotifiMsg3AR AS nvarchar(max),@NotifiMsg4AR AS nvarchar(max),@NotifiMsg5AR AS nvarchar(max)  
	 ,@NotifiMsg6AR AS nvarchar(max),@NotifiModuleMsg1AR AS nvarchar(max),@NotifiModuleMsg2AR AS nvarchar(max),  @NotifiRecipientAR AS NVARCHAR(MAX) ,
	 @NotifiModuleMsg3AR AS nvarchar(MAX),@NotifiModuleMsg4AR AS nvarchar(max) ,@NotifiModuleMsg5AR AS nvarchar(max),@NotifiDaysAR AS NVARCHAR(max)

	 ,@NotifiTempMsgActionFR AS NVARCHAR(max),@NotifiTempMsgRoleFR AS NVARCHAR(max)
	 , @NotifiMsg2FR AS nvarchar(max),@NotifiMsg3FR AS nvarchar(max),@NotifiMsg4FR AS nvarchar(max),@NotifiMsg5FR AS nvarchar(max)  
	 ,@NotifiMsg6FR AS nvarchar(max),@NotifiModuleMsg1FR AS nvarchar(max),@NotifiModuleMsg2FR AS nvarchar(max),  @NotifiRecipientFR AS NVARCHAR(MAX) ,
	 @NotifiModuleMsg3FR AS nvarchar(MAX),@NotifiModuleMsg4FR AS nvarchar(max) ,@NotifiModuleMsg5FR AS nvarchar(max),@NotifiDaysFR AS NVARCHAR(max)

	 SELECT @MsgSeparator=rtrim(ltrim(isnull(dbo.Hits_GetDCCaption('WFAction','separator',@latinlang),':')))    
	 ,@MsgH= isnull(dbo.Hits_GetDCCaption('WFAction','Header',@latinlang),'')+
	 case when @action=0 then ' '+isnull(dbo.Hits_GetDCCaption('NotificationWFAction','InviteAction',@latinlang),'')+' ' else '' end
	 ,@MsgF=isnull(dbo.Hits_GetDCCaption('WFAction','Footer',@latinlang),'')
	 ,@Recipient=''
	 
	  IF @SMSorMail = 0
	  BEGIN
		SELECT  @NotifiMsg2= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Request','E'),'request for employee')                          
	 , @NotifiMsg3= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestApproved','E'),'has been approved by')                          
	 , @NotifiMsg4= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestRejected','E'), 'has been rejected by')                          
	 , @NotifiMsg5= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestChanged','E'),'has been changed by')                          
	 , @NotifiMsg6 = isnull(dbo.Hits_GetDCCaption('NotificationWFAction','NewRequest','E'),'waiting your approval')                          
	 , @Notifidays = isnull(dbo.Hits_GetDCCaption('WFAction','Days','E'),'Days')

	 , @NotifiMsg2AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Request','A'),N'للموظف ')                          
	 , @NotifiMsg3AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestApproved','A'),N'قد تم الموافقة عليها بواسطة ')                          
	 , @NotifiMsg4AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestRejected','A'),N'قد تم رفضها بواسطة ')                          
	 , @NotifiMsg5AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestChanged','A'),N'قد تم تغييرها بواسطة ')                          
	 , @NotifiMsg6AR = isnull(dbo.Hits_GetDCCaption('NotificationWFAction','NewRequest','A'),N'في انتظار موافقتك على الطلب')                          
	 , @NotifidaysAR = isnull(dbo.Hits_GetDCCaption('WFAction','Days','A'), N'ايام')

	 , @NotifiMsg2FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Request','F'),'request for employee')                          
	 , @NotifiMsg3FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestApproved','F'),'has been approved by')                          
	 , @NotifiMsg4FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestRejected','F'), 'has been rejected by')                          
	 , @NotifiMsg5FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','RequestChanged','F'),'has been changed by')                          
	 , @NotifiMsg6FR = isnull(dbo.Hits_GetDCCaption('NotificationWFAction','NewRequest','F'),'waiting your approval') 
	 , @NotifidaysFR = isnull(dbo.Hits_GetDCCaption('WFAction','Days','F'),'Days')
	  END
      
	   
	   
	 SELECT  @Msg2= isnull(dbo.Hits_GetDCCaption('WFAction','2',@latinlang),(case when @latinlang='E' then 'request for employee'+@MsgSeparator else N'للموظف '+@MsgSeparator end))                          
	 , @Msg3= isnull(dbo.Hits_GetDCCaption('WFAction','3',@latinlang),(case when @latinlang='E' then 'has been approved by'+@MsgSeparator else N'قد تم الموافقة عليها بواسطة '+@MsgSeparator end))                          
	 , @Msg4= isnull(dbo.Hits_GetDCCaption('WFAction','4',@latinlang),(case when @latinlang='E' then 'has been rejected by'+@MsgSeparator else N'قد تم رفضها بواسطة '+@MsgSeparator end))                          
	 , @Msg5= isnull(dbo.Hits_GetDCCaption('WFAction','5',@latinlang),(case when @latinlang='E' then 'has been changed by'+@MsgSeparator else N'قد تم تغييرها بواسطة '+@MsgSeparator end))                          
	 
	 SELECT @Msg6=  (SELECT  LookupSelect FROM DataDictionary  WHERE TableName = 'WFAction' AND FieldName='6')
     SELECT @Msg7=  (SELECT  LookupSelect FROM DataDictionary  WHERE TableName = 'WFAction' AND FieldName='7')                     
     SELECT @Msg8= case when @action=0 then isnull(dbo.Hits_GetDCCaption('WFAction','9',@latinlang),(case when @latinlang='E' then 'The message is '+@MsgSeparator else N'الرسالة هي '+@MsgSeparator end)) 
	 else  isnull(dbo.Hits_GetDCCaption('WFAction','8',@latinlang),(case when @latinlang='E' then 'The reason is '+@MsgSeparator else N'السبب هو '+@MsgSeparator end)) end
     , @msg9 = ''
		 ,@SeparatorEnter=isnull(dbo.Hits_GetDCCaption('WFAction','SeparatorEnter' ,@latinlang),'<br>')
        ,@SeparatorEnter2=isnull(dbo.Hits_GetDCCaption('WFAction','SeparatorEnter2',@latinlang),'')  --enter for merck
        ,@days = isnull(dbo.Hits_GetDCCaption('WFAction','Days',@latinlang),(case when @latinlang='e' then 'Days' else N'ايام' end))
      
	
    SELECT @Msg6=CASE WHEN isnull(ltrim(rtrim(@Msg6)),'')=''  THEN (select dbo.Hits_GetDCCaption('WFAction','6',@latinlang))  ELSE ltrim(rtrim(@Msg6)) END 
    SELECT @Msg6= CASE WHEN isnull(ltrim(rtrim(@Msg6)),'')='' then (case when @latinlang='E' then 'Waiting for your action' else N'فى انتظار موافقتك على هذا الطلب' END) ELSE ltrim(rtrim(@Msg6)) END                           	   
    --  SELECT @Msg7=CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')=''  THEN (select dbo.Hits_GetDCCaption('WFAction','7',@latinlang) )  ELSE ltrim(rtrim(@Msg7)) END 
	--SELECT  @Msg7= CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')='' then (case when @latinlang='E' then 'Please visit the following site to check this request' else N'برجاء زيارة هذا الموقع لمراجعة هذا الطلب' end) ELSE ltrim(rtrim(@Msg7)) END                           	   
	 
    SELECT @Msg7=CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')=''  THEN ( dbo.Hits_GetDCCaption('WFAction','7',@latinlang)+' '+ CASE WHEN isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('WFAction','7',@latinlang))),'')<>'' AND @SSDocType<>20 THEN  ltrim(rtrim(@sswebsite)) ELSE '' end  )  ELSE ltrim(rtrim(@Msg7)) END 
    SELECT @Msg7= CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')='' then (case when @latinlang='E' then 'Please visit the following site to check this request'+' '+ ltrim(rtrim(@sswebsite)) else N'برجاء زيارة هذا الموقع لمراجعة هذا الطلب' +' '+ CASE WHEN @SSDocType<>20 THEN  ltrim(rtrim(@sswebsite))ELSE '' END  end) ELSE ltrim(rtrim(@Msg7)) END                           	   


	--SELECT @subject =''
 --   SELECT @subject = (select LookupSelect FROM DataDictionary  WHERE TableName LIKE '%WFActionSubject%' AND FieldName=ltrim(@SSDocType))
 --   SELECT @subject = REPLACE (@subject , '@latinlang', ''''+@latinlang+'''' )  
 --   SELECT @subject = REPLACE (@subject , '@Empid',  @Empid  ) 
 --   SELECT @subject = REPLACE (@subject , '@documentno',  @documentno )
    --
    --declare @TempSubject TABLE ([Subject] NVARCHAR(MAX))
    --INSERT INTO @TempSubject
    --EXEC(@subject)
    --SELECT @subject=SUBJECT FROM @TempSubject
    
    
    --
--    DECLARE @sql AS NVARCHAR(MAX),@cmd AS NVARCHAR(MAX)
--    SELECT @sql = '    CREATE TABLE #Subject( [Subject] NVARCHAR(MAX))
--    INSERT INTO #Subject 
--    EXEC(@subject)
--    SELECT @subject=SUBJECT FROM #Subject
--	DROP TABLE #Subject '
--SELECT @cmd = 'sqlcmd -S ' + @@servername +
--              ' -d ' + db_name() + ' -Q "' + @sql + '"'
--EXEC master..xp_cmdshell @cmd, 'no_output'


    --
 --   CREATE TABLE #Subject( [Subject] NVARCHAR(MAX))
 --   INSERT INTO #Subject 
 --   EXEC(@subject)
 --   SELECT @subject=SUBJECT FROM #Subject
	--DROP TABLE #Subject
	
	
	--DECLARE @str AS NVARCHAR(max)
	--SET @str = '
	--    CREATE TABLE #Subject( [Subject] NVARCHAR(MAX))
 --   INSERT INTO #Subject 
 --   EXEC('+ltrim(@subject)+')
 --   SELECT @subject=SUBJECT FROM #Subject
	--DROP TABLE #Subject
 --  '


 --  EXECUTE sys.sp_executesql @str,N' @subject as nvarchar(max) output', @subject OUTPUT


		SELECT  @tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end 
		from profile with (nolock) where profileid = @RoleProfileid       
  
	
if @SSDocType=3 --vacation
  BEGIN
  
		IF @SMSorMail = 0 
		BEGIN	
			SELECT @NotifiModuleMsg1= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Vacation','E'),'Vacation')                                 
  			  ,@NotifiModuleMsg2= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','VacationFromDate','E'),'From Date')                                 
  			  ,@NotifiModuleMsg3= ISNULL(dbo.Hits_GetDCCaption('NotificationWFAction','VacationToDate','E'),'To Date')                                 
  			  
			  ,@NotifiModuleMsg1AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Vacation','A'),N'اجازة')                                 
  			  ,@NotifiModuleMsg2AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','VacationFromDate','A'),N'من')                                 
  			  ,@NotifiModuleMsg3AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','VacationToDate','A'),N'إلى')                                 

			  ,@NotifiModuleMsg1FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Vacation','F'),'Vacation')                                 
  			  ,@NotifiModuleMsg2FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','VacationFromDate','F'),'From Date')                                 
  			  ,@NotifiModuleMsg3FR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','VacationToDate','F'),'To Date')           
			  
			  SELECT   @notifiBody = 	rtrim(@NotifiModuleMsg1)+' '+ rtrim(@NotifiMsg2)+' '+  ltrim(rtrim(Profile.Name)) +
			' '+RTRIM(@NotifiModuleMsg1)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(vacation.vacationname)) +
			' '+RTRIM(@NotifiModuleMsg2)+' '+
			LTRIM(RTRIM(DAY(empvacat.FromDate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.FromDate),'E')))
			,left(DATENAME(month,empvacat.FromDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.FromDate)))
			 +' '+rtrim(@NotifiModuleMsg3)+' '+
			
			LTRIM(RTRIM(DAY(empvacat.ToDate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.ToDate),'E'))),
			LEFT(DATENAME(month,empvacat.ToDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.ToDate)))
			+ ' '+ LTRIM(' ('+RTRIM(CAST(dbo.VacTakenDays(dbo.EmpVacat.EmpId, dbo.EmpVacat.FromDate, dbo.EmpVacat.ToDate, dbo.EmpVacat.VacCode, dbo.EmpVacat.DocumentNo, dbo.EmpVacat.PartDayFrom, 
			dbo.EmpVacat.PartDayTo)AS FLOAT))+' ' +@NotifiDays+')')  

			 ,@notifiBodyAR =	 RTRIM(@NotifiModuleMsg1AR)+' '+ rtrim(@NotifiMsg2AR)+' '+ltrim(rtrim(Profile.aName)) +
			' '+RTRIM(@NotifiModuleMsg1AR)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(vacation.vacationaname )) +
			' '+RTRIM(@NotifiModuleMsg2AR)+' '+
			CONVERT(char(11), empvacat.FromDate,103)  +' '+rtrim(@NotifiModuleMsg3AR)+' '+CONVERT(char(11), empvacat.ToDate,103) 
			+ ' '+ LTRIM(' ('+RTRIM(CAST(dbo.VacTakenDays(dbo.EmpVacat.EmpId, dbo.EmpVacat.FromDate, dbo.EmpVacat.ToDate, dbo.EmpVacat.VacCode, dbo.EmpVacat.DocumentNo, dbo.EmpVacat.PartDayFrom, 
			dbo.EmpVacat.PartDayTo)AS FLOAT))+' ' +@NotifiDaysAR+')')  

			,@notifiBodyFR = rtrim(@NotifiModuleMsg1FR)+' '+ rtrim(@NotifiMsg2FR)+' '+  ltrim(rtrim(Profile.FName)) +
			' '+RTRIM(@NotifiModuleMsg1FR)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(vacation.vacationFname)) +
			' '+RTRIM(@NotifiModuleMsg2FR)+' '+
			LTRIM(RTRIM(DAY(empvacat.FromDate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.FromDate),'F')))
			,left(DATENAME(month,empvacat.FromDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.FromDate)))
			 +' '+rtrim(@NotifiModuleMsg3)+' '+
			
			LTRIM(RTRIM(DAY(empvacat.ToDate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.ToDate),'F'))),
			LEFT(DATENAME(month,empvacat.ToDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.ToDate)))
			+ ' '+ LTRIM(' ('+RTRIM(CAST(dbo.VacTakenDays(dbo.EmpVacat.EmpId, dbo.EmpVacat.FromDate, dbo.EmpVacat.ToDate, dbo.EmpVacat.VacCode, dbo.EmpVacat.DocumentNo, dbo.EmpVacat.PartDayFrom, 
			dbo.EmpVacat.PartDayTo)AS FLOAT))+' ' +@NotifiDaysFR+')') 


			FROM profile with (nolock) inner join empvacat WITH (NOLOCK) on profile.profileid=empvacat.empid 
			inner join vacation on vacation.vaccode=empvacat.vaccode 

			where profileid = @Empid and empvacat.documentno=@documentno    

			SELECT @NotifiTempMsgAction=CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
		,@NotifiTempMsgRole= RTRIM(ltrim(name))  
		,@NotifiTempMsgActionAR=CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
		,@NotifiTempMsgRoleAR= RTRIM(ltrim(aname))  
		,@NotifiTempMsgActionFR=CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
		,@NotifiTempMsgRoleFR= RTRIM(ltrim(Fname))  
		
		FROM profile with (nolock) where profileid = @RoleProfileid
       
		SELECT @notifiBody = @notifiBody +' '+  CASE WHEN @NotifiTempMsgAction LIKE '%@RoleName%' THEN @NotifiTempMsgRole +replace( @NotifiTempMsgAction ,'@RoleName','') ELSE   @NotifiTempMsgAction  + @NotifiTempMsgRole END
		,@notifiBodyAR =   @notifiBodyAR   +' '+  CASE WHEN @NotifiTempMsgActionAR  LIKE '%@RoleName%' THEN @NotifiTempMsgRoleAR +replace( @NotifiTempMsgActionAR ,'@RoleName','') ELSE   @NotifiTempMsgActionAR  + @NotifiTempMsgRoleAR END
		,@notifiBodyFR =   @notifiBodyFR   +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN @NotifiTempMsgRoleFR +replace(@NotifiTempMsgActionFR,'@RoleName','') ELSE  @NotifiTempMsgActionFR + @NotifiTempMsgRoleFR END

		END                 
		ELSE
		BEGIN

  			SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Vacation',@latinlang),(case when @latinlang='E' then 'Vacation' else N'اجازة' end))                                 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','VacationFromDate',@latinlang),(case when @latinlang='E' then 'From Date' else N'من' end))                                 
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','VacationToDate',@latinlang),(case when @latinlang='E' then 'To Date' else N'إلى' end))                                 
  	        ,@ModuleMsg12=isnull(dbo.Hits_GetDCCaption('WFAction','Vacation2',@latinlang),(case when @latinlang='E' then 'Vacation' else N'اجازة' end))

			 -- for customer "merck"
  	        , @msg9 =isnull(dbo.Hits_GetDCCaption('WFAction','Dear',@latinlang),'')
  	        , @msg10=ISNULL(dbo.Hits_GetDCCaption('WFAction','Message1',@latinlang),'')  
	        , @msg11= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message2',@latinlang),'')
	        , @msg12 =ISNULL(dbo.Hits_GetDCCaption('WFAction','Message3',@latinlang),'')
	        , @msg13= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message4',@latinlang),'')
	        , @msg14 =ISNULL(dbo.Hits_GetDCCaption('WFAction','KindRegards',@latinlang),'')
	        , @msg15= ISNULL(dbo.Hits_GetDCCaption('WFAction','TheMEHRteam',@latinlang),'')
	       
	       SELECT @msg16 =replace(LookupSelect,'@@syswebsite',@sswebsite) FROM DataDictionary WHERE TableName ='WFAction' AND FieldName ='Message7'
	if isnull(ltrim(rtrim(@propname)),'')='Delta Marketing Co'
		BEGIN		
		select @body=ltrim(RTRIM(@MsgH))+' '
		+CASE WHEN @latinlang='A' THEN ltrim(rtrim(vacation.vacationaname)) ELSE ltrim(rtrim(vacation.vacationname)) END 
		+' '+RTRIM(@Msg2)+' '
		+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END 
		+' '+LTRIM(EmpAssignment.EmployeeId)+nchar(13)+nchar(10)
		+rtrim(@ModuleMsg2)+' '+CONVERT(nchar(11), empvacat.FromDate,CASE WHEN @Latinlang='A' THEN 103 ELSE 100 end)
		+' '+rtrim(@ModuleMsg3)+' '+CONVERT(nchar(11), empvacat.ToDate, CASE WHEN @Latinlang='A' THEN 103 ELSE 100 end)
		from profile with (nolock) inner join empvacat with (nolock) on profile.profileid=empvacat.empid 
		inner join vacation on vacation.vaccode=empvacat.vaccode 
		INNER JOIN EmpAssignment with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
		where profileid = @Empid and empvacat.documentno=@documentno

	END 
	else 
	begin
	select @body=LTRIM(RTRIM(@MsgH))+' '+case when @action=0 and @msg9 ='' then isnull(@tempMsgRole,'') +' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +
			rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
			CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(vacation.vacationaname )) WHEN @Switchlang='F' THEN  ltrim(rtrim(vacation.vacationFname )) ELSE  ltrim(rtrim(vacation.vacationname))  END +
			CASE WHEN @msg9 ='' THEN ' ' ELSE   CHAR(13)+CHAR(10) END +rtrim(@ModuleMsg2)+' '+
			
			CASE WHEN @Latinlang='A' THEN CONVERT(char(11), empvacat.FromDate,103) ELSE LTRIM(RTRIM(DAY(empvacat.FromDate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.FromDate),@Latinlang))),left(DATENAME(month,empvacat.FromDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.FromDate)))
			end +' '+rtrim(@ModuleMsg3)+' '+
			
			CASE WHEN @Latinlang='A' THEN CONVERT(char(11), empvacat.ToDate,103) ELSE LTRIM(RTRIM(DAY(empvacat.ToDate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empvacat.ToDate),@Latinlang))),left(DATENAME(month,empvacat.ToDate),3))+' '+LTRIM(RTRIM(YEAR(empvacat.ToDate)))
			end
			+  LTRIM('('+RTRIM(CAST(dbo.VacTakenDays(dbo.EmpVacat.EmpId, dbo.EmpVacat.FromDate, dbo.EmpVacat.ToDate, dbo.EmpVacat.VacCode, dbo.EmpVacat.DocumentNo, dbo.EmpVacat.PartDayFrom, 
			dbo.EmpVacat.PartDayTo)AS FLOAT))+' ' +@days+')')

			FROM profile with (nolock) inner join empvacat WITH (NOLOCK) on profile.profileid=empvacat.empid 
			inner join vacation on vacation.vaccode=empvacat.vaccode 

			where profileid = @Empid and empvacat.documentno=@documentno
		END
		
		IF  @msg9 ='' and @action<>0 -- condition to check customer is not "merck" 
		BEGIN
      
		
		
			SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
		,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       
		SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN @tempMsgRole +replace(@TempMsgAction,'@RoleName','') ELSE  @TempMsgAction + @tempMsgRole END

	END 
END
  end
if  @SSDocType   = 1 -- change of status 
  BEGIN
		IF @SMSorMail = 0 
		BEGIN
			SELECT @NotifiModuleMsg1= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','ChangeofStatus','E'),'change of status' )                                 
  			  ,@NotifiModuleMsg2= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Changeofstatusdate','E'),'As Of Date')                                 
			  
			  ,@NotifiModuleMsg1AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','ChangeofStatus','A'),N'تغير الحالة' )                                 
  			  ,@NotifiModuleMsg2AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Changeofstatusdate','A'),N'بتاريخ')
			                                   
			  ,@NotifiModuleMsg1FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','ChangeofStatus','F'),'change of status' )                                 
  			  ,@NotifiModuleMsg2FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Changeofstatusdate','F'),'As Of Date')


			SELECT @notifiBody=rtrim(@NotifiModuleMsg1)+' '+ rtrim(@NotifiMsg2)+' '+ ltrim(rtrim(Profile.Name)) +
				' '+ RTRIM(@NotifiModuleMsg1)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(ChngStat.Chgname))   
				+' '+ ' '+rtrim(@NotifiModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 			LTRIM(RTRIM(DAY(EmpStatusHdr.EffectiveDate)))+' '+
			    ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpStatusHdr.EffectiveDate),'E'))),left(DATENAME(month,EmpStatusHdr.EffectiveDate),3))+' '+LTRIM(RTRIM(YEAR(EmpStatusHdr.EffectiveDate))) 
			
			,@notifiBodyAR=rtrim(@NotifiModuleMsg1AR)+' '+ rtrim(@NotifiMsg2AR)+' '+ltrim(rtrim(Profile.AName)) +
			' '+ RTRIM(@NotifiModuleMsg1AR)+rtrim(ltrim(@MsgSeparator))+' '+ ltrim(rtrim(ChngStat.ChgAname ))
			 +' '+ ' '+rtrim(@NotifiModuleMsg2AR)+rtrim(ltrim(@MsgSeparator))+' '+
	 		CONVERT(char(11),EmpStatusHdr.EffectiveDate,103) 

			,@notifiBodyFR=rtrim(@NotifiModuleMsg1FR)+' '+ rtrim(@NotifiMsg2FR)+' '+ ltrim(rtrim(Profile.FName)) +
			' '+ RTRIM(@NotifiModuleMsg1FR)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(ChngStat.ChgFname))   
			+' '+ ' '+rtrim(@NotifiModuleMsg2FR)+rtrim(ltrim(@MsgSeparator))+' '+
	 		LTRIM(RTRIM(DAY(EmpStatusHdr.EffectiveDate)))+' '+
		    ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpStatusHdr.EffectiveDate),'F'))),left(DATENAME(month,EmpStatusHdr.EffectiveDate),3))+' '+LTRIM(RTRIM(YEAR(EmpStatusHdr.EffectiveDate))) 
		
		
			FROM  EmpStatusHdr WITH (NOLOCK)
			INNER JOIN ChngStat ON EmpStatusHdr.ChgCode = ChngStat.chgcode 
			INNER JOIN Profile with (nolock) ON EmpStatusHdr.EmpId = Profile.ProfileId
			 WHERE profileid = @Empid and EmpStatusHdr.documentno=@documentno


			SELECT @notifiBody =  @notifiBody  + ' '+case @action when 1 then ' '+rtrim(@NotifiMsg3)+' ' when 2 then ' '+rtrim(@NotifiMsg4)+' ' when 3 then  ' '+rtrim(@NotifiMsg5)+' 'END +rtrim(ltrim(name))  
			,@notifiBodyAR =   @notifiBodyAR  + ' '+case @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' ' when 2 then ' '+rtrim(@NotifiMsg4AR)+' ' when 3 then  ' '+rtrim(@NotifiMsg5AR)+' 'END + RTRIM(ltrim(aname))
			,@notifiBodyFR =   @notifiBodyFR  + ' '+case @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' ' when 2 then ' '+rtrim(@NotifiMsg4FR)+' ' when 3 then  ' '+rtrim(@NotifiMsg5FR)+' 'END +rtrim(ltrim(Fname))  

			FROM profile with (nolock) where profileid = @RoleProfileid 
		END
        
		ELSE
		BEGIN
			 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','ChangeofStatus',@latinlang),(case when @latinlang='E' then 'change of status' else N'تغير الحالة' end))                                 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','Changeofstatusdate',@latinlang),(case when @latinlang='E' then 'As Of Date' else N'بتاريخ' end))                                 
  			,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','ChangeofStatus2',@latinlang),(case when @latinlang='E' then 'Change of status' else N'تغير الحالة' end))
		
			 DECLARE @ChangeStatusDetails AS SMALLINT=0,@DetailsStmt as nvarchar(max)='', @enablerolevalidation as bit
			 SELECT  @ChangeStatusDetails=isnull(ConfigValue,'0') FROM dbo.SysParamConfig  WHERE ConfigID=LTRIM(RTRIM('ChangeOfStatusNotificationDetails'))

			 IF ISNULL(ltrim(rtrim(@propname)),'')='Delta Marketing Co'
			  BEGIN	  
	             DECLARE  @ChangeFields table(fieldname nvarchar(60), OldValue nvarchar(60),NewValue nvarchar(60))
            IF  @ProfileID=@Empid
             BEGIN  
                   --PRINT 'emp'
				   			 DELETE FROM @ChangeFields
                  INSERT into @ChangeFields
				 SELECT case when empstatusdtl.fieldno >1000  then 
					CASE when @Latinlang='e' then Paycodename else paycodeaname end 
					ELSE   case when @Latinlang='E' then chgfield.edesc else chgfield.adesc end 
					END 
					, case when isnull(chngstatfields.hideoldvalue,0)=0 
					THEN dbo.getoldvaluetxt(empstatusdtl.fieldno,dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency),@Latinlang) else '' end 
				,case when isnull(chngstatfields.acceptnewvalue,1)=1 then dbo.getoldvaluetxt(empstatusdtl.fieldno,NewValue,@Latinlang) else '' end  
				  from empstatushdr with (nolock)
				  left join empstatusdtl with (nolock) on empstatushdr.empid =empstatusdtl.empid and empstatushdr.documentno=empstatusdtl.documentno
				  left join chngstatfields on chngstatfields.chgcode= empstatushdr.chgcode and chngstatfields.fieldno=empstatusdtl.fieldno
				  left join empassignment with (nolock) on empassignment.empid=empstatushdr.empid
				  left join nasarrays chgfield on chgfield.itemno=empstatusdtl.fieldno and chgfield.arrayname='chngstatus'
				  left join Paycode on Paycode.code=empstatusdtl.fieldno-1000 and empstatusdtl.fieldno>1000	  
				  where empstatushdr.empid =@Empid and empstatushdr.documentno=@documentno
				  and not (isnull(chngstatfields.hideoldvalue,0)=1 and isnull(chngstatfields.acceptnewvalue,1)=0)
	              DELETE from @ChangeFields where oldvalue='' and newvalue=''
              END
             ELSE  	  
              BEGIN  

	  select @enablerolevalidation=sysparam.enablerolevalidation from sysparam
	  declare @roles as nvarchar(max)='#'
	  DECLARE @RolesT TABLE (RoleId SMALLINT)
		INSERT INTO @RolesT SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId=@ProfileID 
		SELECT @roles = @roles + ltrim(RoleId)+'#'
		FROM  @RolesT

	  --declare @roles as nvarchar(max)=''
	  --select @roles =@roles+'#'+ltrim(rtrim(str(roleid)))
	  --from ssgrouprole
	  ----inner join empassignment on empassignment.ssgroup=ssgrouprole.ssgroup 
	  --where profileid= @ProfileID --and empassignment.empid=@empid
	  ----SELECT @roles
	  --select @roles =@roles+'#'   

       INSERT into @ChangeFields
	     SELECT case when empstatusdtl.fieldno >1000  then 
	        CASE when @latinlang='e' then Paycodename else paycodeaname end 
	        ELSE   case when @Latinlang='E' then chgfield.edesc else chgfield.adesc end 
			END 
			, case when isnull(chngstatfields.hideoldvalue,0)=0 and (
			 (@enablerolevalidation=1 and dbo.rolesexist(@roles,'$'+ISNULL(case when empstatusdtl.fieldno=1 then OldHrStatus.HrStatusRoles 
			                                when empstatusdtl.fieldno=5 then OldJob.JobsRoles 
											when empstatusdtl.fieldno=6 then OldOrganization.OrganizationRoles
											when empstatusdtl.fieldno=7 then OldGrade.GradesRoles
											when empstatusdtl.fieldno=8 then OldPosition.PositionsRoles
											when empstatusdtl.fieldno=9 then OldLocation.LocationRoles
											when empstatusdtl.fieldno=10 then OldEmployer.EmployerRoles
											when empstatusdtl.fieldno=19 then OldVacPack.VacPackRoles
											when empstatusdtl.fieldno=22 then OldSalaryScale.SalaryScalesRoles
											when empstatusdtl.fieldno=23 then OldContractType.ContractTypeRoles
											when empstatusdtl.fieldno=28 then OldTimeRule.TimeRulesRoles
											when empstatusdtl.fieldno>1000 then Paycode.PaycodeRoles
											else ''
											end ,'')+'$',0,0)=1) or @enablerolevalidation=0 ) then dbo.getoldvaluetxt(empstatusdtl.fieldno,dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency),@Latinlang) else '' end 
	    ,case when isnull(chngstatfields.acceptnewvalue,1)=1 and (
		(@enablerolevalidation=1 and dbo.rolesexist(@roles,'$'+ISNULL(case when empstatusdtl.fieldno=1 then NewHrStatus.HrStatusRoles 
			                                when empstatusdtl.fieldno=5 then NewJob.JobsRoles 
											when empstatusdtl.fieldno=6 then NewOrganization.OrganizationRoles
											when empstatusdtl.fieldno=7 then NewGrade.GradesRoles
											when empstatusdtl.fieldno=8 then NewPosition.PositionsRoles
											when empstatusdtl.fieldno=9 then NewLocation.LocationRoles
											when empstatusdtl.fieldno=10 then NewEmployer.EmployerRoles
											when empstatusdtl.fieldno=19 then NewVacPack.VacPackRoles
											when empstatusdtl.fieldno=22 then NewSalaryScale.SalaryScalesRoles
											when empstatusdtl.fieldno=23 then NewContractType.ContractTypeRoles
											when empstatusdtl.fieldno=28 then NewTimeRule.TimeRulesRoles
											when empstatusdtl.fieldno>1000 then Paycode.PaycodeRoles
											else ''
											end ,'')+'$',0,0)=1) or @enablerolevalidation=0 ) then dbo.getoldvaluetxt(empstatusdtl.fieldno,NewValue,@Latinlang) else '' end  
	  from empstatushdr with (nolock)
	  left join empstatusdtl with (nolock) on empstatushdr.empid =empstatusdtl.empid and empstatushdr.documentno=empstatusdtl.documentno
	  left join chngstatfields on chngstatfields.chgcode= empstatushdr.chgcode and chngstatfields.fieldno=empstatusdtl.fieldno
	  left join empassignment with (nolock) on empassignment.empid=empstatushdr.empid
	  left join nasarrays chgfield on chgfield.itemno=empstatusdtl.fieldno and chgfield.arrayname='chngstatus'
	  left join Paycode on Paycode.code=empstatusdtl.fieldno-1000 and empstatusdtl.fieldno>1000
	  left join hrstatus NewHrStatus on NewHrStatus.hrstatus=empstatusdtl.newvalue and empstatusdtl.fieldno=1 
	  left join hrstatus oldHrStatus on oldHrStatus.hrstatus=case when empstatusdtl.fieldno=1 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=1 
	  left join Jobs NewJob on NewJob.Job=empstatusdtl.newvalue and empstatusdtl.fieldno=5 
	  left join Jobs oldJob on oldJob.Job=case when empstatusdtl.fieldno=5 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end  and empstatusdtl.fieldno=5 
	  left join Organization NewOrganization on NewOrganization.Organization=empstatusdtl.newvalue and empstatusdtl.fieldno=6 
	  left join Organization oldOrganization on oldOrganization.Organization= case when empstatusdtl.fieldno=6 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end and empstatusdtl.fieldno=6 
	  left join Grades NewGrade on NewGrade.Grade=empstatusdtl.newvalue and empstatusdtl.fieldno=7 
	  left join Grades oldGrade on oldGrade.Grade=case when empstatusdtl.fieldno=7 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end and empstatusdtl.fieldno=7 
	  left join Positions NewPosition on NewPosition.positionno=empstatusdtl.newvalue and empstatusdtl.fieldno=8 
	  left join Positions oldPosition on oldPosition.positionno=case when empstatusdtl.fieldno=8 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=8 
	  left join Location NewLocation  on  NewLocation.Locationno=empstatusdtl.newvalue and empstatusdtl.fieldno=9 
	  left join Location oldLocation on oldLocation.Locationno=case when empstatusdtl.fieldno=9 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end  and empstatusdtl.fieldno=9 
	  left join Employer NewEmployer  on  NewEmployer.EmployerId=empstatusdtl.newvalue and empstatusdtl.fieldno=10 
	  left join Employer oldEmployer on oldEmployer.EmployerId=case when empstatusdtl.fieldno=10 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=10 
	  left join VacPack NewVacPack  on  NewVacPack.VacPack=empstatusdtl.newvalue and empstatusdtl.fieldno=19 
	  left join VacPack oldVacPack on oldVacPack.VacPack=case when empstatusdtl.fieldno=22 and @enablerolevalidation=1  then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end and empstatusdtl.fieldno=19 
	  left join SalaryScales NewSalaryScale  on  NewSalaryScale.SalaryScaleId=empstatusdtl.newvalue and empstatusdtl.fieldno=22 
	  left join SalaryScales oldSalaryScale on oldSalaryScale.SalaryScaleId= case when empstatusdtl.fieldno=22 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) else 0 end  and empstatusdtl.fieldno=22 
	  left join ContractType NewContractType on  NewContractType.ContractType=case when empstatusdtl.fieldno=23 and @enablerolevalidation=1 then empstatusdtl.newvalue else 0 end  and empstatusdtl.fieldno=23 
	  left join ContractType oldContractType on oldContractType.ContractType=dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency) and empstatusdtl.fieldno=23 
	  left join TimeRules NewTimeRule on  NewTimeRule.TimeRule=empstatusdtl.newvalue and empstatusdtl.fieldno=28 
	  left join TimeRules oldTimeRule on oldTimeRule.TimeRule= case when empstatusdtl.fieldno=28 and @enablerolevalidation=1 then dbo.getoldvalue( empstatushdr.empid,empstatusdtl.fieldno,effectivedate,empassignment.hrcurrency)else 0 end  and empstatusdtl.fieldno=28 
	  
	  where empstatushdr.empid =@Empid and empstatushdr.documentno=@documentno
	  and not (isnull(chngstatfields.hideoldvalue,0)=1 and isnull(chngstatfields.acceptnewvalue,1)=0)
       --SELECT *FROM @ChangeFields       
	   DELETE from @ChangeFields where oldvalue='' and newvalue=''
	   END 
	  select @DetailsStmt=ISNULL(@DetailsStmt,'')+' '+ltrim(rtrim(ISNULL([@ChangeFields].fieldname,'')))+' '+ case when ltrim(rtrim(ISNULL([@ChangeFields].oldvalue,''))) <>'' then isnull(dbo.Hits_GetDCCaption('WFAction','OldValue',@latinlang)  ,case when @latinlang='e' then 'OldValue' else N'القيمة القديمة' end )+':' else '' end +ltrim(rtrim(ISNULL([@ChangeFields].oldvalue,'')))
	  +case when ltrim(rtrim(ISNULL([@ChangeFields].oldvalue,''))) <>''  AND  ltrim(rtrim(ISNULL([@ChangeFields].newvalue,''))) <>''THEN ' , ' ELSE '' END + case when ltrim(rtrim(ISNULL([@ChangeFields].newvalue,''))) <>'' then isnull(dbo.Hits_GetDCCaption('WFAction','NewValue',@latinlang)  ,case when @latinlang='e' then 'NewValue' else N'القيمة الجديدة' end )+':' else '' end +ltrim(rtrim(ISNULL([@ChangeFields].Newvalue,''))) +@SeparatorEnter
	  from @ChangeFields

	   SELECT @DetailsStmt='('+substring(@DetailsStmt,1,len(@DetailsStmt))+')'
       --DROP table [@ChangeFields]
	   END
 
 	SELECT @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then isnull(@tempMsgRole,'')+' for ' else ''  end +rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+ CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) end+
		CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
		CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(ChngStat.ChgAname )) WHEN @Switchlang='F' THEN  ltrim(rtrim(ChngStat.ChgFname )) ELSE  ltrim(rtrim(ChngStat.Chgname))  END 
		+' '+ISNULL(@DetailsStmt,'')+' '+
		' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
		CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpStatusHdr.EffectiveDate,103) ELSE LTRIM(RTRIM(DAY(EmpStatusHdr.EffectiveDate)))+' '+
		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpStatusHdr.EffectiveDate),@Latinlang))),left(DATENAME(month,EmpStatusHdr.EffectiveDate),3))+' '+LTRIM(RTRIM(YEAR(EmpStatusHdr.EffectiveDate))) end
	FROM  EmpStatusHdr WITH (NOLOCK)
	INNER JOIN ChngStat ON EmpStatusHdr.ChgCode = ChngStat.chgcode 
	INNER JOIN Profile with (nolock) ON EmpStatusHdr.EmpId = Profile.ProfileId
		where profileid = @Empid and EmpStatusHdr.documentno=@documentno


				SELECT @body =@body+case when @action<>0 then +' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then  ' '+rtrim(@Msg5)+' 'END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end 
				else '' end  FROM profile with (nolock) where profileid = @RoleProfileid  
END
  end


if  @SSDocType   = 7 -- Benefit
BEGIN

	IF @SMSorMail = 0 
	BEGIN

		SELECT @NotifiModuleMsg1= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Benefit','E'),'Benefit')                                 
  			  ,@NotifiModuleMsg2= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','BenefitEnrollDate','E'),'Enroll Date')                                 
  			  ,@NotifiModuleMsg3 =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','BenefitOption','E'),'Option')                                 
  		
		, @NotifiModuleMsg1AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Benefit','A'),N'خطة المزايا' )                                 
  			  ,@NotifiModuleMsg2AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','BenefitEnrollDate','A'),N'تاريخ التقديم')                                 
  			  ,@NotifiModuleMsg3AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','BenefitOption','A'),N'الإختيار')                                 

		, @NotifiModuleMsg1FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Benefit','F'),'Benefit')                                 
  			  ,@NotifiModuleMsg2FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','BenefitEnrollDate','F'),'Enroll Date')                                 
  			  ,@NotifiModuleMsg3FR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','BenefitOption','F'),'Option')

			SELECT @notifiBody = rtrim(@NotifiModuleMsg1)+' '+ rtrim(@NotifiMsg2)+' '+LTRIM(rtrim(Profile.Name))  +
		 ' '+rtrim(@NotifiModuleMsg1)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(BenefitPlans.PlanName))   +
		 ' '+rtrim(@NotifiModuleMsg2)+' '+rtrim(ltrim(@MsgSeparator))+' '+
		 	 	LTRIM(RTRIM(DAY(EmpBenefit.EnrollDate)))+' '+
		  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.EnrollDate),'E'))),left(DATENAME(month,EmpBenefit.EnrollDate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.EnrollDate)))
		 +isnull('-'+LTRIM(RTRIM(DAY(EmpBenefit.enddate)))+' '+
		  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.enddate),'E'))),left(DATENAME(month,EmpBenefit.enddate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.enddate)))
		   ,'') +' '+rtrim(@NotifiModuleMsg3)+' '+rtrim(ltrim(@MsgSeparator))+' '+
		  ltrim(rtrim(BenefitOptions.OptionName))   
		
			,@notifiBodyAR = rtrim(@NotifiModuleMsg1AR)+' '+ rtrim(@NotifiMsg2AR)+' '+ltrim(rtrim(Profile.aName)) +
		 ' '+rtrim(@NotifiModuleMsg1AR)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(BenefitPlans.PlanaName )) +
		 ' '+rtrim(@NotifiModuleMsg2AR)+' '+rtrim(ltrim(@MsgSeparator))+' '+
		 	 	CONVERT(char(11),EmpBenefit.EnrollDate,103) 
		 +isnull('-'+ CONVERT(char(11),EmpBenefit.enddate,103)  ,'')
		 +' '+rtrim(@NotifiModuleMsg3AR)+' '+rtrim(ltrim(@MsgSeparator))+' '+  ltrim(rtrim(BenefitOptions.OptionAName )) 
		
			,@notifiBodyFR = rtrim(@NotifiModuleMsg1FR)+' '+ rtrim(@NotifiMsg2FR)+' '+LTRIM(rtrim(Profile.FName))  +
		 ' '+rtrim(@NotifiModuleMsg1FR)+rtrim(ltrim(@MsgSeparator))+' '+ LTRIM(rtrim(BenefitPlans.PlanFName))   +
		 ' '+rtrim(@NotifiModuleMsg2FR)+' '+rtrim(ltrim(@MsgSeparator))+' '+
		 	 	LTRIM(RTRIM(DAY(EmpBenefit.EnrollDate)))+' '+
		  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.EnrollDate),'F'))),left(DATENAME(month,EmpBenefit.EnrollDate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.EnrollDate)))
		 +isnull('-'+LTRIM(RTRIM(DAY(EmpBenefit.enddate)))+' '+
		  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.enddate),'F'))),left(DATENAME(month,EmpBenefit.enddate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.enddate)))
		   ,'') +' '+rtrim(@NotifiModuleMsg3FR)+' '+rtrim(ltrim(@MsgSeparator))+' '+
		  ltrim(rtrim(BenefitOptions.OptionFName))
		
		FROM  EmpBenefit WITH (NOLOCK) INNER JOIN
                      BenefitPlans ON EmpBenefit.PlanNo = BenefitPlans.PlanNo INNER JOIN
                      Profile with (nolock) ON EmpBenefit.EmpId = Profile.ProfileId INNER JOIN
                      BenefitOptions ON EmpBenefit.OptionNo = BenefitOptions.OptionNo
		WHERE profileid = @Empid and EmpBenefit.documentno=@documentno


		SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
	   ,@NotifiTempMsgRole=  rtrim(ltrim(name))  
	   
	   ,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
	   ,@NotifiTempMsgRoleAR= rtrim(ltrim(aname))
		
		,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
	   ,@NotifiTempMsgRoleFR=  rtrim(ltrim(Fname))			
		FROM profile where profileid = @RoleProfileid


		SELECT @notifiBody =  @notifiBody  +' '+  CASE WHEN  @NotifiTempMsgAction  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRole  +' '+replace( @NotifiTempMsgAction ,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3)+' '  when 2 then  ' '+rtrim( @NotifiMsg4)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5)+' ' END +rtrim(ltrim(name))  from profile where profileid = @RoleProfileid )end
		
		, @notifiBodyAR =  @notifiBodyAR +' '+  CASE WHEN  @NotifiTempMsgActionAR  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleAR  +' '+replace( @NotifiTempMsgActionAR ,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3AR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5AR)+' ' END +rtrim(ltrim(aname))  from profile where profileid = @RoleProfileid )end
		, @notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleFR  +' '+replace(@NotifiTempMsgActionFR,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3FR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5FR)+' ' END +rtrim(ltrim(Fname))  from profile where profileid = @RoleProfileid )end

	END
    
	ELSE
    BEGIN
			SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Benefit',@latinlang),(case when @latinlang='E' then 'Benefit' else N'خطة المزايا' end))    
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','BenefitEnrollDate',@latinlang),(case when @latinlang='E' then 'Enroll Date' else N'تاريخ التقديم' end))    
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','BenefitOption',@latinlang),(case when @latinlang='E' then 'Option' else N'الإختيار' end))    
  	       ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Benefit2',@latinlang),(case when @latinlang='E' then 'Benefit' else N'خطة المزايا' end))
  	
  	
		       
	select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @tempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +
		rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
	CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(BenefitPlans.PlanaName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(BenefitPlans.PlanFName )) ELSE  ltrim(rtrim(BenefitPlans.PlanName))  END +
		' '+rtrim(@ModuleMsg2)+' '+rtrim(ltrim(@MsgSeparator))+' '+
			CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpBenefit.EnrollDate,103) ELSE LTRIM(RTRIM(DAY(EmpBenefit.EnrollDate)))+' '+
		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.EnrollDate),@Latinlang))),left(DATENAME(month,EmpBenefit.EnrollDate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.EnrollDate)))
		end
		+isnull('-'+
			 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpBenefit.enddate,103) ELSE LTRIM(RTRIM(DAY(EmpBenefit.enddate)))+' '+
		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpBenefit.enddate),@Latinlang))),left(DATENAME(month,EmpBenefit.enddate),3))+' '+LTRIM(RTRIM(YEAR(EmpBenefit.enddate)))
		end
		,'') +' '+rtrim(@ModuleMsg3)+' '+rtrim(ltrim(@MsgSeparator))+' '+
	CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(BenefitOptions.OptionAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(BenefitOptions.OptionFName )) ELSE  ltrim(rtrim(BenefitOptions.OptionName))  END 
	FROM  EmpBenefit WITH (NOLOCK) INNER JOIN
						BenefitPlans ON EmpBenefit.PlanNo = BenefitPlans.PlanNo INNER JOIN
						Profile with (nolock) ON EmpBenefit.EmpId = Profile.ProfileId INNER JOIN
						BenefitOptions ON EmpBenefit.OptionNo = BenefitOptions.OptionNo
		WHERE profileid = @Empid and EmpBenefit.documentno=@documentno
		       
		
			   SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
			   ,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
		       
			   SELECT @body = @Body +case when  @action<>0 then +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (  select @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') )
		                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid )END
                                                else '' end
END
	
				      
   -- select @body =@body+' '+ case @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid 
END

if  @SSDocType   = 2 -- Misconduct
BEGIN
  	  	 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Misconduct',@latinlang),(case when @latinlang='E' then 'Misconduct' else N'مخالفة' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','MisconductDate',@latinlang),(case when @latinlang='E' then 'Misconduct Date' else N'بتاريخ' end))
	         ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Misconduct2',@latinlang),(case when @latinlang='E' then 'Misconduct' else N'مخالفة' end))
	
    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then isnull(@tempMsgRole,'')+' for ' else '' end +rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Mscondct.MiscondAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Mscondct.MiscondFName )) ELSE  ltrim(rtrim(Mscondct.MiscondName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpMscon.MisDate,103) ELSE LTRIM(RTRIM(DAY(EmpMscon.MisDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpMscon.MisDate),@Latinlang))),left(DATENAME(month,EmpMscon.MisDate),3))+' '+LTRIM(RTRIM(YEAR(EmpMscon.MisDate)))
	   end
      FROM EmpMscon with (nolock)
	left join EmpAssignment with (nolock) on EmpAssignment.empid=EmpMscon.empid
	LEFT JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId 
	left JOIN WFDocument on EmpMscon.DocumentNo = WFDocument.DocumentNo AND EmpMscon.EmpId = WFDocument.EmpID 
	LEFT JOIN EmpMsDtl with (nolock) ON EmpMscon.EmpId = EmpMsDtl.EmpId AND EmpMscon.DocumentNo = EmpMsDtl.DocumentNo 
	LEFT JOIN Mscondct ON EmpMsDtl.MsCode = Mscondct.MsCode 
       where profileid = @Empid and EmpMscon.documentno=@documentno
       
       select @body =@body +case when  @action<>0 then +' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end 
                 else '' end from profile where profileid = @RoleProfileid 
                   
end
if  @SSDocType   = 10 -- Objectives 
BEGIN
	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Objective',@latinlang),(case when @latinlang='E' then 'Objective' else N'الهدف' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','ObjectiveDate',@latinlang),(case when @latinlang='E' then 'Assign Start Date' else N'بتاريخ' end))
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','ObjectiveWeight',@latinlang),(case when @latinlang='E' then 'Weight' else N'الثقل' end))
  	        ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Objective2',@latinlang),(case when @latinlang='E' then 'Objective' else N'الهدف' end))
  	
  	
    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @tempMsgRole+' for ' else '' end +rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+ 
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Objectives.ObjectiveAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Objectives.ObjectiveFName )) ELSE  ltrim(rtrim(Objectives.ObjectiveName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpObjectives.AssignStartDate,103) ELSE LTRIM(RTRIM(DAY(EmpObjectives.AssignStartDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpObjectives.AssignStartDate),@Latinlang))),left(DATENAME(month,EmpObjectives.AssignStartDate),3))+' '+LTRIM(RTRIM(YEAR(EmpObjectives.AssignStartDate)))
	   end
     +' ' +rtrim(@ModuleMsg3)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(str(EmpObjectives.ObjectiveWeight)))
	FROM         EmpObjectives with (nolock) INNER JOIN
                      Objectives ON EmpObjectives.ObjectiveId = Objectives.ObjectiveId INNER JOIN
                      Profile with (nolock) ON EmpObjectives.EmpId = Profile.ProfileId

       where profileid = @Empid and EmpObjectives.ObjectiveId =@documentno
   
    select @body =@body+case when  @action<>0 then+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then  ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang='A' THEN rtrim(ltrim(Aname)) ELSE rtrim(ltrim(name)) END  else '' end  from profile where profileid = @RoleProfileid 
                            
  end
 
if  @SSDocType   = 6 -- Appraisal 
BEGIN
		SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Appraisal',@latinlang),(case when @latinlang='E' then 'Appraisal' else N'التقييم' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','AppraisalDate',@latinlang),(case when @latinlang='E' then 'Appraisal Date' else N'بتاريخ' end))
  	         ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Appraisal2',@latinlang),(case when @latinlang='E' then 'Appraisal' else N'التقييم' end))
  	
  	
   SELECT @tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid  
     select @body=ltrim(RTRIM(@MsgH))+case when @action =0 then +' '+@tempMsgRole+' for ' else '' end +rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN rtrim(rtrim(Profile.AName)) ELSE rtrim(rtrim(Profile.Name)) END +
       rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
       CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Appraisals.AppraisalAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Appraisals.AppraisalFName )) ELSE  ltrim(rtrim(Appraisals.AppraisalName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpAppraisal.AppraisalDate,103) ELSE LTRIM(RTRIM(DAY(EmpAppraisal.AppraisalDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpAppraisal.AppraisalDate),@Latinlang))),left(DATENAME(month,EmpAppraisal.AppraisalDate),3))+' '+LTRIM(RTRIM(YEAR(EmpAppraisal.AppraisalDate)))
	   end
	FROM         EmpAppraisal with (nolock) INNER JOIN
                      Appraisals ON EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo INNER JOIN
                      Profile with (nolock) ON EmpAppraisal.EmpId = Profile.ProfileId

       where profileid = @Empid and EmpAppraisal.DocumentNo  =@documentno AND isnull(EmpAppraisal.AssignmentId,0)=@assignmentid

          SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       SELECT @body = @Body+ case when  @action<>0 then +' '+  
	   CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (  select @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end
    from profile with (nolock) where profileid = @RoleProfileid )END else '' end
            


end
 
if  @SSDocType   = 8 -- Vacation Due Adjustment  
BEGIN
			SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','VacDueAdjustment',@latinlang),(case when @latinlang='E' then 'Vacation Due Adjustment' else N'تعديل مستحق الأجازات' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','VacDueAdjusDate',@latinlang),(case when @latinlang='E' then 'Due Adjustment Date' else N'بتاريخ' end))
  	        ,@ModuleMsg12=isnull(dbo.Hits_GetDCCaption('WFAction','VacDueAdjustment2',@latinlang),(case when @latinlang='E' then 'Vacation Due Adjustment' else N'تعديل مستحق الأجازات' end))
  	

    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @TempMsgRole+' for ' else '' end +rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
      CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(VacationDue.VacDueAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(VacationDue.VacDueFName )) ELSE  ltrim(rtrim(VacationDue.VacDueName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpVacationDue.VacDueDate,103) ELSE LTRIM(RTRIM(DAY(EmpVacationDue.VacDueDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpVacationDue.VacDueDate),@Latinlang))),left(DATENAME(month,EmpVacationDue.VacDueDate),3))+' '+LTRIM(RTRIM(YEAR(EmpVacationDue.VacDueDate)))
	   end
	FROM         EmpVacationDue with (nolock) INNER JOIN
                      VacationDue ON EmpVacationDue.VacDueCode = VacationDue.VacDueCode INNER JOIN
                      Profile with (nolock) ON EmpVacationDue.EmpId = Profile.ProfileId

       where profileid = @Empid and EmpVacationDue.DocumentNo  =@documentno

    select @body =@body + case when  @action<>0 then +' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END + CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) END  
else '' end from profile with (nolock) where profileid = @RoleProfileid 
            
  end


if  @SSDocType   = 9 -- Training 
BEGIN
	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEvent',@latinlang),(case when @latinlang='E' then 'Training Event' else N'التدريب المجدول' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEventFrom',@latinlang),(case when @latinlang='E' then 'From Date' else N'من' end))
  			,@ModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEventTo',@latinlang),(case when @latinlang='E' then 'To Date' else N'إلى' end))
  			,@ModuleMsg4 =isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEventLocation',@latinlang),(case when @latinlang='E' then 'Location' else N'المكان' end))
  	        ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','TrainingEvent2',@latinlang),(case when @latinlang='E' then 'Training Event' else N'التدريب المجدول' end))

  		     -- for customer "merck"
  		    ,@msg9 =isnull(dbo.Hits_GetDCCaption('WFAction','Dear',@latinlang),'')
	        ,@msg10=ISNULL(dbo.Hits_GetDCCaption('WFAction','Message5',@latinlang),'')  
	        ,@msg11= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message6',@latinlang),'')
	        ,@msg14 =ISNULL(dbo.Hits_GetDCCaption('WFAction','KindRegards',@latinlang),'')
	        ,@msg15= ISNULL(dbo.Hits_GetDCCaption('WFAction','HRIS',@latinlang),'')
  			
    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 and @msg9 ='' then @TempMsgRole+' for ' else '' end +rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) END +
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
    CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(TrainingEvents.TrainingEventAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(TrainingEvents.TrainingEventFName )) ELSE  ltrim(rtrim(TrainingEvents.TrainingEventName))  END 
+' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),TrainingEvents.EventFromDate,103) ELSE 
	 	 	 	 	 	 		LTRIM(RTRIM(DAY(TrainingEvents.EventFromDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(TrainingEvents.EventFromDate),@Latinlang))),left(DATENAME(month,TrainingEvents.EventFromDate),3))+' '+LTRIM(RTRIM(YEAR(TrainingEvents.EventFromDate)))
	   end
+' '+rtrim(@ModuleMsg3)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),TrainingEvents.EventToDate,103) ELSE 
	 	 	 	 	 	 		LTRIM(RTRIM(DAY(TrainingEvents.EventToDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(TrainingEvents.EventToDate),@Latinlang))),left(DATENAME(month,TrainingEvents.EventToDate),3))+' '+LTRIM(RTRIM(YEAR(TrainingEvents.EventToDate)))
	   end
+' '+rtrim(@ModuleMsg4)+rtrim(ltrim(@MsgSeparator))+' '+
CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(TrainingEvents.EventALocation )) WHEN @Switchlang='F' THEN  ltrim(rtrim(TrainingEvents.EventFLocation )) ELSE  ltrim(rtrim(TrainingEvents.EventLocation))  END
	FROM         EmpTraining with (nolock) INNER JOIN
                      TrainingEvents ON EmpTraining.TrainingEvent = TrainingEvents.TrainingEvent INNER JOIN
                      Profile  with (nolock) ON EmpTraining.EmpId = Profile.ProfileId
       where profileid = @Empid and EmpTraining.DocumentNo  =@documentno
     	-- condition to check customer is not "merck" 
     IF  @msg9 ='' and   @action<>0  
       BEGIN
       	select @body =@body+' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname))ELSE rtrim(ltrim(name)) END  from profile with (nolock) where profileid = @RoleProfileid
       	END     
  end
if  @SSDocType   = 11 -- vacancy
BEGIN
	
				SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','JobRequisition',@latinlang),(case when @latinlang='E' then 'Job Requisition' else N'الوظيفة الشاغرة' end))
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','JobRequisitionDate',@latinlang),(case when @latinlang='E' then 'Vacancy Start Date' else N'تاريخ البداية' end))
  	        ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','JobRequisition2',@latinlang),(case when @latinlang='E' then 'Job Requisition' else N'الوظيفة الشاغرة' end))
  	
  	
    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @TempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
     CHAR(13)+CHAR(10)+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
   CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Vacancies.VacancyAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Vacancies.VacancyFName )) ELSE  ltrim(rtrim(Vacancies.VacancyName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),Vacancies.VacancyStartDate,103) ELSE 
	 	 	 	 	 	 	 		LTRIM(RTRIM(DAY(Vacancies.VacancyStartDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Vacancies.VacancyStartDate),@Latinlang))),left(DATENAME(month,Vacancies.VacancyStartDate),3))+' '+LTRIM(RTRIM(YEAR(Vacancies.VacancyStartDate)))
	   end
	FROM         Vacancies INNER JOIN
                      Profile with (nolock) ON Vacancies.EnterBy = Profile.ProfileId
       where profileid = @Empid and Vacancies.VacancyNo  =@documentno

    select @body =@body+case when  @action<>0 then +' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then ' '+rtrim(@Msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(Aname)) ELSE rtrim(ltrim(name)) END 
            else '' end   from profile with (nolock) where profileid = @RoleProfileid 
          
  end

if  @SSDocType   = 12 -- Time Permission
BEGIN

		IF @SMSorMail = 0 
		BEGIN
			SELECT @NotifiModuleMsg1= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermission','E'),'Time Permission' )                                 
  			  ,@NotifiModuleMsg2= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionat','E'),'at')                                 
  			  ,@NotifiModuleMsg3 =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionFrom','E'),'From')                                 
			  ,@NotifiModuleMsg4= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionTo','E'),'To')                                 
  			  ,@NotifiModuleMsg5 =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionHours','E'),'Permission Hours')                                 

			  ,@NotifiModuleMsg1AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermission','A'),N'اذن حضور و انصراف')                                 
  			  ,@NotifiModuleMsg2AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionat','A'),N'بتاريخ')                                 
  			  ,@NotifiModuleMsg3AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionFrom','A'),N'من')                                 
			  ,@NotifiModuleMsg4AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionTo','A'),N'إلى')                                 
  			  ,@NotifiModuleMsg5AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionHours','A'),N'فترة الأذن')                                 

			  ,@NotifiModuleMsg1FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermission','F'),'Time Permission' )                                 
  			  ,@NotifiModuleMsg2FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionat','F'),'at')                                 
  			  ,@NotifiModuleMsg3FR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionFrom','F'),'From')                                 
			  ,@NotifiModuleMsg4FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionTo','F'),'To')                                 
  			  ,@NotifiModuleMsg5FR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionHours','F'),'Permission Hours')  

				SELECT @notifiBody = rtrim(@NotifiModuleMsg1)+' '+ rtrim(@NotifiMsg2)+' '+ltrim(rtrim(Profile.Name))  +
			    ' '+rtrim(@NotifiModuleMsg1)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(timepermission.permissionname))   +
			     ' '+rtrim(@NotifiModuleMsg2)+' '+ LTRIM(RTRIM(DAY(Emptimepermission.permissionFrom)))+' '+
				  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Emptimepermission.permissionFrom),'E'))),left(DATENAME(month,Emptimepermission.permissionFrom),3))+' '+LTRIM(RTRIM(YEAR(Emptimepermission.permissionFrom)))
				+' '+rtrim(@NotifiModuleMsg3)+' '+
				ltrim(rtrim(convert(char(17),permissionfrom,108))) 
				+' '+rtrim(@NotifiModuleMsg4)+' '+
				ltrim(rtrim(convert(char(17),permissionTo,108)))
				+' '+rtrim(@NotifiModuleMsg5)+' '+
				Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)/60,2,0),' ','0')+':'+
				Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)%60,2,0),' ','0')
				
				,@notifiBodyAR = rtrim(@NotifiModuleMsg1AR)+' '+ rtrim(@NotifiMsg2AR)+' '+ltrim(rtrim(Profile.AName))+
				' '+rtrim(@NotifiModuleMsg1AR)+rtrim(ltrim(@MsgSeparator))+' '+ ltrim(rtrim(timepermission.permissionAname ))+
				 ' '+rtrim(@NotifiModuleMsg2AR)+' '+ CONVERT(char(11),Emptimepermission.permissionFrom,103)  +' '+rtrim(@NotifiModuleMsg3)+' '+
				ltrim(rtrim(convert(char(17),permissionfrom,108)))  +' '+rtrim(@NotifiModuleMsg4AR)+' '+ ltrim(rtrim(convert(char(17),permissionTo,108)))
				+' '+rtrim(@NotifiModuleMsg5AR)+' '+
				Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)/60,2,0),' ','0')+':'+
				Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)%60,2,0),' ','0')

				,@notifiBodyFR = rtrim(@NotifiModuleMsg1FR)+' '+ rtrim(@NotifiMsg2FR)+' '+ltrim(rtrim(Profile.FName))  +
				' '+rtrim(@NotifiModuleMsg1FR)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(timepermission.permissionFname))   +
				 ' '+rtrim(@NotifiModuleMsg2FR)+' '+ LTRIM(RTRIM(DAY(Emptimepermission.permissionFrom)))+' '+
				  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Emptimepermission.permissionFrom),'F'))),left(DATENAME(month,Emptimepermission.permissionFrom),3))+' '+LTRIM(RTRIM(YEAR(Emptimepermission.permissionFrom)))
				  +' '+rtrim(@NotifiModuleMsg3FR)+' '+ ltrim(rtrim(convert(char(17),permissionfrom,108))) 
				  +' '+rtrim(@NotifiModuleMsg4FR)+' '+ ltrim(rtrim(convert(char(17),permissionTo,108))) +' '+rtrim(@NotifiModuleMsg5FR)+' '+
				  REPLACE(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)/60,2,0),' ','0')+':'+
				  REPLACE(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)%60,2,0),' ','0')

				  FROM Emptimepermission WITH (NOLOCK) INNER JOIN
                    timepermission ON Emptimepermission.permissionno=timepermission.permissionno INNER JOIN
                    Profile with (nolock) ON Emptimepermission.EmpId = Profile.ProfileId
					WHERE profileid = @Empid and Emptimepermission.DocumentNo  =@documentno


					SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
					,@NotifiTempMsgRole= rtrim(ltrim(name))  
					,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
					,@NotifiTempMsgRoleAR= rtrim(ltrim(aname))
					,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
					,@NotifiTempMsgRole= rtrim(ltrim(Fname)) 
					 
					from profile with (nolock) where profileid = @RoleProfileid

					SELECT @notifiBody = @notifiBody +' '+  CASE WHEN @NotifiTempMsgAction LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRole  +' '+replace( @NotifiTempMsgAction ,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3)+' '  when 2 then  ' '+rtrim( @NotifiMsg4)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5)+' ' END + rtrim(ltrim(name))  from profile with (nolock) where profileid = @RoleProfileid )end
			  
					,@notifiBodyAR =  @notifiBodyAR  +' '+  CASE WHEN @NotifiTempMsgActionAR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleAR  +' '+replace( @NotifiTempMsgActionAR ,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3AR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5AR)+' ' END + RTRIM(ltrim(aname)) FROM profile with (nolock) where profileid = @RoleProfileid )end
			  
					, @notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleFR  +' '+replace(@NotifiTempMsgActionFR,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3FR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5FR)+' ' END + rtrim(ltrim(Fname))  from profile with (nolock) where profileid = @RoleProfileid )end
		END
        
		ELSE
        BEGIN
				    
			SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TimePermission',@latinlang),(case when @latinlang='E' then 'Time Permission' else N'اذن حضور و انصراف' end))
			,@ModuleMsg2 =isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionat',@latinlang),(case when @latinlang='E' then 'at' else N'بتاريخ' end))
  			,@ModuleMsg3= isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionFrom',@latinlang),(case when @latinlang='E' then 'From' else N'من' end))
  			,@ModuleMsg4 =isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionTo',@latinlang),(case when @latinlang='E' then 'To' else N'إلى' end))
  			,@ModuleMsg5 =isnull(dbo.Hits_GetDCCaption('WFAction','TimePermissionHours',@latinlang),(case when @latinlang='E' then 'Permission Hours' else N'فترة الأذن' end))
  			,@ModuleMsg12=isnull(dbo.Hits_GetDCCaption('WFAction','TimePermission2',@latinlang),(case when @latinlang='E' then 'Time Permission' else N'اذن حضور و انصراف' end))	
  			
  	
			    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @TempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) END +
			     rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
			   CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(timepermission.permissionAname )) WHEN @Switchlang='F' THEN  ltrim(rtrim(timepermission.permissionFname )) ELSE  ltrim(rtrim(timepermission.permissionname))  END +
			     ' '+rtrim(@ModuleMsg2)+' '+
				 	 	 	 	 	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),Emptimepermission.permissionFrom,103) ELSE 
				 	 	 	 	 	 	 	 		LTRIM(RTRIM(DAY(Emptimepermission.permissionFrom)))+' '+
				  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Emptimepermission.permissionFrom),@Latinlang))),left(DATENAME(month,Emptimepermission.permissionFrom),3))+' '+LTRIM(RTRIM(YEAR(Emptimepermission.permissionFrom)))
				   end
				+' '+rtrim(@ModuleMsg3)+' '+
				ltrim(rtrim(convert(char(17),permissionfrom,108))) 
				+' '+rtrim(@ModuleMsg4)+' '+
				ltrim(rtrim(convert(char(17),permissionTo,108)))
			+' '+rtrim(@ModuleMsg5)+' '+
			Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)/60,2,0),' ','0')+':'+
			Replace(Str(datediff(mi,Emptimepermission.permissionFrom,Emptimepermission.permissionto)%60,2,0),' ','0')
			

			FROM Emptimepermission WITH (NOLOCK) INNER JOIN
                    timepermission ON Emptimepermission.permissionno=timepermission.permissionno INNER JOIN
                    Profile with (nolock) ON Emptimepermission.EmpId = Profile.ProfileId
					WHERE profileid = @Empid and Emptimepermission.DocumentNo  =@documentno
						       
			SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
	   ,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       
	   SELECT @body = @Body +case when  @action<>0 then +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (  select @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') )
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid )END
	                                     else '' end 
		END
        
       	

END

if  @SSDocType   = 20 -- NasUsersUncomitted
BEGIN
	IF @SMSorMail = 0 
	BEGIN
		SELECT @NotifiModuleMsg1 = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted1', 'E'), 'User Registration')
				,@NotifiModuleMsg2 = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted2', 'E'), 'User Modification')
				,@NotifiModuleMsg3 = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted3', 'E'), 'User Deletion')
				,@NotifiModuleMsg4 = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommittedUserName', 'E'), 'with username')
				
				,@NotifiModuleMsg1AR = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted1', 'A'), N'تسجيل مستخدم')
				,@NotifiModuleMsg2AR =isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted2', 'A'), N'تعديل مستخدم')
				,@NotifiModuleMsg3AR =isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted3', 'A'), N'مسح مستخدم')
				,@NotifiModuleMsg4AR = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommittedUserName', 'E'), N'ب اسم المستخدم')

				,@NotifiModuleMsg1FR = isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted1', 'F'), 'User Registration')
				,@NotifiModuleMsg2FR =  isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted2', 'F'), 'User Modification')
				,@NotifiModuleMsg3FR =  isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommitted3', 'F'), 'User Deletion')
				,@NotifiModuleMsg4FR =  isnull(dbo.Hits_GetDCCaption('WFAction', 'NasUsersUncommittedUserName', 'F'), 'with username')

		SELECT @notifiBody = ltrim(rtrim(CASE WHEN NasUsersUncommitted.RequestedAction = 1 THEN @NotifiModuleMsg1 WHEN NasUsersUncommitted.RequestedAction = 2 THEN @NotifiModuleMsg2 ELSE @NotifiModuleMsg3 END)) +
		' ' + rtrim(@NotifiMsg2) + ' ' + LTRIM(rtrim(PROFILE.Name)) + 
		' ' + ltrim(rtrim(@NotifiModuleMsg4)) + rtrim(ltrim(@MsgSeparator)) + ' ' + LTRIM(RTRIM(NasUsersUncommitted.LogonName))

		,@notifiBodyAR = ltrim(rtrim(CASE WHEN NasUsersUncommitted.RequestedAction = 1 THEN @NotifiModuleMsg1AR WHEN NasUsersUncommitted.RequestedAction = 2 THEN @NotifiModuleMsg2AR ELSE @NotifiModuleMsg3AR END)) + 
		' ' + rtrim(@NotifiMsg2AR) + ' ' + ltrim(rtrim(PROFILE.aName)) +
		' ' + ltrim(rtrim(@NotifiModuleMsg4AR)) + rtrim(ltrim(@MsgSeparator)) + ' ' + LTRIM(RTRIM(NasUsersUncommitted.LogonName))

		,@notifiBodyFR = ltrim(rtrim(CASE WHEN NasUsersUncommitted.RequestedAction = 1 THEN @NotifiModuleMsg1FR WHEN NasUsersUncommitted.RequestedAction = 2 THEN @NotifiModuleMsg2FR ELSE @NotifiModuleMsg3FR END)) +
		' ' + rtrim(@NotifiMsg2FR) + ' ' + LTRIM(rtrim(PROFILE.FName)) + 
		' ' + ltrim(rtrim(@NotifiModuleMsg4FR)) + rtrim(ltrim(@MsgSeparator)) + ' ' + LTRIM(RTRIM(NasUsersUncommitted.LogonName))							
		FROM NasUsersUncommitted  with (nolock)
		INNER JOIN Profile with (nolock) ON NasUsersUncommitted.EmpId = Profile.ProfileId
		where Profile.profileid = @Empid and NasUsersUncommitted.documentno=@documentno


		SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
			,@NotifiTempMsgRole=  rtrim(ltrim(name))  
	   
			,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
			,@NotifiTempMsgRoleAR= rtrim(ltrim(aname))
		
			,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
		   ,@NotifiTempMsgRoleFR=  rtrim(ltrim(Fname))			
		FROM profile where profileid = @RoleProfileid


		SELECT @notifiBody =  @notifiBody  +' '+  CASE WHEN  @NotifiTempMsgAction  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRole  +' '+replace( @NotifiTempMsgAction ,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3)+' '  when 2 then  ' '+rtrim( @NotifiMsg4)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5)+' ' END +rtrim(ltrim(name))  from profile where profileid = @RoleProfileid )end
		
			, @notifiBodyAR =  @notifiBodyAR +' '+  CASE WHEN  @NotifiTempMsgActionAR  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleAR  +' '+replace( @NotifiTempMsgActionAR ,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3AR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5AR)+' ' END +rtrim(ltrim(aname))  from profile where profileid = @RoleProfileid )end
			, @notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleFR  +' '+replace(@NotifiTempMsgActionFR,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3FR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5FR)+' ' END +rtrim(ltrim(Fname))  from profile where profileid = @RoleProfileid )end
	END
	ELSE
    BEGIN
		SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommitted1',@latinlang),(case when @latinlang='E' then 'User Registration' else N'تسجيل مستخدم' end))
		SELECT @ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommitted2',@latinlang),(case when @latinlang='E' then 'User Modification' else N'تعديل مستخدم' end))
		SELECT @ModuleMsg3= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommitted3',@latinlang),(case when @latinlang='E' then 'User Deletion' else N'مسح مستخدم' end))
		SELECT @ModuleMsg4= LTRIM(RTRIM(isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedURL',@latinlang),(case when @latinlang='E' then 'You can log onto your account using the following URL' else N'يمكنك الدخول إلى حسابك باستخدام الرابط التالي' end))))
		+@MsgSeparator+ CHAR(13)+CHAR(10)+@sswebsite
		--,@ModuleMsg5=  LTRIM(RTRIM(isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedPass',@latinlang),(case when @latinlang='E' then 'Your generated Password is' else N'كلمة المرور التي تم إنشاؤها الخاص بك هي' end))))
		--+@MsgSeparator+ CHAR(13)+CHAR(10)+LTRIM(RTRIM(NasUsersUncommitted.UserInfo))
		,@ModuleMsg5= CASE WHEN LTRIM(RTRIM(nasusers.PassWord))='' or LTRIM(RTRIM(NasUsersUncommitted.UserInfo))='' OR nasusers.WindowsOnly=1  THEN '' ELSE   LTRIM(RTRIM(isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedPass',@latinlang),(case when @latinlang='E' then 'Your generated Password is' else N'كلمة المرور التي تم إنشاؤها الخاص بك هي' end))))
		+@MsgSeparator+ CHAR(13)+CHAR(10)+LTRIM(RTRIM(NasUsersUncommitted.UserInfo)) END 
		FROM NasUsersUncommitted with (nolock) 
		LEFT JOIN nasusers ON nasusers.LogonName = NasUsersUncommitted.LogonName
		where NasUsersUncommitted.EmpId = @Empid and NasUsersUncommitted.documentno=@documentno AND NasUsersUncommitted.DocumentStatus=1 AND NasUsersUncommitted.RequestedAction=1
		SELECT @ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','NasUsersUncommittedUserName',@latinlang),(case when @latinlang='E' then 'with username' else N'ب اسم المستخدم' end))

	
		--Registration request for employee x x x
		--Dear Folan,
		--User Registration request for x x x with username xxx@hitssolutions.com
		--User Modification request for x x x  with username xxx@hitssolutions.com
		--User Deletion request for x x x  with username xxx@hitssolutions.com
		--Folan Waiting for your approval
		--has been approved/rejected by Folan
		--You can log onto your account using the following URL
		--Your generated Password is
		select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @TempMsgRole+' for ' else '' end
		+ltrim(rtrim(CASE WHEN NasUsersUncommitted.RequestedAction = 1 THEN @ModuleMsg1 WHEN NasUsersUncommitted.RequestedAction = 2 THEN @ModuleMsg2 ELSE @ModuleMsg3 END))+' '
		+ ltrim(rtrim(@Msg2))+' '+ CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END
		+' '+ltrim(rtrim(@ModuleMsg12))+rtrim(ltrim(@MsgSeparator))+' '+LTRIM(RTRIM(NasUsersUncommitted.LogonName))
		FROM NasUsersUncommitted  with (nolock)
		INNER JOIN Profile with (nolock) ON NasUsersUncommitted.EmpId = Profile.ProfileId
		where Profile.profileid = @Empid and NasUsersUncommitted.documentno=@documentno



		select @body=@body+case when  @action<>0 then+ ' '+case @action when 1 then ' '+rtrim(@Msg3)+' ' when 2 then ' '+rtrim(@Msg4)+' ' when 3 then  ' '+rtrim(@Msg5)+' 'END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end   else '' end  from profile with (nolock) where profileid = @RoleProfileid 
    END         
END 


 if @SSDocType=23 --EmpReadingsUncommited
  BEGIN
  	IF @SMSorMail = 0 
	BEGIN
		SELECT @NotifiModuleMsg1 = isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TimeKeeping', 'E'), 'Incomplete Time Keeping')
				,@NotifiModuleMsg2 = isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TkTimeIn', 'E'), 'Time In')
				,@NotifiModuleMsg3 = isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TkTimeOut', 'E'), 'Time Out')
				
				,@NotifiModuleMsg1AR = isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TimeKeeping', 'A'), N'قراءة السجلات')
				,@NotifiModuleMsg2AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TkTimeIn', 'A'), N'تسجيل الدخول')
				,@NotifiModuleMsg3AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TkTimeOut', 'A'), N'تسجيل خروج')

				,@NotifiModuleMsg1FR = isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TimeKeeping', 'F'), 'Incomplete Time Keeping')
				,@NotifiModuleMsg2FR =  isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TkTimeIn', 'F'), 'se connecter')
				,@NotifiModuleMsg3FR =  isnull(dbo.Hits_GetDCCaption('NotificationWFAction', 'TkTimeOut', 'F'), 'Déconnexion')

		SELECT @notifiBody = rtrim(@NotifiModuleMsg1) + ' ' + rtrim(@NotifiMsg2) + 
								' ' + LTRIM(rtrim(PROFILE.Name)) + ' ' + rtrim(@NotifiModuleMsg1) + rtrim(ltrim(@MsgSeparator)) + ' ' + 
								CASE 
								WHEN TimeSystemLines.TimeLineType = 1
									THEN RTRIM(@NotifiModuleMsg2)
								ELSE RTRIM(@NotifiModuleMsg3)
								END + ' ' + rtrim(ltrim(@SeparatorEnter2)) + rtrim(ltrim(@MsgSeparator)) +
								' ' + CONVERT(NVARCHAR, EmpTimeReadingsUncommitted.AttendTime) 

				,@notifiBodyAR = rtrim(@NotifiModuleMsg1AR) + ' ' + rtrim(@NotifiMsg2AR) +
					' ' + ltrim(rtrim(PROFILE.aName)) + ' ' + rtrim(@NotifiModuleMsg1AR) + rtrim(ltrim(@MsgSeparator)) + ' ' + 
					CASE 
					WHEN TimeSystemLines.TimeLineType = 1
						THEN RTRIM(@NotifiModuleMsg2AR)
					ELSE RTRIM(@NotifiModuleMsg3AR)
					END + ' ' + rtrim(ltrim(@SeparatorEnter2)) + rtrim(ltrim(@MsgSeparator)) +
					' ' + CONVERT(NVARCHAR, EmpTimeReadingsUncommitted.AttendTime) 

				,@notifiBodyFR = rtrim(@NotifiModuleMsg1FR) + ' ' + rtrim(@NotifiMsg2FR) + ' ' + LTRIM(rtrim(PROFILE.FName)) + 
					CASE 
					WHEN TimeSystemLines.TimeLineType = 1
						THEN RTRIM(@NotifiModuleMsg2FR)
					ELSE RTRIM(@NotifiModuleMsg3FR)
					END + ' ' + rtrim(ltrim(@SeparatorEnter2)) + rtrim(ltrim(@MsgSeparator)) +
					' ' + CONVERT(NVARCHAR, EmpTimeReadingsUncommitted.AttendTime)

		FROM profile with (nolock) 
		INNER join EmpTimeReadingsUncommitted with (nolock) on profile.profileid=EmpTimeReadingsUncommitted.empid 
		INNER JOIN TimeSystems ON TimeSystems.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
		INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = TimeSystems.TimeSystem AND 
		TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsUncommitted.ReaderValue ELSE EmpTimeReadingsUncommitted.FlagValue END   
		   where profileid = @Empid and EmpTimeReadingsUncommitted.documentno=@documentno

		SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
			,@NotifiTempMsgRole=  rtrim(ltrim(name))  
	   
			,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
			,@NotifiTempMsgRoleAR= rtrim(ltrim(aname))
		
			,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
			,@NotifiTempMsgRoleFR=  rtrim(ltrim(Fname))			
		FROM profile where profileid = @RoleProfileid

		SELECT @notifiBody =  @notifiBody  +' '+  CASE WHEN  @NotifiTempMsgAction  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRole  +' '+replace( @NotifiTempMsgAction ,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3)+' '  when 2 then  ' '+rtrim( @NotifiMsg4)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5)+' ' END +rtrim(ltrim(name))  from profile where profileid = @RoleProfileid )end
			, @notifiBodyAR =  @notifiBodyAR +' '+  CASE WHEN  @NotifiTempMsgActionAR  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleAR  +' '+replace( @NotifiTempMsgActionAR ,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3AR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5AR)+' ' END +rtrim(ltrim(aname))  from profile where profileid = @RoleProfileid )end
			, @notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleFR  +' '+replace(@NotifiTempMsgActionFR,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3FR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5FR)+' ' END +rtrim(ltrim(Fname))  from profile where profileid = @RoleProfileid )end
	END
	ELSE
    BEGIN
		 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TimeKeeping',@latinlang),(case when @latinlang='E' then 'Time Keeping' else N'قراءة السجلات' end)) 
			SELECT @ModuleMsg2 = 	isnull(dbo.Hits_GetDCCaption('WFAction','TkTimeIn',@latinlang),(case when @latinlang='E' then 'Time In' else N'تسجيل الدخول' end)) 	
			SELECT @ModuleMsg3 = 	isnull(dbo.Hits_GetDCCaption('WFAction','TkTimeOut',@latinlang),(case when @latinlang='E' then 'Time Out' else N'تسجيل خروج' end)) 	
	
	select @body=ltrim(RTRIM(@MsgH)) +' '+case when @action=0 and  @msg9 ='' then @TempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' ' + rtrim(@Msg2)+' '+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +' ' 
	+RTRIM(ltrim(@SeparatorEnter))+' ' + 
	CASE WHEN TimeSystemLines.TimeLineType=1 THEN  RTRIM(@ModuleMsg2) ELSE RTRIM(@ModuleMsg3) END+ ' ' + 
	rtrim(ltrim(@SeparatorEnter2)) + rtrim(ltrim(@MsgSeparator))+' ' + CONVERT(NVARCHAR, EmpTimeReadingsUncommitted.AttendTime)
	 
	FROM profile  with (nolock)
	INNER join EmpTimeReadingsUncommitted with (nolock) on profile.profileid=EmpTimeReadingsUncommitted.empid 
	INNER JOIN TimeSystems ON TimeSystems.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
	INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = TimeSystems.TimeSystem AND 
	TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsUncommitted.ReaderValue ELSE EmpTimeReadingsUncommitted.FlagValue END   
       where profileid = @Empid and EmpTimeReadingsUncommitted.documentno=@documentno
       
       	-- condition to check customer is not "merck" 
       IF  @msg9 ='' and   @action<>0  
       BEGIN
      
       SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
	   ,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       
	   SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN @tempMsgRole +replace(@TempMsgAction,'@RoleName','') ELSE  @TempMsgAction + @tempMsgRole END

       END
	END

end

 if @SSDocType=24 --EMpHrRequest
  BEGIN
  IF @SMSorMail = 0

	BEGIN

		SELECT
	-- English

			@NotifiModuleMsg1  = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRRequest', 'E'),

			'HR'),

			@NotifiModuleMsg2  = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRReqDate', 'E'),

			'with Date'),

			@NotifiModuleMsg3 = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRRequest2', 'E'),

			'Request'),

			@NotifiModuleMsg4=  ISNULL(dbo.Hits_GetDCCaption('NotificationWFAction','Request','E'),

			'request for employee'),

			-- Arabic

			@NotifiModuleMsg1AR  = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRRequest', 'A'),

			N'طلب عام من الموارد البشرية'),

			@NotifiModuleMsg2AR  = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRReqDate', 'A'),

			N'بتاريخ'),

			@NotifiModuleMsg3AR = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRRequest2', 'A'),

			N'طلب'),

			@NotifiModuleMsg4AR=  ISNULL(dbo.Hits_GetDCCaption('NotificationWFAction','Request','A'),

			'للموظف'),

			-- French

			@NotifiModuleMsg1FR  = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRRequest', 'F'),

			'HR'),

			@NotifiModuleMsg2FR  = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRReqDate', 'F'),

			'with Date'),

			@NotifiModuleMsg3FR = ISNULL(dbo.Hits_GetDCCaption('WFAction','HRRequest2', 'F'),

			'Request'),

			@NotifiModuleMsg4FR=ISNULL(dbo.Hits_GetDCCaption('NotificationWFAction','Request','F'),

			'request for employee');

		SELECT @notifiBody = LTRIM(RTRIM(@NotifiModuleMsg1))         -- "HR"

		+ ' ' + LTRIM(RTRIM(@NotifiModuleMsg4)) --"Request for employee "

		+ ' ' + LTRIM(RTRIM(Profile.Name))      -- Employee name

		+ RTRIM(LTRIM(@MsgSeparator))

		+ ' ' + LTRIM(RTRIM(HRRequest.HRReqName))

		+ ' ' + LTRIM(RTRIM(@NotifiModuleMsg2)) -- "with Date"

		+ ' ' +

		LTRIM(RTRIM(DAY(EmpHRRequest.HRReqDate))) + ' ' +

		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',

		MONTH(EmpHRRequest.HRReqDate), 'E'))),

		LEFT(DATENAME(month, EmpHRRequest.HRReqDate),3))

		+ ' ' + LTRIM(RTRIM(YEAR(EmpHRRequest.HRReqDate)))

		,@notifiBodyAR = LTRIM(RTRIM(@NotifiModuleMsg1AR))         -- "HR" in Arabic
		 + ' ' + LTRIM(RTRIM(@NotifiModuleMsg4AR))                 -- "Request for employee" in Arabic
		+ ' ' + LTRIM(RTRIM(Profile.AName))                     -- Employee name in Arabic

		+ RTRIM(LTRIM(@MsgSeparator))

		+ ' ' + LTRIM(RTRIM(HRRequest.HRReqAName)) -- Request details in Arabic

		+ ' ' + LTRIM(RTRIM(@NotifiModuleMsg2AR))  -- "with Date" in Arabic

		+ ' ' +

		CONVERT(VARCHAR(11), EmpHRRequest.HRReqDate, 103) -- Date in dd/mm/yyyy format

		,@notifiBodyFR = LTRIM(RTRIM(@NotifiModuleMsg1FR))         -- "HR" in French

		+ ' ' + LTRIM(RTRIM(@NotifiModuleMsg4FR)) -- "Request for employee" in French

		+ ' ' + LTRIM(RTRIM(Profile.FName))        -- Employee name in French

		+ RTRIM(LTRIM(@MsgSeparator))

		+ ' ' + LTRIM(RTRIM(HRRequest.HRReqFName)) -- Request details in French

		+ ' ' + LTRIM(RTRIM(@NotifiModuleMsg2FR))  -- "with Date" in French

		+ ' ' +

		LTRIM(RTRIM(DAY(EmpHRRequest.HRReqDate))) + ' ' +

		ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar', MONTH(EmpHRRequest.HRReqDate), 'F'))),

		LEFT(DATENAME(month, EmpHRRequest.HRReqDate), 3)) + ' ' +

		LTRIM(RTRIM(YEAR(EmpHRRequest.HRReqDate))) -- Date in dd MMM yyyy format

		FROM EmpHRRequest    with (nolock)

		left join EmpAssignment with (nolock) on EmpAssignment.empid=EmpHRRequest.empid

		LEFT JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId

		LEFT JOIN HRRequest ON HRRequest.HRReqCode = EmpHRRequest.HRReqCode

		where profileid = @Empid and EmpHRRequest.documentno=@documentno

		SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END

		,@NotifiTempMsgRole=  rtrim(ltrim(name))

		,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END

		,@NotifiTempMsgRoleAR= rtrim(ltrim(aname))

		,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END

		,@NotifiTempMsgRoleFR=  rtrim(ltrim(Fname))

		FROM profile where profileid = @RoleProfileid

		SELECT  @notifiBody =  @notifiBody  +' '+  CASE WHEN  @NotifiTempMsgAction  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRole  +' '+replace( @NotifiTempMsgAction ,'@RoleName','') )

		ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3)+' '  when 2 then  ' '+rtrim( @NotifiMsg4)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5)+' ' END +rtrim(ltrim(name))  from profile where profileid = @RoleProfileid )end

		, @notifiBodyAR =  @notifiBodyAR +' '+  CASE WHEN  @NotifiTempMsgActionAR  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleAR  +' '+replace( @NotifiTempMsgActionAR ,'@RoleName','') )

		ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3AR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5AR)+' ' END +rtrim(ltrim(aname))  from profile where profileid = @RoleProfileid )end

		, @notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleFR  +' '+replace(@NotifiTempMsgActionFR,'@RoleName','') )

		ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3FR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5FR)+' ' END +rtrim(ltrim(Fname))  from profile where profileid = @RoleProfileid )end

		END

ELSE

BEGIN
  	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','HRRequest',@latinlang),(case when @latinlang='E' then 'HR' else N'طلب عام من الموارد البشرية' end))
 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','HRReqDate',@latinlang),(case when @latinlang='E' then 'with Date' else N'بتاريخ' end))
  			
  			 ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','HRRequest2',@latinlang),(case when @latinlang='E' then 'Request' else N'طلب' end))
  			
    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @TempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
    	rtrim(ltrim(@SeparatorEnter))+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(HRRequest.HRReqAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(HRRequest.HRReqfName )) ELSE  ltrim(rtrim(HRRequest.HRReqName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpHRRequest.HRReqDate,103) ELSE LTRIM(RTRIM(DAY(EmpHRRequest.HRReqDate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(EmpHRRequest.HRReqDate),@Latinlang))),left(DATENAME(month,EmpHRRequest.HRReqDate),3))+' '+LTRIM(RTRIM(YEAR(EmpHRRequest.HRReqDate)))
	   end
      FROM EmpHRRequest with (nolock)
	left join EmpAssignment on EmpAssignment.empid=EmpHRRequest.empid
	LEFT JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId 
	LEFT JOIN HRRequest ON EmpHRRequest.HRReqCode = HRRequest.HRReqCode 
       where profileid = @Empid and EmpHRRequest.documentno=@documentno
       
  SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       
       SELECT @body = @Body+ case when  @action<>0 then +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN  @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') 
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END 
                                        +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid )

                                   END else '' end 
  END 
  END

   if @SSDocType=26 --EmpTimeReadingsGeoUncommitted
  BEGIN
  	IF @SMSorMail = 0 
	BEGIN
		SELECT @NotifiModuleMsg1= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimeReadingsGeolocation','E'),'Time Reading Geolocation' )                                 
  			  ,@NotifiModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','From','E'),'From')                                 
  			  ,@NotifiModuleMsg3 =isnull(dbo.Hits_GetDCCaption('WFAction','at','E'),'at')                                 
			  --,@NotifiModuleMsg4= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionTo','E'),'To')                                 
  			--  ,@NotifiModuleMsg5 =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionHours','E'),'Permission Hours')                                 

			  ,@NotifiModuleMsg1AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimeReadingsGeolocation','A'),N'الموقع الجغرافي للحضور والإنصراف' )                               
  			  ,@NotifiModuleMsg2AR= isnull(dbo.Hits_GetDCCaption('WFAction','From','A'),N'من')                                  
  			  ,@NotifiModuleMsg3AR =isnull(dbo.Hits_GetDCCaption('WFAction','at','A'),N'في')                                 
			  --,@NotifiModuleMsg4AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionTo','A'),N'إلى')                                 
  			--  ,@NotifiModuleMsg5AR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionHours','A'),N'فترة الأذن')                                 

			  ,@NotifiModuleMsg1FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimeReadingsGeolocation','F'),'Time Reading Geolocation' )                           
  			  ,@NotifiModuleMsg2FR= isnull(dbo.Hits_GetDCCaption('WFAction','From','F'),'From')                                
  			  ,@NotifiModuleMsg3FR =isnull(dbo.Hits_GetDCCaption('WFAction','at','F'),'at')                                 
			  --,@NotifiModuleMsg4FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionTo','F'),'To')                                 
  			--  ,@NotifiModuleMsg5FR =isnull(dbo.Hits_GetDCCaption('NotificationWFAction','TimePermissionHours','F'),'Permission Hours') 

		SELECT @notifiBody = rtrim(@NotifiModuleMsg1)+' '+ rtrim(@NotifiMsg2)+' '+ltrim(rtrim(Profile.Name))  +
		' '+rtrim(@NotifiModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(GeoLocations.GeoLocationAname )) 
																	 WHEN @Switchlang='F' THEN  ltrim(rtrim(GeoLocations.GeoLocationFname )) ELSE  ltrim(rtrim(GeoLocations.GeoLocationname))  END  +
		  +' '+rtrim(@NotifiModuleMsg3)+' '+  LTRIM(RTRIM(DAY(AttendTime)))+' '+	 ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(AttendTime),'e'))),left(DATENAME(month,AttendTime),3))+' '+LTRIM(RTRIM(YEAR(AttendTime))) +' '+ltrim(rtrim(convert(char(17),AttendTime,108))) 

		,@notifiBodyAR = rtrim(@NotifiModuleMsg1AR)+' '+ rtrim(@NotifiMsg2AR)+' '+ltrim(rtrim(Profile.AName))  +
		' '+rtrim(@NotifiModuleMsg2AR)+rtrim(ltrim(@MsgSeparator))+' '+CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(GeoLocations.GeoLocationAname )) 
																	 WHEN @Switchlang='F' THEN  ltrim(rtrim(GeoLocations.GeoLocationFname )) ELSE  ltrim(rtrim(GeoLocations.GeoLocationname))  END  +
		  +' '+rtrim(@NotifiModuleMsg3AR)+' '+  LTRIM(RTRIM(DAY(AttendTime)))+' '+	 ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(AttendTime),'a'))),left(DATENAME(month,AttendTime),3))+' '+LTRIM(RTRIM(YEAR(AttendTime))) +' '+ltrim(rtrim(convert(char(17),AttendTime,108))) 

		,@notifiBodyFR  = rtrim(@NotifiModuleMsg1FR)+' '+ rtrim(@NotifiMsg2FR)+' '+ltrim(rtrim(Profile.FName))  +
		' '+rtrim(@NotifiModuleMsg2FR)+rtrim(ltrim(@MsgSeparator))+' '+CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(GeoLocations.GeoLocationAname )) 
																	 WHEN @Switchlang='F' THEN  ltrim(rtrim(GeoLocations.GeoLocationFname )) ELSE  ltrim(rtrim(GeoLocations.GeoLocationname))  END  +
		  +' '+rtrim(@NotifiModuleMsg3FR)+' '+  LTRIM(RTRIM(DAY(AttendTime)))+' '+	 ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(AttendTime),'f'))),left(DATENAME(month,AttendTime),3))+' '+LTRIM(RTRIM(YEAR(AttendTime))) +' '+ltrim(rtrim(convert(char(17),AttendTime,108))) 
	
		FROM EmpTimeReadingsGeoUncommitted WITH (NOLOCK) 
		INNER JOIN GeoLocations ON EmpTimeReadingsGeoUncommitted.GeoLocation=GeoLocations.GeoLocation 
		INNER JOIN Profile with (nolock) ON EmpTimeReadingsGeoUncommitted.EmpId = Profile.ProfileId
		 where profileid = @Empid and EmpTimeReadingsGeoUncommitted.DocumentNo  =@documentno

		SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
			,@NotifiTempMsgRole=  rtrim(ltrim(name))  
	   
			,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
			,@NotifiTempMsgRoleAR= rtrim(ltrim(aname))
		
			,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
			,@NotifiTempMsgRoleFR=  rtrim(ltrim(Fname))			
		FROM profile where profileid = @RoleProfileid
		
		SELECT @notifiBody =  @notifiBody  +' '+  CASE WHEN  @NotifiTempMsgAction  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRole  +' '+replace( @NotifiTempMsgAction ,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3)+' '  when 2 then  ' '+rtrim( @NotifiMsg4)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5)+' ' END +rtrim(ltrim(name))  from profile where profileid = @RoleProfileid )end
			, @notifiBodyAR =  @notifiBodyAR +' '+  CASE WHEN  @NotifiTempMsgActionAR  LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleAR  +' '+replace( @NotifiTempMsgActionAR ,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3AR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5AR)+' ' END +rtrim(ltrim(aname))  from profile where profileid = @RoleProfileid )end
			, @notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (  select @NotifiTempMsgRoleFR  +' '+replace(@NotifiTempMsgActionFR,'@RoleName','') )
											ELSE ( SELECT   case @action when 1 then ' '+rtrim( @NotifiMsg3FR)+' '  when 2 then  ' '+rtrim( @NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim( @NotifiMsg5FR)+' ' END +rtrim(ltrim(Fname))  from profile where profileid = @RoleProfileid )end
	END
	ELSE
    BEGIN
		 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','TimeReadingsGeolocation',@latinlang),(case when @latinlang='E' then 'Time Readings Geolocation' else N'الموقع الجغرافي للحضور والإنصراف' end)) 
	     SELECT @ModuleMsg2 = 	isnull(dbo.Hits_GetDCCaption('WFAction','TkTimeIn',@latinlang),(case when @latinlang='E' then 'Time In' else N'تسجيل الدخول' end)) 	
			SELECT @ModuleMsg3 = 	isnull(dbo.Hits_GetDCCaption('WFAction','TkTimeOut',@latinlang),(case when @latinlang='E' then 'Time Out' else N'تسجيل خروج' end)) 	
	
	select @body=ltrim(RTRIM(@MsgH)) +' '+case when @action=0 and  @msg9 ='' then @TempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' ' + rtrim(@Msg2)+' '+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +' ' 
	+RTRIM(ltrim(@SeparatorEnter))+' ' + 
	CASE WHEN TimeSystemLines.TimeLineType=1 THEN  RTRIM(@ModuleMsg2) ELSE RTRIM(@ModuleMsg3) END+ ' ' + 
	rtrim(ltrim(@SeparatorEnter2)) + rtrim(ltrim(@MsgSeparator))+' ' + CONVERT(NVARCHAR, EmpTimeReadingsGeoUncommitted.AttendTime)
	 
	FROM profile  with (nolock)
	INNER join EmpTimeReadingsGeoUncommitted with (nolock) on profile.profileid=EmpTimeReadingsGeoUncommitted.empid 
	INNER JOIN TimeSystems ON TimeSystems.TimeSystem = EmpTimeReadingsGeoUncommitted.TimeSystem
	INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = TimeSystems.TimeSystem AND 
	TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsGeoUncommitted.ReaderValue ELSE EmpTimeReadingsGeoUncommitted.FlagValue END   
       where profileid = @Empid and EmpTimeReadingsGeoUncommitted.documentno=@documentno
       
       	-- condition to check customer is not "merck" 
       IF  @msg9 ='' and   @action<>0  
       BEGIN
      
       SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
	   ,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       
	   SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN @tempMsgRole +replace(@TempMsgAction,'@RoleName','') ELSE  @TempMsgAction + @tempMsgRole END

       END
	END

end


   if @SSDocType=25 --EmpTask
  BEGIN
  	SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Tasks',@latinlang),(case when @latinlang='E' then 'Tasks' else N'المهام' end))
 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','TaskDate',@latinlang),(case when @latinlang='E' then 'with Date' else N'بتاريخ' end))
  			
  			 ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Tasks2',@latinlang),(case when @latinlang='E' then 'Request' else N'طلب' end))
  			
    select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then @TempMsgRole+' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) end+
    	rtrim(ltrim(@SeparatorEnter))+rtrim(@ModuleMsg12)+rtrim(ltrim(@MsgSeparator))+' '+
     CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(EmpTask.TaskAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(EmpTask.TaskFName )) ELSE  ltrim(rtrim(EmpTask.TaskName))  END +
     ' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
	 	 	 	CASE WHEN @Latinlang='A' THEN CONVERT(char(11),EmpTask.startdate,103)+' '+CONVERT(VARCHAR(5),emptask.StartDate, 8)  ELSE LTRIM(RTRIM(DAY(Emptask.startdate)))+' '+
	  ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(Emptask.startdate),@Latinlang))),left(DATENAME(month,Emptask.startdate),3))+' '+LTRIM(RTRIM(YEAR(Emptask.startdate)))+' '+CONVERT(VARCHAR(5),emptask.StartDate, 8) 
	   end
      FROM Emptask with (nolock)
	left join EmpAssignment with (nolock) on EmpAssignment.empid=Emptask.empid
	LEFT JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId 
    where profileid = @Empid and Emptask.documentno=@documentno
              
  SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid
       
       SELECT @body = @Body +case when  @action<>0 then +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN  @tempMsgRole  +' '+replace(@TempMsgAction,'@RoleName','') 
                                        ELSE ( SELECT   case @action when 1 then ' '+rtrim( @msg3)+' '  when 2 then  ' '+rtrim( @msg4)+' '  when 3 THEN ' '+rtrim( @msg5)+' ' END 
                                        +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid )

                                   END else '' end 
  END 


   if @SSDocType = 14 -- Document 
BEGIN
	IF @SMSorMail = 0 
	BEGIN
		SELECT @NotifiModuleMsg1= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Document','E'),'Document')
			  ,@NotifiModuleMsg2= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','DocumentDate','E'),'Document Date')

			  ,@NotifiModuleMsg1AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Document','A'),N'مستند')
			  ,@NotifiModuleMsg2AR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','DocumentDate','A'),N'بتاريخ')

			  ,@NotifiModuleMsg1FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','Document','F'),'Document')
			  ,@NotifiModuleMsg2FR= isnull(dbo.Hits_GetDCCaption('NotificationWFAction','DocumentDate','F'),'Document Date')

		SELECT @notifiBody = rtrim(@NotifiModuleMsg1)+' '+ rtrim(@NotifiMsg2)+' '+ltrim(rtrim(Profile.Name)) +
			' '+rtrim(@NotifiModuleMsg1)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(document.docname)) +
			' '+rtrim(@NotifiModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
			LTRIM(RTRIM(DAY(empdoc.docdate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empdoc.docdate),'E'))),left(DATENAME(month,empdoc.docdate),3))+' '+LTRIM(RTRIM(YEAR(empdoc.docdate)))

			,@notifiBodyAR = rtrim(@NotifiModuleMsg1AR)+' '+ rtrim(@NotifiMsg2AR)+' '+ltrim(rtrim(Profile.AName)) +
			' '+rtrim(@NotifiModuleMsg1AR)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(document.docAname)) +
			' '+rtrim(@NotifiModuleMsg2AR)+rtrim(ltrim(@MsgSeparator))+' '+
			CONVERT(char(11), empdoc.docdate,103)

			,@notifiBodyFR = rtrim(@NotifiModuleMsg1FR)+' '+ rtrim(@NotifiMsg2FR)+' '+ltrim(rtrim(Profile.FName)) +
			' '+rtrim(@NotifiModuleMsg1FR)+rtrim(ltrim(@MsgSeparator))+' '+ltrim(rtrim(document.docfName)) +
			' '+rtrim(@NotifiModuleMsg2FR)+rtrim(ltrim(@MsgSeparator))+' '+
			LTRIM(RTRIM(DAY(empdoc.docdate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empdoc.docdate),'F'))),left(DATENAME(month,empdoc.docdate),3))+' '+LTRIM(RTRIM(YEAR(empdoc.docdate)))

		FROM empdoc with (nolock)
		INNER JOIN document ON document.docId = empdoc.docid
		INNER JOIN Profile with (nolock) ON empdoc.EmpId = Profile.ProfileId
		WHERE profileid = @Empid and empdoc.documentno=@documentno

		SELECT @NotifiTempMsgAction = CASE @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then  ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END
			,@NotifiTempMsgRole = rtrim(ltrim(name))
			,@NotifiTempMsgActionAR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END
			,@NotifiTempMsgRoleAR = rtrim(ltrim(aname))
			,@NotifiTempMsgActionFR = CASE @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then  ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END
			,@NotifiTempMsgRoleFR = rtrim(ltrim(Fname))
		FROM profile with (nolock) where profileid = @RoleProfileid

		SELECT @notifiBody = @notifiBody +' '+  CASE WHEN @NotifiTempMsgAction LIKE '%@RoleName%' THEN (select @NotifiTempMsgRole +' '+replace(@NotifiTempMsgAction,'@RoleName',''))
											ELSE (SELECT case @action when 1 then ' '+rtrim(@NotifiMsg3)+' '  when 2 then ' '+rtrim(@NotifiMsg4)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5)+' ' END +rtrim(ltrim(name)) from profile with (nolock) where profileid = @RoleProfileid) end
		,@notifiBodyAR = @notifiBodyAR +' '+  CASE WHEN @NotifiTempMsgActionAR LIKE '%@RoleName%' THEN (select @NotifiTempMsgRoleAR +' '+replace(@NotifiTempMsgActionAR,'@RoleName',''))
											ELSE (SELECT case @action when 1 then ' '+rtrim(@NotifiMsg3AR)+' '  when 2 then ' '+rtrim(@NotifiMsg4AR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5AR)+' ' END +rtrim(ltrim(aname)) from profile with (nolock) where profileid = @RoleProfileid) end
		,@notifiBodyFR = @notifiBodyFR +' '+  CASE WHEN @NotifiTempMsgActionFR LIKE '%@RoleName%' THEN (select @NotifiTempMsgRoleFR +' '+replace(@NotifiTempMsgActionFR,'@RoleName',''))
											ELSE (SELECT case @action when 1 then ' '+rtrim(@NotifiMsg3FR)+' '  when 2 then ' '+rtrim(@NotifiMsg4FR)+' '  when 3 THEN ' '+rtrim(@NotifiMsg5FR)+' ' END +rtrim(ltrim(Fname)) from profile with (nolock) where profileid = @RoleProfileid) end
	END
	ELSE
	BEGIN
		SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('WFAction','Document',@latinlang),(case when @latinlang='E' then 'Document' else N'مستند' end))
			  ,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('WFAction','DocumentDate',@latinlang),(case when @latinlang='E' then 'Document Date' else N'بتاريخ' end))
			  ,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('WFAction','Document2',@latinlang),(case when @latinlang='E' then 'Document' else N'مستند' end))

		select @body=ltrim(RTRIM(@MsgH))+' '+case when @action=0 then isnull(@tempMsgRole,'')+' for ' else '' end+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @Latinlang ='A' THEN ltrim(rtrim(Profile.AName)) ELSE ltrim(rtrim(Profile.Name)) END +
			rtrim(ltrim(@SeparatorEnter))+rtrim(@ModuleMsg12)+rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
			CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(document.docAname)) WHEN @Switchlang='F' THEN ltrim(rtrim(document.docfName)) ELSE ltrim(rtrim(document.docname)) END +
			' '+rtrim(@ModuleMsg2)+rtrim(ltrim(@MsgSeparator))+' '+
			CASE WHEN @Latinlang='A' THEN CONVERT(char(11),empdoc.docdate,103) ELSE LTRIM(RTRIM(DAY(empdoc.docdate)))+' '+
			ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('WFActioncalendar',MONTH(empdoc.docdate),@Latinlang))),left(DATENAME(month,empdoc.docdate),3))+' '+LTRIM(RTRIM(YEAR(empdoc.docdate)))
			end
		FROM empdoc with (nolock)
		INNER JOIN document ON document.docId = empdoc.docid
		INNER JOIN Profile with (nolock) ON empdoc.EmpId = Profile.ProfileId
		WHERE profileid = @Empid and empdoc.documentno=@documentno

		SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
			,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid

		SELECT @body = @Body + case when @action<>0 then +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN (select @tempMsgRole +' '+replace(@TempMsgAction,'@RoleName',''))
											ELSE (SELECT case @action when 1 then ' '+rtrim(@msg3)+' '  when 2 then ' '+rtrim(@msg4)+' '  when 3 THEN ' '+rtrim(@msg5)+' ' END +CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile with (nolock) where profileid = @RoleProfileid) END
									else '' end
	END
END
--sms or mail part
	
		SET @Tempbody=''

  	
   	-- for customer merck 
  	IF  @msg9 <> '' 
  	BEGIN
  	  	
  		SELECT @TempMsg = rtrim(ltrim(@msg9)) +' '+ CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(FirstAName)) ELSE rtrim(ltrim(FirstName)) END  from profile with (nolock) where profileid =@ProfileID 
  		SELECT @TempMsg = @TempMsg +','+ CHAR(13)+CHAR(10) + CHAR(13)+CHAR(10)
  		
  		IF @SSNewStatus IN (1,2) AND @SSDocType = 3       --vacation 
  		BEGIN
			SELECT @msg12 = CASE WHEN @SSNewStatus=2 THEN REPLACE(@msg12,'approved','rejected') ELSE @msg12 END
			SELECT @msg12 = CASE WHEN @ProfileID <> @Empid  THEN REPLACE(@msg12,'your','employee') ELSE @msg12 END

  		   	SET @EMailbody= @TempMsg +rtrim(ltrim(@msg12))+ nchar(13)+nchar(10)+ @body +nchar(13)+nchar(10)+nchar(13)+nchar(10) + +rtrim(ltrim(@msg13)) + nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
  		END
  		ELSE IF  @SSNewStatus = 0  AND @ProfileID <> @Empid   AND @RoleProfileid <> @ProfileID AND @SSDocType = 3 -- status not approved and manager and vacation 
		BEGIN 
  		    SET @EMailbody=@TempMsg + rtrim(ltrim(@msg10))+ nchar(13)+nchar(10)+ nchar(13)+nchar(10)+@body +nchar(13)+nchar(10) +nchar(13)+nchar(10)+rtrim(ltrim(@msg16))+nchar(13)+nchar(10)+nchar(13)+nchar(10)+rtrim(ltrim(@msg11)) + nchar(13)+nchar(10) +nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
		END
  		ELSE IF  @SSNewStatus = 2  AND @ProfileID <> @Empid AND @SSDocType = 9   -- status placed and manager and training 
  		BEGIN
  		    SET @EMailbody=@TempMsg +rtrim(ltrim(@msg10))+ nchar(13)+nchar(10)+@body +nchar(13)+nchar(10) + rtrim(ltrim(@msg11)) + nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
  		END
  		ELSE  
		BEGIN
			
  	        SET @EMailbody=@body
  		END
  	END
  	ELSE
  	BEGIN  		
		IF @SMSorMail = 0
		BEGIN
			SET @NotifiEMailbody = @notifiBody 
			SET @NotifiEMailbodyAR =   @notifiBodyAR 
			SET @NotifiEMailbodyFR =   @notifiBodyFR 	
		END
		ELSE
			SET @EMailbody=@body

  	END

if @SSNewStatus = 1 and  @profileid = @empid 
BEGIN
	IF @SMSorMail = 0 
	BEGIN
		SET @NotifiEMailbody = @NotifiEMailbody + '. '
		SET @NotifiEMailbodyAR = @NotifiEMailbodyAR + '. '
		SET @NotifiEMailbodyFR = @NotifiEMailbodyFR + '. '
	END
	ELSE
		set @EMailbody = @EMailbody + '. '

	IF @SSDocType=20
	BEGIN
		SET @EMailbody = @EMailbody + CHAR(13)+CHAR(10)+ISNULL(@ModuleMsg4,'') + CHAR(13)+CHAR(10)+ISNULL(@ModuleMsg5,'')
	END

END
       
       
--if @EMailAction = 4
--       set @EMailbody = @EMailbody + '. '+@Msg6
IF @EMailAction IN (1,4,5) AND (SELECT dbo.GetWFActionType2(@ProfileID,@DocumentNo,@Empid,@SSDocNo)) =1      
BEGIN
-- for customer is not merck 
	IF  @msg9 = ''
	BEGIN
		IF @SMSorMail = 0 
		BEGIN
			SET @NotifiEMailbody =  @NotifiEMailbody+' ,'+@NotifiMsg6 + ' @approval@'
			SET @NotifiEMailbodyAR =  @NotifiEMailbodyAR+' ,'+@NotifiMsg6AR + ' @approval@'
			SET @NotifiEMailbodyFR =  @NotifiEMailbodyFR+' ,'+@NotifiMsg6FR + ' @approval@'
		END
        ELSE	
			SET @EMailbody = @EMailbody+@SeparatorEnter+@Msg6  
		
	END

END
IF @EMailAction IN (-1) and @action=0 and (SELECT dbo.GetWFActionType2(@ProfileID,@DocumentNo,@Empid,@SSDocNo)) =1      
BEGIN	
	SET @EMailbody = @EMailbody+@SeparatorEnter+@Msg6  
END
   --=======================================================  
IF @EMailAction =6
BEGIN
		IF @SMSorMail = 0 
		BEGIN
			SET @NotifiEMailbody =  @NotifiEMailbody+CHAR(13)+CHAR(10)
			SET @NotifiEMailbodyAR =  @NotifiEMailbodyAR+CHAR(13)+CHAR(10)
			SET @NotifiEMailbodyFR =  @NotifiEMailbodyFR+CHAR(13)+CHAR(10)
		END
        ELSE	
			SET @EMailbody = @EMailbody+CHAR(13)+CHAR(10)
		
END       

IF @SMSorMail = 0
BEGIN
	SET @notifiTempbody = @NotifiEMailbody
	SET @notifiTempbodyAR = @NotifiEMailbodyAR
	SET @notifiTempbodyFR = @NotifiEMailbodyFR
END
ELSE
	SET @Tempbody=@EMailbody

 -- for customer is not merck 
if @msg9 = '' 
BEGIN
	IF  @SSDocType <> 20 OR (@SSDocType = 20 and  @profileid <> @empid )
	BEGIN
		IF @SMSorMail = 0
		BEGIN
			SELECT @Recipient = '' ,@NotifiRecipient='' ,@NotifiRecipientAR='',@NotifiRecipientFR=''
			SELECT @Recipient = LTRIM(RTRIM( CASE WHEN @latinlang ='A' THEN Profile.AName ELSE Profile.Name END )) FROM Profile with (nolock) WHERE Profile.ProfileId = @ProfileID
		
			SELECT @NotifiRecipient = LTRIM(RTRIM( Profile.Name)) 
			  ,@NotifiRecipientAR = LTRIM(RTRIM( Profile.AName)) 
			  ,@NotifiRecipientFR = LTRIM(RTRIM( Profile.FName)) 
			  FROM Profile with (nolock) WHERE Profile.ProfileId = @ProfileID

			SELECT @notifiTempbody = REPLACE(@notifiTempbody,'@Recipient',@NotifiRecipient)
			  ,@notifiTempbodyAR = REPLACE(@notifiTempbodyAR,'@Recipient',@NotifiRecipientAR)
			  ,@notifiTempbodyFR = REPLACE(@notifiTempbodyFR,'@Recipient',@NotifiRecipientFR)

			SELECT @notifiTempbody = REPLACE(@notifiTempbody,'@EmployeeID',@ID)
			,@notifiTempbodyAR = REPLACE(@notifiTempbodyAR,'@EmployeeID',@ID)
			,@notifiTempbodyFR = REPLACE(@notifiTempbodyFR,'@EmployeeID',@ID)
		END
        
		ELSE
		BEGIN
			if @ActionResaon<>'' 
		begin
			SET @Tempbody=@EMailbody+CHAR(13)+CHAR(10)+rtrim(ltrim(@Msg8))+' '+rtrim(ltrim(@ActionResaon))
			SET @Tempbody=@Tempbody+CHAR(13)+CHAR(10)+@Msg7
		END
		else
		begin
			SET @Tempbody=@EMailbody +  CHAR(13)+CHAR(10)+@Msg7 
			
		end
		set @TaskDesc=@EMailbody
		SELECT @Recipient = '' ,@NotifiRecipient='' ,@NotifiRecipientAR='',@NotifiRecipientFR=''
		SELECT @Recipient = LTRIM(RTRIM( CASE WHEN @latinlang ='A' THEN Profile.AName ELSE Profile.Name END )) FROM Profile with (nolock) WHERE Profile.ProfileId = @ProfileID
		
		SET @Tempbody=@Tempbody+CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)+@MsgF
		

		SELECT @Tempbody = REPLACE(@Tempbody,'@Recipient',@Recipient)
		SELECT @Tempbody = REPLACE(@Tempbody,'@EmployeeID',@ID)

		SELECT @TaskDesc = REPLACE(@TaskDesc,'@Recipient',@Recipient)
		SELECT @TaskDesc = REPLACE(@TaskDesc,'@EmployeeID',@ID)
		END   
	END 
end	 
   
--end sms or mail part
--SELECT @body=CASE WHEN @SmsOrMail=0 THEN @tempBodySMS ELSE @tempBodyMail end

SELECT @body= CASE WHEN @SMSorMail = 0 THEN ( CASE WHEN ISNULL(@notifiTempbody,'') = '' THEN '' ELSE  ' @ENLang@ ' +@notifiTempbody end +
						 CASE WHEN ISNULL(@notifiTempbodyAR,'') = ''  THEN '' ELSE '@ARLang@ ' +ISNULL(@notifiTempbodyAR,'') END +
						 CASE WHEN ISNULL(@notifiTempbodyFR,'') ='' THEN '' ELSE '@FRLang@ ' + ISNULL(@notifiTempbodyFR,'') END)
						 ELSE @Tempbody END	

IF @SMSorMail=2
BEGIN
	SET @body=@TaskDesc
END
	

RETURN 	  @body  
END

GO

