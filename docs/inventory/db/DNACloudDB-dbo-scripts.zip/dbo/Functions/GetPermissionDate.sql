




CREATE                FUNCTION [dbo].[GetPermissionDate]
 (@Empid int, @PermissionFrom smalldatetime, @PermissionTo smalldatetime, @PermissionType as  smallint)
 RETURNS smalldatetime
 AS  
BEGIN 
--this function to return the date of the time permission according to the employee shift
declare @PermissionDate as smalldatetime
select @PermissionDate=max(EntryDate) FROM  EmpShiftInOut 
where Empid=@Empid and ((ShiftIn between @PermissionFrom and @PermissionTo) or (ShiftOut between @PermissionFrom and @PermissionTo)
   or (@PermissionFrom between TimeIn and TimeOut) or (@PermissionTo between TimeIn and TimeOut) or 
   (TimeIn between @PermissionFrom and @PermissionTo) or (TimeOut between @PermissionFrom and @PermissionTo) or
  (@PermissionFrom between dateadd(hh,-4,ShiftIn) and dateadd(hh,4,ShiftOut)) or (@PermissionTo between  dateadd(hh,-4,ShiftIn) and dateadd(hh,4,ShiftOut)))

select @PermissionDate=isnull(@PermissionDate,convert(datetime,convert(nchar(10),@PermissionFrom,120),120))
return @PermissionDate

END

GO

