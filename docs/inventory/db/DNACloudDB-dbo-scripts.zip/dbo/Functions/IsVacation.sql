
CREATE FUNCTION [dbo].[IsVacation](@Date datetime,@VacPack as INT)
RETURNS BIT
AS
BEGIN
	DECLARE @Holiday INT, @DayOff INT 
	SELECT @Holiday=0,@DayOff=0

	SELECT @DayOff = (CASE  WHEN DATEPART(dw,@Date) =  v.doffday1 THEN 1 
							WHEN DATEPART(dw,@Date) =  v.doffday2 THEN 1 ELSE 0 END) 
					FROM vacpack v 
					WHERE v.vacpack=@VacPack AND v.dofftype=1

	IF @DayOff <> 0 RETURN 1 
	
	SELECT @Holiday = 1 
					FROM holidays h 
					WHERE h.vacpack=@VacPack AND h.holiday=1 AND h.date = @Date
	
	IF @Holiday <> 0 RETURN 1
	
	RETURN 0 
END

GO

