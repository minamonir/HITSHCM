

CREATE FUNCTION [dbo].[MC_GetLatestApproval]  (@EmpId int,@MCID UNIQUEIDENTIFIER,@MCDocType smallint,@RoleProfileID int,@MonthlyHistory smallint)
RETURNS INT AS  
BEGIN

--@monthlyHistory:
----0:History
----1:Monthly

	DECLARE @RoleID AS SMALLINT = 0--, @MaxDate AS DATETIME

	IF @MCDocType = 15   --Payroll
	BEGIN
	    if @MonthlyHistory = 0
		begin
			SELECT TOP 1 @RoleID = MCDocApprovalHistory.RoleID 
			FROM MCDocApprovalHistory WITH (NOLOCK)
			INNER JOIN MCDocument WITH (NOLOCK) ON MCDocument.MCDocNo = MCDocApprovalHistory.MCDocNo 
			WHERE ApprovalProfileId = @RoleProfileID AND MCDocument.MCDocType = @MCDocType
			AND MCDocApprovalHistory.MCID = @MCID 
			ORDER BY ApprovalDate DESC
		end
		else
		begin
			SELECT TOP 1 @RoleID = MCDocApproval.RoleID 
			FROM MCDocApproval WITH (NOLOCK)
			INNER JOIN MCDocument WITH (NOLOCK) ON MCDocument.MCDocNo = MCDocApproval.MCDocNo 
			WHERE ApprovalProfileId = @RoleProfileID AND MCDocument.MCDocType = @MCDocType
			AND MCDocApproval.MCID = @MCID 
			ORDER BY ApprovalDate DESC
		end
		
	END

RETURN @RoleID
END

----------------------------------------------------------------------------------------------------------------------------

GO

