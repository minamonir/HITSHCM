
CREATE        FUNCTION [dbo].[Greg2Hijri] (  @l_gergdate As DateTime , @lang as nchar(1) )  
RETURNS nchar(10) AS  
begin
declare @l_day As smallint
declare @l_year As smallint
declare @l_month As smallint
declare @l_noofdays As Integer
declare @l_returndate As nvarchar(100)
declare @l_sign As Integer
declare @l_gergpass As Integer
declare @currmonthdays As Integer
--declare @yearmonth As Integer
declare @totaladjust as integer
declare @adj as integer
declare @days as integer      
declare @Gref as datetime     
declare @Href as nchar(10)
declare @EnableHijri bit 
declare @DateFormat int

declare @casemonth as smallint
declare @caseyear as smallint

set @Gref = '01/01/2001'
set @Href = '06/10/1421'
select @EnableHijri=EnableHijri , @DateFormat=[DateFormat] from dbo.SysParam
if @EnableHijri =0 return N''

if @l_gergdate is null return N''

declare @n As Integer
      If @l_gergdate > @Gref 
           Begin
            set @l_noofdays = datediff(dd,@Gref,@l_gergdate) 
          set @l_sign = 1
         end 
        else 
           Begin
            set @l_noofdays = datediff(dd,@l_gergdate,@Gref)
            set @l_sign = -1
           end

      set @totaladjust= 0
        set @l_day = cast(substring(@Href,1,2) as smallint)
        set @l_month =  cast(substring(@Href,4,2) as smallint)
        set @l_year =  cast(substring(@Href,7,4) as smallint)

        If @l_sign = 1 Begin
            While @l_noofdays > 0
            begin
            set @currmontHdays = 0
            --set @yearmonth = @l_year * 100 + @l_month
            
            set @adj = 0 
            select @adj=Adjustment from HijriAdjustment where HijriYear = @l_year and HijriMonth =@l_month 
            set  @adj = isnull(@adj,0)
                set @currmontHdays = @adj
                set @totaladjust = @totaladjust + @currmontHdays
            set @days = 0
            select @days = HijriDays from HijriBase where HijriMonth =@l_month 
            set @days = isnull(@days,0)
                set @currmontHdays = @currmontHdays +@days
            
               If @l_noofdays > @currmontHdays 
                 Begin
                    If @l_month = 12 
                     Begin
                        set @l_month = 1
                        set @l_year = @l_year + 1
                     end 
                    else 
                     Begin
                        set @l_month = @l_month + 1
                     end
                     set @l_noofdays = @l_noofdays - @currmontHdays
            
            
              end 
                else 
                 Begin
                  
                    If (@l_noofdays + @l_day) > @currmontHdays 
                  Begin
                         If @l_month = 12 Begin
                            set @l_month = 1
                            set @l_year = @l_year + 1
                        end else Begin
                            set @l_month = @l_month + 1
                         end
                        set @l_day = @l_day + @l_noofdays - @currmontHdays
                       end 
                     else Begin
                        set @l_day = @l_day + @l_noofdays
                    end
                    set @l_noofdays = 0
                end
            End 
      end
         else 
           Begin
            While @l_noofdays > 0
            begin
                set @currmontHdays = 0
               -- set @yearmonth = (case when @l_month = 1 then  @l_year - 1 else  @l_year end ) * 100 + (case when @l_month = 1 then  12 else @l_month - 1 end )
            
set  @caseyear= (case when @l_month = 1 then  @l_year - 1 else  @l_year end ) 
set @casemonth =(case when @l_month = 1 then  12 else @l_month - 1 end )

set @adj = 0 
            select @adj=Adjustment from HijriAdjustment where HijriYear =@caseyear and HijriMonth =  @casemonth 
            set @adj = isnull(@adj,0)
                set @currmontHdays = @adj
                set @totaladjust = @totaladjust + @currmontHdays
            set @days = 0
            select @days = HijriDays from   HijriBase where HijriMonth = @casemonth
            set @days = isnull(@days,0)
                set @currmontHdays = @currmontHdays +@days
               If @l_noofdays > @currmontHdays Begin
                    If @l_month = 1 Begin
                       set @l_month = 12
                       set @l_year = @l_year - 1
                    end else Begin
                       set @l_month = @l_month - 1
                    end
                    set @l_noofdays = @l_noofdays - @currmontHdays
                end else Begin
                    If @l_noofdays >= @l_day Begin
                        If @l_month = 1 Begin
                          set  @l_month = 12
                          set  @l_year = @l_year - 1
                        end else Begin
                          set  @l_month = @l_month - 1
                        end
                        set @l_day = @l_day - @l_noofdays + @currmontHdays
                    end else Begin
                       set @l_day = @l_day - @l_noofdays
                    end
                  set  @l_noofdays = 0
                end
            End 
        end

set @l_returndate = N''

--declare @time as nvarchar(15)
--set @time = ''

--if @lang = 'T'  begin 
--                       set @time = convert(nvarchar(15),@l_gergdate,108)   
--                      set @lang = 'E'  
--                       end


if @lang = 'O'
   begin 
       set @lang = 'E'  
       set @DateFormat = 0
   end


if  @lang = 'E' 
   begin
   if @DateFormat = 0 begin -- yyyy/mm/dd

     set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_year)))+ '/'
        If @l_month < 10 Begin
        set @l_returndate = @l_returndate + '0'
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_month))) + '/'
        If @l_day < 10 Begin
        set  @l_returndate =@l_returndate+'0'--+@l_returndate  
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_day))) 

   end
   if @DateFormat = 1  begin -- dd/mm/yyyy
        If @l_day < 10 Begin
        set  @l_returndate ='0'--+@l_returndate  

        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_day))) + '/'

        If @l_month < 10 Begin
        set @l_returndate = @l_returndate + '0'
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_month))) + '/'
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_year)))

end
   if @DateFormat = 2  begin --mm/dd/yyyy

        If @l_month < 10 Begin
        set @l_returndate = @l_returndate + '0'
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_month))) + '/'
        If @l_day < 10 Begin
        set  @l_returndate =@l_returndate+'0'--+@l_returndate  

        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_day))) + '/'

        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_year)))

end
end
else 
begin
  if @DateFormat = 1 begin -- yyyy/mm/dd

     set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_year)))+ '/'
        If @l_month < 10 Begin
        set @l_returndate = @l_returndate + '0'
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_month))) + '/'
        If @l_day < 10 Begin
        set  @l_returndate =@l_returndate+'0'--+@l_returndate  
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_day))) 

       end
   if @DateFormat = 0  begin -- dd/mm/yyyy
        If @l_day < 10 Begin
        set  @l_returndate ='0'--+@l_returndate  

        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_day))) + '/'

        If @l_month < 10 Begin
        set @l_returndate = @l_returndate + '0'
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_month))) + '/'
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_year)))

end
   if @DateFormat = 2  begin --mm/dd/yyyy

        If @l_month < 10 Begin
        set @l_returndate = @l_returndate + '0'
        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_month))) + '/'
        If @l_day < 10 Begin
        set  @l_returndate =@l_returndate+'0'--+@l_returndate  

        end
        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_day))) + '/'

        set @l_returndate = @l_returndate + rtrim(ltrim(str(@l_year)))

end
end
--set  @l_returndate = @l_returndate +' ' +  @time
return @l_returndate
END

GO

