Create FUNCTION [dbo].[Z_GetOverShortWithDetails]
	(@EmpId int,  @FromDate smalldatetime, @ToDate smalldatetime, @ValueType as SMALLINT,@OverShort SMALLINT,@HourFactor decimal(9,3),@CalFactor bit,@IgnoreAccumulate bit)
 RETURNS numeric(18,3)
AS
BEGIN
--@ValueType=1 over, @ValueType=2 short, @ValueType=3 allowance

declare @returnvalue numeric(18,3)

DECLARE @temp TABLE(Empid INT,paycode smallint,OverValue numeric(18,3))

INSERT INTO @temp
SELECT * FROM dbo.Z_GetOverShortTable(@empid,@FromDate,@ToDate,@valuetype,@OverShort,@HourFactor,@CalFactor,@IgnoreAccumulate,0,0)
SELECT @returnvalue=SUM(ISNULL(overvalue,0)) FROM @temp

RETURN ISNULL(@returnvalue,0)
END

GO

