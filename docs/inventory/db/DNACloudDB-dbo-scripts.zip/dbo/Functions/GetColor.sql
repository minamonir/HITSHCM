CREATE FUNCTION GetColor
(
	@ColorInDecimal INT
)
RETURNS NVARCHAR(7)
AS
BEGIN
IF @ColorInDecimal =0
SET @ColorInDecimal=16777215

DECLARE @Hex VARCHAR(8)
DECLARE @ReversedHex  NVARCHAR(6),@ReturnedHex NVARCHAR(7)
SELECT @Hex =CONVERT(VARCHAR(8),CONVERT(VARBINARY(4), @ColorInDecimal),2)
SET @ReversedHex=SUBSTRING(@Hex,3,6)
SET @ReturnedHex ='#'+REVERSE(@ReversedHex)


RETURN @ReturnedHex
END

GO

