

CREATE   FUNCTION [dbo].[GetEmpOrder]
(@EmpId int,@EffectiveDate datetime)
RETURNS int
AS
	BEGIN
	declare @EmpOrder as int 
      
	  
	  select top 1 @EmpOrder =OrderNo   
	  from  EmpOrder 
	  where EmpId = @EmpId and EffectiveDate <= @EffectiveDate
	  order by EffectiveDate desc    
	      
	RETURN isnull(@EmpOrder,0)

end

GO

