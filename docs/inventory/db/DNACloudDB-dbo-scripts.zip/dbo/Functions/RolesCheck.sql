CREATE FUNCTION [dbo].[RolesCheck] 
	(@ReportNo as smallint,@Tablename as nchar(30),@UserId AS int) RETURNS NVARCHAR(max)
AS
BEGIN
	DECLARE @Where AS NVARCHAR(max)
	SET @Where=''		
	IF (SELECT SysParam.EnableRoleValidation FROM SysParam ) = 1
	BEGIN
		DECLARE @RoleFields AS NVARCHAR(max),@SSGroupField AS NVARCHAR(max)
		DECLARE @Roles TABLE (RoleId SMALLINT)
		SELECT @RoleFields = SUBSTRING(ReportsTables.TableRoleFields,1,8000),@SSGroupField=CASE WHEN CHARINDEX('AppAssignment',ReportsTables.TableFrom)>0 THEN 'AppAssignment.SSGroup' WHEN CHARINDEX('EmpAssignment',ReportsTables.TableFrom)>0 THEN 'EmpAssignment.SSGroup' ELSE '0' END FROM ReportsTables 
		WHERE ReportNo=@ReportNo AND TableName=@Tablename
		IF @RoleFields <>''
		BEGIN
			INSERT INTO @Roles SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId=@UserId
			DECLARE @RoleID AS NVARCHAR(max)
			SET @RoleID = '#'
			SELECT @RoleID = @RoleID + CAST(RoleId AS NVARCHAR(5))+'#'
			FROM  @Roles
			 -------------modified by suzie 2023/10/16-------------
			IF  @RoleID = '#' SET @RoleId='' -- to handle the case user is @apply ssgroup=1 and he has no roles (it is called from hits_buildreportquery) 
			----------------------------------------------------
			
			IF @RoleID <> '#'
			--SET @Where = 'AND(dbo.RolesExist('''+@RoleID+''',''$''+ISNULL('+REPLACE(@RoleFields,',',','''')+''$''+ISNULL(')+','''')+''$'')=1)'
			SET @Where = 'AND(dbo.RolesExist('''+@RoleID+''',''$''+ISNULL('+REPLACE(@RoleFields,',',','''')+''$''+ISNULL(')+','''')+''$'','+@SSGroupField+','+ltrim(@UserId)+')=1)'
		END
	END
RETURN @Where
END

GO

