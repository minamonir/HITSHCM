
CREATE FUNCTION [dbo].[GetManager] (@EmpLoyeeID as NVARCHAR(50),@RoleID as INT = 1)
	RETURNS @Temp2 TABLE (EmployeeId NVARCHAR(50),ManagerId NVARCHAR(50))
AS


BEGIN
	
	
declare @Temp TABLE (EmployeeId NVARCHAR(50),ManagerId NVARCHAR(50))
INSERT INTO @Temp
SELECT EmpAssignment_1.EmployeeId EmployeeId
,EmpAssignment.EmployeeId ManagerId
FROM EmpAssignment
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN SSGroupRole ON EmpAssignment.EmpId = SSGroupRole.ProfileId 
LEFT JOIN EmpAssignment EmpAssignment_1 ON EmpAssignment_1.SSGroup = SSGroupRole.SSGroup
LEFT JOIN Profile Profile_1 ON EmpAssignment_1.EmpId = Profile_1.ProfileId 
LEFT JOIN HrStatus  ON HrStatus.hrstatus = EmpAssignment_1.HrStatus --AND HrStatus.paystatus = 1 
LEFT JOIN Organization ON EmpAssignment_1.Organization = Organization.Organization 
LEFT JOIN Grades ON Grades.Grade = EmpAssignment_1.Grade
LEFT JOIN Jobs ON EmpAssignment_1.Job = Jobs.job 
LEFT JOIN Location ON Location.LocationNo = EmpAssignment_1.LocationNo
where HrStatus.paystatus = 1 
AND SSGroupRole.RoleId = @RoleID

INSERT INTO @Temp2

SELECT EmpAssignment_1.EmployeeId EmployeeId
,EmpAssignment.EmployeeId ManagerId
FROM EmpAssignment
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN SSGroupRole ON EmpAssignment.EmpId = SSGroupRole.ProfileId 
LEFT JOIN EmpAssignment EmpAssignment_1 ON EmpAssignment_1.SSGroup = SSGroupRole.SSGroup
LEFT JOIN Profile Profile_1 ON EmpAssignment_1.EmpId = Profile_1.ProfileId 
LEFT JOIN HrStatus  ON HrStatus.hrstatus = EmpAssignment_1.HrStatus --AND HrStatus.paystatus = 1 
LEFT JOIN Organization ON EmpAssignment_1.Organization = Organization.Organization 
LEFT JOIN Grades ON Grades.Grade = EmpAssignment_1.Grade
LEFT JOIN Jobs ON EmpAssignment_1.Job = Jobs.job 
LEFT JOIN Location ON Location.LocationNo = EmpAssignment_1.LocationNo
where HrStatus.paystatus = 1 
AND SSGroupRole.RoleId = @RoleID
and ltrim(rtrim(EmpAssignment.EmployeeId))=ltrim(rtrim(@EmpLoyeeID))

--SELECT EmployeeId FROM @Temp2

DECLARE @TempID AS NVARCHAR(50) 
DECLARE R_Cursor CURSOR FOR

	SELECT EmployeeId FROM @Temp2
	
OPEN R_Cursor
FETCH NEXT FROM R_Cursor INTO @TempID
WHILE @@FETCH_STATUS = 0
BEGIN
	--SELECT @TempID	
	--select * FROM @Temp WHERE ManagerId=@TempID
	INSERT INTO @Temp2
	select * FROM @Temp 
	WHERE ManagerId=@TempID 
	AND dbo.HitsStr(EmployeeId)+'-'+dbo.HitsStr(ManagerId) NOT IN (SELECT dbo.HitsStr(EmployeeId)+'-'+dbo.HitsStr(ManagerId) FROM @Temp2)
	
	FETCH NEXT FROM R_Cursor INTO @TempID
END
CLOSE R_Cursor
DEALLOCATE R_Cursor




	
	RETURN
END

GO

