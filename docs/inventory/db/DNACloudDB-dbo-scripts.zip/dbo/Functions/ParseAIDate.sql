CREATE FUNCTION [dbo].[ParseAIDate] (@DateStr NVARCHAR(50))
RETURNS SMALLDATETIME
AS
BEGIN
    DECLARE @Result SMALLDATETIME;
    DECLARE @MonthYear NVARCHAR(50);

    -- Clean input
    SET @DateStr = LTRIM(RTRIM(ISNULL(@DateStr, '')));

    IF @DateStr = ''
        RETURN NULL;

    -- Handle "present" and "current" keywords - return current date
    --IF LOWER(@DateStr) IN ('present', 'current', 'now', 'till now', 'to present', 'till present', 'to date')
    --    RETURN CAST(GETDATE() AS SMALLDATETIME);

    -- Normalize AI output
    SET @DateStr = LOWER(@DateStr);
    SET @DateStr = REPLACE(@DateStr, '''', '');
    SET @DateStr = REPLACE(@DateStr, '.', '');

	SET @DateStr = REPLACE(@DateStr, 'st', '');
	SET @DateStr = REPLACE(@DateStr, 'nd', '');
	SET @DateStr = REPLACE(@DateStr, 'rd', '');
	SET @DateStr = REPLACE(@DateStr, 'th', '');
	SET @DateStr = REPLACE(@DateStr, ',', '');

    -- Reject values with no digits
    IF @DateStr NOT LIKE '%[0-9]%'
        RETURN NULL;

    -- 1. Try direct cast
    SET @Result = TRY_CAST(@DateStr AS SMALLDATETIME);
    IF @Result IS NOT NULL
        RETURN @Result;

    -- 2. MM/YYYY or MM-YYYY or MM.YYYY
    IF @DateStr LIKE '__[/. -]____'
    BEGIN
        SET @DateStr = REPLACE(REPLACE(@DateStr, '-', '/'), '.', '/');
        SET @Result = TRY_CAST(
                        LEFT(@DateStr, 2) + '/01/' + RIGHT(@DateStr, 4)
                        AS SMALLDATETIME
                     );
        IF @Result IS NOT NULL
            RETURN @Result;
    END

    -- 3. YYYY-MM
    IF @DateStr LIKE '____-__'
    BEGIN
        SET @Result = TRY_CAST(@DateStr + '-01' AS SMALLDATETIME);
        IF @Result IS NOT NULL
            RETURN @Result;
    END

    -- 4. Month name formats
    IF @DateStr LIKE '[a-z]%[0-9][0-9][0-9][0-9]'
    BEGIN
        IF @DateStr NOT LIKE '% %'
            SET @MonthYear =
                LEFT(@DateStr, LEN(@DateStr) - 4) + ' ' + RIGHT(@DateStr, 4);
        ELSE
            SET @MonthYear = @DateStr;

        -- truncate month to 3 letters for SQL Server parsing
        DECLARE @SpacePos INT = CHARINDEX(' ', @MonthYear);
        IF @SpacePos > 0
            SET @MonthYear = LEFT(@MonthYear, 3) + SUBSTRING(@MonthYear, @SpacePos, LEN(@MonthYear) - @SpacePos + 1);

        SET @Result = TRY_CAST('01 ' + @MonthYear AS SMALLDATETIME);
        IF @Result IS NOT NULL
            RETURN @Result;
    END

    -- 5. Year only
    IF LEN(@DateStr) = 4 AND @DateStr NOT LIKE '%[^0-9]%'
    BEGIN
        SET @Result = TRY_CAST('01/01/' + @DateStr AS SMALLDATETIME);
        IF @Result IS NOT NULL
            RETURN @Result;
    END

    RETURN NULL;
END

GO

