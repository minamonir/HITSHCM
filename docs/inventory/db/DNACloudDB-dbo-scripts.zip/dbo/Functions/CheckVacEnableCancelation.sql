

CREATE FUNCTION [dbo].[CheckVacEnableCancelation]
(    @EmpId INT,    
	@DocumentNo INT
)RETURNS BIT
AS
BEGIN
	DECLARE @VacStatus SMALLINT 

	SELECT @VacStatus = VacStatus 
    FROM EmpVacModifications 
    WHERE EmpId = @EmpId AND OriginalDocumentNo = @DocumentNo


	-- Case: staus is entered or not modified

	IF @VacStatus IS NULL OR @VacStatus = 6
	BEGIN
        RETURN 1
	END

    ELSE 
	BEGIN
		RETURN  0
	END
	RETURN  0
END

GO

