
--This fn calculates the salary for the applicant based on AppHrPCodes if not found read hrbasicsal value 

CREATE       FUNCTION [dbo].[calcapptotalsal]
  (@empid int, @assignmentid  int)

RETURNS numeric(18,3)
AS
 BEGIN
 declare @amount numeric(18,3)
 select @amount=sum((case when type=2 then -1 else 1 end)*dbo.CalcAppPaycode(@empid,@assignmentid,p.code,a.InputAmnt,0))  from AppHrPCodes a    inner join paycode p on p.code=A.paycode where
    p.addtotsal=1 and A.empid=@empid and   A.assignmentid=@assignmentid
set @amount=isnull(@amount,0)
 select @amount=@amount+case when p.addtotsal=1 then a.hrbasicsal else 0 end from appassignment a    inner join paycode p on p.code=100 where
    A.empid=@empid and   A.assignmentid=@assignmentid

return @amount
END

GO

