CREATE FUNCTION getNBoxLevelName (@EmpId INT ,@DocumentNo INT , @Type SMALLINT ,@Lang CHAR)
RETURNS NVARCHAR(20)
BEGIN
	
	DECLARE @LevelName AS NVARCHAR(20)
	--@Type=1 AutoNBoxPerformanceResult
	--@Type=2 NBoxPerformanceResult
	--@Type=3 AutoNBoxPotentialResult
	--@Type=4 NBoxPotentialResult
	
	SELECT @LevelName = dbo.GetRatingLevelName(CASE WHEN @Type IN (1 ,2) THEN Appraisals.NboxPerformanceRating ELSE Appraisals.NboxPotentialRating END 
	                                      ,CASE WHEN @Type=1 THEN EmpAppraisal.AutoObjectiveResult 
	                                            WHEN @Type=2 THEN empappraisal.ObjectiveResult
	                                            WHEN @Type=3 THEN empappraisal.AutoCompetenceResult
	                                            WHEN @Type=4 THEN empappraisal.CompetenceResult
	                                        END 
	                                      , @Lang)
	FROM EmpAppraisal 
	LEFT JOIN Appraisals ON Appraisals.AppraisalNo =empappraisal.AppraisalNo
	WHERE empappraisal.empid=@empid AND empappraisal.documentno=@Documentno
	RETURN isnull(@LevelName,'')
END

GO

