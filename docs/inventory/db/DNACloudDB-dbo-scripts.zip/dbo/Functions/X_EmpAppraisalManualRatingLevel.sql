
-- =============================================
create FUNCTION [dbo].[X_EmpAppraisalManualRatingLevel]
(
	 @empid as int,@documentno as int
)
RETURNS smallint
AS
BEGIN
declare @ManualResult as decimal(18,3),@appraisalNo as smallint,@lowlevel as numeric(18,3),@Highlevel as numeric(18,3),@ratingscale as smallint,@ratinglevel as smallint,@lowpercent as numeric(18,3),@Highpercent as numeric(18,3)

select @RatingScale =RatingScale,@ManualResult=EmpAppraisal.AppraisalResult from Empappraisal 
left join Appraisals on Empappraisal.appraisalno=Appraisals.appraisalno
where empid=@empid and documentNo=@documentno

if @RatingScale is null or @ManualResult<=0.0 set @ratinglevel= null
else
begin
select top 1  @lowlevel=ratinglevel ,@lowPercent=LevelPercent from RatingLevels where ratingscale=@ratingScale order by LevelPercent 

select top 1  @Highlevel=ratinglevel ,@HighPercent=LevelPercent from RatingLevels where ratingscale=@ratingScale order by LevelPercent desc

select top 1  @ratinglevel =ratinglevel from ratingLevels where ratingscale=@ratingScale and  LevelPercent<=@ManualResult order by levelpercent desc

if @ManualResult<@lowPercent   set @ratinglevel=@lowlevel
if @ManualResult>@HighPercent  set @ratinglevel=@Highlevel
end
return @ratinglevel


	

END

GO

