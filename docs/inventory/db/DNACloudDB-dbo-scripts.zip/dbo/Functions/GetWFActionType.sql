


CREATE    FUNCTION [dbo].[GetWFActionType]
  (@RoleProfileid int, @DocumentNo int, @Empid int ,  @ssdocno as smallint )
RETURNS  int
as
BEGIN


declare @roleid as smallint
declare @myorder as smallint
declare @beforeme as smallint
declare @beforemerq as smallint
declare @lastaction as smallint
declare @lastRole as smallint
declare @lastOrder as smallint
declare @lastid as int
declare @expired as smallint
declare @enddate as smalldatetime

set @roleid = null
SELECT top 1 @roleid=WFDocApproval.RoleId, @myorder=WFDocApproval.RoleOrder 
 FROM         SSGroupRole INNER JOIN
           WFDocApproval ON SSGroupRole.RoleId = WFDocApproval.RoleId INNER JOIN
           EmpAssignment ON WFDocApproval.EmpID = EmpAssignment.EmpId AND SSGroupRole.SSGroup = EmpAssignment.SSGroup
 WHERE     (SSGroupRole.ProfileId = @RoleProfileid) AND 
(WFDocApproval.DocumentNo =@DocumentNo)   AND (WFDocApproval.EmpID = @empid)  AND 
(WFDocApproval.ssdocno = @ssdocno) and  WFDocApproval.ApprovalProfileId is null
  order by WFDocApproval.RoleOrder 
 
if @roleid is null SELECT top 1 @roleid=WFDocApproval.RoleId, @myorder=WFDocApproval.RoleOrder 
 FROM         SSGroupRole INNER JOIN
           WFDocApproval ON SSGroupRole.RoleId = WFDocApproval.RoleId INNER JOIN
           EmpAssignment ON WFDocApproval.EmpID = EmpAssignment.EmpId AND SSGroupRole.SSGroup = EmpAssignment.SSGroup
 WHERE     (SSGroupRole.ProfileId = @RoleProfileid) AND 
(WFDocApproval.DocumentNo =@DocumentNo)   AND (WFDocApproval.EmpID = @empid)  AND 
(WFDocApproval.ssdocno = @ssdocno) 
  order by WFDocApproval.RoleOrder 


SELECT    top 1 @beforeme=RoleOrder , @beforemerq = ApprovalRequired
 FROM         WFDocApproval
 WHERE     (SSDocNo = @SSDocNo)  AND (RoleOrder <  @myorder) ORDER BY WFDocApproval.RoleOrder DESC
 set  @lastOrder = 1
select  top 1 @lastaction= WFDocApproval.ApprovalStatus ,  @lastRole = WFDocApproval.RoleId ,
  @lastid=WFDocApproval.ApprovalProfileId  , @lastOrder=WFDocApproval.RoleOrder , 
  @expired = WFDocument.Expired ,  @enddate = WFDocument.Enddate 
 FROM  WFDocApproval INNER JOIN
   WFDocument ON WFDocApproval.DocumentNo = WFDocument.DocumentNo AND WFDocApproval.EmpID = WFDocument.EmpID  AND WFDocApproval.ssdocno = WFDocument.ssdocno  
 where WFDocApproval.empid =@Empid and WFDocApproval.DocumentNo = @DocumentNo AND (WFDocApproval.ssdocno = @ssdocno)   
  and WFDocApproval.ApprovalProfileId is not null 
 ORDER BY WFDocApproval.RoleOrder desc


if (@lastOrder = 1) and (@lastaction is null ) and (@myorder = 1 ) and @enddate is  null  return 1

if (@lastOrder = @beforeme and     @lastaction = 1 and @enddate is  null)   return 1

IF  (@lastOrder <= @beforeme  and @beforemerq = 0  and @enddate is  null )    return 1

if ((@lastOrder <= @beforeme) and ( @enddate is  null))       return 0
if @lastOrder > @myorder or @expired = 1 or  @enddate is not null    return -1
return -1

END

GO

