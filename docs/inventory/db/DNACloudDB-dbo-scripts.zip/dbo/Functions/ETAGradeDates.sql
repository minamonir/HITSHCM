


CREATE FUNCTION [dbo].[ETAGradeDates]
(
	@EmpId AS INT ,@Grade AS SMALLINT , @Type AS SMALLINT
)
RETURNS SMALLDATETIME
AS
BEGIN

--Function Types
----------------
-- 1 : تاريخ التسوية
-- 2 : تاريخ الإرجاع
-- 3 : تاريخ الحصول علي الدرجة
-------------------------------

DECLARE @RequestedDate AS SMALLDATETIME

IF @Type = 1 OR @Type = 2
BEGIN

       DECLARE @Erga3 AS SMALLDATETIME,@Taswya AS SMALLDATETIME
       SET @Erga3=(SELECT TOP 1  EmpStatusHdr.EffectiveDate
                      FROM EmpStatusHdr
                      INNER JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = EmpStatusHdr.EmpId AND EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo
                      AND EmpStatusHdr.DocumentStatus = 1 AND EmpStatusDtl.FieldNo = 7 AND EmpStatusDtl.EmpId = @EmpId
                      LEFT JOIN Grades ON Grades.Grade = EmpStatusDtl.NewValue
                      LEFT JOIN Grades OldGrade ON OldGrade.Grade = dbo.GetOldValue(EmpStatusHdr.EmpId,7,EmpStatusHdr.EffectiveDate,NULL)
                      WHERE Grades.GradeAName LIKE N'%تخصصي%'
                      AND OldGrade.GradeAName NOT LIKE N'%تخصصي%'
                      AND OldGrade.GradeAName <> N''
                      ORDER BY EmpStatusHdr.EffectiveDate ASC)

                         

       SET @Taswya = ISNULL((SELECT TOP 1 EmpStatusHdr.EffectiveDate
                          FROM EmpStatusHdr
                          INNER JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = EmpStatusHdr.EmpId AND EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo
                          AND EmpStatusHdr.DocumentStatus = 1 AND EmpStatusDtl.FieldNo = 7 AND EmpStatusDtl.EmpId = @EmpId
                          LEFT JOIN Grades ON Grades.Grade = EmpStatusDtl.NewValue
                          LEFT JOIN Grades OldGrade ON OldGrade.Grade = dbo.GetOldValue(EmpStatusHdr.EmpId,7,EmpStatusHdr.EffectiveDate,NULL)
                          WHERE ltrim(rtrim(Grades.GradeAName)) = LTRIM(RTRIM(OldGrade.GradeAName))
                          AND Grades.GradeAName LIKE N'%تخصصي%'
                          ORDER BY EmpStatusHdr.EffectiveDate ASC) ,@Erga3)  
        
   
       SET @RequestedDate = (SELECT CASE @Type WHEN 1 THEN @Taswya
                                               ELSE (CASE WHEN @Erga3 = @Taswya THEN NULL ELSE @Erga3 END) END)  
                                                                                         

END
ELSE IF @Type = 3 AND @Grade IS NOT NULL
BEGIN
          
          SET @RequestedDate=(SELECT TOP 1 EmpStatusHdr.EffectiveDate
                              FROM EmpStatusHdr
                              INNER JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = EmpStatusHdr.EmpId AND EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo
                              AND EmpStatusHdr.DocumentStatus = 1 AND EmpStatusDtl.FieldNo = 7 AND EmpStatusDtl.EmpId = @EmpId
                              LEFT JOIN Grades ON Grades.Grade = EmpStatusDtl.NewValue
                              WHERE Grades.Grade = @Grade
                              ORDER BY EmpStatusHdr.EffectiveDate DESC)
                              
          IF @RequestedDate IS NULL
          BEGIN
          	SET @RequestedDate = (SELECT HireDate
          	                      FROM EmpAssignment
          	                      WHERE EmpId = @EmpId AND Grade = @Grade)
          END                                  

          
END

RETURN @RequestedDate

END

GO

