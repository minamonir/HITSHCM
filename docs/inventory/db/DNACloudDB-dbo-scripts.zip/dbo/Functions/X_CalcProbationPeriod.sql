CREATE FUNCTION [dbo].[X_CalcProbationPeriod]
(@empid AS INT, @hiredate AS DATETIME, @numDays AS INT, @DontCountDaysOFF AS BIT, @DontCountHolidays AS BIT, @DontCountVacation AS BIT)

RETURNS datetime
AS


BEGIN

DECLARE @countDays AS INT, @vacpackchange AS BIT, @vacpack as INT, @holidays INT, @dayoffs INT, @tempdate AS DATETIME, @VacorNot AS INT
SET @countDays = 0
SET @vacpackchange = 0
SET @tempdate = @hiredate

IF EXISTS(SELECT  EmpStatusHdr.EffectiveDate FROM EmpStatusHdr 
          INNER JOIN EmpStatusDtl ON EmpStatusHdr.EmpId = EmpStatusDtl.EmpId AND EmpStatusHdr.DocumentNo = EmpStatusDtl.DocumentNo
           WHERE (EmpStatusHdr.DocumentStatus = 1) AND (EmpStatusDtl.FieldNo = 19) AND (EmpStatusHdr.EmpId = @empid))
				SET @vacpackchange = 1 
ELSE 
	SELECT @vacpack=dbo.GetOldValue(@empid, 19, dateadd(dd,1,@hiredate), NULL)

IF ((@DontCountDaysOFF = 1) OR (@DontCountHolidays = 1) OR (@DontCountVacation = 1))
BEGIN
	WHILE @countDays < @numDays
	BEGIN
		SET @holidays=0
		SET @dayoffs=0
		SET @VacorNot = 0

		IF @vacpackchange = 1 
			SELECT @vacpack=dbo.GetOldValue(@empid, 19, dateadd(dd,1,@tempdate), NULL)

		IF @DontCountDaysOFF = 1
		BEGIN
			SELECT @dayoffs = (CASE WHEN  DATEPART(dw,@tempdate) =  v.doffday1 THEN 1 WHEN DATEPART(dw,@tempdate) = v.doffday2 THEN 1 ELSE 0 END ) 
			FROM vacpack v WHERE v.vacpack = @vacpack AND v.dofftype = 1
		END

		IF @DontCountHolidays = 1 AND @dayoffs = 0
		BEGIN
			SELECT @holidays= 1
			FROM holidays h WHERE h.vacpack = @vacpack AND h.holiday=1 AND h.date = @tempdate
		END

		IF @DontCountVacation = 1 AND @dayoffs = 0 AND @Holidays = 0
		BEGIN
			SELECT @VacOrNot=count(*) FROM Empvacat 
			LEFT JOIN Vacation ON Vacation.vaccode = Empvacat.VacCode
			WHERE (empid=@empid) 
		   AND (@tempdate between convert(smalldatetime,convert(nchar(12),Fromdate),103) and convert(smalldatetime,convert(nchar(12),todate),103))
		   AND vacstatus=1 AND (Vacation.DayFactor>=1 OR Vacation.DayFactor<=0)
		END
	
		IF @dayoffs=0 AND @holidays = 0 AND @VacorNot = 0 
		BEGIN
			SET  @countDays = @countDays + 1
		END
		SET @tempdate = @tempdate + 1
	END
END 
ELSE
BEGIN
    SET @tempdate = DATEADD(dd, @numDays, @tempdate)
END
RETURN @tempdate
END

GO

