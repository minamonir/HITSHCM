CREATE FUNCTION [dbo].[hits_GetBudget]()
RETURNS @BudgetTable TABLE 
	(BudgetNo int, 
	BudgetName nvarchar(MAX),
	BudgetAName nvarchar(MAX),
	BudgetCurrency int,
        CurName nvarchar(MAX),
	CurAName nvarchar(MAX),
	CalendarNo int,
	CalendarYear int,
	CalendarPeriod int,
        Description nchar(30),
	Value numeric(18,3)
	 )
AS
BEGIN
insert @BudgetTable select HRBudget.BudgetNo,
HRBudget.BudgetName,
HRBudget.BudgetAName,
HRBudget.BudgetCurrency,
Currency.CurName,
Currency.CurAName,
HRBudgetValues.CalendarNo,
HRBudgetValues.CalendarYear,
HRBudgetValues.CalendarPeriod,
'Max' as Description,
HRBudgetValues.MaxAmount As Value
from HRBudget
left join Currency on Currency.cur=HRBudget.BudgetCurrency
left join HRBudgetValues on HRBudgetValues.BudgetNo=HRBudget.BudgetNo
Left join Jobs on jobs.job=HRBudgetValues.job
left join Positions on Positions.positionno=HRBudgetValues.positionno
left join grades on grades.grade=HRBudgetValues.grade
left join location on location.locationno=HRBudgetValues.locationno
LEFT JOIN Organization ON HRBudgetValues.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 

Union

select HRBudget.BudgetNo,
HRBudget.BudgetName,
HRBudget.BudgetAName,
HRBudget.BudgetCurrency,
Currency.CurName,
Currency.CurAName,
HRBudgetValues.CalendarNo,
HRBudgetValues.CalendarYear,
HRBudgetValues.CalendarPeriod,
'Mid' as Description,
HRBudgetValues.MidAmount As Value
from HRBudget
left join Currency on Currency.cur=HRBudget.BudgetCurrency
left join HRBudgetValues on HRBudgetValues.BudgetNo=HRBudget.BudgetNo
Left join Jobs on jobs.job=HRBudgetValues.job
left join Positions on Positions.positionno=HRBudgetValues.positionno
left join grades on grades.grade=HRBudgetValues.grade
left join location on location.locationno=HRBudgetValues.locationno
LEFT JOIN Organization ON HRBudgetValues.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 

Union

select HRBudget.BudgetNo,
HRBudget.BudgetName,
HRBudget.BudgetAName,
HRBudget.BudgetCurrency,
Currency.CurName,
Currency.CurAName,
HRBudgetValues.CalendarNo,
HRBudgetValues.CalendarYear,
HRBudgetValues.CalendarPeriod,
'Min' as Description,
HRBudgetValues.MinAmount as Value
from HRBudget
left join Currency on Currency.cur=HRBudget.BudgetCurrency
left join HRBudgetValues on HRBudgetValues.BudgetNo=HRBudget.BudgetNo
Left join Jobs on jobs.job=HRBudgetValues.job
left join Positions on Positions.positionno=HRBudgetValues.positionno
left join grades on grades.grade=HRBudgetValues.grade
left join location on location.locationno=HRBudgetValues.locationno
LEFT JOIN Organization ON HRBudgetValues.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 

RETURN 
END

GO

