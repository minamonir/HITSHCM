
CREATE FUNCTION [dbo].[CheckResidntDataIfRequired]
  (@TableName NVARCHAR(MAX),@FieldName nvarchar(MAX))
RETURNS BIT
AS 
BEGIN 

	DECLARE @Required AS bit, @LookupSelect AS nVARCHAR(10)

set @Required=0

SELECT @LookupSelect=LookupSelect 
FROM DataDictionary 
WHERE TableName=@TableName AND FieldName=@FieldName
	
	IF @LookupSelect=1 
	BEGIN
		set @Required=1
	END
	
	RETURN @Required
END

GO

