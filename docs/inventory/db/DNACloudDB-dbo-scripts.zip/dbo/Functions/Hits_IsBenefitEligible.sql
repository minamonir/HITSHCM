

CREATE    FUNCTION [dbo].[Hits_IsBenefitEligible](@planno as int ,@enrolldate as smalldatetime, @empid as int)
RETURNS int
AS
BEGIN

declare @eligible as bit,@EligibleNo as smallint ,@required as bit,@count as int

SELECT @count=count(BenefitEligible.EligibleNo)
FROM BenefitEligible  Where BenefitEligible.Planno = @planno and required=1

set @eligible=case when @count<=0 then 1 else 0 end 


declare Eligible_Profiles cursor for SELECT distinct BenefitEligible.EligibleNo
FROM BenefitEligible  Where BenefitEligible.Planno = @planno and required=1

OPEN Eligible_Profiles
FETCH NEXT FROM Eligible_Profiles 
into @EligibleNo
WHILE @@FETCH_STATUS = 0
BEGIN

select @eligible=dbo.Hits_ISEligible(@empid,@EligibleNo,@enrolldate)
if @eligible=1 break
FETCH NEXT FROM Eligible_Profiles
into @EligibleNo 
END
CLOSE Eligible_Profiles
DEALLOCATE Eligible_Profiles
RETURN @eligible

END

GO

