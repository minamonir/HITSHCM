
CREATE  FUNCTION Hits_getpreviousdate 
	(@effectivedate as smalldatetime,@empid as int)
RETURNS  smalldatetime
AS
BEGIN
declare @prevdate smalldatetime
select @prevdate= max(effectivedate) from empstatushdr where effectivedate < @effectivedate and empid = @empid  
set @prevdate = isnull(@prevdate,(select hiredate from empassignment where empid = @empid))
return @prevdate
END

GO

