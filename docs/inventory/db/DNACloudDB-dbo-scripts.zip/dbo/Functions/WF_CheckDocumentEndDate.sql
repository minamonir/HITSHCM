

CREATE  FUNCTION [dbo].[WF_CheckDocumentEndDate] (@EmpID as int, @DocumentNo as int , @SSDocNo as SMALLINT, @RoleProfileId  AS int =0)
RETURNS INT
AS
BEGIN

Declare @WfDocEnd int=0
if exists ( select * from WFDocument where empid=@EmpID and DocumentNo=@DocumentNo 
and SSDocNo=@SSDocNo and EndDate is not null)
 
 set @WfDocEnd=1

RETURN ISNULL(@WfDocEnd,0) 
    
END

GO

