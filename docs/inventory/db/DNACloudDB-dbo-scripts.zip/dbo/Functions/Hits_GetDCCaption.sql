CREATE FUNCTION [dbo].[Hits_GetDCCaption](@TableName nvarchar(50),@FieldName nvarchar(50),@Lang nchar(1))

RETURNS NVARCHAR(100)
AS
BEGIN
	IF ISNULL(@Lang, N'') = N'' SELECT @Lang  = ErrorLang FROM SysParam
	
	DECLARE @Caption AS NVARCHAR(100)

	SELECT @Caption=LTRIM(RTRIM(CASE WHEN @Lang = 'A' THEN DataDictionary.ACaption
									 WHEN @Lang = 'F' THEN DataDictionary.FCaption
									 ELSE DataDictionary.Caption END))		
	FROM DataDictionary 
	WHERE DataDictionary.TableName=@TableName AND DataDictionary.FieldName=@FieldName 

	RETURN @Caption
		
END

GO

