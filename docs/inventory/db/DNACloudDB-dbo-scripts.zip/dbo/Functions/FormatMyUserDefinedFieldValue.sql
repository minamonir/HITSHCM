
CREATE FUNCTION [dbo].[FormatMyUserDefinedFieldValue] (@FieldType SMALLINT,@FieldValue NCHAR(254),@Lang NCHAR(1)='E', @Calendar NCHAR(1)='g') RETURNS NVARCHAR(254)
AS

BEGIN

DECLARE @ReturnTxt AS NVARCHAR(254),@DecimalScale INT ,@Dateformat INT

SELECT @DecimalScale =SysParam.DecimalScale,@Dateformat=SysParam.DateFormat
FROM SysParam

SELECT @ReturnTxt=
CASE WHEN @FieldType=3 THEN 
	CASE WHEN @DecimalScale=0 THEN  Convert(nvarchar,round(cast(@FieldValue AS NUMERIC(18,0)),@DecimalScale))
	WHEN @DecimalScale=1 THEN  Convert(nvarchar,round(cast(@FieldValue AS NUMERIC(18,1)),@DecimalScale))
	WHEN @DecimalScale=2 THEN  Convert(nvarchar,round(cast(@FieldValue AS NUMERIC(18,2)),@DecimalScale))
	ELSE   Convert(nvarchar,round(cast(@FieldValue AS NUMERIC(18,3)),@DecimalScale))
    END
	--Convert(nvarchar,round(@FieldValue,@DecimalScale))
	 WHEN @FieldType=4 AND @Lang='E' THEN
	 CASE WHEN 	@Calendar='G' THEN 
		 CASE	WHEN @Dateformat=0 --yyyy/mm/dd
					THEN substring(str(@FieldValue,8),1,4)+'/'+substring(str(@FieldValue,8),5,2)+'/'+substring(str(@FieldValue,8),7,2) 
				WHEN @Dateformat=1 --dd/mm/yyyy
					THEN substring(STR(@FieldValue,8),7,2)+'/'+substring(str(@FieldValue,8),5,2)+'/'+substring(str(@FieldValue,8),1,4)
				ELSE /*sysparam.DateFormat=2 mm/dd/yyyy*/
						substring(str(@FieldValue,8),5,2)+'/'+substring(str(@FieldValue,8),7,2)+'/'+substring(str(@FieldValue,8),1,4)
		 END
		 ELSE 
		 	CASE WHEN @Calendar='H' THEN dbo.Greg2Hijri(@FieldValue,'E')END
		  
	END
	 WHEN @FieldType=4 AND @Lang='A' THEN
	 CASE WHEN 	@Calendar='G' THEN 
		 CASE	WHEN @Dateformat=1 --yyyy/mm/dd
					THEN substring(str(@FieldValue,8),1,4)+'/'+substring(str(@FieldValue,8),5,2)+'/'+substring(str(@FieldValue,8),7,2) 
				WHEN @Dateformat=0 --dd/mm/yyyy
					THEN substring(STR(@FieldValue,8),7,2)+'/'+substring(str(@FieldValue,8),5,2)+'/'+substring(str(@FieldValue,8),1,4)
				ELSE /*@Dateformat=2 yyyy/dd/mm*/
						 substring(str(@FieldValue,8),1,4)+'/'+substring(str(@FieldValue,8),7,2)+'/'+substring(str(@FieldValue,8),5,2) 
		 END 
	ELSE 
		 	CASE WHEN @Calendar='H' THEN dbo.Greg2Hijri(@FieldValue,'A')END
	END
		 WHEN @FieldType=5 AND @Lang='E' THEN
	 CASE WHEN 	@Calendar='G' THEN 
		 CASE	WHEN @Dateformat=0 --yyyy/mm/dd
					THEN substring(str(@FieldValue,12),1,4)+'/'+substring(str(@FieldValue,12),5,2)+'/'+substring(str(@FieldValue,12),7,2)+' '+ substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)
				WHEN @Dateformat=1 --dd/mm/yyyy
					THEN substring(STR(@FieldValue,12),7,2)+'/'+substring(str(@FieldValue,12),5,2)+'/'+substring(str(@FieldValue,12),1,4)+' '+ substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)
				ELSE /*sysparam.DateFormat=2 mm/dd/yyyy*/
						substring(str(@FieldValue,12),5,2)+'/'+substring(str(@FieldValue,12),7,2)+'/'+substring(str(@FieldValue,12),1,4)+' '+ substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)
		 END
		 ELSE 
		 	CASE WHEN @Calendar='H' THEN dbo.Greg2Hijri(substring(@FieldValue,1,8),'E') END
		  
	END
	 WHEN @FieldType=5 AND @Lang='A' THEN
	 CASE WHEN 	@Calendar='G' THEN 
		 CASE	WHEN @Dateformat=1 --yyyy/mm/dd
					THEN substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)+' '+ substring(str(@FieldValue,12),1,4)+'/'+substring(str(@FieldValue,12),5,2)+'/'+substring(str(@FieldValue,12),7,2) 
				WHEN @Dateformat=0 --dd/mm/yyyy
					THEN substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)+' '+substring(STR(@FieldValue,12),7,2)+'/'+substring(str(@FieldValue,12),5,2)+'/'+substring(str(@FieldValue,12),1,4)
				ELSE /*@Dateformat=2 yyyy/dd/mm*/
						 substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)+' '+substring(str(@FieldValue,12),1,4)+'/'+substring(str(@FieldValue,12),7,2)+'/'+substring(str(@FieldValue,12),5,2) 
		 END 
	ELSE 
		 	CASE WHEN @Calendar='H' THEN dbo.Greg2Hijri(substring(@FieldValue,1,8),'A')END
	END
ELSE @FieldValue		 
END   

IF  @Calendar='H' AND @FieldType=5 and @returntxt <>'' SET @ReturnTxt=case when  @Lang='E' then @ReturnTxt+ ' '+ substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2) ELSE substring(str(@FieldValue,12),9,2)+':'+substring(str(@FieldValue,12),11,2)+' '+@ReturnTxt  END 

RETURN ISNULL(@ReturnTxt, '')
END

GO

