
CREATE FUNCTION [dbo].[IOTGetLocationParent]
  (@LocationID int, @RequiredParentType INT)
RETURNS  INT
AS
BEGIN 
  declare @ParentOfLocationType as int, @RequiredParent as int ,@ParentOfLocation AS INT

  SELECT @ParentOfLocation = IOTDeviceLocationParent FROM IOTDeviceLocations where IOTDeviceLocation=@LocationID 
  select @ParentOfLocationType=IOTDeviceLocationType from IOTDeviceLocations where IOTDeviceLocation=@ParentOfLocation 
  set @RequiredParent=0

  if @ParentOfLocationType<@RequiredParentType set @RequiredParent=0
  if @ParentOfLocationType=@RequiredParentType set @RequiredParent=@ParentOfLocation
  if @ParentOfLocationType>@RequiredParentType  
    BEGIN
      declare   @counter as int
      set @counter=1
      while @counter<8
         begin  
           select @ParentOfLocation=IOTDeviceLocationParent  from IOTDeviceLocations  where IOTDeviceLocation=@ParentOfLocation 
           if (@ParentOfLocation is null) break
           select @ParentOfLocationType=isnull(IOTDeviceLocationType,0) from IOTDeviceLocations where IOTDeviceLocation=@ParentOfLocation
           if @ParentOfLocationType=@RequiredParentType set @RequiredParent=@ParentOfLocation 
           set @counter =@counter+1
		 end          
    end
  return @RequiredParent
END

GO

