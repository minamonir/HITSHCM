CREATE FUNCTION [dbo].[WebAPIApplyRoles] 
	(@RoleFields as  NVARCHAR(max),@UserLogonName as nvarchar(80)) RETURNS NVARCHAR(max)
AS
BEGIN	
	declare @Where AS NVARCHAR(max),@TableRoles AS NVARCHAR(max)
	DECLARE @Roles TABLE (RoleId SMALLINT)
	DECLARE  @i AS INT
	SET @Where=''
	SET @i = 1

	DECLARE @RolesWhere AS nvarchar(max),@UserId AS INT,@ApplySSgrp AS bit,@MySelfParmExist AS INT,@EnableReportsRoles AS INT 
	SELECT @UserId=nasusers.EmpId,@ApplySSgrp=nasusers.ApplySSGroups from nasusers  where @UserLogonName=logonname

	IF (SELECT SysParam.EnableRoleValidation FROM SysParam )=1 and (@ApplySSgrp=1)
	BEGIN 
		 --SELECT  @RoleFields = TableRoleFields FROM ReportsTables 
		 --WHERE ReportNo=@ReportNo AND TableName=@Tablename
		 --select @RoleFields = ltrim(rtrim(isnull(@RoleFields,'')))
	 	  
	IF @RoleFields <>''
	BEGIN
		IF substring(@RoleFields,len(@RoleFields)-1,1) <> ',' select @RoleFields=  @RoleFields+','
	IF left(@RoleFields,1) <> ',' select @RoleFields=  ','+@RoleFields
	
		INSERT INTO @Roles  SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId = @UserId 
			
		WHILE CHARINDEX(',',@RoleFields,@i) < len(@RoleFields)
		BEGIN
		SET @i = CHARINDEX(',',@RoleFields,@i)
		SET @i = @i + 1
		SET @TableRoles = SUBSTRING(@RoleFields,@i,(CHARINDEX(',',@RoleFields,@i) - (CHARINDEX(',',@RoleFields,@i-1)))-1)
		SET @Where = @Where+'AND('+ @TableRoles + '='''' OR '+@TableRoles+' IS NULL'
		SELECT  @Where = @Where+' OR '+@TableRoles+' LIKE''%#'+CAST(RoleId AS NVARCHAR(4))+'#%''' 
		FROM @Roles
		SELECT  @Where = @Where+')'
		CONTINUE
		END
		IF @Where <> ''
			SET @Where = 'AND'+SUBSTRING(@Where,4,len(@Where))+''
		end
	END
RETURN @Where
END

GO

