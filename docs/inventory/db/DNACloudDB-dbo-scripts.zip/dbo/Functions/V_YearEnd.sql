

create  FUNCTION [dbo].[V_YearEnd]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS

--DECLARE @payrollgroup INT=1,@period INT=0,@year INT=0
BEGIN
  
  declare @thedate smalldatetime

		
   if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
   if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup	

  set @thedate=dbo.V_yearstart(@payrollgroup,@period,@year+1)-1



return  @thedate

END

GO

