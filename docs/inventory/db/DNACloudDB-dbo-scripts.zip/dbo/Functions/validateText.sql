
CREATE function [dbo].[validateText] (@TableName nvarchar(MAX),@FieldName nvarchar(MAX), @FieldValue nvarchar(MAX))
RETURNS bit
AS
BEGIN
DECLARE @Valid bit=1
DECLARE @RegexValue AS NVARCHAR(MAX), @RegexValue1 AS NVARCHAR(max)

SELECT @RegexValue = ltrim(rtrim(RegEXValue))
from SysParamRegEX 
where RegEXID = N'SQLFields.ValidateInput'
--'[^=@+-][^@+-]'

select @RegexValue=isnull(@RegexValue,N'')
if (@RegexValue <> N'' and @FieldValue<>N'')
begin
IF exists (SELECT * FROM SysParamExTxtValidation  WHERE RegFieldName=@FieldName and RegTableName=@TableName) 
BEGIN
	SET @Valid = 1
END
ELSE
BEGIN

SELECT @RegexValue1 = REPLICATE(SUBSTRING(@RegexValue,  CHARINDEX(']', @RegexValue) + 1, LEN(@RegexValue)), LEN(LTRIM(@FieldValue)) - 1)
SELECT @RegexValue = SUBSTRING(@RegexValue, 1,  CHARINDEX(']', @RegexValue) ) + '%' + @RegexValue1 + '%'
IF LTRIM(@FieldValue) like  @RegexValue 
BEGIN  
   --PRINT(@FieldValue + ' is Valid') 
   set @Valid=1
END
ELSE 
BEGIN 
	--PRINT(@FieldValue + ' is Not Valid') 
	set @Valid=0
END

	
END
END
    RETURN @Valid
END

GO

