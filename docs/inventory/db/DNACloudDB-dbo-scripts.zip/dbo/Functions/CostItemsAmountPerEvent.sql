

CREATE FUNCTION [dbo].[CostItemsAmountPerEvent]
	(@TrainingEvent int,@Category int,@Admin int, @CostItemType INT,@Type smallint, @Currency SMALLINT, @CostItemSource SMALLINT)
 RETURNS numeric(18,3) 
AS

--@Category = 0 All
--@Category = 1 Trainers
--@Admin = -1 All
--@Admin =0 Trainers = 0
--@Admin = 1 Supervisor = 1
--@Admin=2  Correector = 2
--@Type = 0 All
--@Type = 1 Resources
--@Type = 2 CostItems
--@CostItemSource = 0 All
--@CostItemSource <> 0 PerSource
--@CostItemType = 0 All
--@CostItemType = 2 TrainingCostItemType=1 credit
--@CostItemType = 1 TrainingCostItemType=2 debit

BEGIN

	DECLARE @ResourcesCost AS numeric(18,3)
	DECLARE @CostItems AS numeric(18,3)
	SET @ResourcesCost=0
	SET @CostItems=0

	IF @Type IN (0,1)
	BEGIN
			
			SELECT  @ResourcesCost = sum(dbo.Resource_UtilizationValue(TrainingResourcesBooking.TrainingResource,TrainingResourcesBooking.ResourceCategory,TrainingResourcesBooking.BookFrom
			                                                             ,TrainingResourcesBooking.BookTo,@TrainingEvent,0,1,@Currency,1,@Admin ))
											FROM TrainingResourcesBooking
											LEFT JOIN TrainingResources ON TrainingResources.TrainingResource = TrainingResourcesBooking.TrainingResource 
											AND TrainingResources.ResourceCategory = TrainingResourcesBooking.ResourceCategory
											LEFT JOIN TrainingCostItems ON TrainingResourcesBooking.TrainingCostItem = TrainingCostItems.TrainingCostItem
											LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = TrainingResourcesBooking.TrainingEvent
											WHERE TrainingResourcesBooking.TrainingEvent=@TrainingEvent
											AND TrainingResourcesBooking.BookStatus=1 AND TrainingResourcesBooking.BlockReason IS NULL
				                            AND ((TrainingEvents.EventFromDate BETWEEN TrainingResourcesBooking.BookFrom AND TrainingResourcesBooking.BookTo )
											Or (TrainingEvents.EventToDate   BETWEEN TrainingResourcesBooking.BookFrom  AND TrainingResourcesBooking.BookTo )
											Or ( TrainingResourcesBooking.BookFrom  Between TrainingEvents.EventFromDate And TrainingEvents.EventToDate)
											Or ( TrainingResourcesBooking.BookTo  Between TrainingEvents.EventFromDate And TrainingEvents.EventToDate)) 
										    AND trainingresourcesbooking.AdminResource =CASE WHEN @Admin= -1 THEN trainingresourcesbooking.AdminResource ELSE @Admin END 
									    	AND trainingcostitems.TrainingCostItemType=CASE WHEN @CostItemType=0 THEN trainingcostitems.TrainingCostItemType ELSE @CostItemType END 
			                                AND TrainingResourcesbooking.ResourceCategory=CASE WHEN @Category=0 THEN TrainingResourcesbooking.ResourceCategory ELSE @Category END 
			                                AND TrainingResourcesbooking.CostItemSource=CASE WHEN @CostItemSource=0 THEN TrainingResourcesbooking.CostItemSource ELSE @CostItemSource END 
	END
	
	IF @Type IN (0,2)
	BEGIN 
		SET  @CostItems =(SELECT SUM(
						CASE WHEN @CostItemType=0 THEN
						CASE WHEN TrainingCostItems.TrainingCostItemType =1 
						THEN dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount, EmpTrainingCostItems.CostItemCurrency, @Currency, EmpTrainingCostItems.CostItemDate)
						ELSE -1*dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount, EmpTrainingCostItems.CostItemCurrency, @Currency, EmpTrainingCostItems.CostItemDate) 
						END
						WHEN @CostItemType=1 THEN
						CASE WHEN TrainingCostItems.TrainingCostItemType =1 
						THEN dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount, EmpTrainingCostItems.CostItemCurrency, @Currency, EmpTrainingCostItems.CostItemDate)
						ELSE 0.000 
						END
						WHEN @CostItemType=2 THEN
						CASE WHEN TrainingCostItems.TrainingCostItemType =0 
						THEN dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount, EmpTrainingCostItems.CostItemCurrency, @Currency, EmpTrainingCostItems.CostItemDate)
						ELSE  0.000
						END END)
						FROM EmpTraining
						LEFT JOIN TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = Emptraining.EnrollStatus 
						LEFT JOIN EmpTrainingCostItems ON EmpTrainingCostItems.EmpId = EmpTraining.EmpId AND EmpTrainingCostItems.DocumentNo = EmpTraining.DocumentNo
						LEFT JOIN TrainingCostItems ON EmpTrainingCostItems.TrainingCostItem = TrainingCostItems.TrainingCostItem
						WHERE Emptraining.TrainingEvent=@TrainingEvent AND TrainingEnrollStatus.SystemEnrollStatus=4 AND EmpTraining.AdditionalTraining = 0
		                AND EmpTrainingCostItems.CostItemSource = CASE WHEN @CostItemSource=0 THEN EmpTrainingCostItems.CostItemSource else @CostItemSource END )

	END
RETURN ISNULL(@ResourcesCost,0) + ISNULL(@CostItems,0)
END

GO

