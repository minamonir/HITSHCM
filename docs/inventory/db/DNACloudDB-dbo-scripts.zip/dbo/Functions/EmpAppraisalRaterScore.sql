

CREATE  FUNCTION [dbo].[EmpAppraisalRaterScore] (@empid as int,@DocumentNo as INT,@RaterProfileId AS INT )  
RETURNS numeric(18,3)  AS  

 begin

declare @Appraisalno as int,@TotalScore as numeric(18,3),@CompWeight as numeric(18,3),@ObjWeight as numeric(18,3),
        @QuesWeight as numeric(18,3),@Proficiency as bit,@Performance as bit,@Objective as bit

      SELECT     @Appraisalno= Appraisals.Appraisalno ,@CompWeight=Appraisals.CompetenceWeight,@ObjWeight=Appraisals.ObjectiveWeight,
                 @QuesWeight=Appraisals.QuestionWeight,@Proficiency=Appraisals.Proficiency,@Performance=Appraisals.Performance,@Objective=Appraisals.Objective
      FROM Appraisals inner join EmpAppraisal on Appraisals.AppraisalNo=EmpAppraisal.AppraisalNo
      WHERE     (EmpAppraisal.EmpId = @EmpId) AND (EmpAppraisal.DocumentNo = @DocumentNo)


--------Comptencies and Objectives
IF( (@Performance=1 OR @Proficiency=1) AND @Objective=1)
BEGIN
                  IF (@CompWeight=0 and @ObjWeight=0 AND @QuesWeight=0)
                        begin
                              set @CompWeight=50
                              set @ObjWeight=50
                        END
END

--------Objectives
ELSE IF( (@Performance=0 AND @Proficiency=0) AND @Objective=1)
BEGIN
                  IF (@ObjWeight=0 AND @QuesWeight=0)
                        begin
                              set @ObjWeight=100
                        END
                        
      set @CompWeight=0
END

--------Comptencies
ELSE IF( (@Performance=1 OR @Proficiency=1) AND @Objective=0)
BEGIN
                  IF (@CompWeight=0 AND @QuesWeight=0)
                        begin
                              set @CompWeight=100
                        END
                        
      set @ObjWeight=0
END
                                          
	select @TotalScore=(((CASE WHEN @CompWeight=0 THEN 0 ELSE dbo.EmpCompetenceRaterScore(@empid,@DocumentNo,@RaterProfileId) END) *@CompWeight)
+(CASE WHEN @ObjWeight=0 THEN 0 ELSE dbo.EmpObjectiveRaterScore(@empid,@DocumentNo,@RaterProfileId) END *@ObjWeight)
+(CASE WHEN @QuesWeight=0 THEN 0 ELSE dbo.EmpQuestionsRaterScore(@empid,@DocumentNo,@RaterProfileId) END*@QuesWeight))/
(case when (@CompWeight+@ObjWeight+@QuesWeight)=0 then 1 else (@CompWeight+@ObjWeight+@QuesWeight) END)

--(@CompWeight+@ObjWeight+@QuesWeight)  
from dbo.EmpAppraisal where EmpId= @empid and DocumentNo=@DocumentNo
	

	
	return isnull(@totalscore,0)
 END

GO

