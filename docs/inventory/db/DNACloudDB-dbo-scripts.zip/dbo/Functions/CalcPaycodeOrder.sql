CREATE       FUNCTION [dbo].[CalcPaycodeOrder]   (@calc_code smallint)
RETURNS smallint AS  
begin

--@l_basedonperiod=0 current period
--@l_basedonperiod=1 prev period
--@l_basedonperiod=2 start of year
declare @l_basedon As smallint
declare @l_basedonperiod As smallint
declare @l_calcpaycd As smallint
declare @l_calcgrpcode As smallint
declare @l_inputtp As smallint
declare @l_NetOrTotal as smallint

declare @l_formula as nvarchar(max)

declare @l_order As smallint, @l_ordertemp as smallint

select @l_order=0, @l_ordertemp=0

select @l_basedon=basedon, @l_basedonperiod=basedonperiod, @l_NetOrTotal=NetOrTotal, 
  @l_calcpaycd=case when calcpaycd=code then 0 else calcpaycd end,
  @l_calcgrpcode=case when calcgrpcode=grpcode then 0 else calcgrpcode end,
  @l_inputtp=inputtp, @l_basedon=basedon
from paycode Where Code=@calc_code



if @l_basedon=4 and @l_calcpaycd<>0 -- based on paycode
begin
    if @calc_code<>@l_calcpaycd select @l_order=dbo.CalcPaycodeOrder(@l_calcpaycd)+1

end
if @l_basedon=5 and @l_calcgrpcode<>0 -- based on paycodegroup
begin

    declare grp_pay cursor for SELECT code FROM paycode WHERE grpcode=@l_calcgrpcode
    OPEN grp_pay
    FETCH NEXT FROM grp_pay INTO @l_calcpaycd
    WHILE @@FETCH_STATUS = 0
    begin
       if @calc_code=@l_calcpaycd break
       select @l_ordertemp=dbo.CalcPaycodeOrder(@l_calcpaycd)
       select @l_order = case when @l_ordertemp>=@l_order then @l_ordertemp+1 else @l_order end
       FETCH NEXT FROM grp_pay INTO @l_calcpaycd
    end
    CLOSE grp_pay
    DEALLOCATE grp_pay

end
if @l_basedon=6 --and @l_calcgrpcode<>0 -- based on formula
begin
 
    select @l_formula=upper(formulatxt) from paycode Where Code=@calc_code
    declare grp_pay cursor for SELECT code FROM paycode 
       WHERE CHARINDEX(replace('P'+str(code,3),N' ','0'),@l_formula)<>0
    OPEN grp_pay
    FETCH NEXT FROM grp_pay INTO @l_calcpaycd
    WHILE @@FETCH_STATUS = 0
    begin
       if @calc_code=@l_calcpaycd break
       select @l_ordertemp=dbo.CalcPaycodeOrder(@l_calcpaycd)
       select @l_order = case when @l_ordertemp>=@l_order then @l_ordertemp+1 else @l_order end
       FETCH NEXT FROM grp_pay INTO @l_calcpaycd
    end
    CLOSE grp_pay
    DEALLOCATE grp_pay
 
end
RETURN @l_order
end

GO

