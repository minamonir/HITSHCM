
CREATE  FUNCTION [dbo].[WF_CheckInvitationApprovals] (@LogonName as nvarchar(80)='' , @SSDocNo as SMALLINT, @EmpID as int, @DocumentNo as int ,@RoleId  AS SMALLINT ,@InvitedRoleid AS SMALLINT ,@InvitedProfileIdList AS NVARCHAR(MAX))
RETURNS INT
AS
BEGIN
DECLARE @Approved AS  BIT = 0
, @UserProfileId AS INT  ,@roleorder smallint 

if  @InvitedProfileIdList <> ''
BEGIN  
SELECT @UserProfileId = EmpId FROM dbo.NasUsers WHERE LTRIM(RTRIM(LogonName)) =  LTRIM(RTRIM(@LogonName)) 
SET @InvitedProfileIdList = REPLACE(@InvitedProfileIdList ,';',',')

SELECT TOP 1 @roleorder =roleorder 
FROM dbo.WFDocApproval 
where DocumentNo =@DocumentNo and EmpID= @EmpID and SSDocNo =@SSDocNo 
AND ApprovalProfileId=@UserProfileId AND RoleId=@Roleid AND Delegated IN (0,1)



SELECT @Approved = 1  
FROM dbo.WFDocApproval 
INNER JOIN WFDocInvitation ON WFDocInvitation.DocumentNo = WFDocApproval.DocumentNo AND WFDocInvitation.EmpID = WFDocApproval.EmpID 
AND WFDocInvitation.SSDocNo = WFDocApproval.SSDocNo
AND WFDocInvitation.RoleId = @Roleid AND WFDocApproval.roleid = WFDocInvitation.InvitedRoleid AND ISNULL(wfdocapproval.InvitedByRole,0)=WFDocInvitation.RoleId
AND WFDocApproval.ApprovalProfileId=WFDocInvitation.InvitedRoleProfileid 
where WFDocApproval.DocumentNo =@DocumentNo  and WFDocApproval.EmpID= @EmpID and WFDocApproval.SSDocNo =@SSDocNo   
AND WFDocApproval.RoleId = @InvitedRoleid AND Delegated=3 AND ApprovalStatus IS not NULL 
AND DelegatedBy=@UserProfileId and WFDocApproval.RoleOrder= @roleorder 
----AND WFDocInvitation.RoleProfileId=@UserProfileId
--AND WFDocApproval.ApprovalProfileId=@UserProfileId
----AND WFDocApproval.RoleOrder > 0 
----AND WFDocInvitation.RequestedBy  = 1  




--FROM dbo.WFDocApproval 
----LEFT JOIN dbo.WFDocInvitation ON WFDocInvitation.EmpID = WFDocApproval.EmpID
----AND WFDocInvitation.DocumentNo = WFDocApproval.DocumentNo
----AND WFDocInvitation.SSDocNo = WFDocApproval.SSDocNo
--INNER JOIN WFDocInvitation ON WFDocInvitation.DocumentNo = WFDocApproval.DocumentNo AND WFDocInvitation.EmpID = WFDocApproval.EmpID AND WFDocInvitation.SSDocNo = WFDocApproval.SSDocNo
--AND WFDocInvitation.RoleId = @Roleid AND WFDocApproval.roleid=WFDocInvitation.InvitedRoleid AND WFDocApproval.ApprovalProfileId=WFDocInvitation.InvitedRoleProfileid 
--LEFT JOIN dbo.NasUsers ON NasUsers.EmpId = WFDocApproval.ApprovalProfileId

--WHERE WFDocApproval.EmpID =@EmpID
--AND WFDocApproval.SSDocNo = @SSDocNo
--AND WFDocApproval.DocumentNo =@DocumentNo
--AND WFDocApproval.RoleId = @InvitedRoleid
---- AND ApprovalProfileId in(@InvitedProfileIdList)
---- AND @InvitedProfileIdList  LIKE '%'+rtrim(ltrim(STR(isnull(ApprovalProfileId,0))))+'%'
--AND ApprovalStatus IS NOT NULL
--AND ApprovalDate IS NOT NULL
--AND LTRIM(RTRIM(LogonName)) =  LTRIM(RTRIM(@LogonName))

END  

RETURN ISNULL(@Approved,0) 
    
END

GO

