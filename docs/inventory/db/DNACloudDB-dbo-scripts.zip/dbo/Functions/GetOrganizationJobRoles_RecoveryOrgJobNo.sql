
CREATE FUNCTION [dbo].[GetOrganizationJobRoles_RecoveryOrgJobNo] (@OrgNo AS SMALLINT,@JobNo AS SMALLINT,@RoleID AS SMALLINT,@Param AS NVARCHAR(MAX))
RETURNS nvarchar(max)
AS
BEGIN
	DECLARE @ParentJobOrgNo AS nvarchar(max),@Recovery_ProfileID_Count AS INT,@PosStr AS nvarchar(max),@Temp_LastParentOrgJobNo AS NVARCHAR(MAX)
	SET @ParentJobOrgNo = ''
	SET @Recovery_ProfileID_Count=0
	SET @PosStr=','+rtrim(ltrim(STR(@OrgNo)))+'-'+rtrim(ltrim(STR(@JobNo)))+','
	SET @Temp_LastParentOrgJobNo = ''

	WHILE @Recovery_ProfileID_Count=0 AND @PosStr<>''
	BEGIN
		SET @ParentJobOrgNo=''
		Select @ParentJobOrgNo = @ParentJobOrgNo +rtrim(ltrim(str(V_OrganizationJobRoles.RoleOrganization)))+'-' +rtrim(ltrim(str(V_OrganizationJobRoles.RoleJob)))+','
		FROM V_OrganizationJobRoles
		WHERE @PosStr like '%,'+rtrim(ltrim(STR(V_OrganizationJobRoles.RoleOrganization)))+'-'+rtrim(ltrim(STR(V_OrganizationJobRoles.RoleJob)))+',%'  AND RoleID=@RoleID
		AND @Temp_LastParentOrgJobNo NOT LIKE '%,'+rtrim(ltrim(str(V_OrganizationJobRoles.RoleOrganization)))+'-'+rtrim(ltrim(STR(V_OrganizationJobRoles.RoleJob)))+',%'
		
		SET @ParentJobOrgNo=CASE WHEN @ParentJobOrgNo='' THEN '' ELSE ','+RTRIM(LTRIM(@ParentJobOrgNo)) END 

		--find count of ppl who are playing @roleid on me
		SET @Recovery_ProfileID_Count = (select count(EmpAssignment.EmpId)
		FROM EmpAssignment
		INNER JOIN HrStatus ON HrStatus.hrstatus = EmpAssignment.HrStatus AND HrStatus.paystatus = 1
		AND @ParentJobOrgNo like '%,'+rtrim(ltrim(STR(isnull(EmpAssignment.Organization,0))))+'-'+rtrim(ltrim(STR(isnull(EmpAssignment.job,0))))+',%' )

		set @PosStr = @ParentJobOrgNo
		SET @Temp_LastParentOrgJobNo = @Temp_LastParentOrgJobNo +  @ParentJobOrgNo

		SET @Recovery_ProfileID_Count=ISNULL(@Recovery_ProfileID_Count,0)

	END

	RETURN @ParentJobOrgNo
END

GO

