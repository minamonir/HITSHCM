


---used for AAIB
CREATE FUNCTION [dbo].[EmpMDays] (@empid as int,@Month as int ,@Year as smallint)  
RETURNS numeric(9,3)  AS  
begin
declare @Days as numeric(9,3),@MStart as smalldatetime,@MEnd as smalldatetime,@Currentdate as smalldatetime

select @Currentdate=todaydate from today

select @MStart=convert(datetime,cast(@Month as nchar(2))+'/01/' +convert(nvarchar(4),@Year )),
@MEnd= convert(datetime,case when @Month=12 then '12/31/' else cast(@Month+1 as nchar(2))+'/01/' end +convert(nvarchar(4),@Year ))-case when @Month=12 then 0 else 1 end

select @Days = case 
when (hiredate <= @MStart) and  (isnull(termdate,@Currentdate) = @MEnd ) then 30
when (hiredate between  @MStart and @MEnd ) and  (isnull(termdate,@Currentdate) between  @MStart and @MEnd ) then datediff(d,hiredate,isnull(termdate,@Currentdate))+1 
when (hiredate = @MEnd )  then 1
when (hiredate=@MStart ) then 30
when (hiredate between  @MStart and @MEnd )  then day(@MEnd)-(datediff(d,@MStart,hiredate))
when  (isnull(termdate,@Currentdate) between  @MStart and @MEnd )  then (datediff(d,@MStart,isnull(termdate,@Currentdate)))+1
when hiredate >@MEnd or isnull(termdate,@Currentdate) <@MStart then 0
else 30 end

from empassignment
where empid=@empid






return @Days
end

GO

