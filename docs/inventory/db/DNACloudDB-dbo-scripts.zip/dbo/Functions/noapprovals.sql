CREATE FUNCTION noapprovals(@empid INT, @documentno INT, @ssdocno SMALLINT)
RETURNS SMALLINT
AS
BEGIN
	DECLARE @count AS SMALLINT = 0
 	SELECT	@count = COUNT(*)
	FROM	WFDocApproval
	WHERE	EmpID = @empid AND	DocumentNo = @documentno AND SSDocNo = @ssdocno AND ApprovalStatus IS NOT NULL
	RETURN @count
END

GO

