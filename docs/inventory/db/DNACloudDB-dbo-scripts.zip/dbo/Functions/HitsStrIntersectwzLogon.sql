

CREATE FUNCTION [dbo].[HitsStrIntersectwzLogon](@logonname as nvarchar(80),@tableorgs  as nvarchar(max) )
RETURNS smallint  AS  
--declare @logonname as nvarchar(80)='11',@tableorgs  as nvarchar(max)=''
BEGIN 
--declare @userorgs as nvarchar(max)='50,51,52,53,54,58,275,278,279,290,296',@tableorgs as nvarchar(max)='#51#52#53#'
declare @exist as smallint=0
declare @userorgs as nvarchar(max)

-----------------------------------------
declare @enableorgsetup as bit
select @enableorgsetup =enableorgsetup from sysparam 
if @enableorgsetup=0
begin
    return 1
end 
----------------------------------------


select @userorgs=ltrim(rtrim(userorganization)) from NasUsers where LogonName=@logonname

if @userorgs='' -- or ltrim(rtrim(@tableorgs))='' 
begin
set @exist=1
return @exist
end
else
begin 

declare @str as nvarchar(max)=''


--SELECT @str=@str+ rtrim(ltrim(str(max(OrganizationParentOrChild))))+','
--        from OrganizationParentChild  cross apply dbo.HitsStringSplit(@userorgs,'#') t
--        where  t.value <>'' and t.value=Organization 
--		and OrgRelation in (2,3)
--        group by OrganizationParentOrChild

--SELECT @str=@str+ rtrim(ltrim(str(max(OrganizationParentOrChild))))+','
--        from OrganizationParentChild  
--        where  @userorgs like '%#'+ltrim(rtrim(str(organization)))+'#%'
--		and OrgRelation in (2,3)
--        group by OrganizationParentOrChild



       ----select @str
	    --set  @str=case when  @str<>'' then left(@str,len( @str)-1)else  @str end 


--declare @version as smallint
--SELECT @Version=left(CONVERT(VARCHAR(128), SERVERPROPERTY ('productversion')),2)


--if @Version>=13
IF EXISTS(SELECT * FROM sys.databases WHERE databases.name=DB_NAME() AND databases.compatibility_level>=130)-- SQL2016+
begin


select top 1  @exist=1
 from OrganizationParentChild  inner join  string_split(@userorgs,'#') t on  t.value <>'' and OrgRelation in (2,3) and t.value=Organization 
inner join  string_split(@tableorgs,'#') t1 on  t1.value <>'' and t1.value =OrganizationParentOrChild
       
        
--select top 1  @exist=1
--from  string_split(@tableorgs,'#') t1
--inner join 
--string_split(@str,',') t  on   cast(t1.value as int)=cast(t.value as int)
--and cast(t1.value as int)<>'' and cast(t.value as int)<>''
end

else


begin

SELECT @str=@str+ ltrim(rtrim(str(max(OrganizationParentOrChild))))+','
        from OrganizationParentChild  cross apply dbo.HitsStringSplit(@userorgs,'#') t
        where  t.value <>'' and t.value=Organization 
		and OrgRelation in (2,3)
        group by OrganizationParentOrChild
 set  @str=case when  @str<>'' then left(@str,len( @str)-1)else  @str end 
declare @organizationTemp TABLE (Organization smallint)
 insert into @organizationTemp select * from  dbo.HitsStringSplit(@tableorgs,'#') t1

 select  @exist=1 from @organizationTemp 
 where 
      @str like '%,'+rtrim(ltrim(str(Organization)))+',%'
end


select @exist=case when @exist>0 then 1 else 0 end
end

--select @exist
return @exist
END

GO

