

CREATE FUNCTION [dbo].[KPIServiceYears]
	(@EmpId INT,@RefDate date, @Type smallint, @ReturnType BIT)
RETURNS  numeric(18,3)
AS
BEGIN
	
	--@Type	0→ calculates service years from hire date till @RefDate 
	--		1→ calculates service years from last assignment change till @RefDate
	--		2→ calculates service years from ratio between the service years the employee spend in his last position to the total service years
	--		3→ calculates service years from  his last position to the total service years
	-------------------
	--@ReturnType	0→ Day  
	--				1→ Years
	---------------------------
	
	
	--declare @DecimalScale as SMALLINT 
	DECLARE @Result AS NUMERIC(18,3)

	--select @DecimalScale=DecimalScale from sysparam
	
		declare @Serv_Formula as NUMERIC(18,3)




	select @Serv_Formula =  CASE @Type	WHEN 0 THEN DATEDIFF(dd,Empassignment.HireDate,@RefDate)  
										WHEN 1 THEN DATEDIFF(dd,isNULL(EmpStatusHdr.EffectiveDate,HireDate),@RefDate)
										WHEN 2 THEN (DATEDIFF(dd,isNULL(EmpStatusHdr.EffectiveDate,HireDate),@RefDate)/(DATEDIFF(dd,Empassignment.HireDate,@RefDate)*1.0))
										WHEN 3 THEN DATEDIFF(dd,isNULL(EmpStatusHdr.EffectiveDate,HireDate),@RefDate) END
	                     FROM Empassignment
						 LEFT join EmpStatusHdr ON EmpStatusHdr.EmpId = EmpAssignment.EmpId 
						   AND empstatushdr.DocumentStatus=1 
						   AND empstatushdr.EffectiveDate =(SELECT TOP 1 esh.effectivedate	FROM empstatushdr esh 
															inner JOIN EmpStatusDtl esd ON esd.EmpId = esh.EmpId AND esd.DocumentNo=esh.DocumentNo AND ( (@Type=3 AND esd.FieldNo IN (5,6)) OR (@Type<>3 AND esd.FieldNo IN (5,6,8))  )
															WHERE esh.empid=empstatushdr.empid ORDER BY esh.EffectiveDate DESC ) 
	WHERE EmpAssignment.EmpId = @EmpId

	
	IF @ReturnType = 1 AND @Type <> 2
	BEGIN
		select @Result = @Serv_Formula/(365.0)											
	END
	ELSE 
	BEGIN
		select @Result = @Serv_Formula
	END

	
	RETURN @Result 

END

GO

