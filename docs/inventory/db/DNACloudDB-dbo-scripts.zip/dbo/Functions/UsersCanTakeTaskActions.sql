CREATE function [dbo].[UsersCanTakeTaskActions] (@empid as int ,@documentno as int,@logonName as nvarchar(88) ,@type as smallint ,@wf AS BIT )
RETURNS   bit
as


BEGIN
	
-- this function will decide if the user is allowed to modify in the occurence button and the checkbox can reassign or not 
--@type =1 can reassign
--@type =2 occurence
--@type =3 to open or close save button in Assignment according to acceptance status in work flow
--@type =4 to open or Close DDl "acceptance status"
--@type =5 Disable Task Name Textbox in case i am not the creator of this task (it is assigned from another Employee who is having this task)
--@type =6 to enable or disable Submit button in Work Flow (change mode) according to DDl "acceptance status"
--@type =7 Display Tasks to be read only for all employees except the employee that task is assigned to 

declare @cantakeaction as bit =1
declare @assignedfrom as int ,@owner as int ,@userid as int ,@acceptancestatus AS SMALLINT ,@taskid AS int 
select @assignedfrom =assignedfrom ,@owner =OWNER,@acceptancestatus=acceptancestatus,@taskid=taskid from emptask where empid=@empid and documentno=@documentno
select @userid =empid from nasusers where logonname=@logonName

-- anyone can change in "Can Reassign" except the Employee if Assign from <>EmpId
if @type=1 AND @wf=1
begin 
	if @empid = @userid AND @assignedfrom<>@empid
		begin 
		  select @cantakeaction=0  -- enabled only when assignForm = profileid
		end 

END
-- anyone can change in "Occurence" except the Employee if Assign from <>EmpId

else if @type=2 AND @wf=1
	begin

	if (@empid = @userid AND @assignedfrom<>@empid ) OR (@wf=1 AND @acceptancestatus  <>1 AND @userid<>@empid)
		begin 
		  select @cantakeaction=0  -- enabled only when assignForm = profileid
		end 

	
	END

else if @type=3 AND @wf=1
	BEGIN 

		if @acceptancestatus  <>1 AND @userid<>@empid
			begin 
			  select @cantakeaction=0  -- enabled  for users only if acceptance status is waiting for response
			end 
	END 	
ELSE IF @type=4 AND @wf=1
BEGIN
	IF (@empid <> @userid) Or ( @empid =  @userid AND  @acceptancestatus <> 1 )
	BEGIN
			select @cantakeaction=0  -- the employee can't change in acceptance status once it is accepted or declined
	END
END
ELSE IF @type=5
BEGIN
	IF exists( SELECT * FROM emptask WHERE empid =@assignedfrom AND taskid =@taskid AND NOT (empid =@empid AND documentno=@documentno) )
	BEGIN
			select @cantakeaction=0  -- Task Name textbox will be disabled 
	END
END
ELSE IF @type=6 AND @wf=1 
BEGIN
	IF @acceptancestatus <> 1  And @empid <> @userid
	BEGIN
			select @cantakeaction=0  -- Submit Buttin will be disabled
	END
END
	
ELSE IF @type=7 
BEGIN
	IF EXISTS (SELECT * FROM emptask WHERE (taskid =@taskid AND AssignedFrom =@empid) AND NOT (Assignedfrom=empid))
	BEGIN
			select @cantakeaction=0  -- Disabled for "Assigned from" once task is assigned to another employee 
	END
END
	 RETURN @cantakeaction
END

GO

