
CREATE FUNCTION [dbo].[EmpVacTakenWithStatus] (@EmpId int, @DocNo int, @Date1 smalldatetime,@Date2 smalldatetime,@VacType as int, @Status nvarchar(MAX)) 
RETURNS numeric(18,3)
AS
BEGIN

/******
 This function returns the number of taken vacations by a given employee of a given vacation type in a certain period, given some vacation status, 
 the function will consider all vacations having these given status only. the function will execlude a given vacation document when calculating, however it will
 consider all vacations if no vacation document is specified.

 Parameters:-
 1- EmpId: The empid of the employee.
 2- DocNo: If specified, the vacation of the specified document number will be execluded from the calculation. if 0, the function will consider all vacations.
 3- Date1: The start date to start calculating the vacations from.
 4- Date2: The end date to end calculating the vacations to.
 5- VacType: The type of vacations to only be considered.
 6- Status: The vacations status to only be considered in the form of string and the status are separated by commas. e.g.: ',1,5,' this will only take into 
			consideration the vacations of status 1 or 5.
******/

  Declare @Taken as numeric (18,3)
  
  SELECT @Date1=CASE WHEN HireDate<@Date1 THEN @Date1 ELSE hiredate END
  FROM EmpAssignment WHERE EmpId=@EmpId
  
  declare @Days numeric(18,3), @StartDate Datetime, @EndDate Datetime
	set @Days = 0.000

	set @StartDate = Case When @Date1 > @Date2 THEN dateadd(dd,1,@Date2) ELSE @Date1 END
	set @EndDate = Case When @Date1 > @Date2 THEN @Date1-1 ELSE @Date2 END

	
	SELECT @Days = (CASE When @Date1 > @Date2 THEN -1 ELSE 1 END) * 
				   SUM(dbo.VacTakenDays(@EmpId, 
	               (case when empvacat.fromdate < @StartDate then @StartDate else empvacat.fromdate end)
	               ,( case when empvacat.todate > @EndDate THEN @EndDate else empvacat.todate END) ,empvacat.vaccode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo)  )
				   
	from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode                         
	               INNER JOIN EmpAssignment ON EmpAssignment.EmpId=empvacat.EmpId
				   Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId 
				   --Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup

	where empvacat.empid=@EmpId  and  @Status like '%' + ','+ltrim(rtrim(empvacat.vacstatus))+',' + '%'  
	                    and (  (empvacat.fromdate between @StartDate and @EndDate) or 
	                   (empvacat.todate between @StartDate and @EndDate) or 
	                   (@StartDate between empvacat.fromdate and empvacat.todate)or 
	                   (@EndDate between empvacat.fromdate and empvacat.todate))
	                    AND(vacation.vactype = @VacType ) AND empvacat.FromDate>=hiredate
						AND empvacat.DocumentNo <> @DocNo

	
  Select @Taken= isnull(@Days,0.000)


  RETURN @Taken

END

GO

