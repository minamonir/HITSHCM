
CREATE  FUNCTION EmpAppraisalAutoScore (@empid as int,@DocumentNo as int )  
RETURNS numeric(18,3)  AS  
begin


--declare @empid As   int ,@documentno As   int 
--set @empid = 108 
--set @documentno = 1

declare InsertRows cursor for 
select   Competence ,PerformaceLevel , RatingLevel  
from EmpAppraisalComp 
where EmpId = @EmpId and DocumentNo=@DocumentNo
declare @Competence As   smallint ,@PerformaceLevel As   smallint ,@RatingLevel As   smallint
declare  @RatingScale as int , @RatingMethod as int , @LevelPercent as  numeric(18,3), @PLevelPercent as  numeric(18,3), @WieghtPercent as  numeric(18,3)
declare  @Score as  numeric(18,3),@count as int , @SWieght as  numeric(18,3) , @PScore as  numeric(18,3)

declare @Appraisalno as int

SELECT     @Appraisalno= Appraisals.Appraisalno , @RatingScale=Appraisals.RatingScale, @RatingMethod = Appraisals.RatingMethod  
FROM Appraisals inner join EmpAppraisal on Appraisals.AppraisalNo=EmpAppraisal.AppraisalNo
WHERE     (EmpAppraisal.EmpId = @EmpId) AND (EmpAppraisal.DocumentNo = @DocumentNo)


select  @count= count(*)
from EmpAppraisalComp 
where EmpId = @EmpId and DocumentNo=@DocumentNo
SELECT @SWieght = sum(isnull(AppraisalCompetencies.Weight,1))  FROM  AppraisalCompetencies where Appraisalno=@Appraisalno  

if @SWieght = 0 set @SWieght = 1 

set @Score = 0

set @PScore = 0

OPEN InsertRows
FETCH NEXT FROM InsertRows INTO  @Competence ,@PerformaceLevel ,@RatingLevel
WHILE @@FETCH_STATUS = 0
 BEGIN
	SELECT @LevelPercent = isnull(LevelPercent,0)   FROM LevelsCompetence where Competence=@Competence and RatingLevel = @RatingLevel
	SELECT @pLevelPercent = isnull(LevelPercent,0)   FROM RatingLevels where 
        RatingScale=@RatingScale and RatingLevel = @PerformaceLevel
	SELECT @WieghtPercent = isnull(AppraisalCompetencies.Weight,1)  FROM  AppraisalCompetencies where Appraisalno=@Appraisalno  and Competence=@Competence
 if @WieghtPercent = 0 set @WieghtPercent = 1

--print @pLevelPercent
if  @RatingMethod = 1
set @Score = @Score+ (@LevelPercent)

if  @RatingMethod = 2
set @Score = @Score+ (@pLevelPercent)

if  @RatingMethod = 3
set @Score = @Score+ (@LevelPercent*(@WieghtPercent/ @SWieght))

if  @RatingMethod = 4
set @Score = @Score+ (@pLevelPercent*(@WieghtPercent/ @SWieght))

if  @RatingMethod = 5
set @Score = @Score+ (@LevelPercent*(@WieghtPercent/ @SWieght))
set @PScore = @PScore+ (@pLevelPercent*(@WieghtPercent/ @SWieght))

--print @score

FETCH NEXT FROM InsertRows INTO  @Competence ,@PerformaceLevel ,@RatingLevel
 End
CLOSE InsertRows
DEALLOCATE InsertRows
--print @count



if @count >=1 set @Score =  @Score / @count
else set @Score =  @Score / 1


if  @RatingMethod = 5  
begin
if @count >=1 set @PScore =  @PScore / @count
else set @PScore =  @PScore / 1
 set @Score =  (@Score+@PScore) / 2

end

set @Score =  round(@Score ,2) 

return  isnull(@Score,0)

end

GO

