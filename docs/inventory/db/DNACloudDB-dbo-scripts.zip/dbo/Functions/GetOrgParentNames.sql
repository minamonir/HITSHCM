
CREATE FUNCTION [dbo].[GetOrgParentNames](@Org int,@lang AS nchar)

RETURNS nvarchar(max) AS  

begin

DECLARE @orgparent  AS int,@desc AS nvarchar(max)
sET @orgparent=@org

SET @desc=N''

WHILE @orgparent IS NOT NULL
begin
SELECT @desc=CASE WHEN @lang=N'e' THEN isnull(rtrim(ltrim(organizationname))+N' \ ',N'') ELSE isnull(rtrim(ltrim(organizationaname))+N' \ ',N'') end+@desc 
,@orgparent=organizationparent
FROM Organizationstructure 
LEFT JOIN organization ON Organizationstructure.Organizationparent = Organization.Organization
WHERE Organizationstructure.Organization=@orgparent



END

SELECT @desc=@desc+Organizationname
FROM Organization 
WHERE Organization=@org

RETURN @desc
end

GO

