
CREATE    FUNCTION [dbo].[HPaycodeAmount] (@Empid Int, @Paycode  smallint, @From  int,@To  int,@Currency smallint)
RETURNS numeric(18,3) AS 
begin

declare @PayCodeamount as numeric(18,3)

SELECT @PayCodeamount=SUM(dbo.ConvertAmount(HistoryTransaction.Amount, HistoryPayroll.PayrollCurrency, @Currency,dbo.periodend(HistoryPayroll.PayrollGroup, HistoryPayroll.Month, HistoryPayroll.Year)) ) 
FROM EmpAssignment 
INNER JOIN HistoryPayroll ON HistoryPayroll.EmpId = EmpAssignment.EmpId 
INNER JOIN HistoryTransaction ON HistoryPayroll.Year = HistoryTransaction.Year 
AND HistoryPayroll.Month = HistoryTransaction.Month  
AND HistoryPayroll.EmpId = HistoryTransaction.EmpId 
AND HistoryPayroll.RunNo = HistoryTransaction.RunNo 
where HistoryTransaction.Paycode =@Paycode and Empassignment.empid=@empid 
and( HistoryPayroll.year*100+HistoryPayroll.Month between case when @from =0 then HistoryPayroll.year*100+HistoryPayroll.Month else  @from end 
and case when @to =0 then HistoryPayroll.year*100+HistoryPayroll.Month else  @to end )


return isnull(@PayCodeamount,0.0)
END

GO

