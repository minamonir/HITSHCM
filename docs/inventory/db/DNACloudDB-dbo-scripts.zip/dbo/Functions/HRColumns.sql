CREATE    Function [dbo].[HRColumns] (@empid As Int, @datefrom As SmallDateTime, @dateto As SmallDateTime,@effectivedate as smalldatetime,@recordstatus as int,@ColumnName As nVarChar(15))
RETURNS smallint AS 

begin

 Declare @returnval As Smallint
  Set @returnval=0

declare @firstHdate as smalldatetime
declare @Hiredate as smalldatetime
declare @termdate as smalldatetime

select @firstHdate=isnull(FirstHiredDate,hiredate),@Hiredate=HireDate ,@termdate=termdate
From EmpAssignment Inner Join Profile On Empassignment.EmpId=Profile.ProfileId Where EmpId=@empid 


if @firstHdate=@Hiredate 
BEGIN 
  if CHARINDEX('Count',@ColumnName)<>0
  Begin
    Select @returnval=Case When (@Hiredate<= @dateto )And (@termdate>= @dateto Or @termdate Is Null) Then 1 Else 0 End 
  End
  if CHARINDEX('Hired', @ColumnName)<>0
  Begin
    Select @returnval=Case When (@Hiredate Between @datefrom And @dateto) Then 1 Else 0 End
  End
  if CHARINDEX('Term', @ColumnName)<>0
  Begin
   if @recordstatus =0 
      begin 
            Select @returnval=Case When (@termdate+1 Between @datefrom And @dateto) Then 1 Else 0 End
      end
   else
      begin
            Select @returnval=Case When (@termdate+1 Between @datefrom And @dateto) and (@termdate not between @datefrom and @dateto) Then 1 Else 0 End
       end
  End


END

else
BEGIN 
  if CHARINDEX('Count',@ColumnName)<>0
  Begin
    Select top 1 @returnval =case when (effectivedate =@datefrom and paystatus=2)or paystatus=1 then 1 
when (@Hiredate<= @dateto )And (@termdate>= @dateto Or @termdate Is Null) Then 1
else 0 end 
	from empstatushdr inner join empstatusdtl on  empstatushdr.empid=empstatusdtl.empid 
	and  empstatushdr.documentno=empstatusdtl.documentno
	inner join Hrstatus on hrstatus.hrstatus=empstatusdtl.newvalue
	where empstatushdr.empid=@empid and effectivedate<=@datefrom and fieldno=1 and EmpStatusHdr.DocumentStatus=1
	order by effectivedate desc
---------------------------------------18-10-2007--------------------------------------------------------------------------------

if @@ROWCOUNT=0 Select @returnval=Case When (@Hiredate<= @dateto )And (@termdate>= @dateto Or @termdate Is Null) Then 1 Else 0 End 
 --
  End

  if CHARINDEX('Hired', @ColumnName)<>0
  Begin
	if (@effectivedate between @datefrom And @dateto) and @recordstatus=1
	 begin
	    select @returnval=count(*)  *-1
	    from empstatushdr inner join empstatusdtl on  empstatushdr.empid=empstatusdtl.empid 
	    and  empstatushdr.documentno=empstatusdtl.documentno
	    inner join Hrstatus NewHR on NewHR.hrstatus=empstatusdtl.NewValue
	    inner join Hrstatus OldHR on OldHR.hrstatus=dbo.GetOldValue(empstatushdr.EmpId,EmpStatusDtl.FieldNo,EmpStatusHdr.EffectiveDate,EmpStatusHdr.HrCurrency)
	    where EmpStatusHdr.DocumentStatus=1 and empstatushdr.empid=@empid 
	    and (effectivedate=@effectivedate)and fieldno=1 and NewHR.paystatus=1 and OldHR.paystatus=2
	   end
	   else if @recordstatus=-1 and (@firstHdate between @datefrom And @dateto)
	   begin
     	     select @returnval=case when @effectivedate=min(effectivedate)then 1 else 0 end from hrhistory  where hrhistory.empid=@empid  
		end
	 else set @returnval=0
---------------------------------------18-10-2007--------------------------------------------------------------------------------
if (select count (*) from empstatushdr inner join empstatusdtl on  empstatushdr.empid=empstatusdtl.empid 
	    and  empstatushdr.documentno=empstatusdtl.documentno
	    where EmpStatusHdr.DocumentStatus=1 and empstatushdr.empid=@empid 
	    and (effectivedate between @datefrom And @dateto))=0 and @recordstatus=0
begin 
  Select @returnval=Case When (@Hiredate Between @datefrom And @dateto) Then 1 Else 0 End
   
end

if @recordstatus=-1 and (@Hiredate between @datefrom And @dateto) and (select count (*) from empstatushdr inner join empstatusdtl on  empstatushdr.empid=empstatusdtl.empid 
	    and  empstatushdr.documentno=empstatusdtl.documentno
	    where EmpStatusHdr.DocumentStatus=1 and empstatushdr.empid=@empid 
	    and (effectivedate between @datefrom And @dateto) and fieldno=1)=0
	   begin
     	     select @returnval=case when @effectivedate=min(effectivedate)then 1 else 0 end from hrhistory  where hrhistory.empid=@empid  and effectivedate >=@hiredate
		end

-------------------------------------------------------------------------------------------------------------------------

  End


  if CHARINDEX('Term', @ColumnName)<>0
  begin
   if @recordstatus=1 and (dateadd(d,1,@effectivedate) between @datefrom And @dateto)
	begin
	 select @returnval=count(*)  *-1
	    from empstatushdr inner join empstatusdtl on  empstatushdr.empid=empstatusdtl.empid 
	    and  empstatushdr.documentno=empstatusdtl.documentno
	    inner join Hrstatus NewHR on NewHR.hrstatus=empstatusdtl.NewValue
	    inner join Hrstatus OldHR on OldHR.hrstatus=dbo.GetOldValue(empstatushdr.EmpId,EmpStatusDtl.FieldNo,EmpStatusHdr.EffectiveDate,EmpStatusHdr.HrCurrency)
	    where EmpStatusHdr.DocumentStatus=1 and empstatushdr.empid=@empid 
	    and (effectivedate=@effectivedate)and fieldno=1 and NewHR.paystatus=2 and OldHR.paystatus=1
	   end
   else set @returnval=0

---------------------------------------18-10-2007--------------------------------------------------------------------------------

if (select count (*) from empstatushdr inner join empstatusdtl on  empstatushdr.empid=empstatusdtl.empid 
	    and  empstatushdr.documentno=empstatusdtl.documentno
	    where EmpStatusHdr.DocumentStatus=1 and empstatushdr.empid=@empid 
	    and (effectivedate between @datefrom And @dateto)and fieldno=1)=0 and @recordstatus=0
begin 

  if @recordstatus =0 
      begin 
            Select @returnval=Case When (@termdate+1 Between @datefrom And @dateto) Then 1 Else 0 End
      end
--   else
--      begin
--            Select @returnval=Case When (@termdate+1 Between @datefrom And @dateto) and (@termdate not between @datefrom and @dateto) Then 1 Else 0 End
--       end
end
  end

-------------------------------------------------------------------------------------------------------------------------



END

if CHARINDEX('YTD', @ColumnName)<>0
  begin
           declare @date as smalldatetime, @start as smalldatetime,@paystatus as smallint,@Chgcount as int,@day as int, @NewPayStatus as smallint
           set @start=case when @datefrom<@firstHdate then @firstHdate else @datefrom end
           set @day=day(@dateto)
            if (@recordstatus=0) --empassignment record
              begin
	         select @Chgcount= count(*) from hrhistory where empid=@empid and effectivedate >=@datefrom
	        select @NewPayStatus= paystatus from empassignment inner join hrstatus on empassignment.hrstatus=hrstatus.hrstatus where empassignment.empid=@empid 
	         if @Chgcount=0 and @NewPayStatus=1 set @returnval=dbo.empmonthscount(@start,@dateto,@day)
              end
           else 
              begin
	         select @Chgcount=count(*) from hrhistory where empid=@empid and effectivedate between @datefrom and @dateto
	          if @ChgCount<>0 
	           begin
	                     select top 1 @date=effectivedate,@paystatus=paystatus from hrhistory inner join hrstatus on hrstatus.hrstatus=hrhistory.hrstatus
                    	      where hrhistory.empid=@empid and hrhistory.effectivedate<=@dateto and recordstatus=1 order by effectivedate desc
	                      if @effectivedate=@date and @recordstatus=1 and @paystatus=1 set @returnval=dbo.empmonthscount(@date,@dateto,@day)
                   	   --     else if @effectivedate=@date and @recordstatus=1 and @paystatus=1 and @effectivedate<@datefrom set @returnval=dbo.empmonthscount(@datefrom,@dateto,@day)
                                 if @recordstatus=-1 and (@effectivedate between @datefrom and @dateto)
                     	           begin
			              select @NewPayStatus=paystatus from hrhistory inner join hrstatus on hrstatus.hrstatus=hrhistory.hrstatus
                                      where hrhistory.empid=@empid and hrhistory.effectivedate=@effectivedate and recordstatus=1
                                      set @date=null
                                      set @paystatus=0
                                      select top 1 @date=effectivedate,@paystatus=paystatus from hrhistory inner join hrstatus on hrstatus.hrstatus=hrhistory.hrstatus
                                      where hrhistory.empid=@empid and hrhistory.effectivedate<@effectivedate and recordstatus=1 order by effectivedate desc
                                      if @paystatus=1 and @NewPayStatus=1 set @returnval=dbo.empmonthscount(case when @date>@start then @Date else @Start end,@effectivedate-1,@day)
			              if @paystatus=1 and @NewPayStatus=2 set @returnval=dbo.empmonthscount(case when @date>@start then @Date else @Start end,@effectivedate,@day)
                                      if @paystatus=0 and @date is null 
			               begin
				        if @NewPayStatus =1 set @returnval=dbo.empmonthscount(@start,@effectivedate-1,@day)
				        else  if @NewPayStatus =2 set @returnval=dbo.empmonthscount(@start,@effectivedate,@day)
			               end
				   end
                        end
	         else --if (select count(*) from hrhistory where empid=@empid and effectivedate > @dateto)<>0
	          Begin 
	                select top 1 @date=effectivedate ,@paystatus=paystatus from hrhistory inner join hrstatus on hrstatus.hrstatus=hrhistory.hrstatus where hrhistory.empid=@empid 
	                and hrhistory.effectivedate>@dateto and hrhistory.recordstatus=-1 order by effectivedate asc
                              if @effectivedate=@date and @recordstatus=-1 and @paystatus=1 and @start<=@dateto set @returnval=dbo.empmonthscount(@start,@dateto,@day)
	         end
           end
  end

return @returnval
end

GO

