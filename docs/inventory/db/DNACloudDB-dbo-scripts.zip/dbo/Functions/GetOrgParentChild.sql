CREATE FUNCTION [dbo].[GetOrgParentChild](@userorgs  as nvarchar(max))
RETURNS nvarchar(max)  AS  
BEGIN 


declare @userorgstr as nvarchar(max)=''
declare @str as nvarchar(max)=''
SELECT @userorgstr=@userorgstr+ ltrim(rtrim(str(max(OrganizationParentOrChild))))+','
        from OrganizationParentChild  
        where  ltrim(rtrim(@userorgs)) like '%#'+ltrim(rtrim(str(organization)))+'#%' 
		--and OrgRelation in (2,3)
        group by OrganizationParentOrChild
--select @userorgstr
		set  @str=case when  @userorgstr<>'' then left(@userorgstr,len( @userorgstr)-1)else  @userorgstr end 

       --select @str

return @str
END

GO

