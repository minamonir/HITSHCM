
CREATE FUNCTION [dbo].[EmpVacBalCalendar] (@empid int, @date2 smalldatetime,@VacType as int) 
RETURNS numeric(18,3)
AS
BEGIN
	--DECLARE @empid int, @date2 smalldatetime,@VacType as INT
	--SELECT @empid=207923,@date2='2009-03-31 00:00:00.000',@VacType=1
 
  Declare @Due numeric(18,3),@Taken as numeric (18,3) , @PrevBal as numeric(18,3), @Balance as numeric(18,3),@date1 as smalldatetime 

  declare @DecimalScale as smallint
  select @DecimalScale=DecimalScale from sysparam
 
  SELECT @date1=CASE WHEN enablehijri=1 AND CYear<1900 THEN 
					 CASE WHEN [DateFormat]=0 then dbo.hijri2greg(STR(cyear,4)+'/01/01')
						  WHEN [DateFormat]=1 then dbo.hijri2greg('01/01/'+STR(cyear,4)) 
						  WHEN [DateFormat]=2 then dbo.hijri2greg('01/01/'+STR(cyear,4))
					 END
  				ELSE STR(cyear,4)+'/01/01' 
                END
  FROM EmpAssignment
  INNER JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
  CROSS JOIN Sysparam
  WHERE EmpAssignment.EmpId=@empid
 
	SELECT	 @Due=dbo.EmpVacDue(@empid,@date1,@date2,@VacType)
			,@PrevBal=dbo.EmpVacBal(@empid,@date1-1,@VacType)
			,@Taken=dbo.EmpVacTaken(@empid,@date1,@date2,@VacType)
	From EmpAssignment
	Where EmpAssignment.EmpId=@empid


--SET  @Balance=round(@PrevBal,2)+round(@Due,2)-round(@Taken,2)
SET  @Balance=round(@PrevBal,@DecimalScale)+round(@Due,@DecimalScale)-round(@Taken,@DecimalScale)

	--SELECT @date1,@date1-1,@date2
	--SELECT @Due,@PrevBal,@Taken
	--SELECT @Balance
	
	RETURN @Balance
END

GO

