
--this fn returns a specific part from a date after converting the date to hijri 

CREATE FUNCTION [dbo].[GetDatePart] (@part as nchar,@date as DateTime)  
RETURNS int  AS  
BEGIN 

declare @HijriDate as nchar(18)
declare @DateFormat as smallint
declare @HijriPart as smallint


 set @HijriPart= null
 if @date is null
   return @HijriPart
 else
 	 begin 
		set @HijriDate =dbo.Greg2Hijri(@date,'E')
  		select @DateFormat=[DateFormat] from dbo.SysParam
   		if @DateFormat =0
     		begin
		      select @HijriPart=
		      case when @part='D' then cast(substring(@HijriDate,9,2) as int)
		       when  @part='M' then cast(substring(@HijriDate,6,2) as int)
		       when  @part='Y' then cast(substring(@HijriDate,1,4) as int)
		       when  @part='Q' then  ceiling(cast(substring(@HijriDate,6,2) as int)/3.0)
		       end
	            end
	            else if @DateFormat =1
	            begin
		      select @HijriPart=
		       case when @part='D' then cast(substring(@HijriDate,1,2) as int)
		       when  @part='M' then cast(substring(@HijriDate,4,2) as int)
		       when  @part='Y' then cast(substring(@HijriDate,7,4) as int)
		       when  @part='Q' then  ceiling(cast(substring(@HijriDate,4,2) as int)/3.0)
		       end
	            end
  	          else if @DateFormat =2
    	         begin
		      select @HijriPart=
		       case when @part='D' then cast(substring(@HijriDate,4,2) as int)
		       when  @part='M' then cast(substring(@HijriDate,1,2) as int)
		       when  @part='Y' then cast(substring(@HijriDate,7,4) as int)
		       when  @part='Q' then  ceiling(cast(substring(@HijriDate,1,2) as int)/3.0)
		       end
	     end
	   end

return @HijriPart

END

GO

