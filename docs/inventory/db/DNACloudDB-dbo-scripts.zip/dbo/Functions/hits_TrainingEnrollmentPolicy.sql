
CREATE FUNCTION [dbo].[hits_TrainingEnrollmentPolicy]
(
	-- Function Parameters
	@EmpId AS INT , @DocumentNo AS INT , @TrainingEvent AS BIGINT , @Lang AS NCHAR(1) 
	
)
RETURNS NVARCHAR(200)
AS
BEGIN
	----------------------------------Variables To Be Used In The Function---------------------------------------------------------------
	DECLARE  @Count AS SMALLINT , @Cost AS NUMERIC(18,3) , @Score AS NUMERIC(9,3) , @reason AS NVARCHAR(200)
	----------------------------------Available Currency-----------------------------------------------------------------------------
	Declare @Currency as smallint --from sysparam-- 
	----------------------------------Variables From TrainingEnrollmentPolicy--------------------------------------------------------    
	Declare @TrainingCount AS BIT , @MinTrainingCount AS INT , @MaxTrainingCount AS INT , @TrainingCountSameAct AS BIT 
	       ,@CountDate AS SMALLDATETIME ,@EventFrom AS SMALLDATETIME ,@TrainingActivity AS SMALLINT
	       ,@CostDate AS SMALLDATETIME,@MaxTotalCost AS NUMERIC(18,3) , @TotalCost AS BIT , @MinTotalCost AS NUMERIC(18,3)
	       ,@TotalCostCurrency AS SMALLINT  , @TotalCostSameAct AS BIT , @EventTo AS SMALLDATETIME , @EnrollmentPolicyAction AS SMALLINT
	       ,@LastTrainingScore AS BIT , @MinLastTrainingScore AS NUMERIC(18,3) ,@EventPrice AS NUMERIC(18,3)
	       ,@LastTrainingScoreSameAct AS BIT ,@MaxLastTrainingScore AS NUMERIC(18,3) , @CountTrainings AS SMALLINT
	       ,@CountDate2 AS SMALLDATETIME , @CostDate2 AS SMALLDATETIME ,@EnrollmentPolicyId AS INT , @EventCurrency AS SMALLINT
	      SET @reason=N'' 
	SELECT @CountDate = CASE WHEN TrainingEnrollmentPolicy.TrainingCountEveryUnit = 1 THEN
		                       DATEADD(dd,(TrainingEnrollmentPolicy.TrainingCountEvery * -1),TrainingEvents.EventFromDate)
		                  WHEN TrainingEnrollmentPolicy.TrainingCountEveryUnit = 2 THEN
		                  	   DATEADD(MM,(TrainingEnrollmentPolicy.TrainingCountEvery * -1),TrainingEvents.EventFromDate)
		                  ELSE DATEADD(yyyy,(TrainingEnrollmentPolicy.TrainingCountEvery * -1),TrainingEvents.EventFromDate)
	                    END -- prepare dates for count
	      ,@CountDate2 = CASE WHEN TrainingEnrollmentPolicy.TrainingCountEveryUnit = 1 THEN
		                       DATEADD(dd,(TrainingEnrollmentPolicy.TrainingCountEvery * 1),TrainingEvents.EventToDate)
		                  WHEN TrainingEnrollmentPolicy.TrainingCountEveryUnit = 2 THEN
		                  	   DATEADD(MM,(TrainingEnrollmentPolicy.TrainingCountEvery * 1),TrainingEvents.EventToDate)
		                  ELSE DATEADD(yyyy,(TrainingEnrollmentPolicy.TrainingCountEvery * 1),TrainingEvents.EventToDate)
	                    END -- prepare dates for count2              
	      ,@CostDate = CASE WHEN TrainingEnrollmentPolicy.TotalCostEveryUnit = 1 THEN
		                       DATEADD(dd,(TrainingEnrollmentPolicy.TotalCostEvery * -1),TrainingEvents.EventFromDate)
		                  WHEN TrainingEnrollmentPolicy.TotalCostEveryUnit = 2 THEN
		                  	   DATEADD(MM,(TrainingEnrollmentPolicy.TotalCostEvery * -1),TrainingEvents.EventFromDate)
		                  ELSE DATEADD(yyyy,(TrainingEnrollmentPolicy.TotalCostEvery * -1),TrainingEvents.EventFromDate)
	                    END -- prepare dates for cost
	      ,@CostDate2 = CASE WHEN TrainingEnrollmentPolicy.TotalCostEveryUnit = 1 THEN
		                       DATEADD(dd,(TrainingEnrollmentPolicy.TotalCostEvery * 1),TrainingEvents.EventToDate)
		                  WHEN TrainingEnrollmentPolicy.TotalCostEveryUnit = 2 THEN
		                  	   DATEADD(MM,(TrainingEnrollmentPolicy.TotalCostEvery * 1),TrainingEvents.EventToDate)
		                  ELSE DATEADD(yyyy,(TrainingEnrollmentPolicy.TotalCostEvery *1),TrainingEvents.EventToDate)
	                    END -- prepare dates for cost
	      ,@TrainingCount = TrainingCount , @MinTrainingCount = MinTrainingCount 
	      ,@MaxTrainingCount = MaxTrainingCount,@TrainingCountSameAct = TrainingCountSameActivity
	      ,@EventFrom = TrainingEvents.EventFromDate , @TrainingActivity = TrainingEvents.TrainingActivity
	      ,@TotalCost = TotalCost ,@TotalCostCurrency = TotalCostCurrency
	      ,@MaxTotalCost = MaxTotalCost , @TotalCostSameAct = TotalCostSameActivity, @MinTotalCost = MinTotalCost
	      ,@LastTrainingScore = LastTrainingScore , @MinLastTrainingScore = MinLastTrainingScore 
	      ,@MaxLastTrainingScore = MaxLastTrainingScore ,@LastTrainingScoreSameAct = LastTrainingScoreSameActivity  
	      ,@EventPrice = TrainingEvents.EventPrice , @EventCurrency = TrainingEvents.PriceCurrency
	      ,@EnrollmentPolicyId = TrainingEvents.EnrollmentPolicyId ,@EventTo = TrainingEvents.EventToDate
	      ,@EnrollmentPolicyAction = TrainingEnrollmentPolicy.EnrollmentPolicyAction
	      
	FROM dbo.TrainingEnrollmentPolicy 
	LEFT JOIN dbo.TrainingEvents ON TrainingEvents.EnrollmentPolicyId = TrainingEnrollmentPolicy.EnrollmentPolicyId
	WHERE dbo.TrainingEvents.TrainingEvent = @TrainingEvent
	---------------------------------If Event Approved----------------------------------------------------------------------------------------

	------------------------------------------------------------------------------------------------------------------------------------------
	---------------------------------Check if it is a restricted event or not-----------------------------------------------------------------
	IF ISNULL(@EnrollmentPolicyId,0) = 0
	
	BEGIN
		SET @reason = '001'
		RETURN @reason
	END
	------------------------------------------------------------------------------------------------------------------------------------------
	---------------------------------Need To Check The Count----------------------------------------------------------------------------------
	  IF @TrainingCount = 1
	    BEGIN  
	    	
	  	     	SELECT @Count = COUNT(EmpTraining.DocumentNo) + 1
	  	   	 	FROM EmpTraining 
	  	   	 	LEFT JOIN dbo.TrainingEvents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
	  	   	 	left join dbo.TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus
	  	   	 	WHERE EmpTraining.EmpId = @EmpId
	  	   	 	     AND EmpTraining.DocumentNo <> ISNULL(@DocumentNo,-1)	  	   	 	                                          
	  	   	 	     AND TrainingEvents.EventToDate > @CountDate 
	  	   	 	     AND TrainingEvents.EventFromDate < @CountDate2
	  	   	 	     AND TrainingEvents.TrainingActivity = CASE WHEN @TrainingCountSameAct = 1 THEN @TrainingActivity
	  	   	 	                                                ELSE TrainingEvents.TrainingActivity
	  	   	 	                                                END
	  	   	 	     AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4)
	  	   	 	     
	  	   	 
	  	   	 	  	IF ((@Count = @MinTrainingCount ) OR (@Count > @MinTrainingCount )) AND (@MaxTrainingCount = 0 OR (@Count < = @MaxTrainingCount ))
	  	   	 	  	BEGIN
	  	   	 	  		SET @reason = '001'
	  	   	 	  		RETURN @reason
	  	   	 	  	END
	  	   	 	    SET @reason = CASE WHEN @EnrollmentPolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('TrainingRestriction','Prevent',@lang))),CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE N'عدم سماح : ' END ) + ' 0021 - ' + isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('TrainingRestriction','MinMaxCount',@lang))),(case when @lang='E' then 'Number of courses you got is not between the max & min ranges' else N'عدد التدريبات الحاصل عليها ليس في الحدود المسموح بها' end)) ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('TrainingRestriction','Warning',@lang))),CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE N'تحذير : ' END) + ' 0022 - ' + isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('TrainingRestriction','MinMaxCount',@lang))),(case when @lang='E' then 'Number of courses you got is not between the max & min ranges' else N'عدد التدريبات الحاصل عليها ليس في الحدود المسموح بها' end)) END 
                    RETURN @reason
	  	   	 	 	   
	    END
	----------------------------------End Of Count Checks-------------------------------------------------------------------------------------
	
	----------------------------------Need To Check The Score---------------------------------------------------------------------------------
	   IF @LastTrainingScore = 1
	     BEGIN
	     	    SELECT top 1 @Score = EmpTraining.TrainingScore , @Count = COUNT(EmpTraining.DocumentNo)
	     	    FROM EmpTraining 
	     	    LEFT JOIN TrainingEvents ON EmpTraining.TrainingEvent = TrainingEvents.TrainingEvent 
	     	    left join dbo.TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus
	     	    WHERE EmpTraining.EmpId = @EmpId
	     	         AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4)
	     	         AND EmpTraining.DocumentNo <> ISNULL(@DocumentNo,-1)
	     	         AND TrainingEvents.EventToDate < @EventFrom
	     	         AND TrainingEvents.TrainingActivity = CASE WHEN @LastTrainingScoreSameAct = 1 THEN @TrainingActivity
	  	   	 	                                                ELSE TrainingEvents.TrainingActivity
	  	   	 	                                                END 
	  	   	 	 GROUP BY TrainingEvents.EventToDate,EmpTraining.TrainingScore                                               
	  	   	 	 order by TrainingEvents.EventToDate desc
 
                SET @Score = ISNULL(@Score,0)
                
                ------@count used here to check if the person has got trainings before or not-------
                IF ISNULL(@Count,0) = 0
	  	   	      BEGIN
	  	   	  	   SET @reason = '001'
	  	   	  	   RETURN @reason
	  	   	      END
	  	   	   
                IF ((@Score = @MinLastTrainingScore ) OR (@Score > @MinLastTrainingScore ))	AND (@MaxLastTrainingScore = 0 OR (@Score < = @MaxLastTrainingScore ))  	  
	  	        BEGIN
	  	        	SET @reason = '001'
	  	        	RETURN @reason
	  	        END
 	  	        SET @reason = CASE WHEN @EnrollmentPolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('TrainingRestriction','Prevent',@lang))),CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE N'عدم سماح : ' END ) + ' 0031 - ' + isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('TrainingRestriction','MinMaxScore',@lang))),(case when @lang='E' then 'Last Training Score is not between the max & min ranges' else N'نتيجة اخر تدريب ليست في الحدود المسموح بها' end))ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('TrainingRestriction','Warning',@lang))),CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE N'تحذير : ' END) + ' 0032 - ' +  isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('TrainingRestriction','MinMaxScore',@lang))),(case when @lang='E' then 'Last Training Score is not between the max & min ranges' else N'نتيجة اخر تدريب ليست في الحدود المسموح بها' end)) END 
	  	   	 	RETURN @reason
                         	    
	     END
	----------------------------------End Of Score Checks-----------------------------------------------------------------------------------
	
	----------------------------------Need To Check Cost------------------------------------------------------------------------------------
	    IF @TotalCost = 1
	     BEGIN
	            ---------------------If do not have courses before-----------------------------
	            SELECT @Count = COUNT(EmpTraining.DocumentNo)
	  	   	 	FROM EmpTraining 
	  	   	 	LEFT JOIN dbo.TrainingEvents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
	  	   	 	left join dbo.TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus
	  	   	 	WHERE EmpTraining.EmpId = @EmpId
	  	   	 	     AND EmpTraining.DocumentNo <> ISNULL(@DocumentNo,-1)	  	   	 	                                          
	  	   	 	     AND TrainingEvents.EventToDate < @EventFrom 
	  	   	 	     AND TrainingEvents.TrainingActivity = CASE WHEN @TotalCostSameAct = 1 THEN @TrainingActivity
	  	   	 	                                                ELSE TrainingEvents.TrainingActivity
	  	   	 	                                                END
	  	   	 	     AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4)
	  	   	 
	  	   	  IF ISNULL(@Count,0) = 0
	  	   	  BEGIN
	  	   	  	SET @reason = '001'
	  	   	  	RETURN @reason
	  	   	  END
	            
	            ---------------------If have courses before------------------------------------
	            If @TotalCostCurrency = null
	              Begin
	                select @Currency = SysParam.syscur
	                from dbo.SysParam
	              End
	     	    SELECT @Cost = SUM(dbo.EmpTrainingCost(EmpTraining.TrainingEvent,@EmpId ,EmpTraining.DocumentNo,NULL,isnull(@TotalCostCurrency,@Currency),0,0,NULL,NULL,NULL))  + dbo.ConvertAmount(@EventPrice,@EventCurrency,isnull(@TotalCostCurrency,@Currency),@EventFrom)
	     	    FROM EmpTraining 
	     	    LEFT JOIN TrainingEvents ON EmpTraining.TrainingEvent = TrainingEvents.TrainingEvent 
	     	    left join dbo.TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus
	     	    WHERE  EmpTraining.DocumentNo <> ISNULL(@DocumentNo,-1)
	     	         AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4)
	     	         AND TrainingEvents.EventToDate > @CostDate 
	  	   	 	     AND TrainingEvents.EventFromDate < @CostDate2
	  	   	 	     AND EmpTraining.EmpId=@EmpId
	  	   	 	     AND TrainingEvents.TrainingActivity = CASE WHEN @TotalCostSameAct = 1 THEN @TrainingActivity
	  	   	 	                                                ELSE TrainingEvents.TrainingActivity
	  	   	 	                                           END
	  	   	 	SET @Cost = ISNULL(@Cost,0)
	  	   	 	                                           
	  	   	 	IF ((@Cost = @MinTotalCost ) OR (@Cost > @MinTotalCost )) AND (@MaxLastTrainingScore = 0 OR (@Cost < = @MaxTotalCost ))
	  	   	 	BEGIN
	  	   	 		SET @reason = '001'
	  	   	 		RETURN @reason
	  	   	 	END
	  	   	 	SET @reason = CASE WHEN @EnrollmentPolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('TrainingRestriction','Prevent',@lang))),CASE WHEN @Lang = 'E' THEN 'Prevent : ' ELSE N'عدم سماح : ' END ) + ' 0041 - ' + isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('TrainingRestriction','MinMaxCost',@lang))),(case when @lang='E' then 'Total cost is not between the max & min ranges' else N' قيمة التدريبات ليست في الحدود المسموح بها' end))  ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('TrainingRestriction','Warning',@lang))),CASE WHEN @Lang = 'E' THEN 'Warning : ' ELSE N'تحذير : ' END) + ' 0042 - ' + isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('TrainingRestriction','MinMaxCost',@lang))),(case when @lang='E' then 'Total cost is not between the max & min ranges' else N'قيمة التدريبات ليست في الحدود المسموح بها' end)) END 
	  	   	    RETURN @reason  	  
	     END
	----------------------------------End Of Cost Checks------------------------------------------------------------------------------------     
	RETURN '001'
	
	END

GO

