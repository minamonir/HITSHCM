CREATE FUNCTION [dbo].[HitsStrWzZeroes](@EmployeeId NVARCHAR(50),@Zeroes SMALLINT)
RETURNS NVARCHAR(50)
AS
BEGIN

SELECT @EmployeeId = CASE WHEN EmployeeidType IN (1,2) THEN ISNULL(@EmployeeId,'')
					 ELSE RIGHT(REPLICATE('0',EmployeeidLength)+ISNULL(@EmployeeId,''),EmployeeidLength) END 
					 FROM SysParam
RETURN @EmployeeId
END

GO

