

CREATE FUNCTION [dbo].[emphiretermdays](@empid as INT,@PeriodStart SMALLDATETIME,@PeriodEnd AS SMALLDATETIME, @TermHiredate AS SMALLDATETIME ,@TYPE AS SMALLINT ,@PeriodEndQS AS SMALLINT)
RETURNS NUMERIC(18,3) 
AS
BEGIN
-- @type=0 hired employees
-- @type=1 Terminated Employees
-- @type=3 Number of Working days

--@PeriodEndQS = 1 date diff between term date and period end
--@PeriodEndQS = 0 30 - day part of term date

DECLARE @CountDayoff AS SMALLINT=0  , @payrollgroup AS SMALLINT
DECLARE @ConsiderDayoff AS BIT =0
DECLARE @noofdays AS NUMERIC(18,3) =0
DECLARE @fromDate AS SMALLDATETIME ,@toDate  AS SMALLDATETIME ,@hijridate AS NCHAR(10)
DECLARE @ConsiderHWorkingPerDay AS BIT =0
SELECT @ConsiderDayoff=CASE WHEN DB_NAME() LIKE '%Cl000121%'  THEN 1 ELSE 0 END 
SELECT @ConsiderHWorkingPerDay=CASE WHEN DB_NAME() LIKE '%CL000155%'  THEN 1 ELSE 0 END 
--UNB (adcb)
IF (SELECT LTRIM(RTRIM(PropName)) FROM SysParam) ='adcb'
BEGIN
	SELECT @noofdays= ((DATEPART(DAY,@PeriodEnd)) - (DATEPART(DAY,@TermHiredate)) + (1) - (CASE WHEN DATEPART(DAY,@PeriodEnd) < 30 THEN DATEPART(DAY,@PeriodEnd) ELSE 30 END))
	RETURN ( CASE WHEN @noofdays>0 THEN 0 ELSE @noofdays END )
END



--top hits

SELECT @payrollgroup = PayrollGroup FROM empassignment WHERE empid =@empid

select @hijridate=case when payrollgroup.cyear<1900 then dbo.Greg2Hijri(@PeriodEnd,'O') else '' end
  from payrollgroup 
 where payrollgroup.payrollgroup=@payrollgroup


----------------Count Day off days -------------------------------------------------------
IF @ConsiderDayoff=1
begin

DECLARE  @dayoff1 AS SMALLINT=0 , @dayoff2 AS SMALLINT =0
SELECT @dayoff1= case when empassignment.payrollgroup in (9,20,37,502,10,12,13,18,19,31,46) then 1 ELSE 0 END  ,@dayoff2= case when empassignment.payrollgroup in (10,12,13,18,19,31,46) then 7 else 0 END 
FROM EmpAssignment WHERE empid=@EmpId

IF @type=0 
BEGIN
SELECT @fromDate =@TermHiredate ,@toDate =@PeriodEnd
END
ELSE IF @type=1
BEGIN

SELECT @fromDate =CASE WHEN @PeriodEndQS=0 THEN CONVERT(DATETIME , LTRIM(RTRIM(STR(YEAR(@PeriodEnd)))) +'/'+ LTRIM(RTRIM(STR(Month(@PeriodEnd))))+'/01') ELSE @PeriodStart END  ,@toDate =@TermHiredate
END
ELSE IF @TYPE =3
BEGIN
	select @fromDate=@TermHiredate, @todate=@PeriodEnd
END

WHILE @fromDate<=@toDate
  BEGIN
	IF DATEPART(dw,@fromDate)=@dayoff1 OR DATEPART(dw,@fromDate)=@dayoff2
	BEGIN
		SET @CountDayoff=@CountDayoff+1
	END
	SET @fromDate=DATEADD(DAY,1,@fromDate)
  END

END 

----------------------Count no of days of new Hired Employees--------------------------------------------------------
IF @type=0
BEGIN
----@TermHiredate as hiredate

IF @ConsiderDayoff =1
BEGIN
	SELECT @noofdays =   DATEDIFF(dd, @TermHiredate, @Periodend)+1 -@CountDayoff
	SELECT @noofdays = @noofdays - CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN 26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN 21.67 ELSE 30 END 
	FROM Empassignment 
	WHERE empid =@empid
	select @noofdays= CASE when @noofdays > 0 THEN 0 ELSE @noofdays END 
	RETURN @noofdays
END

ELSE 
	BEGIN 
		IF (@hijridate <>'')
			BEGIN
			SELECT @noofdays = 31-cast(substring(dbo.Greg2Hijri(@TermHiredate,'O'),9,2) as INT)
		    END
       ELSE
	   BEGIN
	      IF (@TermHiredate < @PeriodStart)
		  BEGIN
		  SELECT @noofdays = 31-datepart(dd,@TermHiredate)
		  END
          ELSE
          BEGIN
		  SELECT @noofdays=DATEDIFF(dd, @TermHiredate, @PeriodStart)
		  End
	       
	   END
    END      
END



----------------------------------------------------------------------------------------------------------------
----------------------Count no of days of Terminated Employees --------------------------------------------------

ELSE IF @type=1
BEGIN
----@TermHiredate as Tirmdate
IF @PeriodEndQS =0
BEGIN
	IF @ConsiderDayoff=1
		BEGIN
			SELECT @PeriodStart =CONVERT(SMALLDATETIME , LTRIM(RTRIM(STR(year(@PeriodEnd))))+'/'+LTRIM(RTRIM(STR(month(@PeriodEnd))))+'/01')
			SELECT @noofdays =   DATEDIFF(dd, @PeriodStart, @TermHiredate)+1 - @CountDayoff
			SELECT @noofdays =  CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN 26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN 21.67 ELSE 30 END - @noofdays 
			FROM Empassignment 
			WHERE empid =@empid
			select @noofdays= CASE when @noofdays < 0 THEN 0 ELSE @noofdays END 
		END
	ELSE 
			BEGIN 
			SELECT @noofdays = 30 -datepart(dd,@TermHiredate)
			END   

end
ELSE IF @PeriodEndQS =1
BEGIN
	 IF @ConsiderDayoff=1
	 BEGIN
			SELECT @noofdays =   DATEDIFF(dd, @PeriodStart, @TermHiredate)+1 - @CountDayoff
			SELECT @noofdays =  CASE WHEN  Payrollgroup IN (37,20,502,9,506) THEN 26  WHEN payrollgroup IN (13,19,10,31,46,12) THEN 21.67 ELSE 30 END - @noofdays 
			FROM Empassignment 
			WHERE empid =@empid
			select @noofdays= CASE when @noofdays < 0 THEN 0 ELSE @noofdays END 
	 END
	 ELSE
	 	BEGIN 
             SELECT @noofdays = DATEDIFF(dd, @TermHiredate, @PeriodEnd)   
        END 
END


	
END 

ELSE IF @TYPE =3
BEGIN
	 SELECT @noofdays = DATEDIFF(dd, @TermHiredate, @PeriodEnd)  +1
	 RETURN @noofdays - @CountDayoff
END
IF @ConsiderHWorkingPerDay=1
BEGIN
DECLARE  @WorkSeconds AS int=0 , @HWorkingPerDay AS int =0 ,@DayHours as smallint = 0
SELECT @WorkSeconds= SUM(WorkSeconds)  ,@HWorkingPerDay= HWorkingPerDay*60*60,@DayHours = TimeRules.timerulecons
FROM dbo.EmpShiftInOut
LEFT JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = EmpShiftInOut.EmpId
LEFT JOIN dbo.TimeRules ON TimeRules.TimeRule = EmpAssignment.TimeRule
LEFT JOIN dbo.EmpGroups ON EmpGroups.EmpId = EmpAssignment.EmpId
WHERE EntryDate  BETWEEN @PeriodStart AND  @PeriodEnd 
				and EmpAssignment.empid=@EmpId 
				AND EmpGroups.GroupNo = 108
				GROUP BY EmpAssignment.EmpId,HWorkingPerDay, TimeRules.timerulecons

select @noofdays=( CASE WHEN @WorkSeconds>=@HWorkingPerDay THEN 0 when @WorkSeconds < @HWorkingPerDay then round((@HWorkingPerDay-@WorkSeconds) / 60.0 / 60.0 /  @DayHours,decimalscale) ELSE @noofdays END )
from sysparam
end
----------------------------------------------------------------------------------------------------------------

RETURN @noofdays   --+(@CountDayoff * CASE WHEN @type=1 THEN 1 ELSE -1 END ) 

END

GO

