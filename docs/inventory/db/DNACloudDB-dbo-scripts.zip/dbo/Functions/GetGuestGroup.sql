CREATE FUNCTION dbo.GetGuestGroup()
	
RETURNS int
AS
	BEGIN
            declare @returnval int
	         select @returnval=usergroup from usergroup where usergroupname='guest'
    	RETURN @returnval
	END

GO

