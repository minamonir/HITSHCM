
Create    FUNCTION [dbo].[EmpAppraisalTotalScore] (@empid as int,@DocumentNo as int )  
RETURNS numeric(18,3)  AS  

 begin

declare @Appraisalno as int,@TotalScore as numeric(18,3),@CompWeight as numeric(18,3),@ObjWeight as numeric(18,3), @ObjDimensionWeight as numeric(18,3),
        @QuesWeight as numeric(18,3),@Proficiency as bit,@Performance as bit,@Objective as BIT , @objectiveDimension AS BIT 

      SELECT     @Appraisalno= Appraisals.Appraisalno ,@CompWeight=Appraisals.CompetenceWeight,@ObjWeight=Appraisals.ObjectiveWeight,@ObjDimensionWeight=Appraisals.DimensionWeight,
                 @QuesWeight=Appraisals.QuestionWeight,@Proficiency=Appraisals.Proficiency,@Performance=Appraisals.Performance,@Objective=Appraisals.Objective,@objectiveDimension=appraisals.ObjectiveDimension
      FROM Appraisals inner join EmpAppraisal on Appraisals.AppraisalNo=EmpAppraisal.AppraisalNo
      WHERE     (EmpAppraisal.EmpId = @EmpId) AND (EmpAppraisal.DocumentNo = @DocumentNo)


--------Comptencies and Objectives
IF( (@Performance=1 OR @Proficiency=1) AND @Objective=1 AND @objectiveDimension=0 )
BEGIN
                  IF (@CompWeight=0 and @ObjWeight=0 AND @QuesWeight=0)
                        begin
                              set @CompWeight=50
                              set @ObjWeight=50
                        END
        SET @ObjDimensionWeight=0
END

--------Objectives
ELSE IF( (@Performance=0 AND @Proficiency=0) AND @Objective=1 AND @objectiveDimension=0)
BEGIN
                  IF (@ObjWeight=0 AND @QuesWeight=0)
                        begin
                              set @ObjWeight=100
                        END
                        
      set @CompWeight=0
      SET @ObjDimensionWeight=0
END

--------Comptencies
ELSE IF( (@Performance=1 OR @Proficiency=1) AND @Objective=0 AND @objectiveDimension=0)
BEGIN
                  IF (@CompWeight=0 AND @QuesWeight=0)
                        begin
                              set @CompWeight=100
                        END
                        
		set @ObjWeight=0
       set @ObjDimensionWeight=0
END


-------objective Dimension-------

ELSE IF( (@Performance=0 and @Proficiency=0) AND @Objective=0 AND @objectiveDimension=1)
BEGIN
                  IF (@ObjDimensionWeight=0 AND @QuesWeight=0)
                        begin
                              set @ObjDimensionWeight=100
                        END
                        
      set @ObjWeight=0
      SET @CompWeight =0
END

--------------Objective and Objective Dimension
ELSE IF( (@Performance=0 and @Proficiency=0) AND @Objective=1 AND @objectiveDimension=1 )
BEGIN
                  IF ( @ObjWeight=0 AND @QuesWeight=0 AND @ObjDimensionWeight=0)
                        begin
                              set @ObjDimensionWeight=50
                              set @ObjWeight=50
                        END
                        
             SET @CompWeight =0
END


 
--------Comptencies and Objective Dimension
ELSE IF( (@Performance=1 OR @Proficiency=1) AND @Objective=0 AND @objectiveDimension=1 )
BEGIN
                  IF (@CompWeight=0 and @ObjDimensionWeight=0 AND @QuesWeight=0)
                        begin
                              set @CompWeight=50
                              set @ObjDimensionWeight=50
                        END
                        
                    set @ObjWeight=0
END      

 
--------Comptencies and Objective and Objective Dimension
ELSE IF( (@Performance=1 OR @Proficiency=1) AND @Objective=1 AND @objectiveDimension=1 )
BEGIN
                  IF (@CompWeight=0 AND @ObjWeight=0 and @ObjDimensionWeight=0 AND @QuesWeight=0)
                        begin
                              set @CompWeight=33.333
                              SET @ObjWeight=33.333
                              set @ObjDimensionWeight=33.333
                        END
END  
            
--select @TotalScore=((AutoCompetenceResult*@CompWeight)
--+(AutoObjectiveResult*@ObjWeight)
--+(AutoQuestionResult*@QuesWeight))/
--(case when (@CompWeight+@ObjWeight+@QuesWeight)=0 then 1 else (@CompWeight+@ObjWeight+@QuesWeight) END)

----(@CompWeight+@ObjWeight+@QuesWeight)  
--from dbo.EmpAppraisal where EmpId= @empid and DocumentNo=@DocumentNo
	
	
	select @TotalScore=(((CASE WHEN @CompWeight=0 THEN 0 ELSE AutoCompetenceResult END) *@CompWeight)
+(CASE WHEN @ObjWeight=0 THEN 0 ELSE AutoObjectiveResult END *@ObjWeight)
+(CASE WHEN @ObjDimensionWeight=0 THEN 0 ELSE AutoObjectiveDimensionResult END *@ObjDimensionWeight)
+(CASE WHEN @QuesWeight=0 THEN 0 ELSE AutoQuestionResult END*@QuesWeight))/
(case when (@CompWeight+@ObjWeight+@ObjDimensionWeight+@QuesWeight)=0 then 1 else (@CompWeight+@ObjWeight+@ObjDimensionWeight+@QuesWeight) END)

--(@CompWeight+@ObjWeight+@QuesWeight)  
from dbo.EmpAppraisal where EmpId= @empid and DocumentNo=@DocumentNo
	

	
	return isnull(@totalscore,0)
 END

GO

