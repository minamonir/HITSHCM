CREATE FUNCTION [dbo].[GetRatingLevelName](@RatingScale AS INT, @LevelPercent AS NUMERIC(18, 3), @Lang AS NCHAR(1))
RETURNS NCHAR(20)
AS
BEGIN
	DECLARE
	@lowlevel		 AS NUMERIC(18, 3)
   ,@Highlevel		 AS NUMERIC(18, 3)
   ,@ratinglevelName AS NCHAR(20)
   ,@lowpercent		 AS NUMERIC(18, 3)
   ,@Highpercent	 AS NUMERIC(18, 3)
   ,@RatingLevel	 AS NUMERIC(18, 3)
	IF @RatingScale IS NULL OR	@LevelPercent <= 0 SET @ratinglevelName = N''
	ELSE
	BEGIN
		SELECT TOP 1 @lowlevel	= RatingLevel ,@lowpercent = LevelPercent FROM	RatingLevels WHERE	RatingScale = @RatingScale ORDER BY LevelPercent
		SELECT TOP 1 @Highlevel	 = RatingLevel ,@Highpercent = LevelPercent FROM	RatingLevels WHERE	RatingScale = @RatingScale ORDER BY LevelPercent DESC
		SELECT TOP 1	@RatingLevel = RatingLevel FROM	RatingLevels WHERE	RatingScale = @RatingScale AND	LevelPercent <= @LevelPercent ORDER BY LevelPercent DESC
		IF @LevelPercent < @lowpercent  SET @RatingLevel = @lowlevel
		IF @LevelPercent > @Highpercent SET @RatingLevel = @Highlevel
		SELECT	@ratinglevelName = CASE WHEN @Lang = 'A' THEN RatingLevels.LevelAName ELSE RatingLevels.LevelName END
		FROM	RatingLevels
		WHERE	RatingScale = @RatingScale AND	RatingLevel = @RatingLevel
	END
	RETURN ISNULL(@ratinglevelName, '')
END

GO

