CREATE FUNCTION empValidVaccode
(
	@empid int,@AttendDate DATETIME,@vaccode smallint,@type smallint
)
RETURNS smallint
AS
--214416,'2018-01-11',18,1
--declare @empid int=214416,@AttendDate DATETIME='2018-01-11',@vaccode smallint=18,@type smallint=1
BEGIN
	-- Declare the return variable here
	DECLARE @isvalid AS smallint=0
	declare @excludeVaccodes as nvarchar(1000)=''

select @excludeVaccodes=@excludeVaccodes+','+ltrim(rtrim(str(vaccode)))  from Vacation where vaccodecons in (2)
set @excludeVaccodes=case when @excludeVaccodes<>'' then @excludeVaccodes+',' else @excludeVaccodes end
--select @excludeVaccodes
	select @isvalid=1 
    from  empvacat
	where empid = @empid  and @AttendDate between fromdate and todate and VacStatus=1
	 and @excludeVaccodes like '%,'+ltrim(rtrim(str(vaccode)))+',%'and  EmpVacat.vaccode=@VacCode

--	 print @excludeVaccodes
	
	RETURN isnull(@isvalid,0)

--select isnull(@isvalid,0)
END

GO

