

CREATE   FUNCTION [dbo].[GetEmployeeZone]
	(@ProfileId int, @Paycode smallint, @ZoneDate smalldatetime)

RETURNS nchar(10)
AS
BEGIN

declare @Grade as smallint, @amount as numeric(18,3), @EffectiveDate as smalldatetime, @ReturnZone as nchar(10)

select @EffectiveDate=dateadd(dd,1,convert(smalldatetime,convert(nchar(10),@ZoneDate,101),101))

select @Grade=dbo.GetOldValue(empid, 7, @EffectiveDate, hrcurrency),
  @amount=dbo.GetOldValue(empid, case when @Paycode=100 then 14 else @Paycode+1000 end, @EffectiveDate, hrcurrency)
from empassignment where empid=@ProfileId

select @ZoneDate=max(startdate) from GradeZone 
 where grade=@grade and paycode=@Paycode and startdate<@EffectiveDate

select @ReturnZone=zone from GradeZone inner join empassignment on empassignment.empid=@profileid 
where GradeZone.grade=@grade and GradeZone.paycode=@Paycode and startdate=@ZoneDate 
and dbo.convertamount(@amount,empassignment.hrcurrency,ZoneCurrency,dateadd(dd,-1,@EffectiveDate)) between MinAmount and MaxAmount
--select case when @Paycode=100 then hrbasicsal else 
if @ReturnZone is null
begin
  select top 1 @ReturnZone=case when dbo.convertamount(@amount,empassignment.hrcurrency,ZoneCurrency,dateadd(dd,-1,@EffectiveDate))< MinAmount then zone else null end
    from GradeZone inner join empassignment on empassignment.empid=@profileid
    where GradeZone.grade=@grade and GradeZone.paycode=@Paycode and startdate=@ZoneDate 
    order by minamount 
  if @ReturnZone is null
  begin
   select top 1 @ReturnZone=case when dbo.convertamount(@amount,empassignment.hrcurrency,ZoneCurrency,dateadd(dd,-1,@EffectiveDate))>MaxAmount then zone else null end
    from GradeZone inner join empassignment on empassignment.empid=@profileid
    where GradeZone.grade=@grade and GradeZone.paycode=@Paycode and startdate=@ZoneDate 
    order by maxamount desc
  end
end
RETURN isnull(@ReturnZone,N'')
END

GO

