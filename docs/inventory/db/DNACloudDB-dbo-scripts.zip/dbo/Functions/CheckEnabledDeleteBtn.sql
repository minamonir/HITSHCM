CREATE  FUNCTION [dbo].[CheckEnabledDeleteBtn](@Profileid AS INT, @ReportNo AS INT)
RETURNS SMALLINT   
AS
BEGIN
	DECLARE @Returnval AS SMALLINT = 0 
	IF @ReportNo >= 5000 AND EXISTS (SELECT * FROM ReportsBGRdl WHERE Createby = @Profileid AND ReportNo = @ReportNo)
    SET @Returnval = 1
		
RETURN @Returnval 
END

GO

