

CREATE   FUNCTION [dbo].[GetZoneAmount]
	(@Grade smallint, @Paycode smallint, @ZoneDate smalldatetime, @AmountType smallint, @Currency  smallint)

RETURNS  numeric(18,3)
AS
BEGIN
--@AmountType=1 min, 2 mid, 3 max
declare  @amount as numeric(18,3), @EffectiveDate as smalldatetime

select @EffectiveDate=convert(smalldatetime,convert(nchar(10),@ZoneDate,101),101)

select @ZoneDate=max(startdate) from GradeZone 
 where grade=@grade and paycode=@Paycode and startdate<=@EffectiveDate

if @AmountType=1 select @amount=min(dbo.convertamount(MinAmount,ZoneCurrency,@Currency,@EffectiveDate)) 
          from  GradeZone where GradeZone.grade=@grade and GradeZone.paycode=@Paycode and startdate=@ZoneDate 
if @AmountType=2 select @amount=max(dbo.convertamount(MidAmount,ZoneCurrency,@Currency,@EffectiveDate)) 
          from  GradeZone where GradeZone.grade=@grade and GradeZone.paycode=@Paycode and startdate=@ZoneDate 
if @AmountType=3 select @amount=max(dbo.convertamount(MaxAmount,ZoneCurrency,@Currency,@EffectiveDate)) 
          from  GradeZone where GradeZone.grade=@grade and GradeZone.paycode=@Paycode and startdate=@ZoneDate 

RETURN isnull(@amount,0)
END

GO

