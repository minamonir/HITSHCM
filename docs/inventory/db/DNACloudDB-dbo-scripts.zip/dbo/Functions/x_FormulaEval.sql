CREATE FUNCTION [dbo].[x_FormulaEval]
(@FormulaTxt NVARCHAR (MAX) NULL, @FromTxt NVARCHAR (MAX) NULL)
RETURNS FLOAT (53)
AS
 EXTERNAL NAME [HITS_SQLCLR].[HITS_SQLCLR.FormulaFunctions].[EvaluateFormula]


GO

