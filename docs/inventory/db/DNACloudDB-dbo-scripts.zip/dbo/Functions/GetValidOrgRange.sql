CREATE   Function [dbo].[GetValidOrgRange](@OrgNo smallint , @EmployeeId nvarchar(50) ='0')
Returns Bit 
Begin

  Declare @EmployeeIdFrom nchar(50) , @EmployeeIdTo nchar(50) , @EmployeeIdCount nvarchar(50)

  Select @EmployeeIdFrom=EmployeeIdFrom,@EmployeeIdTo=EmployeeIdTo,@EmployeeIdCount =Empidcnt
  From OrganizationSysParam Where Organization=@OrgNo

   ------Manual check Employeeid within org range
 If(@EmployeeId != '0')
   Begin
	  If dbo.CompareTwoStrings(@EmployeeId,@EmployeeIdFrom) IN(1,2) 
	  AND dbo.CompareTwoStrings(@EmployeeIdTo,@EmployeeId) IN(1,2) 
			     Return 1
            ELSE 
			     Return 0
   End
   ----------------------------------------- 
   ------Auto check Empcount < EmpTo
 If(@EmployeeId = '0')
   Begin	          
			If --dbo.CompareTwoStrings(@EmployeeIdCount,@EmployeeIdFrom) IN (1,2) AND
			 dbo.CompareTwoStrings(@EmployeeIdTo,@EmployeeIdCount) IN (1)
			     Return 1
            ELSE 
			     Return 0	
    End

       Return 0;
End

GO

