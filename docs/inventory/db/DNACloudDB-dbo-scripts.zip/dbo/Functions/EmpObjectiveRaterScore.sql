
CREATE  FUNCTION [dbo].[EmpObjectiveRaterScore] (@empid as int,@DocumentNo as int ,@RaterProfileid as int)  
RETURNS numeric(18,3)  AS  
begin



/*declare @empid As   int ,@documentno As   int 
set @empid = 4013 
set @documentno =2*/


declare  @Score as  numeric(18,3),@totalobjectiveweight numeric(18,3)
set @totalobjectiveweight=0

declare @RaterScore table(RaterProfileId int,score numeric (18,3))

DECLARE @objectivedimension AS BIT =0
SELECT @objectivedimension =Appraisals.ObjectiveDimension 
FROM empappraisalobj 
INNER JOIN empappraisal ON empappraisal.EmpId = empappraisalobj.EmpId AND empappraisal.DocumentNo = empappraisalobj.DocumentNo
INNER JOIN appraisals ON appraisals.AppraisalNo = empappraisal.AppraisalNo
WHERE empappraisal.EmpId=@empid AND EmpAppraisal.DocumentNo = @DocumentNo

select  top 1   @totalobjectiveweight=sum(EmpObjectives.ObjectiveWeight) 
FROM EmpAppraisalObj 
LEFT JOIN EmpObjectives ON EmpAppraisalObj.ObjectiveId = EmpObjectives.ObjectiveId 
AND EmpAppraisalObj.EmpId = EmpObjectives.EmpId
where  EmpAppraisalObj.EmpId=@empid AND EmpAppraisalObj.DocumentNo=@documentno
 and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
group by RaterProfileId

insert into @RaterScore
SELECT   EmpAppraisalObj.RaterProfileId, 
SUM( EmpAppraisalObj.EvaluationPercent* (case when @totalobjectiveweight=0 then 1 else EmpObjectives.ObjectiveWeight end))/case when @totalobjectiveweight=0 then 1 else @totalobjectiveweight end
FROM EmpAppraisalObj 
LEFT JOIN EmpObjectives ON EmpAppraisalObj.ObjectiveId = EmpObjectives.ObjectiveId 
AND EmpAppraisalObj.EmpId = EmpObjectives.EmpId
where  EmpAppraisalObj.EmpId=@empid AND EmpAppraisalObj.DocumentNo=@documentno and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
group by EmpAppraisalObj.RaterProfileId

--select * from @RaterScore

select  @Score =  avg(score) from @RaterScore





IF @objectivedimension =1
begin

DECLARE @APRatingScale AS SMALLINT =0
SELECT @APRatingScale = configvalue FROM SysParamConfig WHERE ConfigID ='APRatingScale'


select @score=((((@Score - AP.LevelPercent )           /  @totalobjectiveweight  ) / ((APPrev.LevelPercent -            AP.LevelPercent )/ 100  )     )        * (RatingLevelsPrev.levelpercent- RatingLevels.LevelPercent) )+RatingLevels.LevelPercent 
FROM EmpAppraisal
LEFT JOIN Appraisals ON Appraisals.AppraisalNo = EmpAppraisal.AppraisalNo
LEFT JOIN RatingLevels ON RatingLevels.RatingScale = Appraisals.RatingScale AND RatingLevels.RatingLevel = dbo.GetRatingLevelCode(@APRatingScale,@Score)
LEFT JOIN RatingLevels as RatingLevelsPrev  ON RatingLevelsPrev.RatingScale = Appraisals.RatingScale AND RatingLevelsPrev.LevelOrder = RatingLevels.LevelOrder+1
  LEFT JOIN RatingLevels AP ON AP.RatingScale = @APRatingScale AND AP.LevelOrder = RatingLevels.LevelOrder
    LEFT JOIN RatingLevels APPrev ON APPrev.RatingScale = @APRatingScale AND APPrev.LevelOrder =AP.LevelOrder+1
WHERE EmpAppraisal.EmpId =@empid AND EmpAppraisal.DocumentNo=@DocumentNo
  
  

END
return     isnull(@Score,0)

END

GO

