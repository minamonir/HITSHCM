CREATE FUNCTION [dbo].[IsOrgParent](@org int,@parent INT)   
RETURNS BIT AS  
BEGIN

DECLARE @NextString NVARCHAR(40)
DECLARE @Pos INT
DECLARE @NextPos INT
DECLARE @String NVARCHAR(max)
DECLARE @Delimiter NVARCHAR(40)
DECLARE @IsParent BIT
SET @Isparent=0
select @String=dbo.GetOrgParentCodes(@org)


SET @Delimiter = N'\'
SET @String = @String + @Delimiter
SET @Pos = charindex(@Delimiter,@String)
WHILE (@pos <> 0)
BEGIN
	SET @NextString = substring(@String,1,@Pos - 1)

	IF @parent= @NextString 
	BEGIN
		SET @Isparent=1
		BREAK
	END
		SET @String = substring(@String,@pos+1,len(@String))
		SET @pos = charindex(@Delimiter,@String)
END 
RETURN @IsParent
END

GO

