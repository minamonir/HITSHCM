CREATE FUNCTION [dbo].[GetCompleteOrgParents](@Org INT, @lang AS NCHAR)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @desc AS NVARCHAR(MAX)=''
	SELECT	@desc = CASE WHEN @lang = N'e' THEN ISNULL(RTRIM(LTRIM(OrganizationName)) + N' \ ', N'') ELSE ISNULL(RTRIM(LTRIM(OrganizationAName)) + N' \ ', N'')END + @desc
	FROM OrganizationParentChild
	LEFT JOIN Organization ON OrganizationParentChild.OrganizationParentOrChild = Organization.Organization
	WHERE OrganizationParentChild.OrgRelation IN (1, 2) AND OrganizationParentChild.organization = @Org
	ORDER BY Organization.OrganizationType DESC
	
	SELECT @desc = CASE WHEN LEN(@desc) = 0 THEN @desc ELSE LEFT(@desc, LEN(@desc) - 1) END
	RETURN @desc
END

GO

