
CREATE FUNCTION [dbo].[V_periodend]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS


--update PayrollGroup set vday=10,vmonth=7,mstartfrst=0
--select * from payrollgroup
--DECLARE @payrollgroup INT=1,@period INT=0,@year INT=0

--DECLARE @payrollgroup INT=1,@period INT=26,@year INT=0
BEGIN
  declare @thedate smalldatetime
  declare @dateformat smallint
  declare @enablehijri as bit
  declare @hijridate as nchar(10)
  declare @mstartfirst bit
  declare @VSDay SMALLINT
  declare @VSMonth as SMALLINT
  


--  if @year=0  select @year=cyear, @period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
   if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
   if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
  
 --   ---------------------------------------------------------------------

 

        select @dateformat=dateformat,  @enablehijri=enablehijri from sysparam
        select @mstartfirst=case when vsday=1 then 1 else 0 end ,@VSDay=vsday ,@VSMonth=VsMonth from payrollgroup where payrollgroup = @payrollgroup
     -- advance the period by 1 to get next period start   
   
   if (@VSDay=0 or @VSMonth=0)
   begin
   set @thedate=dbo.periodend(@payrollgroup,@period,@year)
   end

   else
   begin

    if @period=12 
                begin
                   set @period=1 
                   set @year=@year+1 
               end      else set @period= @period+1
       
       if @enablehijri=1 and @year<1900
          begin
             if (@mstartfirst = 1 or @VSDay = 0 )    
                    set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(@period,2,1)+'/01'
                            when @dateformat=1 then '01/'+str(@period,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(@period,2,1)+'/01/'+str(@year,4,1) end
              else if  (@period=1)   
                              set @hijridate= CASE when @dateformat=0 then str(@year-1,4,1)+'/12/'+str(@VSDay,2,1)
                             when @dateformat=1 then str(@VSDay,2,1)+'/12/'+str(@year-1,4,1)
                                 when @dateformat=2 then '12/'+str(@VSDay,2,1)+'/'+str(@year-1,4,1) end
      
                    else set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(@period-1,2,1)+'/'+str(@VSDay,2,1)
                             when @dateformat=1 then str(@VSDay,2,1)+'/'+str(@period-1,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(@period-1,2,1)+'/'+str(@VSDay,2,1)+'/'+str(@year,4,1) end
               select  @thedate=dbo.hijri2greg(@hijridate)
           end
       else
          begin          
               if (@mstartfirst = 1 or @VSDay = 0 )  set  @thedate= convert(smalldatetime,'01/'+str(@period,2,1)+'/'+str(@year,4,1),103)
                else   if  (@period=1)   set @thedate= convert(smalldatetime,str(@VSDay,2,1)+'/'+str(12,2,1)+'/'+str(@year-1,4,1),103) 
		else    set @thedate= convert(smalldatetime,str(@VSDay,2,1)+'/'+str(@period-1,2,1)+'/'+str(@year,4,1),103)
         end
       --deduct 1 from next period start to have the end of period  
       set  @thedate=dateadd(dd,-1,@thedate)

	   end


--RETURN @thedate

return  @thedate

END

GO

