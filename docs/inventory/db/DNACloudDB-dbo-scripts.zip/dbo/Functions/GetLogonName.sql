CREATE FUNCTION [dbo].[GetLogonName]
  (@logonnametype smallint, @empid int, @username nchar(80))
RETURNS  nchar(80)
as
BEGIN 
  declare @returnname as nvarchar(80)
  if @logonnametype=1  select @returnname=CompanyEmail from profile where ProfileId=@empid
  if @logonnametype=2  set @returnname=ltrim(str(@empid))
  if @logonnametype=3  set @returnname=@username
  return @returnname
END

GO

