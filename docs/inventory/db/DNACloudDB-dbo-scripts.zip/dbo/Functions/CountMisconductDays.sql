CREATE FUNCTION [dbo].[CountMisconductDays] (@EmpId INT , @StartDate SMALLDATETIME , @EndDate SMALLDATETIME , @ConsiderModification BIT , @Type SMALLINT  )
RETURNS NUMERIC (18,3)
AS 
BEGIN 	
	--This Function Count Msconduct Days in certain Period Based on @StartDate  and  @EndDate
	
  -- if @Type =1 it will calculate from 1/7   to 30 /6 where @StartDate exists between it in this case we will pass @StartDate  and  @EndDate by the apprisaldate, used in GOV
  DECLARE @days AS NUMERIC (18,3)=0.000
  
	IF @type =1
	 BEGIN
	 	SELECT @StartDate= CASE WHEN MONTH (@StartDate) <7 THEN ltrim(rtrim(str(YEAR (@StartDate)-1)))+'/07/01' ELSE ltrim(rtrim(str(YEAR (@StartDate))))+'/07/01' END 
	 	SELECT @EndDate= CASE WHEN MONTH (@StartDate) <7 THEN ltrim(rtrim(str(YEAR (@StartDate)))) +'/06/30' ELSE ltrim(rtrim(str(YEAR (@StartDate)+1)))+'/06/30' END
	 END
	
   		IF @ConsiderModification =0
	     BEGIN 
		    SELECT @days =SUM(empmscon.fineamnt) 
		                  FROM EmpMscon 
		                   WHERE EmpMscon.empid =@empid AND EmpMscon.misstatus=1 
		                   AND empmscon.misaction =2 AND empmscon.finetype <>1
		                   AND empmscon.misdate BETWEEN @StartDate AND @EndDate 
	     END 
	    ELSE 
	    BEGIN
	    	--EmpMsconModifications.MisModType =0 "محو "
	    	
	    	SELECT @days =SUM(CASE WHEN EmpMsconModifications.empid IS NOT NULL then 
	    		                 CASE when (EmpMsconModifications.misaction=2 and EmpMsconModifications.finetype <>1 ) AND EmpMsconModifications.MisModType <>0 THEN EmpMsconModifications.fineamnt ELSE 0 END 
	    	                   ELSE 
	    	                      CASE WHEN  EmpMscon.misaction =2 AND EmpMscon.finetype <>1 then EmpMscon.fineamnt ELSE 0 END 
	    	                    END )
	    	              FROM EmpMscon 
	    	              LEFT JOIN EmpMsconModifications ON EmpMsconModifications.EmpId = EmpMscon.EmpId AND EmpMsconModifications.DocumentNo = EmpMscon.DocumentNo
	    	              AND EmpMsconModifications.MisModStatus=1  
	    	              AND EmpMsconModifications.MisModDate = (SELECT MAX(emm.MisModDate) 
	    	                                                      FROM EmpMsconModifications emm 
	    	                                                      WHERE emm.empid =EmpMsconModifications.empid AND emm.documentno =EmpMsconModifications.DocumentNo 
	    	                                                      AND emm.MisModStatus=1)
	    	              WHERE EmpMscon.empid =@empid AND EmpMscon.misstatus=1 
		                   AND empmscon.misdate BETWEEN @StartDate AND @EndDate 
	    END

	RETURN @days
END

GO

