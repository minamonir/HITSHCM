CREATE FUNCTION [dbo].[ISValidBIReport](@SharedBY AS NVARCHAR(80),@ReportNo AS NVARCHAR(250),@SharedTo AS NVARCHAR(80),@UserGroup AS BIT)
RETURNS INT
AS
BEGIN
	DECLARE @ISValid AS INT=0
	--DECLARE @SharedToUserGroup AS SMALLINT
	DECLARE @AllUserGroups AS NVARCHAR(MAX)=''
	IF @UserGroup=0
	BEGIN
		--SELECT @SharedToUserGroup= usergroup FROM NasUsers WHERE LogonName=@SharedTo
		SELECT @AllUserGroups = NasUsers.OtherUserGroups+'#'+LTRIM(NasUsers.UserGroup)+'#' FROM NasUsers WHERE LogonName=@SharedTo
	END
	ELSE
	BEGIN
		--SELECT @SharedToUserGroup=cast(@SharedTo AS INT)
		SELECT @AllUserGroups=@SharedTo
	END
	IF EXISTS(SELECT * FROM NasUsersBIReports WHERE BIReport=@ReportNo AND LogonName=@SharedTo AND SharedStatus=1 AND CanShare=1 AND sharetype=0 AND (@UserGroup=0 AND Sharedby<> @SharedBY ))
	OR EXISTS(SELECT * FROM UserGroupBIReportsBySharing WHERE BIReport=@ReportNo AND UserGroup /*=@SharedToUserGroup*/ IN (SELECT ALLUG.value FROM dbo.HitsStringSplit(@AllUserGroups,'#') AS ALLUG) AND SharedStatus=1 AND CanShare=1  AND ((Sharedby<> @SharedBY AND @UserGroup<>0) OR (@UserGroup=0 AND  Sharedby<> @SharedTo) ) )
	BEGIN
		SET @ISValid=1
	END
	ELSE
	BEGIN
		SET @ISValid=0
	END
	RETURN @ISValid
END

GO

