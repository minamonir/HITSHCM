
CREATE FUNCTION [dbo].[EmpBenefitCreditDebitQTY](@empid as int,@documentno as smallint,@PlanNo as smallint,@StartActivityDate as smalldatetime,@EndActivityDate as smalldatetime,@type as smallint)   
RETURNS numeric (18,3) AS  
--This fn calculate the credit/debit QTY at a specific date for a certain benefit plan

--type=1 debit
--type=2 credit
BEGIN 

declare @TotalQTY as numeric(18,3)


select @TotalQTY=sum(case when BenefitItems.Debitorcredit=@type THEN EmpBenefitItems.ActivityQty else 0 end)
from EmpBenefit
LEFT JOIN EmpBenefitItems ON EmpBenefit.EmpId = EmpBenefitItems.EmpId
 AND EmpBenefit.DocumentNo = EmpBenefitItems.DocumentNo 
LEFT JOIN BenefitItems ON EmpBenefitItems.ItemNo = BenefitItems.ItemNo 
where EmpBenefit.empid=@empid and  EmpBenefit.DocumentNo=@documentno and (EmpBenefitItems.Activitydate between @StartActivityDate and @EndActivityDate) and EmpBenefit.planno=@PlanNo

return isnull(@TotalQTY,0)
END

GO

