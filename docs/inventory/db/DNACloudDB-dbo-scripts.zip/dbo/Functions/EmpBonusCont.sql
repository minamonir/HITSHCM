--USE [DNACloudDB]
--GO
--/****** Object:  UserDefinedFunction [dbo].[EmpBonusCont]    Script Date: 28-Jan-19 9:07:31 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

CREATE FUNCTION [dbo].[EmpBonusCont](@empid as integer,@documentno as integer)
RETURNS numeric(18,3) 
AS
--declare @empid as integer=202738,@documentno as integer=23
BEGIN
declare @bonous as numeric(18,3) 
set @bonous=0.0
DECLARE @custom AS NVARCHAR(20)=''
  	SELECT @custom =configvalue FROM sysparamconfig WHERE ConfigID='ObjectiveCalculation'
  	IF @custom =1
  		BEGIN
  		 SELECT @bonous= AutoObjectiveResult FROM EmpAppraisal WHERE EmpId=@empid AND DocumentNo=@documentno
  		
  		END
  		
  	ELSE 
  		BEGIN 	
SELECT @bonous=@bonous+
--SELECT Objectives.objectivename,EmpObjectives.ObjectiveWeight , MaxAmount,MinAmount,midamount, Avg(EmpAppraisalObj.EvaluationValue),
--CASE WHEN  (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount = 0
--            THEN 0
--     WHEN  (ObjectiveMax - ObjectiveTarget) = 0 
--	        THEN 0
--     WHEN  Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveThreshold AND ObjectiveMax > ObjectiveThreshold
--            THEN 0 
--     WHEN  Avg(EmpAppraisalObj.EvaluationValue) = ObjectiveThreshold AND ObjectiveMax > ObjectiveThreshold
--            THEN ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveThreshold ) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--     WHEN  Avg(EmpAppraisalObj.EvaluationValue) <= ObjectiveTarget AND ObjectiveMax > ObjectiveThreshold
--            THEN --( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveThreshold) / (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--			       ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveTarget ) * EmpObjectives.ObjectiveWeight * MidAmount / 100
--     WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveTarget AND Avg(EmpAppraisalObj.EvaluationValue) <=ObjectiveMax AND ObjectiveMax > ObjectiveThreshold
--            THEN --(( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--			       ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveMax ) * (EmpObjectives.ObjectiveWeight * MaxAmount / 100)
--      WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveMax AND ObjectiveMax > ObjectiveThreshold
--            THEN --((ObjectiveMax - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--			        EmpObjectives.ObjectiveWeight * MaxAmount / 100
--      WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveThreshold AND ObjectiveMax < ObjectiveThreshold
--            THEN 0 
--      WHEN  Avg(EmpAppraisalObj.EvaluationValue) = ObjectiveThreshold AND ObjectiveMax < ObjectiveThreshold
--             THEN ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveThreshold ) * EmpObjectives.ObjectiveWeight * MinAmount / 100 
--      WHEN  Avg(EmpAppraisalObj.EvaluationValue) >= ObjectiveTarget AND ObjectiveMax < ObjectiveThreshold
--            THEN --( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveThreshold) / (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--			       ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveTarget ) * EmpObjectives.ObjectiveWeight * MidAmount / 100
--      WHEN  Avg(EmpAppraisalObj.EvaluationValue) >= ObjectiveMax AND Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveTarget AND ObjectiveMax < ObjectiveThreshold
--            THEN --(( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--			       ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveMax ) * (EmpObjectives.ObjectiveWeight * MaxAmount / 100)
--      WHEN  Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveMax AND ObjectiveMax < ObjectiveThreshold
--            THEN --((ObjectiveMax - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
--			        EmpObjectives.ObjectiveWeight * MaxAmount / 100

CASE WHEN  (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount = 0
            THEN 0

     WHEN  (ObjectiveMax - ObjectiveTarget) = 0 
	 	        THEN 0

     WHEN  Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveThreshold AND ObjectiveMax > ObjectiveThreshold
            THEN 0 

     WHEN  Avg(EmpAppraisalObj.EvaluationValue) = ObjectiveThreshold AND ObjectiveMax > ObjectiveThreshold
            THEN --( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveThreshold ) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			   EmpObjectives.ObjectiveWeight * MinAmount / 100.00

     --WHEN  Avg(EmpAppraisalObj.EvaluationValue) <= ObjectiveTarget AND ObjectiveMax > ObjectiveThreshold
     --       THEN --( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveThreshold) / (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			  --     ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveTarget ) * EmpObjectives.ObjectiveWeight * MidAmount / 100
        
		WHEN  Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveTarget and Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveThreshold  AND ObjectiveMax > ObjectiveThreshold
            THEN --( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveThreshold) / (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			      (1+ ( Avg(EmpAppraisalObj.EvaluationValue)  - ObjectiveThreshold ) /(ObjectiveTarget - ObjectiveThreshold))* EmpObjectives.ObjectiveWeight* MinAmount/ 100.00


     WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveTarget AND Avg(EmpAppraisalObj.EvaluationValue) <ObjectiveMax AND ObjectiveMax > ObjectiveThreshold
            THEN --(( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			       --( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveMax ) * (EmpObjectives.ObjectiveWeight * MaxAmount / 100)
	  (1+(Avg(EmpAppraisalObj.EvaluationValue) -ObjectiveTarget)/(ObjectiveMax - ObjectiveTarget))* EmpObjectives.ObjectiveWeight*MidAmount/100.00

	  
	  WHEN  Avg(EmpAppraisalObj.EvaluationValue) >= ObjectiveMax AND ObjectiveMax > ObjectiveThreshold
            THEN --((ObjectiveMax - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			      EmpObjectives.ObjectiveWeight* MaxAmount / 100.00


       WHEN  Avg(EmpAppraisalObj.EvaluationValue) = ObjectiveTarget AND ObjectiveMax > ObjectiveThreshold
	        --then EmpObjectives.ObjectiveWeight * MidAmount / 100.00
	          then   EmpObjectives.ObjectiveWeight*MidAmount / 100.00

      WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveThreshold AND ObjectiveMax < ObjectiveThreshold
            THEN 0 

      WHEN  Avg(EmpAppraisalObj.EvaluationValue) = ObjectiveThreshold AND ObjectiveMax < ObjectiveThreshold
           THEN  -- ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveThreshold ) * EmpObjectives.ObjectiveWeight * MinAmount / 100 
		      EmpObjectives.ObjectiveWeight*MinAmount / 100.00 
      --WHEN  Avg(EmpAppraisalObj.EvaluationValue) >= ObjectiveTarget AND ObjectiveMax < ObjectiveThreshold
      --      THEN --( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveThreshold) / (ObjectiveTarget - ObjectiveThreshold) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			   --    ( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveTarget ) * EmpObjectives.ObjectiveWeight * MidAmount / 100.00
       
	   WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveTarget and Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveThreshold AND ObjectiveMax < ObjectiveThreshold
            THEN  (1+(ObjectiveThreshold-Avg(EmpAppraisalObj.EvaluationValue)) /(ObjectiveThreshold-ObjectiveTarget))* EmpObjectives.ObjectiveWeight*MinAmount/100.00

      WHEN  Avg(EmpAppraisalObj.EvaluationValue) > ObjectiveMax AND Avg(EmpAppraisalObj.EvaluationValue) < ObjectiveTarget AND ObjectiveMax < ObjectiveThreshold
            THEN --(( Avg(EmpAppraisalObj.EvaluationValue) - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			       --( Avg(EmpAppraisalObj.EvaluationValue)  / ObjectiveMax ) * (EmpObjectives.ObjectiveWeight * MaxAmount / 100)
				   (1+(ObjectiveTarget-Avg(EmpAppraisalObj.EvaluationValue)) /(ObjectiveTarget-ObjectiveMax))* EmpObjectives.ObjectiveWeight*MidAmount/100.00
     
	 
	  WHEN  Avg(EmpAppraisalObj.EvaluationValue) <= ObjectiveMax AND ObjectiveMax < ObjectiveThreshold
            THEN --((ObjectiveMax - ObjectiveTarget) / (ObjectiveMax - ObjectiveTarget) * (MaxAmount -  MinAmount) / MinAmount + 1) * EmpObjectives.ObjectiveWeight * MinAmount / 100
			        --EmpObjectives.ObjectiveWeight * MaxAmount / 100.00
                  EmpObjectives.ObjectiveWeight*MaxAmount / 100.00
	
	WHEN  Avg(EmpAppraisalObj.EvaluationValue) = ObjectiveTarget AND ObjectiveMax < ObjectiveThreshold
		--then  EmpObjectives.ObjectiveWeight * MidAmount / 100.00
		  then    EmpObjectives.ObjectiveWeight*MidAmount / 100.00
END
FROM EmpAppraisalObj  
LEFT JOIN EmpObjectives ON EmpObjectives.ObjectiveId = EmpAppraisalObj.ObjectiveId AND EmpObjectives.EmpId = EmpAppraisalObj.EmpId
LEFT JOIN Objectives ON Objectives.ObjectiveId = EmpObjectives.ObjectiveId
left join Objectives objcat on Objectives.ObjectiveParentId= objcat.ObjectiveId and  objcat.ObjectiveParentId is null
LEFT JOIN EmpAssignment ON EmpAssignment.EmpId = EmpObjectives.EmpId
LEFT JOIN Positions ON Positions.PositionNo = EmpAssignment.PositionNo
LEFT JOIN Jobs ON Jobs.[job] = EmpAssignment.[Job]
LEFT JOIN Organization ON Organization.Organization = EmpAssignment.Organization
LEFT JOIN [Profile] ON [Profile].ProfileId = EmpAssignment.EmpId
LEFT JOIN EmpAppraisal ON EmpAppraisal.EmpId = EmpAppraisalObj.EmpId AND EmpAppraisal.DocumentNo = EmpAppraisalObj.DocumentNo
LEFT JOIN Appraisals ON Appraisals.AppraisalNo = EmpAppraisal.AppraisalNo
LEFT JOIN HRBudgetValues ON HRBudgetValues.Grade = dbo.GetOldValue(@empid,7,Empappraisal.AppraisalDate+1,NULL)
 AND HRBudgetValues.BudgetNo = 9999
where EmpAppraisalObj.empid=@empid and EmpAppraisalObj.documentno=@documentno AND ObjectiveMax<>0 AND ObjectiveTarget<>0 AND ObjectiveThreshold<>0
 GROUP BY 
  EmpAppraisalObj.EmpID
, EmpAssignment.EmployeeId
, EmpAppraisalObj.ObjectiveId
, EmpObjectives.ObjectiveWeight
, ObjectiveMax, ObjectiveTarget
, ObjectiveThreshold
, HRBudgetValues.MaxAmount
, HRBudgetValues.MinAmount
, HRBudgetValues.MidAmount
, Profile.Name
, Profile.AName
, Positions.PositionName
, Jobs.JobName
, Jobs.JobAName
, Positions.PositionAName
, Objectives.ObjectiveName
, Objectives.ObjectiveAName
, EmpObjectives.AssignStartDate
, EmpAssignment.EmpId
, EmpAppraisal.AppraisalDate
,EmpAppraisalobj.DocumentNo
,EmpAssignment.HrCurrency
END 
return isnull(@bonous,0.0)
END

GO

