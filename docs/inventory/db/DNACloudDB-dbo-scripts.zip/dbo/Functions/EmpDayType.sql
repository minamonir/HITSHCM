--this fn check if the specified date is a vacation ,holiday or dayoff for the employee
--@Type='P'  present
--@Type='H' holiday 
--@Type='O' dayoff
--@Type='V' vacation record

CREATE FUNCTION [dbo].[EmpDayType](@empid as int,@date as smalldatetime)
RETURNS nchar  AS  
BEGIN 

declare @Type as nchar,@VacPack as smallint,@holiday as smallint ,@Vacation as smallint,
@DayofWeek as smallint,@DayOffType as smallint , @DayOff as smallint

--select @VacPack=VacPack from empassignment where empassignment.empid=@empid
------------------------------------------
select @VacPack=isnull(dbo.GetOldValue(@EmpId, 19,@date+1,null),0)

-----------------------------holiday case---------------------------------------------------------------------------------
SELECT     @holiday=holiday
FROM         Holidays
where vacpack=@VacPack and [date]=@date
select @holiday=isnull(@holiday,0)
-------------------------Day off case-----------------------------------------------------------------------------------
select @DayOffType=dofftype FROM VacPack WHERE vacpack=@vacpack
--------fixed days per week---
if @DayOffType=1
begin
SELECT @DayofWeek=
   CASE DATENAME(weekday, @date) 
      WHEN  N'Sunday' THEN 1
      WHEN  N'Monday' Then 2
      WHEN  N'Tuesday' Then 3
      WHEN  N'Wednesday' Then 4
      WHEN  N'thursday' Then 5
      WHEN  N'friday' Then 6
      WHEN  N'saturday' Then 7
      
        END 

SELECT     @DayOff=case when @DayofWeek=doffday1 or @DayofWeek=doffday2 then 1 else 0 end
FROM         VacPack
WHERE     (dofftype = 1) and VacPack=@Vacpack
end
----fixed no of days per year----
else if @DayOffType=2
begin
select @DayOff=count(*) from Empvacat 
left join vacation on Empvacat.vaccode=vacation.vaccode
where (empid=@empid) and (@date between Fromdate and todate)and vacstatus=1 and vacation.vactype=3
SELECT     @DayOff=case when @DayOff>0 then 1 else 0 end
end
else
select @DayOff=0

-----------------------------------------------Vaction Case---------------------------------------------------------------------------------
select @Vacation=count(*) from Empvacat where (empid=@empid) and (@date between Fromdate and todate)and vacstatus=1 
-------------------------------------------------------------------------------------------------------------------------------------------------

select @type=case when @holiday=1 then N'H' else case when @dayoff=1 then N'O' else case when @Vacation>0 then N'V' else N'P' end  end end


return @Type
END

GO

