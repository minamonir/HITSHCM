
CREATE FUNCTION [dbo].[vac_calcduePeriod] (@vac_package int ,@vac_hiredate datetime, @vac_birthdate datetime, @vac_startdate datetime, @vac_duedate datetime , @vacpac_type int ,@vac_empid int )  
RETURNS numeric(10,3)  AS  
BEGIN 
declare @ChngCalcBasedonHiredate as nvarchar (max)

set @ChngCalcBasedonHiredate= isnull((select ConfigValue from SysParamConfig where ConfigID ='ChngCalcBasedonHiredate'),0)
if (@ChngCalcBasedonHiredate='1')
begin
select @vac_hiredate = isnull(RevisedHireDate,isnull(WorkReceivingDate,HireDate)) from EmpAssignment where EmpId=@vac_empid
end

--declare @vac_empid int
--declare @vac_startdate datetime
--declare @vac_hiredate datetime
--declare @vac_duedate datetime
--declare @vac_birthdate datetime
--declare @vac_package int
--declare @vacpac_type int
 
--set @vac_package =101
--set @vac_hiredate='Apr 17 1999 12:00:00:000AM'
--set @vac_birthdate='Jul 11 1956 12:00:00:000AM'
--set @vac_startdate = 'Jan 31 2005 12:00:00:000AM'
--set @vac_duedate='Feb 28 2005 12:00:00:000AM'
--set @vac_empid =2.020830000000000e+005
--set @vacpac_type =1





declare @calendar nchar(1)
declare @vac_duewm numeric(10,3)
set @vac_duewm = 0
declare @dayspermonth  INT
declare @monthdays INT

  declare @DecimalScale as smallint
  select @DecimalScale=DecimalScale from sysparam

select @calendar=case when EnableHijri=1  then 'H' else 'G' end from sysparam

select @calendar=case when @calendar='H' and payrollgroup.cyear<1900 then 'H' else 'G' end,
  @vac_duedate=case when isnull(termdate,hiredate)>hiredate and empassignment.termdate<@vac_duedate then empassignment.termdate else  @vac_duedate end
  from empassignment inner join payrollgroup on empassignment.payrollgroup=payrollgroup.payrollgroup where empassignment.empid=@vac_empid

--SELECT @monthdays=monthdays FROM payrollgroup inner join EmpAssignment on payrollgroup.payrollgroup=EmpAssignment.payrollgroup where EmpAssignment.empid=@vac_empid
--iF (@monthdays = 0) set @dayspermonth = 30 
--else set @dayspermonth = @monthdays

-- sameh to adjust no of days per month
set @dayspermonth = 30
--calculate vacdue based on working month

declare  @n  int
set @n = 1
if (@vac_startdate > @vac_hiredate)  set  @vac_startdate = @vac_startdate   else set  @vac_startdate= @vac_hiredate

declare @calc_date1 datetime
set @calc_date1 =  @vac_startdate 
if (@calc_date1 > @vac_hiredate) set @calc_date1 = @calc_date1 else set @calc_date1= @vac_hiredate
----print '@calc_date1: '+ RTRIM(CONVERT(nvarchar(30), @calc_date1)) 
declare @calc_date2 datetime
set @calc_date2 =  @vac_duedate 
----print '@calc_date2: ' + RTRIM(CONVERT(nvarchar(30), @calc_date2)) 
if  ((@vac_startdate >= @vac_hiredate) and (@vac_duedate >= @vac_startdate) )
begin
----print 'enter ((@vac_startdate >= @vac_hiredate) and (@vac_duedate >= @vac_startdate) )' 
declare @temp_date1 datetime
set @temp_date1 = @calc_date1

declare @wmonth1 int ,  @wmonth2 int ,  @wmonth3 int , @wmonth4 int ,  @wmonth5 int ,  @wmonth int
SELECT @wmonth1 = wmonth1 ,  @wmonth2 = wmonth2 ,  @wmonth3 = wmonth3 ,  @wmonth4 = wmonth4,  @wmonth5 = wmonth5   FROM  vacpack where vacpack =@vac_package
declare @duewm11 numeric(10,3),@duewm12 numeric(10,3),@duewm13 numeric(10,3),@duewm14 numeric(10,3),@duewm15 numeric(10,3)
declare @duewm21 numeric(10,3),@duewm22 numeric(10,3),@duewm23 numeric(10,3),@duewm24 numeric(10,3),@duewm25 numeric(10,3)
declare @duewm31 numeric(10,3),@duewm32 numeric(10,3),@duewm33 numeric(10,3),@duewm34 numeric(10,3),@duewm35 numeric(10,3)
      
SELECT  @duewm11=duewm11, @duewm12=duewm12, @duewm13=duewm13, @duewm14=duewm14, @duewm15=duewm15 ,
        @duewm21=duewm21, @duewm22=duewm22, @duewm23=duewm23, @duewm24=duewm24, @duewm25=duewm25 , 
        @duewm31=duewm31, @duewm32=duewm32, @duewm33=duewm33, @duewm34=duewm34, @duewm35=duewm35 
FROM  vacpack where vacpack =@vac_package
set @n=1
set @temp_date1 = @calc_date1
wHILE  @n <=  5
	BEGIN
         ----print 'n ' + str(@n)
            if (@n = 1) set @wmonth = @wmonth1  if (@n = 2) set @wmonth = @wmonth2  if (@n = 3) set @wmonth = @wmonth3  if (@n = 4) set @wmonth = @wmonth4  if (@n = 5) set @wmonth = @wmonth5  
----print  '@wmonth  : '+ RTRIM(CONVERT(nvarchar(30), @wmonth))   
               if @wmonth <> 0 
	       begin
		   
		declare @temp_date2 datetime
	   	if @calendar='H' set @temp_date2 = dbo.h_DATEADD('month',@wmonth,@vac_hiredate )  else set @temp_date2 = DATEADD(month,@wmonth,@vac_hiredate ) 
	  	----print ' (@temp_date2: '+ RTRIM(CONVERT(nvarchar(30), @temp_date2))+ ' )(@calc_date1: '+      RTRIM(CONVERT(nvarchar(30), @calc_date1))+ ' )(@calc_date2: '+      RTRIM(CONVERT(nvarchar(30), @calc_date2))+ ' )(@temp_date1: '+	    RTRIM(CONVERT(nvarchar(30), @temp_date1))
          if ((@temp_date2 >= @calc_date1 ) and 
                   ((@calc_date2 between @temp_date1 and @temp_date2) or
                    (@temp_date1 between @calc_date1 and @calc_date2) or
                    (@temp_date2 between @calc_date1 and @calc_date2)))


 --if (m.temp_date2>=m.calc_date1) and (betw(m.calc_date2,m.temp_date1,m.temp_date2) or;
 --         betw(m.temp_date1,m.calc_date1,m.calc_date2) or betw(m.temp_date2,m.calc_date1,;
 --         m.calc_date2))

		begin		
			declare @noofmonths int
			set @noofmonths = 0
			while 1 = 1
            begin
 				set  @noofmonths = @noofmonths +1
                declare @testdate as datetime 
                if ( @temp_date2 > @calc_date2 ) set @testdate = @calc_date2 else  set @testdate = @temp_date2 
----print '@temp_date2: '+RTRIM(CONVERT(nvarchar(30), @temp_date2))    ----print '@calc_date2: '+RTRIM(CONVERT(nvarchar(30), @calc_date2))   ----print '@temp_date1:  '+RTRIM(CONVERT(nvarchar(30), @temp_date1)) ----print 'testdate:  '+RTRIM(CONVERT(nvarchar(30), @testdate))
				if (DATEADD(day,-1,case when @calendar='H' then dbo.h_DATEADD('month',@noofmonths,@temp_date1 ) else case when  @calendar='H' then dbo.h_DATEADD('month',@noofmonths,@temp_date1 ) else DATEADD(month,@noofmonths,@temp_date1 ) end end) > @testdate) Break
			end
                     
            ----print '@noofmonths'+str(@noofmonths) 
            declare @vac_startdate1 datetime
			set @vac_startdate1 = @temp_date1
			declare @vac_enddate1 datetime
			if (@temp_date2 > @calc_date2) set @vac_enddate1 = @calc_date2 else set @vac_enddate1 = @temp_date2

			declare @a_vacbalcat1 numeric(18,3),@a_vacbalcat2 numeric(18,3),@a_vacbalcat3 numeric(18,3)

			select @a_vacbalcat1=SUM((dbo.vac_datediff((case when empvacat.fromdate<@vac_startdate1 then @vac_startdate1 else empvacat.fromdate end )
,case when empvacat.todate>@vac_enddate1 THEN @vac_enddate1 else empvacat.todate END)
			-((case when empvacat.PartDayFrom=1 AND FromDate>=@vac_startdate1 THEN 1- vacation.PartDayFactorFrom ELSE 0 END
			+case when empvacat.PartDayTo=1 AND todate<=@vac_enddate1 THEN 1-vacation.PartDayFactorTo ELSE 0 END)/30.0)
			) *  (case when vacation.usedayfactor=1 then dayfactor else 1 end))
                        from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode 
                        where empvacat.empid=@vac_empid and empvacat.vacstatus=1
                        and (
                        (empvacat.fromdate between @vac_startdate and @vac_duedate) or 
                        (empvacat.todate between @vac_startdate and @vac_duedate) or 
                        (@vac_startdate between empvacat.fromdate and empvacat.todate)or 
                        (@vac_duedate between empvacat.fromdate and empvacat.todate)
                             ) 
                        AND(vacation.vacbalcat = 1 or vacation.vacbalcat1 = 1 or vacation.vacbalcat2 = 1)
			and (
		        (empvacat.fromdate between @vac_startdate1 and @vac_enddate1) or 
                        (empvacat.todate between @vac_startdate1 and @vac_enddate1) or 
                        (@vac_startdate1 between empvacat.fromdate and empvacat.todate) or 
                        (@vac_enddate1 between empvacat.fromdate and empvacat.todate)
                            )


                        select @a_vacbalcat2=SUM((dbo.vac_datediff((case when empvacat.fromdate<@vac_startdate1 then @vac_startdate1 else empvacat.fromdate end )
,case when empvacat.todate>@vac_enddate1 THEN @vac_enddate1 else empvacat.todate END)
			-((case when empvacat.PartDayFrom=1 AND FromDate>=@vac_startdate1 THEN 1- vacation.PartDayFactorFrom ELSE 0 END
			+case when empvacat.PartDayTo=1 AND todate<=@vac_enddate1 THEN 1-vacation.PartDayFactorTo ELSE 0 END)/30.0)
			) *  (case when vacation.usedayfactor=1 then dayfactor else 1 end))
          		from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode 
                        where empvacat.empid=@vac_empid  and empvacat.vacstatus=1
                        and (
                        (empvacat.fromdate between @vac_startdate and @vac_duedate) or 
                        (empvacat.todate between @vac_startdate and @vac_duedate) or 
                        (@vac_startdate between empvacat.fromdate and empvacat.todate)or 
                        (@vac_duedate between empvacat.fromdate and empvacat.todate)
                             ) 
                        AND(vacation.vacbalcat =2 or vacation.vacbalcat1 = 2 or vacation.vacbalcat2 = 2)
			and (
		        (empvacat.fromdate between @vac_startdate1 and @vac_enddate1) or 
                        (empvacat.todate between @vac_startdate1 and @vac_enddate1) or 
                        (@vac_startdate1 between empvacat.fromdate and empvacat.todate) or 
                        (@vac_enddate1 between empvacat.fromdate and empvacat.todate)
                            )

                       select @a_vacbalcat3=SUM((dbo.vac_datediff((case when empvacat.fromdate<@vac_startdate1 then @vac_startdate1 else empvacat.fromdate end )
,case when empvacat.todate>@vac_enddate1 THEN @vac_enddate1 else empvacat.todate END)
			-((case when empvacat.PartDayFrom=1 AND FromDate>=@vac_startdate1 THEN 1- vacation.PartDayFactorFrom ELSE 0 END
			+case when empvacat.PartDayTo=1 AND todate<=@vac_enddate1 THEN 1-vacation.PartDayFactorTo ELSE 0 END)/30.0)
			) *  (case when vacation.usedayfactor=1 then dayfactor else 1 end))
           		from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode 
                        where empvacat.empid=@vac_empid  and empvacat.vacstatus=1
                        and (
                        (empvacat.fromdate between @vac_startdate and @vac_duedate) or 
                       (empvacat.todate between @vac_startdate and @vac_duedate) or 
                        (@vac_startdate between empvacat.fromdate and empvacat.todate)or 
   (@vac_duedate between empvacat.fromdate and empvacat.todate)
                             ) 
                        AND(vacation.vacbalcat =3 or vacation.vacbalcat1 = 3 or vacation.vacbalcat2 = 3)
			and (
		        (empvacat.fromdate between @vac_startdate1 and @vac_enddate1) or 
                        (empvacat.todate between @vac_startdate1 and @vac_enddate1) or 
                        (@vac_startdate1 between empvacat.fromdate and empvacat.todate) or 
                        (@vac_enddate1 between empvacat.fromdate and empvacat.todate)
                            )

			set @a_vacbalcat1 = isnull(@a_vacbalcat1,0)
			set @a_vacbalcat2 = isnull(@a_vacbalcat2,0)
			set @a_vacbalcat3 = isnull(@a_vacbalcat3,0)
-------------------------------------------------------------------------------------------------------------------------------------
--print  '@a_vacbalcat1='+RTRIM(CONVERT(nvarchar(30),  @a_vacbalcat1)) 
--print  '@a_vacbalcat2='+RTRIM(CONVERT(nvarchar(30),  @a_vacbalcat2)) 
--print  '@a_vacbalcat3='+RTRIM(CONVERT(nvarchar(30),  @a_vacbalcat3))  
-------------------------------------------------------------------------------------------------------------------------------------
			set @noofmonths = @noofmonths -1 
                        declare @noofdays numeric(18,3)

			if (@temp_date2 > @calc_date2)  
                                   set @noofdays = datediff(day,case when @calendar='H' then dbo.h_dateadd('month',@noofmonths,@temp_date1) else dateadd(month,@noofmonths,@temp_date1) end,@calc_date2)+1
                        else       set @noofdays = datediff(day,case when @calendar='H' then dbo.h_dateadd('month',@noofmonths,@temp_date1) else dateadd(month,@noofmonths,@temp_date1) end,@temp_date2)
			
                        declare @duewm1 numeric(10,3),@duewm2 numeric(10,3),@duewm3 numeric(10,3),@duewm4 numeric(10,3),@duewm5 numeric(10,3)
                        declare @duewm numeric(10,3)
			

            if (@vacpac_type = 1) begin set @duewm1 = @duewm11   set @duewm2 = @duewm12   set @duewm3 = @duewm13   set @duewm4 = @duewm14   set @duewm5 = @duewm15 end 
			if (@vacpac_type = 2) begin set @duewm1 = @duewm21  set @duewm2 = @duewm22  set @duewm3 = @duewm23 set @duewm4 = @duewm24   set @duewm5 = @duewm25 end 
			if (@vacpac_type = 3) begin  set @duewm1 = @duewm31 set @duewm2 = @duewm32  set @duewm3 = @duewm33 set @duewm4 = @duewm34  set @duewm5 = @duewm35 end 
			if (@n = 1) set @duewm = @duewm1  if (@n = 2) set @duewm = @duewm2 if (@n = 3) set @duewm = @duewm3 if (@n = 4) set @duewm = @duewm4 if (@n = 5) set @duewm = @duewm5
--------------------------------------------------------------------------------------------------------
--print '@noofmonths'+str(@noofmonths) 
--print '@noofdays'+str(@noofdays)
--print  @vac_duewm 
--print @duewm 
--print @a_vacbalcat1 
--------------------------------------------------------------------------------------------------------
              
		if (@vacpac_type = 1) set @vac_duewm = @vac_duewm + @duewm*(@noofmonths - @a_vacbalcat1 + @noofdays/30.000)
 		if (@vacpac_type = 2) set @vac_duewm = @vac_duewm + @duewm*(@noofmonths - @a_vacbalcat2 + @noofdays/30.000)
        if (@vacpac_type = 3) set @vac_duewm = @vac_duewm + @duewm*(@noofmonths - @a_vacbalcat3 + @noofdays/30.000)

----print  'last @temp_date1='+RTRIM(CONVERT(nvarchar(30),  @temp_date1))       		
-- sameh 29/01/2003 if (@temp_date2>@calc_date2) set @temp_date1 = dateadd(day,1,@calc_date2) else set @temp_date1 = dateadd(day,1,@temp_date2)
if (@temp_date2>@calc_date2) set @temp_date1 = dateadd(day,1,@calc_date2) else set @temp_date1 =@temp_date2
--m.temp_date1=iif(m.temp_date2>m.calc_date2,m.calc_date2,m.temp_date2)+1
--------------------------------------------------------------------------------------------------------
----print  'last @calc_date2='+RTRIM(CONVERT(nvarchar(30),  @calc_date2)) ----print  'last @temp_date2='+RTRIM(CONVERT(nvarchar(30),  @temp_date2)) ----print  'new @temp_date1='+RTRIM(CONVERT(nvarchar(30),  @temp_date1))  ----print  '@vac_duewm='+RTRIM(CONVERT(nvarchar(30),  @vac_duewm))    
--------------------------------------------------------------------------------------------------------
                set @a_vacbalcat1 = 0
  		set @a_vacbalcat2 = 0
  		set @a_vacbalcat3 = 0
		
		end  	
	      end 
         set @n = @n + 1
	 --set @vac_duewm = 0
	END
end
----print  '@vac_duewm='+RTRIM(CONVERT(nvarchar(30),  @vac_duewm)) 
--select @vac_duewm as vac_duewm

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-----------------------    calc vacdue based on age (years)  ------------------------------------------
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
if @vac_birthdate is not null
begin
declare @vac_dueage numeric(10,3)
set @vac_dueage = 0 
set @calc_date1 = @vac_startdate
if (@calc_date1 > @vac_hiredate) set @calc_date1 = @calc_date1 else set @calc_date1= @vac_hiredate
----print '@calc_date1: '+ RTRIM(CONVERT(nvarchar(30), @calc_date1)) 

set @calc_date2 =  @vac_duedate 
----print '@calc_date2: ' + RTRIM(CONVERT(nvarchar(30), @calc_date2)) 
if  ((@vac_startdate >= @vac_hiredate) and (@vac_duedate >= @vac_startdate) )
begin
----print 'enter ((@vac_startdate >= @vac_hiredate) and (@vac_duedate >= @vac_startdate) )' 

set @temp_date1 = @calc_date1

declare @ageyear1 int ,  @ageyear2 int ,  @ageyear3 int , @ageyear4 int ,  @ageyear5 int ,  @ageyear int
SELECT @ageyear1 = ageyear1 ,  @ageyear2 = ageyear2 ,  @ageyear3 = ageyear3 ,  @ageyear4 = ageyear4,  @ageyear5 = ageyear5   FROM  vacpack where vacpack =@vac_package
declare @dueage11 numeric(10,3),@dueage12 numeric(10,3),@dueage13 numeric(10,3),@dueage14 numeric(10,3),@dueage15 numeric(10,3)
declare @dueage21 numeric(10,3),@dueage22 numeric(10,3),@dueage23 numeric(10,3),@dueage24 numeric(10,3),@dueage25 numeric(10,3)
declare @dueage31 numeric(10,3),@dueage32 numeric(10,3),@dueage33 numeric(10,3),@dueage34 numeric(10,3),@dueage35 numeric(10,3)
      
SELECT  @dueage11=dueage11, @dueage12=dueage12, @dueage13=dueage13, @dueage14=dueage14, @dueage15=dueage15 ,
        @dueage21=dueage21, @dueage22=dueage22, @dueage23=dueage23, @dueage24=dueage24, @dueage25=dueage25 , 
        @dueage31=dueage31, @dueage32=dueage32, @dueage33=dueage33, @dueage34=dueage34, @dueage35=dueage35 
FROM  vacpack where vacpack =@vac_package
set @n=1
set @temp_date1 = @calc_date1
wHILE  @n <=  5
	BEGIN
         ----print 'n ' + str(@n)
            if (@n = 1) set @ageyear = @ageyear1  if (@n = 2) set @ageyear = @ageyear2  if (@n = 3) set @ageyear = @ageyear3  if (@n = 4) set @ageyear = @ageyear4  if (@n = 5) set @ageyear = @ageyear5  
----print  '@ageyear  : '+ RTRIM(CONVERT(nvarchar(30), @ageyear))   
               if @ageyear <> 0 
	       begin
		   
		
	   	if @calendar='H' set @temp_date2 = dbo.h_DATEADD('month',@ageyear*12,@vac_birthdate ) else set @temp_date2 = DATEADD(month,@ageyear*12,@vac_birthdate )
	  	----print ' (@temp_date2: '+ RTRIM(CONVERT(nvarchar(30), @temp_date2))+' )(@calc_date1: '+      RTRIM(CONVERT(nvarchar(30), @calc_date1))+' )(@calc_date2: '+      RTRIM(CONVERT(nvarchar(30), @calc_date2))+' )(@temp_date1: '+	    RTRIM(CONVERT(nvarchar(30), @temp_date1))
          if ((@temp_date2 >= @calc_date1 ) and 
                   ((@calc_date2 between @temp_date1 and @temp_date2) or
                    (@temp_date1 between @calc_date1 and @calc_date2) or
                    (@temp_date2 between @calc_date1 and @calc_date2)))


 --if (m.temp_date2>=m.calc_date1) and (betw(m.calc_date2,m.temp_date1,m.temp_date2) or;
 --         betw(m.temp_date1,m.calc_date1,m.calc_date2) or betw(m.temp_date2,m.calc_date1,;
 --         m.calc_date2))

		begin		
			
			set @noofmonths = 0
			while 1 = 1
                        begin
 				set  @noofmonths = @noofmonths +1
                              
                            if ( @temp_date2 > @calc_date2 ) set @testdate = @calc_date2 else  set @testdate = @temp_date2 
----print '@temp_date2: '+RTRIM(CONVERT(nvarchar(30), @temp_date2))    ----print '@calc_date2: '+RTRIM(CONVERT(nvarchar(30), @calc_date2))   ----print '@temp_date1:  '+RTRIM(CONVERT(nvarchar(30), @temp_date1)) ----print 'testdate:  '+RTRIM(CONVERT(nvarchar(30), @testdate))
				if (DATEADD(day,-1,case when @calendar='H' then dbo.h_DATEADD('month',@noofmonths,@temp_date1) else DATEADD(month,@noofmonths,@temp_date1 ) end) > @testdate) Break
			end
                       ----print '@noofmonths'+str(@noofmonths) 
                        
			set @vac_startdate1 = @temp_date1
			
			if (@temp_date2 > @calc_date2) set @vac_enddate1 = @calc_date2 else set @vac_enddate1 = @temp_date2

			


			select @a_vacbalcat1=sum(dbo.vac_datediff((case when empvacat.fromdate<@vac_startdate1 then @vac_startdate1 else empvacat.fromdate end ),
  case when empvacat.todate>@vac_enddate1 THEN @vac_enddate1 else empvacat.todate END)
  *(case when vacation.usedayfactor=1 then dayfactor else 1 end))
                        from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode 
                        where empvacat.empid=@vac_empid  and empvacat.vacstatus=1
                        
                        and (
                        (empvacat.fromdate between @vac_startdate and @vac_duedate) or 
                        (empvacat.todate between @vac_startdate and @vac_duedate) or 
                        (@vac_startdate between empvacat.fromdate and empvacat.todate)or 
                        (@vac_duedate between empvacat.fromdate and empvacat.todate)
                             ) 
                        AND(vacation.vacbalcat = 1 or vacation.vacbalcat1 = 1 or vacation.vacbalcat2 = 1)
			and (
		        (empvacat.fromdate between @vac_startdate1 and @vac_enddate1) or 
                        (empvacat.todate between @vac_startdate1 and @vac_enddate1) or 
                        (@vac_startdate1 between empvacat.fromdate and empvacat.todate) or 
                        (@vac_enddate1 between empvacat.fromdate and empvacat.todate)
                            )


                        select @a_vacbalcat2=sum(dbo.vac_datediff(
  (case when empvacat.fromdate<@vac_startdate1 then @vac_startdate1 else empvacat.fromdate end ),
  case when empvacat.todate>@vac_enddate1 THEN @vac_enddate1 else empvacat.todate END)
  * (case when vacation.usedayfactor=1 then dayfactor else 1 end))
          		from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode 
                        where empvacat.empid=@vac_empid  and empvacat.vacstatus=1
                        and (
                        (empvacat.fromdate between @vac_startdate and @vac_duedate) or 
                        (empvacat.todate between @vac_startdate and @vac_duedate) or 
                        (@vac_startdate between empvacat.fromdate and empvacat.todate)or 
                        (@vac_duedate between empvacat.fromdate and empvacat.todate)
                             ) 
                        AND(vacation.vacbalcat =2 or vacation.vacbalcat1 = 2 or vacation.vacbalcat2 = 2)
			and (
		        (empvacat.fromdate between @vac_startdate1 and @vac_enddate1) or 
                        (empvacat.todate between @vac_startdate1 and @vac_enddate1) or 
                        (@vac_startdate1 between empvacat.fromdate and empvacat.todate) or 
                        (@vac_enddate1 between empvacat.fromdate and empvacat.todate)
                            )

                        select @a_vacbalcat3=sum(dbo.vac_datediff(
  (case when empvacat.fromdate<@vac_startdate1 then @vac_startdate1 else empvacat.fromdate end ),
  case when empvacat.todate>@vac_enddate1 THEN @vac_enddate1 else empvacat.todate END)
  * (case when vacation.usedayfactor=1 then dayfactor else 1 end))
           		from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode 
                        where empvacat.empid=@vac_empid  and empvacat.vacstatus=1
                        and (
                        (empvacat.fromdate between @vac_startdate and @vac_duedate) or 
   (empvacat.todate between @vac_startdate and @vac_duedate) or 
                        (@vac_startdate between empvacat.fromdate and empvacat.todate)or 
                        (@vac_duedate between empvacat.fromdate and empvacat.todate)
                             ) 
                        AND(vacation.vacbalcat =3 or vacation.vacbalcat1 = 3 or vacation.vacbalcat2 = 3)
			and (
		        (empvacat.fromdate between @vac_startdate1 and @vac_enddate1) or 
                        (empvacat.todate between @vac_startdate1 and @vac_enddate1) or 
                        (@vac_startdate1 between empvacat.fromdate and empvacat.todate) or 
                        (@vac_enddate1 between empvacat.fromdate and empvacat.todate)
                            )

			set @a_vacbalcat1 = isnull(@a_vacbalcat1,0)
			set @a_vacbalcat2 = isnull(@a_vacbalcat2,0)
			set @a_vacbalcat3 = isnull(@a_vacbalcat3,0)
-------------------------------------------------------------------------------------------------------------------------------------
----print  '@a_vacbalcat1='+RTRIM(CONVERT(nvarchar(30),  @a_vacbalcat1)) ----print  '@a_vacbalcat2='+RTRIM(CONVERT(nvarchar(30),  @a_vacbalcat2)) ----print  '@a_vacbalcat3='+RTRIM(CONVERT(nvarchar(30),  @a_vacbalcat3))  
-------------------------------------------------------------------------------------------------------------------------------------
			set @noofmonths = @noofmonths -1 
                       

			if (@temp_date2 > @calc_date2)  
                                   set @noofdays = datediff(day,case when @calendar='H' then dbo.h_dateadd('month',@noofmonths,@temp_date1) else dateadd(month,@noofmonths,@temp_date1) end,@calc_date2) +1
                        else       set @noofdays = datediff(day,case when @calendar='H' then dbo.h_dateadd('month',@noofmonths,@temp_date1) else dateadd(month,@noofmonths,@temp_date1) end,@temp_date2)
			
                        declare @dueage1 numeric(10,3),@dueage2 numeric(10,3),@dueage3 numeric(10,3),@dueage4 numeric(10,3),@dueage5 numeric(10,3)
                        declare @dueage numeric(10,3)
			
                        if (@vacpac_type = 1) begin set @dueage1 = @dueage11   set @dueage2 = @dueage12   set @dueage3 = @dueage13   set @dueage4 = @dueage14   set @dueage5 = @dueage15 end 
			if (@vacpac_type = 2) begin set @dueage1 = @dueage21  set @dueage2 = @dueage22  set @dueage3 = @dueage23 set @dueage4 = @dueage24   set @dueage5 = @dueage25 end 
			if (@vacpac_type = 3) begin  set @dueage1 = @dueage31 set @dueage2 = @dueage32  set @dueage3 = @dueage33 set @dueage4 = @dueage34  set @dueage5 = @dueage35 end 
			if (@n = 1) set @dueage = @dueage1  if (@n = 2) set @dueage = @dueage2 if (@n = 3) set @dueage = @dueage3 if (@n = 4) set @dueage = @dueage4 if (@n = 5) set @dueage = @dueage5
--------------------------------------------------------------------------------------------------------
----print '@noofmonths'+str(@noofmonths) ----print '@noofdays'+str(@noofdays) ----print  @vac_dueage ----print @dueage  ----print @a_vacbalcat1 
--------------------------------------------------------------------------------------------------------
		if (@vacpac_type = 1) set @vac_dueage = @vac_dueage + @dueage*(@noofmonths - @a_vacbalcat1 + @noofdays/30.000)
		if (@vacpac_type = 2) set @vac_dueage = @vac_dueage + @dueage*(@noofmonths - @a_vacbalcat2 + @noofdays/30.000)
		if (@vacpac_type = 3) set @vac_dueage = @vac_dueage + @dueage*(@noofmonths - @a_vacbalcat3 + @noofdays/30.000)
----print  'last @temp_date1='+RTRIM(CONVERT(nvarchar(30),  @temp_date1))       		
-- sameh 29/01/2003 if (@temp_date2>@calc_date2) set @temp_date1 = dateadd(day,1,@calc_date2) else set @temp_date1 = dateadd(day,1,@temp_date2)
if (@temp_date2>@calc_date2) set @temp_date1 = dateadd(day,1,@calc_date2) else set @temp_date1 = @temp_date2
--m.temp_date1=iif(m.temp_date2>m.calc_date2,m.calc_date2,m.temp_date2)+1
--------------------------------------------------------------------------------------------------------
----print  'last @calc_date2='+RTRIM(CONVERT(nvarchar(30),  @calc_date2)) ----print  'last @temp_date2='+RTRIM(CONVERT(nvarchar(30),  @temp_date2)) ----print  'new @temp_date1='+RTRIM(CONVERT(nvarchar(30),  @temp_date1))  ----print  '@vac_dueage='+RTRIM(CONVERT(nvarchar(30),  @vac_dueage))    
--------------------------------------------------------------------------------------------------------
                set @a_vacbalcat1 = 0
  		set @a_vacbalcat2 = 0
  		set @a_vacbalcat3 = 0
		
		end  	
	      end 
         set @n = @n + 1
	 --set @vac_dueage = 0
	END
end
end
----print  '@vac_dueage='+RTRIM(CONVERT(nvarchar(30),  @vac_dueage)) 
--select @vac_dueage as vac_dueage
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------    choose @vac_dueage or @vac_duewm          --------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
declare @vac_due numeric(10,3)
if (@vac_dueage > @vac_duewm) set @vac_due = @vac_dueage else set @vac_due = @vac_duewm
if (@vac_due <= 0 ) set @vac_due = 0

----print  '@vac_due='+RTRIM(CONVERT(nvarchar(30),  @vac_due)) 
--select @vac_due as vac_due
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------                adding holidays               --------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

declare @noofholdays int
set @noofholdays = 0
declare @addholi bit
declare @holivtype int
select @addholi = holiadd, @holivtype = holivtype   from vacpack where vacpack = @vac_package
declare hcount cursor for select  holidays.date from holidays where ((holidays.vacpack=@vac_package) and  (holidays.date between @calc_date1 and @vac_duedate ) and ( holidays.holiday = 1 ))

if @addholi = 1 
     begin	
	declare @holivtype1 int
	 select @holivtype1=holivtype from vacpack where vacpack.vacpack=@vac_package
	declare a_vacbaldtl cursor for 
        	SELECT (case when empvacat.fromdate < @calc_date1 then @calc_date1 else empvacat.fromdate end ) as empvacatfrom  ,
        	(case when empvacat.todate > @vac_duedate then @vac_duedate else empvacat.todate end ) as empvacatto
       		 from empvacat
        	left join vacation on empvacat.vaccode=vacation.vaccode 
		where
       		empvacat.empid=@vac_empid  and empvacat.vacstatus=1
        	and ((empvacat.fromdate between @vac_startdate and  @vac_duedate) or 
             	(empvacat.todate between  @vac_startdate and  @vac_duedate) or 
             	(@vac_startdate between  empvacat.fromdate and empvacat.todate) or 
             	(@vac_duedate between empvacat.fromdate and empvacat.todate)) 
        	AND   (vacation.vacbalcat =@holivtype1 or vacation.vacbalcat1 =@holivtype1
                      or vacation.vacbalcat2 = @holivtype1)

	OPEN hcount
	declare @holidaysdate datetime
	declare @rtbetween int	 
	FETCH NEXT FROM hcount INTO @holidaysdate

	WHILE @@FETCH_STATUS = 0
		begin

		set @rtbetween = 0
		
		OPEN a_vacbaldtl
		declare @empvacatfrom datetime,@empvacatto datetime
		FETCH NEXT FROM a_vacbaldtl INTO @empvacatfrom,@empvacatto
                WHILE @@FETCH_STATUS = 0
  			BEGIN         
       --  print  '@holidaysdate='+RTRIM(CONVERT(nvarchar(30),  @holidaysdate)) 
        -- print  '@empvacatfrom='+RTRIM(CONVERT(nvarchar(30),  @empvacatfrom)) 
        -- print  '@empvacatto='+RTRIM(CONVERT(nvarchar(30),  @empvacatto)) 
        -- print '@rtbetween ='+str(@rtbetween)

			if( @holidaysdate between @empvacatfrom  and  @empvacatto)   and  ( @holivtype1 <> 1) -- when accumulated balance for resorts
				begin
				set @rtbetween = 1
       --  print '@rtbetween ='+str(@rtbetween)
				break
				end 
			FETCH NEXT FROM a_vacbaldtl INTO @empvacatfrom,@empvacatto
			end
		
--print '@noofholdays1 ='+str(@noofholdays)
	if ( @rtbetween = 0) set @noofholdays = @noofholdays + 1 
--print '@noofholdays2 ='+str(@noofholdays)
		FETCH NEXT FROM hcount INTO @holidaysdate
		CLOSE a_vacbaldtl
	
	end
 	
	CLOSE hcount
	--DEALLOCATE hcount
	DEALLOCATE a_vacbaldtl
	----print  @holivtype ----print @vacpac_type
 	if (@holivtype = @vacpac_type) set @vac_due = @vac_due + @noofholdays  
	

----print  '@vac_due after adding holi='+RTRIM(CONVERT(nvarchar(30),  @vac_due)) 
--select @vac_due as vac_dueafteraddingholi
end 


--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------                adding dayoff               --------------------------------
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
declare @noofdaysoff numeric (6,2)
set @noofdaysoff=0.00
declare @doffadd bit,@doffvtype smallint,@doffday1 int,@doffday2 int,@doffdonot bit,@dofftype int,@doffdays int
select @doffadd=doffadd,@doffvtype = doffvtype , @doffday1 = doffday1 , @doffday2= doffday2 , @doffdonot=doffdonot,@dofftype=dofftype , @doffdays = doffdays from vacpack where vacpack.vacpack=@vac_package
declare @thesum numeric(10,3) 

if @doffadd = 1
	begin
               --print 'subtract dof'
		
       if @dofftype=1
	    begin
		--print '@dofftype=1'
               declare @dayoffinvacation smallint
      	  if @doffday1<>0
 	        begin
		     --print '@doffday1<>0'
	       declare @dayoffdate datetime
	 	     -- SET DATEFIRST  7
         	       set @dayoffdate=@calc_date1
		 
             	      while @doffday1 <> DATEPART(dw,@dayoffdate)
           	         begin	
	 	         set @dayoffdate=dateadd(day,1,@dayoffdate)   
		         --print '@dayoffdate: '+RTRIM(CONVERT(nvarchar(30), @dayoffdate))	        
         	         end
		       --print '@dayoffdate: '+RTRIM(CONVERT(nvarchar(30), @dayoffdate))
             	   while @dayoffdate<= @vac_duedate
	        begin	
                      set @dayoffinvacation =0
                      select @dayoffinvacation=count(*) from empvacat
                    	left join vacation on empvacat.vaccode=vacation.vaccode where
        	              empvacat.empid=@vac_empid  and empvacat.vacstatus=1
		and (@dayoffdate between empvacat.fromdate and empvacat.todate)
		ANd (vacation.vacbalcat=@doffvtype or vacation.vacbalcat1 =@doffvtype  or vacation.vacbalcat2 = @doffvtype) group by empvacat.empid
                      if  @dayoffinvacation =0
                        begin
                        if (@doffdonot = 1 ) 
	             begin	
	                 --print '@doffdonot = 1'
		    set @noofdaysoff=@noofdaysoff+1	
		    open hcount	
		    FETCH NEXT FROM hcount INTO @holidaysdate
		    WHILE @@FETCH_STATUS = 0
		          begin
		               if (@dayoffdate = @holidaysdate )
                                          begin 
                                           set @noofdaysoff=@noofdaysoff-1
			    break
			  end			
			  --print @dayoffdate
			  --print @holidaysdate
		          FETCH NEXT FROM hcount INTO @holidaysdate
		          end 
		          close hcount 
	         end
                     else set @noofdaysoff=@noofdaysoff+1	
                   end
	     set @dayoffdate=dateadd(day,7,@dayoffdate)
                   if (@dayoffdate>@vac_duedate) break
              end
  --error here sameh 23/10/2002	
 -- if (@thesum <> 0 ) set @noofdaysoff=@noofdaysoff -(@noofdaysoff*@thesum/365)
        end
      
      if @doffday2<>0
	  begin
          set @dayoffdate=@calc_date1
	      --SET DATEFIRST  7
while @doffday2 <> DATEPART(dw,@dayoffdate)
             begin
             set @dayoffdate=dateadd(day,1,@dayoffdate)           
          end
	     while @dayoffdate<= @vac_duedate
	     begin	
                      set @dayoffinvacation =0
                      select @dayoffinvacation=count(*) from empvacat
                    	left join vacation on empvacat.vaccode=vacation.vaccode where
        	              empvacat.empid=@vac_empid  and empvacat.vacstatus=1
		and (@dayoffdate between empvacat.fromdate and empvacat.todate)
		ANd (vacation.vacbalcat=@doffvtype or vacation.vacbalcat1 =@doffvtype  or vacation.vacbalcat2 = @doffvtype) group by empvacat.empid
                      if  @dayoffinvacation =0
                       begin
         if (@doffdonot = 1 )
		     begin
		      set @noofdaysoff=@noofdaysoff+1	
		      open hcount	
		      FETCH NEXT FROM hcount INTO @holidaysdate
		      WHILE @@FETCH_STATUS = 0
			   begin
			       if (@dayoffdate = @holidaysdate )
                    begin 
                       set @noofdaysoff=@noofdaysoff-1
				       break
				   end						     			    			     
			       FETCH NEXT FROM hcount INTO @holidaysdate
			   end 
		       close hcount 
            end
	    else set @noofdaysoff=@noofdaysoff+1
           end
	    set @dayoffdate=dateadd(day,7,@dayoffdate)
            if @dayoffdate>@vac_duedate break
           end 
       --error here sameh 23/10/2002	   
        --       if (@thesum <> 0 ) set @noofdaysoff=@noofdaysoff- (@noofdaysoff*@thesum/365)
	end
        -- sameh 5/5/2004   
        --if (@thesum <> 0 ) set @noofdaysoff=@noofdaysoff- round(@noofdaysoff*@thesum/365,0)
    
end 
else 
  begin
    SELECT @thesum = sum((datediff(day,(case when empvacat.fromdate <@calc_date1 then @calc_date1 else empvacat.fromdate end ),(case when empvacat.todate > @vac_duedate then @vac_duedate else empvacat.todate end )) +1)*(case when vacation.usedayfactor=1 then dayfactor else 1 end)) 
        	from empvacat
        	left join vacation on empvacat.vaccode=vacation.vaccode where
        	empvacat.empid=@vac_empid  and empvacat.vacstatus=1
		and ((empvacat.fromdate between @vac_startdate and @vac_duedate) or 
	    	(empvacat.todate between @vac_startdate and @vac_duedate) or 
            	(@vac_startdate between  empvacat.fromdate and empvacat.todate ) or 
	    	(@vac_duedate  between empvacat.fromdate and empvacat.todate )) 
		ANd (vacation.vacbalcat=@doffvtype or vacation.vacbalcat1 =@doffvtype
                      or vacation.vacbalcat2 = @doffvtype) 
		set @thesum = isnull(@thesum,0)
   	   	--print 'the sum : ' + convert(nvarchar(30),@thesum)

      set @noofdaysoff=@doffdays*(datediff(day,@calc_date1,@vac_duedate)-@thesum+1)/365
   end
  DEALLOCATE hcount	

   if (@noofdaysoff>0) begin if (@doffvtype =  @vacpac_type) set  @vac_due=@vac_due+ cast(@noofdaysoff as numeric(10,3)) end
   --set @vac_due=round (@vac_due,2)
   set @vac_due=round (@vac_due,@DecimalScale)
   
--print  '@vac_due after adding dayoff='+RTRIM(CONVERT(nvarchar(30),  @vac_due)) 
--select @vac_due as vac_dueafteraddingdayoff
end 


--adding vac due adjustment
SELECT @vac_due=isnull(@vac_due,0)+isnull(SUM(EmpVacationDue.VacDueDays),0)
FROM  EmpVacationDue 
    INNER JOIN VacationDue ON EmpVacationDue.VacDueCode = VacationDue.VacDueCode
WHERE  (EmpVacationDue.VacDueStatus = 1) AND (VacationDue.VacDueType = @vacpac_type) AND
  (EmpVacationDue.Empid = @vac_empid) AND (EmpVacationDue.VacDueDate  between @vac_startdate and @vac_duedate )

return  @vac_due


end

GO

