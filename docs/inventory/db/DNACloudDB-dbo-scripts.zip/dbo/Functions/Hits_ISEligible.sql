
CREATE  FUNCTION [dbo].[Hits_ISEligible] (@empid as int ,@EligibleNo as int, @date as smalldatetime)
RETURNS  bit
AS

BEGIN
declare @AgeYesNo as bit ,  @AgeValue1 as numeric(18,2) ,  @AgeValue2 as numeric(18,2) ,  
@ServiceYesNo as bit ,  @ServiceValue1 as numeric(18,2) ,  @ServiceValue2 as numeric(18,2) ,  
@SalaryYesNo as bit ,  @SalaryValue1 as numeric(18,3) ,  @SalaryValue2 as numeric(18,3) ,  
@SalaryCurrency as smallint ,  @AllHRStatus as bit ,  @AllJob as bit ,  
@AllOrganization as bit ,  @AllPosition as bit ,  @AllLocation as bit ,  
@AllGender as bit ,  @AllForeigner as bit ,  @AllMilStatus as bit ,  
@AllSocStatus as bit ,  @AllEmployer as bit ,  @AllGrade as bit ,  
@AllGraduation as bit ,  @OrHRStatus as smallint ,  @OrJob as smallint ,  
@OrOrganization as smallint ,  @OrPosition as smallint ,  @OrLocation as smallint ,  
@OrGender as smallint ,  @OrForeigner as smallint ,  @OrMilStatus as smallint ,  
@OrSocStatus as smallint ,  @OrEmployer as smallint ,  @OrGrade as smallint ,  
@OrGraduation as smallint

SELECT @AgeYesNo=EligibleProfiles.AgeYesNo, @AgeValue1=EligibleProfiles.AgeValue1, @AgeValue2=EligibleProfiles.AgeValue2, 
@ServiceYesNo=EligibleProfiles.ServiceYesNo, @ServiceValue1=EligibleProfiles.ServiceValue1, @ServiceValue2=EligibleProfiles.ServiceValue2, 
@SalaryYesNo=EligibleProfiles.SalaryYesNo, @SalaryValue1=EligibleProfiles.SalaryValue1, @SalaryValue2=EligibleProfiles.SalaryValue2, 
@SalaryCurrency=EligibleProfiles.SalaryCurrency, @AllHRStatus=EligibleProfiles.AllHRStatus, @AllJob=EligibleProfiles.AllJob, 
@AllOrganization=EligibleProfiles.AllOrganization, @AllPosition=EligibleProfiles.AllPosition, 
@AllLocation=EligibleProfiles.AllLocation, @AllGender=EligibleProfiles.AllGender,
@AllForeigner=EligibleProfiles.AllForeigner, @AllMilStatus=EligibleProfiles.AllMilStatus, 
@AllSocStatus=EligibleProfiles.AllSocStatus, @AllEmployer=EligibleProfiles.AllEmployer,
@AllGrade=EligibleProfiles.AllGrade, @AllGraduation=EligibleProfiles.AllGraduation,
@OrHRStatus=EligibleProfiles.OrHRStatus, @OrJob=EligibleProfiles.OrJob, 
@OrOrganization=EligibleProfiles.OrOrganization, @OrPosition=EligibleProfiles.OrPosition, 
@OrLocation=EligibleProfiles.OrLocation, @OrGender=EligibleProfiles.OrGender, 
@OrForeigner=EligibleProfiles.OrForeigner, @OrMilStatus=EligibleProfiles.OrMilStatus, 
@OrSocStatus=EligibleProfiles.OrSocStatus, @OrEmployer=EligibleProfiles.OrEmployer, 
@OrGrade=EligibleProfiles.OrGrade, @OrGraduation=EligibleProfiles.OrGraduation
FROM EligibleProfiles
Where EligibleProfiles.EligibleNo = @EligibleNo

declare @ANDeligible as bit,@OReligible as bit,@Itemeligible as bit

set @ANDeligible=case when @AgeYesNo=0 and @ServiceYesNo=0 and @SalaryYesNo=0 and  
@OrHRStatus =0 and  @OrJob =0 and @OrOrganization=0 and @OrPosition=0 and  @OrLocation=0 and
@OrGender=0 and @OrForeigner =0 and @OrMilStatus=0 and @OrSocStatus =0 and @OrEmployer =0
and @OrGrade=0 and @OrGraduation =0 then 0 else 1 end

set @OReligible=0
set @Itemeligible=0



if @AgeYesNo = 1 
begin
select @Itemeligible = case when datediff(dd,birthdate,@date)/365.00 between  @AgeValue1 and @AgeValue2 then 1 else 0 end from Profile where  profile.profileid = @empid
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end 

if @ServiceYesNo = 1  
BEGIN

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'FN' AND name = 'EmpServiceYears')
select @Itemeligible = case WHEN dbo.EmpServiceYears(@empid,@date)  between  @ServiceValue1 and @ServiceValue2  then 1 else 0 end from empassignment where empassignment.empid = @empid
ELSE 
select @Itemeligible = case when (DATEDIFF(dd,hiredate,@date)+1)/365.00 between  @ServiceValue1 and @ServiceValue2  then 1 else 0 end from empassignment where empassignment.empid = @empid

SET @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

if @SalaryYesNo = 1  
begin
if @SalaryCurrency is not null 
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 15, dateadd(d,1,@Date), @SalaryCurrency) between @SalaryValue1 and @SalaryValue2 then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
else
begin

select @Itemeligible = case when dbo.GetOldValue(@empid, 15, dateadd(d,1,@Date), Empassignment.HrCurrency) between @SalaryValue1 and @SalaryValue2 then 1 else 0 end  from Empassignment where empassignment.empid = @empid
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
end



-----------------------------------------------hrstatus----------------------------------------------------
if @AllHRStatus = 0 and @OrHRStatus = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 1, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'HRSTATUS') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllHRStatus = 1 and @OrHRStatus = 0   
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllHRStatus = 0 and @OrHRStatus = 1   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 1, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'HRSTATUS') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllHRStatus = 1 and @OrHRStatus = 1   
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------Job----------------------------------------------------

if @AllJob = 0 and @OrJob = 0    
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 5, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'JOB') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllJob = 1 and @OrJob = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllJob = 0 and @OrJob = 1
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 5, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'JOB') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0
end
if @AllJob = 1 and @OrJob = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------Organization----------------------------------------------------

if @AllOrganization = 0 and @OrOrganization = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 6, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'ORGANIZATION') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllOrganization = 1 and @OrOrganization = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllOrganization = 0 and @OrOrganization = 1
begin
select @Itemeligible = case when  dbo.GetOldValue(@empid, 6, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'ORGANIZATION') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0  
end
if @AllOrganization = 1 and @OrOrganization = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------Position----------------------------------------------------

if @AllPosition = 0 and @OrPosition = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 8, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'POSITIONNO') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllPosition = 1 and @OrPosition = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllPosition = 0 and @OrPosition = 1
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 8, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'POSITIONNO') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllPosition = 1 and @OrPosition = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------Location----------------------------------------------------

if @AllLocation = 0 and @OrLocation = 0   
begin
select @Itemeligible = case when  dbo.GetOldValue(@empid, 9, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'LOCATIONNO') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllLocation = 1 and @OrLocation = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllLocation = 0 and @OrLocation = 1
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 9, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'LOCATIONNO') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllLocation = 1 and @OrLocation = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end


-----------------------------------------------Gender----------------------------------------------------

if @AllGender = 0 and @OrGender = 0   
begin
select @Itemeligible = case when Gender in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'GENDER') then 1 else 0 end from Profile where profile.profileid = @empid
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllGender = 1 and @OrGender = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllGender = 0 and @OrGender = 1
begin
select @Itemeligible = case when Gender in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'GENDER') then 1 else 0 end  from profile where profile.profileid = @empid
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllGender = 1 and @OrGender = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------Foreigner----------------------------------------------------

if @AllForeigner = 0 and @OrForeigner = 0   
begin
select @Itemeligible = case when Foreigner in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'FOREIGNER') then 1 else 0 end  from profile where profile.profileid = @empid
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllForeigner = 1 and @OrForeigner = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllForeigner = 0 and @OrForeigner = 1
begin
select @Itemeligible = case when Foreigner in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'FOREIGNER') then 1 else 0 end from profile where profile.profileid = @empid
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllForeigner = 1 and @OrForeigner = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------MilStatus----------------------------------------------------

if @AllMilStatus = 0 and @OrMilStatus = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 3, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'MILSTATUS') then 1 else 0 end  
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllMilStatus = 1 and @OrMilStatus = 0
begin
select @Itemeligible =1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllMilStatus = 0 and @OrMilStatus = 1
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 3, dateadd(d,1,@Date),null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'MILSTATUS')then 1 else 0 end 
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0  
end
if @AllMilStatus = 1 and @OrMilStatus = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------SocStatus----------------------------------------------------

if @AllSocStatus = 0 and @OrSocStatus = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 4, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'SOCSTATUS') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllSocStatus = 1 and @OrSocStatus = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllSocStatus = 0 and @OrSocStatus = 1
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 4, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'SOCSTATUS') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllSocStatus = 1 and @OrSocStatus = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

-----------------------------------------------Employer----------------------------------------------------

if @AllEmployer = 0 and @OrEmployer = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 10, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'EMPLOYERID') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllEmployer = 1 and @OrEmployer = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllEmployer = 0 and @OrEmployer = 1
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 10, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'EMPLOYERID') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllEmployer = 1 and @OrEmployer = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end



-----------------------------------------------Grade----------------------------------------------------

if @AllGrade  = 0 and @OrGrade = 0   
begin
select @Itemeligible = case when dbo.GetOldValue(@empid, 7, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'GRADE') then 1 else 0 end
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllGrade = 1 and @OrGrade = 0
begin
select @Itemeligible =1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllGrade = 0 and @OrGrade = 1
begin
select @Itemeligible = case when  dbo.GetOldValue(@empid, 7, dateadd(d,1,@Date), null) in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'GRADE') then 1 else 0 end
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllGrade = 1 and @OrGrade = 1
begin
select @Itemeligible =1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end


-----------------------------------------------Graduate----------------------------------------------------

if @AllGraduation = 0 and @OrGraduation = 0   
begin
select @Itemeligible = case when Graduate in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'GRADUATE') then 1 else 0 end  from profile where profile.profileid = @empid
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllGraduation = 1 and @OrGraduation = 0
begin
select @Itemeligible = 1
set @OReligible= @OReligible | @Itemeligible
set @Itemeligible = 0 
end
if @AllGraduation = 0 and @OrGraduation = 1
begin
select @Itemeligible = case when Graduate in (select EligibleForValue from EligibleFor where EligibleNo=@EligibleNo and  EligibleForField = 'GRADUATE') then 1 else 0 end  from profile where profile.profileid = @empid
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end
if @AllGraduation = 1 and @OrGraduation = 1
begin
select @Itemeligible = 1
set @ANDeligible= @ANDeligible & @Itemeligible
set @Itemeligible = 0 
end

------------------------------------------------------------
return @ANDeligible | @OReligible

END

GO

