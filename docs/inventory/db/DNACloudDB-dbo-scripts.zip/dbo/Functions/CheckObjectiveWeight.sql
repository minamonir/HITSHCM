
CREATE  FUNCTION [dbo].[CheckObjectiveWeight]  (@empid int,@objectiveId int, @PeriodNo smallint, @ObjStartdate smalldatetime, @ObjEnddate smalldatetime,@ObjWeight numeric (18,3),@TotalWeight numeric (18,3))
RETURNS bit 
AS
BEGIN
DECLARE @PeriodStart AS smalldatetime, @YearEnd AS smalldatetime,@PeriodEnd AS smalldatetime,@ObjTotalWeight AS numeric (18,3),@Accepted AS bit,@ChangedObjweight AS numeric (18,3)
DECLARE @setObjWeightBasedonCOS AS SMALLINT =0
SELECT @setObjWeightBasedonCOS = configvalue FROM sysparamconfig WHERE ConfigID='SetObjWeightBasedOnCOS'

SELECT @PeriodStart=CONVERT(smalldatetime,'01/01/'+str(DATEPART(YEAR,@ObjStartdate)),120)
, @YearEnd=CONVERT(smalldatetime,'12/31/'+str(DATEPART(YEAR,@ObjStartdate)),120)
,@PeriodEnd=@PeriodStart


WHILE @PeriodEnd<@YearEnd 
BEGIN

	SELECT  @PeriodEnd=dateadd(dd,-1,dateadd(MM,12/@PeriodNo,@PeriodStart))

IF @ObjStartdate BETWEEN @PeriodStart AND @PeriodEnd
BREAK
ELSE
	SET @PeriodStart=DATEADD(dd,1,@PeriodEnd)
END


------------------------------------------------------------------------
if @setObjWeightBasedonCOS =1
BEGIN
	DECLARE @effectivedate AS SMALLDATETIME 
	select @effectivedate = max(empstatushdr.EffectiveDate) 
	FROM empstatushdr 
	LEFT JOIN empstatusdtl ON empstatusdtl.EmpId = empstatushdr.EmpId AND empstatusdtl.DocumentNo = empstatushdr.DocumentNo
	WHERE empstatushdr.empid =@empid and empstatushdr.DocumentStatus=1 AND  empstatusdtl.FieldNo=5 AND empstatushdr.EffectiveDate BETWEEN @PeriodStart AND @PeriodEnd
	
		if @effectivedate is not null

	begin
	if @objstartdate <@effectivedate set @periodend =@effectivedate
	else 	set @PeriodStart=ISNULL(@effectivedate,@PeriodStart)
	end

END
-------------------------------------------------------------------------

SELECT @ObjTotalWeight=sum(objectiveWeight) FROM EmpObjectives WHERE EmpId=@empid AND AssignStartDate BETWEEN @PeriodStart AND @PeriodEnd AND ObjectiveStatus IN (1,5,6) --AND ObjectiveId<>@objectiveId --AND AssignStartDate<>@ObjStartdate
SELECT @ChangedObjweight= sum(CASE WHEN empobjectives.ObjectiveStatus  IN (1,5,6) then objectiveWeight ELSE 0 END ) 
                          FROM EmpObjectives WHERE EmpId=@empid AND EmpObjectives.AssignStartDate=@ObjStartdate AND ObjectiveId=@objectiveId
                          
IF isnull(@ObjTotalWeight,0)+isnull(@ObjWeight,0)-isnull(@ChangedObjweight,0)>@TotalWeight
SET @Accepted=0
ELSE
SET @Accepted=1

RETURN  @Accepted 
END

GO

