
--This fn returns the number of coins representing an amount for a specified currency

CREATE  FUNCTION dbo.CoinAnalysis
	(@coincur int,  @coinamount numeric(18,3), @coinno smallint)
RETURNS  numeric(18,3)
AS
BEGIN
--round method 1=arithmatic  2=up  3=down  
declare @returnamount  as numeric(18,3), @cointemp as numeric(18,3), @coinnotemp smallint,  @coinremain as numeric(18,3)

set @coinnotemp=1
set @coinremain=@coinamount

while @coinnotemp<=@coinno
  begin
    if @coinnotemp=1 select  @cointemp=coin1 from currency where cur=@coincur
    if @coinnotemp=2 select  @cointemp=coin2 from currency where cur=@coincur
    if @coinnotemp=3 select  @cointemp=coin3 from currency where cur=@coincur
    if @coinnotemp=4 select  @cointemp=coin4 from currency where cur=@coincur
    if @coinnotemp=5 select  @cointemp=coin5 from currency where cur=@coincur
    if @coinnotemp=6 select  @cointemp=coin6 from currency where cur=@coincur
    if @coinnotemp=7 select  @cointemp=coin7 from currency where cur=@coincur
    if @coinnotemp=8 select  @cointemp=coin8 from currency where cur=@coincur
    if @coinnotemp=9 select  @cointemp=coin9 from currency where cur=@coincur
    if @coinnotemp=10 
        begin       
           set @returnamount=@coinremain
           break
       end  
    if (@cointemp<>0 ) 
       begin
         set @returnamount=floor(@coinremain/@cointemp)
         set @coinremain=@coinremain-@returnamount*@cointemp
       end
    else set @returnamount=0
    set @coinnotemp=@coinnotemp+1
  end

return @returnamount
END

GO

