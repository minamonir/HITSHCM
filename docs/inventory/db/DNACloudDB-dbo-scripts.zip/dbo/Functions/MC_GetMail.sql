CREATE  FUNCTION [dbo].[MC_GetMail] (@RoleProfileid  as INT,@Empid  as int, @MCID AS UNIQUEIDENTIFIER, @MCDocNo as INT, @action as INT
,@SSNewStatus as int  ,@ActionResaon as Nvarchar(max) ,
@ProfileID as int , @EMailAction as INT,
  @Latinlang as nchar(1),@SMSorMail AS int)
	RETURNS    NVARCHAR(max)
AS

BEGIN
declare @propname as nvarchar(150) 
select @propname=propname  from SysParam

--@SMSorMail=0  --> for sms , @SMSorMail=1 --> for mail 
declare @English as nchar(1)='E',@Foreign AS NCHAR(1)='F',@Switchlang AS NCHAR(1)
-- for Merck turkey use  SELECT @English='F' , @Foreign='E'
SELECT @English=SysParamConfig.ConfigValue  FROM SysParamConfig WHERE SysParamConfig.ConfigID='WFenglishlang'
SELECT @Foreign=SysParamConfig.ConfigValue  FROM SysParamConfig WHERE SysParamConfig.ConfigID='WFforiegnlang'
SELECT @Switchlang =case WHEN @Latinlang ='F' THEN (CASE WHEN @Foreign='E' THEN 'E' ELSE 'F' END )
                         WHEN @Latinlang ='E'  THEN (CASE WHEN @English='E' THEN 'E' ELSE 'F' END )
                         ELSE  'A' END
-----------------------------------------------------------------
declare @MCDocType as int,@BG_NAME AS NVARCHAR(max),@sswebsite as nvarchar(250)
select @MCDocType=MCDocType from MCdocument where MCDocNo = @MCDocNo 

---------==================Check this
SELECT @BG_NAME = ISNULL(ConfigValue,'') FROM dbo.SysParamConfig WHERE ConfigID='WorkflowApprovalRedirectBG'

IF @BG_NAME <> ''
BEGIN
	DECLARE @adal AS BIT 
	,@url_ltr AS NVARCHAR(max)='logon.aspx?ReturnUrl=%2fNasAgenda%2fAgendaPageGeneral.aspx%3fnodeselected%3d%26nodepage%3d26102%26navbar%3d10002%26iconitemno%3d26102%26ssdoctype%3d'
	,@url_rtl AS NVARCHAR(max)='logon_ar.aspx?ReturnUrl=%2fNasAgenda%2fAgendaPageGeneral_ar.aspx%3fnodeselected%3d%26nodepage%3d26102%26navbar%3d10002%26iconitemno%3d26102%26ssdoctype%3d'
	SELECT TOP 1 @adal= ISNULL(WindowsOnly,0) FROM dbo.NasUsers WHERE EmpId=@ProfileID
	select @sswebsite ='<a href="'+CASE WHEN RIGHT(sswebsite,1) = '/' THEN  sswebsite ELSE sswebsite +'/' END +CASE WHEN @Latinlang='A' THEN @url_rtl ELSE @url_ltr END+LTRIM(@MCDocType)+CASE WHEN @adal=1 THEN '&adal=1&tenantid=' ELSE '&tenantid=' END +@BG_NAME+'' +'">'+sswebsite+'</a>'
	from SysParam
END
ELSE
BEGIN
	select @sswebsite =sswebsite from SysParam
END 
---======================================
declare @assignmentid as int 
select @assignmentid = 0

DECLARE @ID NVARCHAR(50)
SELECT @ID = ISNULL((SELECT EmployeeId FROM EmpAssignment WHERE EmpId=@Empid),@Empid)



  

 declare @body as Nvarchar(max), @Tempbody as Nvarchar(max) , @TempMsg AS NVARCHAR (MAX),@SMSbody as nvarchar(max),@EMailbody as nvarchar(max)
 declare @TempbodySMS as Nvarchar(max),@TempBodyMail AS NVARCHAR(max)
 SELECT  @Tempbody='',@TempbodySMS='' ,@TempBodyMail =''
	 DECLARE @Msg2 AS nvarchar(max),@Msg3 AS nvarchar(max),@Msg4 AS nvarchar(max),@Msg5 AS nvarchar(max)
	 ,@Msg8 AS nvarchar(max),@ModuleMsg1 AS nvarchar(max),@ModuleMsg2 AS nvarchar(max),
	 @ModuleMsg3 AS nvarchar(max),@ModuleMsg4 AS nvarchar(max) ,@ModuleMsg5 AS nvarchar(max), @msg9 AS NVARCHAR(MAX) , @msg10  AS NVARCHAR(MAX)
	 ,@msg11  AS NVARCHAR(MAX), @msg12  AS NVARCHAR(MAX) , @msg13  AS NVARCHAR(MAX),  @msg14  AS NVARCHAR(MAX) , @msg15  AS NVARCHAR(MAX)
	 ,@msg16  AS NVARCHAR(MAX),  @msg17  AS NVARCHAR(MAX) , @msg18  AS NVARCHAR(MAX) ,@msg19  AS NVARCHAR(MAX),  @msg20  AS NVARCHAR(MAX) , @msg21  AS NVARCHAR(MAX)
	 , @msg22  AS NVARCHAR(MAX) ,@SeparatorEnter AS NVARCHAR(max)='',@SeparatorEnter2 AS NVARCHAR(max)=''
	 ,@MsgH AS nvarchar(max) ,@MsgSeparator AS NVARCHAR(MAX)
	 ,@ModuleMsg12 AS nvarchar(max),@TempMsgRole AS NVARCHAR(max),@TempMsgAction AS NVARCHAR(max)
	 ,@Recipient AS NVARCHAR(MAX) ,@days AS NVARCHAR(max),@MsgF AS nvarchar(max),@Msg6 AS nvarchar(max),@Msg7 AS nvarchar(max)
	 
	 SELECT @MsgSeparator=rtrim(ltrim(isnull(dbo.Hits_GetDCCaption('MCAction','separator',@latinlang),':')))    
	 ,@MsgH= isnull(dbo.Hits_GetDCCaption('MCAction','Header',@latinlang),'')
	 ,@MsgF=isnull(dbo.Hits_GetDCCaption('MCAction','Footer',@latinlang),'')
	 ,@Recipient=''
	 
	 SELECT  @Msg2= isnull(dbo.Hits_GetDCCaption('MCAction','2',@latinlang),(case when @latinlang='E' then 'request for employee'+@MsgSeparator else N'للموظف '+@MsgSeparator end))                          
	 , @Msg3= isnull(dbo.Hits_GetDCCaption('MCAction','3',@latinlang),(case when @latinlang='E' then 'has been approved by'+@MsgSeparator else N'قد تم الموافقة عليها بواسطة '+@MsgSeparator end))                          
	 , @Msg4= isnull(dbo.Hits_GetDCCaption('MCAction','4',@latinlang),(case when @latinlang='E' then 'has been rejected by'+@MsgSeparator else N'قد تم رفضها بواسطة '+@MsgSeparator end))                          
	 , @Msg5= isnull(dbo.Hits_GetDCCaption('MCAction','5',@latinlang),(case when @latinlang='E' then 'has been changed by'+@MsgSeparator else N'قد تم تغييرها بواسطة '+@MsgSeparator end))                          
	 SELECT @Msg6= LookupSelect FROM DataDictionary  WHERE TableName = 'MCAction' AND FieldName='6'
     SELECT @Msg7= LookupSelect FROM DataDictionary  WHERE TableName = 'MCAction' AND FieldName='7'                   
     SELECT @Msg8= isnull(dbo.Hits_GetDCCaption('MCAction','8',@latinlang),(case when @latinlang='E' then 'The reason is '+@MsgSeparator else N'السبب هو '+@MsgSeparator end))
     , @msg9 = ''
		 ,@SeparatorEnter=isnull(dbo.Hits_GetDCCaption('MCAction','SeparatorEnter' ,@latinlang),'<br>')
        --,@SeparatorEnter2=isnull(dbo.Hits_GetDCCaption('MCAction','SeparatorEnter2',@latinlang),'')  --enter for merck
        ,@days = isnull(dbo.Hits_GetDCCaption('MCAction','Days',@latinlang),(case when @latinlang='e' then 'Days' else N'ايام' end))
      
	
    SELECT @Msg6=CASE WHEN isnull(ltrim(rtrim(@Msg6)),'')=''  THEN (select dbo.Hits_GetDCCaption('MCAction','6',@latinlang))  ELSE ltrim(rtrim(@Msg6)) END 
    SELECT @Msg6= CASE WHEN isnull(ltrim(rtrim(@Msg6)),'')='' then (case when @latinlang='E' then 'Waiting for your action' else N'فى انتظار موافقتك على هذا الطلب' END) ELSE ltrim(rtrim(@Msg6)) END                           	   
    SELECT @Msg7=CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')=''  THEN ( dbo.Hits_GetDCCaption('MCAction','7',@latinlang)+' '+ CASE WHEN isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('MCAction','7',@latinlang))),'')<>'' AND @MCDocType<>20 THEN  ltrim(rtrim(@sswebsite)) ELSE '' end  )  ELSE ltrim(rtrim(@Msg7)) END 
    SELECT @Msg7= CASE WHEN isnull(ltrim(rtrim(@Msg7)),'')='' then (case when @latinlang='E' then 'Please visit the following site to check this request'+' '+ ltrim(rtrim(@sswebsite)) else N'برجاء زيارة هذا الموقع لمراجعة هذا الطلب' +' '+ CASE WHEN @MCDocType<>20 THEN  ltrim(rtrim(@sswebsite))ELSE '' END  end) ELSE ltrim(rtrim(@Msg7)) END                           	   

	-----------------Check here 
  
if  @MCDocType   = 15 -- Payroll
BEGIN
  	
  	 SELECT @ModuleMsg1= isnull(dbo.Hits_GetDCCaption('MCAction','Payroll',@latinlang),(case when @latinlang='E' then 'Payroll' else N'المرتبات' end))                                 
  			,@ModuleMsg2= isnull(dbo.Hits_GetDCCaption('MCAction','Payroll2',@latinlang),(case when @latinlang='E' then 'Amount' else N'المبلغ' end))
			,@ModuleMsg12= isnull(dbo.Hits_GetDCCaption('MCAction','Payroll3',@latinlang),(case when @latinlang='E' then 'Paycode' else N'بند' end))                                                                  
	 SELECT @msg16 =replace(LookupSelect,'@@syswebsite',@sswebsite) FROM DataDictionary WHERE TableName ='MCAction' AND FieldName ='Message7'
	  ---- for customer "merck"
  	--        , @msg9 =isnull(dbo.Hits_GetDCCaption('WFAction','Dear',@latinlang),'')
  	--        , @msg10=ISNULL(dbo.Hits_GetDCCaption('WFAction','Message1',@latinlang),'')  
	  --      , @msg11= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message2',@latinlang),'')
	  --      , @msg12 =ISNULL(dbo.Hits_GetDCCaption('WFAction','Message3',@latinlang),'')
	  --      , @msg13= ISNULL(dbo.Hits_GetDCCaption('WFAction','Message4',@latinlang),'')
	  --      , @msg14 =ISNULL(dbo.Hits_GetDCCaption('WFAction','KindRegards',@latinlang),'')
	  --      , @msg15= ISNULL(dbo.Hits_GetDCCaption('WFAction','TheMEHRteam',@latinlang),'')

	 select @body=ltrim(RTRIM(@MsgH))+' '+rtrim(@ModuleMsg1)+' '+ rtrim(@Msg2)+' '+CASE WHEN @latinlang='A' THEN ltrim(rtrim(Profile.aName)) ELSE ltrim(rtrim(Profile.Name)) END +
	 rtrim(ltrim(@SeparatorEnter))+' '+rtrim(@ModuleMsg12)+ rtrim(ltrim(@SeparatorEnter2))+rtrim(ltrim(@MsgSeparator))+' '+
	 CASE WHEN @Switchlang ='A' THEN ltrim(rtrim(Paycode.PayCodeAName )) WHEN @Switchlang='F' THEN  ltrim(rtrim(Paycode.PayCodeFName )) ELSE  ltrim(rtrim(Paycode.PayCodeName))  END +
	 CASE WHEN @msg9 ='' THEN ' ' ELSE   CHAR(13)+CHAR(10) END +rtrim(@ModuleMsg2)+' '+ LTRIM(RTRIM(STR(MCMonthlyTransaction.Amount)))
	 from profile
	 INNER JOIN dbo.MCMonthlyTransaction ON profile.ProfileId=MCMonthlyTransaction.EmpId 
	 AND MCMonthlyTransaction.MCID=@MCID
	 INNER JOIN	 dbo.Paycode ON Paycode.code = MCMonthlyTransaction.Paycode
	 where profileid = @Empid 
		
	IF  @msg9 ='' -- condition to check customer is not "merck" 
	BEGIN
      
		SELECT @TempMsgAction=CASE @action when 1 then ' '+rtrim(@Msg3)+' '  when 2 then  ' '+rtrim(@Msg4)+' '  when 3 THEN ' '+rtrim(@Msg5)+' ' END
		,@tempMsgRole= CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(aname)) ELSE rtrim(ltrim(name)) end from profile where profileid = @RoleProfileid
       
		SELECT @body = @Body +' '+  CASE WHEN @TempMsgAction LIKE '%@RoleName%' THEN @tempMsgRole +replace(@TempMsgAction,'@RoleName','') ELSE  @TempMsgAction + @tempMsgRole END
	END 
END	



--sms or mail part
	
SET @Tempbody=''

  	
-- for customer merck 
--IF  @msg9 <> '' 
--  	BEGIN
  	  	
--  		SELECT @TempMsg = rtrim(ltrim(@msg9)) +' '+ CASE WHEN @Latinlang ='A' THEN rtrim(ltrim(FirstAName)) ELSE rtrim(ltrim(FirstName)) END  from profile where profileid =@ProfileID 
--  		SELECT @TempMsg = @TempMsg +','+ CHAR(13)+CHAR(10) + CHAR(13)+CHAR(10)
  		
--  		IF @SSNewStatus IN (1,2) AND @SSDocType = 3       --vacation 
--  		BEGIN
--			SELECT @msg12 = CASE WHEN @SSNewStatus=2 THEN REPLACE(@msg12,'approved','rejected') ELSE @msg12 END
--			SELECT @msg12 = CASE WHEN @ProfileID <> @Empid  THEN REPLACE(@msg12,'your','employee') ELSE @msg12 END

--  		   	SET @EMailbody= @TempMsg +rtrim(ltrim(@msg12))+ nchar(13)+nchar(10)+ @body +nchar(13)+nchar(10)+nchar(13)+nchar(10) + +rtrim(ltrim(@msg13)) + nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
--  		END
--  		ELSE IF  @SSNewStatus = 0  AND @ProfileID <> @Empid   AND @RoleProfileid <> @ProfileID AND @SSDocType = 3 -- status not approved and manager and vacation 
--		BEGIN 
--  		    SET @EMailbody=@TempMsg + rtrim(ltrim(@msg10))+ nchar(13)+nchar(10)+ nchar(13)+nchar(10)+@body +nchar(13)+nchar(10) +nchar(13)+nchar(10)+rtrim(ltrim(@msg16))+nchar(13)+nchar(10)+nchar(13)+nchar(10)+rtrim(ltrim(@msg11)) + nchar(13)+nchar(10) +nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
--		END
--  		ELSE IF  @SSNewStatus = 2  AND @ProfileID <> @Empid AND @SSDocType = 9   -- status placed and manager and training 
--  		BEGIN
--  		    SET @EMailbody=@TempMsg +rtrim(ltrim(@msg10))+ nchar(13)+nchar(10)+@body +nchar(13)+nchar(10) + rtrim(ltrim(@msg11)) + nchar(13)+nchar(10) + rtrim(LTRIM(@msg14)) + nchar(13)+nchar(10) +rtrim(LTRIM(@msg15))
--  		END
--  		ELSE  
--		BEGIN
--  	        SET @EMailbody=@body
--  		END
--  	END
--  	ELSE
--  	BEGIN  			
  		
  	--END
SET @EMailbody=@body

if @SSNewStatus = 1 and  @profileid = @empid 
BEGIN
	set @EMailbody = @EMailbody + '. '
END

       
IF @EMailAction IN (1,4,5) AND (SELECT dbo.MC_GetWFActionType2(@ProfileID,@MCID,@Empid,@MCDocNo)) =1      
BEGIN
-- for customer is not merck 
	IF  @msg9 = ''
	BEGIN
		set @EMailbody = @EMailbody+@SeparatorEnter+@Msg6
	END
END
   --=======================================================  
IF @EMailAction =6
BEGIN
		set @EMailbody = @EMailbody+CHAR(13)+CHAR(10)
END       
--print @allemailto

SET @Tempbody=@EMailbody

 -- for customer is not merck 
if @msg9 = '' 
BEGIN
	IF  @MCDocType <> 20 OR (@MCDocType = 20 and  @profileid <> @empid )
	BEGIN

		if @ActionResaon<>'' 
		begin
			SET @Tempbody=@EMailbody+CHAR(13)+CHAR(10)+rtrim(ltrim(@Msg8))+' '+rtrim(ltrim(@ActionResaon))
			SET @Tempbody=@Tempbody+CHAR(13)+CHAR(10)+@Msg7
		END
		else
		begin
			SET @Tempbody=@EMailbody+CHAR(13)+CHAR(10)+@Msg7
		end

		SET @Tempbody=@Tempbody+CHAR(13)+CHAR(10)+CHAR(13)+CHAR(10)+@MsgF
		SELECT @Recipient = '' 
		SELECT @Recipient = LTRIM(RTRIM( CASE WHEN @latinlang ='A' THEN Profile.AName ELSE Profile.Name END )) FROM Profile WHERE Profile.ProfileId = @ProfileID
		SELECT @Tempbody = REPLACE(@Tempbody,'@Recipient',@Recipient)
	END 
end	 
--end sms or mail part
--SELECT @body=CASE WHEN @SmsOrMail=0 THEN @tempBodySMS ELSE @tempBodyMail end
SELECT @body=@tempBody
	RETURN  @body  
END

----------------------------------------------------------------------------------------------------------------------------

GO

