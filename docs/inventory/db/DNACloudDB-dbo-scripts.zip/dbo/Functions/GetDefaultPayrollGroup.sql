CREATE FUNCTION [dbo].[GetDefaultPayrollGroup] (@Org smallint) 
RETURNS int
AS
BEGIN
  DECLARE @OrgParent smallint
  DECLARE @Payrollgrp smallint

SET @Payrollgrp=null

SET @OrgParent=@Org
WHILE @Payrollgrp IS NULL 
BEGIN 
	SET @Payrollgrp =(SELECT PayrollGroup FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	IF @Payrollgrp IS NULL AND @OrgParent Is NULL
	BEGIN
		SET @Payrollgrp=(SELECT PayrollGroup FROM SysParam) BREAK
	END

END
return @Payrollgrp
END

GO

