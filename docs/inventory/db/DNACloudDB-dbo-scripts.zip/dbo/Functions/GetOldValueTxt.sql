
CREATE    FUNCTION [dbo].[GetOldValueTxt]
  (@FieldNo int, @OldValue numeric(18,3), @Language nchar(1))
	
RETURNS nvarchar(250)
AS
 BEGIN
 /* sql statement ... */
   declare @OldValueTxt nvarchar(250)
   declare @DecimalScale as smallint
   select @DecimalScale=DecimalScale from sysparam

   if @FieldNo>1000 or @FieldNo=20 set  @OldValueTxt=str(@OldValue,18,@DecimalScale)
   if @FieldNo=1 select @OldValueTxt=case when @Language='A' then hrstatusaname else hrstatusname end from hrstatus where hrstatus=@OldValue
   if @FieldNo=2 select @OldValueTxt=case when @Language='A' then adesc else edesc end from nasarrays where itemno=@OldValue and arrayname='taxstatus'
   if @FieldNo=3 select @OldValueTxt=case when @Language='A' then adesc else edesc end from nasarrays where itemno=@OldValue and arrayname='milstatus'
   if @FieldNo=4 select @OldValueTxt=case when @Language='A' then adesc else edesc end from nasarrays where itemno=@OldValue and arrayname='socstatus'
   if @FieldNo=5 select @OldValueTxt=case when @Language='A' then jobaname else jobname end from jobs where job=@OldValue
   if @FieldNo=6 select @OldValueTxt=case when @Language='A' then organizationaname else organizationname end from organization
       where organization=@OldValue
   if @FieldNo=7 select @OldValueTxt=case when @Language='A' then gradeaname else gradename end from grades
       where grade=@OldValue
   if @FieldNo=8 select @OldValueTxt=case when @Language='A' then positionaname else positionname end from positions
       where positionno=@OldValue
   if @FieldNo=9 select @OldValueTxt=case when @Language='A' then locationaname else locationname end from location
       where locationno=@OldValue
   if @FieldNo=10 select @OldValueTxt=case when @Language='A' then employeraname else employername end from employer
       where employerid=@OldValue
	if @FieldNo=11 
	BEGIN
	  IF DB_NAME() LIKE '%CL000106%'
	  select @OldValueTxt=case when @Language='A' then payrollgroupaname else payrollgroupname end from payrollgroup  where payrollgroup=@OldValue   
	  ELSE
	  select @OldValueTxt=case when @Language='A' then adesc else edesc end from nasarrays where itemno=@OldValue and arrayname='scstatus'  
	END

   if @FieldNo=12 select @OldValueTxt=case when @OldValue=1 then (case when @Language='A' then N'نعم' else 'Yes' end) else 
           (case when @Language='A' then N'لا' else 'No' end) end 
  
   if @FieldNo>=13 and @FieldNo<=18 set @OldValueTxt=str(@OldValue,18,@DecimalScale)
   if @FieldNo=19 select @OldValueTxt=case when @Language='A' then VacPackAName else VacPackName end from  VacPack where VacPack=@OldValue
   if @FieldNo=21 select @OldValueTxt=case when @Language='A' then SSGroupAName else SSGroupName end from  SSGroup where SSGroup=@OldValue
   if @FieldNo=22 select @OldValueTxt=case when @Language='A' then SalaryScaleAName else SalaryScaleName end from  SalaryScales where SalaryScaleid=@OldValue
   if @FieldNo=23 select @OldValueTxt=case when @Language='A' then ContractAName else ContractName end from  ContractType where ContractType=@OldValue
   if @FieldNo=28 select @OldValueTxt=case when @Language='A' then TRuleADesc else TRuleDesc end FROM TimeRules where TimeRule=@OldValue   
   if @FieldNo=29 select @OldValueTxt=case when @Language='A' then SInsurAName else SInsurName end from  dbo.SsRules where sscode=@OldValue

   if @FieldNo>=24 and @FieldNo<=27 select @OldValueTxt=case when @OldValue=0 then N'' else case 
    when sysparam.DateFormat=1 then substring(str(@OldValue,8),7,2)+'/'+substring(str(@OldValue,8),5,2)+'/'+substring(str(@OldValue,8),1,4)
    when sysparam.DateFormat=2 then substring(str(@OldValue,8),5,2)+'/'+substring(str(@OldValue,8),7,2)+'/'+substring(str(@OldValue,8),1,4) 
    else substring(str(@OldValue,8),1,4)+'/'+substring(str(@OldValue,8),5,2)+'/'+substring(str(@OldValue,8),7,2) end end from sysparam
return isnull(@oldvaluetxt,N'')
 
END

GO

