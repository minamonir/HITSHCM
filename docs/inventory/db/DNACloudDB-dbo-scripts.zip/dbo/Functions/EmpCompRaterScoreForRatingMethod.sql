


CREATE  FUNCTION [dbo].[EmpCompRaterScoreForRatingMethod] (@empid as int,@DocumentNo as int ,@RaterProfileid as int,@RatingMethod AS int)  
RETURNS numeric(18,3)  AS  
BEGIN
	---@RatingMethod =0   performance
	---@RatingMethod =1   proficiency
	
declare @Competence As   smallint ,@PerformaceLevel As   smallint ,@RatingLevel As   smallint
declare  @RatingScale as int , @LevelPercent as  numeric(18,3), 
@PLevelPercent as  numeric(18,3), @WieghtPercent as  numeric(18,3)
declare  @Score as  numeric(18,3),@Performancecount as int , 
@Proficiencycount as int ,@SWieght as  numeric(18,3) 


declare @Appraisalno as int

SELECT     @Appraisalno= Appraisals.Appraisalno , @RatingScale=Appraisals.RatingScale  
FROM Appraisals inner join EmpAppraisal on Appraisals.AppraisalNo=EmpAppraisal.AppraisalNo
WHERE     (EmpAppraisal.EmpId = @EmpId) AND (EmpAppraisal.DocumentNo = @DocumentNo)


declare InsertRows cursor for 
select   EmpAppraisalComp.Competence ,EmpAppraisalComp.PerformaceLevel , EmpAppraisalComp.RatingLevel  
from EmpAppraisalComp 
left JOIN  dbo.AppraisalCompetencies  ON dbo.AppraisalCompetencies.Competence = dbo.EmpAppraisalComp.Competence
where EmpId = @EmpId and DocumentNo=@DocumentNo  and RaterProfileid =  case when @RaterProfileid = 0
then RaterProfileid else @RaterProfileid end  and (dbo.AppraisalCompetencies.AppraisalNo = @Appraisalno) 

if @RatingMethod = 1 
begin
SELECT  @SWieght = sum(isnull(dbo.AppraisalCompetencies.Weight,1)) 
FROM  dbo.AppraisalCompetencies INNER JOIN
dbo.EmpAppraisalComp ON dbo.AppraisalCompetencies.Competence = dbo.EmpAppraisalComp.Competence INNER JOIN
dbo.LevelsCompetence ON dbo.EmpAppraisalComp.Competence = dbo.LevelsCompetence.Competence AND 
dbo.EmpAppraisalComp.RatingLevel = dbo.LevelsCompetence.RatingLevel
WHERE     (dbo.AppraisalCompetencies.AppraisalNo = @Appraisalno) 
AND (dbo.EmpAppraisalComp.EmpId = @EmpId) AND (dbo.EmpAppraisalComp.DocumentNo = @DocumentNo) AND 
(dbo.LevelsCompetence.LevelPercent >=0)
and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid end
END

if @RatingMethod = 0
BEGIN
SELECT  @SWieght = sum(isnull(dbo.AppraisalCompetencies.Weight,1)) 
FROM         dbo.AppraisalCompetencies INNER JOIN
dbo.EmpAppraisalComp ON dbo.AppraisalCompetencies.Competence = dbo.EmpAppraisalComp.Competence INNER JOIN
dbo.LevelsCompetence ON dbo.EmpAppraisalComp.Competence = dbo.LevelsCompetence.Competence AND 
dbo.EmpAppraisalComp.PerformaceLevel = dbo.LevelsCompetence.RatingLevel
WHERE     (dbo.AppraisalCompetencies.AppraisalNo = @Appraisalno) 
AND (dbo.EmpAppraisalComp.EmpId = @EmpId) AND (dbo.EmpAppraisalComp.DocumentNo = @DocumentNo) AND 
(dbo.LevelsCompetence.LevelPercent >=0)
and RaterProfileid =  case when @RaterProfileid = 0 then RaterProfileid else @RaterProfileid END
end

if @SWieght = 0 set @SWieght = 1  set @Score = 0

OPEN InsertRows
FETCH NEXT FROM InsertRows INTO  @Competence ,@PerformaceLevel ,@RatingLevel
WHILE @@FETCH_STATUS = 0
 BEGIN
 	
if  @RatingMethod = 1
BEGIN
	SELECT @LevelPercent = isnull(LevelPercent,0)   FROM LevelsCompetence where Competence=@Competence and RatingLevel = @RatingLevel
	SELECT @WieghtPercent = isnull(AppraisalCompetencies.Weight,1)  FROM  AppraisalCompetencies where Appraisalno=@Appraisalno  and Competence=@Competence
    if @WieghtPercent = 0 set @WieghtPercent = 1
    set @Score = @Score+ case when @LevelPercent>0 then(@LevelPercent*(@WieghtPercent/ @SWieght))else 0 END
end

if  @RatingMethod = 0
BEGIN
	SELECT @pLevelPercent = isnull(LevelPercent,0)   FROM RatingLevels where RatingScale=@RatingScale and RatingLevel = @PerformaceLevel
	SELECT @WieghtPercent = isnull(AppraisalCompetencies.Weight,1)  FROM  AppraisalCompetencies where Appraisalno=@Appraisalno  and Competence=@Competence
    if @WieghtPercent = 0 set @WieghtPercent = 1
set @Score = @Score+ case when @pLevelPercent>0 then(@pLevelPercent*(@WieghtPercent/ @SWieght))else 0 end	
END



FETCH NEXT FROM InsertRows INTO  @Competence ,@PerformaceLevel ,@RatingLevel
 End
CLOSE InsertRows
DEALLOCATE InsertRows
--print @count


set @Score =  round(@Score ,2,1) 
return  isnull(@Score,0)
end

GO

