CREATE FUNCTION [dbo].[IOTGetFullLocationName](@Location INT,@lang AS nchar,@report AS BIT)

--DECLARE @Location INT=10,@lang AS NCHAR='e',@report AS BIT=1
RETURNS nvarchar(max) AS  
begin
	IF  @Location IS NULL
	BEGIN
		RETURN ''
	END
	DECLARE @Locationparent  AS INT,@desc AS nvarchar(max),@separator AS NVARCHAR(MAX)
	sET @Locationparent=@Location
	SELECT @separator= CASE WHEN @report=0 THEN N'#$#' ELSE N','END

	SET @desc=N''

	WHILE @Locationparent IS NOT NULL AND EXISTS(SELECT IOTDeviceLocations.IOTDeviceLocationParent FROM IOTDeviceLocations WHERE IOTDeviceLocations.IOTDeviceLocation=@Locationparent AND IOTDeviceLocations.IOTDeviceLocationType IS NOT NULL) 
	begin
		SELECT @desc=@desc+CASE WHEN @lang=N'a' THEN ISNULL(rtrim(ltrim(IOTDeviceLocationTypes.IOTDeviceLocationTypeAName)),N'') +' '+ isnull(rtrim(ltrim(IOTDeviceLocations.IOTDeviceLocationAName))+@separator,N'') 
		ELSE isnull(rtrim(ltrim(IOTDeviceLocations.IOTDeviceLocationName)),N'')+' '+isnull(rtrim(ltrim(IOTDeviceLocationTypes.IOTDeviceLocationTypeName))+@separator,N'') end
		,@Locationparent=IOTDeviceLocations.IOTDeviceLocationParent 
		FROM IOTDeviceLocations 
		INNER JOIN IOTDeviceLocationTypes ON IOTDeviceLocationTypes.IOTDeviceLocationType = IOTDeviceLocations.IOTDeviceLocationType
		WHERE IOTDeviceLocations.IOTDeviceLocation=@Locationparent AND IOTDeviceLocations.IOTDeviceLocationType IS NOT NULL

	END

	SELECT @desc=SUBSTRING(@desc,0,LEN(@desc)-LEN(@separator)+1)
	SELECT @desc= CASE WHEN @desc = '' THEN CASE WHEN @lang=N'a' THEN IOTDeviceLocations.IOTDeviceLocationAName ELSE IOTDeviceLocations.IOTDeviceLocationName END ELSE @desc END 
	FROM IOTDeviceLocations 
	WHERE IOTDeviceLocations.IOTDeviceLocation=@Location

	RETURN @desc

--select @desc
end

GO

