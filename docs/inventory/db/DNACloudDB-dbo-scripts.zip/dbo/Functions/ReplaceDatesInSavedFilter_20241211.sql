
CREATE FUNCTION [dbo].[ReplaceDatesInSavedFilter_20241211] (
    
    @LogonName NVARCHAR(80), @Lang Nvarchar(1) ,@filterStr NVARCHAR(MAX) , @EnglishLike int
)
RETURNS NVARCHAR(MAX)
AS

--declare @LogonName NVARCHAR(80) = '1',@filterStr NVARCHAR(MAX)=
--'AND ( EMPASSIGNMENT.HIREDATE Between ''@PayrollYearStartDate'' and ''@PayrollYearEndDate'')',@Lang Nvarchar(1) = 'E' ,@EnglishLike int =1

BEGIN

IF ISNULL(@filterStr,'')<>'' 
BEGIN
	IF @EnglishLike = 1
	BEGIN
		SET @filterStr = REPLACE(@filterStr, '@Today', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@Today', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@Yesterday', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@Yesterday', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthStartDate',[dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarMonthStartDate', @Lang) );
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarYearEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollMonthStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollMonthStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollYearEndDate', @Lang));

	END
	ELSE
	BEGIN
		SET @filterStr = REPLACE(@filterStr, '@Today', FORMAT(GETDATE(), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@Yesterday', FORMAT(DATEADD(day, -1, GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@CalendarMonthStartDate''', 'FORMAT(CONVERT(smalldatetime, LTRIM(RTRIM(CONVERT(VARCHAR, CMonth))) + ''/01/'' + LTRIM(RTRIM(CONVERT(VARCHAR, CYear))), 111), ''yyyyMMdd'')');
		SET @filterStr = REPLACE(@filterStr, '''@CalendarMonthEndDate''', 'FORMAT(DATEADD(d, -1, DATEADD(m, 1, CONVERT(SMALLDATETIME, LTRIM(RTRIM(CONVERT(VARCHAR, CYear))) + ''/'' + LTRIM(RTRIM(CONVERT(VARCHAR, CMonth))) + ''/01''))), ''yyyyMMdd'')');
		SET @filterStr = REPLACE(@filterStr, '''@CalendarYearStartDate''', 'FORMAT(CONVERT(smalldatetime, ''01/01/'' + LTRIM(RTRIM(CONVERT(VARCHAR, CYear))), 111), ''yyyyMMdd'')');
		SET @filterStr = REPLACE(@filterStr, '''@CalendarYearEndDate''', 'FORMAT(CONVERT(smalldatetime, ''12/31/'' + LTRIM(RTRIM(CONVERT(VARCHAR, CYear))), 111), ''yyyyMMdd'')');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollMonthStartDate''', 'PeriodStart');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollMonthEndDate''', 'PeriodEnd');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollYearStartDate''', 'PeriodYearStart');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollYearEndDate''', 'PeriodYearEnd');
	END
	END
    return @filterStr
END

GO

