-- return the no of days between @fromdate and @todate according to the vacation and the employee vacation package setup

CREATE FUNCTION [dbo].[ExcludeDayOffs]
(@fromDate datetime,@toDate datetime,@vacPack as int)
RETURNS numeric(18,3)
AS
BEGIN

declare @DecimalScale as smallint
select @DecimalScale=DecimalScale from sysparam

  declare @days numeric(18,3), @holidays int, @dayoffs int, @doffday1 int, @doffday2 int, 
 @tempdate DATETIME      
  set @days = 0.000
  --set @holidays=0
  set @dayoffs=0
  SET @vacpack=CASE WHEN @vacpack=0 THEN (SELECT defvacpack FROM sysparam)ELSE @vacpack end 
  --CASE WHEN @vacpack=0 THEN (SELECT TOP 1 vacpack.vacpack FROM vacpack)ELSE @vacpack end 
  set @tempdate=@fromdate
 

 -- set @days = datediff(day,@fromdate , @todate )+1


  WHILE (@tempdate <= @todate)
  BEGIN    
    --set @holidays=0
    set @dayoffs=0
   
    
      select @dayoffs = (case when  DATEPART(dw,@tempdate) =  v.doffday1 then 1 when   DATEPART(dw,@tempdate) =  v.doffday2 then 1 else 0 end ) 
        from vacpack v where v.vacpack=@vacpack and v.dofftype=1
        
        
         
      if @dayoffs <> 0 
      begin
        set  @days  = @days+ @dayoffs
      end       
   
    --if  @dayoffs=0
    --begin
    --  select @holidays= 1
    --    from holidays h where h.vacpack=@vacpack and h.holiday=1 and h.date = @tempdate
    --  if @holidays <> 0 
    --  begin
    --    set  @days  = @days + @holidays
    --  end
    --end
    set  @tempdate = @tempdate +1
  end 

 -----------------End While--------------


set @days=round(@days,@DecimalScale)
RETURN @days 
END

GO

