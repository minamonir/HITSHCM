CREATE    FUNCTION [dbo].[hr_history] (@mydate  smalldatetime , @today smalldatetime )
 RETURNS @hr TABLE 
	( organization int,
	job int,
       	positionno int, grade int,      
	locationno  int,employerid int,  
	hrstatus int,   NationId int,   
	Gender int,     Religion int,   
	SocStatus int,  Age  nvarchar(10),      
	TaxStatus int,   MilStatus int,
	HrScStatus int,  HrSSAppl int, 
	HrPoints int, HrBasicSal numeric (18,3) ,  
	HrTotalSal  numeric (18,3), HrSSFixVal  numeric (18,3),         
	HrSSVarVal  numeric (18,3)    ,  HrSSBonVal  numeric (18,3),         
	active_01    int,        hired_01 int,     
       	term_01   int,           transferin_01   int,     
	transferout_01 int,      active_02  int,         
             hired_02      int,       term_02     int,         
	transferin_02     int,   transferout_02      int)

AS
begin
DECLARE @monthstart as smalldatetime
DECLARE @yearstart as smalldatetime
--declare  @today smalldatetime
--set @today = GETDATE()
declare @calendar as nchar(1)
declare @hijridate as nchar(10)
declare @l_dateformat as smallint
--if @calendar is null  
set @calendar='G'


if @calendar='G'
   begin   
       set @monthstart = DATEadd(dd,-1*datepart(dd,@mydate)+1,@mydate) 
       set @yearstart = dateadd(mm,-1*month(@mydate)+1,dateadd(dd,-1*day(@mydate)+1,@mydate))
  end
else
  begin
       set @hijridate=dbo.greg2hijri(@mydate,'O')
       set @hijridate=substring(@hijridate,1,8)+'01'
       set @hijridate= CASE when @l_dateformat=0 then @hijridate
                                         when @l_dateformat=1 then '01/'+substring(@hijridate,6,2)+'/'+substring(@hijridate,1,4)
                                         when @l_dateformat=2 then substring(@hijridate,6,2)+'/01/'+substring(@hijridate,1,4) end
       set @monthstart=dbo.hijri2greg(@hijridate)
       set @hijridate= CASE when @l_dateformat=0 then substring(@hijridate,1,4)+'/01/01'
                                         when @l_dateformat=1 then '01/01/'+substring(@hijridate,7,4)
                                         when @l_dateformat=2 then '01/01/'+substring(@hijridate,7,4) end
       set @yearstart=dbo.hijri2greg(@hijridate)
   end

insert @hr SELECT empassignment.organization, empassignment.job, empassignment.positionno,
 empassignment.grade, empassignment.locationno, empassignment.employerid,
 empassignment.hrstatus, profile.nationid, profile.Gender, profile.religion,
 profile.socstatus, dbo.HITS_CalcAge(profile.birthdate,@mydate) as Age,
 empassignment.HRTaxStat as taxstatus, Profile.MilStatus, empassignment.HrScStatus, empassignment.HrSSAppl,
 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then empassignment.HrPoints else 0 end) +
 SUM(case when (hiredate between @monthstart and @mydate) then empassignment.HrPoints else 0 end) -
 SUM(case when (termdate between @monthstart and @mydate) then empassignment.HrPoints else 0 end) AS HrPoints,

 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then empassignment.HrBasicSal else 0 end) +
 SUM(case when (hiredate between @monthstart and @mydate) then empassignment.HrBasicSal else 0 end) -
 SUM(case when (termdate between @monthstart and @mydate) then empassignment.HrBasicSal else 0 end) AS HrBasicSal,

 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then empassignment.HrTotalSal else 0 end) +
 SUM(case when (hiredate between @monthstart and @mydate) then empassignment.HrTotalSal else 0 end) -
 SUM(case when (termdate between @monthstart and @mydate) then empassignment.HrTotalSal else 0 end) AS HrTotalSal,

 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then empassignment.HrSSFixVal else 0 end) +
 SUM(case when (hiredate between @monthstart and @mydate) then empassignment.HrSSFixVal else 0 end) -
 SUM(case when (termdate between @monthstart and @mydate) then empassignment.HrSSFixVal else 0 end) AS HrSSFixVal,

 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then empassignment.HrSSVarVal else 0 end) +
 SUM(case when (hiredate between @monthstart and @mydate) then empassignment.HrSSVarVal else 0 end) -
 SUM(case when (termdate between @monthstart and @mydate) then empassignment.HrSSVarVal else 0 end) AS HrSSVarVal,

 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then empassignment.HrSSBonVal else 0 end) +
 SUM(case when (hiredate between @monthstart and @mydate) then empassignment.HrSSBonVal else 0 end) -
 SUM(case when (termdate between @monthstart and @mydate) then empassignment.HrSSBonVal else 0 end) AS HrSSBonVal,

 SUM(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null)
 then 1 else 0 end) AS active_01,
 SUM(case when (hiredate between @monthstart and @mydate) then 1 else 0 end) AS hired_01,
 SUM(case when (termdate between @monthstart and @mydate) then 1 else 0 end) AS term_01, 

 max(0) as transferin_01,
 max(0) as transferout_01,

 SUM(case when hiredate< @yearstart AND (termdate>= @yearstart OR termdate is null)
 then 1 else 0 end) AS active_02,

 SUM(case when (hiredate between @yearstart and @mydate) then 1 else 0 end) AS hired_02,

 SUM(case when (termdate between @yearstart and @mydate) then 1 else 0 end) AS term_02, 

 max(0) as transferin_02,
 max(0) as transferout_02

 FROM empassignment LEFT JOIN profile ON empassignment.empid=profile.profileid
 group by organization, job, positionno, grade, locationno, employerid,
  empassignment.hrstatus, profile.nationid, profile.Gender, profile.religion,
  profile.socstatus, dbo.HITS_CalcAge(profile.birthdate, @mydate), empassignment.HRTaxStat,
  Profile.MilStatus, empassignment.HrScStatus, empassignment.HrSSAppl

union

select hrhistory.organization, hrhistory.job, hrhistory.positionno, hrhistory.grade,
 hrhistory.locationno, hrhistory.employerid, hrhistory.hrstatus, profile.nationid,
 profile.gender, profile.religion, hrhistory.socstatus, 
 dbo.HITS_CalcAge(profile.birthdate, @mydate) as Age, hrhistory.TaxStatus,
 hrhistory.MilStatus, hrhistory.HrScStatus, hrhistory.HrSSAppl,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus*hrhistory.HrPoints else 0 end)+
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrPoints else 0 end)-
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrPoints else 0 end)+
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrPoints else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrPoints else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end))-
 ((sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrPoints else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrPoints else 0 end))+
  (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end))-
  (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrPoints else 0 end)))
 as HrPoints,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus*hrhistory.HrBasicSal else 0 end)+
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrBasicSal else 0 end)-
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrBasicSal else 0 end)+
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrBasicSal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrBasicSal else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end))-
 ((sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrBasicSal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrBasicSal else 0 end))+
  (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end))-
  (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrBasicSal else 0 end)))
 as HrBasicSal,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus*hrhistory.HrTotalSal else 0 end)+
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrTotalSal else 0 end)-
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrTotalSal else 0 end)+
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrTotalSal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrTotalSal else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end))-
 ((sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrTotalSal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrTotalSal else 0 end))+
  (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end))-
  (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrTotalSal else 0 end)))
 as HrTotalSal,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus*hrhistory.HrSSFixVal else 0 end)+
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrSSFixVal else 0 end)-
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrSSFixVal else 0 end)+
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSFixVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSFixVal else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end))-
 ((sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSFixVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSFixVal else 0 end))+
  (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end))-
  (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrSSFixVal else 0 end)))
 as HrSSFixVal,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus*hrhistory.HrSSVarVal else 0 end)+
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrSSVarVal else 0 end)-
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrSSVarVal else 0 end)+
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSVarVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSVarVal else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end))-
 ((sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSVarVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSVarVal else 0 end))+
  (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end))-
  (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrSSVarVal else 0 end)))
 as HrSSVarVal,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus*hrhistory.HrSSBonVal else 0 end)+
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrSSBonVal else 0 end)-
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus*hrhistory.HrSSBonVal else 0 end)+
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSBonVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSBonVal else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end))-
 ((sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSBonVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then hrhistory.HrSSBonVal else 0 end))+
  (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end))-
  (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end)-
   sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then hrhistory.HrSSBonVal else 0 end)))
 as HrSSBonVal,

 sum(case when hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then -1*recordstatus else 0 end) as active_01,
 sum(case when (hiredate between @monthstart and @mydate) then -1*recordstatus else 0 end) AS hired_01,
 sum(case when (termdate between @monthstart and @mydate) then -1*recordstatus else 0 end) AS term_01,
 (sum(case when recordstatus=1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then 1 else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then 1 else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @monthstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then 1 else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @monthstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then 1 else 0 end))
 as transferin_01,

 (sum(case when recordstatus=-1 and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then 1 else 0 end)-
  sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @monthstart AND (termdate>= @monthstart OR termdate is null) then 1 else 0 end))+
 (sum(case when recordstatus=-1 and (hiredate between @monthstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @monthstart and @mydate) then 1 else 0 end))-
 (sum(case when recordstatus=-1 and (termdate between @monthstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @monthstart and @mydate) then 1 else 0 end))
 AS transferout_01,

 max(0) AS active_02,
 max(0) AS hired_02,
 max(0) AS term_02, 
 max(0) as transferin_02,
 max(0) AS transferout_02
 from hrhistory inner join empassignment on empassignment.empid = hrhistory.empid 
 inner join profile on empassignment.empid=profile.profileid
 where (effectivedate between @monthstart and @today)
 group by hrhistory.organization, hrhistory.job, hrhistory.positionno, hrhistory.grade,
  hrhistory.locationno, hrhistory.employerid, hrhistory.hrstatus, profile.nationid,
  profile.Gender, profile.religion, hrhistory.socstatus,
  dbo.HITS_CalcAge(profile.birthdate,@mydate), hrhistory.TaxStatus, hrhistory.MilStatus,
  hrhistory.HrScStatus, hrhistory.HrSSAppl, hrhistory.HrPoints,
  hrhistory.HrBasicSal, hrhistory.HrTotalSal, hrhistory.HrSSFixVal,
  hrhistory.HrSSVarVal, hrhistory.HrSSBonVal
union

select hrhistory.organization, hrhistory.job, hrhistory.positionno, hrhistory.grade,
 hrhistory.locationno, hrhistory.employerid, hrhistory.hrstatus, profile.nationid,
 profile.gender, profile.religion, hrhistory.socstatus,
 dbo.HITS_CalcAge(profile.birthdate,@mydate) as Age, hrhistory.TaxStatus,
 hrhistory.MilStatus, hrhistory.HrScStatus, hrhistory.HrSSAppl,
 hrhistory.HrPoints, hrhistory.HrBasicSal, hrhistory.HrTotalSal,
 hrhistory.HrSSFixVal, hrhistory.HrSSVarVal, hrhistory.HrSSBonVal,
 max(0) AS active_01,
 max(0) AS hired_01,
 max(0) AS term_01, 
 max(0) as transferin_01, 
 max(0) as transferout_01,

 sum(case when hiredate< @yearstart AND (termdate>= @yearstart OR termdate is null) then -1*recordstatus else 0 end) as active_02,
 sum(case when (hiredate between @yearstart and @mydate) then -1*recordstatus else 0 end) AS hired_02,
 sum(case when (termdate between @yearstart and @mydate) then -1*recordstatus else 0 end) AS term_02,
 (sum(case when recordstatus=1 and hiredate< @yearstart AND (termdate>= @yearstart OR termdate is null) then 1 else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and hiredate< @yearstart AND (termdate>= @yearstart OR termdate is null) then 1 else 0 end))+
 (sum(case when recordstatus=1 and (hiredate between @yearstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (hiredate between @yearstart and @mydate) then 1 else 0 end))-
 (sum(case when recordstatus=1 and (termdate between @yearstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=1 and effectivedate>@mydate and (termdate between @yearstart and @mydate) then 1 else 0 end))
 as transferin_02,

 (sum(case when recordstatus=-1 and hiredate< @yearstart AND (termdate>= @yearstart OR termdate is null) then 1 else 0 end)-
  sum(case when recordstatus=-1 and effectivedate>@mydate and hiredate< @yearstart AND (termdate>= @yearstart OR termdate is null) then 1 else 0 end))+
 (sum(case when recordstatus=-1 and (hiredate between @yearstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=-1 and effectivedate>@mydate and (hiredate between @yearstart and @mydate) then 1 else 0 end))-
 (sum(case when recordstatus=-1 and (termdate between @yearstart and @mydate) then 1 else 0 end)-
  sum(case when recordstatus=-1 and effectivedate>@mydate and (termdate between @yearstart and @mydate) then 1 else 0 end))
 AS transferout_02

 from hrhistory inner join empassignment on empassignment.empid = hrhistory.empid 
 inner join profile on empassignment.empid=profile.profileid
 where (effectivedate between @yearstart and @today)
 group by hrhistory.organization, hrhistory.job, hrhistory.positionno, hrhistory.grade,
  hrhistory.locationno, hrhistory.employerid, hrhistory.hrstatus, profile.nationid,
  profile.Gender, profile.religion, hrhistory.socstatus,
  dbo.HITS_CalcAge(profile.birthdate,@mydate), hrhistory.TaxStatus,hrhistory.MilStatus,
  hrhistory.HrScStatus, hrhistory.HrSSAppl, hrhistory.HrPoints,
  hrhistory.HrBasicSal, hrhistory.HrTotalSal,hrhistory.HrSSFixVal,
  hrhistory.HrSSVarVal, hrhistory.HrSSBonVal

return	
end

GO

