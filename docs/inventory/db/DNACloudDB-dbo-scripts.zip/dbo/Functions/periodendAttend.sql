
CREATE  FUNCTION [dbo].[periodendAttend]
	(@payrollgroup int,@period int,@year int)
RETURNS smalldatetime
AS
BEGIN
 declare @attenddiffCalendar as bit 
 select @attenddiffCalendar=attenddiffCalendar from payrollgroup where payrollgroup=@payrollgroup	
 if @attenddiffCalendar = 0   return [dbo].[periodend](@payrollgroup ,@period ,@year )

  declare @thedate smalldatetime
  declare @dateformat smallint
  declare @enablehijri as bit
  declare @hijridate as nchar(10)
  declare @mstartfirst bit
  declare @mstartday int
  declare @NoofPeriods as smallint

--  if @year=0  select @year=cyear, @period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
   if @year=0  select @year=cyear from payrollgroup where payrollgroup=@payrollgroup			
   if @Period=0  select @Period=cmonth from payrollgroup where payrollgroup=@payrollgroup			
  select @NoofPeriods=NoofPeriods from payrollgroup where payrollgroup=@payrollgroup
  select @thedate=enddate from PayrollGroupAttendPeriods where payrollgroup=@payrollgroup and period= @period and year=@year

  if @thedate is null and @NoofPeriods=12
       begin
        select @dateformat=dateformat,  @enablehijri=enablehijri from sysparam
        select @mstartfirst=attendmstartfrst,@mstartday=attendmstartday from payrollgroup where payrollgroup = @payrollgroup
     -- advance the period by 1 to get next period start   
    if @period=12 
                begin
                   set @period=1 
                   set @year=@year+1 
               end      else set @period= @period+1
       
       if @enablehijri=1 and @year<1900
          begin
             if (@mstartfirst = 1 or @mstartday = 0 )    
                    set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(@period,2,1)+'/01'
                            when @dateformat=1 then '01/'+str(@period,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(@period,2,1)+'/01/'+str(@year,4,1) end
              else if  (@period=1)   
                              set @hijridate= CASE when @dateformat=0 then str(@year-1,4,1)+'/12/'+str(@mstartday,2,1)
                             when @dateformat=1 then str(@mstartday,2,1)+'/12/'+str(@year-1,4,1)
                                 when @dateformat=2 then '12/'+str(@mstartday,2,1)+'/'+str(@year-1,4,1) end
      
                    else set @hijridate= CASE when @dateformat=0 then str(@year,4,1)+'/'+str(@period-1,2,1)+'/'+str(@mstartday,2,1)
                             when @dateformat=1 then str(@mstartday,2,1)+'/'+str(@period-1,2,1)+'/'+str(@year,4,1)
                                 when @dateformat=2 then str(@period-1,2,1)+'/'+str(@mstartday,2,1)+'/'+str(@year,4,1) end
               select  @thedate=dbo.hijri2greg(@hijridate)
           end
       else
          begin          
               if (@mstartfirst = 1 or @mstartday = 0 )  set  @thedate= convert(smalldatetime,'01/'+str(@period,2,1)+'/'+str(@year,4,1),103)
                else   if  (@period=1)   set @thedate= convert(smalldatetime,str(@mstartday,2,1)+'/'+str(12,2,1)+'/'+str(@year-1,4,1),103) 
		else    set @thedate= convert(smalldatetime,str(@mstartday,2,1)+'/'+str(@period-1,2,1)+'/'+str(@year,4,1),103)
         end
       --deduct 1 from next period start to have the end of period  
       set  @thedate=dateadd(dd,-1,@thedate)
end
RETURN @thedate

END

GO

