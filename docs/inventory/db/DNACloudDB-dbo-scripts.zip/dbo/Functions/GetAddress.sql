CREATE FUNCTION [dbo].[GetAddress]
  (@addressid int, @lang nchar(1), @address nvarchar(254))
RETURNS  nvarchar(559)
as
BEGIN 
  declare @returnaddress as nvarchar(559)
declare @addressformat  nvarchar(559)	
,@countryname nvarchar(60), @provincename nvarchar(60), @cityname nvarchar(60), @areaname nvarchar(60), @policestname nvarchar(60)
  
  select @addressformat= Countries.CountryAddressFormat 
 ,@countryname= (CASE WHEN @lang=N'E' THEN ISNULL(Countries.CountryName,N'') ELSE ISNULL(Countries.CountryaName,N'') END)
 ,@provincename= (CASE WHEN @lang=N'E' THEN ISNULL(Provinces.ProvinceName,N'') ELSE ISNULL(Provinces.ProvinceaName,N'') END)
 ,@cityname= (CASE WHEN @lang=N'E' THEN ISNULL(Cities.CityName,N'') ELSE ISNULL(Cities.CityaName,N'') END)
 ,@areaname= (CASE WHEN @lang=N'E' THEN ISNULL(Areas.AreaName,N'') ELSE ISNULL(Areas.AreaAName,N'') END)
 ,@policestname= (CASE WHEN @lang=N'E' THEN ISNULL(PoliceStations.PoliceStationName,N'') ELSE ISNULL(PoliceStations.PoliceStationaName,N'') END)
	FROM Addresses 
	LEFT JOIN Countries ON Countries.Countryid = Addresses.CountryId
	LEFT JOIN Provinces ON Provinces.Provinceid = Addresses.ProvinceId
	LEFT JOIN	Cities  ON Cities.cityid = Addresses.CityId
	LEFT JOIN Areas ON Areas.Areaid = Addresses.AreaId
	LEFT JOIN PoliceStations ON PoliceStations.PoliceStationid = Addresses.PoliceStationId
	WHERE Addresses.AddressId=@addressid
  
  DECLARE @QM	 AS NVARCHAR(10),@delimeter AS nvarCHAR(10)
SELECT @QM=SUBSTRING(@addressformat,CHARINDEX(N'?',@addressformat),CHARINDEX(N'?',@addressformat,CHARINDEX(N'?',@addressformat)+1)-CHARINDEX(N'?',@addressformat)+1)


IF @lang = N'A' AND @addressformat <> N''
BEGIN
		 
DECLARE  @arabicFormat  nvarchar(250), @Oldaddressformat nvarchar(250)
SET @arabicFormat = N''
SET @Oldaddressformat = @addressformat

WHILE  charindex(@QM,@addressformat) > 0
BEGIN 

SET @arabicFormat = SUBSTRING(@addressformat , 0, charindex(@QM,@addressformat) ) + @QM + @arabicFormat
SET @addressformat = SUBSTRING(@addressformat, charindex(@QM,@addressformat)+LEN(@QM) , LEN(@addressformat))

END 
SET @arabicFormat = @addressformat + @QM + @arabicFormat
SET @addressformat = LEFT(@arabicFormat,LEN(@Oldaddressformat))

END 


IF isnull(@addressformat,N'')<>N''
BEGIN
SET @addressformat=case WHEN @countryname<> N'' THEN replace(@addressformat,N'COUNTRYID',rtrim(ltrim(@countryname))) WHEN Charindex(N'COUNTRYID'+@QM,@addressformat) > 0 THEN replace(@addressformat,N'COUNTRYID'+@QM,N'') ELSE replace(@addressformat,@QM+N'COUNTRYID',N'')  END
SET @addressformat=case WHEN @provincename<> N'' THEN replace(@addressformat,N'PROVINCEID',rtrim(ltrim(@provincename))) WHEN Charindex(N'PROVINCEID'+@QM,@addressformat) > 0 THEN replace(@addressformat,'PROVINCEID'+@QM,N'') ELSE replace(@addressformat,@QM+N'PROVINCEID',N'')  END 
SET @addressformat=case WHEN @cityname<> N'' THEN replace(@addressformat,N'CITYID',rtrim(ltrim(@cityname))) WHEN Charindex(N'CITYID'+@QM,@addressformat) > 0 THEN replace(@addressformat,N'CITYID'+@QM,N'') ELSE replace(@addressformat,@QM+N'CITYID',N'')  END 
SET @addressformat=case WHEN @areaname<> N'' THEN replace(@addressformat,N'AREAID',rtrim(ltrim(@areaname))) WHEN Charindex(N'AREAID'+@QM,@addressformat) > 0 THEN replace(@addressformat,N'AREAID'+@QM,N'') ELSE replace(@addressformat,@QM+N'AREAID',N'')  END 
SET @addressformat=case WHEN @policestname<> N'' THEN replace(@addressformat,N'POLICESTATIONID',rtrim(ltrim(@policestname))) WHEN Charindex(N'POLICESTATIONID'+@QM,@addressformat) > 0 THEN replace(@addressformat,N'POLICESTATIONID'+@QM,N'') ELSE replace(@addressformat,@QM+N'POLICESTATIONID',N'')  END 
SET @addressformat=case WHEN @address<> N'' THEN replace(@addressformat,N'ADDRESS', rtrim(ltrim(@address))) WHEN Charindex(N'ADDRESS'+@QM,@addressformat) > 0 THEN replace(@addressformat,N'ADDRESS'+@QM,N'') ELSE replace(@addressformat,@QM+N'ADDRESS',N'')  END 
SET @addressformat=replace(@addressformat, N'?', N'')
END
ELSE
BEGIN
	IF @lang = N'E'
	BEGIN 
	SET @addressformat=rtrim(ltrim(@address))+
	CASE WHEN @countryname=N'' THEN N'' ELSE N'-' END +rtrim(ltrim(@countryname))+
	CASE WHEN @provincename=N'' THEN N'' ELSE N'-' END +rtrim(ltrim(@provincename))+
	CASE WHEN @cityname=N'' THEN N'' ELSE N'-' END+rtrim(ltrim(@cityname))+
	CASE WHEN @areaname=N'' THEN N'' ELSE N'-' END+rtrim(ltrim(@areaname))+
	CASE WHEN @policestname=N'' THEN N'' ELSE N'-' END+rtrim(ltrim(@policestname))
	END 
	ELSE 
	BEGIN 
	SET @addressformat= rtrim(ltrim(@policestname)) +
	CASE WHEN @areaname=N'' THEN N'' ELSE N'-' END+rtrim(ltrim(@areaname))+
	CASE WHEN @cityname=N'' THEN N'' ELSE N'-' END+rtrim(ltrim(@cityname))+
	CASE WHEN @provincename=N'' THEN N'' ELSE N'-' END +rtrim(ltrim(@provincename))+
	CASE WHEN @countryname=N'' THEN N'' ELSE N'-' END +rtrim(ltrim(@countryname))+
	CASE WHEN @address=N'' THEN N'' ELSE N'-' END +rtrim(ltrim(@address)) 
	END 	
END

IF @addressid IS NULL
BEGIN
	SET @addressformat=@address
END

SET @returnaddress=@addressformat
  return @returnaddress
END

GO

