CREATE FUNCTION [dbo].[CompareTimeInOut](@Empid INT , @DocumentNo INT , @TimeIn as DATETIME,@TimeOut as DATETIME , @AttendType INT , @Lang NCHAR(1) ,@Type INT = 0)
RETURNS NVARCHAR(100)
BEGIN 

	-- @Type = 0 => From Self Service
	-- @Type = 1 => From Agenda

	-- @Calendar = 0 Use PayrollGroup(Start - End)
	-- @Calendar = 1 Use Calendar(Month Start - Month End)

	DECLARE @ErrorSum INT = 0 , @Errormsg NVARCHAR(100) = '', @Calendar INT = 1


	IF @TimeOut > @TimeIn
	BEGIN

	 IF NOT EXISTS ( SELECT  AttendTime
                    FROM    EmpTimeReadings
                    INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = EmpTimeReadings.TimeSystem
                    AND TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadings.ReaderValue ELSE EmpTimeReadings.FlagValue END
                    WHERE   TimeSystemLines.TimeSystem = EmpTimeReadings.TimeSystem 
					AND EmpTimeReadings.EmpId = @EmpId 
					AND AttendTime = CASE WHEN @AttendType = 1 THEN @TimeIn ELSE @TimeOut END 
					AND TimeLineType = @AttendType )
                    BEGIN
						
						IF EXISTS ( SELECT  *
                                    FROM    EmpTimeReadingsUncommitted
                                    WHERE   Empid = @EmpId
                                            AND DocumentNo = @DocumentNo )
                                    BEGIN
									   IF NOT EXISTS ( SELECT  *
                                        FROM    EmpTimeReadingsUncommitted
                                        INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
                                                              AND TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsUncommitted.ReaderValue ELSE EmpTimeReadingsUncommitted.FlagValue END
                                        WHERE   TimeSystemLines.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
                                                AND EmpTimeReadingsUncommitted.Empid = @EmpId
                                                AND AttendTime = CASE WHEN @AttendType = 1 THEN @TimeIn ELSE @TimeOut END 
                                                AND TimeLineType = @AttendType  AND DocumentNo <> @DocumentNo AND DocumentStatus IN (5 ,6)
												  )
												  BEGIN
													IF @AttendType = 1 
													BEGIN 
														IF ( @TimeIn BETWEEN DATEADD(day,-1,@TimeOut) AND @TimeOut ) --OR ( @TimeIn BETWEEN DATEADD(DAY,-1,@TimeOut) and @TimeOut )
														BEGIN 
															SELECT @Errormsg =  ''						
														END
														ELSE 
														BEGIN 
															SELECT @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','TimeInNotBelongTimeOut',@Lang),(case when @Lang='E' then 'TimeIn should be with in 24 hours.' else N'وقت الدخول يجب ان يكون فى خلال 24 ساعة' end))
														END 			
													END
													ELSE IF @AttendType = 2 
													BEGIN 
														IF ( @Timeout BETWEEN @TimeIn and DATEADD(day,1,@TimeIn) ) --OR ( @TimeIn BETWEEN DATEADD(DAY,-1,@TimeOut) and @TimeOut )
														BEGIN 
															SELECT @Errormsg =  ''						
														END
														ELSE 
														BEGIN 
															SELECT @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','TimeOutNotBelongTimeIn',@Lang),(case when @Lang='E' then 'TimeOut should be  with in 24 hours.' else N'وقت الخروج يجب ان يكون فى خلال 24 ساعة' end))
														END 
													END 
												END 
												ELSE
												BEGIN 
								-- SELECT @Errormsg  = dbo.Hits_GetDCCaption('EmpTimeReadingsUncommitted','InsertEmpTimeReadingsUncommitted','E') 
													SELECT @ErrorSum = @@ERROR + @ErrorSum
													SELECT  @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','ReadingInIncompleteTK',@Lang),(case when @Lang='E' then 'You have requested same reading before.' else N'لقد قمت بأدخال هذه القراءة من قبل' end))
													--RAISERROR(@Errormsg,16,1);
												END; 
                                    END		
									ELSE 
									BEGIN 							
									   IF NOT EXISTS ( SELECT  *
                                        FROM    EmpTimeReadingsUncommitted
                                        INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
                                                              AND TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsUncommitted.ReaderValue ELSE EmpTimeReadingsUncommitted.FlagValue END
                                        WHERE   TimeSystemLines.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
                                                AND EmpTimeReadingsUncommitted.Empid = @EmpId
                                                AND AttendTime = CASE WHEN @AttendType = 1 THEN @TimeIn ELSE @TimeOut END 
                                                AND TimeLineType = @AttendType 
												AND DocumentStatus NOT IN ( 2,3)
												  )
												BEGIN
													IF @AttendType = 1 
													BEGIN 
														IF ( @TimeIn BETWEEN DATEADD(day,-1,@TimeOut) AND @TimeOut ) --OR ( @TimeIn BETWEEN DATEADD(DAY,-1,@TimeOut) and @TimeOut )
														BEGIN 
															SELECT @Errormsg =  ''						
														END
														ELSE 
														BEGIN 
															SELECT @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','TimeInNotBelongTimeOut',@Lang),(case when @Lang='E' then 'TimeIn should be with in 24 hours.' else N'وقت الدخول يجب ان يكون فى خلال 24 ساعة' end))
														END 			
													END
													ELSE IF @AttendType = 2 
													BEGIN 
														IF ( @Timeout BETWEEN @TimeIn and DATEADD(day,1,@TimeIn) ) --OR ( @TimeIn BETWEEN DATEADD(DAY,-1,@TimeOut) and @TimeOut )
														BEGIN 
															SELECT @Errormsg =  ''						
														END
														ELSE 
														BEGIN 
															SELECT @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','TimeOutNotBelongTimeIn',@Lang),(case when @Lang='E' then 'TimeOut should be  with in 24 hours.' else N'وقت الخروج يجب ان يكون فى خلال 24 ساعة' end))
														END 
													END 
												END 
												ELSE
												BEGIN 
													-- SELECT @Errormsg  = dbo.Hits_GetDCCaption('EmpTimeReadingsUncommitted','InsertEmpTimeReadingsUncommitted','E') 
													SELECT @ErrorSum = @@ERROR + @ErrorSum
													SELECT  @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','ReadingInIncompleteTK',@Lang),(case when @Lang='E' then 'You have requested same reading before.' else N'لقد قمت بأدخال هذه القراءة من قبل' end))
													--RAISERROR(@Errormsg,16,1);
												END; 
									END 
					END  
					ELSE IF EXISTS (SELECT  *
						FROM EmpTimeReadingsUncommitted
						INNER JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
						AND TimeSystemLines.LineValues = CASE WHEN LineField = 1 THEN EmpTimeReadingsUncommitted.ReaderValue ELSE EmpTimeReadingsUncommitted.FlagValue END
						WHERE   TimeSystemLines.TimeSystem = EmpTimeReadingsUncommitted.TimeSystem
						AND EmpTimeReadingsUncommitted.Empid = @EmpId
						AND AttendTime = CASE WHEN @AttendType = 1 THEN @TimeIn ELSE @TimeOut END 
						AND TimeLineType = @AttendType AND DocumentNo = @DocumentNo  )  --AND DocumentStatus = 1
					BEGIN 						
						--IF @Type = 1
						--BEGIN
							SELECT @Errormsg = ''
						--END


					END	
					ELSE 
					BEGIN
						SELECT @Errormsg = isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','ReadingInAS',@Lang),(case when @Lang='E' then 'Reading exists before' else N'هذة القراءة موجودة من قبل' end))
					END	  
	END 						
	ELSE
	BEGIN
		SELECT @Errormsg =  isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','TimeInAfterTimeOUT',@Lang),(case when @Lang='E' then 'Insert correct Reading' else N'ادخل قراءة صحيحة' end))
	END
	

	if( @Errormsg = '')
	begin
		DECLARE @MaxEntries INT =0
		SELECT @MaxEntries = CAST(ConfigValue AS INT)
		FROM SysParamConfig
		WHERE ConfigID = 'MaxIncompleteTKRequests';

		DECLARE @ApplyIncompleteTkPolicyInAgenda INT =0
		SELECT @ApplyIncompleteTkPolicyInAgenda = ISNULL(
				(SELECT CAST(ConfigValue AS INT)
				 FROM SysParamConfig
				 WHERE ConfigID = 'ApplyIncompleteTkPolicyInAgenda'),
				0
			);
		if(@Type = 0 OR (@Type = 1 AND @ApplyIncompleteTkPolicyInAgenda = 1))  and @MaxEntries>0
		begin
			Declare @PeriodStart as smalldatetime
			Declare @PeriodEnd as smalldatetime
			Declare @EntriesCount as INT
            
			Declare @EntryDate as smalldatetime 
			SELECT @EntryDate = EntryDate FROM dbo.EmpShiftInOut 
			WHERE empid=@Empid 
			AND  @TimeIn= CASE WHEN @AttendType=2 THEN timein ELSE @TimeIn end
			AND @TimeOut= CASE WHEN @AttendType=1 then timeout ELSE @TimeOut END
			----AND timein= CASE WHEN @AttendType=2 then @TimeIn ELSE timein END
			----AND timeout= CASE WHEN @AttendType=1 then @TimeOut ELSE timeout END
			----AND ( (@AttendType=2 AND timein=@TimeIn ) OR (@AttendType=1 AND timeout=@TimeOut) )
			
			--SELECT @EntryDate = EntryDate
			--FROM    EmpTimeReadingsUncommitted
			--WHERE   Empid = @EmpId
			--		AND DocumentNo = @DocumentNo
			SELECT @Calendar=  CAST(ConfigValue AS INT)
			FROM SysParamConfig
			WHERE ConfigID = 'EnableCalendar';

			if(@Calendar = 0)
			begin
				select @PeriodStart = dbo.EndOfPeriodPerDate(PayrollGroup.PayrollGroup,@EntryDate,'G',1),
					   @PeriodEnd =   dbo.EndOfPeriodPerDate(PayrollGroup.PayrollGroup,@EntryDate,'G',2)
				from EmpAssignment join PayrollGroup
				on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup
				where EmpAssignment.EmpId = @Empid
			end
			if(@Calendar = 1)
			begin
				--select @PeriodStart = DATEADD(MONTH, DATEDIFF(MONTH, 0, @TimeIn), 0);							-- first day in month
				--SELECT @PeriodEnd = DATEADD(DAY, -1, DATEADD(MONTH, DATEDIFF(MONTH, 0, @TimeIn) + 1, 0));		-- last day in month

				DECLARE @PeriodStartStr NVARCHAR(10);
				SELECT @PeriodStartStr = RTRIM(LTRIM(STR(YEAR(@EntryDate)))) + '/' + 
										 RIGHT('0' + RTRIM(LTRIM(STR(MONTH(@EntryDate)))), 2) + '/01';

				SELECT @PeriodStart = CONVERT(smalldatetime, @PeriodStartStr);
				SELECT @PeriodEnd = DATEADD(DAY, -1, DATEADD(MONTH, 1, @PeriodStart));
			end

			select @EntriesCount = count(*)
			from EmpTimeReadingsUncommitted
			where Empid = @Empid and DocumentNo <> @DocumentNo and EntryDate between @PeriodStart and @PeriodEnd and DocumentStatus in (1,5)

			if(@EntriesCount >= @MaxEntries AND @MaxEntries>0)
			begin
				select @Errormsg = @Errormsg +  isnull(dbo.Hits_GetDCCaption('EMPTIMEREADINGSUNCOMMITTED','cantInsertRecord',@Lang),(case when @Lang='E' then 'You Cannot insert any more Records this month' else N'لا يمكنك إدخال أي سجلات أخرى هذا الشهر!' end))
			end
		end
	end

	RETURN @Errormsg
END

GO

