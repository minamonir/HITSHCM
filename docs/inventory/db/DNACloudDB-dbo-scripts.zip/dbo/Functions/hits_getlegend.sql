CREATE FUNCTION [dbo].[hits_getlegend]( @lang as nchar(1))
RETURNS @legendtable TABLE 
	(firstgroup nvarchar(MAX), 
	secondgroup nvarchar(MAX),
	thirdgroup nvarchar(MAX),
	fourthgroup nvarchar(800),
	vactype1 nchar(30) collate database_default,
	vactype2 nchar(30) collate database_default,
	vactype3 nchar(30) collate database_default,
	vactype4 nchar(30) collate database_default
	 )
AS
BEGIN

declare @firstgroup nvarchar(max), 
	@secondgroup nvarchar(max),
	@thirdgroup nvarchar(max),
	@fourthgroup nvarchar(800),
	@vactype1 nchar(30),
	@vactype2 nchar(30),
	@vactype3 nchar(30),
	@vactype4 nchar(30)	

--if @lang = 'A'   declare vacations cursor for    select isnull(legend+' : ' + rtrim(vacationaname) + space(30-len(rtrim(vacationaname)))+ case when vactype = 1 then ' (I)'  when vactype = 2 then ' (II)' when vactype = 3 then ' (III)' else ' (IV)' END,'')  as item from vacation
if @lang = 'A'   declare vacations cursor for    select isnull(legend+N' : ' + substring(vacationaname,1,30)+ case when vactype = 1 then N' (I)'  when vactype = 2 then N' (II)' when vactype = 3 then N' (III)' else N' (IV)' END,N'')  as item from vacation
				union select N'P : حاضر '
--if @lang = 'E'  declare vacations cursor for    select isnull(legend+' : ' + rtrim(vacationname) + space(30-len(rtrim(vacationname)))+ case when vactype = 1 then ' (I)'  when vactype = 2 then ' (II)' when vactype = 3 then ' (III)' else ' (IV)' end ,'') as item from vacation
if @lang = 'E'  declare vacations cursor for    select isnull(legend+N' : ' + substring(vacationname,1,30) + case when vactype = 1 then N' (I)'  when vactype = 2 then N' (II)' when vactype = 3 then N' (III)' else N' (IV)' end ,N'') as item from vacation
				union select N'P : Present'
OPEN vacations
declare @item nvarchar(MAX)
declare @switch int
set @switch = 1
set @switch = 1
set @firstgroup= ' '
set @secondgroup = ' ' 
set @thirdgroup = ' '
set @fourthgroup = ' ' 
FETCH NEXT FROM vacations 
INTO @item
WHILE @@FETCH_STATUS = 0
BEGIN
if @switch <= 10
set @firstgroup = @firstgroup +nchar(13)+ @item
if @switch >=11 and @switch <=20
set @secondgroup = @secondgroup +nchar(13)+ @item
if @switch >=21 and @switch <=30
set @thirdgroup = @thirdgroup +nchar(13)+ @item
if @switch >=31
set @fourthgroup = @fourthgroup +nchar(13)+ @item

set @switch = @switch +1

FETCH NEXT FROM vacations 
INTO @item
end

if @lang  = 'A'   declare vactype cursor for 
select vacaname1 from sysparam union
select vacaname2 from sysparam union
select vacaname3 from sysparam
if @lang  = 'E'   declare vactype cursor for
select vacname1 from sysparam union
select vacname2 from sysparam union
select vacname3 from sysparam

OPEN vactype
set @switch = 1
declare @item2 nchar(30)
FETCH NEXT FROM vactype 
INTO @item2
WHILE @@FETCH_STATUS = 0
BEGIN
if @switch = 1
  select  @vactype1 = N'I -  ' + case when @lang  = 'E' then vacname1 else vacaname1 end from sysparam
if @switch = 2
 select @vactype2 = N'II -  ' + case when @lang  = 'E' then vacname2 else vacaname2 end from sysparam
if @switch = 3
  select @vactype3 = N'III - ' +  case when @lang  = 'E' then vacname3 else vacaname3 end from sysparam
if @switch = 4
if @lang='E' set @vactype4 = N'IV - Other'  else  set @vactype4 = N'IV - اخرى'

set @switch = @switch +1

FETCH NEXT FROM vactype 
INTO @item2
end
if @lang='E' set @vactype4 = N'IV - Other'  else  set @vactype4 = N'IV - اخرى'
insert into @legendtable values (@firstgroup,@secondgroup,@thirdgroup,@fourthgroup,
	@vactype1 ,@vactype2 ,@vactype3 ,@vactype4 )	

close vactype
deallocate vactype
close vacations
deallocate vacations

RETURN 
END

GO

