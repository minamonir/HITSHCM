
CREATE FUNCTION [dbo].[reportparents] 
(
	@reportno smallint
	
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @ReportParent AS SMALLINT,@str AS NVARCHAR(250)=N''


select @ReportParent=parentNo  from reports where reportno=@reportNo


DECLARE @tempparent AS SMALLINT=@ReportParent


SET @str=','+isnull(ltrim(rtrim(STr(@ReportParent))),'')

WHILE (@tempparent IS NOT NULL) and (@tempparent NOT IN (32,34) )
BEGIN
SELECT @str=@str+','+isnull(ltrim(rtrim(STr(parentNo))),''),@tempparent=ParentNo from reports where reportno=@ReportParent
--PRINT @str
--PRINT @tempparent
--PRINT @ReportParent
SELECT 	@ReportParent=isnull(@tempparent,@ReportParent)
END
SET @str=@str+ltrim(rtrim(STR(@reportno)))+','
return @str


END

GO

