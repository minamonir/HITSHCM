CREATE       FUNCTION [dbo].[GetWFActionType2new]
  (@RoleProfileid int, @DocumentNo int, @Empid int ,  @ssdocno as smallint )
RETURNS  int
as
BEGIN

DECLARE @returnValue AS SMALLINT,@FirstRequiredNotApprovedOrder AS SMALLINT,@LastApprovedOrder AS SMALLINT
,@HasApprovalStatus AS INT,@HasNoApprovalStatus AS INT,@EndDate AS SMALLDATETIME

SET @returnValue=-2


SELECT  
@EndDate=MAX(EndDate)
,@LastApprovedOrder=MAX(CASE WHEN ApprovalStatus IS NOT NULL THEN RoleOrder ELSE -1 END)
,@FirstRequiredNotApprovedOrder=MIN(CASE WHEN ApprovalStatus IS NULL AND ApprovalRequired=1 THEN RoleOrder ELSE 999 END)
 FROM  dbo.WFDocument WITH (NOLOCK)   
inner JOIN dbo.WFDocApproval WITH (NOLOCK)  ON
  WFDocument.empid=@empid  AND WFDocument.SSDocNo=@ssdocno AND WFDocument.DocumentNo=@DocumentNo
 AND WFDocument.EmpID = WFDocApproval.EmpID 
AND  WFDocument.DocumentNo = WFDocApproval.DocumentNo    AND WFDocument.SSDocNo = WFDocApproval.SSDocNo




SET @LastApprovedOrder=ISNULL(@LastApprovedOrder,-1)	
SET @FirstRequiredNotApprovedOrder=ISNULL(@FirstRequiredNotApprovedOrder,999)	



	IF @RoleProfileid IN ( SELECT approvalprofileid	FROM WFDocApproval WHERE 
	 empid=@empid AND DocumentNo=@DocumentNo AND SSDocNo=@ssdocno and
	 @RoleProfileid=approvalprofileid
	AND ApprovalStatus IS NULL AND  RoleOrder BETWEEN @LastApprovedOrder AND @FirstRequiredNotApprovedOrder AND @EndDate IS NULL)
	BEGIN

		SELECT @returnValue=1
		RETURN @returnValue

	END
	--ELSE
	--BEGIN
	--IF @RoleProfileid IN ( SELECT approvalprofileid	FROM WFDocApproval WHERE 
	-- empid=@empid AND DocumentNo=@DocumentNo AND SSDocNo=@ssdocno and
	--@RoleProfileid=approvalprofileid AND ApprovalStatus IS NULL
	-- AND RoleOrder>@LastApprovedOrder AND @EndDate IS NULL )
	-- begin
	-- 	SELECT @returnValue=0
	--	RETURN @returnValue
	--end
	--END


--IF  @returnValue NOT IN (0,1) --checking history status
--BEGIN

--SELECT @HasApprovalStatus =MAX(CASE WHEN ApprovalStatus IS NOT NULL THEN 1 ELSE 0 END )
--FROM WFDocApproval
--WHERE  empid=@empid AND DocumentNo=@DocumentNo AND SSDocNo=@ssdocno AND  approvalprofileid=@RoleProfileid

--IF @HasApprovalStatus=1 
--begin
--	SELECT @returnValue=-1
--	RETURN @returnValue
--end
--END


RETURN @returnValue
END

GO

