
--this fn calculate the amount for certain paycode
CREATE FUNCTION [dbo].[CalcAppPaycode]  (@calc_empid int, @calc_Assignmentid int, @calc_code smallint, @calc_input numeric(18,3), @calc_balance  numeric(18,3))
RETURNS numeric(18,3) AS  
begin


declare @l_cmonth As smallint
declare @l_cyear As smallint
declare @l_basedon As smallint
declare @l_basedonperiod As smallint
declare @l_calcpaycd As smallint
declare @l_calcgrpcode As smallint
declare @l_inputtp As smallint
declare @l_factor As numeric(9,5)
declare @l_monthdays As smallint
declare @l_dayhours As smallint
declare @l_amount As numeric(18,3)

select 
  @l_basedon=basedon, 
  @l_basedonperiod=basedonperiod, 
  @l_calcpaycd=case when calcpaycd=code then 0 else calcpaycd end,
  @l_calcgrpcode=case when calcgrpcode=grpcode then 0 else calcgrpcode end, 
  @l_inputtp=inputtp, 
  @l_basedon=basedon, 
  @l_factor=case when factor =0 then 1 else factor  end
from paycode 
Where Code=@calc_code

--select 
--  @l_monthdays=case when monthdays=0 then 30 else monthdays end, 
--  @l_dayhours=case when dayhours=0 then 8 else dayhours end, 
--  @l_cmonth=cmonth,
--  @l_cyear=cyear
--from AppAssignment aa inner join payrollgroup p on p.payrollgroup=aa.payrollgroup
--where aa.empid=@calc_empid

---------------------------------------------------------------------------------
--if @l_basedonperiod=2 --start of year
--begin
--  if EXISTS (SELECT ISNULL([Month], 0) FROM HistoryPayroll
--             WHERE (EmpId = @calc_empid) AND ([Year] = @l_cyear)) 
--  begin
--    SELECT top 1 @l_cmonth=ISNULL([Month], 0) FROM HistoryPayroll
--    WHERE   (EmpId = @calc_empid) AND ([Year] = @l_cyear) order by month
--  end
--  else 
--  	set @l_basedonperiod=0
--end
-----------------------------------------------------------------------------------
--if @l_basedonperiod=1 --previous period (previous month)
--begin
--  if EXISTS (SELECT [Month] FROM HistoryPayroll
--       WHERE (EmpId = @calc_empid) AND 
--        ([Year]*100+[Month]=(case when @l_cmonth=1 then (@l_cyear-1)*100+12 else @l_cyear*100+(@l_cmonth-1) end ) ))
--  begin
--	if @l_cmonth=1  
--		select @l_cmonth=12, @l_cyear=@l_cyear-1 
--	else 
--		select @l_cmonth=@l_cmonth-1 
--  end
--  else set @l_basedonperiod=0
--end
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

if @l_basedonperiod=0 --current period
begin
  --select @l_amount=sum(case 
  --  when @l_basedon=4 and paycode.code=isnull(@l_calcpaycd,0) then dbo.CalchrPaycode(HrPCodes.empid ,@l_calcpaycd,HrPCodes.inputamnt,0)*(case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
  --  when @l_basedon=5 and paycode.grpcode=isnull(@l_calcgrpcode,0) then dbo.CalchrPaycode(HrPCodes.empid ,HrPCodes.paycode,HrPCodes.inputamnt,0) *(case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
  --  else 0 end)
  --from HrPCodes 
		--inner join appassignment on appassignment.empid=HrPCodes.empid 
		--inner join payrollgroup on payrollgroup.payrollgroup=appassignment.payrollgroup 
		--inner join paycode on paycode.code=HrPCodes.paycode
  --where appassignment.empid=@calc_empid 

  select @l_amount=
		case when @l_basedon= 1 THEN hrbasicsal 
			 --when @l_basedon= 2 THEN hrtotalsal 
			 when @l_basedon= 3 THEN hrssbonval else @l_amount end
  from appassignment 
  where empid=@calc_empid AND AssignmentId=@calc_Assignmentid
end
---------------------------------------------------------------------------------
--ELSE --start of year OR previous period (previous month)
-----------------------------------------------------------------------------------
--begin
--  select @l_amount=sum(case 
--    when (@l_basedon=1 and paycode.code=100) 
--    then dbo.ConvertAmount( HistoryTransaction.amount, 
--    						HistoryPayroll.PayrollCurrency, 
--    						AppAssignment.HrCurrency, 
--    						dbo.periodend(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year))

--    when (@l_basedon=2 and paycode.addtotsal=1) 
--    then dbo.ConvertAmount( HistoryTransaction.amount, 
--							HistoryPayroll.PayrollCurrency, 
--							AppAssignment.HrCurrency, 
--							dbo.periodend(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year))

    --when (@l_basedon=4 and paycode.code=isnull(@l_calcpaycd,0)) 
    --then (dbo.ConvertAmount(HistoryTransaction.amount, 
				--			HistoryPayroll.PayrollCurrency, 
				--			AppAssignment.HrCurrency,
				--			dbo.periodend(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year))) 
				--			*(case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
    
    --when (@l_basedon=5 and paycode.grpcode=isnull(@l_calcgrpcode,0)) 
    --then (dbo.ConvertAmount(HistoryTransaction.amount, 
				--			HistoryPayroll.PayrollCurrency, 
				--			AppAssignment.HrCurrency, 
				--			dbo.periodend(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year)))
				--			*(case when paycode.type=1 or paycode.code in (100,920,921,922) then 1 else -1 end)
    
 --   else 0 end)
 -- from  HistoryTransaction 
 --   INNER JOIN paycode on HistoryTransaction.paycode=paycode.code
 --   INNER JOIN HistoryPayroll on HistoryPayroll.Year = HistoryTransaction.Year AND HistoryPayroll.month = HistoryTransaction.month AND HistoryPayroll.EmpId  = HistoryTransaction.EmpId  AND HistoryPayroll.RunNo  = HistoryTransaction.RunNo  
	--INNER JOIN AppAssignment on AppAssignment.EmpId = HistoryPayroll.EmpId
 -- where HistoryTransaction.empid=@calc_empid and historytransaction.year=@l_cyear AND HistoryTransaction.month=@l_cmonth 

  --select @l_amount=case when @l_basedon=3 then AppAssignment.hrssbonval else @l_amount end
  --from AppAssignment 
  --where empid=@calc_empid

--end

--IF @l_basedon IN (4,5) 
--	SELECT @l_amount=isnull(@l_amount,0.0) * CASE WHEN type=2 THEN -1 
--ELSE 1 
--END FROM paycode WHERE code=@calc_code
	
set @l_amount = isnull(@l_amount,0.0)

set @l_amount=case @l_inputtp 
     when 1 then @calc_input 
     --when 2 then @calc_input*@l_amount*@l_factor/@l_monthdays
     --when 3 then @calc_input*@l_amount*@l_factor/(@l_monthdays*@l_dayhours) 
     when 4 then @calc_input*@l_amount*@l_factor/100 end


select @l_amount=round(@l_amount,decimalscale) from sysparam

RETURN @l_amount
end

GO

