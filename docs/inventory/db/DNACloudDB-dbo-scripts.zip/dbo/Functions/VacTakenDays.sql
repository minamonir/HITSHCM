CREATE FUNCTION [dbo].[VacTakenDays]
(@empid int,@fromdate datetime,@todate datetime,@vaccode int,@DocumentNo  int,@PartDayFrom bit,@PartDayTo bit)
RETURNS numeric(18,3)
AS
BEGIN
-- return the no of days between @fromdate and @todate according to the vacation and the employee vacation package setup

--DECLARE @empid int,@fromdate datetime,@todate datetime,@vaccode  INT,@DocumentNo  int ,@PartDayFrom  BIT,@PartDayTo  bit
--SELECT @empid =216587,@fromdate ='2022-09-18 00:00:00',@todate ='2022-09-25 00:00:00',@vaccode =1,@PartDayFrom =0,@PartDayTo=0,@DocumentNo=0

--declare @switch as datetime
--IF @fromdate >  @todate BEGIN
--                        set @switch = @todate 
--                        set @todate = @fromdate
--                        set @fromdate = @switch
--                        END 

declare @DecimalScale as smallint
select @DecimalScale=DecimalScale from sysparam

  declare @days numeric(18,3), @holidays int, @dayoffs int
,@daynoshifts int, @donotcountdayoff bit ,@donotcountholiday bit,@donotcountnoshift bit
,@tempdate datetime, @vacpack as int, @vacpackchange as bit
,@PartDayFactorFrom AS numeric(9, 3)=0.000,@PartDayFactorTo AS numeric(9, 3)=0.000
,@FromDayoffOrHoliday BIT=0,@ToDayoffOrHoliday BIT=0
,@OriginalVacFromDate AS DATETIME,@OriginalVacToDate AS DATETIME
,@AcceptPartDayFrom AS BIT,@AcceptPartDayTo AS bit
        
  set @days = 0.000
  set @holidays=0
  set @dayoffs=0
  set @daynoshifts = 0
  set @donotcountdayoff=1
  set @donotcountholiday=1
  set @donotcountnoshift=1
  set @tempdate=@fromdate
  set @vacpackchange=0
  
IF @DocumentNo<>0
BEGIN
	Select @OriginalVacFromDate=EmpVacat.FromDate,@OriginalVacToDate=EmpVacat.ToDate  	FROM EmpVacat WHERE empid=@empid AND DocumentNo=@DocumentNo
END
ELSE
BEGIN
	Select @OriginalVacFromDate=@fromdate,@OriginalVacToDate=@todate
END
Select 
@donotcountdayoff=donotcountdayoff, @donotcountholiday=donotcountholiday,@donotcountnoshift=DoNotCountNoShift,
@AcceptPartDayFrom=AcceptPartDayFrom,@AcceptPartDayTo=AcceptPartDayTo,
@PartDayFactorFrom=case when AcceptPartDayFrom=1 THEN  PartDayFactorFrom ELSE 1 END ,
@PartDayFactorTo=case when AcceptPartDayTo=1 THEN  PartDayFactorTo ELSE 1 END from vacation where vaccode=@vaccode

SET @PartDayFrom=CASE WHEN  @PartDayFrom=1 AND @OriginalVacFromDate=@fromdate AND @AcceptPartDayFrom=1 THEN 1 ELSE 0 END

SET @PartDayTo=CASE WHEN  @PartDayTo=1 AND @OriginalVacToDate=@todate and @AcceptPartDayTo=1 THEN 1 ELSE 0 END  

  --check if there is change of status in vacpack during vacation dates 
  if exists(SELECT  EmpStatusHdr.EffectiveDate FROM EmpStatusHdr INNER JOIN EmpStatusDtl 
   ON EmpStatusHdr.EmpId = EmpStatusDtl.EmpId AND EmpStatusHdr.DocumentNo = EmpStatusDtl.DocumentNo
   WHERE (EmpStatusHdr.DocumentStatus = 1) AND (EmpStatusDtl.FieldNo = 19) AND (EmpStatusHdr.EmpId = @empid) and 
   (EmpStatusHdr.EffectiveDate between @fromdate and @todate)) set @vacpackchange=1 
  else select @vacpack=dbo.GetOldValue(@empid, 19, dateadd(dd,1,@todate), null)

  set @days = datediff(day,@fromdate , @todate )+1
  if ((@donotcountdayoff=1) or (@donotcountholiday=1) OR @donotcountnoshift = 1)
  WHILE (@tempdate <= @todate)
  BEGIN    
	set @holidays=0
	set @dayoffs=0  
	SET @daynoshifts = 0
	if @vacpackchange=1 select @vacpack=dbo.GetOldValue(@empid, 19, dateadd(dd,1,@tempdate), null)
	if @donotcountdayoff=1
	begin
		--select historical vacpack if there is a change in status
		select @dayoffs = (case when  DATEPART(dw,@tempdate) =  v.doffday1 then 1 when   DATEPART(dw,@tempdate) =  v.doffday2 then 1 else 0 end ) 
		from vacpack v where v.vacpack=@vacpack and v.dofftype=1
		if @dayoffs <> 0 
		BEGIN
			SET @FromDayoffOrHoliday=CASE WHEN @tempdate=@fromdate THEN 1 ELSE @FromDayoffOrHoliday end
			SET @ToDayoffOrHoliday=CASE WHEN @tempdate=@todate THEN 1 ELSE @ToDayoffOrHoliday end
			set  @days  = @days - @dayoffs
		end       
	end
	if @donotcountholiday=1 and @dayoffs=0
	begin
		select @holidays= 1
		from holidays h where h.vacpack=@vacpack and h.holiday=1 and h.date = @tempdate
		if @holidays <> 0 
		BEGIN
			SET @FromDayoffOrHoliday=CASE WHEN @tempdate=@fromdate THEN 1 ELSE @FromDayoffOrHoliday end
			SET @ToDayoffOrHoliday=CASE WHEN @tempdate=@todate THEN 1 ELSE @ToDayoffOrHoliday end
			set  @days  = @days - @holidays
		end
	end
	if @donotcountnoshift=1 and @dayoffs=0 AND @holidays=0
	BEGIN
		IF  NOT EXISTS(SELECT * FROM EmpShift  WHERE EmpShift.EmpId=@empid AND EmpShift.ShiftDate=@tempdate AND EmpShift.ShiftNo IS NOT NULL)
		AND NOT EXISTS(SELECT * FROM vacpack  v where v.vacpack=@vacpack AND v.dofftype=1 AND DATEPART(dw,@tempdate) IN (v.doffday1,v.doffday2))
		AND NOT EXISTS(SELECT * FROM holidays h where h.vacpack=@vacpack AND h.holiday=1  AND h.date = @tempdate)
		SELECT @daynoshifts= 1
		ELSE
		SELECT @daynoshifts= 0

		IF @daynoshifts <> 0
		BEGIN
			SET @FromDayoffOrHoliday=CASE WHEN @tempdate=@fromdate THEN 1 ELSE @FromDayoffOrHoliday end	
			SET @ToDayoffOrHoliday=CASE WHEN @tempdate=@todate THEN 1 ELSE @ToDayoffOrHoliday end
			set  @days  = @days - @daynoshifts
		END
	END
	set  @tempdate = @tempdate +1
end 

 -----------------End While--------------
SET @days=@days-CASE WHEN @PartDayFrom=1 and @FromDayoffOrHoliday=0 THEN 1 ELSE 0 END- CASE WHEN @PartDayTo=1 and @ToDayoffOrHoliday=0 THEN CASE WHEN @fromdate=@todate AND @PartDayFrom=1 and @FromDayoffOrHoliday=0 THEN 0 ELSE 1 end  ELSE 0 END
SET @days=@days+CASE WHEN @PartDayFrom=1 and @FromDayoffOrHoliday=0 THEN @PartDayFactorFrom ELSE 0 END+CASE WHEN @PartDayTo=1 and @ToDayoffOrHoliday=0 THEN @PartDayFactorTo ELSE 0 END

select  @days = (case when UseDayFactor = 1 then  @days * DayFactor else @days end ) 
from vacation  where vaccode = @vaccode


set @days=round(@days,@DecimalScale)
RETURN @days 
--SELECT @days
END

GO

