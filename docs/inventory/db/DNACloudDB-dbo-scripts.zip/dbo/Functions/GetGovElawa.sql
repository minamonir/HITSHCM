CREATE FUNCTION [dbo].[GetGovElawa](@from int, @to int, @filterwhere nvarchar(max)=N'' ,@type int )
 RETURNS numeric(18,3) 
AS
BEGIN
	DECLARE @MonthlyAmount AS numeric (18,3)
	DECLARE @HistoryAmount AS numeric(18,3)
	DECLARE @final AS numeric(18,3) 
	DECLARE @SelectMonthlyText AS nvarchar(max)
	DECLARE @SelectHistoryText AS nvarchar(max)
	DECLARE @WhereMonthly AS nvarchar(max)
	DECLARE @WhereHistory AS nvarchar(max)

	 DECLARE @temp TABLE(Amount numeric(18,3))



SELECT @MonthlyAmount = Sum(MonthlyTransaction.Amount) 
FROM EmpAssignment 
INNER JOIN MonthlyTransaction ON EmpAssignment.EmpId = MonthlyTransaction.EmpId 
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo 
LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup 
LEFT JOIN Currency ON PayrollGroup.Currency = Currency.Cur 
LEFT JOIN PayCode ON MonthlyTransaction.PayCode = PayCode.Code 
LEFT JOIN PayCdGrp ON PayCode.GrpCode = PayCdGrp.GrpCode 
LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade
LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN Organization ON EmpAssignment.PayOrganization = Organization.Organization 
LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 
LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = N'Status'
LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = N'TaxStatus' 
LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = N'ScStatus' 
LEFT JOIN NasArrays PayType ON Paycode.Type = PayType.itemno AND PayType.arrayname = N'PayType' 
LEFT JOIN NasArrays InputType ON Paycode.InputTp = InputType.itemno AND InputType.arrayname = N'PayInput'
WHERE MonthlYTransaction.Paycode=CASE WHEN @type=1 THEN 100 WHEN @type=2 THEN 115 END   AND  PayrollGroup.CYear*100+Payrollgroup.CMonth BETWEEN CASE WHEN @from=0 THEN PayrollGroup.CYear*100+Payrollgroup.CMonth ELSE  @from END  AND CASE WHEN @to=0 THEN PayrollGroup.CYear*100+Payrollgroup.CMonth else  @to END  --+ @filterwhere

SELECT @HistoryAmount= Sum(HistoryTransaction.Amount)
FROM EmpAssignment 
INNER JOIN HistoryPayroll ON HistoryPayroll.EmpId = EmpAssignment.EmpId 
INNER JOIN HistoryTransaction ON HistoryPayroll.Year = HistoryTransaction.Year 
 AND HistoryPayroll.Month = HistoryTransaction.Month  
 AND HistoryPayroll.EmpId = HistoryTransaction.EmpId 
 AND HistoryPayroll.RunNo = HistoryTransaction.RunNo 
LEFT JOIN Paycode ON PayCode.Code = HistoryTransaction.PayCode 
LEFT JOIN PaycdGrp ON PayCode.GrpCode = PaycdGrp.GrpCode 
LEFT JOIN Currency ON HistoryPayroll.PayrollCurrency = Currency.Cur 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo 
LEFT JOIN PayrollGroup ON HistoryPayroll.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Currency PayrollGroupCurrency ON PayrollGroupCurrency.Cur = PayrollGroup.Currency 
LEFT JOIN CostCntr ON HistoryPayroll.Center = CostCntr.center 
LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup 
LEFT JOIN TaxRules ON TaxRules.taxcode = EmpAssignment.TaxCode 
LEFT JOIN Organization ON HistoryPayroll.PayOrganization = Organization.Organization 
LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 
LEFT JOIN NasArrays PayType ON PayCode.Type = PayType.itemno AND PayType.arrayname = N'PayType' 
LEFT JOIN NasArrays InputType ON PayCode.InputTp = InputType.itemno AND InputType.arrayname = N'PayInput'
LEFT JOIN NasArrays ScStatus ON HistoryPayroll.ScStatus = ScStatus.itemno AND ScStatus.arrayname = N'ScStatus' 
LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname =N'Status' 
LEFT JOIN NasArrays TaxStatus ON EmpAssignment.TaxStatus = TaxStatus.itemno AND TaxStatus.arrayname = N'TaxStatus' 
LEFT JOIN Payrollgroup Payrollgroup1 ON PayrollGroup.PayrollGroup=EmpAssignment.PayrollGroup
WHERE HistoryTransaction.Paycode=CASE WHEN @type=1 THEN 100 WHEN @type=2 THEN 115 END AND  HistoryTransaction.Year*100+HistoryTransaction.Month BETWEEN CASE WHEN @from=0 THEN (PayrollGroup1.CYear+1)*100+PayrollGroup1.CMonth else  @from END  AND CASE WHEN @to =0 THEN PayrollGroup1.CYear*100+PayrollGroup1.CMonth else  @to END --+ @filterwhere  


SELECT  @final=isnull(@MonthlyAmount,0)+isnull(@HistoryAmount,0)
RETURN  isnull(@final,0)
END

GO

