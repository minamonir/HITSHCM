
--- Returns 1 if occupied
--- Returns 0 if Vacant


CREATE FUNCTION [dbo].[RoomStatus] (@Room_No nCHAR(10), @Date SMALLDATETIME)
RETURNS BIT
BEGIN 
  IF @Room_No IN 
  (
	SELECT RoomNo FROM EmpRooms WHERE RoomNo = @Room_No
	AND ( (@Date BETWEEN FromDate AND ToDate) OR (@Date >= FromDate AND TODate IS NULL))
  )
		BEGIN
		 Return 1
		END
	  		
 RETURN 0	
END

GO

