

CREATE FUNCTION [dbo].[GetOrganizationSysParam]
(
	-- Add the parameters for the function here
	@org smallint ,@employeeId as NVARCHAR(50)='0'
)
RETURNS smallint
AS
--declare @org smallint =20 ,@employeeId as NVARCHAR(max)=401
BEGIN
 DECLARE @EmployeeidType SMALLINT ,@EmployeeidAuto SMALLINT -- 0:Numeric - 1:String
select   @EmployeeidType =EmployeeidType ,@EmployeeidAuto=AutoEmpId from dbo.sysparam 

 --set @EmployeeidType=0
--set @EmployeeidAuto=0

--return -2 in case (have an organization setup but out of range) OR (have no org setup and autoempid=0 and @employeeId exists in another org range)
--return -1 in case (have no org setup and autoempid=1 )

declare @orgNum as smallint=0 ,@EmpIdCount   as NVARCHAR(50) ,@EmpIdTo  as NVARCHAR(10),@EmpIdFrom  as NVARCHAR(10)
declare @status as smallint=0

--------------------------------
 --Declare @Organization smallint=0
 --select @Organization= Organization from OrganizationSysParam where Organization= @org
-----------------
 -- get organization from (OrganizationSysParam or the parent organaization )
	select top 1  @orgNum= OrganizationSysParam.Organization ,@EmpIdCount=OrganizationSysParam.empidcnt 
	,@EmpIdFrom=OrganizationSysParam.employeeidfrom ,@EmpIdTo=OrganizationSysParam.employeeidto
	from
	OrganizationSysParam
	left join OrganizationParentChild on OrganizationSysParam.organization =OrganizationParentChild.OrganizationParentOrChild and OrgRelation in (1,2) 
	LEFT JOIN organization ON OrganizationParentChild.OrganizationParentOrChild = Organization.Organization
	where 
	--OrgRelation in (1,2) 
	--AND empidcnt<employeeidto and
	 isnull(OrganizationParentChild.Organization, OrganizationSysParam.Organization)=@org
	order by Organizationtype DESC
--------------------------------
-- @EmployeeidType =0 is int
if @EmployeeidType =0
    begin
			
			IF  isnull(@orgNum ,0) > 0 
			BEGIN
				   		---check range  
					if(CAST( @EmpIdCount as int) < cast(@EmpIdTo as int) and  @EmployeeidAuto =1 and CAST(@employeeId as int)=0 )	 ----auto in insert----
					--or (CAST( @EmpIdCount as int) <= cast(@EmpIdTo as int) and  @EmployeeidAuto =1 and CAST(@employeeId as int)<>0 ) ----auto in uppdate----
					or ( @EmployeeidAuto =0	and CAST(@employeeId as int) BETWEEN cast(@EmpIdFrom as int) and cast(@EmpIdTo as int))  --- manual insert and update
					begin
					set @status =@orgNum
					end	 
					else
					begin
						set @status =-2
					end
			end
				   else
				   begin
				   ---parent not found 
		              if @EmployeeidAuto =1 set @status =-1
					  if  @EmployeeidAuto=0 and EXISTS(select EmployeeIdFrom,EmployeeIdTo from OrganizationSysParam
					   where cast(@employeeId as int) BETWEEN cast( EmployeeIdFrom as int) and cast( EmployeeIdTo as int)) 
						set @status =-2
				   end
	end
	

	 If(@EmployeeidType =1)   --- employee id string 
         Begin            --	If @employeeId=0 is Auto or  @employeeId !=0 is manual      
		    

					 	---check range  
					   If    isnull(@orgNum ,0)>0 
						   Begin
							   If(@EmployeeidAuto=0 And dbo.GetValidOrgRange(@orgNum,@employeeId) =1) --- manual    
									 Set @status = @orgNum
                     
								  Else IF(@EmployeeidAuto =1 And dbo.GetValidOrgRange(@orgNum,0)=1 )  -- auto 
									 Set @status =@orgNum -- Auto
                       
								  Else Set @status =-2
						   End
                       Else
					   Begin
					      ---parent not found 
		                 if @EmployeeidAuto =1 set @status =-1
					   End
------------------
		End
    return @status

END

GO

