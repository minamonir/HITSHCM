
CREATE FUNCTION [dbo].[HitsStr]
(

	@employeeid AS NVARCHAR(50)
)
RETURNS NVARCHAR(50)
AS
BEGIN
	
DECLARE @EmployeeidType AS smallint


SELECT @EmployeeidType=EmployeeidType FROM SysParam



SET @employeeid=CASE WHEN @EmployeeidType IN (1,2) THEN ltrim(rtrim(@employeeid)) ELSE ltrim(rtrim(Str(cast(@EmployeeId AS FLOAT)))) END 


RETURN  @employeeid

END

GO

