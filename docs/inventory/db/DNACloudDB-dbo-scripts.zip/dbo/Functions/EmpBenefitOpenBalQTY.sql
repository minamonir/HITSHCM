CREATE FUNCTION [dbo].[EmpBenefitOpenBalQTY](@empid as int,@documentno as smallint,@PlanNo as smallint,@StartActivityDate as smalldatetime)   
RETURNS numeric (18,3) AS  
--This fn calculate the openning balance QTY (total debit-total credit) b4 a specific date for a certain benefit plan

BEGIN 

declare @balance as numeric(18,3),@totaldebit as numeric(18,3),@totalcredit as numeric(18,3)

select @totalcredit=sum(case when BenefitItems.Debitorcredit=2 THEN ActivityQty else 0 end),@totaldebit=sum(case when BenefitItems.Debitorcredit=1 then  ActivityQty else 0 end)
from EmpBenefit
LEFT JOIN EmpBenefitItems ON EmpBenefit.EmpId = EmpBenefitItems.EmpId
 AND EmpBenefit.DocumentNo = EmpBenefitItems.DocumentNo 
LEFT JOIN BenefitItems ON EmpBenefitItems.ItemNo = BenefitItems.ItemNo 
where EmpBenefit.empid=@empid and  EmpBenefit.DocumentNo=@documentno and EmpBenefitItems.Activitydate<@StartActivityDate and EmpBenefit.planno=@PlanNo
set @balance=@totaldebit-@totalcredit
return isnull(@balance,0)
END

GO

