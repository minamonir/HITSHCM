
CREATE FUNCTION [dbo].[GetEmpFirstHiringInfo]
(
	@empid INT ,
	@Type INT ,
	@lang NCHAR(1)='E'
)
RETURNS NVARCHAR(max)
AS
BEGIN
IF EXISTS(SELECT * FROM dbo.SysParamConfig WHERE ConfigID='EGGOV' AND ConfigValue='1')
BEGIN	
	DECLARE @EffectiveDate AS SMALLDATETIME,@result AS NVARCHAR(max),@HrCurrency AS SMALLINT,@FieldNo AS INT 
	DECLARE @dateFormat AS SMALLINT = (SELECT SysParam.DateFormat FROM SysParam)
	SELECT TOP 1 @EffectiveDate = EmpStatusHdr.EffectiveDate 
	 From EmpAssignment t 
inner JOIN EmpStatusHdr on t.EmpId = EmpStatusHdr.EmpId AND EmpStatusHdr.DocumentStatus=1
inner JOIN EmpStatusDtl on EmpStatusDtl.EmpId = EmpStatusHdr.EmpId 
And EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo and
EmpStatusDtl.FieldNo = 5  
and t.job =EmpStatusDtl.NewValue 
WHERE t.EmpId=@empid and NewValue<>dbo.GetOldValue(t.EmpId,FieldNo,EffectiveDate,EmpStatusHdr.HrCurrency)  
ORDER BY EmpStatusHdr.EffectiveDate desc
SELECT @EffectiveDate=  ISNULL(@EffectiveDate ,t.HireDate)
FROM  EmpAssignment t  WHERE t.EmpId=@empid

	IF @type=1
     BEGIN

	 RETURN CASE WHEN @dateFormat = 0 THEN CONVERT(nchar(10), @EffectiveDate, 111) WHEN @dateFormat = 1 THEN CONVERT(nchar(10), 
                      @EffectiveDate, 103) ELSE CONVERT(nchar(10), @EffectiveDate, 101) END --AS HireDate 
     END
    ELSE IF @type=2
      BEGIN
      IF EXISTS(SELECT HrCurrency FROM dbo.EmpAssignment WHERE EmpId=@empid AND HrCurrency IS NOT NULL)
      SELECT @HrCurrency= HrCurrency FROM dbo.EmpAssignment WHERE EmpId=@empid
      ELSE
      SELECT @HrCurrency= syscur FROM dbo.SysParam 
     
	   SET @result  = dbo.GetOldValueTxt(1,dbo.GetOldValue(@empid,1,DATEADD(DAY,1,@EffectiveDate),@HrCurrency),@lang)
	  RETURN @result
    END

	ELSE IF @type=3
     BEGIN
	 	 set @EffectiveDate=null
	  	SELECT TOP 1 @EffectiveDate = EmpStatusHdr.EffectiveDate 
			From EmpAssignment t 
			inner JOIN EmpStatusHdr on t.EmpId = EmpStatusHdr.EmpId AND EmpStatusHdr.DocumentStatus=1
			inner JOIN EmpStatusDtl on EmpStatusDtl.EmpId = EmpStatusHdr.EmpId 
			And EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo and
			EmpStatusDtl.FieldNo = 7  
			and t.Grade =EmpStatusDtl.NewValue 
			WHERE t.EmpId=@empid and ISNULL(t.Grade,0)>0 and NewValue<>dbo.GetOldValue(t.EmpId,FieldNo,EffectiveDate,EmpStatusHdr.HrCurrency) ORDER BY EmpStatusHdr.EffectiveDate desc

			SELECT @EffectiveDate=  ISNULL(@EffectiveDate ,t.HireDate) 
			FROM  EmpAssignment t  WHERE t.EmpId=@empid and ISNULL(t.Grade,0)>0

	   RETURN CASE WHEN @dateFormat = 0 THEN CONVERT(nchar(10), @EffectiveDate, 111) WHEN @dateFormat = 1 THEN CONVERT(nchar(10), 
                      @EffectiveDate, 103) ELSE CONVERT(nchar(10), @EffectiveDate, 101) END --AS GradeDate 
     END

END
 RETURN ''
END

GO

