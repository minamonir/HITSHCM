

----------for Mantrac Report 397 
----- calculate taxable total amount for this employee within one year (@Year)
CREATE    FUNCTION [dbo].[Pay_TaxableTotal] (@Empid Int, @payrollgroup smallint,@year as smallint,@from as int,@to as int,@taxcode smallint)
RETURNS numeric(18,3) AS 
begin


declare @DecimalScale smallint, @cyear smallint, @runno smallint, @currency smallint
declare @payrollcalcdate smalldatetime,    @soc_insur numeric(18,3), @taxcmpexmp numeric(18,3), @tax_total numeric(18,3),
    @taxempexmp numeric(18,3), @tax_exempt numeric(18,3), @stmptype smallint, @stmp_amnt numeric(18,3)

declare  @w_months numeric(18,3),  @BasicSal numeric(18,3)

select  @DecimalScale=0, @soc_insur=0, 
    @taxcmpexmp=0, @tax_total=0, @taxempexmp=0, @tax_exempt=0, @stmptype=0, @stmp_amnt=0
select @currency=syscur, @taxcode=case when @taxcode=0 then empassignment.taxcode else @taxcode end from payrollgroup inner join empassignment on payrollgroup.payrollgroup=payrollgroup.payrollgroup cross join sysparam where empid=@empid

select @DecimalScale=DecimalScale from sysparam

DECLARE @ytd_table1 TABLE (Paycode smallint, months smallint, amount numeric(18,3))

insert into @ytd_table1  

select max(paycode.code) as paycode, count(distinct h.[month]) as months,
      sum(dbo.convertamount(h.amount,p.payrollcurrency,@currency,
      dbo.periodend(p.payrollgroup, p.month, p.year))) as amount
from historytransaction h inner join paycode on h.paycode=paycode.code 
  inner join historypayroll p on p.empid=h.empid and p.year=h.year and p.month=h.month and p.runno=h.runno 
where (paycode.type=3 or paycode.taxappl=1) and h.empid=@empid and h.year=@year and h.month between @from and @to and p.payrollgroup=@payrollgroup
group by paycode.code
    
DECLARE @ytd_table TABLE (Paycode smallint, w_months smallint, amount numeric(18,3))

--select * from @ytd_table1      
insert into @ytd_table
select max(paycode) as paycode, max(isnull(months,0)) as w_months,
       sum(isnull(amount,0)) as amount
from @ytd_table1 
group by paycode

--select * from @ytd_table


select @w_months=isnull(max(w_months),1), @BasicSal=sum(case when paycode=100 then amount else 0 end)
from  @ytd_table


      select @soc_insur=sum(case when ytd.paycode in (910,911,912) then ytd.amount else 0 end),          
       @tax_total=sum(case when paycode.taxappl=1  and (paycode.type<>3 or paycode.code=100) then 
               case when paycode.maxexmp<>0 then 
                 case when paycode.percentyn=1 then 
                   case when paycode.maxexmp<100 then (ytd.amount*(100-paycode.maxexmp)/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end 
                 else
                   case when dbo.ConvertAmount(paycode.maxexmp,ISNULL(Paycode.ExmpCurrency, @Currency), 
                      @Currency, @payrollcalcdate)*@w_months<ytd.amount then
                     (ytd.amount-dbo.ConvertAmount(paycode.maxexmp,ISNULL(Paycode.ExmpCurrency, @Currency), 
                      @Currency, @payrollcalcdate)*@w_months)*(case when paycode.type=2 then -1 else 1 end) else 0 end 
                 end                 
               else
                 case when paycode.prcexmp<>0 then 
                   case when paycode.prcexmp*@BasicSal/100<ytd.amount then (ytd.amount-paycode.prcexmp*@BasicSal/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end
                 else
                   ytd.amount*(case when paycode.type=2 then -1 else 1 end)
                 end
               end                               
             else
               0
             end),
       @taxempexmp=sum(case when paycode.taxappl=1 and paycode.partcomp=1 and (paycode.type<>3 or paycode.code=100) then 
               case when paycode.maxexmp<>0 then 
                 case when paycode.percentyn=1 then 
                   case when paycode.maxexmp<100 then (ytd.amount*paycode.maxexmp/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end 
                 else
                   case when dbo.ConvertAmount(paycode.maxexmp,ISNULL(Paycode.ExmpCurrency, @Currency), 
                      @Currency, @payrollcalcdate)*@w_months<ytd.amount then 
                     (dbo.ConvertAmount(paycode.maxexmp,ISNULL(Paycode.ExmpCurrency, @Currency), 
                      @Currency, @payrollcalcdate)*@w_months)*(case when paycode.type=2 then -1 else 1 end) else (ytd.amount)*(case when paycode.type=2 then -1 else 1 end) end 
                 end                 
               else
                 case when paycode.prcexmp<>0 then 
                   case when paycode.prcexmp*@BasicSal/100<ytd.amount then (paycode.prcexmp*@BasicSal/100)*(case when paycode.type=2 then -1 else 1 end) else 0 end
                 else
                   0
                 end
               end                               
             else
               0
             end),       
       @taxcmpexmp=max(dbo.ConvertAmount(taxrules.taxcmpexmp,
          ISNULL(TaxRules.TaxCurrency, @Currency), @Currency, @payrollcalcdate))/12*@w_months,
       @tax_exempt=max(case when empassignment.taxstatus=1 then taxrules.taxexmp1 else 
                  case when empassignment.taxstatus=2 then taxrules.taxexmp2 else
                  case when empassignment.taxstatus=3 then taxrules.taxexmp3 else 0 end end end)
from   @ytd_table ytd inner join paycode on ytd.paycode=paycode.code 
                  inner join taxrules on taxrules.taxcode=@taxcode 
                  inner join empassignment on empassignment.empid=@empid 
                  
group by empassignment.empid

set @tax_total=@tax_total-@soc_insur
if @taxempexmp>@taxcmpexmp set @tax_total=@tax_total+@taxempexmp-@taxcmpexmp
if @tax_total<0 set @tax_total=0
return @tax_total
END

GO

