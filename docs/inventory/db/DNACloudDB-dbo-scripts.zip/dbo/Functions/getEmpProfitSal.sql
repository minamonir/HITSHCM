
Create FUNCTION [dbo].[getEmpProfitSal]( @empid INT ,@CurrentOrPrevious BIT,@yearMonth int ,@Type SMALLINT  )
RETURNS NUMERIC (18,3)
AS 
BEGIN
	DECLARE @amount AS NUMERIC(18,3)=0
	declare @MiscndtBonusProfitAppl AS BIT =0
	DECLARE @Month AS SMALLINT , @Year AS SMALLINT 
	
	SELECT @MiscndtBonusProfitAppl = ConfigValue FROM SysParamConfig WHERE ConfigID = 'MisconductBonusBasedonProfitAppPaycodes'
	IF @yearMonth >0
	BEGIN 
		SELECT @month=RIGHT(@yearMonth,2) , @Year =LEFT (@yearMonth,4)
	END 
		IF @type=1
		BEGIN
			IF @CurrentOrPrevious =0
				BEGIN
					IF @MiscndtBonusProfitAppl=0
					BEGIN
						select @amount=empassignment.SsBonVal FROM empassignment WHERE empid =@empid 
					END
					else IF @MiscndtBonusProfitAppl=1
					BEGIN 
						select @amount= sum(CASE WHEN Paycode.type=1 OR paycode.code =100 THEN 1 ELSE -1 END *MonthlyTransaction.Amount)
						FROM  EmpAssignment 
						LEFT JOIN MonthlyTransaction ON MonthlyTransaction.EmpId = EmpAssignment.EmpId
						LEFT JOIN Paycode ON Paycode.code = MonthlyTransaction.Paycode 
						where Paycode.ProfitAppl = 1 and empassignment.empid =@empid 
		           END 
				END
			ELSE 
			BEGIN
					IF @MiscndtBonusProfitAppl=0
					BEGIN
						select @amount= dbo.GetOldValue(empassignment.empid,18, dbo.periodend (payrollgroup.payrollgroup , @month ,  @Year )+1, payrollgroup.currency)  
						FROM empassignment 
						LEFT JOIN payrollgroup ON payrollgroup.PayrollGroup = empassignment.PayrollGroup
						WHERE empid =@empid 
					END
					else IF @MiscndtBonusProfitAppl=1
					BEGIN 
						SELECT @amount= SUM(CASE WHEN Paycode.type=1 OR paycode.code =100 THEN 1 ELSE -1 END *historytransaction.Amount) 
						FROM  EmpAssignment 
						LEFT JOIN historytransaction ON historytransaction.EmpId = EmpAssignment.EmpId
						AND historytransaction.year*100 +Month =@year*100+@month 
						LEFT JOIN Paycode ON Paycode.code = historytransaction.Paycode 
						where Paycode.ProfitAppl = 1 and empassignment.empid =@empid 
				   END
		END
END 
	return  @amount
END

GO

