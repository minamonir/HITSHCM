CREATE  FUNCTION [dbo].[GetEmployeeManagerData] (@EmpId INT , @RoleId SMALLINT , @ResultData SMALLINT , @ResultType SMALLINT , @lang NCHAR(1) )
RETURNS NVARCHAR (max)
AS
BEGIN
-- Parameters : 
 --@EmpId	->	EmpId
 --@RoleId	->	ssGroupRole Id
 --@ResultData	->	if 1 -> Role ProfileID 
 --					if 2 -> Role Name
 --					if 3 -> Role Position
 --					if 4 -> Role Job	
 --                 IF 5 -> Role ProfileId and Delegate  ProfileId for Appraisal only
 --@ResultType	->	if 1 -> ID
 --@ResultType	->	if 2 -> Name
 --@lang		-> 'e' or 'a'
DECLARE @RoleData AS NVARCHAR (max) =''
	
 IF @ResultData = 2  -- get Role Name 'e' or 'a'
 BEGIN
 		SELECT @RoleData= CASE WHEN @lang = 'a' THEN RoleProfile.AName ELSE  RoleProfile.Name END 
 		FROM empassignment
 		LEFT JOIN ssgroup ON ssgroup.SSGroup = empassignment.SSGroup
 		INNER JOIN ssgrouprole  ON ssgrouprole.SSGroup = SSGroup.SSGroup AND ssgrouprole.RoleId = @RoleId
		AND ssgrouprole.ProfileId = (SELECT TOP 1 ssgr.profileid 
	                             FROM ssgrouprole ssgr
								 WHERE ssgrouprole.SSGroup=ssgr.SSGroup AND ssgrouprole.RoleId=ssgr.RoleId
	                             ORDER BY ssgr.profileid asc )                                                          
		LEFT JOIN [Profile] RoleProfile ON RoleProfile.ProfileId =ssgrouprole.ProfileId
 		WHERE empassignment.EmpId = @EmpId
 END

 IF @ResultData = 3  -- get Role position
 BEGIN

 		 	SELECT @RoleData= CASE WHEN @ResultType = 1 THEN CAST(RoleEmpAssignment.PositionNo AS NVARCHAR(MAX)) ELSE (CASE WHEN @lang = 'a' THEN Rolepositions.PositionAName ELSE   Rolepositions.PositionName END) END 
 			FROM empassignment
 			LEFT JOIN ssgroup ON ssgroup.SSGroup = empassignment.SSGroup
 			INNER JOIN ssgrouprole  ON ssgrouprole.SSGroup = SSGroup.SSGroup AND ssgrouprole.RoleId = @RoleId
			AND ssgrouprole.ProfileId = (SELECT TOP 1 ssgr.profileid 
	                             FROM ssgrouprole ssgr
								 WHERE ssgrouprole.SSGroup=ssgr.SSGroup AND ssgrouprole.RoleId=ssgr.RoleId
	                             ORDER BY ssgr.profileid asc )                                                         
			LEFT JOIN EmpAssignment AS RoleEmpAssignment ON RoleEmpAssignment.EmpId =ssgrouprole.ProfileId 
			LEFT JOIN positions Rolepositions ON Rolepositions.PositionNo = RoleEmpAssignment.PositionNo 
 			WHERE empassignment.EmpId = @EmpId
 	
 END 


 IF @ResultData = 4  -- get Role Job
 BEGIN

 		SELECT @RoleData= CASE WHEN @ResultType = 1 THEN cast(RoleEmpAssignment.[Job] AS NVARCHAR(MAX))  ELSE ( case when @lang = 'a' THEN RoleJobs.JobAName ELSE  RoleJobs.JobName  END) END  
 		FROM empassignment
 		LEFT JOIN ssgroup ON ssgroup.SSGroup = empassignment.SSGroup
 		INNER JOIN ssgrouprole  ON ssgrouprole.SSGroup = SSGroup.SSGroup AND ssgrouprole.RoleId = @RoleId
		AND ssgrouprole.ProfileId = (SELECT TOP 1 ssgr.profileid 
	                             FROM ssgrouprole ssgr
								 WHERE ssgrouprole.SSGroup=ssgr.SSGroup AND ssgrouprole.RoleId=ssgr.RoleId
	                             ORDER BY ssgr.profileid asc )                                                          
		LEFT JOIN EmpAssignment AS RoleEmpAssignment ON RoleEmpAssignment.EmpId =ssgrouprole.ProfileId 
		LEFT JOIN Jobs RoleJobs ON RoleJobs.[job] = RoleEmpAssignment.[Job] 
 		WHERE empassignment.EmpId = @EmpId
 		
 END 
 
 IF @ResultData=5
 BEGIN 
 	declare @Temp TABLE (EmpId int) 
 	declare @Id AS INT 
 	INSERT INTO @Temp
 	SELECT ssgrouprole.profileid 
 	FROM empassignment 
 	inner JOIN ssgrouprole ON ssgrouprole.SSGroup = empassignment.SSGroup AND ssgrouprole.RoleId=@RoleId
 	WHERE empassignment.empid =@EmpId
 	UNION 
	SELECT wfdelegate.DelegatedProfileId
 	FROM EmpAssignment 
 	inner JOIN ssgrouprole ON ssgrouprole.SSGroup = empassignment.SSGroup AND ssgrouprole.RoleId=@RoleId
    LEFT JOIN WFDelegate ON WFDelegate.ProfileId = ssgrouprole.ProfileId
						 AND WFDelegate.RoleId =@RoleId
						 AND CONVERT(CHAR(10),GETDATE(),111) BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo 
						 AND WFDelegate.ApprovalStatus = 1
						 AND WFDelegate.ssdocno IN (SELECT ssdocument.SSDocNo FROM ssdocument WHERE SSDocType =6)
   	WHERE empassignment.empid =@EmpId
   	
   	DECLARE  Cursor_Emp CURSOR FOR SELECT EmpId FROM @Temp
   	OPEN Cursor_Emp 
   	FETCH NEXT FROM Cursor_Emp INTO @Id
   	WHILE @@FETCH_STATUS=0 
   	BEGIN
   		SET @RoleData =@RoleData+'#'+ltrim(rtrim(str(@Id)))+'#'+','
   	FETCH NEXT FROM Cursor_Emp INTO @Id
   	END
   	CLOSE Cursor_Emp
   	DEALLOCATE Cursor_Emp
   	IF LEN(@RoleData)>0
   	SET @RoleData=SUBSTRING(@RoleData,1 ,LEN(@RoleData)-1)
 END
RETURN @RoleData
END

GO

