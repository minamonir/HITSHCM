CREATE FUNCTION dbo.GetitemParent
  (@itemno smallint)
RETURNS  smallint
AS
BEGIN 
  declare @returnp as smallint ,  @to as int, @menu as bit , @index as int

select @to=count(*) from  nasoptions 

select @returnp=parentno from  nasoptions where itemno = @itemno
while @to <> 0 
begin

select @returnp=itemno , @menu = menuitem from  nasoptions where itemno = @returnp

if @returnp is null  begin 
return 0 
break 
end

if @menu = 1  begin 
return @returnp 
break 
end

select @returnp=parentno from  nasoptions where itemno = @returnp
 set  @to  = @to  -1
end

return @returnp
END

GO

