CREATE FUNCTION [dbo].[RolesExist] 
	(@Str1 as NVARCHAR(max),@Str2 as NVARCHAR(max),@SSGroup AS int ,@UserId AS INT ) RETURNS BIT
AS
BEGIN	
	IF @SSGroup IS NULL RETURN 0
	IF ( SELECT LTRIM(RTRIM(REPLACE(@Str2 ,'$',''))) )='' RETURN 1
	IF @SSGroup <> 0
	BEGIN
		SET @Str1 = '#'
		DECLARE @Roles TABLE (RoleId SMALLINT)
		INSERT INTO @Roles SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId=@UserId AND SSGroupRole.SSGroup=@SSGroup
		SELECT @Str1 = @Str1 + ltrim(RoleId)+'#'
		FROM  @Roles
		IF @Str1 = '#' RETURN 0 
	END 


	IF @Str2 ='$$' RETURN 1
	DECLARE @i AS INT,@j AS INT,@k AS INT, @l AS INT ,@Table AS NVARCHAR(max) ,@RoleId AS NVARCHAR(max)
	DECLARE @Flag1 AS INT , @Flag2 AS INT
	SELECT @Flag1=0,@Flag2=0
	SET @Str2=REPLACE(@Str2,'##','#')
	SET @l=1
	SET @k=CHARINDEX('$',@Str2,@l+1)
		 WHILE @k >0
		 BEGIN	
		 	SET @i=1
			SET @j=CHARINDEX('#',@Str1,@i+1) 
			SELECT @Table=SUBSTRING(@Str2,@l+1,@k-@l-1)
			--SET @Table=REPLACE(@Table,'##','#')
			SELECT @Flag1=@Flag1+1
			WHILE @j >0
			BEGIN
				IF isnull(@Table,'')='' BEGIN  SELECT @Flag2=@Flag2+1 BREAK	END
				SELECT @RoleId=SUBSTRING(@Str1,@i,@j-@i+1)
				IF CHARINDEX(@RoleId,@Table)>0	BEGIN  SELECT @Flag2=@Flag2+1 BREAK	END 
				SELECT @i = @j
				SET @j=CHARINDEX('#',@Str1,@i+1)
			END
			SELECT @l = @k
			SET @k=CHARINDEX('$',@Str2,@l+1)
		 IF @Flag1>@Flag2 RETURN 0 
		 END
	
	RETURN 1
END

GO

