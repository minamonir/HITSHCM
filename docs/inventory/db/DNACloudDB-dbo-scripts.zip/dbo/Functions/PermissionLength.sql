

CREATE FUNCTION [dbo].[PermissionLength](@EmpId as int, @DocNo AS INT,@PermissionNo as smallint, @FromDate as datetime,@ToDate as datetime)
RETURNS int
AS
BEGIN
	Declare @PermissionLength int, @PermissionOverShortType as smallint,@CalcActualPermLength as int=1

	select @CalcActualPermLength=configvalue from sysparamconfig where configid='CalcActualPermLength'

	
	select @PermissionOverShortType=timepermission.overshort  from timepermission where PermissionNo=@PermissionNo


	IF ISNULL(@CalcActualPermLength,0)=1
	BEGIN
	   select @PermissionLength=ISNULL(DATEDIFF(s,@fromdate,@todate),0)
    END
	ELSE
    BEGIN
	  --SELECT @PermissionLength = dbo.x_FullDayPermissionLength(@EmpId, @DocNo ,@PermissionNo, @FromDate ,@ToDate)
	  --SELECT @PermissionLength = CASE @PermissionLength WHEN 0 THEN dbo.PermissionTotalTaken(@empid,@DocNo,@fromdate,@todate,1,@PermissionOverShortType,@fromdate,@todate) 
	  --                                                  ELSE @PermissionLength end
	  SELECT @PermissionLength =  dbo.x_FullDayPermissionLength(@EmpId, @DocNo ,@PermissionNo, @FromDate ,@ToDate)
	
    END
    
	RETURN isnull(@PermissionLength	,0)

END

GO

