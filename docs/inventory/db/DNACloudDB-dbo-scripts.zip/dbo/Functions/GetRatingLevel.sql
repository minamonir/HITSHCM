CREATE FUNCTION dbo.GetRatingLevel
  (@RateScale smallint, @RateType smallint)
RETURNS  smallint
as
BEGIN 
  declare @RatingLevel as smallint
  --ratingscale
   if @RateType=1  select top 1 @RatingLevel=RatingLevel from RatingLevels where RatingScale=@RateScale order by ratingscale, ratinglevel desc
  --competence
   if @RateType=2  select top 1 @RatingLevel=RatingLevel from CompetenceLevels where Competence=@RateScale order by competence, ratinglevel desc
  --questions
   if @RateType=3  select top 1 @RatingLevel=questionoption from QuestionOptions where Questionno=@RateScale order by questionno, questionoption desc
set @RatingLevel=isnull(@RatingLevel,0)
   while  1=1
    begin
     if @RatingLevel>32766    set @RatingLevel=1 else set  @RatingLevel=@RatingLevel+1 
      --ratingscale
     if @RateType=1  and not exists (select RatingLevel from RatingLevels where RatingScale=@RateScale and @RatingLevel=RatingLevel) break
    --competence
     if @RateType=2  and not exists (select RatingLevel from  CompetenceLevels where Competence=@RateScale and @RatingLevel=RatingLevel) break
    --questions
     if @RateType=3  and not exists (select questionoption from   QuestionOptions where questionno=@RateScale and @RatingLevel=questionoption) break
  end
  return @RatingLevel
END

GO

