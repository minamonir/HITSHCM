CREATE FUNCTION [dbo].[hits_VacationRestrictionOLD]
(
	-- Add the parameters for the function here
	 @empid as int, @vaccode as smallint, @fromdate as datetime,@todate as datetime,@lang as nchar(1), @DocumentNo AS int,@PartDayFrom AS BIT,@PartDayTo AS BIT
)
RETURNS nvarchar(200)
AS
BEGIN
declare @Latinlang as nchar(1)
set @Latinlang=@lang 
declare @reason as nvarchar(200)
set @reason =''

declare @VacLength as bit, @MinDays as numeric(9, 3), @MaxDays as numeric(9, 3), @CategoryBal as bit, 
@MinBalBefore as numeric(9, 3), @MinBalAfter as numeric(9, 3), @MaxTotal as bit, 
@MaxTotalNo as numeric(9, 3), @MaxTotalEvery as numeric(9, 3), @MaxTotalEveryUnit as smallint , 
@MaxTotalSince as smallint, @MaxOccurance as bit, @MaxOccuranceNo as smallint, @MaxOccuranceEvery as numeric(9, 3),
@MaxOccEveryUnit as smallint, @MaxOccuranceSince as smallint, @AllowAfter as bit, @AllowAfterNo as numeric(9, 3), 
@AllowAfterUnit as smallint, @AllowAfterSince as smallint,@BalanceTill AS smallint
---select the parameters from VacationPolicy table to compare it with the calc parameters when requesting for new vacation
select @VacLength=VacLength, @MinDays=MinDays, @MaxDays=MaxDays, @CategoryBal=CategoryBal, 
@MinBalBefore=MinBalBefore,@MinBalAfter= MinBalAfter, @MaxTotal=MaxTotal, @MaxTotalNo=MaxTotalNo, 
@MaxTotalEvery=MaxTotalEvery,@MaxTotalEveryUnit= MaxTotalEveryUnit, 
@MaxTotalSince=MaxTotalSince, @MaxOccurance=MaxOccurance, @MaxOccuranceNo=MaxOccuranceNo,
@MaxOccuranceEvery= MaxOccuranceEvery, @MaxOccEveryUnit=MaxOccEveryUnit, @MaxOccuranceSince=MaxOccuranceSince, 
@AllowAfter=AllowAfter,@AllowAfterNo= AllowAfterNo,@AllowAfterUnit= AllowAfterUnit, 
@AllowAfterSince=AllowAfterSince,@BalanceTill=BalanceTill
FROM VacationPolicy
inner join empassignment on empassignment.VacPack=VacationPolicy.vacpack
Where vaccode=@vaccode and empid=@empid



declare @vaclengthno as numeric(9, 3),@vactype as smallint,@balancebefore as numeric(9, 3),@totaldays as numeric(9, 3)
,@date1 as datetime,@date2 as datetime,@balanceafter as numeric(9, 3)
set @vaclengthno=0.0

	declare @enablehijri as bit,@payrollgroup as smallint,@year as smallint,@h_Yearfrom as nchar(4),@h_Yearto as nchar(4)
    ,@h_MonthFrom as nchar(4),@h_MonthTo as nchar(4)
	select @vactype=vactype ,@enablehijri=enablehijri from Vacation cross join sysparam where vaccode=@vaccode
	
	select @payrollgroup=EmpAssignment.PayrollGroup,@Year=Cyear 
	from EmpAssignment inner join PayrollGroup on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup where EmpId=@empid


	select @vaclengthno=dbo.VacTakenDays(@EmpId, @FromDate, @ToDate, @VacCode,@DocumentNo,@PartDayFrom,@PartDayTo)
----------------------------------------MinDays and MaxDays-------------------------------------------------------------
if @vaclength=1
begin
--calc the duration of the vacation requested & check that it s between min & max days required
	if @vaclengthno not between @MinDays and @MaxDays
		begin
				set @reason='002 - '+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','MinMaxDays',@latinlang))),(case when @latinlang='E' then 'vacation length is not between min and max days' else N' مدة الاجازة ليست فى الفترة المسموح بها ' end))
				return @reason
		end
end
----------------------------------------------------------------------------------------------------------------------
----------------------------------------AllowAfter--------------------------------------------------------------------------

if @AllowAfter=1
--@AllowAfterSince: check on hire or prob dates

begin
--@date1= hire or prob date according to @AllowAfterSince
	select @date1=case when @AllowAfterSince=1 then hiredate when @AllowAfterSince=2 then probdate end 
	from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid

	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @AllowAfterUnit=2 then dbo.h_dateadd('MM', @AllowAfterNo,@date1)
		when @AllowAfterUnit=3 then dbo.h_dateadd('YY',@AllowAfterNo,@date1)
		else dbo.h_dateadd('DD',@AllowAfterNo,@date1)end-1

	end
	else
	begin	
--@date2= @date1 + @AllowAfterNo
--@AllowAfterUnit : determines whether @AllowAfterNo is day, month or year
		set @date2=case
		when @AllowAfterUnit=2 then dateadd(m,@AllowAfterNo,@date1)
		when @AllowAfterUnit=3 then dateadd(yy,@AllowAfterNo,@date1)
		else dateadd(d,@AllowAfterNo,@date1)end-1
	end
--@date2: date at which it is allowed after it to request for vacation
--compare the vacation date with @date2 
	if @fromdate <=@date2
	begin 
		select @reason='005 - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','AllowAfter',@latinlang))),(case when @latinlang='E' then 'The vacation is allowed after' else N'مسموح بالاجازة بعد' end))+' '+ltrim(rtrim(str(@AllowAfterNo)))+ ' '
+ case when @AllowAfterUnit=2 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('DDLPeriodType','4',@latinlang))),(case when @latinlang='E' then 'Months' else N'شهور' end))  
when @AllowAfterUnit=3 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('DDLPeriodType','6',@latinlang))),(case when @latinlang='E' then 'Years' else N'سنين' end)) 
else isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('DDLPeriodType','2',@latinlang))),(case when @latinlang='E' then 'Days' else N'أيام' end))  end 
+' '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('Common','From',@latinlang))),(case when @latinlang='E' then 'From' else N'من' end)) + ' '+
+case when @AllowAfterSince=1 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','HIREDATE',@latinlang))),(case when @latinlang='E' then 'Hire Date ' else N' تاريخ التوظيف ' end)) ) 
when @AllowAfterSince=2 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','PROBDATE',@latinlang))),(case when @latinlang='E' then 'Probation Date ' else N' تاريخ إنتهاء فترة الإختبار ' end))) end 
		return @reason
	end
end
---------------------------------------minbalbefore & minbalafter------------------------------------------------------

if @CategoryBal=1
-- @BalanceTill=0 balance till end of the year
-- @BalanceTill=1 balance till end of the month
begin

	if @enablehijri=1 and @year<1900
	BEGIN
		IF @BalanceTill=0
		BEGIN
			select @h_Yearfrom=dbo.GetDatePart('y',@fromdate),@h_Yearto=dbo.GetDatePart('y',@todate)
			select @balancebefore=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup, 12,
			case when dbo.periodend(@PayrollGroup,12,@h_Yearfrom)<@fromdate then @h_Yearfrom+1 else  @h_Yearfrom end),@vactype),	
			@balanceafter=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup, 12,
			case when dbo.periodend(@PayrollGroup,12,@h_Yearto)<@todate then @h_Yearto+1 else @h_Yearto end),@vactype)
		END
		ELSE
		BEGIN
			select @h_Yearfrom=dbo.GetDatePart('y',@fromdate),@h_Yearto=dbo.GetDatePart('y',@todate),
			@h_MonthFrom=dbo.GetDatePart('m',@fromdate),@h_MonthTo=dbo.GetDatePart('m',@todate)
			
			select @balancebefore=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup,
			CASE WHEN dbo.periodend(@PayrollGroup,@h_MonthFrom,@h_Yearfrom)<@fromdate THEN (CASE WHEN @h_MonthFrom=12 THEN 1 ELSE @h_MonthFrom + 1 END)  ELSE @h_MonthFrom end ,
			CASE WHEN dbo.periodend(@PayrollGroup,@h_MonthFrom,@h_Yearfrom)<@fromdate THEN (CASE WHEN @h_MonthFrom=12 THEN @h_Yearfrom+1 ELSE @h_Yearfrom END) ELSE @h_Yearfrom END),@vactype),	
			@balanceafter=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup, 
			CASE WHEN dbo.periodend(@PayrollGroup,@h_MonthTo,@h_Yearto)<@todate THEN (CASE WHEN @h_MonthTo=12 THEN 1 ELSE @h_MonthTo+1 END)  ELSE @h_MonthTo end ,
			CASE WHEN dbo.periodend(@PayrollGroup,@h_MonthTo,@h_Yearto)<@todate THEN (CASE WHEN @h_MonthTo=12 THEN @h_Yearto+1 ELSE @h_Yearto END) ELSE @h_Yearto END),@vactype)	
		END
	end
	else
	BEGIN
		IF @BalanceTill=0
		BEGIN
--calc the balance before the requested vacation
			select @balancebefore=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup, 12,
			case when dbo.periodend(@PayrollGroup,12,Year(@fromdate))<@fromdate then Year(@fromdate)+1 else  year(@Fromdate) end),@vactype),	
--	calc the balance after the requested vacation		
			@balanceafter=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup, 12,
			case when dbo.periodend(@PayrollGroup,12,Year(@todate))<@todate then Year(@todate)+1 else  year(@todate) end),@vactype)
		END
		ELSE
		BEGIN
			select @balancebefore=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup,
			CASE WHEN dbo.periodend(@PayrollGroup,month(@fromdate),year(@fromdate))<@fromdate THEN (CASE WHEN month(@fromdate)=12 THEN 1 ELSE month(@fromdate)+1 END) ELSE month(@fromdate) end ,
			CASE WHEN dbo.periodend(@PayrollGroup,month(@fromdate),year(@fromdate))<@fromdate THEN (CASE WHEN month(@fromdate)=12 THEN YEAR(@fromdate)+1 ELSE YEAR(@fromdate) END) ELSE YEAR(@fromdate) END),@vactype),	
			@balanceafter=dbo.EmpVacBal(@empid,
			dbo.periodend(@payrollgroup, 
			CASE WHEN dbo.periodend(@PayrollGroup,month(@todate),year(@todate))<@todate THEN (CASE WHEN month(@todate)=12 THEN 1 ELSE month(@todate)+1 END) ELSE month(@todate) end ,
			CASE WHEN dbo.periodend(@PayrollGroup,month(@todate),year(@todate))<@todate THEN (CASE WHEN month(@todate)=12 THEN YEAR(@todate)+1 ELSE YEAR(@todate) END) ELSE YEAR(@todate) END),@vactype)
			
		end
	end
--compare the calculated balance with min balance required	
	if @balancebefore<=@MinBalBefore 
	begin
		set @reason='003 - '+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','MinBalanceBefore',@latinlang))),(case when @latinlang='E' then 'balance before vacation is less than min balance required  ' else N'الرصيد قبل الاجازة اقل من الحد الادني المسموح ' end))
		--select @reason
		return @reason
	end

	set @balanceafter=@balanceafter-@vaclengthno
	--select @balancebefore,@balanceafter

--compare the calculated balance after with min balance after required	
	if @balanceafter<@MinBalAfter 
	begin
		set @reason='004 - '+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','MinBalanceAfter',@latinlang))),(case when @latinlang='E' then 'balance after vacation is less than min balance required  ' else N' الرصيد بعد الاجازة اقل من الحد الادني المسموح' end))
		return @reason
	end
end

-------------------------------------------------------Total days-------------------------------------------------------------

if @MaxTotal=1
--@MaxTotalSince: check on hire or prob dates
begin
--@date1= hire or prob date according to @MaxTotalSince
	select @date1=case when @MaxTotalSince=1 then hiredate when @MaxTotalSince=2 then probdate end 
	from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)
		else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)end-1
		
		while (@fromdate not between @date1 and @date2)
		begin
			set @date1=@date2+1
			set @date2=case
			when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)
			else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)end-1
		end
	
	end
	else
	begin
--@date2= @date1 + @MaxTotalEvery
--@MaxTotalEveryUnit : determines whether @MaxTotalEvery is day, month or year
--@MaxTotalEvery: the parameter at which max total days 'll reset
		set @date2=case
		when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
		else dateadd(d,@MaxTotalEvery,@date1)end-1
		while (@fromdate not between @date1 and @date2)
		begin
			set @date1=@date2+1
			set @date2=case
			when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
			else dateadd(d,@MaxTotalEvery,@date1)end-1
		end	
	end
	--calc total days for all vacation taken
	select @totaldays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
	(e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
	(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
	@date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocumentNo,@PartDayFrom,@PartDayTo) else 0 end) ,0)
	from empvacat e  where e.vacstatus=1 and e.empid=@empid and e.vaccode=@vaccode
	
	
    --add taken days of the current requested vac to total days calculated above
	set @totaldays=@totaldays+dbo.VacTakenDays(@EmpId, @FromDate,case when  @ToDate <@date2 then @todate else @date2 end, @VacCode,@DocumentNo,@PartDayFrom,@PartDayTo)
	--compare the calculated total days with Max Total Allowed
	if @MaxTotalNo<@totaldays 
	begin
		set @reason='006 - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','TotalDays',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max total days' else N' الاجازة تتعدى الحد الاقصى للايام المسموح بها' end))
		return @reason
	end


while  (@todate not between @date1 and @date2 ) 
begin

	set @date1=@date2+1
	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)
		else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)end-1

	end
	else
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
		else dateadd(d,@MaxTotalEvery,@date1)end-1
	end
	
set @totaldays=0
select @totaldays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
 (e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
 @date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocumentNo,@PartDayFrom,@PartDayTo) else 0 end) ,0)
 from empvacat e  
where e.vacstatus=1 and e.empid=@empid and e.vaccode=@vaccode


set @totaldays=@totaldays+dbo.VacTakenDays(@EmpId, @date1,case when  @ToDate <@date2 then @todate else @date2 end, @VacCode,@DocumentNo,@PartDayFrom,@PartDayTo)

if @MaxTotalNo<@totaldays 
begin
	set @reason='007 - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','TotalDays',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max total days' else N' الاجازة تتعدى الحد الاقصى للايام المسموح بها' end))
	return @reason
end

end

end
---------------------------------------------Occurance------------------------------------------------------------------------

if @MaxOccurance=1
--@MaxOccuranceSince: check on hire or prob dates
begin
--@date1= hire or prob date according to @MaxOccuranceSince
	declare @count as int
	set @count=0
	select @date1=case when @MaxOccuranceSince=1 then hiredate when @MaxOccuranceSince=2 then probdate end 
	from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid

if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)
		else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)end-1
		
		while (@fromdate not between @date1 and @date2)
		begin
			set @date1=@date2+1
			set @date2=case
			when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)
			when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)
			else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)end-1
		end
	end
	
else
	begin
--@date2= @date1 + @MaxOccuranceEvery
--@MaxOccEveryUnit : determines whether @MaxOccuranceEvery is day, month or year
--@MaxOccuranceEvery: the parameter at which max Occurance 'll reset
		set @date2=case
		when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
		else dateadd(d,@MaxOccuranceEvery,@date1)end-1
		
		while (@fromdate not between @date1 and @date2)
		begin
		set @date1=@date2+1
		set @date2=case
		when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
		else dateadd(d,@MaxOccuranceEvery,@date1)end-1

		end
	end

--calc how many times the vacation taken by this empployee
select @count=count(*) 
 from empvacat e  
where e.vacstatus=1 and e.empid=@empid and e.vaccode=@vaccode
and ((e.fromdate between @date1 and @date2) or 
 (e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
(@date2 between e.fromdate  and e.todate))
--add the current requested vac to the above count calculated
set @count=@count+1
--compare the Calculated Count above with Max Occurance allowed
if @MaxOccuranceNo<@count 
begin
set @reason='008 - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max no of occurance' else N'عدد مرات تكرار الاجازة قد تعدى الحد المسموح به ' end)) 
return @reason
end

-----------------------------
while  (@todate not between @date1 and @date2 ) 
begin

	set @date1=@date2+1
	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dbo.h_dateadd('MM', @MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dbo.h_dateadd('YY',@MaxTotalEvery,@date1)
		else dbo.h_dateadd('DD',@MaxTotalEvery,@date1)end-1

	end
	else
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
		else dateadd(d,@MaxTotalEvery,@date1)end-1
	end
	
set @count=0
select @count=count(*) 
 from empvacat e  
where e.vacstatus=1 and e.empid=@empid and e.vaccode=@vaccode
and ((e.fromdate between @date1 and @date2) or 
 (e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
(@date2 between e.fromdate  and e.todate))

set @count=@count+1
if @MaxOccuranceNo<@count 
begin
set @reason='009 - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max no of occurance' else N'عدد مرات تكرار الاجازة قد تعدى الحد المسموح به ' end)) 
return @reason
end

end
-----------------------------

end

return '001'
end

GO

