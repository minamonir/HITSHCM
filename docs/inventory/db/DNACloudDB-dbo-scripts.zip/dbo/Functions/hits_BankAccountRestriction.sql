
CREATE Function [dbo].[hits_BankAccountRestriction] (@empid INT , @paybankact NVARCHAR(30) ,@paybankno SMALLINT , @paymentType AS SMALLINT ,@paymentInactive AS BIT ,@ErrorLang AS CHAR  )
RETURNS nvarchar(MAX)
AS 
BEGIN

--@BankAccountNoUnique =0 not unique
--@BankAccountNoUnique =1 unique for all employees
--@BankAccountNoUnique =2 unique per Bank 

 DECLARE @BankAccountNoUnique as NVARCHAR(1)='0'
 SELECT  @BankAccountNoUnique=configValue FROM sysparamconfig WHERE configId = 'BankAccountNoUnique'
 
 DECLARE @PaymentBank AS BIT  
 SELECT @PaymentBank =paymentbank FROM PaymentTypes WHERE paymenttype =@paymenttype 
 
 DECLARE @strValidation AS NVARCHAR(MAX)=''
 
 IF @BankAccountNoUnique ='0'
	 BEGIN
 		RETURN '001'
	 END
 
 ELSE IF @BankAccountNoUnique='1' AND @PaymentBank =1 AND @paybankact <>'' AND @paymentInactive =0
		 AND  EXISTS( select distinct empid from MonthlyPayment WITH (NOLOCK)
							   WHERE LTRIM(RTRIM(MonthlyPayment.PayBankAct)) =@paybankact AND Monthlypayment.empid <>@empid )						   
	 BEGIN
				SET @strValidation = @strValidation + ISNULL((SELECT dbo.Hits_GetDCCaption('Z_BankAccountNoValidation','BankAccountRepeatingCheck',@ErrorLang)),
									CASE WHEN @ErrorLang = 'A' THEN N'يوجد موظف بنفس رقم الحساب' ELSE 'Another employee has the same bank account number' END )
				RETURN '002 - ' +@strValidation
	END	

 ELSE IF @BankAccountNoUnique='2' AND @PaymentBank =1 AND @paybankact <>'' AND @paymentInactive =0
		 AND  EXISTS( select distinct empid from MonthlyPayment WITH (NOLOCK)
							   WHERE LTRIM(RTRIM(MonthlyPayment.PayBankAct)) =@paybankact
							   AND Monthlypayment.PayBankNo=@paybankno AND Monthlypayment.empid <>@empid )						   
	 BEGIN
				   SET @strValidation = @strValidation + ISNULL((SELECT dbo.Hits_GetDCCaption('Z_BankAccountNoValidation','BankAccountRepeatingCheckPerBank',@ErrorLang)),
										CASE WHEN @ErrorLang = 'A' THEN N'يوجد موظف بنفس رقم الحساب على نفس البنك' ELSE 'Another employee has the same bank account number in this Bank' END )  
				RETURN '002 - ' +@strValidation
	END	

	RETURN '001'			  
 END

GO

