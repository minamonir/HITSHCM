CREATE FUNCTION [dbo].[GetUserType] (@ProfileId int)
RETURNS  smallint
AS 

BEGIN 
	DECLARE @UserType AS SMALLINT
	SELECT @UserType = dbo.GetPersonType(@ProfileId) 

	RETURN @UserType


END

GO

