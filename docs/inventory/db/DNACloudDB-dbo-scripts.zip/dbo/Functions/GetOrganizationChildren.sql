CREATE FUNCTION [dbo].[GetOrganizationChildren] 
	(@ParentNo as smallint, @IncludeParent as SMALLINT = 0) RETURNS @Temp TABLE (Org SMALLINT)
AS


	-- @IncludeParent = 0 [SubOrganization Only]
	-- @IncludeParent = 1 [SubOrganization + ParentOrganization]
	-- @IncludeParent = 2 [ParentOrganization Only]
BEGIN
	DECLARE @TempOrg AS SMALLINT 
	INSERT INTO @Temp(Org) SELECT @ParentNo

	DECLARE Org_Cursor CURSOR FOR
	SELECT Org FROM @Temp 	
	OPEN Org_Cursor
	FETCH NEXT FROM Org_Cursor INTO @TempOrg
	WHILE @@FETCH_STATUS = 0
	BEGIN						   
		
		INSERT INTO @Temp (Org) select organization FROM OrganizationStructure WHERE OrganizationParent=@TempOrg
		and organization not in (select Org from @Temp )

		FETCH NEXT FROM Org_Cursor INTO @TempOrg
	END
	CLOSE Org_Cursor
	DEALLOCATE Org_Cursor
	IF @IncludeParent = 0 DELETE FROM @Temp WHERE Org = @ParentNo
	IF @IncludeParent = -1 DELETE FROM @Temp WHERE Org <> @ParentNo
	
	RETURN
END

GO

