CREATE FUNCTION [dbo].[GetPositionParentCodes](@position INT)
RETURNS nvarchar(max) AS  

begin
DECLARE @positionstring AS nvarchar(max)=''
DECLARE @positionparent AS INT=NULL
WHILE @position IS NOT NULL
BEGIN
set @positionstring=@positionstring+CASE WHEN @positionstring<>'' THEN ',' ELSE '' end+LTRIM(@position)
SELECT @positionparent=dbo.PositionView.PositionParent FROM dbo.PositionView
WHERE dbo.PositionView.positionno=@position
SET @position=@positionparent
END
RETURN @positionstring
end

GO

