
CREATE  FUNCTION [dbo].[EmpTrainingCost](@Event as bigint,@EmpId as int,@DocumentNo as int,@CostItem as SMALLINT ,@Currency as SMALLINT,@Actual AS BIT,@Confirmed as BIT,@From AS SMALLDATETIME,@To AS SMALLDATETIME,@CostItemType AS SMALLINT)   
RETURNS numeric (18,3) AS  
BEGIN

-----------------------------------------------------------------------------------------------------------------------------------------
-- parameters to be used in code
---------------------------------
DECLARE @employeecost AS NUMERIC(18,3),@Total AS NUMERIC(18,3),@sysCur AS SMALLINT

--system currency :
SELECT @sysCur = SysParam.syscur FROM SysParam 
------------------------------------------------------------------------------------------------------------------------------------------
-- Temp Table for each event Cost (Resource Cost) & number of employees/event
-------------------------------------------------------------------------------
DECLARE @EventResourceData TABLE (TEMPTrainingEvent2 BIGINT,EmpCount INT
,TEMPTrainingEventFrom SMALLDATETIME,TEMPTrainingEventTo SMALLDATETIME
,TEMPTrainingResource INT,TEMPResourceCategory SMALLINT,EventCost NUMERIC(18,3) )
-----------------------------------------------------------------------------------
--1st insert with filter on @event & @from & @to
------------------------------------------------
INSERT INTO @EventResourceData(TEMPTrainingEvent2,EmpCount,TEMPTrainingEventFrom,TEMPTrainingEventTo)
SELECT isnull(EmpTraining.TrainingEvent,0),COUNT(Distinct EmpTraining.EmpId) AS EmpCount,
(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END),(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END )
FROM  EmpTraining  
LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = EmpTraining.TrainingEvent
INNER JOIN TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4)
WHERE 
 ((isnull(@From,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END)) BETWEEN (CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END) AND (CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END ) )
OR (isnull(@To,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END )) BETWEEN (CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END) AND(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END ))
OR ((CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END) BETWEEN isnull(@From,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END)) AND isnull(@To,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END )))
OR ((CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END ) BETWEEN isnull(@From,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END)) AND isnull(@To,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END ))))
AND (CASE WHEN @Event IS NULL THEN isnull(EmpTraining.TrainingEvent,0) ELSE @Event END ) = isnull(EmpTraining.TrainingEvent,0)
GROUP BY EmpTraining.TrainingEvent,(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN Emptraining.AdditionalTrainingFrom ELSE TrainingEvents.EventFromDate END),(CASE WHEN EmpTraining.AdditionalTraining = 1 THEN emptraining.AdditionalTrainingTo ELSE TrainingEvents.EventToDate END )
--------------------------------------------------------------------------------------------------------------------------------------------
-- 2nd insert (resources)
---------------------------
INSERT INTO @EventResourceData
SELECT distinct Temp1.TEMPTrainingEvent2,Temp1.EmpCount,
Temp1.TEMPTrainingEventFrom,Temp1.TEMPTrainingEventTo,TrainingResourcesBooking.TrainingResource,
TrainingResourcesBooking.ResourceCategory,0
FROM TrainingResourcesBooking
INNER JOIN @EventResourceData Temp1 ON Temp1.TEMPTrainingEvent2 = TrainingResourcesBooking.TrainingEvent AND Temp1.TEMPTrainingEvent2 <> 0
LEFT JOIN TrainingResources ON TrainingResources.TrainingResource = TrainingResourcesBooking.TrainingResource AND TrainingResources.ResourceCategory = TrainingResourcesBooking.ResourceCategory
LEFT JOIN TrainingCostItems ResourceCostItem ON ResourceCostItem.TrainingCostItem =TrainingResources.TrainingCostItem
LEFT JOIN TrainingCostItems BookCostItem ON BookCostItem.TrainingCostItem = TrainingResourcesBooking.TrainingCostItem
INNER JOIN EmpTraining ON TEMPTrainingEvent2 = emptraining.TrainingEvent
INNER JOIN TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus AND TrainingEnrollStatus.SystemEnrollStatus IN (2,4)
WHERE (CASE WHEN @EmpId IS NULL THEN EmpTraining.EmpId ELSE @EmpId END) = EmpTraining.EmpId  
AND CASE WHEN @DocumentNo IS NULL THEN EmpTraining.DocumentNo ELSE @DocumentNo END = EmpTraining.DocumentNo
AND ((isnull(@From,trainingresourcesbooking.bookfrom) BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto )
OR (isnull(@To,trainingresourcesbooking.bookto) BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto)
OR (trainingresourcesbooking.bookfrom BETWEEN isnull(@From,trainingresourcesbooking.bookfrom) AND isnull(@To,trainingresourcesbooking.bookto))
OR (trainingresourcesbooking.bookto BETWEEN isnull(@From,trainingresourcesbooking.bookfrom) AND isnull(@To,trainingresourcesbooking.bookto)))
AND TrainingResourcesBooking.BookStatus=(CASE WHEN @Confirmed = 1 THEN 1 ELSE TrainingResourcesBooking.BookStatus END )
AND (CASE WHEN @CostItem IS NOT NULL THEN @CostItem ELSE (CASE WHEN BookCostItem.TrainingCostItem IS NOT NULL THEN BookCostItem.TrainingCostItem ELSE ResourceCostItem.TrainingCostItem END ) END) = (CASE WHEN BookCostItem.TrainingCostItem IS NOT NULL THEN BookCostItem.TrainingCostItem ELSE ResourceCostItem.TrainingCostItem END )
AND (CASE WHEN @CostItemType IS NOT NULL THEN @CostItemType ELSE (CASE WHEN BookCostItem.TrainingCostItem IS NOT NULL THEN BookCostItem.TrainingCostItemType ELSE ResourceCostItem.TrainingCostItemType END )END ) = (CASE WHEN BookCostItem.TrainingCostItem IS NOT NULL THEN BookCostItem.TrainingCostItemType ELSE ResourceCostItem.TrainingCostItemType END )
------------------------------------------------------------------------------------------------------------------------------------------
-- update cost using resource Utilization
-------------------------------------------
Update @EventResourceData 
set EventCost = isnull(dbo.Resource_Utilization(TEMPTrainingResource,TEMPResourceCategory,TEMPTrainingEventFrom,TEMPTrainingEventTo,TEMPTrainingEvent2,@Actual,1,isnull(@Currency,@sysCur),@Confirmed),0)
FROM @EventResourceData 
WHERE TEMPTrainingResource IS NOT NULL

-------------------------------------------------------------------------------------------------------------------------------------------
-- Employees Cost
------------------
SELECT @employeecost=SUM(dbo.ConvertAmount(EmpTrainingCostItems.CostItemAmount,EmpTrainingCostItems.CostItemCurrency,isnull(@Currency,@sysCur),TEMPTrainingEventFrom )*(CASE WHEN TrainingCostItems.TrainingCostItemType = 1 THEN 1 ELSE -1 END )) 
FROM EmpTraining 
INNER JOIN @EventResourceData ON isnull(EmpTraining.TrainingEvent,0) = TEMPTrainingEvent2 
AND isnull(TEMPTrainingResource,0) = 0 
AND (CASE WHEN EmpTraining.AdditionalTraining=1 THEN EmpTraining.AdditionalTrainingFrom ELSE TEMPTrainingEventFrom  END) = TEMPTrainingEventFrom
AND (CASE WHEN EmpTraining.AdditionalTraining=1 THEN EmpTraining.AdditionalTrainingTo ELSE TEMPTrainingEventTo END) = TEMPTrainingEventTo
LEFT JOIN EmpTrainingCostItems ON EmpTrainingCostItems.EmpId = EmpTraining.EmpId 
AND EmpTrainingCostItems.DocumentNo = EmpTraining.DocumentNo
LEFT JOIN TrainingCostItems ON TrainingCostItems.TrainingCostItem = EmpTrainingCostItems.TrainingCostItem
LEFT JOIN TrainingEnrollStatus On EmpTraining.EnrollStatus=TrainingEnrollStatus.EnrollStatus
WHERE 
 TrainingEnrollStatus.SystemEnrollStatus in (2,4)
AND (CASE WHEN @CostItem IS NULL THEN EmpTrainingCostItems.TrainingCostItem ELSE @CostItem END) = EmpTrainingCostItems.TrainingCostItem
AND (CASE WHEN @CostItemType IS NULL THEN TrainingCostItems.TrainingCostItemType ELSE @CostItemType END) = TrainingCostItems.TrainingCostItemType
AND (CASE WHEN @EmpId IS NULL THEN EmpTraining.EmpId ELSE @EmpId END ) = EmpTraining.EmpId
AND (CASE WHEN @DocumentNo IS NULL THEN EmpTraining.DocumentNo ELSE @DocumentNo END) = EmpTraining.DocumentNo
-------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------
-- Total Amount
----------------
SELECT @Total = isnull(sum(EventCost /(CASE WHEN @EmpId IS NOT NULL THEN EmpCount ELSE 1 END)),0) + isnull(@employeecost,0)
FROM @EventResourceData 
-----------------------------------------------------------------------------------------------------------------------------------------
RETURN isnull(@Total,0)

END

GO

