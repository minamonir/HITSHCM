




CREATE      FUNCTION [dbo].[WFAccessEmployee]
  (@RoleProfileid int, @Empid int ,  @Itemno as smallint )
RETURNS  int
as
BEGIN
declare @accessemployee as int
set @accessemployee = 0
SELECT     @accessemployee = count(*)
FROM         SSRole INNER JOIN
				 	  SSGroupRole ON SSRole.RoleId = SSGroupRole.RoleId INNER JOIN
					  EmpAssignment ON SSGroupRole.SSGroup = EmpAssignment.SSGroup INNER JOIN
					  UserGroupRights ON SSRole.UserGroup = UserGroupRights.UserGroup 
					  inner join NasUsers on NasUsers.Empid=@RoleProfileid 

WHERE     itemno = @itemno AND SSGroupRole.profileid = @RoleProfileid and empassignment.empid =@empid
and (empassignment.privacy between NasUsers.PrivacyLevelFrom and NasUsers.PrivacyLevelTo)




return isnull(@accessemployee,0)
END

GO

