
CREATE FUNCTION [dbo].[IOTAPIGetPointsSubLocation] (@CamID INT , @Objx FLOAT , @objy FLOAT , @Objx1 FLOAT , @objy1 FLOAT )
RETURNS INT
--RETURNS NVARCHAR(MAX) 

AS
BEGIN
	
	 DECLARE @SubLocation VARCHAR(8000) ='', @substr VARCHAR(255) = ',', @start INT=0, @occurrence INT=1 , @PointsCounter INT , @ActualLocation INT , @ObjPoints NVARCHAR(max)
	 DECLARE @CurIOTDeviceLoc INT
	 --get all sub locations
	-- SELECT @SubLocation = '0, 0, 4, 0, 4, 4, 0, 4'
	 SELECT @ObjPoints = LTRIM(RTRIM(STR(@Objx))) +' ' + LTRIM(RTRIM(STR(@objy))) +', '+
						 LTRIM(RTRIM(STR(@Objx1))) + ' '+ LTRIM(RTRIM(STR(@objy))) +', '+
						 LTRIM(RTRIM(STR(@Objx1))) +' ' + LTRIM(RTRIM(STR(@objy1))) +', '+
						 LTRIM(RTRIM(STR(@Objx))) +' ' + LTRIM(RTRIM(STR(@objy1))) +', '+
						 LTRIM(RTRIM(STR(@Objx))) +' ' + LTRIM(RTRIM(STR(@objy)))

		DECLARE @temp AS table (ObjExist BIT , DeviceLocation INT , IntersectPer NUMERIC (18,3) )

		
		DECLARE CurGetLocation CURSOR FOR
		    SELECT IOTDeviceLocation , LocationImagePoints 
			FROM dbo.IOTDeviceLocations 
			WHERE ISNULL(LocationImagePoints,'') <> '' 
			AND  IOTDeviceLocationParent IN (SELECT IOTDeviceLocation FROM dbo.IOTLocationDevices WHERE IOTDevice = @CamID)

		OPEN CurGetLocation
		FETCH NEXT FROM CurGetLocation INTO @CurIOTDeviceLoc , @SubLocation
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @PointsCounter = LEN(@SubLocation) - LEN(REPLACE(@SubLocation, ',', '')) 
			WHILE	 @PointsCounter > 0
			BEGIN
				SET @occurrence = @PointsCounter
				DECLARE @found INT = @occurrence,@pos INT = @start;
				WHILE 1=1 
				BEGIN
				-- Find the next occurrence
					SET @pos = CHARINDEX(@substr, @SubLocation, @pos);
 				-- The required occurrence found
					IF @found = 1
					BREAK;
				-- Prepare to find another one occurrence
					SET @found = @found - 1;
					SET @pos = @pos + 1;
				END
				SET @PointsCounter = @PointsCounter -2
				SET  @SubLocation = STUFF(@SubLocation , @pos ,1 ,' ')
			END	
			SET @SubLocation = @SubLocation +', '+SUBSTRING(@SubLocation , 0 , CHARINDEX(',' , @SubLocation , 0))

			DECLARE @polygons table( name varchar(32), shape geometry ) 
			INSERT into @polygons values 
			('Area', geometry::STGeomFromText('POLYGON(('+LTRIM(RTRIM(@SubLocation))+'))', 0))
 
			DECLARE @points table( id int identity(1,1),  position geometry ) 
			INSERT into @points values 
			(geometry::STGeomFromText('POLYGON(('+LTRIM(RTRIM(@ObjPoints))+'))',0)) 

			INSERT INTO @temp
			        (DeviceLocation,ObjExist , IntersectPer )
			SELECT @CurIOTDeviceLoc, 1 , position.STIntersection((SELECT shape FROM @polygons WHERE name='Area')).STArea() / position.STArea()
			FROM @points 
			WHERE position.STWithin((SELECT shape FROM @polygons WHERE name='Area'))=1 
			OR position.STIntersects((SELECT shape FROM @polygons WHERE name='Area'))=1 
			DELETE FROM @points 
			DELETE FROM @polygons
		FETCH NEXT FROM CurGetLocation INTO @CurIOTDeviceLoc , @SubLocation
		END
		CLOSE CurGetLocation
		DEALLOCATE CurGetLocation
        SET @CurIOTDeviceLoc = 0
		SELECT TOP 1 @CurIOTDeviceLoc = DeviceLocation FROM @temp WHERE ObjExist = 1 ORDER BY IntersectPer DESC	 
		RETURN @CurIOTDeviceLoc

END

GO

