
CREATE       FUNCTION [dbo].[Greg2HijriTime] (  @l_gergdate1 As DateTime)  
RETURNS nchar(19) AS  
begin
declare @l_returndate1 As nvarchar(19)
select  @l_returndate1 = dbo.Greg2Hijri(@l_gergdate1,'E')
declare @time as nvarchar(15)
set @l_returndate1=@l_returndate1+' '+convert(nvarchar(15),@l_gergdate1,108)   

return @l_returndate1

END

GO

