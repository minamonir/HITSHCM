Create    FUNCTION [dbo].[Hits_IsItemEligible](@itemno as INT,@CodeGuid UNIQUEIDENTIFIER , @empid as INT ,@date AS SMALLDATETIME ,@logonname AS NVARCHAR(80))
RETURNS BIT 
AS
BEGIN
-- @itemno refers to the itemno of each page calling this Fn.
declare @eligible as bit,@EligibleNo as smallint,@count as int

SELECT @count=count(SetupCodesEligibility.EligibleNo)
FROM SetupCodesEligibility  Where SetupCodesEligibility.itemno = @itemno AND CodeGuid=@CodeGuid   and required=1

set @eligible=case when @count=0 then 1 else 0 end 

declare Eligible_Profiles cursor for SELECT distinct SetupCodesEligibility.EligibleNo
FROM SetupCodesEligibility  Where SetupCodesEligibility.itemno = @itemno AND CodeGuid=@CodeGuid   and required=1

OPEN Eligible_Profiles
FETCH NEXT FROM Eligible_Profiles 
into @EligibleNo
WHILE @@FETCH_STATUS = 0
BEGIN

select @eligible=dbo.Hits_ISEligible(@empid,@EligibleNo,@date)
if @eligible=1 break
FETCH NEXT FROM Eligible_Profiles
into @EligibleNo 
END
CLOSE Eligible_Profiles
DEALLOCATE Eligible_Profiles
RETURN @eligible

END

GO

