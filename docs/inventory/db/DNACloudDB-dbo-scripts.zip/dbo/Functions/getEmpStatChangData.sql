CREATE function getEmpStatChangData
(
    @empid INT
)
RETURNS TABLE
AS

RETURN
     
	 (select d.FieldNo ,
       max(h.EffectiveDate) as effectiveDate,
	   d.EmpId ,
	   max(d.DocumentNo) as DocumentNo,
	   max(d.NewValue) as NewValue
 from EmpStatusDtl as d  
  join EmpStatusHdr as h
  on d.DocumentNo=h.DocumentNo and
     d.EmpId=h.EmpId 
	where d.EmpId=@empid
	 group by d.FieldNo ,d.EmpId  )

GO

