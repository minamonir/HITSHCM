CREATE  FUNCTION [dbo].[GetEmpMarketPosition] (@Grade SMALLINT , @TotalSalary NUMERIC)
RETURNS NVARCHAR(20) 
AS 
BEGIN
    DECLARE @MarketPosition AS NVARCHAR(20) = N''
       BEGIN   
              SELECT TOP 1 @MarketPosition=MarketPosition FROM X_MarketPosition WHERE Grade = @Grade and @TotalSalary BETWEEN Minamount  AND maxamount
       END
       RETURN  @MarketPosition
END

GO

