CREATE       FUNCTION [dbo].[Hijri2Greg] (  @l_hijridate As nchar(10)  )  
RETURNS smalldatetime AS  

begin
declare @l_month As smallint
declare @l_day As smallint
declare @l_noofdays As Integer
declare @l_returndate As smalldatetime
--declare @l_returndate As DATETIME

declare @l_sign As Integer
declare @l_hijripass As Integer
declare @l_hijriref As Integer
declare @l_start As Integer
declare @l_fstart As Integer
declare @l_end As Integer
declare @l_dateformat As smallint
declare @l_totaladjust as integer

set @l_fstart=0
set @l_noofdays=0
set @l_sign=1
set @l_day=0
set @l_hijriref=142110

if ltrim(@l_hijridate) =N'' return null



select @l_dateformat=sysparam.dateformat from sysparam

set @l_hijripass= CASE when @l_dateformat=0 then cast(SUBSTRING(@l_hijridate,1,4) as smallint)*100+cast(SUBSTRING(@l_hijridate,6,2) as smallint) 
                                      when @l_dateformat=1 then cast(SUBSTRING(@l_hijridate,7,4) as smallint)*100+cast(SUBSTRING(@l_hijridate,4,2) as smallint)
                                      when @l_dateformat=2 then cast(SUBSTRING(@l_hijridate,7,4) as smallint)*100+cast(SUBSTRING(@l_hijridate,1,2) as smallint) end
--SET @l_hijripass=cast(SUBSTRING(@l_hijridate,7,4) as smallint)*100+cast(SUBSTRING(@l_hijridate,4,2)as smallint)

set @l_day= case when @l_dateformat=0 then cast(SUBSTRING(@l_hijridate,9,2) as smallint)
                             when @l_dateformat=1 then cast(SUBSTRING(@l_hijridate,1,2) as smallint)
                             when @l_dateformat=2 then cast(SUBSTRING(@l_hijridate,4,2) as smallint) end

IF @l_hijriref>@l_hijripass 
  begin
    set @l_start=@l_hijripass
    set @l_end=@l_hijriref
    set @l_noofdays=6-@l_day
    set @l_sign=-1
   end 
ELSE
  begin
    set @l_start=@l_hijriref
    set @l_end=@l_hijripass
    set @l_noofdays=@l_day-6
  END

set @l_fstart=@l_start

  WHILE @l_start<@l_end
    begin
       set @l_month=@l_start%100
       select  @l_noofdays=@l_noofdays+hijridays from hijribase where hijrimonth=@l_month
       IF @l_month=12 set @l_start=@l_start+100-11  ELSE set @l_start=@l_start+1
  END

set @l_totaladjust  =0
set @l_end=@l_end-1
select @l_totaladjust=isnull(sum(adjustment),0) from hijriadjustment where (hijriyear*100+hijrimonth) between @l_fstart and @l_end
set  @l_noofdays=@l_noofdays+isnull(@l_totaladjust,0)
if @l_sign=-1 set @l_noofdays=@l_noofdays*-1

set @l_returndate = convert(smalldatetime,N'01/01/2001',103)
set @l_returndate=dateadd(dd,@l_noofdays,@l_returndate)

RETURN @l_returndate

end

GO

