
			CREATE FUNCTION [dbo].[GetLocationLatLong] ( @Locationgeo AS GEOGRAPHY ,@LatOrLong SMALLINT) 
			RETURNS FLOAT AS
			BEGIN

			--@LatOrLong=0  return Lat
			--@LatOrLong=1  return Long
			DECLARE @Long FLOAT =0,@Lat FLOAT=0
			IF @Locationgeo IS NOT NULL
			SELECT @Lat= @Locationgeo.Lat, @Long=@Locationgeo.Long 

			IF @LatOrLong=0
			RETURN @Lat

			RETURN @Long

			END

GO

