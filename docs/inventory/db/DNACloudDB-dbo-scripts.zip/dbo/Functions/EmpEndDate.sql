CREATE  FUNCTION [dbo].[EmpEndDate] (@Empid int, @date smalldatetime)
RETURNS smalldatetime
BEGIN 

DECLARE @termDate AS smalldatetime, @YearMonth as int


SELECT @termDate = TermDate FROM  EmpAssignment WHERE empid=@Empid 

if @termDate is not null
begin
  select top 1 @YearMonth=AdjProratedPeriod 
     from EmpStatusHdr inner join EmpStatusDtl on EmpStatusHdr.EmpId= EmpStatusDtl.EmpId and
    EmpStatusHdr.DocumentNo= EmpStatusDtl.DocumentNo inner join 
    HrStatus on HrStatus.hrstatus=EmpStatusDtl.NewValue and EmpStatusDtl.FieldNo=1
  where EmpStatusHdr.EmpId=@Empid and  HrStatus.paystatus<>1 and EmpStatusHdr.EffectiveDate=@termDate
  order by EmpStatusHdr.EffectiveDate desc
  
  select @termDate=case when @YearMonth=cyear*100+cmonth then @termDate else @date end 
     from  EmpAssignment inner join PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
     WHERE EmpAssignment.EmpId = @empid 
end
  --set @termDate=ISNULL(@termDate,@date)
  set @termDate=case when @date< ISNULL(@termDate,@date) then @date else ISNULL(@termDate,@date) END
  
RETURN @termDate

END

GO

