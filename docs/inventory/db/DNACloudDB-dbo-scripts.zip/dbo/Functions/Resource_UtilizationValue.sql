CREATE FUNCTION [dbo].[Resource_UtilizationValue](@Resource_No int, @Resource_Category int, @From datetime ,@to datetime ,@event int, @actual BIT,@Time_cost BIT,@currency SMALLINT,@confirmed bit, @AdminResource INT)
 RETURNS numeric(18,3) 
AS
BEGIN
	--@confirmed: if 1 then i will take only confirmed resources else I will take all(confirmed and planned)
	--@actuall : I use it only when resource category equals to one(trainer)then if actual equals to one then take the actuall attendance of the trainer from trainingtrainersattendance table else then calculate it from trainingresourcesbooking table
	--@AdminResource : To get the Time/Cost for certain Resource with specific adminresource (0 = Trainer,1 = Supervisor,2 = Corrector, -1 = get all resources) 
	
	DECLARE @debit AS numeric(18,3)
    DECLARE @credit AS NUMERIC(18,3)
    DECLARE @final AS NUMERIC(18,3)
	DECLARE @correctorcost AS NUMERIC(18,3)
	DECLARE @decimalscale AS SMALLINT, @sysCur AS INT
	SELECT @decimalscale=sysparam.DecimalScale FROM sysparam 
    SELECT @sysCur = sysparam.syscur FROM sysparam
    Select @currency = Isnull(@currency,@sysCur)
-- @To is NULL, it sets @From equal first day of Month (entered in @From) & @To equal Last day of Month
    IF @to IS NULL
    BEGIN
		SELECT @From = CAST(CAST(YEAR(@From) AS NVARCHAR(4)) + '/' + 
		CAST(MONTH(@From) AS NVARCHAR(2)) + '/01' AS DATETIME)
		SELECT @to = DATEADD(s,-1,DATEADD(mm,1 ,@From))   
		SELECT @event = NULL 
		SELECT @actual=0
		SELECT @Time_cost = 0
		SELECT @currency =NULL
		SELECT @confirmed = 0
    END

	IF @actual=1 AND @Resource_Category=1  --Trainer and I want the actual attendance 
	BEGIN
	   SELECT @debit=
		 SUM(CASE WHEN (trainingcostitems.trainingcostitemtype=1 OR trainingcostitems.trainingcostitemtype IS NULL)
		 THEN 
		 	(CASE WHEN trainingresources.measureunit =2 --days
		                   THEN
		                   	
		                   	            	((1+DATEDIFF(dd,CASE when @from > trainingtrainersattendance.timein  THEN @from ELSE trainingtrainersattendance.timein  END ,CASE when @to <trainingtrainersattendance.timeout THEN @to ELSE trainingtrainersattendance.timeout END)))
			              WHEN trainingresources.measureunit=1 --hours 
			              THEN 
			                          -- (we Used minutes instead of hours in the function to get accurate hours with fraction)
                                  	(((DATEDIFF(minute,CASE when @from > trainingtrainersattendance.timein  THEN @from ELSE trainingtrainersattendance.timein  END ,CASE when @to <trainingtrainersattendance.timeout THEN @to ELSE trainingtrainersattendance.timeout END))))/60.0
		                       
		                  ELSE 1 END) ELSE 0 END  ),
		@credit =SUM(CASE WHEN (trainingcostitems.trainingcostitemtype=2)
		 THEN 
		 	(CASE WHEN trainingresources.measureunit =2 --days
		                   THEN
		                   	
		                   	            	((1+DATEDIFF(dd,CASE when @from > trainingtrainersattendance.timein  THEN @from ELSE trainingtrainersattendance.timein  END ,CASE when @to <trainingtrainersattendance.timeout THEN @to ELSE trainingtrainersattendance.timeout END)))
		           
			              WHEN trainingresources.measureunit=1 --hours 
			              THEN 
			                          -- (we Used minutes instead of hours in the function to get accurate hours with fraction)
                                  	(((DATEDIFF(minute,CASE when @from > trainingtrainersattendance.timein  THEN @from ELSE trainingtrainersattendance.timein  END ,CASE when @to <trainingtrainersattendance.timeout THEN @to ELSE trainingtrainersattendance.timeout END))))/60.0
		                       
		                  ELSE 1 END) ELSE 0 END  )
		                  
		                 FROM TrainingTrainersAttendance
		                 LEFT JOIN trainingresources ON trainingresources.trainingresource = TrainingTrainersAttendance.EmpId
		                 LEFT JOIN trainingcostitems ON trainingcostitems.TrainingCostItem = trainingresources.trainingcostitem
		                 WHERE 
		                trainingresources.trainingresource=@Resource_No
		                AND trainingresources.resourcecategory=@Resource_Category
		                AND((@from BETWEEN trainingtrainersattendance.timein AND trainingtrainersattendance.timeout) 
		                OR (@to BETWEEN trainingtrainersattendance.timein AND trainingtrainersattendance.timeout) 
		                OR (trainingtrainersattendance.timein BETWEEN @from AND @to)
		                OR (trainingtrainersattendance.timeout BETWEEN @from AND @to))
		                AND trainingtrainersattendance.attendance=1
		                AND trainingtrainersattendance.trainingevent = CASE WHEN @event IS NOT Null THEN @event ELSE trainingtrainersattendance.trainingevent END
		 
	IF @time_cost=0 -- I need time
	  BEGIN 
	   SET @final=isnull(@debit,0)+isnull(@credit,0)
	  END 
	ELSE --I need cost
	 BEGIN 
		SET @final = (SELECT 
	   (isnull(@debit,0)* dbo.ConvertAmount(trainingresources.unitcost,ISNULL(TrainingResources.CostCurrency,@sysCur),@Currency, @From))-
	   (ISNULL(@credit,0)*dbo.ConvertAmount(trainingresources.unitcost,ISNULL(TrainingResources.CostCurrency,@sysCur),@Currency, @From))
		FROM TrainingResources
		WHERE TrainingResources.TrainingResource= @Resource_No AND TrainingResources.ResourceCategory = @Resource_Category)
	 END
	SET @final = Round(@final,@decimalscale) 
	RETURN isnull(@final,0)
   END
	-----------------------------------------------------------------------------------------------
    ELSE -- Not Actual Time, get from TrainingResourceBooking Table
	BEGIN
	IF @Time_cost = 0   --I need Time
		BEGIN 
			
			-->> Case when UseManualQty is True  <<--
			--Converting Manual MeasureUnit to TrainingResources.MeasureUnit
		SELECT @final = SUM(TrainingResourcesBooking.BookCount*(CASE WHEN TrainingResourcesBooking.UseManualQty= 1 
				THEN ( TrainingResourcesBooking.ManualMeasureQty
				*(CASE WHEN TrainingResourcesBooking.MeasureUnit <> TrainingResources.MeasureUnit
				THEN (CASE WHEN TrainingResourcesBooking.MeasureUnit = 1 AND TrainingResources.MeasureUnit = 2 THEN (1.0/8) 
						   WHEN TrainingResourcesBooking.MeasureUnit = 1 AND TrainingResources.MeasureUnit = 3 THEN 1 --(1.0/((DateDiff(minute, CASE WHEN trainingresourcesbooking.TrainingSession IS NULL THEN TrainingEvents.EventFromDate ELSE TrainingSessions.TrainingSessionFrom END ,CASE WHEN trainingresourcesbooking.TrainingSession IS NULL THEN TrainingEvents.EventToDate ELSE TrainingSessions.TrainingSessionTo END))/60.0)) 
						   WHEN TrainingResourcesBooking.MeasureUnit = 2 AND TrainingResources.MeasureUnit = 1 THEN 8
						   WHEN TrainingResourcesBooking.MeasureUnit = 2 AND TrainingResources.MeasureUnit = 3 THEN 1 --(1.0/(1+DateDiff(dd, CASE WHEN trainingresourcesbooking.TrainingSession IS NULL THEN TrainingEvents.EventFromDate ELSE TrainingSessions.TrainingSessionFrom END ,CASE WHEN trainingresourcesbooking.TrainingSession IS NULL THEN TrainingEvents.EventToDate ELSE TrainingSessions.TrainingSessionTo END)))
						   WHEN TrainingResourcesBooking.MeasureUnit = 3 AND TrainingResources.MeasureUnit = 1 THEN 
						   (Case When trainingresourcesbooking.TrainingSession IS NULL Then dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'h')
						   Else (DateDiff(minute, TrainingSessions.TrainingSessionFrom ,TrainingSessions.TrainingSessionTo))/60.0 END)
						   WHEN TrainingResourcesBooking.MeasureUnit = 3 AND TrainingResources.MeasureUnit = 2 THEN 
						   (Case When trainingresourcesbooking.TrainingSession IS NULL Then dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'d')
						   Else (1+DateDiff(dd,TrainingSessions.TrainingSessionFrom , TrainingSessions.TrainingSessionTo)) END)
					 END ) ELSE 1 END))
				         	
			-->> Case when UseManualQty is False  <<--
				ELSE (CASE WHEN trainingresources.measureunit =1 --hours
					  THEN (CASE WHEN trainingresourcesbooking.TrainingSession is NULL   
						   THEN dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'h')
						   ELSE (((DATEDIFF(minute,CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END ,CASE when @to <trainingresourcesbooking.bookto THEN @to ELSE trainingresourcesbooking.bookto END)))/60.0 ) END )
					  
					  WHEN trainingresources.measureunit=2 --days
					  THEN (CASE WHEN trainingresourcesbooking.TrainingSession is NULL   
						    THEN dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'d')
							ELSE ((1+DATEDIFF(dd,CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END ,CASE when @to <trainingresourcesbooking.bookto THEN @to ELSE trainingresourcesbooking.bookto END))) END )
					  
					  WHEN trainingresources.measureunit IN (3,4) --Event, Piece 
					  THEN 1 

					 END) 
				END) )
					  FROM trainingresourcesbooking
								LEFT JOIN trainingresources ON trainingresourcesbooking.TrainingResource = Trainingresources.TrainingResource AND trainingresourcesbooking.ResourceCategory = Trainingresources.ResourceCategory
								LEFT JOIN trainingcostitems ON trainingcostitems.TrainingCostItem = case when trainingresourcesbooking.TrainingCostItem IS NOT NULL THEN trainingresourcesbooking.trainingcostitem ELSE trainingresources.trainingcostitem end
								LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = trainingresourcesbooking.TrainingEvent
								LEFT JOIN TrainingSessions ON TrainingSessions.TrainingEvent = trainingresourcesbooking.TrainingEvent
								AND TrainingSessions.TrainingSession = trainingresourcesbooking.TrainingSession
								LEFT JOIN TrainingEventStatus ON TrainingEventStatus.EventStatus = TrainingEvents.EventStatus     
							  WHERE 
								trainingresourcesbooking.bookstatus=CASE WHEN @confirmed=1 THEN 1 ELSE trainingresourcesbooking.bookstatus end
								AND (trainingresourcesbooking.BlockReason ='' or trainingresourcesbooking.blockreason is NULL)
								AND trainingresourcesbooking.trainingresource=@Resource_No
								AND trainingresourcesbooking.resourcecategory=@Resource_Category
								AND ((@from BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto)
								OR  (@to BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto) 
								OR  (trainingresourcesbooking.BookFrom BETWEEN @from AND @to)
								OR  (trainingresourcesbooking.bookto BETWEEN @from AND @to))
								AND trainingresourcesbooking.trainingevent = CASE WHEN @event IS NOT Null THEN @event ELSE trainingresourcesbooking.trainingevent END
								AND trainingresourcesbooking.AdminResource = Case WHEN @AdminResource =-1 THEN  trainingresourcesbooking.AdminResource 
								                                                  ELSE @AdminResource END
								AND TrainingEventStatus.SystemEventStatus NOT IN (3)                                                   
		END
	ELSE				 --I need Cost
		BEGIN
			
	
				SELECT @final = SUM(case when trainingresourcesbooking.AdminResource<>2 then TrainingResourcesBooking.BookCount
				*(CASE WHEN (trainingcostitems.trainingcostitemtype=1 OR trainingcostitems.trainingcostitemtype IS NULL)
					THEN 1 ELSE -1 END)  
				*(CASE WHEN TrainingResourcesBooking.UseManualQty= 1 
				THEN ( TrainingResourcesBooking.ManualMeasureQty
				*dbo.ConvertAmount(TrainingResourcesBooking.unitcost,Isnull(TrainingResourcesBooking.CostCurrency,@sysCur),@Currency, CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END)           	
					 )         	
				ELSE (dbo.ConvertAmount(trainingresources.unitcost,ISNULL(TrainingResources.CostCurrency,@sysCur),@Currency, CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END)
					*(CASE WHEN trainingresources.measureunit =1 --hours
					  THEN (CASE WHEN trainingresourcesbooking.TrainingSession is NULL   
						   THEN dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'h')
						   ELSE (((DATEDIFF(minute,CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END ,CASE when @to <trainingresourcesbooking.bookto THEN @to ELSE trainingresourcesbooking.bookto END)))/60.0 ) END )
					  
					  WHEN trainingresources.measureunit=2 --days
					  THEN (CASE WHEN trainingresourcesbooking.TrainingSession is NULL   
						    THEN dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'d')
							ELSE ((1+DATEDIFF(dd,CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END ,CASE when @to <trainingresourcesbooking.bookto THEN @to ELSE trainingresourcesbooking.bookto END))) END )
					  
					  WHEN trainingresources.measureunit IN (3,4) --Event, Piece 
					  THEN 1 

					 END))END) ELSE 0 end),
					 
				@correctorcost=SUM(case when trainingresourcesbooking.AdminResource=2 then TrainingResourcesBooking.BookCount
				*(CASE WHEN (trainingcostitems.trainingcostitemtype=1 OR trainingcostitems.trainingcostitemtype IS NULL)
					THEN 1 ELSE -1 END)  
				*(CASE WHEN TrainingResourcesBooking.UseManualQty= 1 
				THEN ( TrainingResourcesBooking.ManualMeasureQty
				*dbo.ConvertAmount(TrainingResourcesBooking.unitcost,Isnull(TrainingResourcesBooking.CostCurrency,@sysCur),@Currency, CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END)           	
					 )         	
				ELSE (dbo.ConvertAmount(trainingresources.unitcost,ISNULL(TrainingResources.CostCurrency,@sysCur),@Currency, CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END)
					*(CASE WHEN trainingresources.measureunit =1 --hours
					  THEN (CASE WHEN trainingresourcesbooking.TrainingSession is NULL   
						   THEN dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'h')
						   ELSE (((DATEDIFF(minute,CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END ,CASE when @to <trainingresourcesbooking.bookto THEN @to ELSE trainingresourcesbooking.bookto END)))/60.0 ) END )
					  
					  WHEN trainingresources.measureunit=2 --days
					  THEN (CASE WHEN trainingresourcesbooking.TrainingSession is NULL   
						    THEN dbo.EventDuration(trainingresourcesbooking.TrainingEvent,@From,@to,1,'d')
							ELSE ((1+DATEDIFF(dd,CASE when @from > trainingresourcesbooking.BookFrom THEN @from ELSE trainingresourcesbooking.bookfrom END ,CASE when @to <trainingresourcesbooking.bookto THEN @to ELSE trainingresourcesbooking.bookto END))) END )
					  
					  WHEN trainingresources.measureunit IN (3,4) --Event, Piece 
					  THEN 1 

					 END)) 
				END) ELSE 0 end)
				
								FROM trainingresourcesbooking
								LEFT JOIN trainingresources ON trainingresourcesbooking.TrainingResource = Trainingresources.TrainingResource AND trainingresourcesbooking.ResourceCategory = Trainingresources.ResourceCategory
								LEFT JOIN trainingcostitems ON trainingcostitems.TrainingCostItem = case when trainingresourcesbooking.TrainingCostItem IS NOT NULL THEN trainingresourcesbooking.trainingcostitem ELSE trainingresources.trainingcostitem end
								LEFT JOIN TrainingEvents ON TrainingEvents.TrainingEvent = trainingresourcesbooking.TrainingEvent
								LEFT JOIN TrainingSessions ON TrainingSessions.TrainingEvent = trainingresourcesbooking.TrainingEvent
								AND TrainingSessions.TrainingSession = trainingresourcesbooking.TrainingSession
								LEFT JOIN TrainingEventStatus ON TrainingEventStatus.EventStatus = TrainingEvents.EventStatus     
							  WHERE 
								trainingresourcesbooking.bookstatus=CASE WHEN @confirmed=1 THEN 1 ELSE trainingresourcesbooking.bookstatus end
								AND (trainingresourcesbooking.BlockReason ='' or trainingresourcesbooking.blockreason is NULL)
								AND trainingresourcesbooking.trainingresource=@Resource_No
								AND trainingresourcesbooking.resourcecategory=@Resource_Category
								AND ((@from BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto)
								OR  (@to BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto) 
								OR  (trainingresourcesbooking.BookFrom BETWEEN @from AND @to)
								OR  (trainingresourcesbooking.bookto BETWEEN @from AND @to))
								AND trainingresourcesbooking.trainingevent = CASE WHEN @event IS NOT Null THEN @event ELSE trainingresourcesbooking.trainingevent END
								AND trainingresourcesbooking.AdminResource = Case WHEN @AdminResource =-1 THEN  trainingresourcesbooking.AdminResource 
								                                                  ELSE @AdminResource END
								AND TrainingEventStatus.SystemEventStatus NOT IN (3)                                                   
				   -- (Corrector case > we multiply the Cost by the no of Trainees attended the event)
				DECLARE @Admin AS int 
			    SELECT @Admin = Max(AdminResource) FROM TrainingResourcesBooking 
			    WHERE TrainingResource = @Resource_No AND ResourceCategory= @Resource_Category AND TrainingEvent = @event
			    And trainingresourcesbooking.bookstatus=CASE WHEN @confirmed=1 THEN 1 ELSE trainingresourcesbooking.bookstatus end
			    AND ((@from BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto)
				OR  (@to BETWEEN trainingresourcesbooking.bookfrom AND trainingresourcesbooking.bookto) 
				OR  (trainingresourcesbooking.BookFrom BETWEEN @from AND @to)
				OR  (trainingresourcesbooking.bookto BETWEEN @from AND @to))
				AND trainingresourcesbooking.AdminResource = Case WHEN @AdminResource =-1 THEN trainingresourcesbooking.AdminResource ELSE @AdminResource END
			    
				IF @Admin = 2  
					BEGIN 
						SELECT @correctorcost = @correctorcost*isnull(Count(EmpTraining.EmpId),0)
						FROM  EmpTraining
						LEFT JOIN TrainingEnrollStatus ON TrainingEnrollStatus.EnrollStatus = EmpTraining.EnrollStatus
						WHERE TrainingEnrollStatus.SystemEnrollStatus IN (2,4) AND  
						EmpTraining.TrainingEvent = @event
					END 
	

		END	
	
	END
	SET @final=isnull(@final,0)+isnull(@correctorcost,0)
	SET @final = Round(@final,@decimalscale)
	RETURN isnull(@final,0)
    END

GO

