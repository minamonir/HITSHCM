
CREATE FUNCTION [dbo].[GetDocumentNo] (@ProfileId int, @SSDocType smallint)
RETURNS  int
as
BEGIN 
  declare @DocumentNo as int
   --change of status
   if @SSDocType=1  select top 1 @DocumentNo=DocumentNo from EmpStatusHdr where Empid=@ProfileId order by Empid, DocumentNo desc
   --misconduct
   if @SSDocType=2  select top 1 @DocumentNo=DocumentNo from empmscon where Empid=@ProfileId order by Empid, DocumentNo desc
   --vacation
   if @SSDocType=3  select top 1 @DocumentNo=DocumentNo from empvacat where Empid=@ProfileId order by Empid, DocumentNo desc
   --application  
   if @SSDocType=4  select top 1 @DocumentNo=AssignmentId from appassignment where Empid=@ProfileId order by Empid, AssignmentId desc
   --medical 
   if @SSDocType=5  select top 1 @DocumentNo=DocumentNo from empmedical where Empid=@ProfileId order by Empid, DocumentNo desc 
   --Appraisal  
   if @SSDocType=6  select top 1 @DocumentNo=DocumentNo from empappraisal where Empid=@ProfileId order by Empid, DocumentNo desc
   --benefit  
   if @SSDocType=7  select top 1 @DocumentNo=DocumentNo from empbenefit where Empid=@ProfileId order by Empid, DocumentNo desc
   --vacation due adjustment  
   if @SSDocType=8  select top 1 @DocumentNo=DocumentNo from EmpVacationDue where Empid=@ProfileId order by Empid, DocumentNo desc
   --training  
   if @SSDocType=9  select top 1 @DocumentNo=DocumentNo from emptraining where Empid=@ProfileId order by Empid, DocumentNo desc
   --staffhousing
   if @SSDocType=10  select top 1 @DocumentNo=DocumentNo from emphkitems where Empid=@ProfileId order by Empid, DocumentNo desc
   --Profilettachment
   if @SSDocType=11  select top 1 @DocumentNo=DocumentNo from Profileattachment where profileid=@ProfileId order by profileid, DocumentNo desc
   --EmpTimePermission
   if @SSDocType=12 select top 1 @DocumentNo=DocumentNo from EmpTimePermission where Empid=@ProfileId order by Empid, DocumentNo DESC
   --EmpDoc
   if @SSDocType=14 select top 1 @DocumentNo=DocumentNo from EmpDoc where Empid=@ProfileId order by Empid, DocumentNo DESC
   	--EmpHKItems (Housing)
   if @SSDocType=16   select top 1 @DocumentNo=DocumentNo from EmpHKItems where Empid=@ProfileId order by Empid, DocumentNo DESC
    --EmpActivities
   if @SSDocType=18 select top 1 @DocumentNo=DocumentNo from EmpActivities where Empid=@ProfileId order by Empid, DocumentNo desc  
    --EmpTrainingEval
   if @SSDocType=19 select top 1 @DocumentNo=DocumentNo from EmpTrainingEval where Empid=@ProfileId AND DocumentNo>=10000 order by Empid, DocumentNo desc  
    --NasUsersUncommitted
   if @SSDocType=20  select top 1 @DocumentNo=DocumentNo from NasUsersUncommitted where Empid=@ProfileId order by Empid, DocumentNo DESC
   
   --EmpHRDevPlanStage
    if @SSDocType=21  select top 1 @DocumentNo=DocumentNo from EmpHRDevPlanStage where Empid=@ProfileId order by Empid, DocumentNo desc

    --ProfilePhones
	if @SSDocType=22 select top 1 @DocumentNo=DocumentNo from ProfilePhones where Empid=@ProfileId order by Empid, DocumentNo DESC
    --UpdateShift
	if @SSDocType=23 select top 1 @DocumentNo=DocumentNo from EmpTimeReadingsUncommitted where Empid=@ProfileId order by Empid, DocumentNo desc

	--EMPHRReques
	if @SSDocType=24 select top 1 @DocumentNo=DocumentNo from EmpHrRequest where Empid=@ProfileId order by Empid, DocumentNo DESC
	
	--EmpTask
	if @SSDocType=25 select top 1 @DocumentNo=DocumentNo from dbo.EmpTask where Empid=@ProfileId order by Empid, DocumentNo DESC

	--EmpTimeReadingsGeoUncommitted
	if @SSDocType=26 select top 1 @DocumentNo=DocumentNo from dbo.EmpTimeReadingsGeoUncommitted where Empid=@ProfileId order by Empid, DocumentNo desc

	--EmpBenefitItems
	if @SSDocType=27 select top 1 @DocumentNo=ItemDocumentNo from dbo.EmpBenefitItems where Empid=@ProfileId order by Empid, EmpBenefitItems.ItemDocumentNo desc

	--EmpSSDOCBundle
	if @SSDocType=28 select top 1 @DocumentNo=BundleDocumentNo from dbo.EmpBundle where Empid=@ProfileId order by Empid, EmpBundle.BundleDocumentNo desc
	 
     --AppInterviews 
	if @SSDocType=29 select @DocumentNo =0 -- SSDocType =29 used in another SP getSubDocumentNo 
    --vacation Modifications
   if @SSDocType=30  select top 1 @DocumentNo=DocumentNo from EmpVacModifications where Empid=@ProfileId order by Empid, DocumentNo desc


   IF @SSDocType=19
   BEGIN
   	set @DocumentNo=isnull(@DocumentNo,10000)
   END
   ELSE
   	BEGIN
   		set @DocumentNo=isnull(@DocumentNo,0)
   	END

   while  1=1
    begin
     if  @DocumentNo>2147483647    set @DocumentNo=1 else set  @DocumentNo=@DocumentNo+1 
     --change of status     
     if @SSDocType=1 and not exists (select DocumentNo from EmpStatusHdr where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --misconduct
     if @SSDocType=2 and not exists (select DocumentNo  from empmscon where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --vacation
     if @SSDocType=3 and not exists (select DocumentNo  from empvacat where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --application
     if @SSDocType=4 and not exists (select assignmentid  from appassignment where EmpId=@ProfileId and assignmentid=@DocumentNo)  break
   --medical
     if @SSDocType=5 and not exists (select DocumentNo  from empmedical where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
    --Appraisal  
     if @SSDocType=6 and not exists (select DocumentNo  from empappraisal where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --benefit  
     if @SSDocType=7 and not exists (select DocumentNo  from empbenefit where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --vacation due adjustment  
     if @SSDocType=8 and not exists (select DocumentNo  from EmpVacationDue where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --training  
     if @SSDocType=9 and not exists (select DocumentNo  from emptraining where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --staffhousing
     if @SSDocType=10 and not exists (select DocumentNo  from emphkitems where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
     --Profilettachment
     if @SSDocType=11 and not exists (select DocumentNo  from Profileattachment where profileid=@ProfileId and DocumentNo=@DocumentNo)  break 
     --EmpTimePermission
     if @SSDocType=12 and not exists (select DocumentNo  from EmpTimePermission where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break 
     --EmpDoc
	 if @SSDocType=14 and not exists (select DocumentNo  from EmpDoc where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
	 --EmpHKItems (Housing)
	 if @SSDocType=16 and not exists (select DocumentNo  from EmpHKItems where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
	 --EmpActivities   
	 if @SSDocType=18 AND  not exists (SELECT DocumentNo from EmpActivities where Empid=@ProfileId and DocumentNo=@DocumentNo)  break  
	--EmpTrainingEval
    if @SSDocType=19 AND  not exists (SELECT DocumentNo from EmpTrainingEval where Empid=@ProfileId and DocumentNo=@DocumentNo)  break  
	--NasUsersUncommitted
	if @SSDocType=20 AND  not exists (SELECT DocumentNo from NasUsersUncommitted where Empid=@ProfileId and DocumentNo=@DocumentNo)  break 
	   --EmpHRDevPlanStage
    if @SSDocType=21  AND  not exists (SELECT DocumentNo from EmpHRDevPlanStage where Empid=@ProfileId and DocumentNo=@DocumentNo) break 
	--ProfilePhones
	if @SSDocType=22 and not exists (SELECT DocumentNo from ProfilePhones where Empid=@ProfileId and DocumentNo=@DocumentNo) break 
	--UpdateShift
	if @SSDocType=23 and not exists (SELECT DocumentNo from EmpTimeReadingsUncommitted where Empid=@ProfileId and DocumentNo=@DocumentNo) break 
	--EmpHRRequest
	if @SSDocType=24 and not exists (SELECT DocumentNo from EmpHRRequest where Empid=@ProfileId and DocumentNo=@DocumentNo) break 
	--EmpTask
	if @SSDocType=25 and not exists (SELECT DocumentNo from emptask where Empid=@ProfileId and DocumentNo=@DocumentNo) break 
	
	--EmpTimeReadingsGeoUncommitted
	if @SSDocType=26 and not exists (SELECT DocumentNo from EmpTimeReadingsGeoUncommitted where Empid=@ProfileId and DocumentNo=@DocumentNo) break 
	--EmpBenefitItems
	if @SSDocType=27 and not exists (SELECT ItemDocumentNo from EmpBenefitItems where Empid=@ProfileId and ItemDocumentNo=@DocumentNo) break 
	--EmpSSDOCBundle
	if @SSDocType=28 and not exists (SELECT BundleDocumentNo from EmpBundle where Empid=@ProfileId and BundleDocumentNo=@DocumentNo) break 
        --AppInterviews 
	if @SSDocType=29  break -- SSDocType =29 used in another SP getSubDocumentNo 
     --vacation Modification
     if @SSDocType=30 and not exists (select DocumentNo  from EmpVacModifications where EmpId=@ProfileId and DocumentNo=@DocumentNo)  break
  end
  return @DocumentNo
END

GO

