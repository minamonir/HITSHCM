CREATE FUNCTION [dbo].[ReportRoles] 
	(@ReportNo as smallint,@Tablename as nchar(30),@UserId AS int) RETURNS NVARCHAR(max)
AS
BEGIN	
DECLARE @RoleFields AS NVARCHAR(max) , @Where AS NVARCHAR(max),@TableRoles AS NVARCHAR(max)
DECLARE @Roles TABLE (RoleId SMALLINT)
DECLARE  @i AS INT
SET @Where=''
SET @i = 1

IF (SELECT SysParam.EnableRoleValidation FROM SysParam ) = 1
BEGIN 
	IF @ReportNo = 0 AND (@Tablename ='Paycodes'
	                      OR @Tablename ='PayrollGroup' 
	                       OR  @Tablename = 'hrstatus' 
						   OR  @Tablename = 'organization') -- For Get External Paycodes & For Update Profile with payroll data
	BEGIN
		-- wrong condition removed ... condition added by logonname in procedures calling this function
		--IF (SELECT NasUsers.ApplySSGroups FROM NasUsers WHERE empid=@UserId)=1 
		--begin
		--SELECT  @RoleFields = 'PaycodeRoles' 
		SELECT  @RoleFields = Case when @Tablename ='Paycodes' then 'PaycodeRoles' when @Tablename ='PayrollGroup' then 'PayrollGroupRoles' when @Tablename = 'hrstatus'  then 'HrStatusRoles' when @Tablename = 'Organization' then 'organization.OrganizationRoles' end
		INSERT INTO @Roles  SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId = @UserId 
		SET @i = CHARINDEX(',',@RoleFields,@i)
		SET @i = @i + 1
		SET @Where = @Where+'AND(('+ @RoleFields+ '='''')OR('+@RoleFields+' IS NULL))'
		SELECT  @Where = @Where+'OR('+@RoleFields+' LIKE''%#'+LTRIM(RoleId)+'#%'') ' 
		FROM @Roles
		IF @Where <> '' SET @Where = 'AND('+SUBSTRING(@Where,4,len(@Where))+') '
		--end
	END
	ELSE IF @ReportNo = 0
	BEGIN
		INSERT INTO @Roles  SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId = @UserId 
		SET @Where = @Where+'AND(('+ LTRIM(RTRIM(@Tablename))+ '='''')OR('+LTRIM(RTRIM(@Tablename))+' IS NULL))'
		SELECT  @Where = @Where+'OR('+LTRIM(RTRIM(@Tablename))+' LIKE''%#'+LTRIM(RoleId)+'#%'') ' 
		FROM @Roles
		IF @Where <> '' SET @Where = ' Not ('+SUBSTRING(@Where,4,len(@Where))+') '
	END
	ELSE
	BEGIN
		SELECT  @RoleFields = TableRoleFields FROM ReportsTables 
		WHERE ReportNo=@ReportNo AND TableName=@Tablename
		select @RoleFields = ltrim(rtrim(isnull(@RoleFields,'')))
		IF @RoleFields <>''
		BEGIN
			IF substring(@RoleFields,len(@RoleFields)-1,1) <> ',' select @RoleFields=  @RoleFields+','
			INSERT INTO @Roles  SELECT DISTINCT RoleId FROM SSGroupRole WHERE ProfileId = @UserId 
			WHILE CHARINDEX(',',@RoleFields,@i) < len(@RoleFields)
			BEGIN
				SET @i = CHARINDEX(',',@RoleFields,@i)
				SET @i = @i + 1
				SET @TableRoles = SUBSTRING(@RoleFields,@i,(CHARINDEX(',',@RoleFields,@i) - (CHARINDEX(',',@RoleFields,@i-1)))-1)
				SET @Where = @Where+'AND(('+ @TableRoles + '='''')OR('+@TableRoles+' IS NULL))'
				SELECT  @Where = @Where+'OR('+@TableRoles+' LIKE''%#'+LTRIM(RoleId)+'#%'')' 
				FROM @Roles
				CONTINUE
			END
			IF @Where <> '' SET @Where = 'AND('+SUBSTRING(@Where,4,len(@Where))+')'
		END
	END
END
RETURN @Where
END

GO

