CREATE FUNCTION [dbo].[WebAPI2WF_CheckRoleInvitation] (@LogonName as nvarchar(80)='' ,@RoleProfileid as int, @EmpID as int, @DocumentNo as int , @SSDocNo as SMALLINT, @action as INT)
RETURNS SMALLINT
AS
BEGIN

	DECLARE @result AS SMALLINT=0

	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[WF_CheckRoleInvitation]') AND type in (N'FN'))
	BEGIN
		SELECT @result =  dbo.WF_CheckRoleInvitation(@LogonName,@RoleProfileid, @EmpID, @DocumentNo, @SSDocNo,@action)
	END
	RETURN @result 	
END

GO

