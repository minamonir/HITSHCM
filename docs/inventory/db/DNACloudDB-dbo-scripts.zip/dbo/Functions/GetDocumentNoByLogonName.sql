
CREATE  FUNCTION [dbo].[GetDocumentNoByLogonName] (@LogonName NVARCHAR(80),@EmpId int,@SSDocType SMALLINT)
RETURNS  INT
AS 
BEGIN
	DECLARE @DocumentNo AS INT
	
	IF @SSDocType=20 --NasUsersUncommitted
	BEGIN
		SELECT  @DocumentNo=MAX(T.DocumentNo)
		FROM (
		SELECT ISNULL((SELECT MAX(DocumentNo) FROM NasUsersUncommitted WHERE Empid=@EmpId),0) AS DocumentNo
		UNION
		SELECT ISNULL((SELECT MAX(DocumentNo) FROM NasUsersUncommitted WHERE NasUsersUncommitted.LogonName=@LogonName),0) AS DocumentNo) AS T
	END
	WHILE 1=1
    BEGIN
    	 IF @DocumentNo>2147483647	SET @DocumentNo=1 ELSE SET @DocumentNo=@DocumentNo+1
    	 --NasUsersUncommitted 
    	 IF @SSDocType=20 AND NOT EXISTS (SELECT DocumentNo FROM NasUsersUncommitted WHERE NasUsersUncommitted.LogonName=@LogonName AND DocumentNo=@DocumentNo) BREAK 
    END 
	RETURN @DocumentNo
END

GO

