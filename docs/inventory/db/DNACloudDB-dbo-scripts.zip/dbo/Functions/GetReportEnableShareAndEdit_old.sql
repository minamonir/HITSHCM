CREATE FUNCTION [dbo].[GetReportEnableShareAndEdit_old] (@RepNo AS INT,@logonname AS NVARCHAR(MAX))
RETURNS SMALLINT
AS
BEGIN

DECLARE @NasUsersReports_CanShare AS SMALLINT , @UserGroupReports_CanShare AS SMALLINT,@UserGroup_CanShare AS SMALLINT
SET @UserGroup_CanShare = -1
SET @NasUsersReports_CanShare = -1
SET @UserGroupReports_CanShare = -1


--select @UserGroup_CanShare= (select TOP 1 1 from nasusers cross apply dbo.HitsStringSplit( OtherUserGroups+'#'+ltrim(nasusers.UserGroup)+'#','#') t  
--inner join UserGroupReports on (UserGroupReports.UserGroup =t.value) and   t.value <>''   WHERE ReportNo = @RepNo AND LTRIM(RTRIM(LogonName)) = @logonname)


declare  @usergroups as nvarchar(max)=''
select @usergroups=OtherUserGroups+'#'+ltrim(nasusers.UserGroup)+'#' from NasUsers where LogonName =@logonname

SELECT TOP 1 @UserGroup_CanShare= 1 
FROM UserGroupReports
CROSS APPLY STRING_SPLIT(@usergroups, '#') AS UG
WHERE ReportNo = @RepNo
AND UG.value = UserGroupReports.UserGroup and value <>''

SELECT TOP 1 @UserGroup_CanShare =1 
FROM UserGroupReports 
inner JOIN nasusers ON NasUsers.LogonName =@logonname  AND UserGroupReports.usergroup LIKE OtherUserGroups+'%#'+ltrim(nasusers.UserGroup)+'#%' 
WHERE ReportNo = @RepNo 



IF @UserGroup_CanShare = 1
BEGIN
	--if report is in my user group reports so i can share it
	RETURN 1
END

ELSE 
BEGIN
--check if i can share report through NasUsersReports
SET  @NasUsersReports_CanShare =(SELECT  MAX(CanShare)
FROM NasUsersReports 
WHERE ReportNo = @RepNo AND ltrim(rtrim(LogonName)) = LTRIM(RTRIM(@logonname)) AND SharedStatus = 1)

IF @NasUsersReports_CanShare = 1
BEGIN
--i can share it through my NasUsersReports
return 1
END
ELSE 
BEGIN
--check if i can share it through UserGroupReportsBySharing	


SET  @UserGroupReports_CanShare = (select MAX(CanShare)
FROM NasUsers
cross apply dbo.HitsStringSplit( OtherUserGroups+'#'+ltrim(nasusers.UserGroup)+'#','#') t  
inner JOIN UserGroupReportsBySharing ON (UserGroupReportsBySharing.UserGroup =t.value) and   t.value <>''  AND ltrim(rtrim(nasusers.LogonName)) = LTRIM(RTRIM(@LogonName))
WHERE ReportNo = @RepNo AND SharedStatus = 1)


IF @UserGroupReports_CanShare = 1
return 1 
ELSE 
RETURN 0	 

END
END

--dummy return
RETURN 1
END

GO

