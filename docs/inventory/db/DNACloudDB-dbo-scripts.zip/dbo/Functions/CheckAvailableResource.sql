
-- This function is called in TrainingResourcesBooking.ascx.vb and TrainingResourcesBlocking.aspx.vb
-- To get available resource count in certain dates
CREATE FUNCTION [dbo].[CheckAvailableResource](@BlockFlag as Int,@BookNo Int, @TrainingResource Int, @FormDate DateTime ,
@ToDate DateTime ,@RequestBookedCount Int, @lang varchar(1))
RETURNS Nvarchar(225)
AS 
BEGIN
	
	declare @originalCount as Int=0, @blockedCount as Int=0, @bookedCount as Int=0 

	-- 1-Get the original(MAX) count of resource 
	select @originalCount= TrainingResourceCount from TrainingResources
	where TrainingResource = @TrainingResource

	--select @originalCount as Original

	-- 2-Get the booked or blocked count count of resource 

	-- if @BlockFlag = 1 then block mode(get blocked only) else book mode (get all booked and blocked from TrainingResourcesBooking table )
	select @blockedCount=isnull(sum(BookCount),0) from TrainingResourcesBooking
	where BookStatus = 1 -- confirmed 
	and BookNo <> @BookNo -- if bookNo = 0 then insertionMode with no exclusion of bookNo else then edit mode with exclusion of this bookNo  
	and isnull(TrainingEvent,0) =  (case when @BlockFlag = 1 then  0 else isnull(TrainingEvent,0) end) 
	and TrainingResource = @TrainingResource
	and ((BookFrom between @FormDate and @ToDate) or (BookTo between  @FormDate and @ToDate) or
	(@FormDate between BookFrom and BookTo) or (@ToDate between  BookFrom and BookTo))


	--select @blockedCount as Blocked -- Blocked is either booked or blocked


	if @RequestBookedCount >@originalCount-@blockedCount --@RequestBookedCount>(Avalible Count)
		begin -- No availabel resource at this date with requested quantity
			if @BlockFlag = 1 
				return dbo.Hits_GetDCCaption('TrainingResourcesBlocking','CountCheck',@lang)


			else --@BlockFlag = 1 
				return dbo.Hits_GetDCCaption('TrainingResourcesBooking','CountCheck',@lang)

		end
	--Else --@RequestBookedCount<=(Avalible Count)
	
	return '001'
END

GO

