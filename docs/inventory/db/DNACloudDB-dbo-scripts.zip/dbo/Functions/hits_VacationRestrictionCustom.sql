

CREATE FUNCTION [dbo].[hits_VacationRestrictionCustom]
(

	-- Add the parameters for the function here
	 @empid as int, @vaccode as smallint, @fromdate as datetime,@todate as datetime,@lang as nchar(1), @DocNo AS int,@WF AS bit,@PartDayFrom AS BIT,@PartDayTo AS BIT
)
RETURNS nvarchar(max)
AS

BEGIN
	
SET @WF=1

--@MaxTotalSince=1      hiredate 
--@MaxTotalSince=2      probdate 
--@MaxTotalSince=3      calendar year start
--@MaxTotalSince=4      ContStart
--@MaxTotalSince=5      RevisedHireDate
--@MaxTotalSince=6      WorkReceivingDate
--@MaxTotalSince=7      PayrollGroup Year Start
--@MaxTotalSince=8      Social Insurance Date

declare @Latinlang as nchar(1)
set @Latinlang=@lang 
declare @reason as nvarchar(max)
set @reason =N''

declare @VacLength as bit, @MinDays as numeric(9, 3), @MaxDays as numeric(9, 3), @CategoryBal as bit, 
@MinBalBefore as numeric(9, 3), @MinBalAfter as numeric(9, 3), @MaxTotal as bit, 
@MaxTotalNo as numeric(9, 3), @MaxTotalEvery as numeric(9, 3), @MaxTotalEveryUnit as smallint , 
@MaxTotalSince as smallint, @MaxOccurance as bit, @MaxOccuranceNo as smallint, @MaxOccuranceEvery as numeric(9, 3),
@MaxOccEveryUnit as smallint, @MaxOccuranceSince as smallint, @AllowAfter as bit, @AllowAfterNo as numeric(9, 3), 
@AllowAfterUnit as smallint, @AllowAfterSince as smallint,@BalanceTill AS smallint
,@proratedMaxOccuranceNo AS smallint,@HireDate AS smalldatetime,@ProratedMaxTotalNo AS numeric(9, 3)
,@PolicyAction AS smallint,@VacPolicyExist AS smallint
,@VacAffectDueDays AS numeric(9,3),@HiringProratedDays AS numeric(9,3)
,@MaxTotalVacAffectDue AS bit,@MaxOccVacAffectDue AS bit
,@VacValidity AS bit,@VacValidityNo AS  numeric(9, 3),@VacValidityUnit AS smallint,@VacValidityVacCodes AS nvarchar(254)
,@RequestFromValidity AS bit,@RequestFromNo AS smallint,@RequestFromUnit AS smallint
,@MaxTotalVacCodes AS nvarchar(254),@MaxOccVacCodes AS nvarchar(254), @MaxTotalVacCodestemp AS NVARCHAR(254),
@MaxOccVacCodestemp AS NVARCHAR(254), @MaxBalBefore as bit,@MaxBalBeforeNo as numeric(9, 3),@MaxBalBeforeCategory as smallint,
@MaxBalBeforeTill as SMALLINT, @AllowIntersectedSubmittedVac AS bit


---select the parameters from VacationPolicy table to compare it with the calc parameters when requesting for new vacation
select @VacPolicyExist=VacationPolicy.vaccode,@VacLength=VacLength, @MinDays=MinDays, @MaxDays=MaxDays, @CategoryBal=CategoryBal, 
@MinBalBefore=MinBalBefore,@MinBalAfter= MinBalAfter, @MaxTotal=MaxTotal, @MaxTotalNo=MaxTotalNo, 
@MaxTotalEvery=MaxTotalEvery,@MaxTotalEveryUnit= MaxTotalEveryUnit, 
@MaxTotalSince=MaxTotalSince, @MaxTotalVacAffectDue=MaxTotalVacAffectDue,
@MaxOccurance=MaxOccurance, @MaxOccuranceNo=MaxOccuranceNo,
@MaxOccuranceEvery= MaxOccuranceEvery, @MaxOccEveryUnit=MaxOccEveryUnit, 
@MaxOccuranceSince=MaxOccuranceSince, @MaxOccVacAffectDue=MaxOccVacAffectDue,
@AllowAfter=AllowAfter,@AllowAfterNo= AllowAfterNo,@AllowAfterUnit= AllowAfterUnit, 
@AllowAfterSince=AllowAfterSince,@BalanceTill=BalanceTill,
@PolicyAction=PolicyAction,
@VacValidity =VacValidity,@VacValidityNo =VacValidityNo,
@VacValidityUnit =VacValidityUnit,@VacValidityVacCodes =VacValidityVacCodes
,@RequestFromValidity=RequestFromValidity,@RequestFromNo=RequestFromNo,@RequestFromUnit=RequestFromUnit
,@MaxTotalVacCodes=VacationPolicy.MaxTotalVacCodes,@MaxOccVacCodes=VacationPolicy.MaxOccVacCodes,
@MaxBalBefore=VacationPolicy.MaxBalBefore,@MaxBalBeforeNo=VacationPolicy.MaxBalBeforeNo,
@MaxBalBeforeCategory=VacationPolicy.MaxBalBeforeCategory,@MaxBalBeforeTill=VacationPolicy.MaxBalBeforeTill

FROM VacationPolicy
inner join empassignment on empassignment.VacPack=VacationPolicy.vacpack
Where vaccode=@vaccode and empid=@empid


IF @VacPolicyExist IS  NULL
BEGIN
	return N'001'
END

SELECT @HireDate= hiredate from EmpAssignment  where EmpId=@empid

declare @vaclengthno as numeric(9, 3),@vactype as smallint,@balancebefore as numeric(9, 3),@totaldays as numeric(9, 3)
,@date1 as datetime,@date2 as datetime,@balanceafter as numeric(9, 3),@prevyearbalafter as numeric(9, 3)
set @vaclengthno=0.0

	declare @enablehijri as bit,@payrollgroup as smallint,@year as smallint,@h_Yearfrom as nchar(4),@h_Yearto as nchar(4)
    ,@h_MonthFrom as nchar(4),@h_MonthTo as nchar(4)
	select @vactype=vactype ,@enablehijri=enablehijri from Vacation cross join sysparam where vaccode=@vaccode
	
	select @payrollgroup=EmpAssignment.PayrollGroup,@Year=Cyear 
	from EmpAssignment inner join PayrollGroup on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup where EmpId=@empid


	select @vaclengthno=dbo.VacTakenDays(@EmpId, @FromDate, @ToDate, @VacCode,@DocNo,@PartDayFrom , @PartDayTo)
	---------------------------------------------------------------------------------------------------------------------
		DECLARE @OldVacLength AS NUMERIC(9,3),@OldFromDate AS SMALLDATETIME,@OldToDate AS SMALLDATETIME,@CurrentYearStart AS SMALLDATETIME,@CurrentYearEnd AS SMALLDATETIME
		,@OldVacCode AS SMALLINT,@oldVacStatus as smallint,@StartDatePeriodEnd AS SMALLDATETIME,@EndDatePeriodEnd AS SMALLDATETIME, @Reenter AS BIT
----------------------------------------MinDays and MaxDays-------------------------------------------------------------
if @vaclength=1
begin
--calc the duration of the vacation requested & check that it s between min & max days required
	if @vaclengthno not between @MinDays and @MaxDays
		begin
				--set @reason='002'+rtrim(ltrim(str(@PolicyAction)))+' - '+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','MinMaxDays',@latinlang))),(case when @latinlang='E' then 'vacation length is not between min and max days' else N' مدة الاجازة ليست فى الفترة المسموح بها ' end))
			set @reason= @reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'002'+rtrim(ltrim(str(@PolicyAction)))+' - '
				+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'MinMaxDays',@latinlang))),(case when @latinlang=N'E' then N'vacation length is not between min and max days' else N' مدة الاجازة ليست فى الفترة المسموح بها ' end))		
	end
end
----------------------------------------------------------------------------------------------------------------------
----------------------------------------AllowAfter--------------------------------------------------------------------------

if @AllowAfter=1
--@AllowAfterSince: check on hire or prob dates

begin
--@date1= hire or prob date according to @AllowAfterSince

select @date1=case when @AllowAfterSince=1 then hiredate 
                   when @AllowAfterSince=2 then probdate 
                   WHEN @AllowAfterSince=3 THEN 
                                 case when(@enablehijri=1 and @year<1900)then 
                                     dbo.Hijri2Greg((N'01/01/'+CONVERT(nvarchar(4),(dbo.GetDatePart(N'y',@fromdate))))) else
	                                CONVERT(smalldatetime,N'01/01/'+ltrim(str(year(@fromdate))),111)
                                 end
                   WHEN @AllowAfterSince=4 THEN ContStart
                   WHEN @AllowAfterSince=5 THEN RevisedHireDate
                   WHEN @AllowAfterSince=6 THEN WorkReceivingDate
                   WHEN @AllowAfterSince=7 THEN 
                                case when(@enablehijri=1 and @year<1900)then 
			                    (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, dbo.GetDatePart(N'y',@fromdate)+1 )) < convert(nchar(10),@fromdate,111) THEN 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,(dbo.GetDatePart(N'y',@fromdate))+1) ELSE 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,(dbo.GetDatePart(N'y',@fromdate))) 
                                     END) else
					         (CASE WHEN DATEADD(dd, -1, dbo.periodstart(EmpAssignment.PayrollGroup, 1, year(@fromdate)+1 )) < convert(nchar(10),@fromdate,111) THEN 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) 
                                     END)
                                 END
                   WHEN @AllowAfterSince=8 THEN SsDate
	         end 
from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid
					
	
	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @AllowAfterUnit=2 then dbo.h_dateadd(N'MM', @AllowAfterNo,@date1)
		when @AllowAfterUnit=3 then dbo.h_dateadd(N'YY',@AllowAfterNo,@date1)
		else dbo.h_dateadd(N'DD',@AllowAfterNo,@date1)end-1
	end

	else
	begin	
--@date2= @date1 + @AllowAfterNo
--@AllowAfterUnit : determines whether @AllowAfterNo is day, month or year
		set @date2=case
		when @AllowAfterUnit=2 then dateadd(m,@AllowAfterNo,@date1)
		when @AllowAfterUnit=3 then dateadd(yy,@AllowAfterNo,@date1)
		else dateadd(d,@AllowAfterNo,@date1)end-1
	end
--@date2: date at which it is allowed after it to request for vacation
--compare the vacation date with @date2 
	if @fromdate <=@date2
	begin 
--		select @reason='005'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','AllowAfter',@latinlang))),(case when @latinlang='E' then 'The vacation is allowed after' else N'مسموح بالاجازة بعد' end))+' '+ltrim(rtrim(str(@AllowAfterNo)))+ ' '
--+ case when @AllowAfterUnit=2 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('DDLPeriodType','4',@latinlang))),(case when @latinlang='E' then 'Months' else N'شهور' end))  
--when @AllowAfterUnit=3 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('DDLPeriodType','6',@latinlang))),(case when @latinlang='E' then 'Years' else N'سنين' end)) 
--else isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('DDLPeriodType','2',@latinlang))),(case when @latinlang='E' then 'Days' else N'أيام' end))  end 
--+' '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('Common','From',@latinlang))),(case when @latinlang='E' then 'From' else N'من' end)) + ' '+
--+case 
--when @AllowAfterSince=1 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','HIREDATE',@latinlang))),(case when @latinlang='E' then 'Hire Date ' else N' تاريخ التوظيف ' end)) ) 
--when @AllowAfterSince=2 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','PROBDATE',@latinlang))),(case when @latinlang='E' then 'Probation Date ' else N' تاريخ إنتهاء فترة الإختبار ' end))) 
--when @AllowAfterSince=3 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('common','CalendarYearStart',@latinlang))),(case when @latinlang='E' then 'Calendar Year Start ' else N' بداية سنة التقويم ' end))) 
--when @AllowAfterSince=4 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','ContStart',@latinlang))),(case when @latinlang='E' then 'Contract Start Date ' else N' تاريخ بداية التعاقد ' end))) 
--when @AllowAfterSince=5 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','RevisedHireDate',@latinlang))),(case when @latinlang='E' then 'Revised Hire Date ' else N' تاريخ التعيين بعد المراجعة ' end))) 
--when @AllowAfterSince=6 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('empassignment','WorkReceivingDate',@latinlang))),(case when @latinlang='E' then 'Work Receiving Date  ' else N' تاريخ إستلام العمل ' end))) 
--end 
set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+ CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'005'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction','AllowAfter',@latinlang))),(case when @latinlang=N'E' then N'The vacation is allowed after' else N'مسموح بالاجازة بعد' end))+N' '+ltrim(rtrim(str(@AllowAfterNo)))+ N' '
+ case when @AllowAfterUnit=2 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'4',@latinlang))),(case when @latinlang=N'E' then N'Months' else N'شهور' end))  
when @AllowAfterUnit=3 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'6',@latinlang))),(case when @latinlang=N'E' then N'Years' else N'سنين' end)) 
else isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'2',@latinlang))),(case when @latinlang=N'E' then N'Days' else N'أيام' end))  end 
+N' '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'Common',N'From',@latinlang))),(case when @latinlang=N'E' then N'From' else N'من' end)) + N' '+
+case 
when @AllowAfterSince=1 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'empassignment',N'HIREDATE',@latinlang))),(case when @latinlang=N'E' then N'Hire Date ' else N' تاريخ التوظيف ' end)) ) 
when @AllowAfterSince=2 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'empassignment',N'PROBDATE',@latinlang))),(case when @latinlang=N'E' then N'Probation Date ' else N' تاريخ إنتهاء فترة الإختبار ' end))) 
when @AllowAfterSince=3 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'common',N'CalendarYearStart',@latinlang))),(case when @latinlang=N'E' then N'Calendar Year Start ' else N' بداية سنة التقويم ' end))) 
when @AllowAfterSince=4 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'empassignment','ContStart',@latinlang))),(case when @latinlang=N'E' then N'Contract Start Date ' else N' تاريخ بداية التعاقد ' end))) 
when @AllowAfterSince=5 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'empassignment',N'RevisedHireDate',@latinlang))),(case when @latinlang=N'E' then N'Revised Hire Date ' else N' تاريخ التعيين بعد المراجعة ' end))) 
when @AllowAfterSince=6 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'empassignment',N'WorkReceivingDate',@latinlang))),(case when @latinlang=N'E' then N'Work Receiving Date  ' else N' تاريخ إستلام العمل ' end))) 
when @AllowAfterSince=7 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'common',N'PayrollGroupYearStart',@latinlang))),(case when @latinlang=N'E' then N'Payroll Group Year Start ' else N' بداية سنة مجموعة المرتب ' end))) 
when @AllowAfterSince=8 then (isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'empassignment',N'SSDATE',@latinlang))),(case when @latinlang=N'E' then N'Social Insurance Date ' else N' تاريخ التأمين ' end))) 

 end 

	end
end

---------------------------------------minbalbefore & minbalafter------------------------------------------------------
if @CategoryBal=1
-- @BalanceTill=0 balance till end of the year
-- @BalanceTill=1 balance till end of the month
-- @BalanceTill=2 balance till end of the year (calender)
-- @BalanceTill=3 balance till end of the month (calender)
begin
DECLARE @vactypeTemp AS smallint
--the commented below line is for Aljazira Takaful to solve the case " prevent requesting “Unpaid Leave” if the  annual balance <0"
--SET @vactypeTemp=CASE WHEN @vactype>3 THEN 1 ELSE @vactype END  ------- if the catogery of the vacation is "other" , we will apply the policy on the annual balance
SET @vactypeTemp=@vactype
	
    SELECT @Reenter = 0
		
			IF @DocNo<>0
			BEGIN
				select @OldVacLength=dbo.[VacTotalTaken](@EmpId, FromDate, ToDate, VacCode),@OldFromDate=FromDate,@OldToDate=ToDate,@OldVacCode=EmpVacat.VacCode,@oldVacStatus=empvacat.VacStatus
				FROM EmpVacat 
				WHERE empid=@empid AND DocumentNo=@DocNo
				SELECT @Reenter = 1
			select @CurrentYearStart=dbo.periodstart(@PayrollGroup,1,@year),@CurrentYearEnd=DATEADD(dd, -1, dbo.periodstart(@PayrollGroup, 1, @year+1)) 
			END
-----------------------------------------------------------------------------------------------------------------------------------------------------------   
---------------------------------------------------------------------hijri--------------------------------------------------------------------------------------------------------------
	if @enablehijri=1 and @year<1900
	BEGIN
		IF @BalanceTill=0
		BEGIN
			select @h_Yearfrom=dbo.GetDatePart(N'y',@fromdate),@h_Yearto=dbo.GetDatePart(N'y',@todate)
			set @StartDatePeriodEnd=DATEADD(dd, -1, dbo.periodstart(@PayrollGroup, 1, 
			case when DATEADD(dd, -1, dbo.periodstart(@PayrollGroup, 1, @h_Yearfrom+1)) <@fromdate then @h_Yearfrom+1 else  @h_Yearfrom END+1))
			
			set @EndDatePeriodEnd=dateadd(day,-1,dbo.periodstart(@payrollgroup, 1,
			case when dateadd(day,-1,dbo.periodstart(@PayrollGroup,1,@h_Yearto+1))<@todate then @h_Yearto+1 else @h_Yearto END+1))
			select @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),	
			       @balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)

	   IF @DocNo<>0  and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		END

		 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------


		END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		--end of year(calender)hijri
	IF @BalanceTill=2
	BEGIN
		select @h_Yearfrom=(dbo.GetDatePart(N'y',@fromdate)+1),@h_Yearto=(dbo.GetDatePart(N'y',@todate)+1)
		set @StartDatePeriodEnd=DATEADD(dd,-1,dbo.Hijri2Greg((N'01/01/'+CONVERT(nvarchar(4),@h_Yearfrom))))
		set @EndDatePeriodEnd=DATEADD(dd,-1,dbo.Hijri2Greg((N'01/01/'+CONVERT(nvarchar(4),@h_Yearto))))
		select @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp)	,		
		@balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)
		

	   IF @DocNo<>0  and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		END

		 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------

		
	END
		
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		--end of month(payroll) hijri
------------------------------------------
		IF @BalanceTill=1
		BEGIN
			select @h_Yearfrom=dbo.GetDatePart(N'y',@fromdate),@h_Yearto=dbo.GetDatePart(N'y',@todate),
			@h_MonthFrom=dbo.GetDatePart(N'm',@fromdate),@h_MonthTo=dbo.GetDatePart(N'm',@todate)
			select @balancebefore=dbo.EmpVacBal(@empid,dbo.EndOfPeriodPerDate(@payrollgroup,@fromdate,'H',2),@vactypeTemp),	
			@balanceafter=dbo.EmpVacBal(@empid,dbo.EndOfPeriodPerDate(@payrollgroup,@todate,'H',2),@vactypeTemp)	
			SET @StartDatePeriodEnd=dbo.EndOfPeriodPerDate(@payrollgroup,@fromdate,'H',2)
			SET @EndDatePeriodEnd=dbo.EndOfPeriodPerDate(@payrollgroup,@todate,'H',2)

		

	   IF @DocNo<>0 and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		END

 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------


		END
		------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
         ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		--end of month(calender) hijri

		IF @BalanceTill=3
		BEGIN
			select @h_Yearfrom=(dbo.GetDatePart(N'y',@fromdate)),@h_Yearto=(dbo.GetDatePart(N'y',@todate)),@h_monthfrom=(dbo.GetDatePart(N'm',@fromdate))+1,@h_monthto=(dbo.GetDatePart(N'm',@todate))+1
		    set @StartDatePeriodEnd=convert(smalldatetime,dbo.h_DATEADD('DD',-1,convert(datetime,dbo.Hijri2Greg((N'01/'+CONVERT(nvarchar(2),@h_monthfrom)+'/'+CONVERT(nvarchar(4),@h_Yearfrom))))))
		    set @EndDatePeriodEnd=convert(smalldatetime,dbo.h_DATEADD('DD',-1,convert(datetime,dbo.Hijri2Greg((N'01/'+CONVERT(nvarchar(2),@h_monthto)+'/'+CONVERT(nvarchar(4),@h_Yearto))))))
		    select @balancebefore=dbo.EmpVacBal(@EmpId,@StartDatePeriodEnd,@vactypeTemp)	,		
		    @balanceafter=dbo.EmpVacBal(@EmpId,@EndDatePeriodEnd,@vactypeTemp)

	    IF @DocNo<>0 and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	    BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		END

	 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------

	   END
	   	----------------------------Balacne Before one day from Vacation Date
   IF @BalanceTill in (4,5)
   BEGIN
        set @StartDatePeriodEnd= convert (smalldatetime,DATEADD(d,-1,@fromdate)) 
        set @EndDatePeriodEnd=case when @BalanceTill = 4 then @StartDatePeriodEnd else @todate end
	    SELECT @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),
               @balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)
	  	   IF @DocNo<>0  and @oldVacStatus=1  AND (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart)
		   BEGIN
				IF @OldFromDate<= @StartDatePeriodEnd
				BEGIN
					SET  @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
							
				END
                IF @OldFromDate<=@EndDatePeriodEnd
			    BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END

			END    
		END  
 END   
else
-----------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------Gregorian----------------------------------------------------------------------------------
   BEGIN
		IF @BalanceTill=0 -- payroll year
		BEGIN
         --calc the balance before the requested vacation
           SET @StartDatePeriodEnd=dbo.periodend(@payrollgroup, 12,
                       case when dateadd(day,-1,dbo.periodstart(@PayrollGroup,1,Year(@fromdate)+1))<@fromdate then Year(@fromdate)+1 else  year(@Fromdate) end)
           set @EndDatePeriodEnd=dateadd(day,-1,dbo.periodstart(@payrollgroup, 1,
			           case when dateadd(day,-1,dbo.periodstart(@PayrollGroup,1,Year(@todate)+1))<@todate then Year(@todate)+1 else  year(@todate) END+1))
		   select @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),	
            --	calc the balance after the requested vacation		
			      @balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)

	   IF @DocNo<>0 and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		END

     ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------

        END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		--end of year(calender)
	IF @BalanceTill=2
	BEGIN
		SET @StartDatePeriodEnd=CONVERT(smalldatetime,(ltrim(str(year(@fromdate)))+N'/12/31'),111)
		SET @EndDatePeriodEnd=CONVERT(smalldatetime,(ltrim(str(year(@todate)))+N'/12/31'),111)
		select @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),			
			   @balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)
	   IF @DocNo<>0 and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		END

 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------

	END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		--end of month(payroll)

		IF @BalanceTill=1
		BEGIN
			SET @StartDatePeriodEnd=dbo.endofperiodperdate(@payrollgroup,@fromdate,'G',2)
			SET @EndDatePeriodEnd=dbo.endofperiodperdate(@payrollgroup,@todate,'G',2)

			select @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),	
			@balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)
	   IF @DocNo<>0 and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
			
		END

 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------

	    END
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		--end of month (calender)
		if @BalanceTill=3
		BEGIN
			 set @StartDatePeriodEnd=DATEADD(d,-1,DATEADD(m,1,CONVERT(SMALLDATETIME , ltrim(rtrim(str(YEAR(@fromdate))))+'/'+ ltrim(rtrim(str(Month(@fromdate))))+'/01')))
			 set @EndDatePeriodEnd=DATEADD(d,-1,DATEADD(m,1,CONVERT(SMALLDATETIME , ltrim(rtrim(str(YEAR(@todate))))+'/'+ ltrim(rtrim(str(Month(@todate))))+'/01')))
		----OR
             --set @StartDatePeriodEnd=dateadd(dd,-1,convert(smalldatetime,(CONVERT(nvarchar(4),(case when month(@fromdate)=12 then  year(@fromdate)+1 else year(@fromdate) end))+'/'+CONVERT(nvarchar(2),(case when month(@fromdate)=12 then 1 else month(@fromdate)+1 end ))+N'/01')))
             --set @EndDatePeriodEnd=dateadd(dd,-1,convert(smalldatetime,(CONVERT(nvarchar(4),(case when month(@todate)=12 then  year(@todate)+1 else year(@todate) end))+'/'+CONVERT(nvarchar(2),(case when month(@todate)=12 then 1 else month(@todate)+1 end ))+N'/01')))
		     select @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),
		            @balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)
       IF @DocNo<>0 and @oldVacStatus=1 AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd
				BEGIN
					SET @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
				IF @OldFromDate<=@EndDatePeriodEnd
				BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END
				
		 END

 ------------------------------
		SELECT @balancebefore=@balancebefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd THEN @StartDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd


		SELECT @balanceafter=@balanceafter+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@EndDatePeriodEnd THEN @EndDatePeriodEnd ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@vactypeTemp AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@EndDatePeriodEnd

		---------------------------------


	end

	----------------------------Balacne Before one day from Vacation Date
   IF @BalanceTill in (4,5)
   BEGIN
        set @StartDatePeriodEnd= convert (smalldatetime,DATEADD(d,-1,@fromdate)) 
        set @EndDatePeriodEnd=case when @BalanceTill = 4 then @StartDatePeriodEnd else @todate end
	    SELECT @balancebefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd,@vactypeTemp),
               @balanceafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd,@vactypeTemp)
	  	   IF @DocNo<>0   and @oldVacStatus=1 AND (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart)
		   BEGIN
				IF @OldFromDate<= @StartDatePeriodEnd
				BEGIN
					SET  @balancebefore=@balancebefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd then @StartDatePeriodEnd else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
							
				END
                IF @OldFromDate<=@EndDatePeriodEnd
			    BEGIN
				    SET @balanceafter=@balanceafter+
				    ( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd then @EndDatePeriodEnd else @OldToDate end, @OldVacCode))
                    SELECT @Reenter = 0
				END

			END    
			end 
		-----------------------------------------------------------------------------------------------------------------------------------------------------------
		-----------------------------------------------------------------------------------------------------------------------------------------------------------
		-----------------------------------------------------------------------------------------------------------------------------------------------------------
end
--compare the calculated balance with min balance required	
	--the commented below line is for Aljazira Takaful to solve the case " prevent requesting “Unpaid Leave” if the annual balance <0"
	--if (@balancebefore<=@MinBalBefore AND @vactype<=3)OR (@vactype>3  AND @balancebefore >@MinBalBefore )
	--------------------------------------------------------------------------------------------------------------------------------------------------

	if (@balancebefore<@MinBalBefore )
	begin
	
		--set @reason='003'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','MinBalanceBefore',@latinlang))),(case when @latinlang='E' then 'balance before vacation is less than min balance required  ' else N'الرصيد قبل الاجازة اقل من الحد الادني المسموح ' end))
		set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+ CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'003'+rtrim(ltrim(str(@PolicyAction)))+N' - '+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'MinBalanceBefore',@latinlang))),(case when @latinlang=N'E' then N'balance before vacation is less than min balance required  ' else N'الرصيد قبل الاجازة اقل من الحد الادني المسموح ' end))
		IF @Reenter = 1
		BEGIN
			set @reason=@reason+CASE WHEN @reason <> N'' THEN N' - ' ELSE N'' END+ 
			isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'ReEnter',@latinlang))),(case when @latinlang=N'E' then N'Please Delete the Vacation and Re-enter it ' else N'من فضلك امسح الأجازة واعد إدخالها ' end))
			SET @Reenter = 0
		END	

	end

	--the commented below line is for Aljazira Takaful to solve the case " prevent requesting “Unpaid Leave” if the annual balance <0"
	--set @balanceafter=case when @vactype>3 then @balanceafter else @balanceafter-@vaclengthno end

	set @balanceafter=@balanceafter-@vaclengthno 

--compare the calculated balance after with min balance after required	
	if @balanceafter<@MinBalAfter 
	begin
		--set @reason='004'+rtrim(ltrim(str(@PolicyAction)))+' - '+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','MinBalanceAfter',@latinlang))),(case when @latinlang='E' then 'balance after vacation is less than min balance required  ' else N' الرصيد بعد الاجازة اقل من الحد الادني المسموح' end))
	set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'004'+rtrim(ltrim(str(@PolicyAction)))+N' - '+ isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'MinBalanceAfter',@latinlang))),(case when @latinlang=N'E' then N'balance after vacation is less than min balance required  ' else N' الرصيد بعد الاجازة اقل من الحد الادني المسموح' end))
		IF @Reenter = 1
		BEGIN
			set @reason=@reason+CASE WHEN @reason <> N'' THEN N' - ' ELSE N'' END+ 
			isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'ReEnter',@latinlang))),(case when @latinlang=N'E' then N'Please Delete the Vacation and Re-enter it ' else N'من فضلك امسح الأجازة واعد إدخالها ' end))
			SET @Reenter = 0
		END	
	end
end

----------------------------------------------------------MaxBalBefore -------------------------------------------------------------
if @MaxBalBefore=1
BEGIN


		DECLARE @StartDatePeriodEnd_max AS SMALLDATETIME,@balbefore as numeric(9, 3),@oldvactype  AS smallint,@EndDatePeriodEnd_max AS SMALLDATETIME,@balafter as numeric(9, 3),@calcbalance as numeric(9, 3)
            SELECT @Reenter = 0
			IF @DocNo<>0
			BEGIN
				select 
				@OldFromDate=FromDate,@OldToDate=ToDate,@OldVacCode=EmpVacat.VacCode,@oldVacStatus=empvacat.VacStatus
				FROM EmpVacat 
				WHERE empid=@empid AND DocumentNo=@DocNo
				SELECT @Reenter = 1
			    select @CurrentYearStart=dbo.periodstart(@PayrollGroup,1,@year),@CurrentYearEnd=dateadd(day,-1,dbo.periodstart(@PayrollGroup,1,@year+1))
                select @oldvactype=vactype from Vacation where vacation.vaccode=@OldVacCode
			END
-----------------------------------------------------------------------------------------------------------------------------------------------------------   
---------------------------------------------------------------------hijri--------------------------------------------------------------------------------------------------------------
	if @enablehijri=1 and @year<1900
	BEGIN
		--end of year(payroll) hijri
		-------------------------------------------------------------------
		IF @MaxBalBeforeTill=0
		BEGIN
			select @h_Yearfrom=dbo.GetDatePart(N'y',@fromdate)
			set @StartDatePeriodEnd_max=dateadd(day,-1,dbo.periodstart(@payrollgroup, 1,case when dateadd(day,-1,dbo.periodstart(@PayrollGroup,1,@h_Yearfrom+1))<@fromdate then @h_Yearfrom+1 else  @h_Yearfrom END+1))
			select @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)
	    IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	     BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END	
 		 END
 		 
 		 ------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------
		
		END
		--end of year(calender)hijri
		-------------------------------------------------------------------
		IF @MaxBalBeforeTill=2
		BEGIN
            select @h_Yearfrom=(dbo.GetDatePart(N'y',@fromdate)+1)
            set @StartDatePeriodEnd_max=DATEADD(dd,-1,dbo.Hijri2Greg((N'01/01/'+CONVERT(nvarchar(4),@h_Yearfrom))))
            select @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)
		IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
		BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
		END
		
		------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------
		
		END
		--end of month(payroll) hijri
		-------------------------------------------------------------------
		IF @MaxBalBeforeTill=1
		BEGIN
		select @h_Yearfrom=dbo.GetDatePart(N'y',@fromdate)
			,@h_MonthFrom=dbo.GetDatePart(N'm',@fromdate)
			
				select @balbefore=dbo.EmpVacBal(@empid,dbo.endofperiodperdate(@payrollgroup,@fromdate,'H',2) ,@MaxBalBeforeCategory)
        SET @StartDatePeriodEnd_max =dbo.endofperiodperdate(@payrollgroup,@fromdate,'H',2)

		
       IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
		END
		
			 ------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------
		
		END
		--end of month(calender) hijri
		-------------------------------------------------------------------
		IF @MaxBalBeforeTill=3
		BEGIN
           select @h_Yearfrom=(dbo.GetDatePart(N'y',@fromdate))
           ,@h_monthfrom=(dbo.GetDatePart(N'm',@fromdate))+1
		    set @StartDatePeriodEnd_max=convert(smalldatetime,dbo.h_DATEADD('DD',-1,convert(datetime,dbo.Hijri2Greg((N'01/'+CONVERT(nvarchar(2),@h_monthfrom)+'/'+CONVERT(nvarchar(4),@h_Yearfrom))))))
             select @balbefore=dbo.EmpVacBal(@EmpId,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)	
	    IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	    BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
		END
		
		------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------
		
		END
		
		
		-------------------------------24-01-2016 ----------------- Balacne Before one day from Vacation Date  hijri------------------------
		IF @MaxBalBeforeTill = 4
		BEGIN
			--SET  @StartDatePeriodEnd_max =CONVERT (smalldatetime,dbo.h_dateadd('DD',-1,dbo.Hijri2Greg(@fromdate)))
			SET  @StartDatePeriodEnd_max = 	convert (smalldatetime,DATEADD(d,-1,@fromdate)) 
			  select @balbefore=dbo.EmpVacBal(@EmpId,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)	
			      IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
					BEGIN
						IF @OldFromDate<=@StartDatePeriodEnd_max
						BEGIN
							SET @balbefore=@balbefore+
							( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
							SELECT @Reenter = 0
						END
					END
		END 
	---------------------------------------------------------------------Balacne after taking the vacation ----------------------------------------------------------------------- 
	IF @MaxBalBeforeTill = 5
	BEGIN
		SET  @EndDatePeriodEnd_max = @todate
	
	    SELECT @balafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd_max,@MaxBalBeforeCategory)
	  	      IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory)   AND (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart)
		       BEGIN
				IF @OldFromDate<= @EndDatePeriodEnd_max
						BEGIN
							SET @balafter= @balafter+
							( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd_max then @EndDatePeriodEnd_max else @OldToDate end, @OldVacCode))
							SELECT @Reenter = 0
							
						END
						
	
				  END          
	END	
		-------------------------------------------------------
 END   
else
-----------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------Gregorian----------------------------------------------------------------------------------
    BEGIN
   		--end of year(payroll)
		-------------------------------------------------------------------
		IF @MaxBalBeforeTill=0 
		BEGIN
		
            SET @StartDatePeriodEnd_max=dateadd(day,-1,dbo.periodstart(@payrollgroup, 1,
            case when dateadd(day,-1,dbo.periodstart(@PayrollGroup,1,Year(@fromdate)+1))<@fromdate then Year(@fromdate)+1 else  year(@Fromdate) END+1))
		    select @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)
       IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max 
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
        END

		 ------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------

        END
		--end of year(calender)
		-------------------------------------------------------------------
    	IF @MaxBalBeforeTill=2
	    BEGIN
	    SET @StartDatePeriodEnd_max=CONVERT(smalldatetime,(ltrim(str(year(@fromdate)))+N'/12/31'),111)
		select @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)		
        IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	    BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max 
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
		END

	
		------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------

	    END
		--end of month(payroll)
		-------------------------------------------------------------------
		IF @MaxBalBeforeTill=1
		BEGIN
		SET @StartDatePeriodEnd_max=dbo.endofperiodperdate(@payrollgroup,@fromdate,'G',2)
            select @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)

         
	   IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	   BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max 
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
		END

		 ------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------

	    END
		--end of month (calender)
		-------------------------------------------------------------------
		if @MaxBalBeforeTill=3
		BEGIN
            set @StartDatePeriodEnd_max=DATEADD(d,-1,DATEADD(m,1,CONVERT(SMALLDATETIME , ltrim(rtrim(str(YEAR(@fromdate))))+'/'+ ltrim(rtrim(str(Month(@fromdate))))+'/01')))
	      	select @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory) 
        IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory) AND  (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart) 
	    BEGIN
				IF @OldFromDate<=@StartDatePeriodEnd_max 
				BEGIN
					SET @balbefore=@balbefore+
					( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
					SELECT @Reenter = 0
				END
		  END   

	 ------------------------------
		SELECT @balbefore=@balbefore+( dbo.[VacTotalTaken](@EmpId,CASE WHEN FromDate>@fromdate THEN FromDate ELSE @fromdate END ,CASE WHEN todate>@StartDatePeriodEnd_max THEN @StartDatePeriodEnd_max ELSE todate END, EmpVacat.VacCode))
		FROM dbo.EmpVacat LEFT JOIN dbo.Vacation ON Vacation.vaccode = EmpVacat.VacCode
		WHERE empid=@empid AND VacStatus=1 AND VacType=@MaxBalBeforeCategory AND DocumentNo<> @DocNo AND FromDate>=@fromdate AND FromDate<=@StartDatePeriodEnd_max
		---------------------------------

		END
		
		
		
		
		------------------------------- 24-01-2016 ----------------- Balacne Before one day from Vacation Date  --------------------------------------------------
			
	IF @MaxBalBeforeTill = 4
	
	BEGIN
		SET  @StartDatePeriodEnd_max =  convert (smalldatetime,DATEADD(d,-1,@fromdate)) 
	
	    SELECT @balbefore=dbo.EmpVacBal(@empid,@StartDatePeriodEnd_max,@MaxBalBeforeCategory)
	  	      IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory)   AND (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart)
		       BEGIN
				IF @OldFromDate<= @StartDatePeriodEnd_max
						BEGIN
							SET @balbefore= @balbefore+
							( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @StartDatePeriodEnd_max then @StartDatePeriodEnd_max else @OldToDate end, @OldVacCode))
							SELECT @Reenter = 0
							
						END
						
	
				  END          
	END
	
	---------------------------------------------------------------------Balacne after taking the vacation ----------------------------------------------------------------------- 
	IF @MaxBalBeforeTill = 5
	BEGIN
		SET  @EndDatePeriodEnd_max = @todate
	
	    SELECT @balafter=dbo.EmpVacBal(@empid,@EndDatePeriodEnd_max,@MaxBalBeforeCategory)
	  	      IF @DocNo<>0 and @oldVacStatus=1 and (@oldvactype=@MaxBalBeforeCategory)   AND (@OldFromDate >= @CurrentYearStart) AND (@FromDate  >= @CurrentYearStart)
		       BEGIN
				IF @OldFromDate<= @EndDatePeriodEnd_max
						BEGIN
							SET @balafter= @balafter+
							( dbo.[VacTotalTaken](@EmpId,@OldFromDate,case when @OldToDate > @EndDatePeriodEnd_max then @EndDatePeriodEnd_max else @OldToDate end, @OldVacCode))
							SELECT @Reenter = 0
							
						END
						
	
				  END          
	END	
		
------------------------------------------------------
   end
   IF @MaxBalBeforeTill = 5 and @MaxBalBeforeCategory=@vactype
	BEGIN
	  SET @balafter= @balafter-@vaclengthno

	End
-------------enter msg in datadictionary 

select @calcbalance =(case when @MaxBalBeforeTill=5 then @balafter else @balbefore end )
	   IF (@calcbalance > @MaxBalBeforeNo )
	   BEGIN

	       set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+ CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'003'+rtrim(ltrim(str(@PolicyAction)))+N' - '+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(case when @MaxBalBeforeTill=5 then dbo.Hits_GetDCCaption(N'VacationRestriction',N'MaxBalAfter',@latinlang) else dbo.Hits_GetDCCaption(N'VacationRestriction',N'MaxBalBefore',@latinlang)end)),(case when @latinlang=N'E' then (case when @MaxBalBeforeTill=5 then N'balance after vacation is greater than balance required for taking this type of vacation'  else N'balance before vacation is greater than balance required for taking this type of vacation' end )else (case when @MaxBalBeforeTill=5 then N'الرصيد بعد الاجازة اكبر من الحد المسموح به لاخذ هذا النوع من الاجازات 'else N'الرصيد قبل الاجازة اكبر من الحد المسموح به لاخذ هذا النوع من الاجازات ' end )end))
          IF @Reenter = 1
		  BEGIN
			set @reason=@reason+CASE WHEN @reason <> N'' THEN N' - ' ELSE N'' END+ 
			isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'ReEnter',@latinlang))),(case when @latinlang=N'E' then N'Please Delete the Vacation and Re-enter it ' else N'من فضلك امسح الأجازة واعد إدخالها ' end))
			SET @Reenter = 0
		  END	
		  end

END
-------------------------------------------------------Total days-------------------------------------------------------------

if @MaxTotal=1
--@MaxTotalSince: check on hire or prob dates
BEGIN
	SELECT @HiringProratedDays=0.0,@VacAffectDueDays=0.0
--@date1= hire or prob date according to @MaxTotalSince

   select @date1=case when @MaxTotalSince=1 then hiredate 
                      when @MaxTotalSince=2 then probdate 
                      WHEN @MaxTotalSince=3 THEN 
                                 case when(@enablehijri=1 and @year<1900)then 
                                     dbo.Hijri2Greg((N'01/01/'+CONVERT(nvarchar(4),(dbo.GetDatePart(N'y',@fromdate))))) else
	                                CONVERT(smalldatetime,N'01/01/'+ltrim(str(year(@fromdate))),111)
                                 end
			         WHEN @MaxTotalSince=4 THEN ContStart
			         WHEN @MaxTotalSince=5 THEN RevisedHireDate
			         WHEN @MaxTotalSince=6 THEN WorkReceivingDate
			         WHEN @MaxTotalSince=7 THEN 
                                case when(@enablehijri=1 and @year<1900)then 
			                    (CASE WHEN dateadd(day,-1,dbo.periodstart(EmpAssignment.PayrollGroup, 1,(dbo.GetDatePart(N'y',@fromdate))+1)) < convert(nchar(10),@fromdate,111) THEN 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,(dbo.GetDatePart(N'y',@fromdate))+1) ELSE 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,(dbo.GetDatePart(N'y',@fromdate))) 
                                     END) else
					         (CASE WHEN dateadd(day,-1,dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) 
                                     END)
                                 END
			       WHEN @MaxTotalSince=8 THEN SsDate
	end 
    from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid

	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dbo.h_dateadd(N'MM', @MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dbo.h_dateadd(N'YY',@MaxTotalEvery,@date1)
		else dbo.h_dateadd(N'DD',@MaxTotalEvery,@date1)end-1
		
		while (@fromdate not between @date1 and @date2)
		begin
			set @date1=@date2+1
			set @date2=case
			when @MaxTotalEveryUnit=2 then dbo.h_dateadd(N'MM', @MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=3 then dbo.h_dateadd(N'YY',@MaxTotalEvery,@date1)
			else dbo.h_dateadd(N'DD',@MaxTotalEvery,@date1)end-1
		end
	
	end
	else
	begin
--@date2= @date1 + @MaxTotalEvery
--@MaxTotalEveryUnit : determines whether @MaxTotalEvery is day, month or year
--@MaxTotalEvery: the parameter at which max total days 'll reset
		set @date2=case
		when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
		else dateadd(d,@MaxTotalEvery,@date1)end-1
		while (@fromdate not between @date1 and @date2)
		begin
			set @date1=@date2+1
			set @date2=case
			when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
			when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
			else dateadd(d,@MaxTotalEvery,@date1)end-1
		end	
	END
	SET @MaxTotalVacCodestemp=CASE when @MaxTotalVacCodes <>'' THEN @MaxTotalVacCodes ELSE ','+rtrim(ltrim(str(@vaccode)))+',' end

	--calc total days for all vacation taken
	select @totaldays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
	(e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
	(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
	@date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocNo,@PartDayFrom , @PartDayTo) else 0 end) ,0)
	from empvacat e  where e.vacstatus=1 and e.empid=@empid and @MaxTotalVacCodestemp LIKE '%,'+ltrim(rtrim(str(e.vaccode)))+',%' AND e.DocumentNo<>@DocNo AND e.FromDate<=@fromdate
    --add taken days of the current requested vac to total days calculated above

	IF  charindex(','+ltrim(rtrim(str(@VacCode)))+',',@MaxTotalVacCodes )=0   AND @MaxTotalVacCodes<>''
    set @totaldays=@totaldays
    ELSE 
    --add taken days of the current requested vac to total days calculated above
	set @totaldays=@totaldays+dbo.VacTakenDays(@EmpId, @FromDate,case when  @ToDate <@date2 then @todate else @date2 end, @VacCode,@DocNo,@PartDayFrom , @PartDayTo)
	--compare the calculated total days with Max Total Allowed
	
-------------------------------------

IF (@MaxTotalSince=3 OR @MaxTotalSince=7) AND (@HireDate BETWEEN @date1 AND @date2) AND @HireDate <> @date1
BEGIN
		--@MaxOccEveryUnit=2 month  --@MaxOccEveryUnit=3 year  --@MaxOccEveryUnit=1 day

	SELECT @HiringProratedDays=datediff(d,@date1,@HireDate)
end

IF @MaxTotalVacAffectDue=1
BEGIN
	select @VacAffectDueDays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
	(e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
	(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
	@date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocNo,@PartDayFrom , @PartDayTo) else 0 end) ,0)
	from empvacat e 
	LEFT JOIN Vacation v ON v.vaccode = e.VacCode
	 where e.vacstatus=1 and e.empid=@empid and (v.vacbalcat=1 OR v.vacbalcat1=1 OR v.vacbalcat2=1) AND e.FromDate<=@fromdate
END

IF @HiringProratedDays<>0 OR @VacAffectDueDays<>0
	SET @ProratedMaxTotalNo=round((@MaxTotalNo/((datediff(d,@date1,@date2)+1)*1.00))*(datediff(d,@date1,@date2)+1-@VacAffectDueDays-@HiringProratedDays),0)
ELSE 
	SET @ProratedMaxTotalNo=@MaxTotalNo

--SELECT @date1,@date2,@totaldays,@HiringProratedDays,@VacAffectDueDays,(@MaxTotalNo/((datediff(d,@date1,@date2)+1)*1.00))*(datediff(d,@date1,@date2)+1-@VacAffectDueDays-@HiringProratedDays)
if @ProratedMaxTotalNo<@totaldays 
begin
	--set @reason='006'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','TotalDays',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max total days' else N' الاجازة تتعدى الحد الاقصى للايام المسموح بها' end))
	set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+ N'006'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction','TotalDays',@latinlang))),(case when @latinlang=N'E' then N'the vacation will exceed max total days' else N' الاجازة تتعدى الحد الاقصى للايام المسموح بها' end))
end


while  (@todate not between @date1 and @date2 ) 
begin

	set @date1=@date2+1
	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dbo.h_dateadd(N'MM', @MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dbo.h_dateadd(N'YY',@MaxTotalEvery,@date1)
		else dbo.h_dateadd(N'DD',@MaxTotalEvery,@date1)end-1

	end
	else
	begin
		set @date2=case
		when @MaxTotalEveryUnit=2 then dateadd(m,@MaxTotalEvery,@date1)
		when @MaxTotalEveryUnit=3 then dateadd(yy,@MaxTotalEvery,@date1)
		else dateadd(d,@MaxTotalEvery,@date1)end-1
	end
	
set @totaldays=0
SET @MaxTotalVacCodestemp=CASE when @MaxTotalVacCodes <>N'' THEN @MaxTotalVacCodes ELSE N','+rtrim(ltrim(str(@vaccode)))+N',' end
select @totaldays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
 (e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
 @date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocNo,@PartDayFrom , @PartDayTo) else 0 end) ,0)
 from empvacat e  
where e.vacstatus=1 and e.empid=@empid and @MaxTotalVacCodestemp LIKE '%,'+ltrim(rtrim(str(e.vaccode)))+',%' AND e.DocumentNo<>@DocNo AND e.FromDate<=@fromdate

	IF  charindex(','+ltrim(rtrim(str(@VacCode)))+',',@MaxTotalVacCodes )=0   AND @MaxTotalVacCodes<>''
    set @totaldays=@totaldays
    ELSE
    set @totaldays=@totaldays+dbo.VacTakenDays(@EmpId, @date1,case when  @ToDate <@date2 then @todate else @date2 end, @VacCode,@DocNo,@PartDayFrom , @PartDayTo)

IF @MaxTotalVacAffectDue=1
BEGIN
	SET @VacAffectDueDays=0.0
	select @VacAffectDueDays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
	(e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
	(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
	@date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocNo,@PartDayFrom , @PartDayTo) else 0 end) ,0)
	from empvacat e 
	LEFT JOIN Vacation v ON v.vaccode = e.VacCode
	 where e.vacstatus=1 and e.empid=@empid and (v.vacbalcat=1 OR v.vacbalcat1=1 OR v.vacbalcat2=1) AND e.FromDate<=@fromdate
END

IF  @VacAffectDueDays<>0
	SET @ProratedMaxTotalNo=round((@MaxTotalNo/((datediff(d,@date1,@date2)+1)*1.00))*(datediff(d,@date1,@date2)+1-@VacAffectDueDays),0)
ELSE 
	SET @ProratedMaxTotalNo=@MaxTotalNo

if @ProratedMaxTotalNo<@totaldays 
begin
	--set @reason='007'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','TotalDays',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max total days' else N' الاجازة تتعدى الحد الاقصى للايام المسموح بها' end))
	set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'007'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'TotalDays',@latinlang))),(case when @latinlang=N'E' then N'the vacation will exceed max total days' else N' الاجازة تتعدى الحد الاقصى للايام المسموح بها' end))
end

end

end

---------------------------------------------Occurance------------------------------------------------------------------------

if @MaxOccurance=1
--@MaxOccuranceSince: check on hire or prob dates
begin
--@date1= hire or prob date according to @MaxOccuranceSince

SELECT @HiringProratedDays=0.0,@VacAffectDueDays=0.0

	declare @count as int
	set @count=0
select @date1=case when @MaxOccuranceSince=1 then hiredate 
                   when @MaxOccuranceSince=2 then probdate 
                   WHEN @MaxOccuranceSince=3 THEN 
                                 case when(@enablehijri=1 and @year<1900)then 
                                     dbo.Hijri2Greg((N'01/01/'+CONVERT(nvarchar(4),(dbo.GetDatePart(N'y',@fromdate))))) else
	                                CONVERT(smalldatetime,N'01/01/'+ltrim(str(year(@fromdate))),111)
                                 end
			      WHEN @MaxOccuranceSince=4 THEN ContStart
			      WHEN @MaxOccuranceSince=5 THEN RevisedHireDate
			      WHEN @MaxOccuranceSince=6 THEN WorkReceivingDate
			      WHEN @MaxOccuranceSince=7 THEN 
                                case when(@enablehijri=1 and @year<1900)then 
			                    (CASE WHEN dateadd(day,-1,dbo.periodstart(EmpAssignment.PayrollGroup, 1,(dbo.GetDatePart(N'y',@fromdate))+1)) < convert(nchar(10),@fromdate,111) THEN 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,(dbo.GetDatePart(N'y',@fromdate))+1) ELSE 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,(dbo.GetDatePart(N'y',@fromdate))) 
                                     END) else
					         (CASE WHEN dateadd(day,-1,dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1)) < convert(nchar(10),@fromdate,111) THEN 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)+1) ELSE 
                                        dbo.periodstart(EmpAssignment.PayrollGroup,1,year(@fromdate)) 
                                     END)
                                 END
			    WHEN @MaxOccuranceSince=8 THEN SsDate
 end 
from EmpAssignment inner join Profile on EmpAssignment.EmpId = Profile.ProfileId where EmpId=@empid

if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxOccEveryUnit=2 then dbo.h_dateadd(N'MM', @MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dbo.h_dateadd(N'YY',@MaxOccuranceEvery,@date1)
		else dbo.h_dateadd(N'DD',@MaxOccuranceEvery,@date1)end-1
		
		while (@fromdate not between @date1 and @date2)
		begin
			set @date1=@date2+1
			set @date2=case
			when @MaxOccEveryUnit=2 then dbo.h_dateadd(N'MM', @MaxOccuranceEvery,@date1)
			when @MaxOccEveryUnit=3 then dbo.h_dateadd(N'YY',@MaxOccuranceEvery,@date1)
			else dbo.h_dateadd(N'DD',@MaxOccuranceEvery,@date1)end-1
		end
	end
	
else
	begin
--@date2= @date1 + @MaxOccuranceEvery
--@MaxOccEveryUnit : determines whether @MaxOccuranceEvery is day, month or year
--@MaxOccuranceEvery: the parameter at which max Occurance 'll reset
		set @date2=case
		when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
		else dateadd(d,@MaxOccuranceEvery,@date1)end-1
		
		while (@fromdate not between @date1 and @date2)
		begin
		set @date1=@date2+1
		set @date2=case
		when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
		else dateadd(d,@MaxOccuranceEvery,@date1)end-1

		end
	end

--calc how many times the vacation taken by this empployee
SET @MaxOccVacCodestemp=CASE when @MaxOccVacCodes <>'' THEN @MaxOccVacCodes ELSE ','+rtrim(ltrim(str(@vaccode)))+',' end


select @count=count(*) 
 from empvacat e  
where e.vacstatus=1 and e.empid=@empid and @MaxOccVacCodestemp LIKE '%,'+ltrim(rtrim(str(e.vaccode)))+',%' AND e.DocumentNo<>@DocNo
and ((e.fromdate between @date1 and @date2) or 
 (e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
(@date2 between e.fromdate  and e.todate)) AND e.FromDate<=@fromdate
--add the current requested vac to the above count calculated
	IF  charindex(','+ltrim(rtrim(str(@VacCode)))+',',@MaxOccVacCodes )=0 AND @MaxOccVacCodes<>''
    set @count=@count
    else
    set @count=@count+1
--compare the Calculated Count above with Max Occurance allowed


IF (@MaxOccuranceSince=3 OR @MaxOccuranceSince=7) AND (@HireDate BETWEEN @date1 AND @date2) AND (@HireDate<>@date1)
BEGIN
	SELECT @HiringProratedDays=datediff(d,@date1,@HireDate)
END
IF @MaxOccVacAffectDue=1
BEGIN
	select @VacAffectDueDays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
	(e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
	(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
	@date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocNo,@PartDayFrom , @PartDayTo) else 0 end) ,0)
	from empvacat e 
	LEFT JOIN Vacation v ON v.vaccode = e.VacCode
	 where e.vacstatus=1 and e.empid=@empid and (v.vacbalcat=1 OR v.vacbalcat1=1 OR v.vacbalcat2=1) AND e.FromDate<=@fromdate
END

IF @HiringProratedDays<>0 OR @VacAffectDueDays<>0
	SET @proratedMaxOccuranceNo=round((@MaxOccuranceNo/((datediff(d,@date1,@date2)+1)*1.00))*(datediff(d,@date1,@date2)+1-@VacAffectDueDays-@HiringProratedDays),0)
ELSE 
	SET 	@proratedMaxOccuranceNo=@MaxOccuranceNo

--SELECT @date1 ,@date2 ,@count,@HiringProratedDays,@VacAffectDueDays,@proratedMaxOccuranceNo
--,(@MaxOccuranceNo/((datediff(d,@date1,@date2)+1)*1.00))*(datediff(d,@date1,@date2)+1-@VacAffectDueDays-@HiringProratedDays)

if @proratedMaxOccuranceNo<@count 
begin
	--set @reason='008'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max no of occurance' else N'عدد مرات تكرار الاجازة قد تعدى الحد المسموح به ' end)) 
	set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'008'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction','Occurance',@latinlang))),(case when @latinlang=N'E' then N'the vacation will exceed max no of occurance' else N'عدد مرات تكرار الاجازة قد تعدى الحد المسموح به ' end)) 
end

-----------------------------
while  (@todate not between @date1 and @date2 ) 
begin

	set @date1=@date2+1
	if @enablehijri=1 and @year<1900
	begin
		set @date2=case
		when @MaxOccEveryUnit=2 then dbo.h_dateadd('MM', @MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dbo.h_dateadd('YY',@MaxOccuranceEvery,@date1)
		else dbo.h_dateadd('DD',@MaxOccuranceEvery,@date1)end-1

	end
	else
	begin
		set @date2=case
		when @MaxOccEveryUnit=2 then dateadd(m,@MaxOccuranceEvery,@date1)
		when @MaxOccEveryUnit=3 then dateadd(yy,@MaxOccuranceEvery,@date1)
		else dateadd(d,@MaxOccuranceEvery,@date1)end-1
	end
	
set @count=0

SET @MaxOccVacCodestemp=CASE when @MaxOccVacCodes <>'' THEN @MaxOccVacCodes ELSE ','+rtrim(ltrim(str(@vaccode)))+',' end

select @count=count(*) 
 from empvacat e  
where e.vacstatus=1 and e.empid=@empid and @MaxOccVacCodestemp LIKE '%,'+ltrim(rtrim(str(e.vaccode)))+',%' AND e.DocumentNo<>@DocNo
and ((e.fromdate between @date1 and @date2) or 
 (e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
(@date2 between e.fromdate  and e.todate)) AND e.FromDate<=@fromdate

	IF charindex(','+ltrim(rtrim(str(@VacCode)))+',',@MaxOccVacCodes )=0 AND @MaxOccVacCodes<>''
    set @count=@count
    else
    set @count=@count+1

IF @MaxOccVacAffectDue=1
BEGIN
	SET @VacAffectDueDays=0.0

	select @VacAffectDueDays=isnull(sum(case when ((e.fromdate between @date1 and @date2) or 
	(e.todate between @date1 and @date2) or (@date1 between e.fromdate and e.todate) or 
	(@date2 between e.fromdate  and e.todate)) then dbo.vactakendays(e.empid, case when e.fromdate<@date1 then
	@date1 else e.fromdate end,case when e.todate>@date2 then @date2 else e.todate end, e.vaccode,@DocNo,@PartDayFrom , @PartDayTo) else 0 end) ,0)
	from empvacat e 
	LEFT JOIN Vacation v ON v.vaccode = e.VacCode
	 where e.vacstatus=1 and e.empid=@empid and (v.vacbalcat=1 OR v.vacbalcat1=1 OR v.vacbalcat2=1) AND e.FromDate<=@fromdate
END

IF @VacAffectDueDays<>0
	SET @proratedMaxOccuranceNo=round((@MaxOccuranceNo/(datediff(d,@date1,@date2)*1.00))*(datediff(d,@date1,@date2)-@VacAffectDueDays),0)
ELSE
	SET @proratedMaxOccuranceNo=@MaxOccuranceNo

if @proratedMaxOccuranceNo<@count 
begin
--set @reason='009'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('VacationRestriction','Occurance',@latinlang))),(case when @latinlang='E' then 'the vacation will exceed max no of occurance' else N'عدد مرات تكرار الاجازة قد تعدى الحد المسموح به ' end)) 
	set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END+CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
				ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
				CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
				+N'009'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Occurance',@latinlang))),(case when @latinlang=N'E' then N'the vacation will exceed max no of occurance' else N'عدد مرات تكرار الاجازة قد تعدى الحد المسموح به ' end)) 
end

end
-----------------------------

END

IF @VacValidity=1
BEGIN
-- the idea of checking the validity is 
--creating a table with all the validity vac codes and the end of each vacation and the end of the 
--validity period for each vacation
-- then cursor to get all the employee vacations records of the same requested vac code
--then assign each vac to the proper record in the temp table according to the vac date and the vac no of days
---then after finishing the cursor , check the requested vac is valid or not by gettining the proper records from
--the temp table which matched with the requested vac dates and vac requested days no.
DECLARE @tempvac TABLE 
(tempVacCode smallint,tempFromDate smalldatetime,tempToDate smalldatetime
,TempPeriodend smalldatetime,TempNoOFDays  numeric(9,3),Tempvalidvac NVARCHAR(max),Tempvalidvacdays numeric(9,3))

DECLARE @tempvac1 table 
(tempVacCode smallint,tempFromDate smalldatetime,tempToDate smalldatetime
,TempPeriodend smalldatetime,TempNoOFDays  numeric(9,3),Tempvalidvac NVARCHAR(max),Tempvalidvacdays numeric(9,3),validvaccode smallint)

 
 DECLARE @ValidVacDocumentNo int,@ValidVacFromDate smalldatetime,@ValidVacToDate smalldatetime,
 @validvacdays AS numeric(9,3),@tempVacCode smallint,@TempPeriodend smalldatetime,@TempToDate smalldatetime
 , @validvacdaysRemaining AS numeric(9,3),@ValidVacCode AS SMALLINT
 
 DECLARE @i AS nvarchar(max),@validVacTemp as integer
SET @i=N''
set @validVacTemp=0
 	
 	-- filling table @tempvac with all employee vacation records of validity vac codes
INSERT INTO @tempvac1
SELECT EmpVacat.VacCode,FromDate,ToDate,
CASE when VacationPolicy.VacValidityUnit=2 then dateadd(m,VacationPolicy.VacValidityNo,ToDate)
when VacationPolicy.VacValidityUnit=3 then dateadd(yy,VacationPolicy.VacValidityNo,ToDate)
else dateadd(d,VacationPolicy.VacValidityNo,ToDate)end-1  AS Periodend
,abs(dbo.VacTotalTaken(EmpVacat.empid,fromdate,todate,EmpVacat.VacCode)) AS NoOFDays,
CAST(N' ' AS NVARCHAR(max)) AS validvac,0 AS validvacdays,VacationPolicy.vaccode AS validvaccode
 FROM EmpVacat  
 left join empassignment ON empassignment.EmpId = EmpVacat.EmpId 
 left join VacationPolicy on VacationPolicy.VacPack = empassignment.VacPack
WHERE EmpVacat.empid=@empid AND  VacationPolicy.VacValidityVacCodes LIKE N'%,'+ltrim(rtrim(str(EmpVacat.vaccode)))+N',%' 
AND VacationPolicy.VacValidity=1
AND EmpVacat.VacStatus=1
ORDER BY FromDate asc
 
-------------------------------------------
  UPDATE @tempvac1
    SET Tempvalidvac=@i
        ,@i=CASE WHEN @validVacTemp=tempVacCode  THEN case when CHARINDEX(N','+rtrim(ltrim(str(validvaccode)))+N',',@i)=0 then @i+rtrim(ltrim(str(validvaccode)))+N',' else @i END ELSE N','+rtrim(ltrim(str(validvaccode)))+N',' END
      ,@validVacTemp=tempVacCode
      


--select * from #tempvac1
INSERT INTO @tempvac
select tempVacCode,tempFromDate,tempToDate,TempPeriodend, TempNoOFDays,max(Tempvalidvac)  AS Tempvalidvac, Tempvalidvacdays
from @tempvac1
group by tempVacCode,tempFromDate,tempToDate,TempPeriodend, TempNoOFDays, Tempvalidvacdays
ORDER BY tempFromDate asc

--select * from #tempvac

---cursor to get all the employee vacation records of the requested vacation
declare Validvaccursor Cursor for 
SELECT EmpVacat.vaccode,DocumentNo,FromDate,ToDate,dbo.VacTotalTaken(EmpVacat.empid,fromdate,todate,EmpVacat.vaccode) 
FROM EmpVacat 
left join empassignment ON empassignment.EmpId = EmpVacat.EmpId 
 left join VacationPolicy on VacationPolicy.VacPack = empassignment.VacPack
WHERE EmpVacat.empid=@empid AND EmpVacat.VacCode=VacationPolicy.vaccode AND VacationPolicy.VacValidity=1 AND VacStatus=1
AND EmpVacat.DocumentNo <> @DocNo AND FromDate<=@fromdate
ORDER BY FromDate asc

open Validvaccursor 
Fetch next from Validvaccursor
into @ValidVacCode,@ValidVacDocumentNo,@ValidVacFromDate,@ValidVacToDate,@validvacdays
while @@fetch_status =0
BEGIN
-------------------------------------------
	SET @validvacdaysRemaining=@validvacdays
	--- cursor to get matched vacations in the temp table to the current vac in Validvaccursor cursor
	-- and 
	declare TempVacCursor Cursor for 
	SELECT  tempVacCode,TempPeriodend,TempToDate 
		FROM @tempvac WHERE @ValidVacFromDate BETWEEN TempToDate AND TempPeriodend
		AND TempNoOFDays-Tempvalidvacdays <>0 AND Tempvalidvac LIKE N'%,'+RTRIM(ltrim(STR(@ValidVacCode)))+N',%'
		ORDER BY TempToDate ASC
		

	open TempVacCursor 
	Fetch next from TempVacCursor
	into @tempVacCode,@TempPeriodend,@TempToDate
	while @@fetch_status =0
	BEGIN
		--SELECT @validvacdays,@tempVacCode,@TempPeriodend,@TempToDate
		IF @validvacdays <>0
		UPDATE @tempvac
		SET Tempvalidvacdays=CASE WHEN TempNoOFDays-Tempvalidvacdays >=@validvacdays THEN Tempvalidvacdays+@validvacdays
		ELSE TempNoOFDays END 
		,@validvacdaysRemaining=CASE WHEN TempNoOFDays-Tempvalidvacdays >=@validvacdays THEN 0
		ELSE @validvacdays-(TempNoOFDays-Tempvalidvacdays) END 
		WHERE  tempVacCode=@tempVacCode AND @TempPeriodend=TempPeriodend AND @TempToDate=TempToDate
		AND Tempvalidvac LIKE N'%,'+RTRIM(ltrim(STR(@ValidVacCode)))+N',%'

	SET @validvacdays=@validvacdaysRemaining

	FETCH NEXT FROM TempVacCursor 
	INTO @tempVacCode,@TempPeriodend,@TempToDate
	end
	close TempVacCursor 
	DEALLOCATE TempVacCursor
	----------------------------------------
FETCH NEXT FROM Validvaccursor 
INTO @ValidVacCode,@ValidVacDocumentNo,@ValidVacFromDate,@ValidVacToDate,@validvacdays
end
close Validvaccursor 
DEALLOCATE Validvaccursor



DECLARE @TempCount AS int
	SELECT  @TempCount=count(*)
	FROM @tempvac WHERE @FromDate BETWEEN TempToDate AND TempPeriodend
	 AND Tempvalidvac LIKE N'%,'+RTRIM(ltrim(STR(@VacCode)))+N',%'
HAVING sum(TempNoOFDays-Tempvalidvacdays) >=dbo.[VacTakenDays](@empid,@fromdate,@todate,@vaccode,@DocNo,@PartDayFrom , @PartDayTo)


--SELECT dbo.[VacTakenDays](@empid,@fromdate,@todate,@vaccode)
if isnull(@TempCount,0)<= 0
begin
	set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('VacationRestriction','Prevent',@lang))),
	CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
	ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
	CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
	+N'010'+rtrim(ltrim(str(@PolicyAction)))+' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'validity',@latinlang))),(case when @latinlang=N'E' then N'The validity of requesting the vacation is expired ' else N'انتهت صلاحية طلب الاجازة ' end)) 
end
	
	
END

IF @RequestFromValidity=1 AND @wf=0
---@wf paramater 
--called with value=1, from wfaction sp,to avoid the calculation of the restriction fn again(as if there is any delay in the approval process)
--called with value=0 in all the system (Wf or agenda forms)
BEGIN
	DECLARE @getdate AS smalldatetime
	
	select @getdate=ToDate
	FROM dbo.[HitsGetDate]
	
	select @date1=@fromdate
		
	set @date2=case
		when @RequestFromUnit=2 then dateadd(m,@RequestFromNo*-1,@date1)
		when @RequestFromUnit=3 then dateadd(yy,@RequestFromNo*-1,@date1)
		else dateadd(d,@RequestFromNo*-1,@date1)end
				
		IF @getdate>@date2
		BEGIN
			set @reason=@reason+CASE WHEN @reason <>'' THEN '<br>' ELSE '' END + CASE WHEN @PolicyAction = 1 THEN ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption('VacationRestriction','Prevent',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Prevent : ' ELSE N'عدم سماح : ' END ) 
			ELSE ISNULL(LTRIM(RTRIM(dbo.Hits_GetDCCaption(N'VacationRestriction',N'Warning',@lang))),
			CASE WHEN @Lang = N'E' THEN N'Warning : ' ELSE N'تحذير : ' END) end 
			+N'011'+rtrim(ltrim(str(@PolicyAction)))+N' - '+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'VacationRestriction',N'ValidityRequestFrom',@latinlang))),(case when @latinlang=N'E' then N'Invalid to request a vacation before ''Start Date'' .The allowed period is ' else N' غير مسموح بطلب الأجازة قبل "تاريخ البدء" . الفترة المسموحة هى ' end)) 
			+N' '+ltrim(rtrim(str(@RequestFromNo)))+ N' '
			+ case when @RequestFromUnit=2 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'4',@latinlang))),(case when @latinlang=N'E' then N'Months' else N'شهور' end))  
			when @RequestFromUnit=3 then isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType',N'6',@latinlang))),(case when @latinlang=N'E' then N'Years' else N'سنين' end)) 
			else isnull(ltrim(rtrim(dbo.Hits_GetDCCaption(N'DDLPeriodType','2',@latinlang))),(case when @latinlang=N'E' then N'Days' else N'أيام' end))  end 
						
		end
		
END



IF @reason=N''
set @reason=N'001'

RETURN @reason
END

GO

