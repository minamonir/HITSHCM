
--translate entered name from English to Arabic and vise verse according to @Lang
--@Lang='A' translate from Arabic to English
--@Lang='E' translate from English to Arabic 

CREATE  FUNCTION [dbo].[TranslateName](@EnteredExp As nvarchar(40), @Lang As nvarchar(1))
RETURNS nvarchar(40) AS  
BEGIN 
  Declare @ReturnValue nvarchar(40), @TempChar nvarchar(40), @TempWord nvarchar(40), @TempChar2 nvarchar(40)
  Declare @Num1 Int, @Num2 Int
  Set @EnteredExp=RTrim(LTrim(@EnteredExp))
  Set @ReturnValue=N''
  Set @TempChar=N''
  Set @TempWord=N''
  Set @Num1=1
  Set @Num2=1
  If @Lang=N'A'
  Begin
    While @Num1<=Len(@EnteredExp)
    Begin
      Set @TempChar=SubString(@EnteredExp, @Num1, 1)
      Set @Num1=@Num1+1
      If ASCII(@TempChar)=220
      Begin
        --Set @Num1=@Num1+1
        CONTINUE
      End    
      If ASCII(@TempChar)=32
      Begin
        If N''<>RTrim(LTrim(@TempWord))
        Begin
          If (Select Count(*) From datatrans Where AName=@TempWord)<>0
          Begin                 
            Set @ReturnValue= @ReturnValue+N' '+(Select RTrim(LTrim(Min(Name))) From datatrans Where AName=@TempWord) 
            --Set @Num1=@Num1+1
            Set @TempWord=N''
            CONTINUE     
          End
          Else
          Begin
            Set @ReturnValue= @ReturnValue+N' '
            Set @Num2=1
            While @Num2<=Len(@TempWord)
            Begin 
              Set @TempChar2=RTrim(LTrim(SubString(@TempWord, @Num2, 2)))
              If (Select Count(*) From chrtrans Where AChr=@TempChar2)<>0
              Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(Chr))) From chrtrans Where AChr=@TempChar2)
              Else
              Begin
                Set @TempChar2=SubString(@TempWord, @Num2, 1)
                If (Select Count(*) From chrtrans Where AChr=@TempChar2)<>0
                Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(Chr))) From chrtrans Where AChr=@TempChar2)
              End
              Set @Num2=@Num2+1
              CONTINUE
            End  
          End
          Set @TempWord=N''
        End
      End
      Else
      Begin    
        Set @TempWord=@TempWord+@TempChar
        --Set @Num1=@Num1+1       
      End
    End
    If N''<>RTrim(LTrim(@TempWord))
    Begin
      If (Select Count(*) From datatrans Where AName=@TempWord)<>0
      Set @ReturnValue= @ReturnValue+N' '+(Select RTrim(LTrim(Min(Name))) From datatrans Where AName=@TempWord)
      Else
      Begin    
        Set @ReturnValue= @ReturnValue+N' '
        Set @Num2=1
        While @Num2<=Len(@TempWord)
        Begin
          Set @TempChar2=RTrim(LTrim(SubString(@TempWord, @Num2, 2)))
          If (Select Count(*) From chrtrans Where AChr=@TempChar2)<>0
          Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(Chr))) From chrtrans Where AChr=@TempChar2)
          Else
          Begin
            Set @TempChar2=SubString(@TempWord, @Num2, 1)
            If (Select Count(*) From chrtrans Where AChr=@TempChar2)<>0
            Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(Chr))) From chrtrans Where AChr=@TempChar2)
          End
          Set @Num2=@Num2+1
          CONTINUE
        End  
      End
      Set @TempWord=N''
    End
  End
  Else
  Begin
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
    While @Num1<=Len(@EnteredExp)
    Begin
      Set @TempChar=SubString(@EnteredExp, @Num1, 1)
     Set @Num1=@Num1+1
      If ASCII(@TempChar)=32 And (N'AL'<>RTrim(LTrim(Upper(@TempWord))) and N'EL'<>RTrim(LTrim(Upper(@TempWord))))
      Begin
        If N''<>RTrim(LTrim(@TempWord))
        Begin
          If (Select Count(*) From datatrans Where Name=@TempWord)<>0
          Begin
            Set @ReturnValue= @ReturnValue+N' '+(Select RTrim(LTrim(Min(AName))) From datatrans Where Name=@TempWord) 
            --Set @Num1=@Num1+1
            Set @TempWord=N''
            CONTINUE     
          End
          Else
          Begin
            Set @ReturnValue= @ReturnValue+N' '
            Set @Num2=1
            While @Num2<=Len(@TempWord)
            Begin 
              Set @TempChar2=RTrim(LTrim(SubString(@TempWord, @Num2, 2)))
              If (Select Count(*) From chrtrans Where Chr=@TempChar2)<>0
              Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(AChr))) From chrtrans Where Chr=@TempChar2)
              Else
              Begin
                Set @TempChar2=SubString(@TempWord, @Num2, 1)
                If (Select Count(*) From chrtrans Where Chr=@TempChar2)<>0
                Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(AChr))) From chrtrans Where Chr=@TempChar2)
              End
              Set @Num2=@Num2+1
              CONTINUE
            End  
          End
          Set @TempWord=N''
        End
      End
      Else
      begin    
        Set @TempWord=@TempWord+@TempChar
        --Set @Num1=@Num1+1
      End
    End
    If N''<>RTrim(LTrim(@TempWord))
    Begin
      If (Select Count(*) From datatrans Where Name=@TempWord)<>0
      Set @ReturnValue= @ReturnValue+N' '+(Select RTrim(LTrim(Min(AName))) From datatrans Where Name=@TempWord)
      Else
      Begin    
        Set @ReturnValue= @ReturnValue+N' '
        Set @Num2=1
        While @Num2<=Len(@TempWord)
        Begin
          Set @TempChar2=RTrim(LTrim(SubString(@TempWord, @Num2, 2)))
          If (Select Count(*) From chrtrans Where Chr=@TempChar2)<>0
          Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(AChr))) From chrtrans Where Chr=@TempChar2)
          Else
          Begin
            Set @TempChar2=SubString(@TempWord, @Num2, 1)
            If (Select Count(*) From chrtrans Where Chr=@TempChar2)<>0
            Set @ReturnValue= @ReturnValue+(Select RTrim(LTrim(Min(AChr))) From chrtrans Where Chr=@TempChar2)
          End
          Set @Num2=@Num2+1
          CONTINUE
        End  
      End
      Set @TempWord=N''
    End
  End
  --Set @ReturnValue=RTrim(LTrim(@ReturnValue))
  SELECT @ReturnValue= CASE WHEN DB_NAME()='CL000080' AND @Lang=N'E' THEN '' ELSE RTrim(LTrim(@ReturnValue)) END 
  Return @ReturnValue
End

GO

