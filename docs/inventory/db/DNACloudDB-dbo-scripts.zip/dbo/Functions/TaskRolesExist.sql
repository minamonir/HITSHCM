CREATE FUNCTION [dbo].[TaskRolesExist] (@empid int ,@documentno int  ,@UserId AS INT ) RETURNS BIT
AS
BEGIN	
	DECLARE @str1 AS NVARCHAR(MAX)='' ,@roleid AS NVARCHAR(10)  , @taskPrivacy AS SMALLINT =0
	DECLARE @assignedfrom AS INT 
	SELECT @assignedfrom =assignedfrom FROM emptask WHERE empid =@empid AND documentno=@documentno
	DECLARE @Roles TABLE (RoleId NVARCHAR(10))
	IF  @UserId =@assignedfrom return 1
    SELECT @str1 = TaskPrivacyRoles ,@taskPrivacy=TaskPrivacy  FROM emptask WHERE empid =@empid AND documentno=@documentno 
  
   IF @taskPrivacy=1 AND @UserId=@empid RETURN 1
   ELSE IF @taskprivacy=2 AND EXISTS(SELECT DISTINCT roleid
                                 FROM ssgrouprole
                                 LEFT JOIN empassignment ON empassignment.SSGroup = ssgrouprole.SSGroup
                                 WHERE empassignment.empid =@empid AND ssgrouprole.profileid =@UserId ) RETURN 1
  ELSE IF  @taskPrivacy=3
  	  BEGIN
  	  	
  	 INSERT INTO @Roles 	
	select DISTINCT '#'+ltrim(rtrim(str(RoleId)))+'#' FROM ssgrouprole 	
	INNER JOIN empassignment ON empassignment.SSGroup = ssgrouprole.SSGroup
	WHERE empassignment.empid =@empid  AND ssgrouprole.profileid =@UserId
  DECLARE Role_Cursor CURSOR FOR SELECT DISTINCT RoleId FROM @Roles
  OPEN Role_Cursor
  FETCH NEXT FROM Role_Cursor INTO   @roleid
  WHILE @@FETCH_STATUS = 0
  BEGIN
  	IF CHARINDEX(@roleid,@str1)>0 
  	RETURN 1

  FETCH NEXT FROM Role_Cursor INTO   @roleid
  END
  CLOSE Role_Cursor
  DEALLOCATE Role_Cursor
    END 
   RETURN 0
END

GO

