
CREATE FUNCTION [dbo].[GetEmployeeZoneAmount] 
(@ProfileId int, @Grade SMALLINT, @Paycode SMALLINT, @ZoneDate SMALLDATETIME, @AmountType SMALLINT, @Currency SMALLINT)

RETURNS numeric(18,3)
AS
BEGIN
	DECLARE @Amount AS NUMERIC(18,3), @EffectiveDate AS SMALLDATETIME, @ReturnZone AS NCHAR(10)

SELECT @EffectiveDate =DATEADD(dd,1,CONVERT(SMALLDATETIME,CONVERT(NCHAR(10),@ZoneDate,101),101))

SELECT --@Grade=dbo.GetOldValue(empid, 7, @EffectiveDate, hrcurrency),
  @amount=dbo.GetOldValue(empid,CASE WHEN @Paycode=100 THEN 14 ELSE @Paycode+1000 END, @EffectiveDate, hrcurrency)
FROM empassignment WHERE empid=@ProfileId

SELECT @ZoneDate = MAX(startdate) 
FROM GradeZone 
WHERE grade=@grade AND paycode=@Paycode AND startdate<@EffectiveDate

SELECT @ReturnZone=zone 
FROM GradeZone 
INNER JOIN empassignment ON empassignment.empid=@profileid 
WHERE GradeZone.grade=@grade AND GradeZone.paycode=@Paycode AND startdate=@ZoneDate 
AND dbo.convertamount(@amount,empassignment.hrcurrency,ZoneCurrency,DATEADD(dd,-1,@EffectiveDate)) BETWEEN MinAmount AND MaxAmount

--SELECT @ReturnZone,@Amount

IF @ReturnZone IS NULL
BEGIN
  SELECT TOP 1 @ReturnZone=CASE WHEN dbo.convertamount(@amount,empassignment.hrcurrency,ZoneCurrency,DATEADD(dd,-1,@EffectiveDate))< MinAmount THEN zone ELSE NULL END
    FROM GradeZone 
	INNER JOIN empassignment on empassignment.empid=@profileid
    WHERE GradeZone.grade=@grade AND GradeZone.paycode=@Paycode AND startdate=@ZoneDate
    ORDER BY minamount 
	--SELECT @ReturnZone

  IF @ReturnZone IS NULL
  BEGIN
   SELECT TOP 1 @ReturnZone = CASE WHEN dbo.convertamount(@amount,empassignment.hrcurrency,ZoneCurrency,DATEADD(dd,-1,@EffectiveDate))>MaxAmount THEN zone ELSE NULL END
    FROM GradeZone 
	INNER JOIN empassignment on empassignment.empid=@profileid
    WHERE GradeZone.grade=@grade AND GradeZone.paycode=@Paycode AND startdate=@ZoneDate 
    ORDER BY maxamount DESC
	--SELECT @ReturnZone
  END
END

--SELECT @ReturnZone

SELECT @EffectiveDate=convert(smalldatetime,convert(nchar(10),@ZoneDate,101),101)

--SELECT @ZoneDate=MAX(startdate) 
--FROM GradeZone 
--WHERE grade=@grade and paycode=@Paycode and startdate<=@EffectiveDate

if @AmountType=1 SELECT @amount=MIN(dbo.convertamount(MinAmount,ZoneCurrency,@Currency,@EffectiveDate)) 
          FROM GradeZone WHERE GradeZone.grade=@grade AND GradeZone.paycode=@Paycode AND startdate=@ZoneDate AND zone = @ReturnZone
if @AmountType=2 select @amount=MAX(dbo.convertamount(MidAmount,ZoneCurrency,@Currency,@EffectiveDate)) 
          FROM GradeZone WHERE GradeZone.grade=@grade AND GradeZone.paycode=@Paycode AND startdate=@ZoneDate AND zone = @ReturnZone
if @AmountType=3 SELECT @amount=MAX(dbo.convertamount(MaxAmount,ZoneCurrency,@Currency,@EffectiveDate)) 
          FROM GradeZone WHERE GradeZone.grade=@grade AND GradeZone.paycode=@Paycode AND startdate=@ZoneDate AND zone = @ReturnZone

--SELECT @amount
	-- Return the result of the function
	RETURN isnull(@amount,0)
END

GO

