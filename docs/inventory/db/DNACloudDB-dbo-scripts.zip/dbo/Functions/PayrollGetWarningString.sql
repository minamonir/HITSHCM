

CREATE FUNCTION [dbo].[PayrollGetWarningString]
(
	@itemno AS SMALLINT,@Lang AS CHAR(1),@LogonName AS NVARCHAR(80),@PayrollGroup AS SMALLINT
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @str AS NVARCHAR(MAX)='',@MC_Payroll AS NVARCHAR(1)
SET @MC_Payroll= ISNULL((SELECT ConfigValue FROM SysParamConfig WHERE ConfigID ='MC_Payroll'),0)
IF @MC_Payroll ='1' AND @itemno IN (20561,20560)
		BEGIN 
		IF EXISTS(SELECT * FROM dbo.MCMonthlyTransaction
		INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = MCMonthlyTransaction.EmpId
		 WHERE PayrollGroup=@PayrollGroup AND Expired=0 AND DocumentStatus=5 AND enddate IS null )
		 SET @str=ISNULL((SELECT dbo.Hits_GetDCCaptionWzLogon('WP_PayrollCalculation','WarningStr',@Lang,@LogonName)),CASE WHEN LTRIM(RTRIM(LOWER(@Lang)))='a' THEN N'هناك معاملات لم يتخذ قرار بها. وسوف تنتهي صلاحيتها. قم بمراجعتها أولاً أو اضغط على نعم للمتابعة.' ELSE 'There are uncommitted transactions, they will be expired.Revise them first or press yes to continue.' END)
		 ELSE
		 SET @str=ISNULL((SELECT dbo.Hits_GetDCCaptionWzLogon('Common','BatchConfirmMsg',@Lang,@LogonName)), CASE WHEN LTRIM(RTRIM(LOWER(@Lang)))='a' THEN N'هل أنت متأكد ؟' ELSE 'Are you sure ?' END)
		END
		ELSE
        BEGIN
		SET @str=ISNULL((SELECT dbo.Hits_GetDCCaptionWzLogon('Common','BatchConfirmMsg',@Lang,@LogonName) ), CASE WHEN LTRIM(RTRIM(LOWER(@Lang)))='a' THEN N'هل أنت متأكد ؟' ELSE 'Are you sure ?' END)
		END


	RETURN @str

END

GO

