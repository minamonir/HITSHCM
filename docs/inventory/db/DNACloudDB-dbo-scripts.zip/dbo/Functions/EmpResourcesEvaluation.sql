CREATE FUNCTION [dbo].[EmpResourcesEvaluation] (@EmpID int, @DocumentNo int ,@TrainingEval int, @Resource int, @Category int)  
RETURNS numeric(18,3)  AS  
BEGIN
	DECLARE @Score as  numeric(18,3)

		SET @Score =
		(	SELECT  SUM(RatingLevels.LevelPercent)/COUNT(EmpTrainingEvalResources.TrainingEvalItem)
			FROM EmpTrainingEvalResources
				LEFT JOIN TrainingEvalItems ON EmpTrainingEvalResources.TrainingEval = TrainingEvalItems.TrainingEval
					  AND EmpTrainingEvalResources.TrainingEvalItem= TrainingEvalItems.TrainingEvalItem
				LEFT JOIN TrainingEvals ON TrainingEvalItems.TrainingEval = TrainingEvals.TrainingEval
				LEFT JOIN RatingScales ON ISNULL(TrainingEvalItems.RatingScale, TrainingEvals.RatingScale) = RatingScales.RatingScale
				LEFT JOIN RatingLevels ON RatingScales.RatingScale  = RatingLevels.RatingScale 
					  AND RatingLevels.RatingLevel = EmpTrainingEvalResources.RatingLevel	
			WHERE EmpTrainingEvalResources.EmpId = @EmpID AND EmpTrainingEvalResources.DocumentNo =@DocumentNo 
				AND EmpTrainingEvalResources.TrainingEval = @TrainingEval 
				AND EmpTrainingEvalResources.TrainingResource = CASE WHEN @Resource IS NULL THEN  EmpTrainingEvalResources.TrainingResource  ELSE @Resource END 
				AND EmpTrainingEvalResources.ResourceCategory = CASE WHEN @Category IS NULL THEN  EmpTrainingEvalResources.ResourceCategory  ELSE @Category END 
		)


	RETURN  ISNULL(@Score,0)
END

GO

