CREATE        FUNCTION [dbo].[GetWFActionType2OLD]
  (@RoleProfileid int, @DocumentNo int, @Empid int ,  @ssdocno as smallint )
RETURNS  int
as
BEGIN

declare @SSDocType as smallint

select @SSDocType = SSDocType  from SSDocument where ssdocno = @ssdocno

declare @assignmentid as int 
select @assignmentid = 0
if @SSDocType = 6 select @assignmentid = assignmentid from empappraisal  where empid = @empid and documentno = @DocumentNo





declare @roleid as smallint
declare @myorder as smallint
declare @beforeme as smallint
declare @beforemerq as smallint
declare @lastaction as smallint
declare @lastRole as smallint
declare @lastOrder as smallint
declare @lastid as int
declare @expired as smallint
declare @enddate as smalldatetime


DECLARE @Temp TABLE (
	DocumentNo int,
	EmpID int,
	SSDocNo smallint,
	RoleId smallint,
	ApprovalStatus smallint,
	ActionResaon varchar(max) ,
	ApprovalProfileId int,
	ApprovalDate smalldatetime,
	RoleOrder smallint,
	ApprovalRequired bit)
	
INSERT INTO @Temp
SELECT DocumentNo, EmpID, SSDocNo, RoleId, ApprovalStatus, ActionResaon,
       ApprovalProfileId, ApprovalDate, RoleOrder, ApprovalRequired 
FROM WFDocApproval
WHERE EmpID=@Empid AND DocumentNo=@DocumentNo AND  SSDocNo=@ssdocno

declare @GetDate as smalldatetime
select @GetDate=  todate from HitsGetDate

set @roleid=null

IF @SSDocType = 20 
BEGIN
   
	SELECT top 1 @roleid=t.RoleId, @myorder=t.RoleOrder 
	 FROM 
	-- SSGroupRole 	 INNER JOIN 
	 
	 @Temp T
	 -- ON SSGroupRole.RoleId = T.RoleId 
	 --AND T.DocumentNo =@DocumentNo AND T.EmpID = @empid AND T.ssdocno = @ssdocno 
	 --AND  T.Approvalstatus is NULL
  --   INNER JOIN NasUsersUncommitted ON NasUsersUncommitted.Documentno = T.DocumentNo AND NasUsersUncommitted.EmpId = T.EmpID
	 --CROSS JOIN SysParamUserDefaults
	 --LEFT JOIN EmpAssignment ON T.EmpID = EmpAssignment.EmpId 
	 --WHERE   SSGroupRole.SSGroup = case when  EmpAssignment.EmpId is null then SysParamUserDefaults.ssgroup else EmpAssignment.ssgroup end
	 --AND ( (SSGroupRole.ProfileId = @RoleProfileid)	
	 --OR (SSGroupRole.ProfileId in (SELECT  WFDelegate.ProfileId	
		--							FROM WFDelegate 
		--							WHERE (WFDelegate.DelegatedProfileId = @RoleProfileid) 
		--							AND WFDelegate.RoleId = SSGroupRole.RoleId	
		--							AND @GetDate BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo AND (WFDelegate.ssdocno = @ssdocno)))) 
	 WHERE t.ApprovalProfileId=@RoleProfileid
	  order by T.RoleOrder 
 
END

ELSE
IF isnull(@assignmentid,0) = 0 
BEGIN

	SELECT top 1 @roleid=t.RoleId, @myorder=t.RoleOrder 
	 FROM     @Temp T
	 --    SSGroupRole INNER JOIN
	--		   @Temp T ON SSGroupRole.RoleId = T.RoleId AND 
	--(T.DocumentNo =@DocumentNo)   AND (T.EmpID = @empid)  AND 
	--(T.ssdocno = @ssdocno) and  T.Approvalstatus is null
	--INNER JOIN
	--		   EmpAssignment ON T.EmpID = EmpAssignment.EmpId AND SSGroupRole.SSGroup = EmpAssignment.SSGroup
	-- WHERE    ( (SSGroupRole.ProfileId = @RoleProfileid)
	--or (SSGroupRole.ProfileId in (
	--SELECT  WFDelegate.ProfileId
	--FROM         WFDelegate 
	----left outer  JOIN SSGroupRole ON WFDelegate.RoleId = SSGroupRole.RoleId AND WFDelegate.ProfileId = SSGroupRole.ProfileId 
	--WHERE     (WFDelegate.DelegatedProfileId = @RoleProfileid) and WFDelegate.RoleId = SSGroupRole.RoleId
	--AND @GetDate BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo AND (WFDelegate.ssdocno = @ssdocno))) 
	-- ) 
	 WHERE t.ApprovalProfileId=@RoleProfileid and  T.Approvalstatus is null
	  order by T.RoleOrder 
 
	if @roleid is null SELECT top 1 @roleid=T.RoleId, @myorder=T.RoleOrder 
	 FROM      @Temp T
	--    SSGroupRole INNER JOIN
	--		   @Temp T ON SSGroupRole.RoleId = T.RoleId and (SSGroupRole.ProfileId = @RoleProfileid) AND 
	--(T.DocumentNo =@DocumentNo)   AND (T.EmpID = @empid)  AND 
	--(T.ssdocno = @ssdocno) 
	--INNER JOIN
	--		   EmpAssignment ON T.EmpID = EmpAssignment.EmpId AND SSGroupRole.SSGroup = EmpAssignment.SSGroup
  WHERE t.ApprovalProfileId=@RoleProfileid
	  order by T.RoleOrder 



end 

else 

begin

SELECT top 1 @roleid=T.RoleId, @myorder=T.RoleOrder 
 FROM         SSGroupRole INNER JOIN
           @Temp T ON SSGroupRole.RoleId = T.RoleId AND 
(T.DocumentNo =@DocumentNo)   AND (T.EmpID = @empid)  AND 
(T.ssdocno = @ssdocno) and  T.Approvalstatus is null
           INNER JOIN
           appassignment ON T.EmpID = appassignment.EmpId and  
			appassignment.assignmentid = @assignmentid AND SSGroupRole.SSGroup = appassignment.SSGroup
 WHERE    ( (SSGroupRole.ProfileId = @RoleProfileid)
or (SSGroupRole.ProfileId in (
SELECT  WFDelegate.ProfileId
FROM         WFDelegate 
--left outer  JOIN SSGroupRole ON WFDelegate.RoleId = SSGroupRole.RoleId AND WFDelegate.ProfileId = SSGroupRole.ProfileId 
WHERE     (WFDelegate.DelegatedProfileId = @RoleProfileid) and WFDelegate.RoleId = SSGroupRole.RoleId
AND @GetDate BETWEEN WFDelegate.DelegateFrom AND WFDelegate.DelegateTo AND (WFDelegate.ssdocno = @ssdocno))) 
 ) 

  order by T.RoleOrder 
 
if @roleid is null SELECT top 1 @roleid=T.RoleId, @myorder=T.RoleOrder 
 FROM         SSGroupRole INNER JOIN
           @Temp T ON SSGroupRole.RoleId = T.RoleId 
           AND   (SSGroupRole.ProfileId = @RoleProfileid) AND 
(T.DocumentNo =@DocumentNo)   AND (T.EmpID = @empid)  AND 
(T.ssdocno = @ssdocno) 
           INNER JOIN
           appassignment ON T.EmpID = appassignment.EmpId and  
			appassignment.assignmentid = @assignmentid AND SSGroupRole.SSGroup = appassignment.SSGroup
 
  order by T.RoleOrder 


end 






--********New part to check if there is any one have to approve before me and his approval is required  ********

 declare @ApprovalRequiredcount int 
 set @ApprovalRequiredcount=0
 select @ApprovalRequiredcount=count(*) 
 from @Temp t 
 where t.Approvalstatus is null
  and t.ApprovalDate is null
   and (RoleOrder <  @myorder) 
   and t.ApprovalRequired=1
 --************************************
 
 
SELECT    top 1 @beforeme=RoleOrder , @beforemerq = ApprovalRequired
 FROM         @Temp T
 WHERE     (SSDocNo = @SSDocNo)  AND (RoleOrder <  @myorder) ORDER BY T.RoleOrder DESC
 set  @lastOrder = 1
 
 
select  top 1 @lastaction= T.ApprovalStatus ,  @lastRole = T.RoleId ,
  @lastid=T.Approvalstatus  , @lastOrder=T.RoleOrder 
 FROM  @Temp T INNER JOIN
   WFDocument ON T.DocumentNo = WFDocument.DocumentNo AND T.EmpID = WFDocument.EmpID  
    AND T.ssdocno = WFDocument.ssdocno  
 and T.empid =@Empid and T.DocumentNo = @DocumentNo AND (T.ssdocno = @ssdocno)   
  and T.Approvalstatus is not null 
 ORDER BY T.RoleOrder DESC
 
 select  top 1  @expired = WFDocument.Expired ,  @enddate = WFDocument.Enddate 
 FROM  @Temp T INNER JOIN
   WFDocument ON T.DocumentNo = WFDocument.DocumentNo AND T.EmpID = WFDocument.EmpID  
    AND T.ssdocno = WFDocument.ssdocno  
 and T.empid =@Empid and T.DocumentNo = @DocumentNo AND (T.ssdocno = @ssdocno)   
 -- and T.Approvalstatus is not null 
 ORDER BY T.RoleOrder desc

--by sameh on 12/07/2007
--if @myorder is null return -2  
--by sameh on 12/07/2007

--replace (@myorder =1) with (@ApprovalRequiredcount =0)
IF (@myorder IS NULL) RETURN -2

if (@lastOrder = 1) and (@lastaction is null ) and (@ApprovalRequiredcount =0) and @enddate is  null  return 1--0

if (@lastOrder = @beforeme and     @lastaction IS NOT null and @enddate is  null)   return 1--0

IF  (@lastOrder <= @beforeme  and @beforemerq = 0  and @enddate is  null and      @lastaction IS NOT NULL AND (@ApprovalRequiredcount =0) )    return 1--0

if ((@lastOrder <= @beforeme) and ( @enddate is  null))       return 0--2
if (@lastOrder > @myorder or @expired = 1 or  @enddate is not null  ) and @myorder is not null  return -1--2
return -2

END

GO

