
CREATE FUNCTION [GetEmpReturnDate] (@Empid AS INT, @Documentno AS INT)
RETURNS SMALLDATETIME
AS
BEGIN
	
	DECLARE @fromdate AS SMALLDATETIME , @UnpaidDocNo AS INT 
	
	SELECT TOP 1  @UnpaidDocNo = EmpLeaveWizard.UnpaidDocumentno			  
	FROM EmpLeaveWizard
	WHERE  EmpLeaveWizard.EmpId = @empid AND EmpLeaveWizard.DocumentNo = @Documentno
	ORDER BY EmpLeaveWizard.ProcessedDate DESC	


	SELECT @fromdate = EmpVacat.FromDate
	FROM EmpVacat
	LEFT JOIN EmpLeaveWizard ON EmpLeaveWizard.EmpId = EmpVacat.EmpId AND EmpLeaveWizard.UnpaidDocumentno = EmpVacat.DocumentNo 

	WHERE EmpVacat.EmpId = @Empid AND EmpVacat.DocumentNo = @UnpaidDocNo AND EmpVacat.VacStatus = 1 
	
	IF @fromdate IS NULL
	BEGIN
		 SELECT @fromdate = dateadd(day,1,EmpVacat.ToDate)
		 FROM EmpVacat
		 WHERE EmpVacat.EmpId = @Empid AND EmpVacat.DocumentNo = @Documentno AND EmpVacat.VacStatus = 1 
	END
	
	RETURN @fromdate
END

GO

