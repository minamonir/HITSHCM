CREATE FUNCTION [dbo].[Z_GetOverShortTable]
	(@EmpId int,  @FromDate smalldatetime, @ToDate smalldatetime, @ValueType as SMALLINT,
	@OverShort SMALLINT,@HourFactor decimal(9,3),@CalFactor bit,@IgnoreAccumulate BIT,@Paycode SMALLINT,@checkMINMax smallint)
RETURNS @Temptotal TABLE (Empid INT,paycode smallint,OverValue numeric(18,3))
as
BEGIN
DECLARE  @Temp TABLE ( empid INT,EntryDate SMALLDATETIME,paycode smallint,OverValue numeric(18,3)
,overshort smallint,FromHours decimal(9,3),FromTime nvarchar(5))
DECLARE @MinAmountCalc AS NUMERIC(18,3)=0.000,@MaxAmountCalc AS NUMERIC(18,3)=0.000

--@ValueType=1 over, @ValueType=2 short, @ValueType=3 allowance
declare @returnvalue numeric(18,3), @UseTime bit, @FixedHours bit, 
  @PerShiftPart bit, @AccumulateRanges bit, 
  @UsePermissionOver bit,  @UsePermissionShort bit,@HourlyPayroll BIT,@minvalue  NUMERIC(18,3)=0.000,@maxvalue NUMERIC(18,3)=0.000

select @UsePermissionOver=0,  @UsePermissionShort=0

select @UseTime=isnull(UseTime,0), @FixedHours=isnull(FixedHours,0),
  @PerShiftPart=PerShiftPart, @AccumulateRanges=CASE WHEN @ValueType=1 THEN OverAccumulateRanges WHEN @ValueType=2 THEN shortAccumulateRanges ELSE  0 END, @UsePermissionOver=UsePermissionOver,
  @UsePermissionShort=UsePermissionShort,@HourlyPayroll=HourlyPayroll,@minvalue=CASE WHEN @ValueType=1 THEN MinOver WHEN @ValueType=2 THEN MinShort ELSE MinAllow END
  ,@maxvalue=CASE WHEN @ValueType=1 THEN MaxOver WHEN @ValueType=2 THEN MaxShort ELSE MaxAllow  END
  from  EmpAssignment INNER JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
  where EmpAssignment.empid=@EmpId

SET @AccumulateRanges= CASE WHEN @IgnoreAccumulate=1 then 0 else @AccumulateRanges END

set @returnvalue=0
if @UseTime =1
begin

  
    DECLARE @TempOverShort1 TABLE (EmpId int, EntryDate datetime, ShiftNo smallint, 
      HoursIn1 numeric(18,3), HoursOut1 numeric(18,3), 
      HoursIn2 numeric(18,3), HoursOut2 numeric(18,3),
      HoursTotal1 numeric(18,3), HoursTotal2 numeric(18,3),
      ShiftHours numeric(18,3), WorkHours numeric(18,3),
      PHoursIn1 numeric(18,3), PHoursOut1 numeric(18,3), 
      PHoursIn2 numeric(18,3), PHoursOut2 numeric(18,3),
      PHoursTotal1 numeric(18,3), PHoursTotal2 numeric(18,3))
      
      
      
        -------------------------------------------
    
  IF @ValueType=2   -- short time and vacation with fraction less than 1 (ex. 1/2 day  vacation)
  BEGIN
  	
 DECLARE @TempVac TABLE (EmpId int, FromDate datetime, ToDate datetime,ShiftDate DATETIME,VacTaken numeric(18,3) ,TempShiftHours numeric(18,3),VacHours numeric(18,3))
      
       INSERT INTO @TempVac
		SELECT EmpVacat.empid,FromDate,todate,EmpShift.ShiftDate,sum(isnull(dbo.vactakendays(EmpVacat.empid, case when EmpShift.ShiftDate <@FromDate then
		@FromDate else EmpShift.ShiftDate  end,case when EmpShift.ShiftDate >@ToDate then @ToDate else EmpShift.ShiftDate  end, EmpVacat.VacCode,empvacat.DocumentNo,empvacat.PartDayFrom,empvacat.PartDayTo),0)),
		max((datediff(s,dbo.ShiftStartEnd(empshift.empid,shiftdate,1,1),dbo.ShiftStartEnd(empshift.empid,shiftdate,2,1))
		+ isnull(datediff(s,dbo.ShiftStartEnd(empshift.empid,shiftdate,1,2),dbo.ShiftStartEnd(empshift.empid,shiftdate,2,2)),0)
		)/3600.0 ),0
		
		FROM EmpVacat 
		LEFT JOIN Vacation ON  Vacation.vaccode = EmpVacat.VacCode
		inner JOIN EmpShift ON EmpShift.EmpId = EmpVacat.EmpId 
		
		AND (
			(EmpShift.ShiftDate between EmpVacat.FromDate AND  EmpVacat.todate AND (Vacation.DayFactor<1 and Vacation.DayFactor >0 ) )
		or
			(EmpShift.ShiftDate = EmpVacat.FromDate AND EmpVacat.PartDayFrom=1 )
		
		OR  (EmpShift.ShiftDate = EmpVacat.todate AND EmpVacat.PartDayTo=1  )
		
		)
		
		LEFT JOIN TimeShifts ON EmpShift.ShiftNo = TimeShifts.ShiftNo
		
		WHERE (Vacation.UseDayFactor=1 OR Vacation.AcceptPartDayFrom=1 OR Vacation.AcceptPartDayTo=1) AND  EmpVacat.empid=@EmpId AND 
		(EmpVacat.FromDate BETWEEN @FromDate AND @ToDate 
		OR EmpVacat.todate BETWEEN @FromDate AND @ToDate
		OR  @FromDate BETWEEN EmpVacat.FromDate AND EmpVacat.todate
		OR @ToDate BETWEEN EmpVacat.FromDate AND EmpVacat.todate) AND EmpVacat.VacStatus=1	
		AND shiftdate BETWEEN @FromDate AND @ToDate
		GROUP BY EmpVacat.empid,FromDate,todate,EmpShift.ShiftDate
		
		delete from @TempVac where VacTaken >=1 or VacTaken<=0
		
		update @TempVac set VacHours=VacTaken*tempShiftHours 
  	 	
  END
  -------------------------------------------
  
  
   IF @ValueType<>3
  BEGIN
      DECLARE @TempEmpShift TABLE (EmpId int, Shiftdate datetime, ShiftNo SMALLINT)
      
      INSERT INTO @TempEmpShift
      SELECT  EmpId,Shiftdate,ShiftNo
      FROM EmpShift WHERE EmpShift.EmpId=@EmpId AND EmpShift.Shiftdate between @FromDate and @ToDate
      
      
      
    if @PerShiftPart=1 and @FixedHours=0
    begin 
      insert @TempOverShort1
      SELECT TESIO.EmpId, TESIO.EntryDate, TES.ShiftNo, 
        SUM(case when TESIO.ShiftTimeNo=1 then case when @ValueType=1 then TESIO.OverSecondsIn else TESIO.ShortSecondsIn end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=1 then case when @ValueType=1 then TESIO.OverSecondsOut else TESIO.ShortSecondsOut end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=2 then case when @ValueType=1 then TESIO.OverSecondsIn else TESIO.ShortSecondsIn end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=2 then case when @ValueType=1 then TESIO.OverSecondsOut else TESIO.ShortSecondsOut end else 0 end*1.000)/3600, 
        SUM(case when TESIO.ShiftTimeNo<=1 then case when @ValueType=1 then TESIO.OverSeconds else TESIO.ShortSeconds end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=2 then case when @ValueType=1 then TESIO.OverSeconds else TESIO.ShortSeconds end else 0 end*1.000)/3600,
        SUM(TESIO.ShiftSeconds*1.000)/3600, SUM(TESIO.WorkSeconds*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=1 then case when @ValueType=1 then isnull(TESIO.POverSecondsIn,0) else isnull(TESIO.PShortSecondsIn,0) end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=1 then case when @ValueType=1 then isnull(TESIO.POverSecondsOut,0) else isnull(TESIO.PShortSecondsOut,0) end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=2 then case when @ValueType=1 then isnull(TESIO.POverSecondsIn,0) else isnull(TESIO.PShortSecondsIn,0) end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=2 then case when @ValueType=1 then isnull(TESIO.POverSecondsOut,0) else isnull(TESIO.PShortSecondsOut,0) end else 0 end*1.000)/3600, 
        SUM(case when TESIO.ShiftTimeNo<=1 then case when @ValueType=1 then isnull(TESIO.POverSeconds,0) else isnull(TESIO.PShortSeconds,0) end else 0 end*1.000)/3600,
        SUM(case when TESIO.ShiftTimeNo=2 then case when @ValueType=1 then isnull(TESIO.POverSeconds,0) else isnull(TESIO.PShortSeconds,0) end else 0 end*1.000)/3600
      FROM EmpShiftInOut TESIO  
      INNER JOIN  @TempEmpShift TES ON TESIO.empid=TES.EmpId  and TESIO.empid=@EmpId and TESIO.EntryDate between @FromDate and @ToDate
      AND tesio.EntryDate=tes.Shiftdate
     -- WHERE EmpShiftInOut.empid=@EmpId and EmpShiftInOut.EntryDate between @FromDate and @ToDate
      GROUP BY TESIO.EmpId, TESIO.EntryDate, TES.ShiftNo
    end
    else
    begin
      insert @TempOverShort1 
      SELECT TESIO.EmpId, TESIO.EntryDate, TES.ShiftNo,
        SUM(case when @ValueType=1 then TESIO.OverSecondsIn else TESIO.ShortSecondsIn end*1.000)/3600,
        SUM(case when @ValueType=1 then TESIO.OverSecondsOut else TESIO.ShortSecondsOut end*1.000)/3600,
        0,0,
        SUM(case when @ValueType=1 then TESIO.OverSeconds else TESIO.ShortSeconds end*1.000)/3600,
        0,
        SUM(TESIO.ShiftSeconds*1.000)/3600, SUM(TESIO.WorkSeconds*1.000)/3600,
        SUM(case when @ValueType=1 then isnull(TESIO.POverSecondsIn,0) else isnull(TESIO.PShortSecondsIn,0) end*1.000)/3600,
        SUM(case when @ValueType=1 then isnull(TESIO.POverSecondsOut,0) else isnull(TESIO.PShortSecondsOut,0) end*1.000)/3600,
        0,0,
        SUM(case when @ValueType=1 then isnull(TESIO.POverSeconds,0) else isnull(TESIO.PShortSeconds,0) end*1.000)/3600,
        0
      FROM  EmpShiftInOut  TESIO
     INNER JOIN  @TempEmpShift TES ON TESIO.empid=TES.EmpId  and TESIO.empid=@EmpId and TESIO.EntryDate between @FromDate and @ToDate
     AND tesio.EntryDate=tes.Shiftdate
      --WHERE EmpShiftInOut.empid=@EmpId and EmpShiftInOut.EntryDate between @FromDate and @ToDate
      GROUP BY TESIO.EmpId, TESIO.EntryDate ,TES.ShiftNo
    end
    
    if @FixedHours=1
	BEGIN
	IF @ValueType=1 

--	empid INT,EntryDate SMALLDATETIME,shiftno smallint,paycode smallint,OverValue numeric(18,3)
--,overshort smallint,FromHours decimal(9,3),FromTime nvarchar(5)
	INSERT INTO @temp
	SELECT t1.Empid ,t.EntryDate ,t1.paycode ,t1.OverValue 
	,t1.overshort ,t1.FromHours ,t1.FromTime
	FROM @TempOverShort1 t
     LEFT JOIN @TempVac TV ON t.EmpId=TV.EmpId AND t.EntryDate between TV.FromDate AND TV.ToDate AND t.EntryDate=ShiftDate
	 Cross apply dbo.Z_GetOverShortValueTable(@EmpId,ShiftNo, @AccumulateRanges, 0, 0,(WorkHours-ShiftHours), @ValueType,0, 0,case when @UsePermissionOver=0 then (WorkHours-ShiftHours) else (PHoursTotal1+PHoursTotal2) END,0,0,0,0,0,0,isnull(VacHours,0),@OverShort,@HourFactor,@CalFactor,@Paycode) t1
     where (WorkHours<>0  OR @HourlyPayroll=1) and WorkHours>ShiftHours 
	 --ORDER BY t.EntryDate

	 IF @ValueType=2 
	INSERT INTO @temp
	SELECT t1.Empid ,t.EntryDate,t1.paycode ,t1.OverValue
	,t1.overshort ,t1.FromHours ,t1.FromTime
	FROM @TempOverShort1 t
     LEFT JOIN @TempVac TV ON t.EmpId=TV.EmpId AND t.EntryDate between TV.FromDate AND TV.ToDate AND t.EntryDate=ShiftDate
	 Cross apply dbo.Z_GetOverShortValueTable(@EmpId,ShiftNo, @AccumulateRanges, 0, 0,(ShiftHours-WorkHours), @ValueType,0, 0,case when @UsePermissionShort=0 then 0 else (PHoursTotal1+PHoursTotal2) end,0,0,0,0,0,0,isnull(VacHours,0),@OverShort,@HourFactor,@CalFactor,@Paycode) t1
     where (WorkHours<>0  OR @HourlyPayroll=1) and WorkHours<ShiftHours 
	 --ORDER BY t.EntryDate

    end

    else 

	BEGIN
	IF @ValueType=1 
	INSERT INTO @temp
	SELECT t1.Empid ,t.EntryDate,t1.paycode ,t1.OverValue
	,t1.overshort ,t1.FromHours ,t1.FromTime
	FROM @TempOverShort1 t
     LEFT JOIN @TempVac TV ON t.EmpId=TV.EmpId AND t.EntryDate between TV.FromDate AND TV.ToDate AND t.EntryDate=ShiftDate
	 Cross apply dbo.Z_GetOverShortValueTable (@EmpId,ShiftNo, @AccumulateRanges, HoursIn1, HoursOut1, HoursTotal1, @ValueType,
             case when @UsePermissionOver=0 then HoursIn1 else PHoursIn1 end, case when @UsePermissionOver=0 then HoursOut1 else PHoursOut1 end, 
             case when @UsePermissionOver=0 then HoursTotal1 else PHoursTotal1 end,HoursIn2, HoursOut2, HoursTotal2, 
             case when @UsePermissionOver=0 then HoursIn2 else PHoursIn2 end, case when @UsePermissionOver=0 then HoursOut2 else PHoursOut2 end, 
             case when @UsePermissionOver=0 then HoursTotal2 else PHoursTotal2 END,isnull(VacHours,0),@OverShort,@HourFactor,@CalFactor,@Paycode) t1
     where (WorkHours<>0  OR @HourlyPayroll=1) 
	 --ORDER BY t.EntryDate

	 IF @ValueType=2 
	INSERT INTO @temp
	SELECT t1.Empid ,t.EntryDate,t1.paycode ,t1.OverValue
	,t1.overshort ,t1.FromHours ,t1.FromTime
	FROM @TempOverShort1 t
     LEFT JOIN @TempVac TV ON t.EmpId=TV.EmpId AND t.EntryDate between TV.FromDate AND TV.ToDate AND t.EntryDate=ShiftDate
	 Cross apply dbo.Z_GetOverShortValueTable(@EmpId,ShiftNo, @AccumulateRanges, HoursIn1, HoursOut1, HoursTotal1, @ValueType, 
             case when @UsePermissionShort=0 then 0 else PHoursIn1 end, case when @UsePermissionShort=0 then 0 else PHoursOut1 end, 
             case when @UsePermissionShort=0 then 0 else PHoursTotal1 end,HoursIn2, HoursOut2, HoursTotal2, 
             case when @UsePermissionShort=0 then 0 else PHoursIn2 end, case when @UsePermissionShort=0 then 0 else PHoursOut2 end, 
             case when @UsePermissionShort=0 then 0 else PHoursTotal2 END,isnull(VacHours,0),@OverShort,@HourFactor,@CalFactor,@Paycode) t1
     where (WorkHours<>0  OR @HourlyPayroll=1) 
	 --ORDER BY t.EntryDate
    end

  IF @checkMINMax=1
  SELECT @MaxAmountCalc=sum(ISNULL(OverValue,0)) FROM @temp
 ------------------------------------------------------------------------
 
  IF @ValueType IN (1,2) AND (ISNULL(@MaxAmountCalc,0)<@maxvalue OR @checkMINMax=0)
  and exists(select * from empshift
inner join timeshifttimes on empshift.shiftno=timeshifttimes.shiftno
where empid=@Empid and shiftdate between @FromDate and @ToDate and (fromtime<>'00:00' or totime <>'00:00'))
  INSERT INTO @temp
  select *
  from GetOverShortValueTimesTable(@empid,  @FromDate, @ToDate,0, @ValueType ,@OverShort ,@HourFactor ,@CalFactor,@Paycode,0,@UsePermissionOver ,  @UsePermissionShort)t1


     
 end   

  IF @ValueType=3
   BEGIN
   	DECLARE  @AllowanceTemp TABLE ( empid INT,EntryDate SMALLDATETIME,paycode smallint,OverValue numeric(18,3),minvalue  numeric(18,3),InputAmtBasedOnWH BIT,inputamt numeric(18,3))
    INSERT INTO @AllowanceTemp  
    SELECT dbo.EmpShift.EmpId,Shiftdate AS EntryDate,TimeShiftAllowances.paycode,
	 dbo.GetIntersectionPeriod
	(EmpShift.EmpId,shiftdate,0,1,1,TimeShiftAllowances.fromtime,TimeShiftAllowances.totime)/3600.00 
	
	AS OverValue
	,TimeShiftAllowances.MinHours,TimeShiftAllowances.InputAmtBasedOnWH,inputamt
    from EmpShift   
	inner JOIN TimeShiftAllowances ON  TimeShiftAllowances.ShiftNo = EmpShift.shiftno 
    WHERE EmpShift.EmpId=@EmpId AND EmpShift.Shiftdate between @FromDate and @ToDate
    
    INSERT INTO @Temp 
    SELECT empid ,EntryDate ,paycode ,
    case when OverValue>=minvalue then case when InputAmtBasedOnWH=1 THEN  OverValue else inputamt END ELSE 0 end
	,0,0,''
    FROM @AllowanceTemp WHERE OverValue<>0.0
    UNION ALL 
	SELECT @empid, @FromDate,timerules.payallow,
	SUM(allowamnt)  AS allowamnt
	,0,0,''
	FROM dbo.EmpAssignment
	INNER JOIN dbo.TimeRules ON TimeRules.TimeRule = EmpAssignment.TimeRule 
	INNER JOIN ( SELECT EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate,
	SUM(EmpShiftInOut.WorkSeconds*1.000)/3600 AS WorkSeconds , MAX(TimeShifts.allowamnt)  AS allowamnt
	,MAX(CASE WHEN shifttype=5 THEN CASE WHEN dbo.EmpVacOrNot(EmpShiftInOut.empid,EntryDate) NOT IN (1,4) THEN 5 ELSE 0 END ELSE 0 end)  AS ShiftType

	FROM  EmpShiftInOut  INNER JOIN  EmpShift 
	ON EmpShiftInOut.EmpId = EmpShift.EmpId AND EmpShiftInOut.EntryDate = EmpShift.ShiftDate 
	INNER JOIN  TimeShifts ON EmpShift.ShiftNo = TimeShifts.ShiftNo
	WHERE EmpShiftInOut.empid=@EmpId and EmpShiftInOut.EntryDate between @FromDate and @ToDate
	and TimeShifts.allowamnt<>0
	GROUP BY EmpShiftInOut.EmpId, EmpShiftInOut.EntryDate, EmpShift.ShiftNo )AS ShiftAllowance ON ShiftAllowance.EmpId=dbo.EmpAssignment.empid
	WHERE EmpAssignment.empid=@EmpId AND timerules.usetime=1 AND timerules.payallow IS NOT NULL AND (WorkSeconds<>0 OR ShiftType=5)
	GROUP BY timerules.payallow  
    
  --  UNION all
  --  select empassignment.empid,@FromDate, timerules.payallow, 
  --  dbo.GetOverShort(empassignment.EmpId, @FromDate, @ToDate, 3)  
    
  --FROM EmpAssignment 
  --INNER JOIN dbo.TimeRules ON TimeRules.TimeRule = EmpAssignment.TimeRule 
  --AND timerules.usetime=1 AND  empassignment.empid=@EmpId 

    	
  END 
     

IF @checkMINMax=1
begin

SELECT @MinAmountCalc=sum(ISNULL(OverValue,0)) FROM @temp

IF ISNULL(@MinAmountCalc,0)>=@minvalue
BEGIN
 
 
 WITH Emptemp AS  
 (  
 SELECT ROW_NUMBER() OVER(ORDER BY entrydate,overshort,FromHours ,FromTime) AS ROWNUMBER,
 
 * from @temp 

                     
) 

 , EmpPaycodes AS  
 (  
 SELECT Y.EMPID ,y.paycode,y.ROWNUMBER,CAST(SUM(ISNULL(X.OverValue,0))+MIN(y.OverValue) AS NUMERIC(18,3)) AS AcmulatedAmount
 ,MIN(Y.overvalue) AS overvalue

FROM Emptemp Y LEFT JOIN Emptemp X ON X.EMPID=Y.EMPID  
AND  X.ROWNUMBER<Y.ROWNUMBER 
 WHERE Y.paycode IS NOT null
 GROUP BY Y.EMPID,y.paycode,y.ROWNUMBER

                     
) 

INSERT INTO @Temptotal
SELECT EMPID ,paycode,SUM(ISNULL(CASE WHEN AcmulatedAmount<=@maxvalue THEN overvalue ELSE CASE WHEN overvalue-(AcmulatedAmount-@maxvalue) <0 THEN 0 ELSE overvalue-(AcmulatedAmount-@maxvalue) END END,0))
FROM EmpPaycodes
GROUP BY EMPID,paycode
END
END
ELSE
BEGIN

	INSERT INTO @Temptotal
	SELECT EMPID ,paycode,SUM(ISNULL(overvalue,0))
	FROM @temp
	 WHERE paycode IS NOT null
	GROUP BY EMPID,paycode

END
END

return 
END

GO

