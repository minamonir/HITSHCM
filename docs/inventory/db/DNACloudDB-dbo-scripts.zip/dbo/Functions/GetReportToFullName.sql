

CREATE FUNCTION [dbo].[GetReportToFullName] (@EmpId AS int,@Lang AS NCHAR)
RETURNS NVARCHAR(88)
AS
BEGIN

DECLARE @PositionNo AS SMALLINT,@ReportToRole AS SMALLINT = 0 ,@ReportToName AS NVARCHAR(88)
--get employee position no 
SELECT @PositionNo = PositionNo
FROM EmpAssignment
WHERE EmpId = @EmpId

SELECT @ReportToRole = case when isnumeric(configvalue)=0 THEN 0 ELSE configvalue END  
                      FROM sysparamconfig WHERE ConfigID='ReportToRole'

IF @PositionNo IS NULL 
BEGIN
-- if no position for the employee..
-- select 1st role in the ssgroup where wfadmin = true without any order for the roles !
IF @ReportToRole <> 0
BEGIN
DECLARE @RoleProfileID AS int
SET @RoleProfileID = (SELECT TOP 1 SSGroupRole.ProfileId 
                      FROM SSGroupRole 
                      INNER JOIN EmpAssignment ON EmpAssignment.SSGroup = SSGroupRole.SSGroup AND EmpAssignment.EmpId = @EmpId
                      WHERE SSGroupRole.RoleId = @ReportToRole )

SELECT @ReportToName =  case when @Lang  = 'e' then PROFILE.Name
                             ELSE PROFILE.AName END
FROM PROFILE WHERE ProfileId = @RoleProfileID
IF LTRIM(RTRIM(LOWER(@Lang)))='w'
BEGIN
SET @ReportToName=LTRIM(RTRIM(STR(@RoleProfileID)))
END
END

--IF ReportTo Name is null [No ppl returned]-- > should return empty
IF @ReportToName IS NULL
BEGIN
SET @ReportToName = N''
IF LTRIM(RTRIM(LOWER(@Lang)))='w'
BEGIN
SET @ReportToName='0'
END
END                    

END
ELSE
BEGIN
-- If position is not null
DECLARE @PositionParentNo AS SMALLINT
SELECT @PositionParentNo = PositionParent
FROM PositionsStructure 
WHERE PositionNo = @PositionNo
AND VersionNo = 1

set @ReportToName = (SELECT TOP 1 CASE WHEN @Lang = 'e' THEN PROFILE.Name
                                  ELSE PROFILE.AName END
                     FROM EmpAssignment
                     INNER JOIN PROFILE ON ProfileId = EmpAssignment.EmpId 
                     WHERE EmpAssignment.PositionNo = @PositionParentNo AND EmpAssignment.Status = 1)
IF LTRIM(RTRIM(LOWER(@Lang)))='w'
BEGIN
SET @ReportToName=(SELECT TOP 1 LTRIM(RTRIM(STR(ProfileId)))
                     FROM EmpAssignment
                     INNER JOIN PROFILE ON ProfileId = EmpAssignment.EmpId 
                     WHERE EmpAssignment.PositionNo = @PositionParentNo AND EmpAssignment.Status = 1)
END
-- if no ppl returned should return the word [Vacant]
IF @ReportToName IS NULL
BEGIN
SELECT @ReportToName = CASE WHEN @Lang = 'e' THEN 'Vacant' ELSE N'شاغر' END
IF LTRIM(RTRIM(LOWER(@Lang)))='w'
BEGIN
SET @ReportToName='0'
END
END
		
END
	
RETURN @ReportToName
END

GO

