
CREATE   FUNCTION   [dbo].[EmpServiceYears]( @EmpId INT ,
      @RefDate DATE )
 RETURNS NUMERIC(18, 10)
AS
    BEGIN
		  
   --SELECT @EmpId = 2505    ,
   --@RefDate = '2018-09-19',
   --@Type = 2
   DECLARE @Type AS INT
    
   IF EXISTS(SELECT * FROM SysParamConfig WHERE ConfigID='ServiceYearsCalcType' AND ConfigValue IN (1,2,3))
      SELECT @Type =configvalue FROM SysParamConfig WHERE ConfigID='ServiceYearsCalcType' 
   ELSE 
      SELECT @Type=1

DECLARE @Serv_Formula AS NUMERIC(18, 10)= 0 ,
            @Result AS NUMERIC(18, 10)= 0 ,
            @HireDate SMALLDATETIME
           , @TermDate SMALLDATETIME
           , @ContStart SMALLDATETIME
	,  @tmpdate datetime, @years int, @months int, @days int;
		   

			IF ( @Type = 1 )
            BEGIN 
                SELECT  @HireDate = HireDate
                FROM    EmpAssignment
                WHERE   EmpId = @EmpId;
              IF @HireDate <= @RefDate
                        SELECT  @Serv_Formula = DATEDIFF(dd, @HireDate, @RefDate)+1
             SELECT  @Result = @Serv_Formula;	
										
            END
			else if ( @Type = 3 ) ---for blom bank
            BEGIN 
                SELECT  @TermDate = TermDate, @ContStart= ContStart
                FROM    EmpAssignment
                WHERE   EmpId = @EmpId;
              IF @ContStart <= @TermDate
			  begin
                        --SELECT  @Serv_Formula = DATEDIFF(dd, @ContStart, @TermDate )+1
				set @tmpdate = @ContStart

				SET @years = DATEDIFF(yy, @tmpdate, @TermDate) - CASE WHEN (MONTH(@ContStart) > MONTH(@TermDate)) OR (MONTH(@ContStart) = MONTH(@TermDate) AND DAY(@ContStart) > DAY(@TermDate)) THEN 1 ELSE 0 END
				SET @tmpdate = DATEADD(yy, @years, @tmpdate)
				set @months = DATEDIFF(m, @tmpdate, @TermDate) - CASE WHEN DAY(@ContStart) > DAY(@TermDate) THEN 1 ELSE 0 END
				SET @tmpdate = DATEADD(m, @months, @tmpdate)
				SET @days = DATEDIFF(d, @tmpdate, @TermDate)

				select @Serv_Formula= (@years*360) + (@months*30) + @days

          
				END		
				   SELECT  @Result = @Serv_Formula;					
            END 
			ELSE
            BEGIN

                DECLARE @EffectiveDate SMALLDATETIME ,
                    @active AS BIT ,
                    @rownumber AS INT = 1 ,
                    @PrevEffectiveDate SMALLDATETIME , @Curactive INT  ,
                    @i int=0

                DECLARE @Temp TABLE
                    (
                      Empid INT ,
                      EffectiveDate SMALLDATETIME ,
                      Active BIT ,
                      Rownumber INT IDENTITY (1,1)
                    )
                INSERT  INTO @Temp ( empid , EffectiveDate , active  )
                        SELECT distinct EmpStatusDtl.EmpId , EffectiveDate ,CASE WHEN paystatus = 1 THEN 1     ELSE 0 END AS active                         
						FROM  EmpStatusHdr 
						INNER JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = EmpStatusHdr.EmpId AND EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo
						INNER JOIN HrStatus ON NewValue = hrstatus
                        WHERE   EmpStatusHdr.EmpId = @EmpId
						AND EffectiveDate <= @RefDate
						AND FieldNo = 1
						AND DocumentStatus = 1
                        ORDER BY EffectiveDate desc; 

	      IF (SELECT COUNT(*) FROM @Temp)<=1
		   BEGIN
			 SELECT  @HireDate = HireDate
                FROM    EmpAssignment
                WHERE   EmpId = @EmpId;
              IF @HireDate <= @RefDate
                    SELECT  @Serv_Formula = DATEDIFF(dd, @HireDate, @RefDate)+1
	 	   END	

         ELSE 
		  BEGIN 
		  ------------
		   --INSERT  INTO @Temp (  EffectiveDate   )
					--SELECT @RefDate
		 -------------
		   SELECT  @Serv_Formula +=case when b.Active=1 then DATEDIFF(d, b.EffectiveDate, a.EffectiveDate) else 0 END  
		         ,@Serv_Formula +=case when a.Rownumber=1 and a.Active=1 then DATEDIFF(d, a.EffectiveDate,@RefDate) else 0 END
		   FROM    @Temp a JOIN @Temp b ON a.Rownumber = b.Rownumber - 1
		  END 
            SELECT  @Result = @Serv_Formula;	

  --              DECLARE EmpCursor CURSOR
  --              FOR
  --                  SELECT  Empid , EffectiveDate ,Active ,Rownumber FROM    @Temp; 
  --              OPEN EmpCursor;   
  --              FETCH NEXT FROM EmpCursor INTO @EmpId, @EffectiveDate, @active, @rownumber;
  --              WHILE @@FETCH_STATUS = 0
  --              BEGIN				
		--			if @active=1
		--			BEGIN
		--				IF @i=0  SELECT   @Serv_Formula = DATEDIFF(dd, @EffectiveDate ,@RefDate)

		--			ELSE 
		--				SELECT   @Serv_Formula = @Serv_Formula + DATEDIFF(dd ,@EffectiveDate ,@PrevEffectiveDate)
		--			END
		--			SELECT @PrevEffectiveDate = @EffectiveDate ,@i=@i+1
		--			FETCH NEXT FROM EmpCursor INTO @EmpId, @EffectiveDate, @active, @rownumber; 
		--		END; 								
		--	CLOSE EmpCursor;   
		--	DEALLOCATE EmpCursor;

            END;
DECLARE @currentyear AS SMALLINT; 
SELECT  @currentyear = CYear FROM PayrollGroup
        INNER JOIN EmpAssignment ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup AND EmpId = @EmpId; 
IF ( @currentyear < 1900 )
    SELECT @Result= @Result / 360; 
ELSE
    SELECT @Result= @Result / (case when @Type =3 then 360.0 else 365.25 end) ; 


RETURN @Result

END;

GO

