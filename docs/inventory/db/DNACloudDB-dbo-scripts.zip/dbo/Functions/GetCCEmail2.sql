CREATE FUNCTION [dbo].[GetCCEmail2](@ProfileID INT,@Roles NVARCHAR(1000),@AssignmentId INT) RETURNS NVARCHAR(MAX)
AS
BEGIN	

--SELECT dbo.[GetCCEmail](1,'1,2,3')

--@Roles = ''		--> No  Roles ,No CC
--@Roles = '0'		--> All Roles
--@Roles = '1,2,3'	--> RoleID IN (1,2,3)

--@AssignmentId = 0 then Employee else Applicant
IF ISNULL(@Roles,'') = '' RETURN '' 

DECLARE @SSGroup INT

IF @AssignmentId = 0 SELECT @SSGroup = SSGroup FROM EmpAssignment WHERE EmpId=@ProfileID
	   ELSE  SELECT @SSGroup = SSGroup FROM AppAssignment WHERE EmpId=@ProfileID AND AppAssignment.AssignmentId = @AssignmentId

IF @SSGroup IS NULL RETURN ''

DECLARE @CC NVARCHAR(MAX)=''

SELECT @CC=@CC+RTRIM(LTRIM((CASE WHEN [Profile].CompanyEmail<>'' THEN [Profile].CompanyEmail ELSE [Profile].PrivateEmail END))) +';'
FROM SSGroupRole
INNER JOIN [Profile] ON [Profile].ProfileId = SSGroupRole.ProfileId
WHERE SSGroup = @SSGroup
AND RTRIM(LTRIM((CASE WHEN [Profile].CompanyEmail<>'' THEN [Profile].CompanyEmail ELSE [Profile].PrivateEmail END)))<>''
AND(RoleId = CASE WHEN @Roles = '0' THEN RoleId ELSE 0 END 
OR(@Roles = LTRIM(STR(RoleId)) OR @Roles LIKE ''+LTRIM(STR(RoleId))+',%' OR @Roles LIKE  '%,'+LTRIM(STR(RoleId))+'' OR @Roles LIKE '%,'+LTRIM(STR(RoleId))+',%'))
GROUP BY [Profile].CompanyEmail,[Profile].PrivateEmail

RETURN @CC

END

GO

