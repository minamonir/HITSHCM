-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[Hits_ServiceYearsRange]
(
	@EmpId INT ,
      @RefDate SMALLDATETIME
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Result AS NVARCHAR(10) =''

	SELECT @Result=CASE WHEN dbo.EmpServiceYears(@EmpId,@RefDate)*12<6 THEN '..<6M' 
	 WHEN dbo.EmpServiceYears(@EmpId,@RefDate)*12>=6 AND dbo.EmpServiceYears(@EmpId,@RefDate)*12<24 THEN '6M<..<2Y'  
	 WHEN dbo.EmpServiceYears(@EmpId,@RefDate)*12>=24 AND dbo.EmpServiceYears(@EmpId,@RefDate)*12<60 THEN '2Y<..<5Y'
	 WHEN dbo.EmpServiceYears(@EmpId,@RefDate)*12>=60 AND dbo.EmpServiceYears(@EmpId,@RefDate)*12<120 THEN '5Y<..<10Y'
	 WHEN dbo.EmpServiceYears(@EmpId,@RefDate)*12>=120 AND dbo.EmpServiceYears(@EmpId,@RefDate)*12<240 THEN '10Y<..<20Y'
	 WHEN  dbo.EmpServiceYears(@EmpId,@RefDate)*12>240 THEN '..>20Y' END 

	RETURN @Result

END

GO

