


CREATE FUNCTION [dbo].[WebAPI2ColorToHex](@ARGB VARCHAR(MAX))
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	--DECLARE @ARGB VARCHAR(max) = '3381759'


        DECLARE @Octet1 TINYINT
        DECLARE @Octet2 TINYINT
        DECLARE @Octet3 TINYINT
        DECLARE @Octet4 TINYINT
        DECLARE @RestOfColor BIGINT

        SET @Octet1 = @ARGB / 16777216
        SET @RestOfColor = @ARGB - ( @Octet1 * CAST(16777216 AS BIGINT) )
        SET @Octet2 = @RestOfColor / 65536
        SET @RestOfColor = @RestOfColor - ( @Octet2 * 65536 )
        SET @Octet3 = @RestOfColor / 256
        SET @Octet4 = @RestOfColor - ( @Octet3 * 256 )

      
	  RETURN
              
               '#' + RIGHT(sys.fn_varbintohexstr(@Octet4), 2)
                   + RIGHT(sys.fn_varbintohexstr(@Octet3), 2)
                   + RIGHT(sys.fn_varbintohexstr(@Octet2), 2)
                   

END

GO

