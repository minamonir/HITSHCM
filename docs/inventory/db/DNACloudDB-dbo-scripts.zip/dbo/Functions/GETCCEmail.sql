
CREATE FUNCTION [dbo].[GETCCEmail](@ProfileID INT,@Roles NVARCHAR(1000)) RETURNS NVARCHAR(MAX)
AS
BEGIN	
--USE 
--SELECT dbo.[GetCCEmail](1,'1,2,3')

--@Roles = ''		--> No  Roles ,No CC
--@Roles = '0'		--> All Roles
--@Roles = '1,2,3'	--> RoleID IN (1,2,3)

IF ISNULL(@Roles,'') = '' RETURN '' 

DECLARE @SSGroup INT
SELECT @SSGroup = SSGroup FROM EmpAssignment WHERE EmpId=@ProfileID
IF @SSGroup IS NULL RETURN ''

DECLARE @CC NVARCHAR(MAX)
SELECT @CC=''

SELECT @CC=@CC+rtrim(ltrim((CASE WHEN [Profile].CompanyEmail<>'' THEN [Profile].CompanyEmail ELSE [Profile].PrivateEmail END))) +';'
FROM SSGroupRole
LEFT JOIN [Profile] ON [Profile].ProfileId = SSGroupRole.ProfileId
WHERE SSGroup = @SSGroup
AND rtrim(ltrim((CASE WHEN [Profile].CompanyEmail<>'' THEN [Profile].CompanyEmail ELSE [Profile].PrivateEmail END)))<>''
AND( RoleId = CASE WHEN @Roles = '0' THEN RoleId ELSE 0 END 
	OR(@Roles = LTRIM(STR(RoleId)) OR @Roles LIKE ''+LTRIM(STR(RoleId))+',%' OR @Roles LIKE  '%,'+LTRIM(STR(RoleId))+'' OR @Roles LIKE '%,'+LTRIM(STR(RoleId))+',%'))
GROUP BY [Profile].CompanyEmail,[Profile].PrivateEmail

RETURN @CC

END

GO

