

CREATE FUNCTION [dbo].[IOTAPIGetPointOnMapLocation] (@ParentZone INT , @ObjPoints geography   )
RETURNS INT

--@ParentZone : Parent No for zones to search in
--@ObjPoints : point (long,lat) to get 

--Description : to get the most accurate zone that intersects with @ObjPoints point

--if any changes applied on this function you need to apply same changes on :
		-- * IOTEmployeesNotRecNotification
		-- * IOTEmployeesPeriodNoHeartBeating
		-- * GetNearestLocation

AS
BEGIN
	
	 DECLARE @SubLocation VARCHAR(8000) ='', @substr VARCHAR(255) = ',', @start INT=0, @occurrence INT=1 , @PointsCounter INT , @ActualLocation INT --, @ObjPoints NVARCHAR(max)
	 DECLARE @CurIOTDeviceLoc INT
	 DECLARE @SubLocationTemp VARCHAR(8000) =''
	 declare @OldPos as int = 0  ,@oldfound as int = 0
	 declare @lat varchar (max)='' , @long as varchar(max) = ''
	 --get all sub locations
	 DECLARE @temp AS table (ObjExist BIT , DeviceLocation INT ,Area float)
		DECLARE CurGetLocation CURSOR FOR
		    SELECT IOTDeviceLocation , LocationImagePoints 
			FROM dbo.IOTDeviceLocations 
			WHERE ISNULL(LocationImagePoints,'') <> '' 
				AND isnull(IOTDeviceLocationParent,0) = Case When @ParentZone = 0 Then isnull(IOTDeviceLocationParent,0) ELSE @ParentZone END 
			AND IOTGeoLocation = 1
--			AND IOTDeviceLocation in
--(
--187,188,
--100,200    
--,60	
--,1011
--,1012
--,1013
--,1014
--,1021
--,1022
--,1023
--,1024
--,1025
--,1026
--,1027
--,1028
--,1029
--,1030
--,20000
--,2010
--,30000
--,3010
--,3011
--,3012
--,3013
--,3014
--,3015
--,3016
--,3017,30001,30002,40003,7762)
		OPEN CurGetLocation
		FETCH NEXT FROM CurGetLocation INTO @CurIOTDeviceLoc , @SubLocation
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @PointsCounter = LEN(@SubLocation) - LEN(REPLACE(@SubLocation, ',', '')) 
			WHILE	 @PointsCounter > 0
			BEGIN
				SET @occurrence = @PointsCounter
				DECLARE @found INT = @occurrence,@pos INT = @start;
				WHILE 1=1 
				BEGIN
				-- Find the next occurrence
					SET @pos = CHARINDEX(@substr, @SubLocation, @pos);
					 -- The required occurrence found
					IF @found <0
					begin
						set @PointsCounter =0
						BREAK;
					end
					if (@found %2 =1)
					begin
						select @long =  SUBSTRING(@SubLocation ,@OldPos ,(@pos-@OldPos) )
					end
					else
					begin
						select @lat =  SUBSTRING(@SubLocation ,@OldPos ,(case when @pos = 0 then len (@SubLocation) else @pos-@OldPos end) )
						set @SubLocationTemp = @SubLocationTemp + ',' + ltrim(rtrim(@lat)) +'  '+ltrim(rtrim(@long))
						set @lat=''
						set @long=''
					end
				-- Prepare to find another one occurrence
					SET @found = @found - 1;
					SET @pos = @pos + 1;
					set @OldPos = @pos	
				END
				SET @PointsCounter = @PointsCounter -2
				SET  @SubLocation = STUFF(@SubLocation , @pos ,1 ,' ')
			END	
			SET @SubLocationTemp = SUBSTRING (@SubLocationTemp , CHARINDEX(',' , @SubLocationTemp , 0)+1 ,LEN(@SubLocationTemp)) 
			SET @SubLocationTemp = @SubLocationTemp +', '+SUBSTRING(@SubLocationTemp , 0 , CHARINDEX(',' , @SubLocationTemp , 0))
			set @SubLocation = @SubLocationTemp

			DECLARE @polygons table( name varchar(32), shape geometry ) 
			INSERT into @polygons values 
			('Area', geometry::STGeomFromText('POLYGON(('+LTRIM(RTRIM(@SubLocation))+'))', 0))
			DECLARE @GeoPolygons TABLE( name varchar(32), GeoShape GEOGRAPHY ,Area float )

			INSERT INTO @GeoPolygons(name, GeoShape,Area  )
			SELECT 'Area' , shape.MakeValid().STUnion(shape.STStartPoint()).STAsText(),shape.STArea()
			FROM @polygons

			DECLARE @points table( id int identity(1,1),  position GEOGRAPHY ) 
			INSERT into @points values (@ObjPoints)
			--values(geography::STGeomFromText('POINT('+LTRIM(RTRIM(@ObjPoints))+')',4326)) 
			INSERT INTO @temp
			        (DeviceLocation,ObjExist ,Area)
			SELECT @CurIOTDeviceLoc, 1 ,g.Area 
			FROM @points p
			join @GeoPolygons g on p.position.STIntersects(g.GeoShape)=1 and g.name='Area'
			--FROM @points 
			--WHERE position.STIntersects((SELECT GeoShape FROM @GeoPolygons WHERE name='Area'))=1 
			DELETE FROM @points 
			DELETE FROM @polygons
			DELETE FROM @GeoPolygons
			set @SubLocationTemp = ''
		FETCH NEXT FROM CurGetLocation INTO @CurIOTDeviceLoc , @SubLocation
		END
		CLOSE CurGetLocation
		DEALLOCATE CurGetLocation
        SET @CurIOTDeviceLoc = 0
		SELECT TOP 1 @CurIOTDeviceLoc = DeviceLocation FROM @temp WHERE ObjExist = 1 order by Area
		RETURN @CurIOTDeviceLoc

END

GO

