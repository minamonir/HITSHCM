
--This fn  gets the shifts no ,Shift name,shift aname
CREATE FUNCTION [dbo].[hits_getlegendTime] ( @lang as nchar(1))
RETURNS @legendtable TABLE 
	(firstgroup nvarchar(MAX), 
	secondgroup nvarchar(MAX),
	thirdgroup nvarchar(MAX),
	fourthgroup nvarchar(800),
        Shifttype1 nchar(30),
	Shifttype2 nchar(30),
	Shifttype3 nchar(30),
	Shifttype4 nchar(30),
	Shifttype5 nchar(30)
	 )
AS
BEGIN

declare @firstgroup nvarchar(MAX), 
	@secondgroup nvarchar(MAX),
	@thirdgroup nvarchar(MAX),
	@fourthgroup nvarchar(800),
        @Shifttype1 nchar(30),
	@Shifttype2 nchar(30),
	@Shifttype3 nchar(30),
	@Shifttype4 nchar(30),
	@Shifttype5 nchar(30)
	
if @lang = 'A'  declare Shifts cursor for select space(3-len(rtrim(ltrim(ShiftNo)))) + rtrim(ltrim(str(ShiftNo))) + ' : '+ rtrim(substring(ShiftAName,1,30))+space(30-len(rtrim(substring(ShiftAName,1,30)))) +  case when ShiftType = 1 then ' (I)'  when ShiftType = 2 then ' (II)' when ShiftType = 3 then ' (III)'  when  ShiftType =4 then ' (IV)'  else  ' (V)'end as item from TimeShifts 
--if @lang = 'E'  declare Shifts cursor for select ltrim(str(ShiftNo))+ ' : '+ rtrim(ShiftName) +space(30-len(rtrim(ShiftName))) +'['+ltrim(str(TimeShifts.ShiftType))+']' as item from TimeShifts 
if @lang = 'E'  declare Shifts cursor for select space(3-len(rtrim(ltrim(ShiftNo)))) + rtrim(ltrim(str(ShiftNo)))+ ' : '+ rtrim(substring(ShiftName,1,30)) +space(30-len(rtrim(substring(ShiftName,1,30)))) +case when ShiftType = 1 then ' (I)'  when ShiftType = 2 then ' (II)' when ShiftType = 3 then ' (III)'  when  ShiftType =4 then ' (IV)'  else  ' (V)'end as item from TimeShifts 



OPEN Shifts
declare @item nvarchar(MAX)
declare @switch int
set @switch = 1
set @switch = 1
set @firstgroup= ' '
set @secondgroup = ' ' 
set @thirdgroup = ' '
set @fourthgroup = ' ' 
FETCH NEXT FROM Shifts 
INTO @item
WHILE @@FETCH_STATUS = 0
BEGIN
if @switch <= 10
set @firstgroup = @firstgroup +nchar(13)+ @item
if @switch >=11 and @switch <=20
set @secondgroup = @secondgroup +nchar(13)+ @item
if @switch >=21 and @switch <=30
set @thirdgroup = @thirdgroup +nchar(13)+ @item
if @switch >=31
set @fourthgroup = @fourthgroup +nchar(13)+ @item

set @switch = @switch +1

FETCH NEXT FROM Shifts 
INTO @item
end

if @lang  = 'A'   declare Shifttype cursor for 
select adesc as ShiftName from Nasarrays where arrayname='shifttype'
if @lang  = 'E'   declare Shifttype cursor for
select edesc as ShiftName from Nasarrays where arrayname='shifttype'

OPEN Shifttype
set @switch = 1
declare @item2 nchar(30)
FETCH NEXT FROM Shifttype 
INTO @item2
WHILE @@FETCH_STATUS = 0
BEGIN
if @switch = 1
set @Shifttype1 = 'I - ' + @item2
if @switch = 2
set @Shifttype2 = 'II - ' +@item2
if @switch = 3
set @Shifttype3 = 'III - ' +  @item2
if @switch = 4
set @Shifttype4 = 'IV - ' + @item2
if @switch = 5
set @Shifttype5 = 'V - ' + @item2

set @switch = @switch +1

FETCH NEXT FROM Shifttype 
INTO @item2
end

insert into @legendtable values (@firstgroup,@secondgroup,@thirdgroup,@fourthgroup,
	@Shifttype1 ,@Shifttype2 ,@Shifttype3 ,@Shifttype4,@Shifttype5 )	

close Shifts
deallocate Shifts

RETURN 
END

GO

