

-- get the total no of days taken in this vacation (@VacCode) between @fromdate and @todate for this employee (@empid)
CREATE  FUNCTION [dbo].[EmpVacTakenCount]
(@empid int,@fromdate datetime,@todate datetime,@vaccode as int)
RETURNS int
AS
BEGIN
	DECLARE @Count AS int
SELECT @count= count(*)
from EmpVacat 
WHERE EmpVacat.empid=@empid 
AND EmpVacat.vaccode=CASE WHEN @vaccode=0 THEN EmpVacat.vaccode ELSE @vaccode END  
AND EmpVacat.VacStatus=1 
AND ((@fromdate between EmpVacat.FromDate and EmpVacat.ToDate) or
  (@todate between EmpVacat.FromDate and EmpVacat.ToDate) or
  (EmpVacat.FromDate between @fromdate and @todate) or
  (EmpVacat.ToDate between @fromdate and @todate))

RETURN @count 
END

GO

