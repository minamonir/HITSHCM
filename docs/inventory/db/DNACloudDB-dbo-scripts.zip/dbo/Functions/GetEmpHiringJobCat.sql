-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE  FUNCTION [dbo].[GetEmpHiringJobCat] (@empid AS INT,@lang AS NCHAR(1)) RETURNS NCHAR(505)
AS

BEGIN

DECLARE @jobcat AS NCHAR(250),@currentjobcat AS NCHAR(250),@jobcatgrb AS NCHAR(250),@currentjobcatgrb AS NCHAR(250)			
-------------------------------------------------------------------------------------------------------------------------------------------------
SELECT @currentjobcatgrb=case when @lang =N'A' then JobCatGrp.JobCatGrpAName ELSE JobCatGrp.JobCatGrpName END,
@currentjobcat=case when @lang =N'A' then jobcat.JobCatAName ELSE jobcat.JobCatName end
From EmpAssignment t 				
LEFT JOIN jobs ON jobs.job = t.Job
LEFT JOIN jobcat ON jobcat.jobcat = Jobs.jobcat
LEFT JOIN JobCatGrp ON JobCatGrp.JobCatGrp = JobCat.JobCatGrp
where t.empid= @empid
							
SELECT TOP 1 @jobcatgrb=CASE WHEN @lang=N'A' THEN  jcg.JobCatGrpAName ELSE jcg.JobCatGrpName END ,
@jobcat=CASE WHEN @lang=N'A' THEN  jc.JobCatAName ELSE jc.JobCatName END
From EmpAssignment t 
inner JOIN EmpStatusHdr on t.EmpId = EmpStatusHdr.EmpId AND EmpStatusHdr.DocumentStatus=1
inner JOIN EmpStatusDtl on EmpStatusDtl.EmpId = EmpStatusHdr.EmpId 
And EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo and
EmpStatusDtl.FieldNo = 5  
LEFT JOIN Jobs j ON j.job =EmpStatusDtl.NewValue
LEFT JOIN JobCat jc ON jc.jobcat = j.jobcat
LEFT JOIN JobCatGrp jcg ON jcg.JobCatGrp = jc.JobCatGrp
where t.empid= @empid
ORDER BY EmpStatusHdr.EffectiveDate ASC
-------------------------------------------------------------------------------------------------------------------------------------------------

SELECT @jobcatgrb= CASE WHEN @jobcat IS NULL THEN @currentjobcatgrb ELSE @jobcatgrb END ,
@jobcat=ISNULL(@jobcat,@currentjobcat)
							
RETURN LTRIM(RTRIM(@jobcat)) +ISNULL(' - ' +LTRIM(RTRIM(@jobcatgrb)),'')

/*
--For Ambulance Only
DECLARE @GraduateType AS NCHAR(60)

SELECT  @GraduateType=CASE WHEN @lang=N'A' THEN GraduateType.GradTypeAName ELSE GraduateType.GradTypeName END 
FROM [Profile]
INNER JOIN Graduate ON Graduate.Graduate = [Profile].Graduate
INNER JOIN GraduateType ON GraduateType.GradType = Graduate.GradType
where [Profile].ProfileId= @empid


RETURN isnull(@GraduateType,'')
*/
END

GO

