CREATE FUNCTION [dbo].[EmpFirstOrLastWorkDate] (@empid AS INT, @DocNo AS INT, @FirstOrLast AS BIT, @date DATETIME, @PartDay BIT)

RETURNS datetime
AS
--firstorlast parameter: 0 for last day before vacation , 1 for first day after vacation--

--SET @empid = 213638
--SET @DocNo = 0
--SET @FirstOrLast = 1
--SET @date = '2016-11-30 00:00:00'
--SET @PartDay = 0


BEGIN
DECLARE  @vacpack as INT, @holidays INT, @dayoffs INT, @tempdate AS DATETIME, @VacorNot AS INT

IF (@date IS NOT NULL)
BEGIN
	
	SELECT @tempdate = CASE WHEN ((@PartDay=0) AND @FirstOrLast = 0) THEN (@date-1)
	                        WHEN ((@PartDay=0) AND @FirstOrLast = 1) THEN (@date+1) 
							ELSE @date END 
END

ELSE 
BEGIN
SELECT @tempdate = CASE WHEN (Empvacat.PartDayFrom = 0 AND @FirstOrLast = 0) THEN FromDate-1 
						WHEN (Empvacat.PartDayFrom = 1 AND @FirstOrLast = 0) THEN FromDate
						WHEN (Empvacat.PartDayto = 0 AND @FirstOrLast = 1) THEN ToDate+1
				        WHEN (Empvacat.PartDayto = 1 AND @FirstOrLast = 1) THEN ToDate END 
				   FROM EmpVacat 
				   WHERE EmpId=@empid AND DocumentNo=@DocNo
				   --SELECT @tempdate
END
				   
		SET @holidays=-1
		SET @dayoffs=-1
		SET @VacorNot=-1


	WHILE @dayoffs <> 0 or @holidays <> 0 or @VacorNot <> 0
	BEGIN
	
		SET @holidays=0
		SET @dayoffs=0
		SET @VacorNot = 0

		SELECT @vacpack=dbo.GetOldValue(@empid, 19, dateadd(dd,1,@tempdate), NULL)

		SELECT @dayoffs = (CASE WHEN  DATEPART(dw,@tempdate) =  v.doffday1 THEN 1 WHEN DATEPART(dw,@tempdate) = v.doffday2 THEN 1 ELSE 0 END ) 
		FROM vacpack v WHERE v.vacpack = @vacpack AND v.dofftype = 1 
		
		IF @dayoffs = 0
		BEGIN
			SELECT @holidays= 1
			FROM holidays h WHERE h.vacpack = @vacpack AND h.holiday=1 AND h.date = @tempdate
		END
		
		IF  @dayoffs = 0 AND @Holidays = 0
		BEGIN
			SELECT @VacOrNot=(SELECT COUNT(*) FROM Empvacat 
			LEFT JOIN Vacation ON Vacation.vaccode = Empvacat.VacCode
			WHERE (empid=@empid) 
		   AND (@tempdate between convert(smalldatetime,convert(nchar(12),Fromdate),103) and convert(smalldatetime,convert(nchar(12),todate),103))
		   AND vacstatus=1 
		   AND (Vacation.DayFactor>=1 OR Vacation.DayFactor<=0)
		   AND DocumentNo <> @DocNo
		   AND CASE WHEN ((@tempdate = ToDate AND PartDayTo = 1) OR (@tempdate = FromDate AND PartDayFrom = 1)) THEN 0 ELSE 1 END = 1 )

		END
		
		--SELECT @tempdate AS date,@dayoffs AS dayoff,@holidays AS holiday,@VacorNot AS vacornot	

		IF @dayoffs = 0 AND @Holidays = 0 AND @VacorNot = 0 
		BEGIN		
		    SET @tempdate = @tempdate
		END
		ELSE
        BEGIN
  			SET @tempdate =  CASE WHEN (@FirstOrLast = 1) THEN (@tempdate+1) ELSE (@tempdate-1) END
        END
	END
	Return @tempdate
END

GO

