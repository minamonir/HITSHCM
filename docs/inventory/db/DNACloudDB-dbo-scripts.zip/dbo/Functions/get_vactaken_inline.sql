CREATE   FUNCTION [dbo].[get_vactaken_inline]
	(
		@empid INT,
		@startdate DATETIME,
		@enddate DATETIME,
		@vaccat INT
	)
	RETURNS TABLE
	AS
	RETURN
	(
		select 
			DaysTaken = isnull(sum(
				dbo.VacTakenDays(
					@empid,
					 (case when empvacat.FromDate < @startdate then @startdate else empvacat.FromDate end),
					 (case when empvacat.ToDate > @enddate then @enddate else empvacat.ToDate end),
					 empvacat.VacCode, empvacat.DocumentNo,empvacat.PartDayFrom, empvacat.PartDayTo)
						), 0.000)

								 from  empvacat left join vacation on empvacat.vaccode=vacation.vaccode                         
								 INNER JOIN EmpAssignment ON EmpAssignment.EmpId=empvacat.EmpId

		where empvacat.empid=@empid  and empvacat.vacstatus=1
							and (  (empvacat.fromdate between @startdate and @enddate) or 
						   (empvacat.todate between @startdate and @enddate) or 
						   (@startdate between empvacat.fromdate and empvacat.todate)or 
						   (@enddate between empvacat.fromdate and empvacat.todate))
							AND(vacation.vactype = @vaccat ) AND empvacat.FromDate>=hiredate
        
	);

GO

