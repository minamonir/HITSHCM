CREATE          FUNCTION [dbo].[vac_calcdue] (@vac_package int ,@vac_hiredate datetime, @vac_birthdate datetime, @vac_startdate datetime, @vac_duedate datetime , @vacpac_type int ,@vac_empid int )  
RETURNS numeric(10,3)  AS  
BEGIN 

IF EXISTS (SELECT * FROM sysparam WHERE propName='Orascom Development' ) AND EXISTS (SELECT * FROM empassignment WHERE empid =@vac_empid AND payrollgroup IN (80,81))
BEGIN
DECLARE @Experience AS int
SELECT @Experience =dbo.CalcExperience('' ,'','e',@vac_empid,0,5 )
SELECT @vac_hiredate =DATEADD(day, -1 * @Experience,@vac_hiredate)

END 
declare  @vac_due as  numeric(10,3), @EffectiveDate as datetime, @vacpack as SMALLINT, @nextvacpack as SMALLINT

set @vac_due=0

declare @wmonth1 int ,  @wmonth2 int ,  @wmonth3 int , @wmonth4 int ,  @wmonth5 int ,  @wmonth INT
declare @ageyear1 int ,  @ageyear2 int ,  @ageyear3 int , @ageyear4 int ,  @ageyear5 int ,  @ageyear INT
declare @duewm1 numeric(10,3),@duewm2 numeric(10,3),@duewm3 numeric(10,3),@duewm4 numeric(10,3),@duewm5 numeric(10,3)
declare @dueage1 numeric(10,3),@dueage2 numeric(10,3),@dueage3 numeric(10,3),@dueage4 numeric(10,3),@dueage5 numeric(10,3)
    
declare @nextwmonth1 int ,  @nextwmonth2 int ,  @nextwmonth3 int , @nextwmonth4 int ,  @nextwmonth5 int ,  @nextwmonth INT
declare @nextageyear1 int ,  @nextageyear2 int ,  @nextageyear3 int , @nextageyear4 int ,  @nextageyear5 int ,  @nextageyear INT
declare @nextduewm1 numeric(10,3),@nextduewm2 numeric(10,3),@nextduewm3 numeric(10,3),@nextduewm4 numeric(10,3),@nextduewm5 numeric(10,3)
declare @nextdueage1 numeric(10,3),@nextdueage2 numeric(10,3),@nextdueage3 numeric(10,3),@nextdueage4 numeric(10,3),@nextdueage5 numeric(10,3)


if exists(SELECT  EmpStatusHdr.EffectiveDate FROM EmpStatusHdr INNER JOIN EmpStatusDtl 
   ON EmpStatusHdr.EmpId = EmpStatusDtl.EmpId AND EmpStatusHdr.DocumentNo = EmpStatusDtl.DocumentNo
   WHERE (EmpStatusHdr.DocumentStatus = 1) AND (EmpStatusDtl.FieldNo = 19) AND (EmpStatusHdr.EmpId = @vac_empid) and 
   (EmpStatusHdr.EffectiveDate between @vac_startdate and @vac_duedate))
BEGIN
	
  declare empvacpack cursor for SELECT distinct EmpStatusHdr.EffectiveDate FROM EmpStatusHdr INNER JOIN EmpStatusDtl 
    ON EmpStatusHdr.EmpId = EmpStatusDtl.EmpId AND EmpStatusHdr.DocumentNo = EmpStatusDtl.DocumentNo
    WHERE (EmpStatusHdr.DocumentStatus = 1) AND (EmpStatusDtl.FieldNo = 19) AND (EmpStatusHdr.EmpId = @vac_empid) and 
    (EmpStatusHdr.EffectiveDate between @vac_startdate and @vac_duedate)
	AND dbo.GetOldValue(@vac_empid, 19, EffectiveDate, null)<>EmpStatusDtl.NewValue
 
  OPEN empvacpack
  FETCH NEXT FROM empvacpack INTO @EffectiveDate
  WHILE @@FETCH_STATUS = 0
  BEGIN
  	
     select @vacpack=dbo.GetOldValue(@vac_empid, 19, @EffectiveDate, null)
     select @nextvacpack=dbo.GetOldValue(@vac_empid, 19, @EffectiveDate+1, null)
      
		 SELECT  @duewm1=case when @vacpac_type=1 then duewm11 WHEN @vacpac_type=2 THEN duewm21 WHEN @vacpac_type=3 THEN duewm31 END, 
				 @duewm2=case when @vacpac_type=1 then duewm12 WHEN @vacpac_type=2 THEN duewm22 WHEN @vacpac_type=3 THEN duewm32 END ,
				 @duewm3=case when @vacpac_type=1 then duewm13 WHEN @vacpac_type=2 THEN duewm23 WHEN @vacpac_type=3 THEN duewm33 END , 
				 @duewm4=case when @vacpac_type=1 then duewm14 WHEN @vacpac_type=2 THEN duewm24 WHEN @vacpac_type=3 THEN duewm34 END ,
				 @duewm5=case when @vacpac_type=1 then duewm15 WHEN @vacpac_type=2 THEN duewm25 WHEN @vacpac_type=3 THEN duewm35 END  ,
				 						 
				 @dueage1=case when @vacpac_type=1 then dueage11 WHEN @vacpac_type=2 THEN dueage21 WHEN @vacpac_type=3 THEN dueage31 END, 
				 @dueage2=case when @vacpac_type=1 then dueage12 WHEN @vacpac_type=2 THEN dueage22 WHEN @vacpac_type=3 THEN dueage32 END ,
				 @dueage3=case when @vacpac_type=1 then dueage13 WHEN @vacpac_type=2 THEN dueage23 WHEN @vacpac_type=3 THEN dueage33 END , 
				 @dueage4=case when @vacpac_type=1 then dueage14 WHEN @vacpac_type=2 THEN dueage24 WHEN @vacpac_type=3 THEN dueage34 END ,
				 @dueage5=case when @vacpac_type=1 then dueage15 WHEN @vacpac_type=2 THEN dueage25 WHEN @vacpac_type=3 THEN dueage35 END  ,
				 
				 @wmonth1 = wmonth1 ,  @wmonth2 = wmonth2 ,  @wmonth3 = wmonth3 ,  @wmonth4 = wmonth4,  @wmonth5 = wmonth5 ,
				 @ageyear1 = ageyear1 ,  @ageyear2 = ageyear2 ,  @ageyear3 = ageyear3 ,  @ageyear4 = ageyear4,  @ageyear5 = ageyear5   
			FROM  vacpack where vacpack =@vacpack
	
	
	 SELECT  @nextduewm1=case when @vacpac_type=1 then duewm11 WHEN @vacpac_type=2 THEN duewm21 WHEN @vacpac_type=3 THEN duewm31 END, 
				 @nextduewm2=case when @vacpac_type=1 then duewm12 WHEN @vacpac_type=2 THEN duewm22 WHEN @vacpac_type=3 THEN duewm32 END ,
				 @nextduewm3=case when @vacpac_type=1 then duewm13 WHEN @vacpac_type=2 THEN duewm23 WHEN @vacpac_type=3 THEN duewm33 END , 
				 @nextduewm4=case when @vacpac_type=1 then duewm14 WHEN @vacpac_type=2 THEN duewm24 WHEN @vacpac_type=3 THEN duewm34 END ,
				 @nextduewm5=case when @vacpac_type=1 then duewm15 WHEN @vacpac_type=2 THEN duewm25 WHEN @vacpac_type=3 THEN duewm35 END  ,
				 						 
				 @nextdueage1=case when @vacpac_type=1 then dueage11 WHEN @vacpac_type=2 THEN dueage21 WHEN @vacpac_type=3 THEN dueage31 END, 
				 @nextdueage2=case when @vacpac_type=1 then dueage12 WHEN @vacpac_type=2 THEN dueage22 WHEN @vacpac_type=3 THEN dueage32 END ,
				 @nextdueage3=case when @vacpac_type=1 then dueage13 WHEN @vacpac_type=2 THEN dueage23 WHEN @vacpac_type=3 THEN dueage33 END , 
				 @nextdueage4=case when @vacpac_type=1 then dueage14 WHEN @vacpac_type=2 THEN dueage24 WHEN @vacpac_type=3 THEN dueage34 END ,
				 @nextdueage5=case when @vacpac_type=1 then dueage15 WHEN @vacpac_type=2 THEN dueage25 WHEN @vacpac_type=3 THEN dueage35 END  ,
				 
				 @nextwmonth1 = wmonth1 ,  @nextwmonth2 = wmonth2 ,  @nextwmonth3 = wmonth3 ,  @nextwmonth4 = wmonth4,  @nextwmonth5 = wmonth5 ,
				 @nextageyear1 = ageyear1 ,  @nextageyear2 = ageyear2 ,  @nextageyear3 = ageyear3 ,  @nextageyear4 = ageyear4,  @nextageyear5 = ageyear5   
			FROM  vacpack where vacpack =@nextvacpack
			

	 IF NOT( @duewm1=@nextduewm1 and @duewm2=@nextduewm2 and @duewm3=@nextduewm3 and @duewm4=@nextduewm4 and @duewm5=@nextduewm5 and  @dueage1=@nextdueage1 and
			 @dueage2=@nextdueage2 and @dueage3=@nextdueage3 and @dueage4=@nextdueage4 and @dueage5=@nextdueage5   
			 and @wmonth1 = @nextwmonth1  and  @wmonth2 = @nextwmonth2  and  @wmonth3 = @nextwmonth3  and  @wmonth4 = @nextwmonth4 and  @wmonth5 = @nextwmonth5  and
			   @ageyear1 = @nextageyear1  and  @ageyear2 = @nextageyear2  and  @ageyear3 = @nextageyear3  and  @ageyear4 = @nextageyear4 and  @ageyear5 = @nextageyear5 
       
			 )
		     	begin
						select @vac_due=@vac_due+isnull(dbo.vac_calcduePeriod (@vacpack ,@vac_hiredate, @vac_birthdate, @vac_startdate, dateadd(dd,-1,@EffectiveDate) , @vacpac_type,@vac_empid),0)
						select @vac_startdate=@EffectiveDate	
				END
  
     
      
     
     FETCH NEXT FROM empvacpack INTO @EffectiveDate

  end
  CLOSE empvacpack
  DEALLOCATE empvacpack
end

select @vacpack=isnull(dbo.GetOldValue(@vac_empid, 19,@vac_duedate, null),@vac_package)
select @vac_due=@vac_due+isnull(dbo.vac_calcduePeriod (@vacpack ,@vac_hiredate, @vac_birthdate, @vac_startdate, @vac_duedate , @vacpac_type,@vac_empid),0)
return  @vac_due


end

GO

