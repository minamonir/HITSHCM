CREATE FUNCTION [dbo].[Resource_Utilization](@Resource_No int, @Resource_Category int, @From datetime ,@to datetime ,@event int, @actual BIT,@Time_cost BIT,@currency SMALLINT,@confirmed bit)
 RETURNS numeric(18,3) 
AS
BEGIN

	RETURN dbo.Resource_UtilizationValue(@Resource_No,@Resource_Category, @From, @to,@event, @actual, @Time_cost, @currency, @confirmed, -1)
	
END

GO

