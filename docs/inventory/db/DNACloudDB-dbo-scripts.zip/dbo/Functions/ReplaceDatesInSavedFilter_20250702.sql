create FUNCTION [dbo].[ReplaceDatesInSavedFilter_20250702] (
    
    @LogonName NVARCHAR(80), @Lang Nvarchar(1) ,@filterStr NVARCHAR(MAX) , @EnglishLike int 
)
RETURNS NVARCHAR(MAX)
AS

--declare @LogonName NVARCHAR(80) = '1',@filterStr NVARCHAR(MAX)=
--'AND ( EMPASSIGNMENT.HIREDATE Between ''@PayrollYearStartDate'' and ''@PayrollYearEndDate'')',@Lang Nvarchar(1) = 'E' ,@EnglishLike int =1

BEGIN

IF ISNULL(@filterStr,'')<>'' 
BEGIN
	IF @EnglishLike = 1
	BEGIN
		SET @filterStr = REPLACE(@filterStr, '@Today', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@Today', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@Yesterday', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@Yesterday', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthStartDate',[dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarMonthStartDate', @Lang) );
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarYearEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollMonthStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollMonthStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollYearEndDate', @Lang));
		---previous
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousMonthStartDate',[dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarPreviousMonthStartDate', @Lang) );
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarPreviousMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarPreviousYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@CalendarPreviousYearEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollPreviousMonthStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollPreviousMonthStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollPreviousMonthEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollPreviousMonthEndDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollPreviousYearStartDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollPreviousYearStartDate', @Lang));
		SET @filterStr = REPLACE(@filterStr, '@PayrollPreviousYearEndDate', [dbo].[Hits_GetDCCaption]('SavedFiltersDateMap', '@PayrollPreviousYearEndDate', @Lang));

	END
	Else If @EnglishLike = 2 
	Begin
		SET @filterStr = REPLACE(@filterStr, '@Today', FORMAT(GETDATE(), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@Yesterday', FORMAT(DATEADD(day, -1, GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthEndDate', FORMAT(EOMONTH(GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 1, 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 12, 31), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@PayrollMonthStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodStart'')')
 		SET @filterStr = REPLACE(@filterStr, '''@PayrollMonthEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodEnd'')')
		SET @filterStr = REPLACE(@filterStr, '''@PayrollYearStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodYearStart'')')
		SET @filterStr = REPLACE(@filterStr, '''@PayrollYearEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PeriodYearEnd'')')
		---previous
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(DATEADD(MONTH, -1, GETDATE())), MONTH(DATEADD(MONTH, -1, GETDATE())), 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousMonthEndDate', FORMAT(EOMONTH(DATEADD(MONTH, -1, GETDATE())), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 1, 1), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 12, 31), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousMonthStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodStart'')')
 		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousMonthEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodEnd'')')
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousYearStartDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodYearStart'')')
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousYearEndDate''','dbo.GetPGPeriodDates(@PayrollGroup,''PrevPeriodYearEnd'')')

	End 
	ELSE
	BEGIN
		SET @filterStr = REPLACE(@filterStr, '@Today', FORMAT(GETDATE(), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@Yesterday', FORMAT(DATEADD(day, -1, GETDATE()), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@CalendarMonthEndDate', FORMAT(EOMONTH(GETDATE()), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 1, 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@CalendarYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()), 12, 31), 'yyyyMMdd')) ;
		SET @filterStr = REPLACE(@filterStr, '''@PayrollMonthStartDate''', 'PeriodStart');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollMonthEndDate''', 'PeriodEnd');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollYearStartDate''', 'PeriodYearStart');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollYearEndDate''', 'PeriodYearEnd');
		---previous
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousMonthStartDate', FORMAT(DATEFROMPARTS(YEAR(DATEADD(MONTH, -1, GETDATE())), MONTH(DATEADD(MONTH, -1, GETDATE())), 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousMonthEndDate', FORMAT(EOMONTH(DATEADD(MONTH, -1, GETDATE())), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousYearStartDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 1, 1), 'yyyyMMdd') );
		SET @filterStr = REPLACE(@filterStr, '@CalendarPreviousYearEndDate', FORMAT(DATEFROMPARTS(YEAR(GETDATE()) - 1, 12, 31), 'yyyyMMdd'));
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousMonthStartDate''', 'PrevPeriodStart');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousMonthEndDate''', 'PrevPeriodEnd');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousYearStartDate''', 'PrevPeriodYearStart');
		SET @filterStr = REPLACE(@filterStr, '''@PayrollPreviousYearEndDate''', 'PrevPeriodYearEnd');
	END
	END
    return @filterStr
END

GO

