
CREATE FUNCTION [dbo].[EndOfPeriodPerDate](@Payrollgroup SMALLINT , @checkedDate SMALLDATETIME, @Calendar AS CHAR(1),@startorEnd AS smallint )
--@startorEnd =1 periodStart
--@startorEnd =2 periodEnd
--@startorEnd =3 @year@month01
--@startorEnd =4 VacationperiodStart
--@startorEnd =5 VacationperiodEnd 
RETURNS SMALLDATETIME
as
BEGIN
	DECLARE @returndate AS SMALLDATETIME
	DECLARE @noofPeriods AS SMALLINT 
	DECLARE @month AS SMALLINT ,@year AS SMALLINT 
	IF @startorEnd =1 OR @startorEnd =2 OR @startorEnd =3
	   BEGIN 
	     SELECT @NoofPeriods =payrollgroup.NoofPeriods FROM payrollgroup WHERE PayrollGroup=@Payrollgroup
	   END 
	ELSE 
		BEGIN 
			SELECT @NoofPeriods =12
		END 
		
	IF @Calendar='H' SELECT @month =dbo.GetDatePart(N'm',@checkedDate),@year =dbo.GetDatePart(N'y',@checkedDate)
    ELSE SELECT @month = MONTH(@checkedDate),@year =YEAR(@checkedDate)

	WHILE @returndate IS NULL 
	BEGIN
	 IF @startorEnd =1 OR @startorEnd =2 OR @startorEnd =3
	   BEGIN 
		IF dbo.periodend(@Payrollgroup,@month ,@year) <@checkedDate
			SELECT @year =CASE WHEN @month =@NoofPeriods THEN @year+1 ELSE @year END  ,@month=case when @month=@noofPeriods then 1 else @month +1 end   
		ELSE SELECT @returndate = CASE WHEN @startorEnd=1 THEN dbo.periodstart(@Payrollgroup,@month ,@year) WHEN @startorEnd=3 THEN rtrim(ltrim(STR(@year)))+'/'+rtrim(ltrim(STR(@month)))+'/01'  ELSE dbo.periodend(@Payrollgroup,@month ,@year) END 
	
	   END
	 ELSE 
		BEGIN 
			IF dbo.V_periodend(@Payrollgroup,@month ,@year) <@checkedDate
			SELECT @year =CASE WHEN @month =@NoofPeriods THEN @year+1 ELSE @year END  ,@month=case when @month=@noofPeriods then 1 else @month +1 end   
		ELSE SELECT @returndate = CASE WHEN @startorEnd=4 THEN dbo.v_periodstart(@Payrollgroup,@month ,@year)  ELSE dbo.V_periodend(@Payrollgroup,@month ,@year) END 
	
		END
	END 
	RETURN @returndate	
END

GO

