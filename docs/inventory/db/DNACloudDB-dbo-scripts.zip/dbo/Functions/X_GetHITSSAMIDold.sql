CREATE FUNCTION [dbo].[X_GetHITSSAMIDold] (@email NVARCHAR(80),@logonname NVARCHAR(80))
RETURNS NVARCHAR(80)
BEGIN 
 	DECLARE @user NVARCHAR(80)=''
	SELECT @logonname = ISNULL(@logonname,'')
	SELECT  @user = SUBSTRING(@email,1,CHARINDEX('@',@email)-1) WHERE CHARINDEX('@',@email)>1
	
	IF @user = '' RETURN ''
	
	IF EXISTS(SELECT * FROM NasUsers WHERE CHARINDEX('@',NasUsers.LogonName)>1 
			AND SUBSTRING(NasUsers.LogonName,1,CHARINDEX('@',NasUsers.LogonName)-1) = @user 
			AND NasUsers.LogonName=@logonname) 
	RETURN @user
	IF NOT EXISTS(SELECT *  FROM NasUsers WHERE CHARINDEX('@',NasUsers.LogonName)>1 
			AND SUBSTRING(NasUsers.LogonName,1,CHARINDEX('@',NasUsers.LogonName)-1) = @user 
			AND NasUsers.LogonName<>@logonname AND NasUsers.WindowsOnly = 1)
	RETURN @user
	
	RETURN ''
END

GO

