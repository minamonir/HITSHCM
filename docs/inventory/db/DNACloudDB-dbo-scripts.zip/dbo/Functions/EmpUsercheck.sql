CREATE FUNCTION [dbo].[EmpUsercheck] 
(
	 @logonname as nvarchar(80),@empid as int ,@pageitemno as int ,@empidquerystring as int
)
RETURNS INT
as
BEGIN
	DECLARE @Parents AS NVARCHAR(max) = [dbo].[NasOptionsItemparents] (@pageitemno)
	-- Declare the return variable here

	IF  (EXISTS(select * from NasOptions
where  ( @Parents like '%,20010,%'
or(itemprog like '%record%' and itemprog like '%wfmain%' 
 and @Parents like '%,10002,%'
or
 itemprog like '%ssmain%') )and itemno=@pageitemno)) AND @pageitemno<>-1 AND @empid<>-1

BEGIN

	DECLARE @count as int=0

	DECLARE @TempEmpid AS INT,@ApplySSGroup AS int
	SELECT @TempEmpid=empid ,@ApplySSGroup=ApplySSGroups FROM dbo.NasUsers WHERE LogonName=@logonname
	
	if @empidquerystring<>0 and @empidquerystring<>@empid 
	begin
	return 0
	end

IF @ApplySSGroup=0 or @TempEmpid=@empid
BEGIN
select @count=count(distinct UserGroupRights.ItemNo)
    FROM  nasusers
    cross apply dbo.HitsStringSplit( OtherUserGroups+'#'+ltrim(nasusers.UserGroup)+'#','#') t
    inner join UserGroupRights on (UserGroupRights.UserGroup=t.value) and t.value <>'' 
	and itemno=@pageitemno
    WHERE LogonName=@logonname

END
ELSE
BEGIN

  DECLARE @PersonType AS SMALLINT 
	SELECT @PersonType =PersonType FROM dbo.Profile WHERE ProfileId=@empid
IF @Parents like '%,20170,%' OR @PersonType IN (1,2,6)
BEGIN

		select @count= count(*)
	from AppAssignment
	inner join SSGroupRole on SSGroupRole.SSGroup=AppAssignment.SSGroup 
	and AppAssignment.empid=@empid
	inner join NasUsers on LogonName=@logonname
	inner join SSRole on SSRole.RoleId=SSGroupRole.RoleId and NasUsers.EmpId=SSGroupRole.ProfileId
	inner join UserGroupRights on UserGroupRights.UserGroup=SSRole.UserGroup
	and ItemNo=@pageitemno
END
ELSE
	begin
	select @count= count(*)
	from EmpAssignment
	inner join SSGroupRole on SSGroupRole.SSGroup=EmpAssignment.SSGroup 
	and EmpAssignment.empid=@empid
	inner join NasUsers on LogonName=@logonname
	inner join SSRole on SSRole.RoleId=SSGroupRole.RoleId and NasUsers.EmpId=SSGroupRole.ProfileId
	inner join UserGroupRights on UserGroupRights.UserGroup=SSRole.UserGroup
	and ItemNo=@pageitemno
	END 

END 
END

ELSE
BEGIN

SET @count=1

end

	RETURN isnull(@count,0)

END

GO

