Create FUNCTION [dbo].[IsValid](@FieldNo AS SMALLINT , @Value AS SMALLINT,@Date AS smalldatetime)
RETURNS BIT 
AS 
BEGIN
	
	--@FieldNo 5 Jobs
	--         6 Organization
	--         7 Grade
	--         8 Position
	--         9 Location
	DECLARE @IsValid AS BIT 
	
IF @FieldNo=5
 BEGIN
 	if exists(select Job from jobs where job=@value and @Date between isnull(JobFromDate,@Date) and isnull(JobToDate,@Date))
 	SELECT @IsValid=1
 	ELSE
 	SELECT @IsValid=0
 END
 ELSE IF @FieldNo=6
 BEGIN
 	if exists(select Organization from Organization where Organization=@Value and @Date between isnull(OrganizationFromDate,@Date)and isnull(OrganizationToDate,@Date))
 	SELECT @IsValid=1
 	ELSE
 	SELECT @IsValid=0
 END
 ELSE IF @FieldNo=7
 BEGIN
 	if exists(select grade from Grads where grade=@Value AND @Date between isnull(gradeFromDate,@Date) and isnull(gradeToDate,@Date))
 	SELECT @IsValid=1
 	ELSE
 	SELECT @IsValid=0
 END
 ELSE IF @FieldNo=8
 BEGIN
 	IF EXISTS(select PositionNo from Positions where PositionNo=@Value and @Date between isnull(PositionFromDate,@Date) and isnull(PositionToDate,@Date))
    SELECT @IsValid=1
 	ELSE
 	SELECT @IsValid=0                             
 END
 ELSE IF @FieldNo=9
 BEGIN
 	 	IF EXISTS(select LocationNo from Location where LocationNo=@Value and @date between isnull(LocationFromDate,@date) and isnull(LocationToDate,@date))
    SELECT @IsValid=1
 	ELSE
 	SELECT @IsValid=0 
 END
	RETURN @IsValid
END

GO

