
CREATE FUNCTION [dbo].[GetWFTransactionName](@EmpID INT, @DocumentNo INT,@SSDocType SMALLINT,@lang char(1))
RETURNS NVARCHAR(max)
AS
BEGIN
DECLARE @Name NVARCHAR(max)=''
  IF @SSDocType = 1
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN ChngStat.ChgAName ELSE ChngStat.ChgName END
    FROM EmpStatusHdr 
    INNER JOIN ChngStat ON EmpStatusHdr.ChgCode = ChngStat.chgcode
    WHERE EmpStatusHdr.EmpID = @EmpID AND EmpStatusHdr.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 2
  BEGIN
   SELECT @Name = @Name + CASE WHEN @lang = 'A' THEN Mscondct.MiscondAName ELSE Mscondct.MiscondName END + CHAR(13) + CHAR(10)
    FROM EmpMsDtl  
    INNER JOIN Mscondct ON EmpMsDtl.mscode = Mscondct.mscode
    WHERE EmpMsDtl.EmpID = @EmpID AND EmpMsDtl.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 3
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN Vacation.VacationAName ELSE Vacation.vacationname END
    FROM EmpVacat 
    INNER JOIN Vacation ON EmpVacat.VacCode = Vacation.VacCode
    WHERE EmpVacat.EmpID = @EmpID AND EmpVacat.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 5
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN MedicalItems.MedicalItemAName  ELSE MedicalItems.MedicalItemName END
    FROM EmpMedical 
    INNER JOIN MedicalItems ON EmpMedical.MedicalItem = MedicalItems.MedicalItem
    WHERE EmpMedical.EmpID = @EmpID AND EmpMedical.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 6
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN Appraisals.AppraisalAName ELSE Appraisals.AppraisalName END
    FROM EmpAppraisal 
    INNER JOIN Appraisals ON EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo
    WHERE EmpAppraisal.EmpID = @EmpID AND EmpAppraisal.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 7
  BEGIN
   SELECT @Name = CASE WHEN @lang = 'A' THEN ISNULL(BenefitPlans.PlanAname, '') + ' - ' + ISNULL(BenefitOptions.OptionAName, '')  
                  ELSE ISNULL(BenefitPlans.PlanName, '') + ' - ' + ISNULL(BenefitOptions.OptionName, '') END
   FROM EmpBenefit 
   INNER JOIN BenefitPlans ON EmpBenefit.PlanNo = BenefitPlans.PlanNo 
   INNER JOIN BenefitOptions ON EmpBenefit.OptionNo = BenefitOptions.OptionNo 
   WHERE EmpBenefit.EmpID = @EmpID AND EmpBenefit.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 8
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN VacationDue.VacDueAName ELSE VacationDue.VacDueName END 
    FROM EmpVacationDue 
    INNER JOIN VacationDue ON EmpVacationDue.VacDueCode = VacationDue.VacDueCode
    WHERE EmpVacationDue.EmpID = @EmpID AND EmpVacationDue.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 9
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN TrainingEvents.TrainingEventAName ELSE TrainingEvents.TrainingEventName END 
    FROM EmpTraining 
    INNER JOIN TrainingEvents ON EmpTraining.TrainingEvent = TrainingEvents.TrainingEvent
    WHERE EmpTraining.EmpID = @EmpID AND EmpTraining.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 10
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN Objectives.ObjectiveAName ELSE Objectives.ObjectiveName END
    FROM EmpObjectives 
    INNER JOIN Objectives ON EmpObjectives.ObjectiveId = Objectives.ObjectiveId
    WHERE EmpObjectives.EmpID = @EmpID AND EmpObjectives.ObjectiveId = @DocumentNo
  END
  ELSE IF @SSDocType = 11
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN Vacancies.VacancyAname ELSE Vacancies.Vacancyname END
    FROM WFDocument 
    INNER JOIN Vacancies ON WFDocument.DocumentNo = Vacancies.VacancyNo
    WHERE WFDocument.EmpID = @EmpID AND WFDocument.DocumentNo = @DocumentNo;
  END
  ELSE IF @SSDocType = 12
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN TimePermission.PermissionAName ELSE TimePermission.PermissionName END 
    FROM EmpTimePermission 
    INNER JOIN TimePermission ON EmpTimePermission.PermissionNo = TimePermission.PermissionNo
    WHERE EmpTimePermission.EmpID = @EmpID AND EmpTimePermission.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 14
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN Document.DocAName ELSE Document.DocName END 
    FROM EmpDoc 
    INNER JOIN Document ON EmpDoc.docid = Document.docid
    WHERE EmpDoc.EmpID = @EmpID AND EmpDoc.DocumentNo = @DocumentNo 
  END
  ELSE IF @SSDocType = 16
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN HKItems.HKItemAName ELSE HKItems.HKItemName END 
    FROM EmpHKItems 
    INNER JOIN HKItems ON EmpHKItems.HKItem = HKItems.HKItem
    WHERE EmpHKItems.EmpID = @EmpID AND EmpHKItems.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 18
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN Activities.ActivityAName ELSE Activities.ActivityName END 
    FROM EmpActivities 
    INNER JOIN Activities ON EmpActivities.ActivityNo = Activities.ActivityNo
    WHERE EmpActivities.EmpID = @EmpID AND EmpActivities.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 19
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN TrainingEvals.TrainingEvalAName   ELSE TrainingEvals.TrainingEvalName END  
    FROM EmpTrainingEval 
    INNER JOIN TrainingEvals ON EmpTrainingEval.TrainingEval = TrainingEvals.TrainingEval
    WHERE EmpTrainingEval.EmpID = @EmpID AND EmpTrainingEval.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 20
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN UserGroup.UserGroupAName ELSE UserGroup.UserGroupName END    
    FROM NasUsersUncommitted 
    INNER JOIN UserGroup ON NasUsersUncommitted.UserGroup = UserGroup.UserGroup
    WHERE NasUsersUncommitted.EmpID = @EmpID AND NasUsersUncommitted.DocumentNo = @DocumentNo
  END
  ELSE IF @SSDocType = 24
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN HRRequest.HRReqAName ELSE HRRequest.HRReqName END    
    FROM EmpHRRequest 
    INNER JOIN HRRequest ON EmpHRRequest.HRReqCode = HRRequest.HRReqCode
    WHERE EmpHRRequest.EmpID = @EmpID AND EmpHRRequest.DocumentNo = @DocumentNo
  END 
  ELSE IF @SSDocType = 25
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN TaskAName ELSE TaskName END   
    FROM EmpTask 
    WHERE EmpTask.EmpID = @EmpID AND EmpTask.DocumentNo = @DocumentNo
  END  
  ELSE IF @SSDocType = 26
  BEGIN
    SELECT @Name = CASE WHEN @lang = 'A' THEN GeoLocations.GeoLocationAName ELSE GeoLocations.GeoLocationName END   
    FROM EmpTimeReadingsGeoUncommitted 
    INNER JOIN GeoLocations ON EmpTimeReadingsGeoUncommitted.GeoLocation = GeoLocations.GeoLocation
    WHERE EmpTimeReadingsGeoUncommitted.EmpID = @EmpID AND EmpTimeReadingsGeoUncommitted.DocumentNo = @DocumentNo
  END
 RETURN @Name
END

GO

