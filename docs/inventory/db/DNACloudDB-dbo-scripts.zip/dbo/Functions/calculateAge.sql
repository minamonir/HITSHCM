Create function calculateAge()
returns table
as
return(SELECT BirthDate, DATEDIFF(YEAR, BirthDate, GETDATE()) AS AgeYears,
    DATEDIFF(MONTH, BirthDate, GETDATE()) % 12 AS AgeMonths,
    DATEDIFF(DAY, BirthDate, GETDATE()) % 30 AS AgeDays
FROM Profile)

GO

