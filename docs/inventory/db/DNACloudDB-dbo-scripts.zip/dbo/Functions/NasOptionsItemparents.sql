CREATE FUNCTION [dbo].[NasOptionsItemparents](@Itemno SMALLINT)RETURNS NVARCHAR(MAX)
AS
BEGIN
    DECLARE @ItemParent AS SMALLINT, @str AS NVARCHAR(250) = N'',@tempparent AS SMALLINT 
    SELECT @ItemParent = NasOptions.ParentNo
    FROM NasOptions
    WHERE ItemNo = @Itemno
    SELECT @tempparent = @ItemParent
    SET @str = N',' + ISNULL(LTRIM(@ItemParent), '')
	IF NOT EXISTS (SELECT * FROM NasOptions WHERE NasOptions.ItemNo = @tempparent) RETURN @str
    WHILE (@tempparent IS NOT NULL)
    BEGIN
        SELECT @str = @str + N',' + ISNULL(LTRIM(ParentNo), ''), @tempparent = NasOptions.ParentNo
        FROM NasOptions
        WHERE NasOptions.ItemNo = @ItemParent
		IF NOT EXISTS (SELECT * FROM NasOptions WHERE NasOptions.ItemNo = @tempparent) RETURN @str
        SELECT @ItemParent = ISNULL(@tempparent, @ItemParent)
    END
    SET @str = @str + LTRIM(@Itemno) + N','
    RETURN @str
END

GO

