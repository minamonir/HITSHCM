

CREATE      FUNCTION [dbo].[HITS_ActionsPermitted] (@SSDocNo as int , @ApprovalProfileId as int , @EmpId as int, @DocumentNo as int)                                                     
RETURNS nchar(5)  AS  
BEGIN 
declare @return as nchar(5)
/*approve reject change  */
set @return=N'00000'
declare TempDocumentRole cursor  for SELECT     SSDocumentRole.*
FROM SSGroupRole INNER JOIN
     SSDocumentRole ON SSGroupRole.RoleId = SSDocumentRole.RoleId INNER JOIN
     EmpAssignment ON SSGroupRole.SSGroup = EmpAssignment.SSGroup
WHERE     (EmpAssignment.EmpId = @EmpId)  and ssdocno=@SSDocNo
ORDER BY SSDocumentRole.RoleOrder
/*AND (SSGroupRole.ProfileId = @ApprovalProfileId)*/
OPEN TempDocumentRole
/*FETCH NEXT FROM TempDocumentRole INTO @holidaysdate*/
deallocate TempDocumentRole
return @return

END

GO

