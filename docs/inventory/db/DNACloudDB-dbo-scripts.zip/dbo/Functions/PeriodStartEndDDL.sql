CREATE  FUNCTION [dbo].[PeriodStartEndDDL] (@empid AS INT ,@selectedindex AS SMALLINT ,@StartorEnd AS SMALLINT,@UserLogonName AS NVARCHAR(80),@Pageitemno AS INT)
RETURNS SMALLDATETIME 
AS 
BEGIN
	
	--@selectedIndex=0 0r -1 current year
	--@selectedIndex=1 current month
	--@selectedIndex=2 previous month
	--@selectedIndex=3 previous year
	
	--@startorend=1 periodstart
	--@Startorend=2 periodend

DECLARE @payrollgroup AS INT,@month AS SMALLINT,@year AS SMALLINT,@Date AS SMALLDATETIME
	
SELECT @payrollgroup=isnull(EmpAssignment.PayrollGroup,-1),@month=ISNULL(CMonth,DATEPART(month,GETDATE())),@year=ISNULL(Cyear,DATEPART(year,GETDATE())) 
FROM EmpAssignment
LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup 
WHERE EmpId=@empid

 If @selectedindex = 0 Or @selectedindex = -1 --current year
 BEGIN
 	select   @Date = case when @StartorEnd=1 THEN CASE  WHEN @Pageitemno IN ( 20130 ,32352) THEN dbo.V_YearStart(@payrollgroup,@month,@year)  ELSE dbo.periodstart(@payrollgroup, 1, @year)  END  
	                       ELSE CASE WHEN @Pageitemno IN ( 20130 ,32352)  THEN dbo.V_YearEnd(@payrollgroup,@month,@year)  ELSE  DATEADD(DAY,-1,dbo.periodstart(@payrollgroup, 1, @year+1)) END   END --dbo.periodend(@payrollgroup, 12, @year)
 END
ELSE IF @SelectedIndex = 1 --current month
BEGIN
	SELECT @Date = case when @StartorEnd =1 then CASE WHEN @Pageitemno IN ( 20130 ,32352) THEN dbo.V_periodstart(@payrollgroup, @month, @year) ELSE  dbo.periodstart(@payrollgroup, @month, @year) END   
	                     ELSE  CASE WHEN @Pageitemno IN ( 20130 ,32352)  THEN dbo.V_periodend(@payrollgroup, @month, @year) ELSE  dbo.periodend(@payrollgroup, @month, @year) END  end
END
ELSE IF @selectedindex=2 --previous month
BEGIN
	DECLARE @prvmonth AS SMALLINT, @prvyear AS SMALLINT 
	IF @month = 1 
	BEGIN
		select @prvmonth=12, @prvyear=@year-1
	END 
	ELSE
		BEGIN
			select @prvmonth=@month-1,@prvyear=@year
		END
 SELECT @Date = case when @StartorEnd =1 THEN  CASE WHEN @Pageitemno IN ( 20130 ,32352) THEN  dbo.V_periodstart(@payrollgroup, @prvmonth, @prvyear) ELSE dbo.periodstart(@payrollgroup, @prvmonth, @prvyear) END  
                      else CASE WHEN  @Pageitemno IN ( 20130 ,32352) THEN dbo.V_periodend(@payrollgroup, @prvmonth, @prvyear)  ELSE dbo.periodend(@payrollgroup, @prvmonth, @prvyear) END  end
END
ELSE IF @selectedindex=3 ---previous year
BEGIN
	select @Date = CASE WHEN @StartorEnd=1 THEN CASE WHEN @Pageitemno IN ( 20130 ,32352) THEN dbo.V_YearStart(@payrollgroup,@month,@year -1) ELSE dbo.periodstart(@payrollgroup, 1, @year - 1) END  
	                     ELSE CASE WHEN @Pageitemno IN ( 20130 ,32352) THEN dbo.V_YearEnd(@payrollgroup,@month,@year -1) ELSE  DATEADD(DAY,-1,dbo.periodstart(@payrollgroup, 1, @year)) END  end --dbo.periodend(@payrollgroup,12,@year-1)
END


RETURN  isnull(@Date,CONVERT( NVARCHAR(10), GETDATE (),111))

END

GO

