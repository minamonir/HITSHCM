CREATE FUNCTION [dbo].[VacDueCase] (@empid int, @date2 datetime, @vacdue as int) 
RETURNS numeric(18,3)
AS
BEGIN
  Declare @MyValue numeric(18,3)
  
  Select @MyValue=Case When dbo.v_periodstart(EmpAssignment.PayrollGroup, PayrollGroup.CMonth, PayrollGroup.CYear) > @date2 
  Then -1*dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate, @date2+1, 
    dbo.v_periodstart(EmpAssignment.PayrollGroup, PayrollGroup.CMonth, PayrollGroup.CYear)-1, @vacdue, EmpAssignment.EmpId) 
  Else dbo.vac_calcdue(EmpAssignment.VacPack, EmpAssignment.HireDate, Profile.BirthDate, 
    dbo.v_periodstart(EmpAssignment.PayrollGroup, PayrollGroup.CMonth,PayrollGroup.CYear), @date2, @vacdue, EmpAssignment.EmpId) End 
  From EmpAssignment Left Join Profile On EmpAssignment.EmpId=Profile.ProfileId Inner Join PayrollGroup On EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup
  Where EmpAssignment.EmpId=@empid
  RETURN @MyValue
END

GO

