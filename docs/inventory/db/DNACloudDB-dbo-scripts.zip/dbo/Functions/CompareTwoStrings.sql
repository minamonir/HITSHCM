CREATE   Function [dbo].[CompareTwoStrings]( @Str1 NVARCHAR(50) , @Str2 NVARCHAR(50) )
Returns smallint 
Begin
    
	--------return 1 if str1>str2 ---return 2 if str1=str2 else return 0
	SET @Str1 =LTRIM(RTRIM(@Str1))
	SET @Str2 =lTRIM(RTRIM(@Str2))
	 -- Replace [ا or آ]  to  'أ' 
    WHILE PATINDEX( N'%[إاآ]%', @Str1) > 0 
           BEGIN
              SET @Str1 =REPLACE( @Str1, SUBSTRING( @Str1, PATINDEX( N'%[إاآ]%', @Str1 ), 1 ),N'أ')
           END

		 -- Replace 'ى'  to  'ي' 
    WHILE PATINDEX( N'%[ى]%', @Str1) > 0 
           BEGIN
              SET @Str1 =REPLACE( @Str1, SUBSTRING( @Str1, PATINDEX( N'%[ى]%', @Str1 ), 1 ),N'ي')
           END

		  -- Replace 'ؤ'  to  'و' 
    WHILE PATINDEX( N'%[ؤ]%', @Str1) > 0 
           BEGIN
              SET @Str1 =REPLACE( @Str1, SUBSTRING( @Str1, PATINDEX( N'%[ؤ]%', @Str1 ), 1 ),N'و')
           END
		   	   	 -- Replace 'ئ'  to  'ء' 
    WHILE PATINDEX( N'%[ئ]%', @Str1) > 0 
           BEGIN
              SET @Str1 =REPLACE( @Str1, SUBSTRING( @Str1, PATINDEX( N'%[ئ]%', @Str1 ), 1 ),N'ء')
           END
---------------------------------------------
	 -- Replace [ا or آ]  to  'أ' 
    WHILE PATINDEX( N'%[إاآ]%', @Str2) > 0 
           BEGIN
              SET @Str2 =REPLACE( @Str2, SUBSTRING( @Str2, PATINDEX( N'%[إاآ]%', @Str2 ), 1 ),N'أ')
           END
     -- SELECT @Str1

		    -- Replace 'ى'  to  'ي' 
    WHILE PATINDEX( N'%[ى]%', @Str2) > 0 
           BEGIN
              SET @Str2 =REPLACE( @Str2, SUBSTRING( @Str2, PATINDEX( N'%[ى]%', @Str2 ), 1 ),N'ي')
           END
		    -- Replace 'ؤ'  to  'و' 
    WHILE PATINDEX( N'%[ؤ]%', @Str2) > 0 
           BEGIN
              SET @Str2 =REPLACE( @Str2, SUBSTRING( @Str2, PATINDEX( N'%[ؤ]%', @Str2 ), 1 ),N'و')
           END
    	   	 -- Replace 'ئ'  to  'ء' 
    WHILE PATINDEX( N'%[ئ]%', @Str2) > 0 
           BEGIN
              SET @Str2 =REPLACE( @Str2, SUBSTRING( @Str2, PATINDEX( N'%[ئ]%', @Str2 ), 1 ),N'ء')
           END
		 
  ---------------------------------------------------------------------------------
    DECLARE @NumericStr1 NVARCHAR(400) = @Str1
    DECLARE @strStr1 NVARCHAR(400)

    DECLARE @NumericStr2 NVARCHAR(400) = @Str2
    DECLARE @strStr2 NVARCHAR(400)

	--DECLARE @expresAhpha  NVARCHAR(50) = '%[a-z .,;:\-@\@.''"?:/,+&();_-]%'
	DECLARE @expresAhpha  NVARCHAR(50) =  N'%[ء-يa-z .,;:\-@\@.''"?:/,+&();_]%'

    -- Getting numbers and chars from Parameter(@Str1) 
    WHILE PATINDEX( @expresAhpha, @NumericStr1) > 0 
           BEGIN
               SET @NumericStr1 =REPLACE( @NumericStr1, SUBSTRING( @NumericStr1, PATINDEX( @expresAhpha, @NumericStr1 ), 1 ),'')
           END

		 set  @strStr1= Replace(@Str1,@NumericStr1,'')

  -- Getting numbers and chars from Parameter(@Str2) 
    WHILE PATINDEX( @expresAhpha, @NumericStr2) > 0 
           BEGIN
               SET @NumericStr2 =REPLACE( @NumericStr2, SUBSTRING( @NumericStr2, PATINDEX( @expresAhpha, @NumericStr2 ), 1 ),'')
           END

		 set  @strStr2= Replace(@Str2,@NumericStr2,'')
------------------------------------------------------------------
       IF(lEN(@strStr1)= lEN(@strStr2) AND @strStr1>@strStr2)  or  lEN(@strStr1)> lEN(@strStr2)  Return 1


	   IF(lEN(@strStr1)= lEN(@strStr2) AND @strStr1=@strStr2)
	     Begin
		     IF( Cast (@NumericStr1 AS INT) > Cast (@NumericStr2 AS INT))  Return 1
			 IF( Cast (@NumericStr1 AS INT) = Cast (@NumericStr2 AS INT))  Return 2
		 End

	   

       Return 0
End

GO

