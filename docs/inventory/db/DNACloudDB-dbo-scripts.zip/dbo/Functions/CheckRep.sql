CREATE FUNCTION [dbo].[CheckRep](@ReportNo AS SMALLINT)
RETURNS nvarchar(1000)
AS
BEGIN
	DECLARE @sp as bit  ,@SPName as nvarchar(4000)='',@HasDateParam as smallint=0,@ReturnVal as nvarchar(1000)=''
set @sp=0


 --set @sp= case when substring(rtrim(ltrim(@select)),1,1)='[' then 1 else 0 end 

 select @sp= case when substring(rtrim(ltrim(TableSelect)),1,1)='[' then 1 else 0 end  
 ,@SPName=case when @SP=1 then SUBSTRING(
           TableSelect,
           CHARINDEX('[', TableSelect) + 1,
           CHARINDEX(']', TableSelect) - CHARINDEX('[', TableSelect) - 1
       )else '' end
 from reportstables where reportno=@reportno

  --select @sp,@SPName

  if @Sp=1 and @SPName<>''
  begin
  SELECT
   @HasDateParam=count(*)
FROM
    sys.parameters p
INNER JOIN
    sys.objects o ON p.object_id = o.object_id
WHERE
    o.type = 'P' -- P = Stored Procedure
    AND o.name = @SPName and TYPE_NAME(p.user_type_id) like '%date%'

  end



  select @ReturnVal= rtrim(ltrim(str(@ReportNo)))+'-'+case when @HasDateParam>0 then '1' else '0' end

  return @ReturnVal


END

GO

