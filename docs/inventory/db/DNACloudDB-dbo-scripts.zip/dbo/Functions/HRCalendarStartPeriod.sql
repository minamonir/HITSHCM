CREATE FUNCTION HRCalendarStartPeriod (@calno int , @year int,@period int)
RETURNS datetime as

begin
declare @startperiodend as datetime

select top 1  @startperiodend =PeriodEndDate  from dbo.HRCalendarPeriods 
                             where CalendarNo = @calno  and Calendaryear*100+ CalendarPeriod < @year*100+@period
order by Calendaryear*100+CalendarPeriod  desc

if  @startperiodend is null   select @startperiodend=  Calendarstartdate from hrcalendar where calendarno=@calno
else   set  @startperiodend=  @startperiodend+1 

return @startperiodend

	end

GO

