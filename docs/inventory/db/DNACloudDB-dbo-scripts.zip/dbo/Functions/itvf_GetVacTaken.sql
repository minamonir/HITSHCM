CREATE   FUNCTION [dbo].[itvf_GetVacTaken]
(
    @empid     INT,
    @startdate DATETIME,
    @enddate   DATETIME,
    @vaccat    INT
)
RETURNS TABLE
AS
RETURN
WITH Rows AS (
    -- one row per matching empvacat record, clipped to the requested window
    SELECT
        empvacat.EmpId,
        empvacat.vaccode,
        empvacat.DocumentNo,
        empvacat.PartDayFrom AS PartDayFrom_in,
        empvacat.PartDayTo   AS PartDayTo_in,
        CASE WHEN empvacat.fromdate < @startdate THEN @startdate ELSE empvacat.fromdate END AS CalcFrom,
        CASE WHEN empvacat.todate   > @enddate   THEN @enddate   ELSE empvacat.todate   END AS CalcTo,
        empvacat.fromdate AS OrigFrom,
        empvacat.todate   AS OrigTo
    FROM empvacat
    INNER JOIN vacation ON empvacat.vaccode = vacation.vaccode
    WHERE empvacat.empid = @empid
      AND empvacat.vacstatus = 1
      AND empvacat.fromdate <= @enddate
      AND empvacat.todate   >= @startdate
      AND vacation.vactype  = @vaccat
      -- confirm hiredate actually lives on EmpAssignment; adjust if it's elsewhere
      AND EXISTS (
          SELECT 1 FROM EmpAssignment ea
          WHERE ea.EmpId = empvacat.EmpId
            AND empvacat.FromDate >= ea.hiredate
      )
),
RowsExt AS (
    -- pull vacation-package rules + resolve part-day flags exactly as VacTakenDays did
    SELECT
        r.*,
        v.donotcountdayoff, v.donotcountholiday, v.DoNotCountNoShift,
        v.UseDayFactor, v.DayFactor,
        CASE WHEN v.AcceptPartDayFrom = 1 THEN v.PartDayFactorFrom ELSE 1 END AS PartDayFactorFrom,
        CASE WHEN v.AcceptPartDayTo   = 1 THEN v.PartDayFactorTo   ELSE 1 END AS PartDayFactorTo,
        oh.OrigVacFrom, oh.OrigVacTo,
        CASE WHEN r.PartDayFrom_in = 1
                  AND (CASE WHEN r.DocumentNo <> 0 THEN oh.OrigVacFrom ELSE r.OrigFrom END) = r.CalcFrom
                  AND v.AcceptPartDayFrom = 1
             THEN 1 ELSE 0 END AS PartDayFrom,
        CASE WHEN r.PartDayTo_in = 1
                  AND (CASE WHEN r.DocumentNo <> 0 THEN oh.OrigVacTo ELSE r.OrigTo END) = r.CalcTo
                  AND v.AcceptPartDayTo = 1
             THEN 1 ELSE 0 END AS PartDayTo,
        CASE WHEN EXISTS (
            SELECT 1 FROM EmpStatusHdr h
            INNER JOIN EmpStatusDtl d ON h.EmpId = d.EmpId AND h.DocumentNo = d.DocumentNo
            WHERE h.DocumentStatus = 1 AND d.FieldNo = 19 AND h.EmpId = r.EmpId
              AND h.EffectiveDate BETWEEN r.CalcFrom AND r.CalcTo
        ) THEN 1 ELSE 0 END AS VacPackChanged
    FROM Rows r
    INNER JOIN vacation v ON v.vaccode = r.vaccode
    OUTER APPLY (
        SELECT TOP (1) ev.FromDate AS OrigVacFrom, ev.ToDate AS OrigVacTo
        FROM EmpVacat ev
        WHERE ev.empid = r.EmpId AND ev.DocumentNo = r.DocumentNo
    ) oh
),
-- bounded set of vacpack "change points" per row instead of one GetOldValue call per day.
-- Most rows have VacPackChanged = 0, so they skip this entirely and just call GetOldValue once.
ChangePoints AS (
    SELECT
        re.EmpId, re.DocumentNo, re.CalcFrom, re.CalcTo,
        cp.PointDate,
        dbo.GetOldValue(re.EmpId, 19, DATEADD(day, 1, cp.PointDate), NULL) AS VacPack
    FROM RowsExt re
    CROSS APPLY (
        SELECT re.CalcFrom AS PointDate
        UNION
        SELECT h.EffectiveDate
        FROM EmpStatusHdr h
        INNER JOIN EmpStatusDtl d ON h.EmpId = d.EmpId AND h.DocumentNo = d.DocumentNo
        WHERE h.DocumentStatus = 1 AND d.FieldNo = 19 AND h.EmpId = re.EmpId
          AND h.EffectiveDate BETWEEN re.CalcFrom AND re.CalcTo
    ) cp
    WHERE re.VacPackChanged = 1
),
-- day-by-day expansion, replacing the WHILE loop. spt_values comfortably covers
-- ranges up to ~2500 days; swap in a dedicated Numbers/Calendar table for reliability.
Days AS (
    SELECT
        re.EmpId, re.vaccode, re.DocumentNo, re.CalcFrom, re.CalcTo,
        re.donotcountdayoff, re.donotcountholiday, re.DoNotCountNoShift,
        DATEADD(day, n.n, re.CalcFrom) AS d,
        COALESCE(
            (SELECT TOP (1) cp.VacPack FROM ChangePoints cp
             WHERE cp.EmpId = re.EmpId AND cp.DocumentNo = re.DocumentNo
               AND cp.PointDate <= DATEADD(day, n.n, re.CalcFrom)
             ORDER BY cp.PointDate DESC),
            dbo.GetOldValue(re.EmpId, 19, DATEADD(day, 1, re.CalcTo), NULL)
        ) AS vacpack
    FROM RowsExt re
    CROSS APPLY (
        SELECT TOP (DATEDIFF(day, re.CalcFrom, re.CalcTo) + 1)
               ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS n
        FROM master.dbo.spt_values
    ) n
),
DayFlags AS (
    SELECT
        dd.*,
        CASE WHEN dd.donotcountdayoff = 1 AND EXISTS (
            SELECT 1 FROM vacpack v
            WHERE v.vacpack = dd.vacpack AND v.dofftype = 1
              AND DATEPART(dw, dd.d) IN (v.doffday1, v.doffday2)
        ) THEN 1 ELSE 0 END AS IsDayoff,
        CASE WHEN dd.donotcountholiday = 1 AND NOT EXISTS (
            SELECT 1 FROM vacpack v
            WHERE v.vacpack = dd.vacpack AND v.dofftype = 1
              AND DATEPART(dw, dd.d) IN (v.doffday1, v.doffday2)
        ) AND EXISTS (
            SELECT 1 FROM holidays h
            WHERE h.vacpack = dd.vacpack AND h.holiday = 1 AND h.date = dd.d
        ) THEN 1 ELSE 0 END AS IsHoliday,
        CASE WHEN dd.DoNotCountNoShift = 1
              AND NOT EXISTS (SELECT 1 FROM EmpShift es WHERE es.EmpId = dd.EmpId AND es.ShiftDate = dd.d AND es.ShiftNo IS NOT NULL)
              AND NOT EXISTS (SELECT 1 FROM vacpack v WHERE v.vacpack = dd.vacpack AND v.dofftype = 1 AND DATEPART(dw, dd.d) IN (v.doffday1, v.doffday2))
              AND NOT EXISTS (SELECT 1 FROM holidays h WHERE h.vacpack = dd.vacpack AND h.holiday = 1 AND h.date = dd.d)
        THEN 1 ELSE 0 END AS IsNoShift
    FROM Days dd
),
Agg AS (
    SELECT
        EmpId, vaccode, DocumentNo, CalcFrom, CalcTo,
        SUM(IsDayoff + IsHoliday + IsNoShift) AS ExcludedDays,
        MAX(CASE WHEN d = CalcFrom AND (IsDayoff = 1 OR IsHoliday = 1 OR IsNoShift = 1) THEN 1 ELSE 0 END) AS FromDayoffOrHoliday,
        MAX(CASE WHEN d = CalcTo   AND (IsDayoff = 1 OR IsHoliday = 1 OR IsNoShift = 1) THEN 1 ELSE 0 END) AS ToDayoffOrHoliday
    FROM DayFlags
    GROUP BY EmpId, vaccode, DocumentNo, CalcFrom, CalcTo
),
Params AS (
    SELECT DecimalScale FROM sysparam
)
SELECT
    SUM(
        ROUND(
            (
                (DATEDIFF(day, re.CalcFrom, re.CalcTo) + 1 - a.ExcludedDays)
                - CASE WHEN re.PartDayFrom = 1 AND a.FromDayoffOrHoliday = 0 THEN 1 ELSE 0 END
                - CASE WHEN re.PartDayTo = 1 AND a.ToDayoffOrHoliday = 0
                       THEN CASE WHEN re.CalcFrom = re.CalcTo AND re.PartDayFrom = 1 AND a.FromDayoffOrHoliday = 0 THEN 0 ELSE 1 END
                       ELSE 0 END
                + CASE WHEN re.PartDayFrom = 1 AND a.FromDayoffOrHoliday = 0 THEN re.PartDayFactorFrom ELSE 0 END
                + CASE WHEN re.PartDayTo = 1 AND a.ToDayoffOrHoliday = 0 THEN re.PartDayFactorTo ELSE 0 END
            ) * CASE WHEN re.UseDayFactor = 1 THEN re.DayFactor ELSE 1 END,
            p.DecimalScale
        )
    ) AS days
FROM RowsExt re
INNER JOIN Agg a ON a.EmpId = re.EmpId AND a.DocumentNo = re.DocumentNo AND a.CalcFrom = re.CalcFrom AND a.CalcTo = re.CalcTo
CROSS JOIN Params p;

GO

