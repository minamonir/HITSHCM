


CREATE FUNCTION [dbo].[calcEmpTotalSal]
  (@empid int, @Date  datetime,@HrorPayroll bit)

--@Date the function calculates total salary at this date
--@HRorPayroll if 1 it will calculate amounts according to HrPCodes 
RETURNS numeric(18,3)
AS
 BEGIN
DECLARE @amount numeric(18,3)
DECLARE @HrCurrency AS smallint
DECLARE @FirstHireDate AS datetime
DECLARE @HireDate AS datetime
SET @amount=0
-- to calculate paycodes of inputtype =amount
SELECT @HrCurrency=HrCurrency,@FirstHireDate=Profile.FirstHiredDate,@HireDate=EmpAssignment.HireDate
FROM EmpAssignment 
LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId WHERE EmpAssignment.EmpId=@empid
IF @Date <isnull(@FirstHireDate ,@HireDate)
BEGIN
	SET @amount=0
END
ELSE
BEGIN
	DECLARE @yearmonth AS int
    SELECT @yearmonth =year*100+month
    FROM HistoryPayroll  WHERE  EmpId=@empid
    AND @date BETWEEN dbo.periodstart(HistoryPayroll.PayrollGroup,month,year) AND dbo.periodend(HistoryPayroll.PayrollGroup,month,year)

	IF @HrorPayroll=1
		BEGIN
			  select @amount=isnull(sum(CASE WHEN Paycode.type =2 THEN -1 ELSE 1 END * isnull(dbo.GetOldValue(@empid, Paycode.code+1000,@Date+1,@HrCurrency),0)),0)
               FROM Paycode
              -- LEFT JOIN Paycode ON HrpCodes.paycode=Paycode.code 
               WHERE Paycode.addtotsal=1 AND Paycode.inputtp=1 AND Paycode.code<>100
                -- AND HrPCodes.EmpId=@empid
          SET @amount=ISNULL(@amount,0)
          SET @amount=@amount+dbo.GetOldValue(@empid,14,@Date+1,@HrCurrency)

        -- history
          IF @yearmonth IS NOT NULL
           BEGIN
	           select @amount=@amount+isnull(sum(CASE WHEN Paycode.type =2 THEN -1 ELSE 1 END * isnull(dbo.HPaycodeAmount(@empid,Paycode.code,@yearmonth,@yearmonth,@HrCurrency),0)),0)
	           FROM Paycode WHERE Paycode.addtotsal=1 AND Paycode.inputtp <>1 AND Paycode.code<>100
           END
         ELSE
         --Current
	      BEGIN
	          select @amount=@amount+isnull(sum( CASE WHEN Paycode.type =2 THEN -1 ELSE 1 END * isnull(dbo.CalcPaycode(@empid,Paycode.code,HrPCodes.inputamnt,null),0) ),0)
	          FROM  HrPCodes LEFT JOIN Paycode ON Paycode.code = HrPCodes.paycode WHERE Paycode.addtotsal=1 AND Paycode.inputtp <>1 AND HrPCodes.paycode<>100
	           AND HrPCodes.empid=@empid
	      END

		END
		ELSE
		 --From Paycode
			BEGIN
		   -- history
               IF @yearmonth IS NOT NULL
                  BEGIN
	                select @amount=isnull(sum( CASE WHEN Paycode.type =2 THEN -1 ELSE 1 END * isnull(dbo.HPaycodeAmount(@empid,Paycode.code,@yearmonth,@yearmonth,@HrCurrency),0) ),0)
	                FROM Paycode WHERE Paycode.addtotsal=1 
                  END
               ELSE
              --Current
	             BEGIN
	                select @amount=isnull(sum(CASE WHEN Paycode.type =2 THEN -1 ELSE 1 END * isnull(dbo.CalcPaycode(@empid,Paycode.code,Paycode.inputamt,null),0) ),0)
	                 FROM Paycode WHERE Paycode.addtotsal=1
	             END	
		     END
	END

return ISNULL(@amount,0)
END

GO

