CREATE FUNCTION [dbo].[EmpSubjectEvaluation](@EmpID int, @DocumentNo int, @TrainingEval int ,@Subjcet int )
RETURNS numeric(18,3) AS
BEGIN
	DECLARE @Score AS numeric(18,3)
   
		SET @Score=
		  (	SELECT SUM(ratinglevels.levelpercent)/COUNT(emptrainingevalsubjects.TrainingEvalItem)
			FROM emptrainingevalsubjects 
				LEFT JOIN trainingevalitems ON trainingevalitems.trainingeval=emptrainingevalsubjects.TrainingEval AND trainingevalitems.trainingevalitem=emptrainingevalsubjects.trainingevalitem
				LEFT JOIN trainingevals ON trainingevals.TrainingEval = trainingevalitems.TrainingEval
				LEFT JOIN RatingScales ON ISNULL(TrainingEvalItems.RatingScale, TrainingEvals.RatingScale) = RatingScales.RatingScale
				LEFT JOIN RatingLevels ON RatingScales.RatingScale  = RatingLevels.RatingScale  
					  AND RatingLevels.RatingLevel = emptrainingevalsubjects.RatingLevel	
			WHERE emptrainingevalsubjects.empid=@EmpID
				AND emptrainingevalsubjects.documentno=@DocumentNo
				AND emptrainingevalsubjects.TrainingEval=@TrainingEval
				AND emptrainingevalsubjects.TrainingSubject=CASE WHEN @Subjcet IS NOT NULL THEN @Subjcet ELSE EMPTRAININGEVALSUBJECTS.TRAININGSUBJECT END               
			)
		

	 RETURN ISNULL(@Score,0)		
End

GO

