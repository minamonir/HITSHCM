
--USE [HITSDNA2020MLI]
--GO
--/****** Object:  UserDefinedFunction [dbo].[EmpWorkdays]    Script Date: 2/7/2023 2:29:57 PM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
CREATE FUNCTION [dbo].[EmpWorkMonths]  (@Empid int,@MonthDays int, @StartPeriod smalldatetime, @EndPeriod SMALLDATETIME, @CheckHiringTerm BIT=1,@CalcVac SMALLINT=0,@vacCodes NVARCHAR(max)=N'',@CalcPaycodes BIT=0 ,@PayCodes NVARCHAR(max)=N'', @WorkHours SMALLINT=8)
RETURNS numeric(18,3) AS  
--declare @Empid int=80,@MonthDays int=0, @StartPeriod smalldatetime=N'2022-02-01', @EndPeriod SMALLDATETIME=N'2022-08-31', 
--@CheckHiringTerm BIT=1,@CalcVac SMALLINT=0,@vacCodes NVARCHAR(max)=N'',@CalcPaycodes BIT=0 ,@PayCodes NVARCHAR(max)=N'', @WorkHours SMALLINT=0
begin
DECLARE @WorkDays AS numeric(18,3)
DECLARE @TotalPyCdsAmount AS numeric(18,3),@Monthly AS INT
SET @Monthly=0


DECLARE @Hiredate AS SMALLDATETIME,@FirstHiredate AS SMALLDATETIME,@TermDate AS SMALLDATETIME

SELECT @Hiredate= HireDate,@FirstHiredate=FirstHiredDate,@TermDate=TermDate
FROM EmpAssignment 
LEFT JOIN [Profile] ON [Profile].ProfileId = EmpAssignment.EmpId
WHERE empid=@Empid

---------------not rehiring case
IF (@Hiredate>@EndPeriod OR @TermDate<@StartPeriod) AND ISNULL(@FirstHiredate,@Hiredate)=@Hiredate 
BEGIN
	SET @WorkDays=0
	return @WorkDays
END


--SET @vacCodes=ISNULL(@vacCodes,N'')
SET @MonthDays=CASE WHEN @MonthDays=0 THEN datediff(MM,@StartPeriod,@EndPeriod)+1 ELSE @MonthDays END
--SET @PayCodes=CASE WHEN @PayCodes<>'' THEN N','+@PayCodes+N','  else N'' end


------------------------------------------- Calculate Paycodes amount ------------------------------------------------------
--IF @CalcPaycodes=1
--BEGIN
--	---- Check if it is monthly or not
--	SELECT @Monthly=COUNT(*) FROM EmpAssignment 
--	INNER JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
--	WHERE EmpAssignment.EmpId=@Empid AND dbo.periodstart(PayrollGroup.PayrollGroup,PayrollGroup.CMonth,PayrollGroup.CYear)=@StartPeriod 
--	AND dbo.periodend(PayrollGroup.PayrollGroup,PayrollGroup.CMonth,PayrollGroup.CYear)=@EndPeriod

--				IF @Monthly<>0 -------------- Monthly
--						SELECT  @TotalPyCdsAmount=SUM ((CASE WHEN Paycode.[type]=1 OR Paycode.code=100  THEN 1.00 
--																	WHEN Paycode.[type]=2 or Paycode.code IN (901,902,910,911,912)  THEN -1.00 else 1 end)
--							*(CASE WHEN Paycode.inputtp IN (1,2) THEN MonthlyTransaction.InputAmnt WHEN Paycode.inputtp=3 THEN MonthlyTransaction.InputAmnt/@WorkHours ELSE MonthlyTransaction.Amount END) ) 
--							FROM EmpAssignment  
--							INNER JOIN MonthlyTransaction ON EmpAssignment.EmpId = MonthlyTransaction.EmpId 
--							LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup  
--							LEFT JOIN Paycode ON Paycode.code = MonthlyTransaction.Paycode
--							WHERE TransactionInactive=0 AND EmpAssignment.EmpId=@Empid 
--							AND @PayCodes like CASE WHEN @PayCodes <> '' THEN  '%,'+ltrim(rtrim(STR(Paycode.code)))+',%' ELSE @PayCodes  end  
							
--				ELSE 
--				BEGIN
--					  ------------------- History
					  
--						DECLARE @HYear AS INT,@HMonth AS INT
--						select @HYear=HistoryPayroll.[Year],@HMonth=HistoryPayroll.[Month]
--						FROM HistoryPayroll
--						WHERE HistoryPayroll.EmpId=@Empid AND (dbo.periodstart(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year) = @StartPeriod )
--							AND (dbo.periodend(HistoryPayroll.PayrollGroup,HistoryPayroll.Month,HistoryPayroll.Year)=@EndPeriod) 
					    
--						SELECT  @TotalPyCdsAmount=SUM ((CASE WHEN Paycode.[type]=1 or Paycode.code=100 THEN 1.00 WHEN Paycode.[type]=2 or paycode.code IN (901,902,910,911,912) THEN -1.00 else 1 END)
--														*(CASE WHEN Paycode.inputtp IN (1,2) THEN HistoryTransaction.InputAmnt when Paycode.inputtp=3 THEN HistoryTransaction.InputAmnt/@WorkHours ELSE HistoryTransaction.Amount END) ) 
--							FROM EmpAssignment 
--							INNER JOIN HistoryPayroll ON HistoryPayroll.EmpId = EmpAssignment.EmpId 
--							INNER JOIN HistoryTransaction ON HistoryPayroll.Year = HistoryTransaction.Year 
--										AND HistoryPayroll.Month = HistoryTransaction.Month  
--										AND HistoryPayroll.EmpId = HistoryTransaction.EmpId 
--										AND HistoryPayroll.RunNo = HistoryTransaction.RunNo 
--							LEFT JOIN Paycode ON PayCode.Code = HistoryTransaction.PayCode 
--							WHERE EmpAssignment.EmpId=@Empid AND  HistoryPayroll.[Year]=@HYear AND HistoryPayroll.[Month]=@HMonth
--							AND @PayCodes like CASE WHEN @PayCodes <>'' THEN  '%,'+ltrim(rtrim(STR(Paycode.code)))+',%' else @PayCodes end  
							
--					END

--END
 
------------------------------------------ Calculating The Final Actual Working Days ---------------------------------------------------------------------------
--IF  @CalcVac=2
--BEGIN
--DECLARE @days AS NUMERIC(18,3)=0
--DECLARE @commaIndex AS INT=0,@vaccode AS INT , @vacDays AS numeric(18,3) = 0 
--IF @vaccodes =N''
--	BEGIN
--		SELECT @vacdays=SUM(dbo.VacTakenDays(@Empid,AttendDate,AttendDate,VacCode,0,0,0)) 
--		FROM dbo.EmpAttendance 
--		WHERE AttendDate BETWEEN @StartPeriod AND @EndPeriod 
--		AND VacCode IS NOT NULL 
--		AND EmpId=@Empid
--	END
--ELSE
-- BEGIN 
--	SET @vaccodes = @vaccodes+','
--		WHILE charindex(',',@vaccodes,0)>0
--		BEGIN 
--			SET @commaIndex= charindex(',',@vaccodes,0)
--			SET @vaccode=substring(@vaccodes,1,@commaIndex-1)
--			SET @vaccodes=substring(@vaccodes,@commaIndex+1,len(@vaccodes))
--			SELECT @days=SUM(dbo.VacTakenDays(@Empid,AttendDate,AttendDate,@vaccode,0,0,0)) FROM dbo.EmpAttendance WHERE AttendDate BETWEEN @StartPeriod AND @EndPeriod AND EmpId=@Empid AND VacCode=@vaccode
--		SELECT @vacDays=@vacDays+ISNULL(@days ,0)
--		END
--  END 
--	 SELECT @vacDays=ISNULL(@vacDays,0)
--END

------------------------------------------------------------------------------------------------------------------

SELECT   @WorkDays=@MonthDays 
--+ isnull(@TotalPyCdsAmount,0)
					-CASE WHEN @CheckHiringTerm=1 THEN (CASE WHEN @Hiredate between @StartPeriod and @EndPeriod then DATEDIFF(MM,@StartPeriod,@Hiredate ) else 0 end) ELSE 0 end
					-CASE WHEN @CheckHiringTerm=1 THEN  (CASE WHEN @TermDate between @StartPeriod and @EndPeriod then DATEDIFF(MM, @TermDate,@EndPeriod) else 0 end )  ELSE 0 end
					---(Case when @CalcVac =1 then dbo.[VacationsTotalTaken](@empid,@StartPeriod,@EndPeriod,@vaccodes) WHEN @calcvac=2 THEN @vacDays ELSE 0 END )
return @WorkDays
end

GO

