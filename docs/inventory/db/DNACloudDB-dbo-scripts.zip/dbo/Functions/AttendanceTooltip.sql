CREATE Function [dbo].[AttendanceTooltip] (@Empid INT,  @EntryDate SMALLDATETIME,@lang NCHAR(1), @Type SMALLINT)
returns nvarchar(max) as 
BEGIN
	--DECLARE @Empid INT,  @EntryDate SMALLDATETIME,@lang NCHAR(1), @Type SMALLINT
	--SELECT @Empid =202593,  @EntryDate ='2014-07-17',@lang ='E', @Type =1
	DECLARE @Tooltip NVARCHAR(MAX)
	DECLARE @vacname NVARCHAR(max) , @workhours NUMERIC(5,2) ,@shiftname  NVARCHAR(60)
	SELECT @Tooltip=''
	IF @Type=2
	BEGIN
	SELECT @vacname= CASE WHEN  @lang = 'E' THEN ltrim(rtrim(VacationName))+N' ('+ltrim(rtrim(SSDocStatus))+N') '
	 ELSE ltrim(rtrim(VacationAName))+N' ('+ltrim(rtrim(SSDocAStatus))+N') ' END
	FROM EmpVacat
	INNER JOIN vacation ON	vacation.vaccode = EmpVacat.VacCode
	LEFT JOIN SSDocumentStatus ON SSDocumentStatus.SSDocStatusNo = EmpVacat.VacStatus
	WHERE EmpId = @Empid AND  @EntryDate BETWEEN FromDate AND ToDate AND VacStatus in (1,5)
    END
    ELSE
    begin
	SELECT @vacname= CASE WHEN  @lang = 'E' THEN ltrim(rtrim(VacationName)) ELSE ltrim(rtrim(VacationAName)) END
	FROM EmpVacat
	INNER JOIN vacation ON	vacation.vaccode = EmpVacat.VacCode
	WHERE EmpId = @Empid AND  @EntryDate BETWEEN FromDate AND ToDate AND VacStatus = 1
	end
	SELECT @workhours= isnull(cast(ROUND((SUM(EmpShiftInOut.WorkSeconds)/3600.00),0) as smallint),0) 
	FROM EmpShiftInOut WHERE EmpId = @Empid AND EntryDate = @EntryDate 
	group by EmpShiftInOut.empid,EmpShiftInOut.entrydate
	
	SELECT @shiftname = ISNULL(CASE WHEN  @lang = 'E' THEN ltrim(rtrim(TimeShifts.ShiftName)) 
	ELSE ltrim(rtrim(TimeShifts.ShiftAName)) END ,'')
	FROM EmpShift
	INNER JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo
	WHERE EmpId = @Empid AND ShiftDate= @EntryDate
	
	SELECT @Tooltip = CASE WHEN  @lang = 'E' then N'Vacation: ' + isnull(@vacname,N'None') + CHAR(13)+CHAR(10)
	+ N'Shift: ' + isnull(@shiftname,N'None') + CHAR(13)+CHAR(10) 
	+ N'Work Hours: ' + isnull(ltrim(rtrim(str(@workhours))),0)
	ELSE  N'الأجازة: ' + isnull(@vacname,N'لا يوجد') + CHAR(13)+CHAR(10)
	+ N'الوردية: ' + isnull(@shiftname,N'لا يوجد') + CHAR(13)+CHAR(10) 
	+ N'ساعات العمل: ' + isnull(ltrim(rtrim(str(@workhours))),0) END
	
RETURN @Tooltip
END

GO

