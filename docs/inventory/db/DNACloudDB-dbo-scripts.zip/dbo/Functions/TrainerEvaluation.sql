/*** Sum Percentage For the Evaluation Items / Count of The Items To Get The Average  ****/
CREATE FUNCTION [dbo].[TrainerEvaluation](@Resource INT,@ResourceCat SMALLINT,@Subject SMALLINT,@From SMALLDATETIME, @To SMALLDATETIME)   
RETURNS numeric (18,3) AS  

BEGIN

--DECLARE @Resource AS INT, @ResourceCat AS SMALLDATETIME,@Subject AS SMALLINT,@From AS SMALLDATETIME, @To AS SMALLDATETIME

--SET @Resource=1001
--SET @ResourceCat=1 
--SET @Subject=2
--SET @From='2011/01/01 00:00:00'
--SET @To='2011/06/01 00:00:00'

	DECLARE @Score AS numeric(18,3)
	
		SET @Score=
		(	SELECT Sum(RatingLevels.LevelPercent)/COUNT(EmpTrainingEvalTrainers.TrainingEvalItem)
			FROM EmpTrainingEvalTrainers
			LEFT JOIN TrainingEvalItems ON  TrainingEvalItems.TrainingEval = EmpTrainingEvalTrainers.TrainingEval 
				  AND TrainingEvalItems.TrainingEvalItem = EmpTrainingEvalTrainers.TrainingEvalItem
				  AND TrainingEvalItems.ResourceCategory =EmpTrainingEvalTrainers.ResourceCategory
			LEFT JOIN TrainingEvals ON TrainingEvals.TrainingEval = EmpTrainingEvalTrainers.TrainingEval
			lEFT JOIN RatingScales  ON ISNULL(TrainingEvalItems.RatingScale, TrainingEvals.RatingScale) = RatingScales.RatingScale
			LEFT JOIN RatingLevels  ON RatingScales.RatingScale  = RatingLevels.RatingScale  
				  AND RatingLevels.RatingLevel = EmpTrainingEvalTrainers.RatingLevel
			LEFT JOIN EmpTrainingEval ON EmpTrainingEval.EmpId = EmpTrainingEvalTrainers.EmpId 
			AND EmpTrainingEval.DocumentNo = EmpTrainingEvalTrainers.DocumentNo 
			AND EmpTrainingEval.TrainingEval = EmpTrainingEvalTrainers.TrainingEval	  	
			WHERE  EmpTrainingEvalTrainers.TrainingResource = CASE WHEN @Resource IS NULL THEN EmpTrainingEvalTrainers.TrainingResource ELSE @Resource END 
			       AND EmpTrainingEvalTrainers.ResourceCategory = CASE WHEN @ResourceCat IS NULL THEN EmpTrainingEvalTrainers.ResourceCategory ELSE @ResourceCat END
			       AND EmpTrainingEvalTrainers.TrainingSubject  = CASE WHEN @Subject IS NULL THEN EmpTrainingEvalTrainers.TrainingSubject ELSE @Subject END
			       AND  EmpTrainingEval.TrainingEvalDate BETWEEN isnull(@From,EmpTrainingEval.TrainingEvalDate) AND isnull(@To,EmpTrainingEval.TrainingEvalDate)
		)
	--SELECT @Score	
		
RETURN ISNULL(@Score,0)
END

GO

