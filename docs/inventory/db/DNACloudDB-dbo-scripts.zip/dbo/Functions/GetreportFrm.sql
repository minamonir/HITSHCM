create FUNCTION [dbo].[GetreportFrm]
  (@ReportNo smallint)
RETURNS  nvarchar(max)
as
BEGIN 
  declare @ReportFrm as nvarchar(max)=N''
   
       select @ReportFrm=FilterForm  from reports where reportno=@ReportNo 
  return @ReportFrm
END

GO

