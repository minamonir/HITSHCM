



CREATE PROCEDURE [dbo].[BatchWP_GetExternalBenefitPlan]
	
(@actiontype AS SMALLINT=3, @tablename as nvarchar(150),@actual AS smallint,@tabletype AS NVARCHAR(max),@Where AS nvarchar(max),@Parameters AS nvarchar(max),@outputstr AS nvarchar(max)output) AS
DECLARE @SELECT AS nvarchar(max)DECLARE @DateFormat AS INT,@countUDF INT 
Declare @Params nvarchar(500)
DECLARE @ErrorValue AS INT
declare  @ErrorSum as INT
DECLARE @error AS INT 
DECLARE @errormsg AS NVARCHAR(max)
SELECT  @Error=0,@errormsg=''
SET @tabletype=CASE WHEN @tabletype LIKE '%UDF%' THEN SUBSTRING(@tabletype,CHARINDEX('UDF',@tabletype),LEN(@tabletype)) ELSE  '' end
select @ErrorSum=0 
	SELECT  @DateFormat =  
	CASE WHEN (SELECT [DateFormat] FROM dbo.SysParam) = 1 THEN 103
	WHEN (SELECT [DateFormat] FROM dbo.SysParam) = 2 THEN 101
	ELSE 111 END  
    	   
			CREATE TABLE #UDFTemp(UDF nVARCHAR(8))
			SET @select ='INSERT INTO #UDFTemp (UDF) SELECT substring(COLUMN_NAME ,4,len(COLUMN_NAME))
FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME Like ''UDF%'' '
EXECUTE(@select)
IF @actiontype=1 --post
BEGIN
	DECLARE @Parameter1 AS nvarchar (100)
	DECLARE @Parameter2 AS nvarchar (100)
	DECLARE @Parameter3 AS nvarchar (100)
	DECLARE @Parameter4 AS nvarchar (100)
	DECLARE @Parameter5 AS nvarchar (100) --Flag to determine if the user wants to update or insert a benefit plan
	DECLARE @Parameter6 AS nvarchar (100)
	DECLARE @RefYear AS nvarchar (100)--RefYear
	DECLARE @RefNum AS nvarchar (10)--RefNum
	DECLARE @IssueDate AS nvarchar (100)--IssueDate
	DECLARE @ExecDate AS nvarchar (100)--ExecDate
	DECLARE @RefStatus AS nvarchar (100)--RefStatus
	DECLARE @RefSource AS nvarchar (100)--RefSource
	DECLARE @RrfDesc AS nvarchar(max)--RrfDesc
	DECLARE @AttachmentPath AS nvarchar(max)--AttachmentPath
	DECLARE @AttachmentDesc AS nvarchar(120)--Desc
	DECLARE @AttachmentADesc AS nvarchar(120)--ADesc
	DECLARE @EnterDate AS nvarchar (100)--EnterDate
	DECLARE @EnterBy AS nvarchar (100)--EnterBy
	DECLARE @enableAttachments AS BIT
	DECLARE @enableRef AS BIT
	DECLARE @Result AS NVARCHAR(MAX) =''
	DECLARE @updatetablestr as nvarchar(MAX)
	SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 
	
	DECLARE @index AS smallint
	
	SET @index=charindex(',',@Parameters)	
	SET @Parameter1=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@Parameter1='+@Parameter1
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @Parameter2=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))	
	PRINT '@Parameter2='+@Parameter2
	PRINT @Parameters

  SET @index=charindex(',',@Parameters)	
	SET @Parameter3=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@Parameter3='+@Parameter3
	PRINT @Parameters

	 SET @index=charindex(',',@Parameters)	
	SET @Parameter4=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@Parameter4='+@Parameter4
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @Parameter5=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@Parameter5='+@Parameter5
	PRINT @Parameters
	
		SET @index=charindex(',',@Parameters)	
	SET @Parameter6=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@Parameter6='+@Parameter6
	PRINT @Parameters
	--Enable Refrence params
	SET @index=charindex('@referenceNostart',@Parameters)	
	PRINT @Parameters
	SET @RefYear=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceNostart'),len(@Parameters))
	PRINT '@RefYear='+@RefYear
	PRINT @Parameters
	
	SET @index=charindex('@referenceNoEnd',@Parameters)	
	SET @RefNum=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceNoEnd'),len(@Parameters))
	PRINT '@RefNum='+@RefNum
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @IssueDate=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@IssueDate='+@IssueDate
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @ExecDate=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@ExecDate='+@ExecDate
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @RefStatus=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@RefStatus='+@RefStatus
	PRINT @Parameters
	
	SET @index=charindex('@referenceDescstart',@Parameters)	
	SET @RefSource=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceDescstart'),len(@Parameters))
	PRINT '@RefSource='+@RefSource
	PRINT @Parameters
	


IF @enableAttachments=1
BEGIN
		SET @index=charindex('@referenceDescEnd',@Parameters)	
	SET @RrfDesc=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceDescEnd'),len(@Parameters))
	PRINT '@RrfDesc='+@RrfDesc
	PRINT @Parameters
	
	SET @index=charindex('@AttachmentPathEnd',@Parameters)	
	SET @AttachmentPath=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@AttachmentPathEnd'),len(@Parameters))
	PRINT '@AttachmentPath='+@AttachmentPath
	PRINT @Parameters
	
	SET @index=charindex('@AttachmentDesEnd',@Parameters)	
	SET @AttachmentDesc=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@AttachmentDesEnd'),len(@Parameters))
	PRINT '@AttachmentDesc='+@AttachmentDesc
	PRINT @Parameters
	
	SET @index=charindex('@AttachmentADesEnd',@Parameters)	
	SET @AttachmentADesc=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@AttachmentADesEnd'),len(@Parameters))
	PRINT '@AttachmentADesc='+@AttachmentADesc
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @EnterDate=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@EnterDate='+@EnterDate
	PRINT @Parameters
	
	SET @EnterBy=@Parameters
	PRINT '@EnterBy='+@EnterBy
	
END
ELSE
	BEGIN
		SET @RrfDesc=@Parameters
		PRINT '@RrfDesc='+@RrfDesc
	END

	
	--------------------------------------------
	DECLARE @DisableCompensation AS BIT ,@DisableCoverage AS BIT,@Compensation AS NUMERIC(18,3),@CoverageFormula AS NVARCHAR(max)
SELECT @DisableCompensation=DisableCompensation,@DisableCoverage=DisableCoverage ,
@Compensation=Compensation,@CoverageFormula=CoverageFormula
FROM BenefitPlanOptions WHERE PlanNo=@Parameter1 AND OptionNo=@Parameter3

IF @DisableCompensation=1
BEGIN
EXEC ('update '+@tablename+ ' set LevelAmount = '+ @Compensation)
END



SET @SELECT='update profile set profilechangeby=profilechangeby from '+@tablename+' t where t.post=1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' and ProfileId='+@Parameter4

PRINT @SELECT
EXECUTE (@SELECT)	

DECLARE @empid AS int
DECLARE @docno AS int
DECLARE @enrolldate AS smalldatetime
DECLARE @CoverageAmount AS numeric(18,3)
DECLARE @LevelAmount AS numeric(18,3)
DECLARE @BenefitNote AS nvarchar(max)
DECLARE @PlanSupplierNo AS SMALLINT
DECLARE @PlanServiceNo AS SMALLINT
DECLARE @cur_empid AS NVARCHAR(256)
DECLARE @employeeid AS NVARCHAR(50),@string AS NVARCHAR(MAX)

DECLARE @Cur_RYear AS SMALLINT=null, @Cur_RNo AS nvarchar(10)=null, @Cur_IssueDate as nvarchar (100)=null, @Cur_ExecDate AS nvarchar (100)=null
					,@Cur_RStatus AS SMALLINT=null, @Cur_RSource  AS SMALLINT =null, @Cur_RDesc nvarchar(max) =null
					,@cur_AttachDesc nvarchar(max) , @cur_AttachPath nvarchar(max)  


DECLARE @cur_str NVARCHAR(MAX)='',@cur_str2 NVARCHAR(MAX)=''

IF   @enableRef = 1
 begin
 SET @cur_str= ' , t.[RYear], t.[RNo], t.[RIssueDate] , t.[RExecDate] 
				,NasArraysStatus.itemno [RStatus], NasArraysSource.itemno [RSource] , t.[RDesc] '

				
 SET @cur_str2='LEFT JOIN NasArrays NasArraysStatus ON  ltrim(rtrim(t.[RStatus]))  = case when '''+@Where+'''= ''E'' then ltrim(rtrim(NasArraysStatus.edesc)) else ltrim(rtrim(NasArraysStatus.adesc)) end 
AND NasArraysStatus.arrayname=''RStatus'' 
LEFT JOIN NasArrays NasArraysSource ON   ltrim(rtrim(t.[RSource] ))= case when '''+@Where+'''= ''E'' then ltrim(rtrim(NasArraysSource.edesc)) else ltrim(rtrim(NasArraysSource.adesc)) end  
AND NasArraysSource.arrayname=''RSource'' '
end
ELSE
SET @cur_str= ' , null, null, null , null,null,null , null '

IF @enableAttachments=1
SET @cur_str= @cur_str +' ,t.AttDesc, t.AttPath '
ELSE
SET @cur_str= @cur_str + ' , null, null '



EXEC('DECLARE benefitcursor CURSOR FOR SELECT distinct e.empid, t.EnrollDate, t.CoverageAmount, t.LevelAmount, t.BenefitNote 
,CASE WHEN rtrim(ltrim(isnull(t.remarks,''''))) <> '''' THEN SupplierService.SupplierNo ELSE Supplier.SupplierNo END AS SupplierNo
,CASE WHEN rtrim(ltrim(isnull(t.remarks,''''))) <> '''' THEN SupplierService.ServiceNo ELSE service.ServiceNo END  AS ServiceNo
,t.empid '+@cur_str +'
 FROM empassignment e inner join '+@tablename+' t on e.employeeid=t.empid 
left join Supplier ON ltrim(rtrim(t.Supplier)) = (case when '''+@Where+''' = ''A'' then ( ltrim(rtrim(Supplier.SupplierAName)) ) else  ltrim(rtrim((Supplier.SupplierName ))) end) 
left join Service ON ltrim(rtrim(t.Service)) = (case when '''+@Where+''' = ''A'' then ltrim(rtrim(( Service.ServiceAName  ))) else  ltrim(rtrim((Service.ServiceName ))) end)  
LEFT JOIN SupplierService ON SupplierService.SupplierNo = Supplier.SupplierNo  AND SupplierService.ServiceNo = Service.ServiceNo 
'+@cur_str2 +'
where t.post=1 and 
(rtrim(ltrim(isnull(t.remarks,'''')))='''' 
or rtrim(ltrim(isnull(t.remarks,'''')))=isnull(dbo.Hits_GetDCCaption(''	common'',''ErrMsgsupplierservice'','''+@Where+'''),(case when '''+@Where+'''=''A'' then N''المورد لا يقدم هذة الخدمة'' ELSE N''Supplier does not supply this service''  end))
 )')

OPEN benefitcursor
FETCH next FROM benefitcursor
INTO @empid, @enrolldate, @CoverageAmount, @LevelAmount, @BenefitNote,@PlanSupplierNo,@PlanServiceNo,@cur_empid
,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath
WHILE @@FETCH_STATUS=0
BEGIN
PRINT @empid	


	BEGIN TRANSACTION;
      BEGIN TRY   

	  IF @Parameter5=2 OR @Parameter5=3 --Update
			BEGIN
			
			   SET @docno=0
			   SELECT DISTINCT @docno=DocumentNo  
			   FROM EmpBenefit
			   WHERE EmpBenefit.EmpId=@empid AND EmpBenefit.PlanNo=@Parameter1 AND EmpBenefit.OptionNo=@Parameter3 AND EmpBenefit.EnrollDate=@enrolldate
			END
			PRINT ('update @CoverageAmoun a sdff ')
	  IF @DisableCoverage=1
	BEGIN
		
           
		   DECLARE @docno2 INT = CASE WHEN  @Parameter5=2 OR @Parameter5=3 THEN @docno ELSE NULL END 

		 DECLARE @1_amount NUMERIC(18, 3);
		EXEC dbo.benefitformula @l_empid = @empid, -- int
		    @l_programno = NULL, -- smallint
		    @l_planno = @Parameter1, -- smallint
		    @l_optionno = @Parameter3, -- smallint
		    @l_itemno = null, -- smallint
		    @l_documentno =  @docno2 , -- int
		    @l_calcdate = @enrolldate, -- smalldatetime
		    @l_calcwhat = 1, -- smallint
		    @l_calcformula = '', -- nvarchar(4000)
		    @1_amount = @1_amount OUTPUT, -- numeric(18, 3)
		    @OriginalItemQuantity = NULL, -- numeric(18, 3)
		    @SupplierNo = @PlanSupplierNo, -- smallint
		    @ServiceNo = @PlanServiceNo -- smallint

		SET @CoverageAmount=@1_amount
		
		SELECT @employeeid=employeeid FROM dbo.EmpAssignment WHERE EmpId=@empid

		EXEC ('update '+@tablename+ ' set CoverageAmount = '+@CoverageAmount+'  where empid='''+@employeeid+'''' )

	END

IF @Parameter5=1 --Insert
BEGIN
	
    
	SET @docno=dbo.GetDocumentNo(@empid ,7)	
	PRINT @docno
                    
     INSERT INTO EmpBenefit (EmpId, DocumentNo, BenefitStatus, Closed, ProgramNo, PlanNo,       
                             OptionNo, EnrollDate, EndDate, CoverageAmount, LevelAmount,PlanSupplierNo,PlanServiceNo, BenefitNote, EnterBy, EnterDate,EmpBenefitRYear
                             ,EmpBenefitRNo,EmpBenefitRIssueDate,EmpBenefitRExecDate,EmpBenefitRStatus, EmpBenefitRSource, EmpBenefitRDesc)  
                             Values(@empid,@docno,@Parameter2,0,NULL,@Parameter1,@Parameter3,convert(nvarchar(10),@enrolldate,111),NULL,isnull(@CoverageAmount,0),isnull(@LevelAmount,0)
                             ,@PlanSupplierNo,@PlanServiceNo,isnull(@BenefitNote, ''),@Parameter4, getdate()
                             	,ISNULL(lTRIM(@Cur_RYear),@RefYear) 
								,ISNULL(@Cur_RNo,@RefNum)
					            ,ISNULL(@Cur_IssueDate,CASE WHEN @IssueDate='NULL' THEN NULL ELSE @IssueDate END)
					            ,ISNULL(@Cur_ExecDate,CASE WHEN @ExecDate='NULL' THEN NULL ELSE @ExecDate END)
		                        ,ISNULL(lTRIM(@Cur_RStatus),CASE WHEN @RefStatus='NULL' THEN NULL ELSE @RefStatus END)
		                        ,ISNULL(lTRIM(@Cur_RSource),CASE WHEN @RefSource='NULL' THEN NULL ELSE @RefSource END) 
		                        , ISNULL(@Cur_RDesc,@RrfDesc)
					 )
                             


                           SET @ErrorValue=@@ERROR
                     PRINT str(@@ERROR)+'error'+str(@ErrorValue)
           IF @enableAttachments=1 AND ISNULL(@cur_AttachPath,@AttachmentPath)<>'' AND @ErrorValue=0
				BEGIN		
					INSERT INTO Attachments
					(
						-- AttachmentId -- this column value is auto-generated,
						EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,	AttachmentPath,EnterBy,EnterDate
					)
					VALUES
					(@EmpId,7,@docno,0,0,ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachDesc,@AttachmentADesc),ISNULL(@cur_AttachPath,@AttachmentPath),@EnterBy,@EnterDate)
					

				END 
                              
                             IF len(@Parameter6)>0
                             BEGIN
	                             IF EXISTS(SELECT * FROM EmpBenefit eb WHERE eb.EmpId=@empid AND eb.DocumentNo=@docno)
	                             BEGIN
	                                 INSERT INTO WFDocument (DocumentNo, EmpID, SSDocNo,StartDate, EnterDate, EnterBy) 
	                                 values(@docno, @empid,@Parameter6,getdate(), getdate(), @Parameter4)
	                             END
                              END
							  
END
IF @Parameter5=2 --Update
	BEGIN
		
         --  select @docno, * from   EmpBenefit WHERE EmpBenefit.empid=  @empid and EmpBenefit.documentno=@docno
           IF EXISTS(SELECT * FROM EmpBenefit WHERE EmpBenefit.EmpId=@empid AND EmpBenefit.DocumentNo=@docno)
           BEGIN
           	IF @enableRef=1
           	BEGIN
			   
           		UPDATE EmpBenefit  set CoverageAmount=isnull(@CoverageAmount,0), LevelAmount=isnull(@LevelAmount,0),PlanServiceNo = @PlanServiceNo,PlanSupplierNo = @PlanSupplierNo, BenefitNote=isnull(@BenefitNote,''), changeby=@Parameter4,changedate=getdate()
              ,EmpBenefitRYear=ISNULL(lTRIM(@Cur_RYear),@RefYear) ,EmpBenefitRNo=ISNULL(@Cur_RNo,@RefNum),EmpBenefitRIssueDate= ISNULL(@Cur_IssueDate,CASE WHEN @IssueDate='NULL' THEN NULL ELSE @IssueDate END),EmpBenefitRExecDate=ISNULL(@Cur_ExecDate,CASE WHEN @ExecDate='NULL' THEN NULL ELSE @ExecDate END)
              ,EmpBenefitRStatus=ISNULL(lTRIM(@Cur_RStatus),CASE WHEN @RefStatus='NULL' THEN NULL ELSE @RefStatus END), EmpBenefitRSource=ISNULL(lTRIM(@Cur_RSource),CASE WHEN @RefSource='NULL' THEN NULL ELSE @RefSource END) , EmpBenefitRDesc=ISNULL(@Cur_RDesc,@RrfDesc)
              WHERE EmpBenefit.empid=  @empid and EmpBenefit.documentno=@docno
			   
           	END
           	ELSE
           		BEGIN
           			UPDATE EmpBenefit  set CoverageAmount=isnull(@CoverageAmount,0), LevelAmount=isnull(@LevelAmount,0),PlanServiceNo = @PlanServiceNo,PlanSupplierNo = @PlanSupplierNo, BenefitNote=isnull(@BenefitNote,''), changeby=@Parameter4,changedate=getdate()
              WHERE EmpBenefit.empid=  @empid and EmpBenefit.documentno=@docno
           		END
           	      			IF @enableAttachments=1
			BEGIN
					IF  @AttachmentPath<>''
					BEGIN
						
					
						INSERT INTO Attachments
						(
						-- AttachmentId -- this column value is auto-generated,
						EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,	AttachmentPath,EnterBy,EnterDate
						)
						VALUES
						(@EmpId,7,@docno,0,0,ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachDesc,@AttachmentADesc),ISNULL(@cur_AttachPath,@AttachmentPath),@EnterBy,@EnterDate)
						
					END 
				--END	
			END 
           END    
       
        
	END
			--UDF
				
				--SELECT @updatetablestr = 'update '+@TableName+' set remarks = N'''+replace(cast(@Result AS NVARCHAR(250)),'''','''''')+N''' where empid = ''' + @cur_empid +''''
				--SELECT @cur_empid
				DECLARE @udf AS NCHAR(10)
				DECLARE TempTable_cursor2 CURSOR FOR SELECT UDF FROM #UDFTemp 
     OPEN TempTable_cursor2
     FETCH NEXT FROM TempTable_cursor2 INTO @udf
     WHILE @@FETCH_STATUS = 0
      BEGIN 
      DECLARE @NewValueUDF AS NVARCHAR(max)
       select @params = N'@@NewValueUDF nvarchar(254) OUTPUT'  
       SET @SELECT='select @@NewValueUDF= UDF'+@udf +' from '+@tablename 
                  +' inner join empassignment on empassignment.employeeid='+@tablename+'.EmpId'+' where cast (empassignment.empid as nvarchar(max))='+CAST(@empid AS NVARCHAR(max))
                   
                PRINT @select
                           
         EXEC sp_executesql @SELECT,@Params,@NewValueUDF OUTPUT      
       SET @udf=CONVERT(int,@udf)
      
          ------------------------------ fix to load dropdown values 
  
          DECLARE @NewValueUDFfromlist AS NVARCHAR(250)
          SELECT @NewValueUDFfromlist= (SELECT UserFieldsItems.FieldItemNo
          FROM UserFieldsNames left join UserFieldsItems ON UserFieldsNames.FormNo = UserFieldsItems.FormNo AND UserFieldsItems.FieldNo = UserFieldsNames.FieldNo
          WHERE UserFieldsNames.FormNo =13 AND UserFieldsNames.FieldNo = @udf   AND (UserFieldsItems.FieldItemValue = @NewValueUDF OR UserFieldsItems.FieldItemAValue = @NewValueUDF ))
                      
   ------------------------------ fix to load dropdown values 

   SET @NewValueUDF = ISNULL(@NewValueUDFfromlist,@NewValueUDF)
   IF EXISTS (SELECT * FROM dbo.UserFieldsValues where ProfileId=@empid AND DocumentNo=@docno AND FormNo=13 AND FieldNo=@udf)
   BEGIN
   UPDATE dbo.UserFieldsValues  SET FieldValue=@NewValueUDF ,FieldAValue=@NewValueUDF ,FieldFValue=@NewValueUDF  WHERE  ProfileId=@empid AND DocumentNo=@docno AND FormNo=13 AND FieldNo=@udf
   END
   ELSE
   begin
           SET @SELECT='INSERT INTO UserFieldsValues (ProfileId,DocumentNo,FormNo,FieldNo,FieldValue,FieldAValue)
                      select '+ltrim(rtrim(str(@empid)))
                      +','+ltrim(rtrim(str(@docno))) 
                      +',13'
                      +','+ ltrim(rtrim(str(@udf)))
                      --+','''+ @NewValueUDF
                      --+''','''+@NewValueUDF+'''' 
                      +','+'N' + ''''+ @NewValueUDF
                      +''''+','+'N' +''''+@NewValueUDF+'''' 
       
      EXECUTE(@SELECT)
	 end
      select @ErrorSum= @@Error+ @ErrorSum
      set @error=@@ERROR
      IF @error<>0   
        SELECT @errormsg=@errormsg+ 'error: '+sqlmessages.[description] 
		FROM SQLmessages WHERE [error]=@error
		              
    FETCH NEXT FROM TempTable_cursor2 into @udf
     END
    CLOSE TempTable_cursor2
    DEALLOCATE TempTable_cursor2
	
		IF @Parameter5=3 --Update
	BEGIN
	
	 IF EXISTS(SELECT * FROM EmpBenefit WHERE EmpBenefit.EmpId=@empid AND EmpBenefit.DocumentNo=@docno)
           BEGIN
	          UPDATE EmpBenefit  set Closed=1 , changeby= @Parameter4 , changedate=getdate() 
              WHERE EmpBenefit.EmpId=  @empid and EmpBenefit.DocumentNo=@docno AND Closed=0 
	       END
	END
		


	 COMMIT;
                             END TRY
							    BEGIN CATCH
							    SELECT @Result = ERROR_MESSAGE()
								IF @@TRANCOUNT > 0 ROLLBACK;
								SELECT @updatetablestr = 'update '+@TableName+' set remarks = N'''+replace(cast(@Result AS NVARCHAR(250)),'''','''''')+N''' where empid = ''' + @cur_empid +''''
							    END CATCH 


EXECUTE (@updatetablestr)










--					DECLARE @udf AS INT
--					DECLARE @udfcursor AS NVARCHAR(max)
				
--			SET @udfcursor='DECLARE benefitUDF CURSOR FOR SELECT CAST(#UDFTemp.UDF AS INT) FROM #UDFTemp '
--			PRINT(@udfcursor)
--			EXECUTE (@udfcursor)
--					 OPEN benefitUDF
--FETCH next FROM benefitUDF
--INTO @udf
--WHILE @@FETCH_STATUS=0
--BEGIN
--DECLARE @udfvalue AS NVARCHAR(max)
--DECLARE @fieldtype AS int
--DECLARE @selectudf NVARCHAR(max)
--DECLARE @fielditemno int
--SELECT @selectudf=
--'
-- select @udfvalue=  UDF'+CAST(@udf AS NVARCHAR(max))+' FROM '+@tablename+' inner join empassignment on  empassignment.employeeid='+@tablename+'.empid'+' and cast(empassignment.empid as nvarchar(max))='+CAST(@empid AS NVARCHAR(max))
--PRINT (@selectudf)
--EXEC sp_executesql @selectudf ,N'@udfvalue nvarchar(max) OUTPUT ' , @udfvalue OUTPUT 
--SELECT @fieldtype=UserFieldsNames.FieldType FROM dbo.UserFieldsNames WHERE UserFieldsNames.FieldNo=@udf AND UserFieldsNames.FormNo=13
----SELECT @empid,@docno,@udf,@udfvalue,@fieldtype
--IF @fieldtype=2
--BEGIN
--SELECT  DISTINCT @fielditemno=UserFieldsItems.FieldItemNo FROM dbo.UserFieldsItems INNER JOIN  dbo.UserFieldsValues ON UserFieldsValues.FieldNo = UserFieldsItems.FieldNo AND UserFieldsValues.FormNo = UserFieldsItems.FormNo 
--WHERE LTRIM(RTRIM(UserFieldsItems.FieldItemValue))=LTRIM(RTRIM(@udfvalue)) AND UserFieldsItems.FormNo=13
--IF @fielditemno IS NOT NULL
--BEGIN
--IF @Parameter5=1
--BEGIN
--INSERT INTO dbo.UserFieldsValues( ProfileId ,DocumentNo ,FormNo ,FieldNo ,FieldValue ,FieldAValue ,FieldFValue )
--VALUES  ( @empid ,@docno ,13 , @udf, @fielditemno , @fielditemno , @fielditemno )
--END
--ELSE
--BEGIN
--IF EXISTS (SELECT * FROM dbo.UserFieldsValues where ProfileId=@empid AND DocumentNo=@docno AND FormNo=13 AND FieldNo=@udf)
--BEGIN
--UPDATE dbo.UserFieldsValues  SET FieldValue=@fielditemno ,FieldAValue=@fielditemno ,FieldFValue=@fielditemno  WHERE  ProfileId=@empid AND DocumentNo=@docno AND FormNo=13 AND FieldNo=@udf
--END
--ELSE
--BEGIN
--INSERT INTO dbo.UserFieldsValues( ProfileId ,DocumentNo ,FormNo ,FieldNo ,FieldValue ,FieldAValue ,FieldFValue )
--VALUES  ( @empid ,@docno ,13 , @udf, @fielditemno , @fielditemno , @fielditemno )
--end
--end
--end
--END
--ELSE
--BEGIN
----SELECT @udfvalue
--IF @Parameter5=1
--begin
--INSERT INTO dbo.UserFieldsValues( ProfileId ,DocumentNo ,FormNo ,FieldNo ,FieldValue ,FieldAValue ,FieldFValue )
--VALUES  ( @empid ,@docno ,13 , @udf, @udfvalue , @udfvalue , @udfvalue )
--END
--ELSE
--BEGIN
--IF EXISTS (SELECT * FROM dbo.UserFieldsValues WHERE  ProfileId=@empid AND DocumentNo=@docno AND FormNo=13 AND FieldNo=@udf)
--BEGIN
--UPDATE dbo.UserFieldsValues  SET FieldValue=@udfvalue ,FieldAValue=@udfvalue ,FieldFValue=@udfvalue  WHERE  ProfileId=@empid AND DocumentNo=@docno AND FormNo=13 AND FieldNo=@udf
--END
--ELSE
--BEGIN
--INSERT INTO dbo.UserFieldsValues( ProfileId ,DocumentNo ,FormNo ,FieldNo ,FieldValue ,FieldAValue ,FieldFValue )
--VALUES  ( @empid ,@docno ,13 , @udf, @udfvalue , @udfvalue , @udfvalue )
--end
--end
--end
--FETCH next FROM benefitUDF
--INTO @udf
--END
--CLOSE benefitUDF
--DEALLOCATE benefitUDF	

--SET @SELECT='UPDATE EmpBenefit  set CoverageAmount=t.CoverageAmount, LevelAmount=t.LevelAmount, BenefitNote=isnull(t.BenefitNote,''''), changeby='+@Parameter4+' ,changedate=getdate()
--FROM '+@tablename+' t
--WHERE t.post =1 
-- and EmpBenefit.empid=  '+str(@empid)+' 
--and EmpBenefit.planno='+@Parameter1+' and EmpBenefit.optionno='+@Parameter3+' ' --and EmpBenefit.closed=0
--
--PRINT @SELECT
--EXECUTE (@SELECT)	
--
--
--SET @docno=dbo.GetDocumentNo( @empid ,7)	
--	
----	SET @SELECT='INSERT INTO EmpBenefit (EmpId, DocumentNo, BenefitStatus, Closed, ProgramNo, PlanNo, OptionNo, EnrollDate, EndDate,  CoverageAmount, LevelAmount, BenefitNote, EnterBy, EnterDate)
----SELECT 	 '+str(@empid)+','+str(@docno)+','+@Parameter2+',0,null,'+@Parameter1+','+@Parameter3+',t.enrolldate,null, t.CoverageAmount,t.LevelAmount,isnull(t.BenefitNote,''''),'+@Parameter4+',getdate()
----FROM '+@tablename+' t
----WHERE t.post =1 
---- and  '+ltrim(rtrim(str(@empid)))+'
----not IN (SELECT DISTINCT eb.EmpId FROM EmpBenefit eb where eb.empid='+str(@empid)+' and eb.planno='+@Parameter1+' and eb.optionno='+@Parameter3+'  and eb.closed=0)'
--SET @SELECT='INSERT INTO EmpBenefit (EmpId, DocumentNo, BenefitStatus, Closed, ProgramNo, PlanNo, OptionNo, EnrollDate, EndDate,  CoverageAmount, LevelAmount, BenefitNote, EnterBy, EnterDate)
--SELECT 	 '+str(@empid)+','+str(@docno)+','+@Parameter2+',0,null,'+@Parameter1+','+@Parameter3+',CONVERT(nvarchar(10),t.enrolldate,111),null, t.CoverageAmount,t.LevelAmount,isnull(t.BenefitNote,''''),'+@Parameter4+',getdate()
--FROM '+@tablename+' t
--left join empassignment e on e.employeeid = t.empid
--WHERE t.post =1 and e.empid='+str(@empid)+' 
-- and  str('+ltrim(rtrim(str(@empid)))+'-'+ltrim(rtrim(str(@docno)))+')
--not IN (SELECT DISTINCT ltrim(rtrim(str(eb.EmpId)))+''-''+ltrim(rtrim(str(eb.documentno))) FROM EmpBenefit eb where eb.empid='+str(@empid)+' and eb.planno='+@Parameter1+' and eb.optionno='+@Parameter3+'  and eb.closed=0)'
--
--PRINT @SELECT
--EXECUTE (@SELECT)
--	
--
--
--
----SET @SELECT='INSERT INTO EmpBenefit (EmpId, DocumentNo, BenefitStatus, Closed, ProgramNo, PlanNo, OptionNo, EnrollDate, EndDate,  CoverageAmount, LevelAmount, BenefitNote, EnterBy, EnterDate)
----SELECT 	 '+str(@empid)+','+str(@docno)+','+@Parameter2+',0,null,'+@Parameter1+','+@Parameter3+',t.enrolldate,null, t.CoverageAmount,t.LevelAmount,isnull(t.BenefitNote,''''),'+@Parameter4+',getdate()
----FROM '+@tablename+' t
----WHERE t.post =1 
---- and  '+ltrim(rtrim(str(@empid)))+'
----not IN (SELECT DISTINCT ltrim(rtrim(str(eb.EmpId))) FROM EmpBenefit eb where eb.empid='+str(@empid)+' and eb.planno='+@Parameter1+' and eb.optionno='+@Parameter3+'  and eb.closed=0)'
--
--
--IF len(@Parameter5)>0
--BEGIN
--	IF EXISTS(SELECT * FROM EmpBenefit eb WHERE eb.EmpId=@empid AND eb.DocumentNo=@docno)
--	BEGIN
--	SET @SELECT='INSERT INTO WFDocument (DocumentNo, EmpID, SSDocNo,StartDate, EnterDate, EnterBy) 
--	values( '+str(@docno)+', '+str(@empid)+', '+@Parameter5+',getdate(), getdate(), '+@Parameter4+')'
--	
--	PRINT @SELECT
--	EXECUTE (@SELECT)	
--	END
--	
--
--END	
FETCH NEXT FROM benefitcursor
  INTO  @empid, @enrolldate, @CoverageAmount, @LevelAmount, @BenefitNote, @PlanSupplierNo,@PlanServiceNo,@cur_empid
  ,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath
END
CLOSE benefitcursor
DEALLOCATE benefitcursor

END




IF @actiontype=2 --export
BEGIN
		DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
		SET @t=@tablename
		SET @t=replace(@t,'dbo.[','')
		SET @t=replace(@t,']','')
		select @count=count(*) FROM sysobjects s WHERE s.name=@t
		
	
		IF @actual>0 SET @str='select 0 as empid,'''' as name,getdate() as enrolldate,0.00 as CoverageAmount,0.00 as LevelAmount, 0 as Supplier, 0 as Service,'''' as BenefitNote,'''' as remarks WHERE 1<>1'
		ELSE
			IF @count=1 SET @str='select * from '+@tablename
			ELSE
				SET @str='select 0 as empid,'''' as name,getdate() as enrolldate,0.00 as CoverageAmount,0.00 as LevelAmount,0 as Supplier, 0 as Service, 0 as post,'''' as BenefitNote,'''' as remarks WHERE 1<>1'
	exec sp_executesql @str
	
END

IF @actiontype=3 --import

	BEGIN
	 SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 
	DECLARE @Cursor_UDF as nCHAR(4) 
	DECLARE @updatestrUDF AS  NVARCHAR(max)=''
		DECLARE @updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@insertstrUDF AS NVARCHAR(max)='',@deletestr AS nvarchar(max),
	@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100)
	, @CreateStrRefAttach AS nvarchar(max)='', @SelectStrRefAttach AS nvarchar(max)='', @InsertStrRefAttach AS nvarchar(max)='', @UpdateStrRefAttach AS nvarchar(max)=''


	

 DECLARE update_cursor2 CURSOR FOR SELECT * FROM #UDFTemp 
   OPEN update_cursor2
   FETCH NEXT FROM update_cursor2 INTO @Cursor_UDF
   WHILE @@FETCH_STATUS = 0
    BEGIN
	   SET @updatestrUDF=@updatestrUDF+' UDF'+@Cursor_UDF+'=@UDF'+@Cursor_UDF+', '
     SET @insertstrUDF=' @UDF'+@Cursor_UDF+','	
     FETCH NEXT FROM update_cursor2 into @Cursor_UDF	
    END
  CLOSE update_cursor2
  
  --------------------------------------------------------------
  DEALLOCATE update_cursor2
	DECLARE @TableNamelen AS int 
	SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
	
		IF rtrim(ltrim(@tablename))<>'' 
		begin
		IF  @enableRef = 1
		  begin 
		  		   SET @CreateStrRefAttach='[RYear] [smallint],[RNo] [nvarchar](10),[RIssueDate] [datetime],[RExecDate] [datetime],[RStatus] [nvarchar](30),[RSource] [nvarchar](30),[RDesc] [nvarchar](max) ,'
		  end 

		IF @enableAttachments=1
		  begin 
		  		SET @CreateStrRefAttach= @CreateStrRefAttach+' AttDesc [nvarchar](max), AttPath [nvarchar](max),'
		  end 
		
		SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
        +' CREATE TABLE ' + @tablename+ ' (empid [nvarchar](256) ,name [nvarchar](256),
 	enrolldate datetime ,CoverageAmount	[numeric](18,3) ,LevelAmount [numeric](18,3),Supplier [nvarchar](256) collate database_default ,Service [nvarchar](256) collate database_default,'+@tabletype+  + @CreateStrRefAttach +' post bit,BenefitNote [nvarchar](256), remarks [nvarchar](256),[Row_Number] int Identity(1,1) NOT NULL Primary Key)'
 
  

    end 
		ELSE
			begin

			IF  @enableRef = 1
		  begin 
		  		   SET @CreateStrRefAttach='[RYear] [smallint],[RNo] [nvarchar](10),[RIssueDate] [datetime],[RExecDate] [datetime],[RStatus] [nvarchar](30),[RSource] [nvarchar](30),[RDesc] [nvarchar](max) ,'
		  end 

		IF @enableAttachments=1
		  begin 
		  		SET @CreateStrRefAttach= @CreateStrRefAttach+' AttDesc [nvarchar](max), AttPath [nvarchar](max),'
		  end 
			SET @tablename='  '
		 SET @selectstr='select 0 as empid,'''' as name,getdate() as enrolldate,0.00 as CoverageAmount,0.00 as LevelAmount,0 as Service, 0 as Supplier,'+@CreateStrRefAttach+'0 as post,'''' as BenefitNote,  '''' as remarks WHERE 1<>1'
			END
		PRINT @select	

		 -----------------------------------------------------------------------------------------------------	
  IF  @enableRef = 1 
  SET @UpdateStrRefAttach=' RYear=ltrim(rtrim(@RYear)), RNo=ltrim(rtrim(@RNo))
, RIssueDate=convert(datetime,@RIssueDate,'+ltrim(rtrim(str(@DateFormat)))+')
, RExecDate =convert(datetime,@RExecDate,'+ltrim(rtrim(str(@DateFormat)))+')
,RStatus=ltrim(rtrim(@RStatus)), RSource=ltrim(rtrim(@RSource)), RDesc=ltrim(rtrim(@RDesc)),'

IF @enableAttachments=1
  SET @UpdateStrRefAttach= @UpdateStrRefAttach+' AttDesc=ltrim(rtrim(@AttDesc)) , AttPath=ltrim(rtrim(@AttPath)) ,'


	SET @updatestr=' update '+@tablename+' 
   set enrolldate= Convert(smalldatetime,@enrolldate,'+ltrim(rtrim(str(@DateFormat)))+') 
      ,CoverageAmount=@CoverageAmount
      ,LevelAmount=@LevelAmount
	  ,BenefitNote=@BenefitNote 
	  ,Service=@Service 
	  ,Supplier=@Supplier
	  ,'+@updatestrUDF+@UpdateStrRefAttach+'post=@post 
      ,remarks =@remarks
	where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0) '
	   IF  @enableRef = 1  
	SET @InsertStrRefAttach=' @RYear, @RNo, @RIssueDate, @RExecDate 
					,@RStatus, @RSource, @RDesc, '
IF @enableAttachments=1
	SET @InsertStrRefAttach= @InsertStrRefAttach+' @AttDesc , @AttPath ,'
SET @insertstr=' insert into '+@tablename+' select @empid ,
 	@name ,@enrolldate ,@CoverageAmount ,@LevelAmount ,
 	@post ,@BenefitNote,@Supplier,@Service,'+@insertstrUDF+@UpdateStrRefAttach+'@remarks'

	

	SET @deletestr=' delete from  '+@tablename+' where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)  '
  
  

  SELECT @countUDF=COUNT(UDF) FROM #UDFTemp 
	  
	  SET @countUDF=@countUDF+10 -- 10 is number of other col before Remarks col without UDF cols
	 IF  @enableRef = 1  SET @countUDF=@countUDF+7
   IF  @enableAttachments = 1  SET @countUDF=@countUDF+2
	SET @DisabledColStr='1,2,'+ltrim(rtrim(str(@countUDF)))
	--	IF @lang='A' SET @hidecolstr='1,2,4,5,8'
	--	ELSE
			--SET @DisabledColStr='1,2,10,11'
			exec sp_executesql @select
			SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr

	END
	IF @actiontype=4
	BEGIN
		set @outputstr = 'select 0 as empid,'' '' as name,,getdate() as enrolldate,0.00 as CoverageAmount,0.00 as LevelAmount,0 as Service, 0 as Supplier,0 as post,'''' as BenefitNote, '''' as remarks
 , identity(int,1,1) as [Row_Number] into #EndResultPagging  where 1<>1 '--+ @filterwhere+' order by  '+@p_sort_str+' costcpay.center, costcpay.paycode'
	END
	 DROP TABLE #UDFTemp

GO

