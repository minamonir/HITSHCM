
CREATE PROCEDURE [dbo].[AI_InsertTrainingActivity] (
	@TrainingActivityName NVARCHAR(120)
	,@TrainingMethod NVARCHAR(60)
	,@TrainingDescription NVARCHAR(max)
	,@TrainingTotalHours NUMERIC(9, 3)
	,@TrainingAudience NVARCHAR(max)=''
	,@TrainingObjective NVARCHAR(max)
	,@TrainingMinStudent SMALLINT
	,@TrainingMaxStudent SMALLINT
	,@TrainingSuccess NVARCHAR(30) 
	
	,@PassDegree AS numeric(18, 3) 
	,@ValidityPeriod AS numeric(9, 3) 
	,@RequiredAttendance AS numeric(18, 3) 
	,@TrainingPrerequisites AS nvarchar(MAX) 
	,@EvaluationMethod AS NVARCHAR(MAX) 
	,@Supplier AS smallint 
	,@Organization AS smallint 
	,@Currency AS smallint 
	,@ActualCost AS numeric(18, 3) 
	,@BudgetCost AS numeric(18, 3) 
	,@IntranetPublish AS bit 
	

	,@LogonName NVARCHAR(80)
	,@ActivityNo AS SMALLINT OUTPUT
	)
AS
BEGIN
	DECLARE @TrainingMethodNo AS SMALLINT = 0;

	SET @ActivityNo = ISNULL((
				SELECT TOP 1 TrainingActivities.TrainingActivity
				FROM TrainingActivities
				WHERE LTRIM(RTRIM(TrainingActivityName)) = LTRIM(RTRIM(@TrainingActivityName))
					OR LTRIM(RTRIM(TrainingActivityAName)) = LTRIM(RTRIM(@TrainingActivityName))
				), 0)
	SET @TrainingMethodNo = ISNULL((
				SELECT TOP 1 TrainingMethods.TrainingMethod
				FROM TrainingMethods
				WHERE LTRIM(RTRIM(TrainingMethodName)) = LTRIM(RTRIM(@TrainingMethod))
					OR LTRIM(RTRIM(TrainingMethodAName)) = LTRIM(RTRIM(@TrainingMethod))
				), 0)

	IF @TrainingMethodNo = 0
	BEGIN
		CREATE TABLE #StoredResult (
			PrimaryKey INT
			,IsUEnterByExists INT
			,OrgsColumn INT
			);

		INSERT INTO #StoredResult
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'TrainingMethods'
			,@PkFieldName = N'TrainingMethod'
			,@LogonName = @LogonName;

		SELECT @TrainingMethodNo = PrimaryKey
		FROM #StoredResult;

		INSERT INTO [dbo].[TrainingMethods] (
			[TrainingMethod]
			,[TrainingMethodName]
			,[TrainingMethodAName]
			,[TrainingMethodFName]
			,[UEnterBy]
			)
		VALUES (
			@TrainingMethodNo
			,@TrainingMethod
			,@TrainingMethod
			,@TrainingMethod
			,@LogonName
			)
	END

	IF @ActivityNo = 0
	BEGIN
		CREATE TABLE #StoredResult2 (
			PrimaryKey INT
			,IsUEnterByExists INT
			,OrgsColumn INT
			);

		INSERT INTO #StoredResult2
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'TrainingActivities'
			,@PkFieldName = N'TrainingActivity'
			,@LogonName = @LogonName;

		SELECT @ActivityNo = PrimaryKey
		FROM #StoredResult2;

		INSERT INTO [dbo].[TrainingActivities] (
			[TrainingActivity]
			,[TrainingActivityName]
			,[TrainingActivityAName]
			,[TrainingActivityFName]
			,[TrainingMethod]
			,[TrainingDescription]
			,[TrainingADescription]
			,[TrainingFDescription]
			,[TrainingPrerequisites]
			,[TrainingAPrerequisites]
			,[TrainingFPrerequisites]
			,[TrainingEvaluationMethod]
			,[TrainingAEvaluationMethod]
			,[TrainingFEvaluationMethod]
			,[TrainingTotalHours]
			,[TrainingValidityperiod]
			,[TrainingAudience]
			,[TrainingAAudience]
			,[TrainingFAudience]
			,[TrainingObjective]
			,[TrainingAObjective]
			,[TrainingFObjective]
			,[TrainingMinStudent]
			,[TrainingMaxStudent]
			,[TrainingActualCost]
			,[TrainingBudgetCost]
			,[TrainingCurrency]
			,[TrainingSuccess]
			,[TrainingASuccess]
			,[TrainingFSuccess]
			,[SupplierNo]
			,[Organization]
			,[IntranetPublish]
			,[TrainingPassDegree]
			,[TrainingRequiredAttendance]
			,[TrainingActivityCons]
			,[TrainingActivityNameCons]
			,[TrainingActivityANameCons]
			,[TrainingActivityFNameCons]
			,[TrainingActivityFromDate]
			,[TrainingActivityToDate]
			,[TrainingActivitiesRoles]
			,[TrainingActivitiesOrgs]
			,[TrainingActivitiesRYear]
			,[TrainingActivitiesRNo]
			,[TrainingActivitiesRIssueDate]
			,[TrainingActivitiesRExecDate]
			,[TrainingActivitiesRStatus]
			,[TrainingActivitiesRSource]
			,[TrainingActivitiesRDesc]
			,[UEnterBy]
			,[UEnterDate]
			,[UChangeBy]
			,[UChangeDate]
			,[ReviewedBy]
			,[ReviewedDate]
			,[ApprovedBy]
			,[ApprovedDate]
			,[CodeStatus]
			,[TrainingActivitiesOrder]
			)
		VALUES (
			@ActivityNo
			,@TrainingActivityName
			,@TrainingActivityName
			,@TrainingActivityName
			,@TrainingMethodNo
			,@TrainingDescription
			,@TrainingDescription
			,@TrainingDescription
			,@TrainingPrerequisites
			,@TrainingPrerequisites
			,@TrainingPrerequisites
			,@EvaluationMethod
			,@EvaluationMethod
			,@EvaluationMethod
			,@TrainingTotalHours
			,@ValidityPeriod
			,@TrainingAudience
			,@TrainingAudience
			,@TrainingAudience
			,@TrainingObjective
			,@TrainingObjective
			,@TrainingObjective
			,@TrainingMinStudent
			,@TrainingMaxStudent
			,@ActualCost
			,@BudgetCost
			,@Currency
			,@TrainingSuccess
			,@TrainingSuccess
			,@TrainingSuccess
			,@Supplier
			,@Organization
			,@IntranetPublish
			,@PassDegree
			,@RequiredAttendance
			,0
			,''
			,''
			,''
			,NULL
			,NULL
			,''
			,''
			,0
			,''
			,NULL
			,NULL
			,NULL
			,NULL
			,''
			,@LogonName
			,GETDATE()
			,''
			,NULL
			,''
			,NULL
			,''
			,NULL
			,NULL
			,0
			)
	END
	ELSE
	BEGIN
		UPDATE TrainingActivities
		SET TrainingMethod = @TrainingMethodNo
			,TrainingDescription = @TrainingDescription
			,TrainingADescription = @TrainingDescription
			,TrainingFDescription = @TrainingDescription
			,TrainingTotalHours = @TrainingTotalHours
			,TrainingAudience = @TrainingAudience
			,TrainingAAudience = @TrainingAudience
			,TrainingFAudience = @TrainingAudience
			,TrainingObjective = @TrainingObjective
			,TrainingAObjective = @TrainingObjective
			,TrainingFObjective = @TrainingObjective
			,TrainingMinStudent = @TrainingMinStudent
			,TrainingMaxStudent = @TrainingMaxStudent
			,TrainingSuccess = @TrainingSuccess
			,TrainingASuccess = @TrainingSuccess
			,TrainingFSuccess = @TrainingSuccess

			,TrainingPassDegree= @PassDegree 
			,TrainingValidityperiod= @ValidityPeriod  
			,TrainingRequiredAttendance= @RequiredAttendance 
			,TrainingPrerequisites= @TrainingPrerequisites 
			,TrainingAPrerequisites= @TrainingPrerequisites
			,TrainingFPrerequisites= @TrainingPrerequisites
			,TrainingEvaluationMethod= @EvaluationMethod  
			,TrainingAEvaluationMethod= @EvaluationMethod  
			,TrainingFEvaluationMethod= @EvaluationMethod  
			,SupplierNo= @Supplier 
			,Organization= @Organization 
			,TrainingCurrency= @Currency 
			,TrainingActualCost= @ActualCost  
			,TrainingBudgetCost= @BudgetCost  
			,IntranetPublish= @IntranetPublish  

			,UChangeBy = @LogonName
			,UChangeDate = GETDATE()
		WHERE TrainingActivity = @ActivityNo
	END
END

GO

