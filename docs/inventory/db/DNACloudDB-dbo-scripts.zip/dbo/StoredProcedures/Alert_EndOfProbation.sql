
CREATE PROCEDURE [dbo].[Alert_EndOfProbation] @before AS INT , @period AS INT , @max AS INT	, @SubNo AS int , @AlertNo AS INT = 0 , @profileid AS INT =0 	
AS
BEGIN

DECLARE @ActProfileID AS INT
DECLARE @RoleName AS NVARCHAR(MAX)='' , @mailIndex AS INT 

	IF @SubNo = 6771 AND @profileid = 0   
	BEGIN
		SELECT  (t.EmpId *100)+ ROW_NUMBER()  OVER(PARTITION BY t.EmpId ORDER BY t.EmpId)  AS profileid
	    ,t.CompanyEmail AS CompanyEmail  
		FROM (	SELECT  DISTINCT Empassignment.EmpId ,  (CASE WHEN PROFILE.CompanyEmail <> '' THEN PROFILE.CompanyEmail ELSE PROFILE.PrivateEmail END) AS CompanyEmail
				FROM   SSGroupRole
       LEFT JOIN PROFILE ON  PROFILE.profileid = SSGroupRole.profileid
	   left JOIN Empassignment ON  Empassignment.SSGroup = SSGroupRole.ssgroup
	   left JOIN Empassignment RoleAssignment ON  RoleAssignment.EmpId = PROFILE.profileid
	   LEFT JOIN HrStatus RoleHrStatus ON  RoleHrStatus.hrstatus = RoleAssignment.hrstatus
		WHERE  (PROFILE.CompanyEmail <> '' OR PROFILE.PrivateEmail <> '')
	   AND RoleHrStatus.paystatus = 1
				AND ( CONVERT (SMALLDATETIME , CONVERT(CHAR(12) ,dbo.X_CalcProbationPeriod(dbo.EmpAssignment.EmpId,dbo.EmpAssignment.HireDate, @max, 1, 0,1) ),103)
				BETWEEN CONVERT(SMALLDATETIME, CONVERT(CHAR(12), DATEADD(d,@before,GETDATE())), 103)
        AND     CONVERT(SMALLDATETIME, CONVERT(CHAR(12), DATEADD(d,@before+ @period,GETDATE())), 103) )
				AND SSGroupRole.RoleId IN (100,456,350) 
				) t
		ORDER BY t.EmpId ASC, t.CompanyEmail ASC
	END	

	ELSE IF @AlertNo = 6771 AND @profileid <> 0  -- Aler No 6771 (After 30 Days)
	BEGIN
		
SET @mailIndex = RIGHT(LTRIM(RTRIM(STR(@profileid))) , 2)
SET @ActProfileID = CAST ( SUBSTRING(LTRIM(RTRIM(STR(@profileid))) , 1 , LEN(@profileid)-2)  AS int )

CREATE TABLE  #temp6771 ( RoleName NVARCHAR(max),RoleMail  nvarchar(MAX) , [Row_Number] int identity(1,1) PRIMARY KEY)

INSERT INTO  #temp6771
SELECT  DISTINCT  PROFILE.name ,CompanyEmail
				FROM   SSGroupRole
				LEFT JOIN PROFILE ON  PROFILE.profileid = SSGroupRole.profileid
				LEFT JOIN Empassignment ON  Empassignment.SSGroup = SSGroupRole.ssgroup
				LEFT JOIN Empassignment RoleAssignment ON  RoleAssignment.EmpId = PROFILE.profileid
				LEFT JOIN HrStatus RoleHrStatus ON  RoleHrStatus.hrstatus = RoleAssignment.hrstatus
				WHERE  (PROFILE.CompanyEmail <> '' OR PROFILE.PrivateEmail <> '')
				AND RoleHrStatus.paystatus = 1
				AND ( CONVERT (SMALLDATETIME , CONVERT(CHAR(12) ,dbo.X_CalcProbationPeriod(dbo.EmpAssignment.EmpId,dbo.EmpAssignment.HireDate, @max, 1, 0,1) ),103)
				BETWEEN CONVERT(SMALLDATETIME, CONVERT(CHAR(12), DATEADD(d,@before,GETDATE())), 103)
				AND     CONVERT(SMALLDATETIME, CONVERT(CHAR(12), DATEADD(d,@before+ @period,GETDATE())), 103) )
				AND Empassignment.EmpId = @ActProfileID
				AND SSGroupRole.RoleId IN (100,456,350) 
				ORDER BY  CompanyEmail ASC 

SELECT @RoleName = LTRIM(RTRIM(RoleName)) FROM  #temp6771  WHERE Row_Number = @mailIndex


DROP TABLE	#temp6771

SELECT  
N'Dear ' + @RoleName+',' AS Header, 
N'The probation period for '+LTRIM(RTRIM(profile.Name))+' is due to end on approximately @ProbDate.' AS Body1,
N'On @ProbationPeriodDate, they would have completed 30 days working in ABK.
Kindly meet with the employee to discuss performance and establish scorecard objectives.
The objectives should be recorded on their Success Factors Profile' AS Body2,
N'Thank you.' AS Footer ,
        dbo.EmpAssignment.ProbDate AS ProbDate ,
		dbo.X_CalcProbationPeriod(dbo.EmpAssignment.EmpId,dbo.EmpAssignment.HireDate, @max, 1, 0, 1) AS ProbationPeriodDate,
        ( CASE WHEN SysParam.DateFormat = 0 THEN 'yyyy/MM/dd'
               WHEN SysParam.DateFormat = 1 THEN 'dd/MM/yyyy'
               ELSE 'MM/dd/yyyy'
          END ) AS DateFormat ,
        'EndSelect' 
FROM    EmpAssignment
        LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId
        CROSS JOIN SysParam
WHERE dbo.EmpAssignment.empid = @ActProfileID
	END
    
	ELSE IF @AlertNo = 6772 AND @profileid <> 0  -- Aler No 6772 (After 80 Days)
	BEGIN
		
SET @mailIndex = RIGHT(LTRIM(RTRIM(STR(@profileid))) , 2)
SET @ActProfileID = CAST ( SUBSTRING(LTRIM(RTRIM(STR(@profileid))) , 1 , LEN(@profileid)-2)  AS int )

CREATE TABLE  #temp6772 ( RoleName NVARCHAR(max),RoleMail  nvarchar(MAX) , [Row_Number] int identity(1,1) PRIMARY KEY)

INSERT INTO  #temp6772
SELECT  DISTINCT  PROFILE.name ,CompanyEmail
				FROM   SSGroupRole
				LEFT JOIN PROFILE ON  PROFILE.profileid = SSGroupRole.profileid
				LEFT JOIN Empassignment ON  Empassignment.SSGroup = SSGroupRole.ssgroup
				LEFT JOIN Empassignment RoleAssignment ON  RoleAssignment.EmpId = PROFILE.profileid
				LEFT JOIN HrStatus RoleHrStatus ON  RoleHrStatus.hrstatus = RoleAssignment.hrstatus
				WHERE  (PROFILE.CompanyEmail <> '' OR PROFILE.PrivateEmail <> '')
				AND RoleHrStatus.paystatus = 1
				AND ( CONVERT (SMALLDATETIME , CONVERT(CHAR(12) ,dbo.X_CalcProbationPeriod(dbo.EmpAssignment.EmpId,dbo.EmpAssignment.HireDate, @max, 1, 0,1) ),103)
				BETWEEN CONVERT(SMALLDATETIME, CONVERT(CHAR(12), DATEADD(d,@before,GETDATE())), 103)
				AND     CONVERT(SMALLDATETIME, CONVERT(CHAR(12), DATEADD(d,@before+ @period,GETDATE())), 103) )
				AND Empassignment.EmpId = @ActProfileID
				AND SSGroupRole.RoleId IN (100,456,350) 
				ORDER BY  CompanyEmail ASC 

SELECT @RoleName = LTRIM(RTRIM(RoleName)) FROM  #temp6772  WHERE Row_Number = @mailIndex


DROP TABLE	#temp6772

SELECT  
N'Dear ' + @RoleName+',' AS Header, 
N'The probation period for '+LTRIM(RTRIM(profile.Name))+' is due to end on approximately @ProbDate.' AS Body1,
N'On @ProbationPeriodDate, they would have completed 80 days working in ABK.
Please login to HITS and fill out their probation assessment form.' AS Body2 ,
N'Thank you.' AS Footer ,
        dbo.EmpAssignment.ProbDate AS ProbDate ,
		dbo.X_CalcProbationPeriod(dbo.EmpAssignment.EmpId,dbo.EmpAssignment.HireDate, @max, 1, 0, 1) AS ProbationPeriodDate,
        ( CASE WHEN SysParam.DateFormat = 0 THEN 'yyyy/MM/dd'
               WHEN SysParam.DateFormat = 1 THEN 'dd/MM/yyyy'
               ELSE 'MM/dd/yyyy'
          END ) AS DateFormat ,
        'EndSelect' 
FROM    EmpAssignment
        LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId
        CROSS JOIN SysParam
WHERE dbo.EmpAssignment.empid = @ActProfileID
	END


END

GO

