

CREATE PROCEDURE [dbo].[AI_InsertTrainingActivitiesCompetences] 
	@ActivityNo SMALLINT
	,@CompetenceName NVARCHAR(120)
	,@LevelBefore NCHAR(6) -- scale level key
	,@LevelAfter NCHAR(6) -- scale level key
	,@LogonName NVARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CompetenceNo AS SMALLINT = 0,
			@RatingScale AS SMALLINT = 0

	SET @CompetenceNo = ISNULL((
				SELECT TOP 1 Competencies.Competence
				FROM Competencies
				WHERE LTRIM(RTRIM(Competencies.CompetenceName)) = LTRIM(RTRIM(@CompetenceName))
					OR LTRIM(RTRIM(Competencies.CompetenceAName)) = LTRIM(RTRIM(@CompetenceName))
				), 0);

	-- sets it to the first RatingScale if there is no sysparamconfig
	SET @RatingScale = ISNULL((
					SELECT TOP 1 CAST(ConfigValue AS SMALLINT)
					FROM SysParamConfig 
					WHERE ConfigID = 'DefaultRatingScaleAI'
				), 1) 

	IF @CompetenceNo = 0
	BEGIN
		CREATE TABLE #StoredResult4 (
			PrimaryKey INT
			,IsUEnterByExists INT
			,OrgsColumn INT
			);

		INSERT INTO #StoredResult4
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Competencies'
			,@PkFieldName = N'Competence'
			,@LogonName = @LogonName;

		SELECT @CompetenceNo = PrimaryKey
		FROM #StoredResult4;

		DROP TABLE #StoredResult4

		INSERT INTO [dbo].[Competencies] (
			[Competence]
			,[CompetenceCategory]
			,[CompetenceName]
			,[CompetenceAName]
			,[CompetenceFName]
			,[CompetenceDesc]
			,[CompetenceADesc]
			,[CompetenceFDesc]
			,[RatingScale]
			,[UEnterBy]
			,[UEnterDate]
			)
		VALUES (
			@CompetenceNo
			,NULL
			,@CompetenceName
			,@CompetenceName
			,@CompetenceName
			,''
			,''
			,''
			,@RatingScale
			,@LogonName
			,GETDATE()
			)
	END
	ELSE
	BEGIN
		UPDATE Competencies 
		SET RatingScale = @RatingScale,
			UChangeBy = @LogonName,
			UChangeDate = GETDATE()
		WHERE Competence = @CompetenceNo
	END

	IF NOT EXISTS (SELECT * 
				FROM TrainingActivityCompetence 
				WHERE TrainingActivity = @ActivityNo AND Competence = @CompetenceNo)
	BEGIN
		INSERT INTO TrainingActivityCompetence(TrainingActivity, Competence, LevelBefore, LevelAfter)
		VALUES(
			@ActivityNo,
			@CompetenceNo,
			CAST(@LevelBefore AS SMALLINT),
			CAST(@LevelAfter AS SMALLINT)
		)
	END
	ELSE
	BEGIN 
		-- Update
		UPDATE TrainingActivityCompetence
		SET LevelBefore = CAST(@LevelBefore AS SMALLINT),
			LevelAfter = CAST(@LevelAfter AS SMALLINT)
		WHERE TrainingActivity = @ActivityNo AND Competence = @CompetenceNo
	END
END

GO

