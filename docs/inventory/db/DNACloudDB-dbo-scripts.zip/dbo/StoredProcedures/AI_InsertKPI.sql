
CREATE PROCEDURE [dbo].[AI_InsertKPI](@JobName as nvarchar(max),@KPIName as nvarchar(max),@KPIDescription as nvarchar(max),@Weight as numeric(18,3),@Target as numeric(18,3),@ObjectiveParentId as int)

AS
BEGIN
	declare @KPINo as int=0
	--set @KPINo = isnull((select top 1 Objectives.ObjectiveId from Objectives where ltrim(rtrim(Objectives.ObjectiveName))=ltrim(rtrim(@KPIName)) or ltrim(rtrim(Objectives.ObjectiveAName))=ltrim(rtrim(@KPIName))),0)



--if @KPINo =0
--begin
--CREATE TABLE #StoredResult3 (
--					PrimaryKey INT,
--					IsUEnterByExists INT,
--					OrgsColumn INT
--				);
 
--				INSERT INTO #StoredResult3
--				EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Objectives', @PkFieldName = N'ObjectiveId', @LogonName = '1';
 
--				SELECT @KPINo = PrimaryKey FROM #StoredResult3;

--drop table #StoredResult3
--INSERT INTO [dbo].[Objectives]
--           ([ObjectiveId]
--          ,[ObjectiveParentId]
--           ,[ObjectiveStartDate]
--          -- ,[ObjectiveEndDate]
--           ,[ObjectiveName]
--           ,[ObjectiveAName]
--           ,[ObjectiveFName]
--           ,[ObjectiveText]
--           ,[ObjectiveAText]
--           ,[ObjectiveFText]
--           --,[AssignObjective]
--           --,[ShareObjective]
--           --,[CalcMethod]
--           --,[HideMax]
--           --,[HideThreshold]
--           --,[MaxCompletion]
--           --,[ObjectiveIdCons]
--           --,[ObjectiveNameCons]
--           --,[ObjectiveANameCons]
--           --,[ObjectiveFNameCons]
--           --,[ObjectivesRYear]
--           --,[ObjectivesRNo]
--           --,[ObjectivesRIssueDate]
--           --,[ObjectivesRExecDate]
--           --,[ObjectivesRStatus]
--           --,[ObjectivesRSource]
--           --,[ObjectivesRDesc]
--           --,[ObjectivesGUID]
--           --,[ObjectiveDimenssionCategory]
--		   )
--     VALUES
--           (@KPINo
--          ,@ObjectiveParentId
--           ,GETDATE()
--           --,<ObjectiveEndDate, smalldatetime,>
--           ,@KPIName
--           ,@KPIName
--           ,@KPIName
--           ,@KPIDescription
--           ,@KPIDescription
--           ,@KPIDescription
--           --,<AssignObjective, bit,>
--           --,<ShareObjective, bit,>
--           --,<CalcMethod, smallint,>
--           --,<HideMax, bit,>
--           --,<HideThreshold, bit,>
--           --,<MaxCompletion, numeric(18,3),>
--           --,<ObjectiveIdCons, int,>
--           --,<ObjectiveNameCons, nvarchar(250),>
--           --,<ObjectiveANameCons, nvarchar(250),>
--           --,<ObjectiveFNameCons, nvarchar(250),>
--           --,<ObjectivesRYear, smallint,>
--           --,<ObjectivesRNo, nvarchar(10),>
--           --,<ObjectivesRIssueDate, datetime,>
--           --,<ObjectivesRExecDate, datetime,>
--           --,<ObjectivesRStatus, smallint,>
--           --,<ObjectivesRSource, smallint,>
--           --,<ObjectivesRDesc, nvarchar(max),>
--           --,<ObjectivesGUID, uniqueidentifier,>
--           --,<ObjectiveDimenssionCategory, int,>
--		   )

--end
--else
--begin
--update Objectives set ObjectiveText=@KPIDescription where ObjectiveId=@KPINo
--end

declare @JobNo as smallint=0
set @JobNo = isnull((select top 1 Jobs.job from Jobs where ltrim(rtrim(JobName))=ltrim(rtrim(@JobName)) or ltrim(rtrim(JobAName))=ltrim(rtrim(@JobName))),0)

if @JobNo=0
begin
CREATE TABLE #StoredResult2 (
					PrimaryKey INT,
					IsUEnterByExists INT,
					OrgsColumn INT
				);
 
				INSERT INTO #StoredResult2
				EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Jobs', @PkFieldName = N'job', @LogonName = '1';
 
				SELECT @JobNo = PrimaryKey FROM #StoredResult2;
insert into Jobs(job,JobName,JobAName,JobFName)
select @JobNo,@JobName,@JobName,@JobName
drop table #StoredResult2
end

set @KPINo = isnull((select top 1 JobKPIs.KPI from JobKPIs where job=@JobNo AND (ltrim(rtrim(@KPIName))=ltrim(rtrim([KPIName])) or ltrim(rtrim([KPIAName]))=ltrim(rtrim(@KPIName)))),0)

if @KPINo =0
begin
declare @where as nvarchar(max)=' job= '+str(@JobNo)
CREATE TABLE #StoredResult3 (
					PrimaryKey INT,
					IsUEnterByExists INT,
					OrgsColumn INT
				);
 
				INSERT INTO #StoredResult3
				EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'JobKPIs', @PkFieldName = N'KPI', @LogonName = '1',@Where= @where
 
				SELECT @KPINo = PrimaryKey FROM #StoredResult3;

drop table #StoredResult3
end

if not exists(select * from JobKPIs where job=@JobNo AND (ltrim(rtrim(@KPIName))=ltrim(rtrim([KPIName])) or ltrim(rtrim([KPIAName]))=ltrim(rtrim(@KPIName))))
begin
INSERT INTO [dbo].[JobKPIs]
           ([Job]
           ,[KPI]
           ,[KPIName]
           ,[KPIAName]
           ,[KPIFName]
           ,[KPICategory]
           ,[KPIWeight]
           ,[KPITarget]
           --,[KPIText]
           --,[KPIAText]
           --,[KPIAFText]
           --,[JobKPIsGUID]
		   )
     VALUES
           (@JobNo
           ,@KPINo
           ,@KPIName
           ,@KPIName
           ,@KPIName
           ,@ObjectiveParentId
           ,@Weight
           ,@Target
           --,<KPIText, nvarchar(max),>
           --,<KPIAText, nvarchar(max),>
           --,<KPIAFText, nvarchar(max),>
           --,<JobKPIsGUID, uniqueidentifier,>
		   )
end
else
begin
update JobKPIs set KPIWeight=@Weight,KPITarget=@Target,KPICategory=@ObjectiveParentId where job=@JobNo and JobKPIs.KPI=@KPINo
end

END

GO

