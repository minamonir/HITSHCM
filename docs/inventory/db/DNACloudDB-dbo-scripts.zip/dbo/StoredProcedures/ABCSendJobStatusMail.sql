
CREATE   PROCEDURE [dbo].[ABCSendJobStatusMail]
	AS
BEGIN
declare @JobName as nvarchar(max),@JobId as nvarchar(max),@SqlMailTo as nvarchar(max)='abanoubm@hitstechnology.com',@JobStatus as smallint,@NamePrefix as nvarchar(max)=''
select @NamePrefix = ltrim(rtrim(isnull(edesc,'')))+ ' ' +ltrim(rtrim(FirstName)) from Profile 
left join NasArrays on NamePrefix=NasArrays.itemno and arrayname='nameprefix'
where CompanyEmail=@SqlMailTo

select top 1 @JobName = ltrim(rtrim(msdb.dbo.sysjobs.name)),
@JobId=sysjobs.job_id , @JobStatus=msdb.dbo.sysjobhistory.run_status
from msdb.dbo.sysjobs 
left join msdb.dbo.sysjobhistory on msdb.dbo.sysjobs.job_id=msdb.dbo.sysjobhistory.job_id
where sysjobs.job_id='0B180614-754E-489A-A314-8F0F22944250' and msdb.dbo.sysjobhistory.step_id=1
and run_date= CONVERT(VARCHAR(10), getdate(), 112)
order by run_date desc, run_time desc 
--select @JobName,@JobId,@JobStatus

if not exists (
select CONVERT(VARCHAR(10), sqlmailcreateddate, 111) from SQLMailLog
where SQLMailTo=@SqlMailTo and SQLMailSubject='('+@JobName+') status mail' and CONVERT(VARCHAR(10), sqlmailcreateddate, 111) = CONVERT(VARCHAR(10), getdate(), 111)) and @JobStatus in (0,1,3)
begin
declare @Getdate as datetime
select @Getdate= GETDATE()

 insert into SQLMailLog( SQLMailTo,SQLMailSubject,SQLMailBody,SQLMailCreatedDate,SQLMailSentDate)
select top 1 @SqlMailTo, '('+@JobName+') status mail',
'Dear '+ isnull(@NamePrefix,'') +','+ CHAR(13) + 'Kindly be informed the job ('+@JobName+')' + case when msdb.dbo.sysjobhistory.run_status =0 then ' Failed.'
  when msdb.dbo.sysjobhistory.run_status = 1 then ' Succeeded.' 
 -- when msdb.dbo.sysjobhistory.run_status = 2 then ' Retry.'
  when msdb.dbo.sysjobhistory.run_status = 3 then ' Canceled.' 
 -- when msdb.dbo.sysjobhistory.run_status = 4 then ' In Progress.' 
end  + CHAR(13)+CHAR(13) + message
,@Getdate,@Getdate
from msdb.dbo.sysjobhistory where job_id=@JobId and step_id=1
and run_date= CONVERT(VARCHAR(10), getdate(), 112)
order by msdb.dbo.sysjobhistory.run_date desc,msdb.dbo.sysjobhistory.run_time desc
--select @Getdate,@SqlMailTo

--select * from  SQLMailLog  where CONVERT(VARCHAR(20),SQLMailCreatedDate,120)=CONVERT(VARCHAR(20),@Getdate,120) and SQLMailTo=@SqlMailTo
update SQLMailLog set SQLMailSentDate=GETDATE() where  SQLMailSentDate is null and SQLMailSubject='('+@JobName+') status mail' and SQLMailTo=@SqlMailTo
select top 1 'Dear '+ isnull(@NamePrefix,'') +',' as header,
'Kindly be informed the job ('+@JobName+')' + case when msdb.dbo.sysjobhistory.run_status =0 then ' Failed.'
  when msdb.dbo.sysjobhistory.run_status = 1 then ' Succeeded.' 
  --when msdb.dbo.sysjobhistory.run_status = 2 then ' Retry.'
  when msdb.dbo.sysjobhistory.run_status = 3 then ' Canceled.' 
  --when msdb.dbo.sysjobhistory.run_status = 4 then ' In Progress.' 
end  as body ,   
case when msdb.dbo.sysjobhistory.run_status =0 then 
message else '' end 
as msg
from msdb.dbo.sysjobhistory 
where sysjobhistory.job_id=@JobId and step_id=1
and run_date= CONVERT(VARCHAR(10), getdate(), 112)
order by msdb.dbo.sysjobhistory.run_date desc,msdb.dbo.sysjobhistory.run_time desc

end

END

GO

