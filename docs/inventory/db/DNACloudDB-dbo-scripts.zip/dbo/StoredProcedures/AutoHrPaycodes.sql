CREATE PROCEDURE [dbo].[AutoHrPaycodes]
@DocumentStatus nvarchar(1) = '1'
, @ChgCode nvarchar(5) = '92'
, @EnterBy nvarchar(10) = '99999999'
, @ExcludePCode nvarchar(max) = ''
, @filterWhere nvarchar(max)
AS
begin

declare @STR nvarchar(max);
set @STR
    = N'if EXISTS(SELECT * FROM dbo.HrPCodes
WHERE inputamnt <>0)
BEGIN
INSERT INTO EmpStatusHdr(EmpId, DocumentNo, DocumentStatus,  ChgCode, EffectiveDate, HRCurrency,EnterBy)
SELECT DISTINCT HrPCodes.empid,dbo.GetDocumentNo(HrPCodes.empid,1),' + @DocumentStatus + N',' + @ChgCode
      + N',CAST(CAST(YEAR(GETDATE()) AS NVARCHAR(4))+''-''+CAST(MONTH(GETDATE()) AS NVARCHAR(2))+''-10'' AS SMALLDATETIME),EmpAssignment.HrCurrency,'
      + @EnterBy
      + N' FROM HrPCodes 
INNER JOIN dbo.EmpAssignment ON EmpAssignment.EmpId = HrPCodes.empid
inner join Paycode on HrPCodes.paycode = Paycode.code
WHERE inputamnt <>0
and Paycode.freq=2
 and HrPCodes.paycode not in ('
      + case when ltrim(rtrim(isnull(@ExcludePCode, ''))) = '' then '0' else @ExcludePCode end + N') 
' + @filterWhere
      + N'

/****************************************************/

insert EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
select HrPCodes.EmpId,max(EmpStatusHdr.DocumentNo),1000+HrPCodes.paycode,0
from EmpStatusHdr
inner join HrPCodes on EmpStatusHdr.EmpId = HrPCodes.empid
inner join Paycode on HrPCodes.paycode = Paycode.code

where HrPCodes.inputamnt <>0
and EmpStatusHdr.ChgCode=92
and Paycode.freq=2
and HrPCodes.paycode not in (' + case when ltrim(rtrim(isnull(@ExcludePCode, ''))) = '' then '0' else @ExcludePCode end
      + N') 
' + @filterWhere + N'

group by HrPCodes.empid,HrPCodes.paycode

END
';
exec (@STR);

end;

GO

