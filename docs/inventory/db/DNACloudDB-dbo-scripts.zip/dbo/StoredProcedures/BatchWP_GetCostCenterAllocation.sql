
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[BatchWP_GetCostCenterAllocation]
	
(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS smallint,@Where AS nvarchar(max),@Paramaters AS nvarchar(max),@outputstr AS nvarchar(max)output) AS
DECLARE @SELECT AS nvarchar(max)



IF @actiontype=1
begin
--

--SET @SELECT='delete MEmpCntr FROM MEmpCntr INNER JOIN EmpAssignment ON MEmpCntr.empid = EmpAssignment.EmpId
--INNER JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup
--LEFT JOIN '+@tablename+' ON EmpAssignment.employeeid = '+@tablename+'.empid
--where MEmpCntr.empid=EmpAssignment.empid and MEmpCntr.runno=payrollgroup.runno and  
--post=1 and convert(numeric,Percentage,3) <>0.0 and (ltrim(rtrim(remarks))  ='''' or remarks is null )'

SET @SELECT='delete MEmpCntr FROM MEmpCntr INNER JOIN EmpAssignment ON MEmpCntr.empid = EmpAssignment.EmpId
INNER JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup
LEFT JOIN '+@tablename+' ON EmpAssignment.employeeid = '+@tablename+'.empid
where MEmpCntr.empid=EmpAssignment.empid and MEmpCntr.runno=payrollgroup.runno AND MEmpCntr.center= '+@tablename+'.CostCenter and  
post=1 and convert(numeric,Percentage,3) =0.0 and (ltrim(rtrim(remarks))  ='''' or remarks is null ) '


PRINT @SELECT
EXECUTE (@SELECT)

SET @SELECT= 'INSERT INTO MEmpCntr (empid, center, runno, cntpercent)
 select EmpAssignment.Empid,'+@tablename+'.CostCenter,payrollgroup.runno,'+@tablename+'.Percentage FROM '+ @tablename +
 ' LEFT JOIN EmpAssignment ON EmpAssignment.employeeid = '+@tablename+'.empid 
 INNER JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
 WHERE post=1 and  convert(numeric,Percentage,3)<>0.0 and (ltrim(rtrim(remarks))  ='''' or remarks is null )
 and EmpAssignment.employeeid='+@tablename+'.empid and isnull(empassignment.center,0)<>CostCenter'


PRINT @SELECT
EXECUTE (@SELECT)
END

IF @actiontype=2
BEGIN
		DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
		SET @t=parsename(@tablename,1)
		select @count=count(*) FROM sysobjects s WHERE s.name=@t
		
	
		IF @actual>0 SET @str='select 0 as empid,'''' as name,0 as CostCenter ,'''' as CostCenterName ,0.00 as Percentage ,0 as post,'''' as remarks  WHERE 1<>1'
		ELSE
			IF @count=1 SET @str='select * from '+@tablename
			ELSE
				SET @str='select 0 as empid,'''' as name,0 as CostCenter ,'''' as CostCenterName ,0.00 as Percentage ,0 as post,'''' as remarks  WHERE 1<>1'
	exec sp_executesql @str
	
END

IF @actiontype=3

	BEGIN
		DECLARE @updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
	@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100)

		IF rtrim(ltrim(@tablename))<>'' 
--		
BEGIN
--	 SET @select='   CREATE TABLE ' + @tablename+ ' (empid [nvarchar](256) ,name [nvarchar](256),
--	Days [nvarchar](256) ,Remarks [nvarchar](256) ,post	bit)'
DECLARE @TableNamelen AS int 
SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'CREATE TABLE ' + @tablename+ ' (empid [nvarchar](256) ,name [nvarchar](256),
	CostCenter [nvarchar](256) ,CostCenterName [nvarchar](256),Percentage numeric(18,3),post	bit,Remarks [nvarchar](256),[Row_Number] int Identity(1,1) NOT NULL Primary Key )'
END 

		ELSE
			begin
			SET @tablename='  '
		 SET @selectstr='select 0 as empid,'''' as name,0 as CostCenter ,'''' as CostCenterName ,0.00 as Percentage ,0 as post,'''' as remarks  WHERE 1<>1'
			END
			
	SET @updatestr=' update '+@tablename+' set post=@post
	where isnull(ltrim(rtrim(empid)),0)=isnull(ltrim(rtrim(@originalempid)),0)'
	   
SET @insertstr=' insert into '+@tablename+' select @empid ,
 	@name ,@CostCenter ,@CostCenterName,@Percentage,@post,@remarks'

	SET @deletestr=' delete from  '+@tablename+' where isnull(ltrim(rtrim(empid)),0)=isnull(ltrim(rtrim(@originalempid)),0) '

	--	IF @lang='A' SET @hidecolstr='1,2,4,5'
	--	ELSE
			SET @DisabledColStr='1,2,3,4,5,7'
			exec sp_executesql @select
			SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr

	END
	IF @actiontype=4
	BEGIN
		set @outputstr = 'select 0 as empid,'''' as name,0.00 as Days ,'''' as remarks ,0 as post
 , identity(int,1,1) as [Row_Number] into #EndResultPagging  where 1<>1 '--+ @filterwhere+' order by  '+@p_sort_str+' costcpay.center, costcpay.paycode'

	END

GO

