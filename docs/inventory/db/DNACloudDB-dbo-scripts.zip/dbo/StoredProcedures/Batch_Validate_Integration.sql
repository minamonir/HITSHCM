
Create    PROCEDURE [dbo].[Batch_Validate_Integration]  (@tablename AS nvarchar(150),@LogonName nchar(80),@Paycode AS int,@tabletype AS nvarchar(max),@lang AS nchar(1)) 
AS
BEGIN
	
	DECLARE @DateFormat AS INT
	DECLARE @pcodeno AS INT 
	DECLARE @DecimalScale AS INT
    SELECT  @DecimalScale= decimalscale FROM SysParam
	DECLARE 

	  @NatnNoLength INT = 0
	, @NatnNoUnique INT =0
	, @NatnNoMandatory INT = 0
	, @NatnlNoUniqueActiveInsertOnly AS INT = 0
	, @FileNoRequired INT = 0,@FileNoExistAndUnique INT = 0
	, @BirthdateNatnlNoConflict  AS INT = 0		            -- Birthdate NatnlNo Validation
	, @NatnlNoFirstDigitCheck AS INT = 0
	,@PassportorNatnlnoRequired as int = 0					-- Passport is required for all nations except Egyptians , for Egyptians National no. is required


	DECLARE @empid AS int,@ApplySSGroups AS bit,@PrivacyLevelFrom AS int,@PrivacyLevelTo AS int,@str AS nvarchar(max)
	DECLARE @errormsg AS nvarchar(max)

 	select  @empid=empid , @ApplySSGroups =ApplySSGroups , @PrivacyLevelFrom=PrivacyLevelFrom,@PrivacyLevelTo=PrivacyLevelTo
	from nasusers
	CROSS JOIN SysParam
	where @logonname=logonname 

------------------------------------ WP_ExternalSystemsBatchPosting -----------------------------------------------------

	IF LTRIM(rtrim(@tabletype)) LIKE '%WP_ExternalSystemsBatchPosting%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_ExternalSystemsBatchPosting_ar%'
	BEGIN
		
	select @str='UPDATE '+@tablename+' set post= 1
	FROM '+@tablename+' temptable'
	--print @str7
	EXECUTE(@str)

	select @str='UPDATE '+@tablename+' set processed= ''''
	FROM '+@tablename+' temptable
	where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	--PRINT @str2
	EXECUTE(@str)
	                        
	SELECT @errormsg= isnull(dbo.Hits_GetDCCaption('common','errormsg',@lang),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not a valid employee'  end))        
	
	select @str='UPDATE '+@tablename+' set processed=processed+ rtrim(ltrim(N'''+@errormsg+'''))+char(13) ,post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.EmployeeId collate database_default=empassignment.EmployeeId collate database_default
	and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	'WHERE EmpAssignment.empid IS null  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '  
		print 1111
		PRINT @str
	
	EXECUTE(@str)

	SELECT @errormsg= isnull(dbo.Hits_GetDCCaption('WP_ExternalSystemsBatchPosting','errormsg2',@lang),(case when @lang='A' then N'الضريبة لا تسمح بدخول حروف' ELSE N'Emp901Tax should only contain Numbers'  end))                          
	SELECT @str='UPDATE '+@tablename+' set processed=rtrim(ltrim(processed) + ltrim(N'''+@errormsg+''')) +char(13) , post=0  
	FROM '+@tablename+' temptable
	WHERE  ISNumeric(emp901tax) = 0
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	PRINT @str
	EXECUTE(@str)


		SELECT @errormsg= isnull(dbo.Hits_GetDCCaption('wp_ExternalStystemBatchPosting','InactiveEmployee',@lang),(case when @lang='A' then N'الموظف غير عامل' ELSE N'Inactive Employee'  end))                          
	SELECT @str='UPDATE '+@tablename+' set processed=rtrim(ltrim(processed) + ltrim(N'''+@errormsg+''')) +char(13) , post=0  
	FROM '+@tablename+' temptable
	LEFT JOIN EmpAssignment ON temptable.EmployeeId collate database_default=empassignment.EmployeeId collate database_default and EmpAssignment.Status=0
	 WHERE EmpAssignment.empid IS NOT NULL and  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	PRINT @str
	EXECUTE(@str)

	END

END

GO

