

CREATE PROCEDURE [dbo].[AI_AddApplicantCV]
	@ProfileID INT,
	@AttachmentPath AS NVARCHAR(MAX), 
	@logonName NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON;
	declare @enterby int
	select @EnterBy=empid from nasusers where LogonName=@LogonName
	IF NOT EXISTS(SELECT 1 FROM ProfileAttachment WHERE ProfileID = @ProfileID AND AttachmentPath = @AttachmentPath)
	BEGIN
		INSERT INTO ProfileAttachment (ProfileID, DocumentNo, AttachmentDescription, AttachmentADescription, AttachmentPath, EnterBy, EnterDate)
		VALUES (@ProfileID,
			dbo.GetDocumentNo(@ProfileID, 11),
			'CV', 
			'CV',
			@AttachmentPath, 
			@EnterBy, 
			GETDATE())
	END

END

GO

