CREATE PROCEDURE [dbo].[AI_InsertEstablishment]
(
    @Establishment SMALLINT = NULL OUTPUT,
    @EstablishmentName NVARCHAR(60)=N'',
    @EstablishmentAName NVARCHAR(60)=N'',
    @EstablishmentFName NVARCHAR(60)=N'',
    @EstablishmentType SMALLINT,
    @EstablishmentAddress NVARCHAR(200)=N'',
    @EstablishmentContact NVARCHAR(60)=N'',
    @ContactTitle NVARCHAR(60)=N'',
    @EstablishmentCons INT=0,
    @EstablishmentNameCons NVARCHAR(250)=N'',
    @EstablishmentANameCons NVARCHAR(250)=N'',
    @EstablishmentFNameCons NVARCHAR(250)=N'',
    @EstablishmentRoles NVARCHAR(MAX)=N'',
    @EstablishmentOrgs NVARCHAR(MAX)=N'',
    @EstablishmentRYear SMALLINT=0,
    @EstablishmentRNo NVARCHAR(10)=N'',
    @EstablishmentRDesc NVARCHAR(MAX)=N'',
    @UEnterBy NVARCHAR(80)=N'',
	@UEnterDate SMALLDATETIME=NULL,
    @UChangeBy NVARCHAR(80)=N'',
	@UChangeDate  SMALLDATETIME=NULL,
    @ReviewedBy NVARCHAR(80)=N'',
    @ApprovedBy NVARCHAR(80)=N'',
    @EstablishmentOrder INT=0
)
AS
BEGIN
    SET NOCOUNT ON;

		IF NULLIF(LTRIM(RTRIM(@EstablishmentName)), '') IS NULL
		BEGIN
			SET @Establishment = NULL;  
			RETURN;                    
		END


    DECLARE @ExistingEstablishment SMALLINT;
    
    /* =========================================================
       Check if establishment already exists
       ========================================================= */
    SELECT @ExistingEstablishment = Establishment
    FROM dbo.Establishment
    WHERE EstablishmentName = @EstablishmentName
        AND EstablishmentType = @EstablishmentType;
    
    /* =========================================================
       If it exists, return the existing establishment ID
       ========================================================= */
    IF @ExistingEstablishment IS NOT NULL
    BEGIN
        SET @Establishment = @ExistingEstablishment;
        RETURN; 
    END

    /* =========================================================
       Generate PK if NULL (only if it doesn't exist)
       ========================================================= */
    IF @Establishment IS NULL
    BEGIN
        DROP TABLE IF EXISTS #StoredResult;

        CREATE TABLE #StoredResult
        (
            PrimaryKey INT,
            IsUEnterByExists INT,
            OrgsColumn INT
        );

        INSERT INTO #StoredResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName   = N'Establishment',
            @PkFieldName = N'Establishment',
            @LogonName   = @UEnterBy;

        SELECT @Establishment = PrimaryKey
        FROM #StoredResult;
        
        DROP TABLE #StoredResult;
    END

    /* =========================================================
       Insert Establishment (only if it doesn't exist)
       ========================================================= */
    INSERT INTO dbo.Establishment
    (
        Establishment,
        EstablishmentName,
        EstablishmentAName,
        EstablishmentFName,
        EstablishmentType,
        EstablishmentAddress,
        EstablishmentContact,
        ContactTitle,
        EstablishmentCons,
        EstablishmentNameCons,
        EstablishmentANameCons,
        EstablishmentFNameCons,
        EstablishmentRoles,
        EstablishmentOrgs,
        EstablishmentRYear,
        EstablishmentRNo,
        EstablishmentRDesc,
        UEnterBy,
		UEnterDate,
        EstablishmentOrder
    )
    VALUES
    (
        @Establishment,
        @EstablishmentName,
        @EstablishmentAName,
        @EstablishmentFName,
        @EstablishmentType,
        @EstablishmentAddress,
        @EstablishmentContact,
        @ContactTitle,
        @EstablishmentCons,
        @EstablishmentNameCons,
        @EstablishmentANameCons,
        @EstablishmentFNameCons,
        @EstablishmentRoles,
        @EstablishmentOrgs,
        @EstablishmentRYear,
        @EstablishmentRNo,
        @EstablishmentRDesc,
        @UEnterBy,
		@UEnterDate,
        @EstablishmentOrder
    );
END

GO

