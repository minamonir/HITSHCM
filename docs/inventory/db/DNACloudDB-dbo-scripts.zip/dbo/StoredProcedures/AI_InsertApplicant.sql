CREATE PROCEDURE [dbo].[AI_InsertApplicant]
(
      @ProfileId            INT,
      @PersonType           SMALLINT = NULL,
      @Name                 NVARCHAR(88) = NULL,
      @FirstName            NVARCHAR(20) = NULL,
      @LastName             NVARCHAR(20) = NULL,
      @AName                NVARCHAR(88) = NULL,
      @FirstAName           NVARCHAR(20) = NULL,
      @MidAName             NVARCHAR(25) = NULL,
      @LastAName            NVARCHAR(20) = NULL,

      @Mobile               NVARCHAR(20) = NULL,
      @PrivateEmail         NVARCHAR(80) = NULL,
      @Gender               SMALLINT = NULL,
      @NatnlNo              NVARCHAR(20) = NULL,

      @BirthDate            SMALLDATETIME = NULL,
      @BirthPlace           NVARCHAR(30) = NULL,
      @Country              NVARCHAR(20) = NULL,
      @CityId               SMALLINT = NULL,
      @Address              NVARCHAR(254) = NULL,

      @ApplicationStatus    SMALLINT = NULL,
	  @ApplicationStart     DATETIME = NULL,
	  @ApplicationEnd       DATETIME = NULL,
	  @VacancyNo            INT =Null,
	  @ApplicationSource    SMALLINT = NULL,
      @EnterBy              INT = NULL,

      @NewApplicantNo       INT OUTPUT
)
AS
BEGIN
    SET NOCOUNT ON;
	--SET @VacancyNo = TRY_CAST(@VacancyNo AS INT);
	--SET @ApplicationStatus = TRY_CAST(@ApplicationStatus AS SMALLINT); -- NOT NULL	
	--SET @ApplicationSource = TRY_CAST(@ApplicationSource AS SMALLINT);
	 
	
	 print'vacancyNo='+ ltrim(rtrim( @VacancyNo))
	IF @ApplicationStatus IS NULL
		SET @ApplicationStatus = 0;

    DECLARE @PositionNo   SMALLINT,
            @Job          SMALLINT,
            @Organization SMALLINT,
            @LocationNo   SMALLINT,
            @Grade        SMALLINT

    SELECT
        @PositionNo   = PositionNo,
        @Job          = Job,
        @Organization = Organization,
        @LocationNo   = LocationNo,
        @Grade        = Grade
    FROM dbo.Vacancies
    WHERE VacancyNo = @VacancyNo;



    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO [dbo].[V_Applicants]
        (
             [ProfileId],
             [PersonType],
             [Name],
             [FirstName],
             [LastName],
             [AName],
             [FirstAName],
             [MidAName],
             [LastAName],

             [Mobile],
             [PrivateEmail],
             [Gender],
             [NatnlNo],

             [BirthDate],
             [BirthPlace],
             [Country],
             [CityId],
             [Address],

             [ApplicationStatus],
			 [ApplicationStart], 
			 [ApplicationEnd],
			 [VacancyNo],
			 [ApplicationSource],
             [EnterBy],
             [EnterDate],

             [PositionNo],
             [Job],
             [Organization],
             [LocationNo],
             [Grade]
        )
        VALUES
        (
             @ProfileId,
             @PersonType,
             @Name,
             @FirstName,
             @LastName,
             @AName,
             @FirstAName,
             @MidAName,
             @LastAName,

             @Mobile,
             @PrivateEmail,
             @Gender,
             @NatnlNo,

             @BirthDate,
             @BirthPlace,
             @Country,
             @CityId,
             @Address,

             @ApplicationStatus,
			 @ApplicationStart,
			 @ApplicationEnd,
			 @VacancyNo , 
			 @ApplicationSource,
             @EnterBy,
             GETDATE(),

             @PositionNo,
             @Job,
             @Organization,
             @LocationNo,
             @Grade
        );

		    SELECT @NewApplicantNo = ProfileId
            FROM dbo.V_Applicants
            WHERE Mobile = @Mobile OR PrivateEmail = @PrivateEmail;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        THROW;
    END CATCH
END

GO

