
CREATE  PROCEDURE [dbo].[Alert_EmployeeswzcontiouslyvacationNew]
  (@Period int = 14,@PayrollOrCal SMALLINT=0 ,@EmployeeOrManager SMALLINT=0,@AlertOrSub AS SMALLINT=0,@Roles AS NVARCHAR(MAX), @Profileid AS INT=0,@donotcountdayoff AS BIT=0,@donotcountholiday AS BIT=0 , @x AS NVARCHAR (250)='')
AS
-- @Period : number of continuous day 
-- @EmployeeOrManager :
-- 0: employee  
-- 1: Manager 
-- @AlertOrSub :
-- 0: subscription
-- 1: Alert
-- @PayrollOrCal :
-- 0: payroll year 
-- 1: calender year
-- @Roles : will contain the RoleIds separated by commas
-- @ProfileId : will contain the profile id of the role in case of manager alert	
--@donotcountdayoff :0
--@donotcountholiday:1

declare @filterselect nvarchar(max)= ' , 0 as GroupLevel1 , '''''''' as GroupName1  , 0 as GroupLevel2 , '''''''' as GroupName2  , 0 as GroupLevel3 , '''''''' as GroupName3  , 0 as GroupLevel4 , '''''''' as GroupName4  
	, 0 as GroupLevel5 , '''''''' as GroupName5  , 0 as GroupLevel6 , '''''''' as GroupName6  , 0 as GroupLevel7 , '''''''' as GroupName7 , 0 AS GroupLevel8, '''''''' AS GroupName8  '

SET NOCOUNT ON

DECLARE @vacfrom AS SMALLDATETIME = CAST(year(GETDATE()) AS nCHAR(4))+'-01-01'
DECLARE @vacto AS SMALLDATETIME =  getdate()
--DECLARE @filterwhere AS NVARCHAR(max) =' and  HrStatus.PayStatus=1 and EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where profileid = case when '+cast(@Profileid AS NVARCHAR(10))+ ' = 0 then profileid else '+cast(@Profileid AS NVARCHAR(10))+ ' end ' +@RolesFilter+') '
DECLARE @filterwhere AS NVARCHAR(max) 
PRINT @filterwhere
DECLARE @empId AS int
DECLARE @from AS datetime
DECLARE @To AS datetime

DECLARE @PrevEmpID AS int
DECLARE @PrevToDate AS datetime
DECLARE @ContDays AS numeric(18,3)
DECLARE @VacTakenDays AS numeric(18,3)
DECLARE @RolesFilter NVARCHAR(250)
DECLARE @RolesFilter1 NVARCHAR(250)
SET @RolesFilter=''
SET @RolesFilter1=''
SET @PrevEmpID=0

IF @EmployeeOrManager=0
	  BEGIN
	  	 --SET @filterwhere1= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''') and convert(nchar(10),convert(smalldatetime,'''+@CYear+'''+''-''+'''+@NextMonth+'''+''-01'')-1,120) = CONVERT(NCHAR(10),Getdate(),120)'
		 SET  @filterwhere= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''') '
		PRINT @filterwhere
	  END
ELSE 
	 BEGIN 
	  	IF ltrim(rtrim(@Roles))<>''
	  	    BEGIN 
	  	      SET @RolesFilter= ' and RoleId in ('+@Roles+')'
	  	      SET @RolesFilter1= ' and SSRole.RoleId in ('+@Roles+')'
	    	END 
	  		
	  	IF @AlertOrSub=0
	  	BEGIN
	  			SET @filterwhere='  and  HrStatus.PayStatus=1 AND EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where 1=1 '+@RolesFilter+')'
	  		END 
	  	ELSE
	  	BEGIN
	  		SET @filterwhere=' and  HrStatus.PayStatus=1  
	  		                     and EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where profileid = case when '+cast(@Profileid AS NVARCHAR(10))+ ' = 0 then profileid else '+cast(@Profileid AS NVARCHAR(10))+ ' end ' +@RolesFilter+')'
			--SET @filterwhere = ' and  HrStatus.PayStatus=1 and EmpAssignment.SSGroup in (select distinct SSGroup.ssgroup from SSGroup 
			--								  LEFT JOIN SSRole ON SSRole.RoleId = SSGroup.SSGroup 
			--								  LEFT JOIN SSGroupRole ON SSGroupRole.RoleId = SSRole.RoleId  AND SSGroupRole.SSGroup = SSGroup.SSGroup where
			--								    profileid = case when '+cast(@Profileid AS NVARCHAR(10))+ ' = 0 then profileid else '+cast(@Profileid AS NVARCHAR(10))+ ' end '+@RolesFilter1+') '
	  	END 
	 END 

CREATE TABLE #Temp(
               EmpId int
              ,EmployeeId nvarchar(88)
              ,Name nvarchar(88)
              ,AName nvarchar(88) 
              ,JobName nvarchar(250)
              ,JobAName nvarchar(250)
			  ,OrganizationName nvarchar(250)
              ,ContDays int 
              ,ContTimes int   
              ,NonContDays numeric(18,3)
              ,NonContTimes int
              ,GroupLevel1 int
              ,GroupName1 nvarchar(250)
              ,GroupLevel2 int
              ,GroupName2 nvarchar(250)
              ,GroupLevel3 int
              ,GroupName3 nvarchar(250)
              ,GroupLevel4 int
              ,GroupName4 nvarchar(250)
              ,GroupLevel5 int
              ,GroupName5 nvarchar(250)
              ,GroupLevel6 int
              ,GroupName6 nvarchar(250)
              ,GroupLevel7 int
              ,GroupName7 nvarchar(250)
              ,GroupLevel8 int
              ,GroupName8 nvarchar(250)
               ) 
                    
    create Table #temp2(EmpId int
                 ,ContinousDays numeric(18,3)
                 ,ContinousTimes int
                 ,NonContinousDays numeric(18,3)
                 ,NonContinousTimes int)


EXEC(' declare tempemployee cursor for
SELECT 
EmpVacat.empid,
EmpVacat.FromDate,
EmpVacat.ToDate
,dbo.vactakendays(EmpVacat.EmpId, CASE WHEN '''+ @VACFROM+''' > EmpVacat.FromDate THEN '''+@VACFROM +''' ELSE EmpVacat.FromDate END , CASE WHEN '''+@VACTO+''' < Empvacat.ToDate THEN '''+@VACTO +''' ELSE EmpVacat.ToDate END
,Empvacat.VacCode, empvacat.DocumentNo, empvacat.PartDayFrom, empvacat.PartDayTo)
FROM EmpVacat 
LEFT JOIN Vacation ON EmpVacat.VacCode = Vacation.vaccode 
LEFT JOIN Empassignment on EmpVacat.Empid = EmpAssignment.Empid
LEFT JOIN Profile on EmpVacat.Empid = Profile.ProfileId 
LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
CROSS JOIN SysParam
where EmpVacat.VacStatus=1 

AND ((EmpVacat.FromDate Between '''+@VacFrom+''' And'''+ @VacTo+''')
Or (EmpVacat.ToDate Between '''+@VacFrom+''' AND'''+ @VacTo+''')
Or ('''+@VacFrom+''' Between EmpVacat.FromDate And EmpVacat.ToDate)
Or ('''+@VacTo+''' Between EmpVacat.FromDate And EmpVacat.ToDate)) 
' +@filterwhere +' Order By Empvacat.EmpId, EmpVacat.Fromdate')

OPEN tempemployee
FETCH NEXT FROM tempemployee
INTO  @empid,@from,@To,@VacTakenDays
WHILE @@FETCH_STATUS = 0
 BEGIN	
   IF @empid<>@PrevEmpID 
    BEGIN

	   set @ContDays=@VacTakenDays
	   if @contDays>=@Period
	  begin
			insert into #temp2(EmpId ,ContinousDays,ContinousTimes,NonContinousDays,NonContinousTimes) 
			Values (@empId,@ContDays,1,0,0)  
		   set @ContDays=0
	  end
	
	
  END   
  ELSE
  BEGIN
  		IF @from=dateadd(dd,1,@PrevToDate)
   		  BEGIN
	   	    
			set @ContDays=@ContDays+@VacTakenDays
   			if @ContDays>=@Period
   			BEGIN
	   	
   			  insert into #temp2(EmpId 
					 ,ContinousDays
					 ,ContinousTimes
					 ,NonContinousDays
					 ,NonContinousTimes)
			  Values (@empId,@ContDays,1,0,0)
			  set @ContDays=0
   			end	
	    SET @PrevToDate=@To
   		  END
   		ELSE
   		BEGIN
		set @ContDays=@VacTakenDays
   		  if @ContDays>=@Period
		  begin
			 insert into #temp2(EmpId 
					 ,ContinousDays
					 ,ContinousTimes
					 ,NonContinousDays
					 ,NonContinousTimes)
		   Values (@PrevEmpId,@ContDays,1,0,0)
		   SET @ContDays=0
		  END 
   		END 
	END 
    SET @PrevToDate  =@To 


---------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------

	SET @PrevEmpID=@empId
	FETCH NEXT FROM tempemployee
	INTO  @empid,@from,@To,@VacTakenDays
   END
   
CLOSE tempemployee
DEALLOCATE tempemployee	

SELECT '#temp2',* FROM #temp2



  INSERT into #Temp(
               EmpId
              ,EmployeeId 
              ,Name
              ,AName
              ,JobName
              ,JobAName 
			  ,OrganizationName
              ,ContDays 
              ,ContTimes  
              ,NonContDays 
              ,NonContTimes 
              ,GroupLevel1 
              ,GroupName1
              ,GroupLevel2 
              ,GroupName2 
              ,GroupLevel3 
              ,GroupName3 
              ,GroupLevel4 
              ,GroupName4 
              ,GroupLevel5 
              ,GroupName5 
              ,GroupLevel6 
              ,GroupName6 
              ,GroupLevel7 
              ,GroupName7 
              ,GroupLevel8 
              ,GroupName8 
  )
  -- i inserted left joins because of @filterselect only
       EXEC('SELECT EmpAssignment.EmpId
			,EmpAssignment.EmployeeId 
			,Profile.Name
			,Profile.AName
			, (case when Positions.PositionNo is null then Jobs.JobName else Positions.PositionName end )as JobName
			, (case when Positions.PositionNo is null then Jobs.JobAName else Positions.PositionAName end )as JobAName 
			,Organization.OrganizationName
			,sum(#temp2.ContinousDays ) as ContDays
			,sum(#temp2.ContinousTimes  ) as ContTimes
			,sum(#temp2.NonContinousDays ) as NonContDays
			,sum(#temp2.NonContinousTimes) as NonContTimes'+@filterselect+'
			FROM EmpAssignment
			INNER JOIN #temp2 ON #temp2.EmpId=EmpAssignment.EmpId
			LEFT JOIN Profile on EmpAssignment.Empid = Profile.ProfileId 
			LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
			LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
			LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
			LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
			LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
			LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
			LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat
			LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
			LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
			LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
			LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
			LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
			LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
			LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
			LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
			LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
			CROSS JOIN SysParam
			Group by EmpAssignment.EmpId
			,EmpAssignment.EmployeeId
			,Profile.Name
			,Profile.AName
			,Positions.PositionNo
			,Positions.PositionName
			,Positions.PositionAName
			,Jobs.JobName
			,Jobs.JobAName
			,Organization.OrganizationName       
            ')

          
IF  @EmployeeOrManager=0
      BEGIN   
      	--Employee subscription
         SELECT DISTINCT PROFILE.ProfileId,(case when CompanyEmail <>'' then Profile.CompanyEmail else Profile.PrivateEmail end) as CompanyEmail
	 	  FROM #Temp LEFT JOIN PROFILE ON PROFILE.ProfileId= #Temp.EmpId order by PROFILE.ProfileId
      END 
     
  ELSE
     
  	IF @AlertOrSub=0
     BEGIN 
     	
     		PRINT 'Manager sub. '
     		
     	    --Manager Subscription

			DECLARE @str3 AS nvarchar(MAX)


    -- 		SET @str3 =' select distinct SSGroupRole.ProfileId,#Temp.EmpId,SSGroupRole.SSGroup,
    --         (CASE WHEN Mang.CompanyEmail<>'''' THEN Mang.CompanyEmail ELSE Mang.PrivateEmail END )AS CompanyEmail
    --         from #Temp
			 --Left JOIN empassignment ON #Temp.EmpId = empassignment.EmpId
			 --inner join SSGroupRole on SSGroupRole.SSGroup =EmpAssignment.SSGroup '+@RolesFilter+'
    --         left join Profile as Mang on Mang.profileid=SSGroupRole.profileid
    --         where (Mang.CompanyEmail <>'''' OR Mang.PrivateEmail <>'''')' 


			SET @str3 =' SELECT DISTINCT PROFILE.ProfileId,(case when CompanyEmail <>'''' then Profile.CompanyEmail else Profile.PrivateEmail end) as CompanyEmail
	 			FROM #Temp
				LEFT JOIN EmpAssignment  ON EmpAssignment.EmpId = #Temp.EmpId
				LEFT JOIN PROFILE ON PROFILE.ProfileId=' + Cast(@Profileid AS NVARCHAR(10))

			PRINT @str3
			EXEC (@str3)

     END 
     ELSE 
     	BEGIN 

     		--Manager Alert
			 DECLARE @str AS NVARCHAR(MAX)			 

			 SET @str = 'SELECT distinct  ''Dear  ''+rtrim(ltrim(isnull(ManagerProfile.FirstName,'''')))+'','' AS Header ,
						 ''Kindly note that the below mentioned employees take 2 consecutive weeks of annual leave.'' as Body,
						EmpAssignment.EmployeeId,#Temp.Name, #Temp.OrganizationName , #temp.ContDays as days ,
						CASE WHEN EmpAssignment.PositionNo is null THEN  #Temp.JobName ELSE Positions.PositionName END AS Job,
						 '''+LTRIM (RTRIM (@x))+ '''+'' '' as Footer,
						''EndSelect''

						 FROM #Temp
						 LEFT JOIN EmpAssignment  ON EmpAssignment.EmpId = #Temp.EmpId
						 LEFT JOIN Positions ON EmpAssignment.PositionNo=Positions.PositionNo
						 cross join (select FirstName from profile   where profileid = '+cast(@Profileid AS NVARCHAR(10))+') ManagerProfile
						 where #temp.ContDays > '+CAST(@Period AS NVARCHAR(5))+'
						'
					   PRINT @str
					   EXECUTE (@str ) 
  
				
     	END 
   
DROP TABLE #Temp
DROP TABLE #Temp2

GO

