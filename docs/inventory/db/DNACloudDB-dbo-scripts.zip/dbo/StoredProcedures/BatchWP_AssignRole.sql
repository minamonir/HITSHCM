
CREATE PROCEDURE [dbo].[BatchWP_AssignRole]
	
(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS smallint,@Where AS nvarchar(max),@Paramaters AS nvarchar(max),@outputstr AS nvarchar(max)output) AS
DECLARE @SELECT AS nvarchar(max)
DECLARE @Type AS nvarchar (100)
DECLARE @lang AS nvarchar (100)
DECLARE @RoleId AS NVARCHAR(100)
--DECLARE @paramater3 AS nvarchar (100)

DECLARE @StartIndex AS int 



IF @actiontype=1 --- Save
begin
--

SET @StartIndex=CHARINDEX(',',@Paramaters)
SET @Type= substring (@Paramaters,0,@StartIndex)

SET @lang=substring(@Paramaters,@StartIndex+1,1)
SET @StartIndex=CHARINDEX(',',@Paramaters,@StartIndex+1)
SET @RoleId=SUBSTRING(@Paramaters,@StartIndex+1,8)
--SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))

--SET @paramater3=@Paramaters

if @Type=1 ----Post
begin

SET @SELECT= 'INSERT INTO SSGroupRole (RoleId, SSGroup, ProfileId) 
select '+@RoleId+','+@tablename+'.SSGroup , Profile.ProfileId FROM '+ @tablename +
' LEFT JOIN Profile ON Profile.ProfileId = '+@tablename+'.empid WHERE post=1 and rtrim(ltrim(isnull(remarks,'''')))='''' '
end

if @Type=2 and @tablename<>'' --- Load
begin
declare @selectfields AS nvarchar(max)
select @selectfields= case when @lang like '%e%' then ' SSGroup.ssgroup,ssgroupName,ProfileId,Name ' else ' SSGroup.ssgroup,ssgroupAName,ProfileId,AName ' end
	set @SELECT= 'Insert into '+@tablename +' (SSgroup , SSgroupName  , empid  ,name , Remarks,post) select '+ @selectfields +','''',1 FROM SSGroup cross join PROFILE where 1=1 '+ @Where 
end

PRINT @SELECT
EXECUTE (@SELECT)
END

IF @actiontype=2 --- Export/Import
BEGIN
		DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
		SET @t=@tablename
		SET @t=replace(@t,'dbo.[','')
		SET @t=replace(@t,']','')
		select @count=count(*) FROM sysobjects s WHERE s.name=@t
		
	
		IF @actual>0 SET @str='select 0 as SSgroup,'''' as SSgroupname, 0 as empid,'''' as name,'''' as remarks,0 as post WHERE 1<>1'
		ELSE
			IF @count=1 SET @str='select * from '+@tablename
			ELSE
				SET @str='select 0 as SSgroup,'''' as SSgroupname, 0 as empid,'''' as name,'''' as remarks,0 as post WHERE 1<>1'
	exec sp_executesql @str
	
END

IF @actiontype=3 -- Create Temp table

	BEGIN
		DECLARE @updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
	@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100)

		IF rtrim(ltrim(@tablename))<>'' 
--		
BEGIN
--DECLARE @TableNamelen AS int 
--SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
--SET @select ='IF not EXISTS(SELECT top 1 1
--       FROM '+substring(@tablename,0,charindex('.dbo',@tablename))+'.INFORMATION_SCHEMA.Columns 
--       WHERE  '+substring(@tablename,0,charindex('.dbo',@tablename))+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+SUBSTRING(@TableName,charindex('[nasbatch',@TableName)+1,@TableNamelen)+''')'
--      +'CREATE TABLE ' + @tablename+ ' (empid [nvarchar](256) ,name [nvarchar](256),
--	Days [nvarchar](256) ,Remarks [nvarchar](256) ,post	bit)'


	SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'CREATE TABLE ' + @tablename+ ' (SSgroup [nvarchar](256) , SSgroupName [nvarchar](256) , empid [nvarchar](256) ,name [nvarchar](256),
	Remarks [nvarchar](256) ,post	bit,[Row_Number] int Identity(1,1) NOT NULL Primary Key)'
END 

		ELSE
			begin
			SET @tablename='  '
		 SET @selectstr='select  0 as SSgroup,'''' as SSgroupname, 0 as empid,'''' as name,'''' as remarks,0 as post  WHERE 1<>1'
			END


			
	SET @updatestr=' update '+@tablename+' set post=@post
	where isnull(ltrim(rtrim(empid)),0)=isnull(ltrim(rtrim(@originalempid)),0) and isnull(ltrim(rtrim(ssgroup)),0)=isnull(ltrim(rtrim(@originalssgroup)),0)'
	   
SET @insertstr=' insert into '+@tablename+' select @ssgroup , @ssgroupname , @empid ,
 	@name,@remarks,@post'

	SET @deletestr=' delete from  '+@tablename+' where isnull(ltrim(rtrim(empid)),0)=isnull(ltrim(rtrim(@originalempid)),0) and isnull(ltrim(rtrim(ssgroup)),0)=isnull(ltrim(rtrim(@originalssgroup)),0)'

	--	IF @lang='A' SET @hidecolstr='1,2,4,5'
	--	ELSE
			SET @DisabledColStr='1,2,3,4,5'
			exec sp_executesql @select
			SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr

	END
	
	
IF @actiontype=5 --- Delete
BEGIN



SET @SELECT= 'DELETE from SSGroupRole
FROM SSGroupRole AS t
LEFT JOIN SSGroup ON SSGroup.SSGroup = t.SSGroup
LEFT JOIN [Profile] ON [Profile].ProfileId = t.ProfileId where 1=1 '+@Where
EXEC(@SELECT)
PRINT @SELECT


END

GO

