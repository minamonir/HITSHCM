CREATE PROCEDURE  [dbo].[AmounRestaurant]  ( @from AS smalldatetime,@to AS smalldatetime,@minutes AS int, @amount1 AS numeric(18,3),@amount2 AS numeric(18,3),@paycode1  AS int,@paycode2 AS int)
AS 

CREATE TABLE #temp (
EmpId int,
paycode int,
amount numeric(18,3))


CREATE TABLE #ResINOut (
EmpId int,
EntryDate smalldatetime,
entryno	smallint,
timein smalldatetime,
timeout smalldatetime)

insert into #ResINOut (EmpId,EntryDate,entryno,timein)
SELECT  EmpShiftInOut.EmpId,EmpShiftInOut.EntryDate ,EmpShiftInOut.entryno,
convert(nchar(16),EmpShiftInOut.Timeout,120) as timein
	FROM EmpShiftInOut 
	LEFT JOIN EmpAssignment ea ON ea.EmpId = EmpShiftInOut.EmpId
	LEFT JOIN EmpTimeReadings INType ON    INType.AttendTime=EmpShiftInOut.Timeout AND INType.empid=EmpShiftInOut.EmpId
	WHERE     (EmpShiftInOut.Timeout IS NOT NULL)
	AND EmpShiftInOut.EntryDate BETWEEN @from AND @to AND INType.FlagValue IN (10)
AND INType.TimeSystem=405 

update #ResINOut
set timeout=convert(nchar(16),EmpShiftInOut.Timein,120)
FROM EmpShiftInOut 
LEFT JOIN EmpAssignment ea ON ea.EmpId = EmpShiftInOut.EmpId
LEFT JOIN EmpTimeReadings OutType ON    OutType.AttendTime=EmpShiftInOut.Timein AND OutType.empid=EmpShiftInOut.EmpId
WHERE    (EmpShiftInOut.Timein IS NOT NULL)
AND EmpShiftInOut.EntryDate BETWEEN @from AND @to AND ((OutType.FlagValue IN (11)))
and #ResINOut.EntryDate=EmpShiftInOut.EntryDate and #ResINOut.entryno+1=EmpShiftInOut.entryno
AND OutType.TimeSystem=405 


--select * from #ResINOut

INSERT INTO #temp
SELECT     #ResINOut.EmpId,
CASE WHEN datediff(mi,convert(datetime,convert(nchar(16),#ResINOut.TimeIn,120),120), 
	convert(datetime,convert(nchar(16),#ResINOut.Timeout,120),120))<=@minutes THEN @paycode1 ELSE @paycode2 END ,
CASE WHEN datediff(mi,convert(datetime,convert(nchar(16),#ResINOut.TimeIn,120),120), 
	convert(datetime,convert(nchar(16),#ResINOut.Timeout,120),120))<=@minutes THEN @amount1 ELSE @amount2 END 
	FROM #ResINOut 
	where #ResINOut.Timeout IS NOT NULL and #ResINOut.TimeIn IS NOT NULL 


--INSERT INTO MonthlyTransaction
--(
--	EmpId,
--	RunNo,
--	Paycode,
--	TransactionInactive,
--	Amount
--)

--select * from #temp
SELECT empid,1 AS runno,paycode,sum(amount) AS amount FROM #temp t GROUP BY t.EmpId,t.paycode

drop table #temp,#ResINOut

GO

