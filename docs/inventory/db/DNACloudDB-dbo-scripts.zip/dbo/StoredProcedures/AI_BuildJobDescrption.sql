
CREATE PROCEDURE [dbo].[AI_BuildJobDescrption]
	@logonName	  NVARCHAR(MAX),
	@jobName AS NVARCHAR(250),
	@jobDesc AS NVARCHAR(MAX),
	@jobDuties AS NVARCHAR(MAX),
	@job AS SMALLINT OUT
AS
BEGIN
	SET NOCOUNT ON;
	SELECT @job = Job FROM Jobs WHERE RTRIM(LTRIM(LOWER(JobName))) = RTRIM(LTRIM(LOWER(@jobName)))

	IF @job IS NULL
	BEGIN
		DECLARE @jobcat AS SMALLINT = NULL, @jobCons AS INT = 0,
				@jobNameCons AS NVARCHAR(250) = '', @jobFromDate AS SMALLDATETIME = NULL,
				@jobToDate AS SMALLDATETIME = NULL, @jobWeight AS NUMERIC = 0, @jobsRYear AS SMALLINT = 0,
				@jobsRNo AS NVARCHAR(10) = '', @jobsRIssueDate AS DATETIME = NULL, @jobsRExecDate AS DATETIME = NULL,
				@jobsRStatus AS SMALLINT = NULL, @jobsRSource AS SMALLINT = NULL, @jobsRDesc AS NVARCHAR(MAX) = '',
				@jobsOrder AS INT = 0

				CREATE TABLE #StoredResult (
					PrimaryKey INT,
					IsUEnterByExists INT,
					OrgsColumn INT
				);

				INSERT INTO #StoredResult
				EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Jobs', @PkFieldName = N'job', @LogonName = @logonName;

				SELECT @job = PrimaryKey FROM #StoredResult;
					   			 
		INSERT INTO [Jobs] ([job], [JobName], [jobcat], [JobDuties], [JobDesc],
							[JobCons], [JobNameCons], [JobFromDate], [JobToDate],
							[JobWeight], [JobsRYear], [JobsRNo], [JobsRIssueDate],
							[JobsRExecDate], [JobsRStatus], [JobsRSource], [JobsRDesc],[JobsOrder]
							,uenterdate,Uenterby) 
		VALUES (@job, @JobName, @jobcat, @jobDuties, @jobDesc, @jobCons, @jobNameCons, @jobFromDate, @jobToDate, @jobWeight, @jobsRYear, @jobsRNo, @jobsRIssueDate, @jobsRExecDate, @jobsRStatus, @jobsRSource, @jobsRDesc,@jobsOrder
		, getdate(),@logonname)
	END
	ELSE
	BEGIN
		UPDATE Jobs SET JobDesc = @jobDesc, JobDuties = @jobDuties  ,UChangeBy=@logonname
   ,UChangeDate=getdate() WHERE job = @job
	END
END

GO

