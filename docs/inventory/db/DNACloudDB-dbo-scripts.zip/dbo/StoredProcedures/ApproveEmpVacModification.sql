
CREATE   PROCEDURE [dbo].[ApproveEmpVacModification] (@Empid as  int ,@DocumentNo as int,@RoleProfileid  as int,@ActionType as smallint)
AS
BEGIN
if @ActionType = 0 --- (Modifiy)
begin
declare @OriginalDocumentNo as int,@vaccodeMod as smallint
						,@vacdateMod as smalldatetime
						,@fromdateMod as smalldatetime
						,@todateMod as smalldatetime
						,@lastworkingdateMod as smalldatetime
						,@lastworkingtextMod as nvarchar(max)
						,@firstworkingdateMod as smalldatetime
						,@firstworkingtextMod as nvarchar(max)
						,@addressMod as nvarchar(max)
						,@telMod as nchar(20)
						,@otherinfoMod  as nvarchar(max)
						,@partdayfromMod as bit
						,@partdaytoMod as bit
						,@getdateMod as smalldatetime =getdate (),@NewDocumentno as int

		
						select @OriginalDocumentNo=OriginalDocumentNo,@vaccodeMod = vaccode
						,@vacdateMod =vacdate
						,@fromdateMod =fromdate
						,@todateMod =todate
						,@lastworkingdateMod =lastworkingdate
						,@lastworkingtextMod =lastworkingtext
						,@firstworkingdateMod =firstworkingdate
						,@firstworkingtextMod =firstworkingtext
						,@addressMod =address
						,@telMod =tel
						,@otherinfoMod  =otherinfo
						,@partdayfromMod =partdayfrom
						,@partdaytoMod =partdayto
		
						  from EmpVacmodifications where  EmpId=@Empid and DocumentNo=@DocumentNo


	 update empvacat set vacstatus = 3, chngby = @RoleProfileid	, chngdate = getdate()
    	WHERE   (empvacat.DocumentNo =@OriginalDocumentNo)  AND (empvacat.EmpID = @empid) 
						

	EXEC dbo.Insert_Empvacat @empid , -- int
							@NewDocumentno OUTPUT , -- int
							1, -- @vacstatus smallint
							@vaccodeMod , -- smallint
							@vacdateMod , -- smalldatetime
							@fromdateMod , -- smalldatetime
							@todateMod , -- smalldatetime
							@lastworkingdateMod , -- smalldatetime
							@lastworkingtextMod , -- nvarchar(max)
							@firstworkingdateMod , -- smalldatetime
							@firstworkingtextMod , -- nvarchar(max)
							@addressMod , -- nvarchar(max)
							@telMod , -- nchar(20)
							@otherinfoMod , -- nvarchar(max)
							@partdayfromMod , -- bit
							@partdaytoMod , -- bit
							@RoleProfileid , -- int
							@getdateMod , -- smalldatetime
							@RoleProfileid , -- int
							@getdateMod , -- smalldatetime
							0 , -- bit
							0 , -- smallint  ?
							0, -- smallint
							N'', -- nvarchar(10)
							NULL, -- datetime
							NULL, -- datetime
							NULL, -- smallint
							NULL, -- smallint
							N'' -- nvarchar(max)
							

							update empvacmodifications 
											 set NewDocumentNo=@NewDocumentno
											, chngby = @RoleProfileid
											, chngdate = getdate()
											WHERE   (empvacmodifications.DocumentNo =@DocumentNo)   AND (empvacmodifications.EmpID = @empid) 


insert into UserFieldsValues (ProfileId,DocumentNo,FormNo, FieldNo,FieldValue,FieldAValue,FieldFValue)
select ProfileId,@DocumentNo,FormNo, FieldNo,FieldValue,FieldAValue,FieldFValue from UserFieldsValues where ProfileId=@Empid and DocumentNo =@OriginalDocumentNo and FormNo=3

select * from Attachments
insert into Attachments (EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,AttachmentFDescription,AttachmentPath,EnterBy,EnterDate,SysDate,SSDocAttachmentId,PDFDigitalSignature)
select EmpId,FormNo,@DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,AttachmentFDescription,AttachmentPath,EnterBy,EnterDate ,SysDate,SSDocAttachmentId,PDFDigitalSignature from Attachments where DocumentNo =@OriginalDocumentNo   and EmpID = @empid and FormNo=3

end
else 
begin
	update empvacat 
		set vacstatus = 3
		, chngby = @RoleProfileid
		, chngdate = getdate()
		WHERE   (empvacat.DocumentNo =@OriginalDocumentNo)  AND (empvacat.EmpID = @empid) 


end

END

GO

