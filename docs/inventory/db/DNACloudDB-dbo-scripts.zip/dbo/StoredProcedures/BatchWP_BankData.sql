
CREATE  PROCEDURE [dbo].[BatchWP_BankData] (@actiontype AS smallint, @tablename as nvarchar(150),@actual AS smallint,@outputstr AS nvarchar(max)output) AS
--DECLARE @tablename as nvarchar(150)
--SELECT @tablename =''

--@actiontype=1 save 
--@actiontype=2 export 
--@actiontype=3 create temp table
--@actiontype=4 select
DECLARE @SELECT AS nvarchar(max)
DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150),@x AS NVARCHAR(150)
	IF @actiontype=1
	begin
	SET @select='UPDATE    Banks
	SET  BankName =isnull(t.BankName,N''''), BankAName =isnull(t.BankAName,N''''), 
	BankInfo =isnull(t.BankInfo,N''''), 
	BanknoCons =isnull(t.BanknoCons,0), BankNameCons =isnull(t.BankNameCons,N''''), BankANameCons =isnull(t.BankANameCons,N'''')

	FROM '+ @tablename+' t WHERE t.bankno = banks.bankno '
	PRINT @SELECT
	EXECUTE (@SELECT)

	SET @select='INSERT INTO Banks
                      (bankno, BankName, BankAName, BankInfo, BanknoCons, BankNameCons, BankANameCons) 
	 SELECT     bankno, isnull(BankName,N''''), isnull(BankAName,N''''), isnull(BankInfo,N''''), 
	 isnull(BanknoCons,0), isnull(BankNameCons,N''''), isnull(BankANameCons,N'''')
	FROM '+@tablename+' t
	WHERE  t.bankno  NOT IN (select bankno FROM Banks)'


	PRINT @SELECT
	EXECUTE (@SELECT)
	END

	IF @actiontype=2
	BEGIN
	IF ltrim(rtrim(@tablename))<>''
begin
		--DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
		SET @t=@tablename
		--SET @t=replace(@t,'dbo.[','')
		--SET @t=replace(@t,']','')
		--select @count=count(*) FROM sysobjects s WHERE s.name=@t
		
	SET @x=LEFT(@t,charindex('[',@t)-1)
	SET @T=RIGHT(@t,len(@t)-charindex('[',@t))
	SET @t=replace(@t,']',N'')
		SET @t=N''+@t+N''
		--PRINT @t
		--PRINT @x
		SET @str='select @formulaOutput=count(*) FROM '+@x+'sysobjects s WHERE s.name='''+@t+''''
		PRINT @str
	

	exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
	end
		IF @actual>0 SET @SELECT='select * from banks'
		ELSE
			IF @count=1 
				SET @SELECT='select * from '+@tablename
			ELSE
				SET @SELECT=' select * from banks where 1=2'
	
	
		exec sp_executesql @SELECT

	
	END

	

	IF @actiontype=3

	BEGIN
		DECLARE @updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
	@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100)

IF ltrim(rtrim(@tablename))<>N''
begin
		SET @t=@tablename
		--SET @t=replace(@t,'dbo.[','')
		--SET @t=replace(@t,']','')
		--select @count=count(*) FROM sysobjects s WHERE s.name=@t
		--PRINT @count
		--PRINT @t
		SET @x=LEFT(@t,charindex('[',@t)-1)
	SET @T=RIGHT(@t,len(@t)-charindex('[',@t))
	SET @t=replace(@t,']','')
		SET @t=N''+@t+N''
		--PRINT @t
		--PRINT @x
		SET @str='select @formulaOutput=count(*) FROM '+@x+'sysobjects s WHERE s.name='''+@t+''''
		PRINT @str
	

	exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
	end
		IF rtrim(ltrim(@tablename))<>N'' AND @count=0 SET @str='CREATE TABLE ' +@tablename + '  ( [bankno]  [nvarchar](256)  NOT NULL PRIMARY KEY ,[BankName] [nvarchar](256),[BankAName] [nvarchar](256) ,[BankInfo] [Nvarchar(max)] ,[BanknoCons]  [nvarchar](256)  ,[BankNameCons] [nvarchar](250) ,[BankANameCons][nvarchar](250)) '
		ELSE
			begin
			SET @tablename=' Banks '
			SET @selectstr=' select * from banks'
			END
			
		SET @updatestr='UPDATE '+ @tablename+ ' SET bankno = @bankno,BankName =@BankName ,BankAName =@BankAName ,BankInfo =@BankInfo ,BanknoCons =@BanknoCons,BankNameCons =@BankNameCons,BankANameCons =@BankANameCons where bankno=@originalbankno'
		SET @insertstr='INSERT INTO '+ @tablename+ '  VALUES (@bankno,@BankName	,@BankAName	,@BankInfo,@BanknoCons,@BankNameCons,@BankANameCons	)'
		SET @deletestr='DELETE FROM '+ @tablename+ '  WHERE bankno=@originalbankno'
		SET @DisabledColStr='1'

		exec sp_executesql @str
		SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr

	END
	
	IF @actiontype=4
	BEGIN
	set @outputstr = 'SELECT *, identity(int,1,1) as [Row_Number] into #EndResultPagging from banks'
	END

GO

