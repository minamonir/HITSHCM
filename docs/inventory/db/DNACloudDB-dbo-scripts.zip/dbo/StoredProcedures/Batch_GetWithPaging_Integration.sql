

CREATE     PROCEDURE [dbo].[Batch_GetWithPaging_Integration]  (
@tablename AS nvarchar(150),
@p_sort_str nvarchar(max),
@p_page_number int,
@p_batch_size int,@tabletype  nvarchar(100),@filterwhere nvarchar(max) ,@count int OUTPUT) 

AS
BEGIN 
--declare @p7 int
--set @p7=20
--exec Batch_GetWithPaging @tablename=N'DNACLOUDDBBatchTemp.dbo.[Nasbatch4042012123111514939d74c8f34974247bcf364d858bf9ef6]',@p_sort_str=N' ',@p_page_number=1,@p_batch_size=10,@tabletype=N'WP_GetExternalData',@filterwhere=N' ',@count=@p7 output
--select @p7


--DECLARE @tablename AS nvarchar(150),
--@p_sort_str nvarchar(max),
--@p_page_number int,
--@p_batch_size int,@tabletype  nvarchar(100),@filterwhere nvarchar(max) ,@count int
--SELECT  @tablename=N'DNACLOUDDBBatchTemp.dbo.[Nasbatch4042012123111514939d74c8f34974247bcf364d858bf9ef6]',
--@p_sort_str=N'rdesc',@p_page_number=1,@p_batch_size=10,@tabletype=N'WP_GetExternalData',@filterwhere=N' '
SET NOCOUNT ON 

DECLARE @str AS nvarchar(max),@where as nvarchar(max)
DECLARE @outstr AS nvarchar(max),@actualtablename AS nvarchar(150)
SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName LIKE @tabletype

SET @actualtablename=CASE WHEN @actualtablename=N'' THEN NULL ELSE @actualtablename end

if ltrim(rtrim(@tabletype))= 'WP_BatchResult'  or ltrim(rtrim(@tabletype))= 'WP_INTApplyBatchPath' or ltrim(rtrim(@tabletype))= 'WP_BatchResult_ar' OR ltrim(rtrim(@tabletype))= 'WP_ApplyBatchPath' OR ltrim(rtrim(@tabletype))= 'WP_ApplyBatchPath_ar'
begin
--if  ltrim(rtrim(@tabletype))= 'WP_ApplyBatchPath' 
	if  charindex('WP_ApplyBatchPath' ,ltrim(rtrim(@tabletype)))>0
	begin
		SET @str=' SELECT @formulaOutput= count('+@tablename+'.Row_Number)  from '+@tablename+' where processtime is not null ' 
		set @where = ' ('+@tablename+'.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'+@filterwhere
		--Set @str=@str+' select * from '+@tablename+' where' + @where + ' and processtime is not null ' + ' order by '+@tablename+'.processtime desc'

 		DECLARE @time_Sort_Direction nvarchar(max)
 	
 		SET @time_Sort_Direction =( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime DESC%' THEN 'DESC'
 		WHEN  ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN  N''
 		ELSE  'DESC' END ) 
 	
		SET @p_sort_str=( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN N' '
 		ELSE @p_sort_str  END ) 
		if  @p_page_number = 1
		BEGIN
			Set @str=@str+'SELECT TOP ' + str(@p_batch_size) 
			+ ' * FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) where    processtime is not null ORDER BY '
			+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
			PRINT @str	
		END 
		ELSE
		BEGIN
			DECLARE @IndexedSort AS nvarchar(max)
			
			SET @IndexedSort=replace(@p_sort_str,'0','1')
			Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + ' *
			FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
			WHERE NOT (EXISTS(
				SELECT NULL AS [EMPTY]
				FROM (
				SELECT TOP '+ str(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
				FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
				where processtime is not null
				ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
				') AS [t2]
			WHERE [t0].[row_number] = [t2].[row_number]
			)) and   processtime is not null
			ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				
			PRINT @str
		END
	END
	----------------------//WP_INTApplyBatchPath
	Else if charindex('WP_INTApplyBatchPath' ,ltrim(rtrim(@tabletype)))>0
	begin
	set @filterwhere=case when @filterwhere='' then '  1=1 ' else  @filterwhere end
	SET @str=' SELECT @formulaOutput= count('+@tablename+'.Row_Number)  from '+@tablename+' where processtime is not null and ' +@filterwhere 

 		SET @time_Sort_Direction =( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime DESC%' THEN 'DESC'
 		WHEN  ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN  N''
 		ELSE  'DESC' END ) 
 	
		SET @p_sort_str=( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN N' '
 		ELSE @p_sort_str  END ) 
		if  @p_page_number = 1
		BEGIN
			Set @str=@str+' SELECT TOP ' + str(@p_batch_size) 
			+ ' * FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) where  processtime is not null and '+@filterwhere+' ORDER BY '
			+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
			PRINT @str	
		END 
		ELSE
		BEGIN

			SET @IndexedSort=replace(@p_sort_str,'0','1')
			Set @str=@str+' SELECT TOP ' + str(@p_batch_size) + ' *
			FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
			WHERE  '+ @filterwhere +' and NOT (EXISTS(
				SELECT NULL AS [EMPTY]
				FROM (
				SELECT TOP '+ str(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
				FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
				where   processtime is not null and '+@filterwhere+
				' ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
				') AS [t2]
			WHERE  [t0].[row_number] = [t2].[row_number]
			))  and   processtime is not null and '+@filterwhere+
			' ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				
			PRINT @str
		END
	end 
	else
	begin 
		IF @p_page_number=0 AND @p_batch_size=-1 AND @tabletype='WP_BatchResult'
		BEGIN
			SET @str=' SELECT  * FROM '+@tableName +'ORDER BY '+@p_sort_str
		END 
		ELSE
		BEGIN 
			SET @str=' SELECT @formulaOutput= count('+@tablename+'.Row_Number)  from '+@tablename+'' 
			--set @where = ' ('+@tablename+'.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'
			--Set @str=@str+' select * from '+@tablename+' where' + @where + ' order by '+@p_sort_str
			IF ltrim(rtrim(@p_sort_str)) =''
			BEGIN
				SET @str=@str+' SELECT top '+str(@p_batch_size)+' * FROM '+@tableName +
				' WHERE ROW_NUMBER NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER FROM '+@tableName + ')'
			END
			ELSE
			BEGIN
				SET @str=@str+' SELECT top '+str(@p_batch_size)+' * FROM '+@tableName +
				' WHERE ROW_NUMBER  NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER FROM '+@tableName + ' order by '+@p_sort_str+')'
				+ ' order by '+@p_sort_str
			END
		END
	END 
	print @str
	exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
end 
else
BEGIN
	IF @p_page_number > 0 and @p_batch_size >= 0 
	BEGIN
		IF ltrim(rtrim(@tablename))<>N''
		BEGIN
			------------------------create table dynamically without select in to------------

			DECLARE @SelectStr AS NVARCHAR(max)
			DECLARE @tableStr AS NVARCHAR(max)
			--SELECT @tableStr=SUBSTRING(@tableName,CHARINDEX('.',@tableName,CHARINDEX('dbo.',@tableName,0))+1,LEN(@tableName))
			--SELECT @tableStr=REPLACE(@tableStr,'[','')
			--SELECT @tableStr=REPLACE(@tableStr,']','')
			set @tableStr=parsename(@tablename,1)
			SET @SelectStr='select Column_Name ,Data_Type + case when CHARACTER_MAXIMUM_LENGTH is not null then case when CHARACTER_MAXIMUM_LENGTH = -1 then ''(Max)'' else ''(''+ltrim(rtrim(str(CHARACTER_MAXIMUM_LENGTH)))+'')'' end else case when Data_Type=''Numeric'' then ''(''+ltrim(rtrim(str(NUMERIC_PRECISION)))+'',''+ltrim(rtrim(str(NUMERIC_SCALE))) +'')'' else N'''' end end   from '+ parsename(@tablename,3)+'.INFORMATION_SCHEMA.Columns' 
			+' WHERE ' +parsename(@tablename,3)+'.INFORMATION_SCHEMA.Columns.Table_Name' +'='''+parsename(@tablename,1)+''' and ltrim(rtrim( '+parsename(@tablename,3)+'.INFORMATION_SCHEMA.Columns.Column_Name))' +'<>''Row_Number'''
			PRINT @SelectStr

					declare @colname  NVARCHAR (500),@datetype NVARCHAR(500),@temptable NVARCHAR(MAX),@columnsStr AS NVARCHAR(max)
						 
			SET @columnsStr=N''	
			SET @temptable=N' '

			exec('DECLARE Temp_cursor CURSOR FOR '+@SelectStr)

			OPEN Temp_cursor
			FETCH NEXT FROM Temp_cursor
			INTO @colname,@Datetype
			WHILE @@FETCH_STATUS = 0 
			BEGIN
		IF @tabletype LIKE N'%WP_GetExternalPayrollfromExternalSystem%'
			BEGIN
				select @temptable=@temptable +'['+@colname+']'+N' '+@datetype+ ','  
				SELECT @columnsStr=@columnsStr + ',['+@colname+']'
			END
			ELSE
			BEGIN
				select @temptable=@temptable +@colname+N' '+@datetype+ ','  
				SELECT @columnsStr=@columnsStr + ','+@colname
			END
				FETCH NEXT FROM Temp_cursor
			INTO @colname,@Datetype

			END
			CLOSE Temp_cursor;
			DEALLOCATE Temp_cursor;

			SET @columnsStr=SUBSTRING(@columnsStr,2,LEN(@columnsStr))
			set @temptable='create table #EndResultPagging('+@temptable+'[Row_Number] Int identity(1,1))'

			-------------------------------------------------------------------------------------------------------------------
			SET @str=@temptable+N' '+'insert into #EndResultPagging SELECT '+ @columnsStr+'  from '+@tablename		
		
		
			PRINT @str

		END	
		ELSE
		begin
			print @tablename

			--if ltrim(rtrim(@tabletype))='WP_JVSetup' SET @str ='exec [BatchWP_JVSetup] 4,'''+@tablename+''',0,'''+@filterwhere+''', @formulaOutput output'
			--else
			set @str = 'EXEC [hits_importexport]  4,''' +@actualtablename+''','''+ @tablename  +''',0,@formulaOutput output'

			exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
			PRINT @str

			-- 
			-- if ltrim(rtrim(@type))='WP_JVSetup' exec batch_JV 4,@tablename,0, @outstr output
			-- if ltrim(rtrim(@type))='WP_BankData' exec batch_BankData 4,@tablename,0, @outstr output
			SET @str=@outstr
		END

		PRINT  @str

		SET @str=@str+' SELECT @formulaOutput= count(#EndResultPagging.Row_Number)  from #EndResultPagging' 
		--set @where = ' (#EndResultPagging.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'
		--Set @str=@str+' select * from #EndResultPagging where' + @where +' order by #EndResultPagging.Row_Number'

		DECLARE @col AS NVARCHAR(50),@checkcoltype AS NVARCHAR(1000),@coloutput AS SMALLINT,@isnumeric AS SMALLINT,@desc AS NVARCHAR(5)
		SELECT @col=@p_sort_str,@checkcoltype=N'',@coloutput=0,@isnumeric=0
			
		SelecT @col=replace(@col,' desc',''),@desc=CASE WHEN @p_sort_str LIKE '% desc%' THEN ' desc' ELSE '' END
		PRINT @col
		PRINT @desc

		IF @p_sort_str<>N'' and charindex('row_number',@p_sort_str)=0 AND @tablename<>''
		BEGIN
			SET @checkcoltype=' SELECT @coloutput= min(ISNUMERIC(isnull('+@col+',0)))  from '+@tablename+'' 
			exec sp_executesql @checkcoltype , N' @coloutput int OUTPUT', @coloutput=@isnumeric OUTPUT
			PRINT @checkcoltype
			PRINT @isnumeric

		END
		else
		BEGIN
			SET @p_sort_str=CASE WHEN @p_sort_str='' THEN '#EndResultPagging.ROW_NUMBER ' ELSE @p_sort_str END
			PRINT @p_sort_str

		END
		SET @str=@str+' SELECT top '+str(@p_batch_size)
		+' * FROM #EndResultPagging WHERE #EndResultPagging.ROW_NUMBER NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER FROM #EndResultPagging order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
		+ ') order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 

		SET @str=@str+' drop table #EndResultPagging'
		print @str

		exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
	END
	
	SET NOCOUNT OFF
END


END

GO

