CREATE PROCEDURE [dbo].[AI_GenerateCvConfiguration]
    @LogonName NVARCHAR(80)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables for AI_CvSetup output
    DECLARE @EducationQualificationNo INT;
    DECLARE @WorkExperienceQualificationNo INT;
    DECLARE @TrainingQualificationNo INT;
    DECLARE @CertificateQualificationNo INT;
    DECLARE @ProjectQualificationNo INT;
    DECLARE @LanguageQualificationNo INT;
    DECLARE @ComputerSkillQualificationNo INT;
    DECLARE @JobSkillQualificationNo INT;
    DECLARE @DigitalSkillQualificationNo INT;

    -- Declare variables for AI_SetupUDFFields output
    DECLARE @LinkedInFieldNo SMALLINT;
    DECLARE @FacebookFieldNo SMALLINT;
    DECLARE @OtherSocialLinksFieldNo SMALLINT;

    -- 1. Education
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'educations qualification  ',
        @QualificationMajorTypeName = 'majors cv ',
        @QualificationGradeTypeName = 'grades cv',
        @EstablishmentTypeName = 'universitities cv',
        @SectionTitle = 'Education cv',
		@CaptionGrade='Degree',
		@CaptionMajor='FieldOfStudy',
		@CaptionEstablishment='Institution',
		@CaptionAGrade=N'الدرجة العلمية',
		@CaptionAMajor=N'مجال الدراسة',
		@CaptionAEstablishment=N'المؤسسة التعليمية',
        @LogonName = @LogonName,
        @SectionQualificationNo = @EducationQualificationNo OUTPUT;

    -- 2. Work Experience 
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'workexperiences qualification',
        @QualificationMajorTypeName = 'positions cv',
        @QualificationGradeTypeName = 'departments cv',
        @EstablishmentTypeName = 'companies cv',
        @SectionTitle = 'WorkExperience cv',
		@CaptionGrade='Department',
		@CaptionMajor='Position',
		@CaptionEstablishment='Company',
		@CaptionAGrade=N'القسم',
		@CaptionAMajor=N'المسمى الوظيفي',
		@CaptionAEstablishment=N'الشركة',
        @LogonName = @LogonName,
        @SectionQualificationNo = @WorkExperienceQualificationNo OUTPUT;

    -- 3. Training
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'trainings qualification',
        @QualificationMajorTypeName = 'trainings field cv',
        @QualificationGradeTypeName = 'trainings level cv',
        @EstablishmentTypeName = 'trainings center cv',
        @SectionTitle = 'Training cv',
		@CaptionGrade='Training Name',
		@CaptionMajor='Training Program',
		@CaptionEstablishment='Instituation',
		@CaptionAGrade=N'اسم التدريب',
		@CaptionAMajor=N'برنامج التدريب',
		@CaptionAEstablishment=N'جهة التدريب',
        @LogonName = @LogonName,
        @SectionQualificationNo = @TrainingQualificationNo OUTPUT;

    -- 4. Certificates
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'certificates qualification',
        @QualificationMajorTypeName = 'certificates field cv',
        @QualificationGradeTypeName = 'certificates level cv',
        @EstablishmentTypeName = 'certificates body cv',
        @SectionTitle = 'Certificates cv',
		@CaptionGrade='Certificates Name	',
		@CaptionMajor='FieldOfStudy',
		@CaptionEstablishment='Institution',
		@CaptionAGrade=N'اسم الشهادة',
		@CaptionAMajor=N'مجال الدراسة',
		@CaptionAEstablishment=N'الجهة المانحة',
        @LogonName = @LogonName,
        @SectionQualificationNo = @CertificateQualificationNo OUTPUT;

    -- 5. Projects 
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'projects qualification',
        @QualificationMajorTypeName = 'projects type cv',
        @QualificationGradeTypeName = 'projects role cv',
        @EstablishmentTypeName = 'clients cv',
        @SectionTitle = 'Project cv',
		@CaptionGrade='Project Name',
		@CaptionMajor='',
		@CaptionEstablishment='',
		@CaptionAGrade=N'اسم المشروع',
		@CaptionAMajor=N'',
		@CaptionAEstablishment=N'',
        @LogonName = @LogonName,
		@EnterEstablishment =0,
		@EnterMajor =0,
        @SectionQualificationNo = @ProjectQualificationNo OUTPUT;

    -- 6. Languages
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'languages qualification',
        @QualificationMajorTypeName = 'languages type cv',
        @QualificationGradeTypeName = 'Experience level cv',
        @EstablishmentTypeName = 'languages institute cv',
        @SectionTitle = 'Language cv',
		@CaptionGrade='Skill Level',
		@CaptionMajor='Skill Name',
		@CaptionEstablishment='',
		@CaptionAGrade=N'مستوى المهارة',
		@CaptionAMajor=N'اسم المهارة',
		@CaptionAEstablishment='',
        @LogonName = @LogonName,
		@EnterEstablishment =0,
        @SectionQualificationNo = @LanguageQualificationNo OUTPUT;

    -- 7. Computer Skills 
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'computers skill qualification',
        @QualificationMajorTypeName = 'software categories cv',
        @QualificationGradeTypeName = 'skills level cv',
        @EstablishmentTypeName = 'vendor cv',
        @SectionTitle = 'Computer Skill cv',
		@CaptionGrade='Skill Level',
		@CaptionMajor='Skill Name',
		@CaptionEstablishment='',
		@CaptionAGrade=N'مستوى المهارة',
		@CaptionAMajor=N'اسم المهارة',
		@CaptionAEstablishment='',
        @LogonName = @LogonName,
		@EnterEstablishment =0,
        @SectionQualificationNo = @ComputerSkillQualificationNo OUTPUT;

    -- 8. Job Related Skills 
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'jobs skill qualification',
        @QualificationMajorTypeName = 'skills category cv',
        @QualificationGradeTypeName = 'Experience level cv',
        @EstablishmentTypeName = 'industries cv',
        @SectionTitle = 'Job Skill cv',
		@CaptionGrade='Skill Level',
		@CaptionMajor='Skill Name',
		@CaptionEstablishment='',
	    @CaptionAGrade=N'مستوى المهارة',
		@CaptionAMajor=N'اسم المهارة',
		@CaptionAEstablishment='',
        @LogonName = @LogonName,
		@EnterEstablishment =0,
        @SectionQualificationNo = @JobSkillQualificationNo OUTPUT;

    -- 9. Digital Skills 
    EXEC dbo.AI_CvSetup
        @QualificationTypeName = 'digitals skill qualification',
        @QualificationMajorTypeName = 'digitals tool category cv',
        @QualificationGradeTypeName = 'skills level cv',
        @EstablishmentTypeName = 'platforms cv',
        @SectionTitle = 'Digital Skill cv',
		@CaptionGrade='Skill Level',
		@CaptionMajor='Skill Name',
		@CaptionEstablishment='',
		@CaptionAGrade=N'مستوى المهارة',
		@CaptionAMajor=N'اسم المهارة',
		@CaptionAEstablishment='',
        @LogonName = @LogonName,
		@EnterEstablishment =0,
        @SectionQualificationNo = @DigitalSkillQualificationNo OUTPUT;

    -- 1. LinkedInProfile
    EXEC dbo.AI_SetupUDFFields
        @FormNo = 10,
        @Caption = 'LinkedInProfile',
        @FieldNo = @LinkedInFieldNo OUTPUT;

    -- 2. FacebookPage
    EXEC dbo.AI_SetupUDFFields
        @FormNo = 10,
        @Caption = 'FacebookPage',
        @FieldNo = @FacebookFieldNo OUTPUT;

    -- 3. OtherSocialLinks
    EXEC dbo.AI_SetupUDFFields
        @FormNo = 10,
        @Caption = 'OtherSocialLinks',
        @FieldNo = @OtherSocialLinksFieldNo OUTPUT;

    -- Update AIConfig with dynamic values
    UPDATE AIConfig 
    SET 
        param1 = N'workexperience:' + CAST(@WorkExperienceQualificationNo AS NVARCHAR(max)) + 
                ',education:' + CAST(@EducationQualificationNo AS NVARCHAR(max)) + 
                ',Training:' + CAST(@TrainingQualificationNo AS NVARCHAR(max)) + 
                ',Certificates:' + CAST(@CertificateQualificationNo AS NVARCHAR(max)) + 
                ',Projects:' + CAST(@ProjectQualificationNo AS NVARCHAR(max)) + 
                ',lanuage:' + CAST(@LanguageQualificationNo AS NVARCHAR(max)) + 
                ',ComputerSkills:' + CAST(@ComputerSkillQualificationNo AS NVARCHAR(max)) + 
                ',JobRelatedSkills:' + CAST(@JobSkillQualificationNo AS NVARCHAR(max)) + 
                ',DigitalSkills:' + CAST(@DigitalSkillQualificationNo AS NVARCHAR(max)),
        param2 = N'udf1:' + CAST(@LinkedInFieldNo AS NVARCHAR(max)) + 
                ',udf2:' + CAST(@FacebookFieldNo AS NVARCHAR(max)) + 
                ',udf3:' + CAST(@OtherSocialLinksFieldNo AS NVARCHAR(max))
    WHERE ItemNo = 32574;
END

GO

