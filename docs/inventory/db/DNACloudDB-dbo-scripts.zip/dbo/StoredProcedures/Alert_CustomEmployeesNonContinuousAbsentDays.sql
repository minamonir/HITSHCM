
CREATE PROCEDURE [dbo].[Alert_CustomEmployeesNonContinuousAbsentDays]
(
		
--@EmployeeOrManager SMALLINT,
@AlertOrSub AS SMALLINT,
@Roles AS NVARCHAR(MAX)='',
@Profileid AS INT,
@donotcountdayoff AS BIT,
@donotcountholiday AS BIT,
@minimum AS SMALLINT,
@maximum AS SMALLINT, 
@Footer AS NVARCHAR (250)=N'',
@lang AS NCHAR(1)
)
AS 

BEGIN
-- @Period : number of continuous day 
-- @EmployeeOrManager : 
-- 0: employee  
-- 1: Manager 
-- @AlertOrSub :
-- 0: subscription
-- 1: Alert
-- @PayrollOrCal :
-- 0: payroll year 
-- 1: calender year
-- @Roles : will contain the RoleIds separated by commas
-- @ProfileId : will contain the profile id of the role in case of manager alert	
--@donotcountdayoff :0
--@donotcountholiday:1
--@minimum : First Time Alert
--@maximum : Second Time Alert

	DECLARE @cur_statment NVARCHAR(MAX)
	DECLARE @Peroidstart SMALLDATETIME
	DECLARE @filterselect nvarchar(MAX)
	DECLARE @filterwhere nvarchar(MAX)
	DECLARE @filterwhere1 NVARCHAR(MAX)
	DECLARE @payrollgroup SMALLINT
	DECLARE @EndDate SMALLDATETIME
	DECLARE @RolesFilter NVARCHAR(250)
	--DECLARE @FebruaryEnd AS NCHAR(10)
	--schedule preparations
	--DECLARE @CYear AS NCHAR(4)
	--SELECT @CYear = ltrim(rtrim(STR(YEAR(GETDATE())))) 


	SET @filterselect=' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  '
	SET @EndDate=  getdate()
	SET @RolesFilter=''

	--IF @EmployeeOrManager=0
	--BEGIN	  	 
	--	SET  @filterwhere1= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''') '
	--END
	--ELSE 
	--BEGIN 
		IF ltrim(rtrim(@Roles))<>''
		BEGIN 
			SET @RolesFilter= ' and RoleId in ('+@Roles+')'
		END 
	  		
		IF @AlertOrSub=0
		BEGIN
			SET @filterwhere1='  and  HrStatus.PayStatus=1 AND   EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where 1=1 '+@RolesFilter+') '
		END 
		ELSE
		BEGIN
			SET @filterwhere1=' and  HrStatus.PayStatus=1 and EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where profileid = case when '+cast(@Profileid AS NVARCHAR(10))+ ' = 0 then profileid else '+cast(@Profileid AS NVARCHAR(10))+ ' end ' +@RolesFilter+') '
		END 
	--END 

	DECLARE @YearStart AS NCHAR(4)
	

	SET @filterwhere=@filterwhere1 
	DECLARE @Periodfrom as SMALLDATETIME
	DECLARE @PeriodTo as SMALLDATETIME
	DECLARE @NoOFdayscont as INT
	DECLARE @NoOfDaysNonCont INT
	DECLARE @filtergroup nvarchar(MAX)		 
	SET @PeriodTo= @EndDate
	SET @filtergroup=''
	DECLARE @empId AS int
	DECLARE @VacFrom AS datetime
	DECLARE @VacTo AS DATETIME,@tempDate AS DATETIME ,@dofftype AS INT ,@doffday1  AS INT ,@doffday2 AS INT  ,@DayoffdaysCount AS INT,@Tempholidays AS int
	DECLARE @PrevEmpID AS int
	DECLARE @PrevToDate AS datetime
	DECLARE @ContDays AS numeric(18,3)
	DECLARE @VacTakenDays AS numeric(18,3)
	DECLARE @tempVacDaysoff AS numeric(18,3)=0.0,@tempdate1 AS datetime

	CREATE TABLE #TempHireDates	(
									EmpId INT ,
									AnniversaryHireDate SMALLDATETIME
								)
	EXECUTE 
	(
	'Insert Into #TempHireDates 
	SELECT EmpId,  (DATEADD( yy,DATEPART(yy ,(GETDATE()))-DATEPART(yy ,hiredate)-
	CASE 
	WHEN DATEPART(mm ,EmpAssignment.HireDate)*100+DATEPART(dd ,EmpAssignment.HireDate) >DATEPART(mm ,GETDATE())*100+DATEPART(dd ,GETDATE()) 
	THEN 1
	ELSE 0
	END,EmpAssignment.HireDate)) 
	FROM EmpAssignment
	LEFT JOIN payrollgroup ON payrollgroup.PayrollGroup=EmpAssignment.PayrollGroup
	'
	)




	SET @PrevEmpID=0
	CREATE TABLE #Temp	(
							EmpId INT
							,Employeeid NVARCHAR(50)
							,NAME NVARCHAR(100)
							,AName NVARCHAR(100)
							,JobName NVARCHAR(250)
							,JobAName NVARCHAR(250)
							,OrganizationName NVARCHAR(250)
							,OrganizationAName NVARCHAR(250)
							,DivisionName NVARCHAR(250)
							,DivisionAName NVARCHAR(250)
							,VacTakenDays NUMERIC(18,3)
							,HireDate SMALLDATETIME
							,GroupLevel1 int
							,GroupName1 NVARCHAR(250)
							,GroupLevel2 INT 
							,GroupName2 NVARCHAR(250)
							,GroupLevel3 INT
							,GroupName3 NVARCHAR(250)
							,GroupLevel4 INT
							,GroupName4 NVARCHAR(250)
							,GroupLevel5 INT
							,GroupName5 NVARCHAR(250)
							,GroupLevel6 INT
							,GroupName6 NVARCHAR(250)
							,GroupLevel7 INT
							,GroupName7 NVARCHAR(250)
							,GroupLevel8 INT
							,GroupName8 NVARCHAR(250)
						) 
                    
	--DECLARE @holidays AS INT
	--SET @holidays=0
	DECLARE @tempstr AS NVARCHAR(10)=''
	SET @tempstr= CASE WHEN @donotcountdayoff=0 THEN '0' ELSE '1' END +','+ CASE WHEN @donotcountholiday=0 THEN '0' ELSE '1' END
            

	                   
		EXEC('INSERT INTO #Temp SELECT 
	EmpVacat.empid, empassignment.employeeid, Profile.Name , Profile.AName , Jobs.JobName , JobAName,Organization.OrganizationName,Organization.OrganizationAName,
	dbo.GetOrganizationParent(organization.organization,2,1,1,''E'') as DivisionName ,dbo.GetOrganizationParent(organization.organization,2,1,1,''A'') as DivisionAName,
	SUM(dbo.[X_VacTakenDays]( EmpVacat.empid,CASE WHEN #TempHireDates.AnniversaryHireDate  > EmpVacat.FromDate THEN #TempHireDates.AnniversaryHireDate ELSE EmpVacat.FromDate END  , CASE WHEN '''+@PeriodTo+''' < Empvacat.ToDate THEN '''+@PeriodTo +''' ELSE EmpVacat.ToDate END,TimeRules.VacAbsent,'+@tempstr +',0,0,0)),
	empassignment.hiredate
	' + @filterselect +'
	FROM EmpVacat 
	LEFT JOIN Vacation ON EmpVacat.VacCode = Vacation.vaccode 
	LEFT JOIN Empassignment on EmpVacat.Empid = EmpAssignment.Empid
	LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule
	LEFT JOIN Profile on EmpVacat.Empid = Profile.ProfileId 
	LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
	LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
	LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
	LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
	LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
	LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
	LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat
	LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
	LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
	LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
	LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
	LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
	LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
	LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
	LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
	LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
	LEFT JOIN #TempHireDates ON #TempHireDates.Empid = Empassignment.Empid
	CROSS JOIN SysParam
	where empvacat.vaccode = TimeRules.VacAbsent and  EmpVacat.VacStatus=1 and (Vacation.dayfactor>=1 or Vacation.dayfactor=0)
	AND ((EmpVacat.FromDate Between #TempHireDates.AnniversaryHireDate And '''+ @PeriodTo+''')
	Or (EmpVacat.ToDate Between #TempHireDates.AnniversaryHireDate AND '''+ @PeriodTo+''')
	Or (#TempHireDates.AnniversaryHireDate Between EmpVacat.FromDate And EmpVacat.ToDate)
	Or ('''+@PeriodTo+''' Between EmpVacat.FromDate And EmpVacat.ToDate)) 
	' +@filterwhere +' 
	Group By	EmpVacat.empid, empassignment.employeeid, Profile.Name , Profile.AName , Jobs.JobName , JobAName,Organization.OrganizationName,Organization.OrganizationAName,
				organization.organization,empassignment.hiredate
	Order By Empvacat.EmpId
	')

                


	--IF  @EmployeeOrManager=0
	--BEGIN   
	----Employee subscription
	--	SELECT DISTINCT PROFILE.ProfileId,(case when CompanyEmail <>'' then Profile.CompanyEmail else Profile.PrivateEmail end) as CompanyEmail		
	--	FROM #Temp 
	--	LEFT JOIN PROFILE ON PROFILE.ProfileId= #Temp.EmpId	
	--	GROUP BY ProfileId,dbo.Profile.CompanyEmail ,Profile.PrivateEmail 
	--	HAVING SUM(VacTakenDays) IN (@minimum,@maximum)	 
	--	ORDER BY PROFILE.ProfileId
		
		
	--END 
     
	--ELSE
	IF @AlertOrSub=0
	BEGIN 
     	     		
	--Manager Subscription
	DECLARE @strsub AS NVARCHAR(MAX)
	
	SET @strsub=' select distinct SSGroupRole.ProfileId,
		(CASE WHEN Mang.CompanyEmail<>'''' THEN Mang.CompanyEmail ELSE Mang.PrivateEmail END )AS CompanyEmail
		from #Temp
		Left JOIN empassignment ON #Temp.EmpId = empassignment.EmpId
		inner join SSGroupRole on SSGroupRole.SSGroup =EmpAssignment.SSGroup '+@RolesFilter+'
		left join Profile as Mang on Mang.profileid=SSGroupRole.profileid
		where (Mang.CompanyEmail <>'''' OR Mang.PrivateEmail <>'''')
and VacTakenDays IN('+ str(@minimum) + ','+ str(@maximum) +')'

		EXEC(@strsub)

	END 
	ELSE 
	BEGIN 
	--Manager Alert
		DECLARE @str AS NVARCHAR(MAX) =N'' COLLATE database_default 
	    DECLARE @header AS NVARCHAR(max) = CASE WHEN @lang = 'a' THEN N'عزيزي ' ELSE N'Dear ' END
		DECLARE @body AS NVARCHAR(max)= CASE WHEN @lang = 'a' THEN N'يرجى ملاحظة أن الموظفين المذكورين أدناه أخذوا 10 أو 20 يومًا غائبًين.' ELSE N'Kindly note that the below mentioned employees take 10 or 20 absent days.' end
			 
		SET @str = N'SELECT distinct case when N'''+@lang+'''=N''a'' then N'''+@header+''' +rtrim(ltrim(isnull(ManagerProfile.FirstAName,N'''')))+N'','' else  N'''+@header+''' +rtrim(ltrim(isnull(ManagerProfile.FirstName, N'''')))+N'','' end AS Header,
		N'''+@body+''' as Body
		,VacTakenDays AS [Absent Days],
		EmpAssignment.EmployeeId,#Temp.Name,#Temp.AName, #Temp.OrganizationName, #Temp.OrganizationAName ,#Temp.hiredate,
		CASE WHEN EmpAssignment.PositionNo is null THEN  #Temp.JobName ELSE Positions.PositionName END AS Job,
		CASE WHEN EmpAssignment.PositionNo is null THEN  #Temp.JobAName ELSE Positions.PositionAName END AS AJob,
		N'''+LTRIM (RTRIM (@footer))+ '''+N'' '' as Footer,
		''EndSelect''
		
		FROM #Temp
		LEFT JOIN EmpAssignment  ON EmpAssignment.EmpId = #Temp.EmpId
		LEFT JOIN Positions ON EmpAssignment.PositionNo=Positions.PositionNo
		cross join(select FirstName,FirstAName from profile  where profileid = '+cast(@Profileid AS NVARCHAR(10))+') ManagerProfile
		where VacTakenDays IN('+ str(@minimum) + ','+str(@maximum) +')
		'
		PRINT @str																																							
		EXECUTE (@str) 
		--and ((empassignment.SSGroup in (select distinct ssgroup from SSGroupRole where ProfileId ='+cast(@Profileid AS NVARCHAR(10))+')and '+cast(@Profileid AS NVARCHAR(10))+' <>0)or (empassignment.EmpId=empassignment.EmpId and '+cast(@Profileid AS NVARCHAR(10))+'=0))																																							
		
	END 
	DROP TABLE #Temp
	DROP TABLE #TempHireDates
END

GO

