
CREATE   PROCEDURE [dbo].[Batch_Save] (@tablename as nvarchar(150),@tabletype as nvarchar(100),@Where AS nvarchar(max),@Paramaters AS nvarchar(max)) 
AS
BEGIN 
DECLARE @outstr AS nvarchar(max)
DECLARE @str AS nvarchar(max)
--set @str = 'EXEC [batch'+ltrim(rtrim(@tabletype))+']  1,''' + @tablename  +''',0,@formulaOutput output'
--test 

DECLARE @actualtablename AS nvarchar(150)
SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName LIKE @tabletype
PRINT '000'
PRINT @tablename 
PRINT @Where
PRINT @Paramaters
PRINT '111'
if ltrim(rtrim(@tabletype))='WP_JVSetup' exec BatchWP_JVSetup 1,@tablename,0,'', @outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords_ar' EXEC [BatchWP_GetExternalTimeKeepingRecords] 1,@tablename ,0,@Where,@Paramaters,@outstr output

ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmployees%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmployees_ar%' EXEC [BatchWP_GetExternalEmployees] 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExternalSystemsBatchPosting%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_ExternalSystemsBatchPosting_ar%' EXEC [BatchWP_ExternalSystemsBatchPosting] 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalApplicants_ar%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalApplicants%' EXEC [BatchWP_GetExternalApplicants] 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE

IF ltrim(rtrim(@tabletype)) ='WP_GetExternalAdditionalevents' 
begin SET @Paramaters='E,' +@Paramaters EXEC [BatchWP_GetExternalAdditionalTraining] 1,@tablename ,0,@Where,@Paramaters,@outstr output end
else
IF  ltrim(rtrim(@tabletype)) ='WP_GetExternalAdditionalevents_ar' begin SET @Paramaters='A,' +@Paramaters EXEC [BatchWP_GetExternalAdditionalTraining] 1,@tablename ,0,@Where,@Paramaters,@outstr output end
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalData' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalData_ar' EXEC BatchWP_getExternalData 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalDataFile%'  EXEC BatchWP_GetExternalDataFile 1,@tablename ,0,'',@Paramaters,@outstr OUTPUT
ELSE	
IF ltrim(rtrim(@tabletype)) ='WP_LoadPaymentData' OR ltrim(rtrim(@tabletype)) ='WP_LoadPaymentData_ar' EXEC BatchWP_LoadPaymentData 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_ApplyExtFinanceChanges' OR ltrim(rtrim(@tabletype)) ='WP_ApplyExtFinanceChanges_ar' EXEC BatchWP_ApplyExtFinanceChanges 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_HrBudgetEntry' OR ltrim(rtrim(@tabletype)) ='WP_HrBudgetEntry_ar' 
begin
select @Paramaters= case when ltrim(rtrim(@tabletype)) ='WP_HrBudgetEntry' then ltrim(@Paramaters)+ltrim(',E') 
else ltrim(@Paramaters)+ltrim(',A') end
EXEC BatchWP_HrBudgetEntry 1,@tablename ,0,@Where,@Paramaters,@outstr output
end
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanCostItems%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanCostItems_ar%' EXEC BatchWP_TrainingPlanCostItems 1,@tablename ,'0',@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalEmpShift' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalEmpShift_ar' EXEC BatchWP_GetExternalEmpShift 1,@tablename ,0,@Where,@Paramaters,@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanActivities%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanActivities_ar%' EXEC BatchWP_TrainingPlanActivities 1,@tablename ,'0',@Where,@Paramaters,@outstr output
ELSE	
	
	
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalVacDueAdjust' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalVacDueAdjust_ar' EXEC BatchWP_GetExternalVacDueAdjust 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimePermission' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalTimePermission_ar' EXEC BatchWP_GetExternalTimePerm 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalProfilePhone' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalProfilePhone_ar'
EXEC BatchWP_GetExternalProfilePhone 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE	
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalAppraisalWMR' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalAppraisalWMR_ar' EXEC BatchWP_GetExternalAppraisalWMR 1,@tablename ,0,@Where,@Paramaters,' '
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalVacRecords%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalVacRecords_ar%' EXEC BatchWP_GetExternalVacRecords 1,@tablename ,0,@Where,@Paramaters,' ',@outstr  output
ELSE
IF  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalProfileUserDefinedFields%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalProfileUserDefinedFields_ar%' EXEC BatchWP_GetExternalProfileUserDefinedFields 1,@tablename,' ',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalAdditionalEvents%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalAdditionalEvents_ar%' EXEC BatchWP_GetExternalAdditionalTraining   1,@tablename ,0,@Where,@Paramaters,@outstr  OUTPUT
------- 05/05/2016 -----------------
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalObjective%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalObjective_ar%' EXEC BatchWP_GetExternalObjective   1,@tablename ,0,@Where,@Paramaters,@outstr  OUTPUT
---------------------------------------------------------------------
ELSE
IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalHRRequests%' 
BEGIN 
	 EXEC BatchWP_GetExternalHRRequests  1,@tablename ,0,@Where,@Paramaters,' ',@outstr  OUTPUT END 
 ELSE
IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalTasks%' 
BEGIN 
	 EXEC BatchWP_GetExternalTasks  1,@tablename ,0,@Where,@Paramaters,' ',@outstr  OUTPUT END 

ELSE 	
IF  ltrim(rtrim(@tabletype))LIKE 'WP_GetExternalHistoryPaycodes_ar%'
BEGIN
SET @Paramaters='A,' + @Paramaters
EXEC dbo.BatchWP_getExternalHistoryPaycodes 1,@tablename ,0,@Where,@Paramaters,' ',@outstr OUTPUT
END

ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalHistoryPaycodes%' 
BEGIN
SET @Paramaters='E,' + @Paramaters
EXEC dbo.BatchWP_getExternalHistoryPaycodes 1,@tablename ,0,@Where,@Paramaters,' ',@outstr OUTPUT
END
Else
IF ltrim(rtrim(@tabletype)) like 'WP_GetExternalPaycodes_ar%' begin SET @Paramaters='A,' +@Paramaters EXEC dbo.BatchWP_getExternalPaycodes 1,@tablename ,0,@Where,@Paramaters,@tabletype,@outstr OUTPUT  end
ELSE	
IF ltrim(rtrim(@tabletype)) like 'WP_GetExternalPaycodes%'  begin  SET @Paramaters='E,' + @Paramaters  EXEC dbo.BatchWP_getExternalPaycodes 1,@tablename ,0,@Where,@Paramaters,@tabletype,@outstr OUTPUT  end
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetPayrollDataFromExternalSystem' OR ltrim(rtrim(@tabletype)) ='WP_GetPayrollDataFromExternalSystem_ar' EXEC BatchWP_getPayrollDataFromExternalSystem 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems_ar' EXEC BatchWP_getExternalBenefitItems 1,@tablename ,0,@Where,@Paramaters,@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalNasUsers' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalNasUsers_ar' EXEC BatchWP_GetExternalNassUsers 1,@tablename ,0,@Where,@Paramaters,@outstr OUTPUT
ELSE

IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalMisconduct%'  EXEC BatchWP_getExternalMisconduct 1,@tablename ,0,@Where,@Paramaters,'',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalBenefitPlan%' OR ltrim(rtrim(@tabletype))  LIKE '%WP_GetExternalBenefitPlan_ar%' EXEC BatchWP_GetExternalBenefitPlan 1,@tablename ,0,@tabletype,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalChangeOfStatus' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalChangeOfStatus_ar' 
BEGIN 
PRINT @Where
PRINT @Paramaters

select @Where= case when ltrim(rtrim(@tabletype)) ='WP_GetExternalChangeOfStatus' then ltrim(@Where)+ltrim(',E') 
else ltrim(@Where)+ltrim(',A') end
PRINT @Where
EXEC BatchWP_GetExternalChangeOfStatus 1,@tablename ,0,@Where,@Paramaters,' ',@outstr output
END 
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetCostCenterAllocation' OR ltrim(rtrim(@tabletype)) ='WP_GetCostCenterAllocation_ar' EXEC BatchWP_GetCostCenterAllocation 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_AssignSelfServiceGroups' OR ltrim(rtrim(@tabletype)) ='WP_AssignSelfServiceGroups_ar' EXEC [BatchWP_AssignRole] 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingNeedsCollection%' OR ltrim(rtrim(@tabletype))LIKE 'WP_TrainingNeedsCollection_ar%' EXEC BatchWP_TrainingNeedsCollection 1,@tablename,@where,@Paramaters ,@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) = 'WP_GetExternalPayrollDetails'  EXEC dbo.BatchWP_GetExternalPayrollDetails 1,@tablename ,0,'E,0',@Paramaters,' ',@outstr OUTPUT
ELSE	
IF ltrim(rtrim(@tabletype)) = 'WP_GetExternalPayrollDetails_ar'  EXEC dbo.BatchWP_GetExternalPayrollDetails 1,@tablename ,0,'A,0',@Paramaters,' ',@outstr output
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_PostTrainingPlanActivitytoTrainingEvent%' OR ltrim(rtrim(@tabletype))LIKE 'WP_PostTrainingPlanActivitytoTrainingEvent_ar%' EXEC BatchWP_GetTrainingPlanActivitiesasEvent 1,@tablename ,'0',@Where,@Paramaters,@outstr OUTPUT

ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales_ar%' OR ltrim(rtrim(@tabletype))LIKE 'WP_ExportBenefitSalaryScales%' 
BEGIN
PRINT 1
PRINT @tablename 
PRINT 0
PRINT @Where
PRINT @Paramaters
PRINT @tabletype
EXEC BatchWP_ExportBenefitSalaryScales 1,@tablename ,0,@Where,@Paramaters,@tabletype,@outstr output
END 


---------------------------------------------------Salary Scale Details-----------------------------------------------------------------------------------
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails_ar%' OR ltrim(rtrim(@tabletype))LIKE 'WP_ExportSalaryScalesDetails%' 
EXEC BatchWP_ExportSalaryScalesDetails 1,@tablename ,0,@Where,@Paramaters,@tabletype,@outstr OUTPUT

ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalDocuments' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalDocuments_ar'
begin
select @Where= case when ltrim(rtrim(@tabletype)) ='WP_GetExternalDocuments' then ltrim(@Where)+ltrim('E') 
else ltrim(@Where)+ltrim('A') end
PRINT @Where
PRINT @Paramaters
EXEC BatchWP_GetExternalDocuments 1,@tablename ,0,@Where,@Paramaters,' ',@outstr output
end
ELSE 
IF LTRIM(RTRIM(@tabletype)) LIKE  '%WP_GetExternalHousingItems%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalHousingItems_ar%' EXEC BatchWP_GetExternalHousingItems 1, @tablename, 0, @Where,@Paramaters,' ',@outstr OUTPUT
---------------------------------------------------------------------Get External Training-----------------------------
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalevents%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalevents_ar%' EXEC BatchWP_GetExternalevents 1,@tablename ,0,@Where,@Paramaters,' ',@outstr  output
----------------------------------------------------------------------------------------------------------------------- 	
--------
ELSE
IF LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalCompetencies' OR LTRIM(RTRIM(@tabletype))='WP_GetExternalCompetencies_ar' EXEC BatchWP_GetExternalCompetencies 1, @tablename, 0, @Where,@Paramaters, @outstr output
--------
ELSE
IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalEmpSSGroupRoles%' OR LTRIM(RTRIM(@tabletype))='WP_GetExternalEmpSSGroupRoles_ar%' EXEC BatchWP_GetExternalEmpSSGroupRoles 1,@tablename ,0,@Where,@Paramaters,' ',@outstr output

--------
ELSE	
BEGIN
set @str = 'EXEC [hits_importexport] 1,''' +@actualtablename+''','''+ @tablename  +''',0,@formulaOutput output'
PRINT @str
	exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
end
-- if ltrim(rtrim(@type))='WP_JVSetup' exec batch_JV 1,@tablename,0, @outstr output
-- if ltrim(rtrim(@type))='WP_BankData' exec batch_BankData 1,@tablename,0, @outstr output
END

GO

