
CREATE PROCEDURE [dbo].[BankInfoChangesComaprison]  (@runno Int, @netortotal INT,@from int,@to int,@filterselect nvarchar(max)='',@filterwhere nvarchar(max)='',@filtergroup nvarchar(max)='')
aS
/*declare @runno Int, @netortotal INT,@from int,@to int,@filterselect nvarchar(max),@filterwhere nvarchar(max),
@filtergroup nvarchar(max)
select @runno =1, @netortotal =0,@from =0,@to=0,@filterselect='',@filterwhere ='',@filtergroup=''*/
BEGIN

SET NOCOUNT ON;
declare @select nvarchar(max),@fromclause nvarchar(max),@where nvarchar(max)

if @from=0 and @to=0
begin
set @select='
SELECT distinct empassignment.EmpId,empassignment.employeeid,profile.name,profile.aname, 
MonthlyPayment.PaymentType,PaymentTypes.PaymentTypeName,PaymentTypes.PaymentTypeaName,MonthlyPayment.RunNo,HistoryPayment.PayBankNo oldPayBankNo,HistBanks.bankName OldBank,HistBanks.bankaName AOldBank,
MonthlyPayment.PayBankNo NewPayBankNo,banks.bankname NewBank,banks.bankaname ANewBank,HistoryPayment.PayBankAct oldPayBankAct,
MonthlyPayment.PayBankAct NewPayBankAct,HistoryPayment.SwiftCode oldSwiftCode,MonthlyPayment.SwiftCode NewSwiftCode 
,CAST(HistoryPayment.PaymentInfo AS NVARCHAR(max)) OldPaymentInfo,CAST(MonthlyPayment.PaymentInfo AS NVARCHAR(max)) NewPaymentInfo 
,case when Payrollgroup.CMonth=1 then Payrollgroup.CYear-1 else Payrollgroup.CYear end as PrevYear,
 case when Payrollgroup.CMonth=1 then 12 else Payrollgroup.CMonth-1 end  PrevMonth
,Payrollgroup.CYear as CurrentYear,
Payrollgroup.CMonth as CurrentMonth

--,case when '+str(@To)+' =0 then case when Payrollgroup.CMonth=1 then Payrollgroup.CYear-1 else Payrollgroup.CYear end else left('+str(@To)+',4) end as PrevYear,
-- case when '+str(@To)+'=0 then case when Payrollgroup.CMonth=1 then 12 else Payrollgroup.CMonth-1 end else right('+str(@To)+' ,2)end PrevMonth


 '+@filterselect

set @fromclause= '
from MonthlyPayment
left join empassignment on MonthlyPayment.empid=empassignment.empid and empassignment.status=1
left join profile on empassignment.empid=profile.profileid 
left join payrollgroup on empassignment.payrollgroup=payrollgroup.payrollgroup
left join HistoryPayment on HistoryPayment.empid=MonthlyPayment.empid 
and (MonthlyPayment.runno=HistoryPayment.runno)
and historypayment.year=( case when Payrollgroup.CMonth=1 then Payrollgroup.CYear-1 else Payrollgroup.CYear end )
and historypayment.month=( case when Payrollgroup.CMonth=1 then 12 else Payrollgroup.Cmonth-1 end)
and MonthlyPayment.PaymentType=historyPayment.PaymentType
left JOIN HistoryPayroll ON HistoryPayroll.EmpId = HistoryPayment.EmpId 
and HistoryPayroll.year = HistoryPayment.year 
and HistoryPayroll.month = HistoryPayment.month
and HistoryPayroll.runno = HistoryPayment.runno
left JOIN HistoryTransaction ON HistoryTransaction.Year = HistoryPayroll.Year 
AND HistoryPayroll.Month = HistoryTransaction.Month   
AND HistoryPayroll.EmpId = HistoryTransaction.EmpId 
AND HistoryPayroll.RunNo = HistoryTransaction.RunNo 
--left join payrollgroup on empassignment.payrollgroup=payrollgroup.payrollgroup 
left JOIN PaymentTypes ON MonthlyPayment.PaymentType = PaymentTypes.PaymentType 
LEFT JOIN MonthlyTransaction ON MonthlyTransaction.EmpId = MonthlyPayment.EmpId 
 AND MonthlyTransaction.RunNo= MonthlyPayment.RunNo 
LEFT JOIN Banks ON MonthlyPayment.PayBankNo = Banks.BankNo 
LEFT JOIN Banks HistBanks ON HistoryPayment.PayBankNo = HistBanks.BankNo 
LEFT JOIN Currency PayrollGroupCurrency ON PayrollGroup.Currency = PayrollGroupCurrency.Cur 
LEFT JOIN Currency PaymentCurrency ON PaymentCurrency.Cur=MonthlyPayment.PaymentCurrency  
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN JobCatGrp ON JobCatGrp.JobCatGrp = JobCat.JobCatGrp
LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo 
LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.taxcode 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId
LEFT JOIN Organization ON EmpAssignment.PayOrganization = Organization.Organization 
LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 
LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus'' 
LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus'' '
Set @filterwhere = Replace(@filterwhere, 'HistoryPAYMENT', 'monthlypayment')
Set @filterwhere = Replace(@filterwhere, 'HistoryTransaction','monthlytransaction')
set @where='
where 

((
(isnull(MonthlyPayment.PayBankNo,0)<>isnull(HistoryPayment.PayBankNo,0) or 
isnull(MonthlyPayment.PayBankAct,0)<>isnull(HistoryPayment.PayBankAct,0)
or (isnull(MonthlyPayment.Swiftcode,0)<>isnull(HistoryPayment.Swiftcode,0))))
)

and monthlypayment.Runno between (case when '+ rtrim(ltrim(str(@netortotal))) +' =1 then '+ rtrim(ltrim(str(@runno))) +'  else 1 end) and  '+ rtrim(ltrim(str(@runno))) +' 


' + @filterwhere
-- + @filtergroup 

execute (@select+@fromclause +@where)
print 'printed'+(@select+@where)
end
else
begin
set @select=''
set @select='
SELECT    distinct 
empassignment.EmpId,empassignment.employeeid,profile.name,profile.aname, 
HistoryPayment.PaymentType,PaymentTypes.PaymentTypeName,PaymentTypes.PaymentTypeAName,
HistoryPayment.RunNo,LPayment.PayBankNo oldPayBankNo,HistBanks.BankName oldBank,HistBanks.BankaName AoldBank,
HistoryPayment.PayBankNo NewPayBankNo,banks.bankname NewBank,banks.bankAname ANewBank,LPayment.PayBankAct oldPayBankAct,
HistoryPayment.PayBankAct NewPayBankAct,
LPayment.SwiftCode oldSwiftCode ,
HistoryPayment.SwiftCode NewSwiftCode,
CAST(LPayment.PaymentInfo AS NVARCHAR(max)) OldPaymentInfo,
CAST(HistoryPayment.PaymentInfo AS NVARCHAR(max)) NewPaymentInfo
,left('+str(@From)+',4) as PrevYear,
right('+str(@From)+' ,2)as PrevMonth
,left('+str(@To)+',4) as CurrentYear,
right('+str(@To)+' ,2)as CurrentMonth



'+ @filterselect
set @fromclause=''
set @fromclause=' 
from HistoryPayment 
left join empassignment on HistoryPayment.empid=empassignment.empid and empassignment.status=1
left join profile on empassignment.empid=profile.profileid 
left join HistoryPayment LPayment on HistoryPayment.empid=LPayment.empid 
and (lPayment.runno=HistoryPayment.runno)
and lPayment.PaymentType=historyPayment.PaymentType
and LPayment.year * 100 + LPayment.month='+rtrim(ltrim(str(@from)))+'
--and historypayment.year * 100 + historypayment.month='+ rtrim(ltrim(str(@to)))+' 

left JOIN HistoryPayroll ON HistoryPayroll.EmpId = EmpAssignment.EmpId 
INNER JOIN HistoryTransaction ON HistoryPayroll.Year = HistoryTransaction.Year 
 AND HistoryPayroll.Month = HistoryTransaction.Month  
 AND HistoryPayroll.EmpId = HistoryTransaction.EmpId 
 AND HistoryPayroll.RunNo = HistoryTransaction.RunNo 
LEFT join PaymentTypes ON HistoryPayment .PaymentType = PaymentTypes.PaymentType 
left join banks on HistoryPayment.PayBankNo=Banks.bankno
left join banks HistBanks on LPayment.PayBankNo=HistBanks.bankno 
LEFT JOIN Paycode ON PayCode.Code = HistoryTransaction.PayCode 
LEFT JOIN PaycdGrp ON PayCode.GrpCode = PaycdGrp.GrpCode 
LEFT JOIN Currency ON HistoryPayroll.PayrollCurrency = Currency.Cur 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN JobCatGrp ON JobCatGrp.JobCatGrp = JobCat.JobCatGrp
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo 
LEFT JOIN PayrollGroup ON HistoryPayroll.PayrollGroup = PayrollGroup.PayrollGroup  
LEFT JOIN Currency PayrollGroupCurrency ON PayrollGroupCurrency.Cur = PayrollGroup.Currency 
LEFT JOIN CostCntr ON HistoryPayroll.Center = CostCntr.center 
LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN Organization ON HistoryPayroll.PayOrganization = Organization.Organization 
LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 
LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 
LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 
LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 
LEFT JOIN NasArrays ScStatus ON HistoryPayroll.ScStatus = ScStatus.itemno AND ScStatus.arrayname = ''ScStatus'' 
LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname = ''Status'' 
LEFT JOIN NasArrays TaxStatus ON EmpAssignment.TaxStatus = TaxStatus.itemno AND TaxStatus.arrayname = ''TaxStatus'' 
'
set @filterwhere = Replace(@filterwhere, 'monthlypayment', 'HistoryPAYMENT')
Set @filterwhere = Replace(@filterwhere, 'monthlytransaction','HistoryTransaction')
set @where=''
set @where=' 
WHERE
(isnull(historypayment.PayBankNo,0)<>isnull(LPayment.PayBankNo,0) or 
(isnull(historypayment.PayBankAct,0)<>isnull(LPayment.PayBankAct,0)) 
or (isnull(historypayment.Swiftcode,0)<>isnull(LPayment.Swiftcode,0)))
and historypayment.year * 100 + historypayment.month='+ rtrim(ltrim(str(@to)))+' 
and historypayment.Runno between (case when '+ rtrim(ltrim(str(@netortotal))) +' =1 then '+ rtrim(ltrim(str(@runno))) +'  else 1 end) and  '+ rtrim(ltrim(str(@runno))) +' 

'+ @filterwhere
--+@filtergroup

execute (@select+@fromclause +@where)
print 'printed'+ (@select +@where)
end
END

GO

