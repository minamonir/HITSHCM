
CREATE PROCEDURE [dbo].[AI_InsertTrainingActivitiesSubjects] 
	@ActivityNo AS SMALLINT,
	@CategoryName AS NVARCHAR(60),
	@SubjectName AS NVARCHAR(60),
	@Order AS SMALLINT,
	@SessionDay AS SMALLINT,
	@SessionStart AS NVARCHAR(5),
	@SessionEnd AS NVARCHAR(5),
	@LogonName nvarchar(80)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @CategoryNo AS SMALLINT = 0
		,@SubjectNo AS SMALLINT = 0

	SET @CategoryNo = ISNULL((
				SELECT TOP 1 TrainingSubjectCategories.TrainingSubjectCategory
				FROM TrainingSubjectCategories
				WHERE LTRIM(RTRIM(TrainingSubjectCategoryName)) = LTRIM(RTRIM(@CategoryName))
					OR LTRIM(RTRIM(TrainingSubjectCategoryName)) = LTRIM(RTRIM(@CategoryName))
				), 0)

	SET @SubjectNo = ISNULL((
				SELECT TOP 1 TrainingSubjects.TrainingSubject
				FROM TrainingSubjects
				WHERE LTRIM(RTRIM(TrainingSubjectName)) = LTRIM(RTRIM(@SubjectName))
					OR LTRIM(RTRIM(TrainingSubjectAName)) = LTRIM(RTRIM(@SubjectName))
				), 0)

	-- Add category if there is no category with this name
	IF @CategoryNo = 0
	BEGIN
		CREATE TABLE #StoredResult1 (
			PrimaryKey INT
			,IsUEnterByExists INT
			,OrgsColumn INT
			);

		INSERT INTO #StoredResult1
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'TrainingSubjectCategories'
			,@PkFieldName = N'TrainingSubjectCategory'
			,@LogonName = @LogonName;

		SELECT @CategoryNo = PrimaryKey
		FROM #StoredResult1;

		INSERT INTO [dbo].[TrainingSubjectCategories] (
			[TrainingSubjectCategory]
			,[TrainingSubjectCategoryName]
			,[TrainingSubjectCategoryAName]
			,[TrainingSubjectCategoryFName]
			,[UEnterBy]
			,[UEnterDate]
			,[TrainingSubjectCategoriesOrder]
			)
		VALUES (
			@CategoryNo
			,@CategoryName
			,@CategoryName
			,@CategoryName
			,@LogonName
			,GETDATE()
			,0
			)
	END

	IF @SubjectNo = 0
	BEGIN
		CREATE TABLE #StoredResult2 (
			PrimaryKey INT
			,IsUEnterByExists INT
			,OrgsColumn INT
			);

		INSERT INTO #StoredResult2
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'TrainingSubjects'
			,@PkFieldName = N'TrainingSubject'
			,@LogonName = @LogonName;

		SELECT @SubjectNo = PrimaryKey
		FROM #StoredResult2;

		INSERT INTO [dbo].[TrainingSubjects]
			([TrainingSubject]
			,[TrainingSubjectCategory]
			,[TrainingSubjectName]
			,[TrainingSubjectAName]
			,[TrainingSubjectFName]
			,[UEnterBy]
			,[UEnterDate])
		VALUES
			(@SubjectNo
			,@CategoryNo
			,@SubjectName
			,@SubjectName
			,@SubjectName
			,@LogonName
			,GETDATE())
	END
	ELSE 
	BEGIN
		UPDATE [dbo].[TrainingSubjects]
		SET [TrainingSubjectCategory] = @CategoryNo,
		[UChangeBy] = @LogonName,
		[UChangeDate] = GETDATE()
		WHERE TrainingSubject = @SubjectNo
	END

	IF NOT EXISTS(SELECT TOP 1 TrainingActivity 
				FROM TrainingActivitySubjects 
				WHERE TrainingActivity = @ActivityNo AND TrainingSubject = @SubjectNo)
	BEGIN
		INSERT INTO [dbo].[TrainingActivitySubjects]
           ([TrainingActivity]
           ,[TrainingSubject]
           ,[TrainingSessionDay]
           ,[TrainingSessionStart]
           ,[TrainingSessionEnd]
           ,[TrainingSubjectOrder])
     VALUES
           (@ActivityNo
           ,@SubjectNo
           ,@SessionDay
           ,@SessionStart
           ,@SessionEnd
           ,@Order)
	END
	ELSE
	BEGIN
		UPDATE [dbo].[TrainingActivitySubjects]
		SET [TrainingSessionDay] = @SessionDay,
			[TrainingSessionStart] = @SessionStart,
			[TrainingSessionEnd] = @SessionEnd,
			[TrainingSubjectOrder] = @Order
		WHERE TrainingActivity = @ActivityNo AND TrainingSubject = @SubjectNo
	END
END

GO

