CREATE PROCEDURE [dbo].[AssigningShiftsAutomaticallyOnEmployees](@Profileid INT , @FridayShift  SMALLINT , @SaturdayShift  SMALLINT , @HolidayShift  SMALLINT,@FridayNight SMALLINT, @SaturdayNight SMALLINT , @HolidayNight SMALLINT )
AS


DECLARE @shiftdate AS DATETIME
	--SELECT @shiftdate=GETDATE()

BEGIN
	
CREATE TABLE #temp(EmpId INT ,shiftNo SMALLINT )
--SET @shiftdate=Convert(nchar(10),dateadd(dd,-1,getdate()),120)
SELECT  @shiftdate = max(dbo.periodstart(PayrollGroup,0,0)) FROM PayrollGroup
SET @shiftdate= Convert(nchar(10),@shiftdate,120)

PRINT @shiftdate
WHILE (Convert(nchar(10),@shiftdate,120) < Convert(nchar(10),getdate(),120))
BEGIN 
	
PRINT @shiftdate

INSERT INTO #temp
SELECT EmpAssignment.EmpId , CASE WHEN min(PermissionFrom) BETWEEN @shiftdate+'07:00:0.000' AND @shiftdate+'15:00:0.000' AND min(PermissionTo)  BETWEEN @shiftdate+'07:00:0.000' AND @shiftdate+'15:00:0.000' THEN 1
                              WHEN min(PermissionFrom) BETWEEN @shiftdate+'15:00:0.000' AND @shiftdate+'23:00:0.000' AND min(PermissionTo)  BETWEEN @shiftdate+'15:00:0.000' AND @shiftdate+'23:00:0.000' THEN 2
                              WHEN min(PermissionFrom) BETWEEN @shiftdate+'23:00:0.000' AND dateadd(day,1,@shiftdate)+'07:00:0.000' AND min(PermissionTo)  BETWEEN @shiftdate+'23:00:0.000' AND dateadd(day,1,@shiftdate)+' 07:00:0.000' THEN 3
                              END

FROM EmpTimeReadings 
LEFT JOIN EmpAssignment ON EmpAssignment.EmployeeId = EmpTimeReadings.EmployeeId
INNER JOIN EmpTimePermission  ON EmpTimePermission.EmpId = EmpAssignment.EmpId 
               AND (CONVERT (nvarchar(10),EmpTimePermission.PermissionFrom,111)= @shiftdate
                OR CONVERT (nvarchar(10),EmpTimePermission.PermissionTo,111)= @shiftdate)
WHERE emptimepermission.DocumentStatus=1
AND emptimereadings.AttendTime BETWEEN emptimepermission.PermissionFrom AND  case when PermissionFrom BETWEEN @shiftdate+'07:00:0.000' AND @shiftdate+'15:00:0.000' and PermissionTo BETWEEN @shiftdate+'07:00:0.000' AND @shiftdate+'15:00:0.000' THEN 
                                                                                   dateadd(hour,2,emptimepermission.PermissionTo)     
                                                                                 ELSE  dateadd(hour,1,emptimepermission.PermissionTo) END  
 
AND  EmpTimeReadings.FlagValue='I' AND EmpTimeReadings.Inactive=0                                                                                  
AND (emptimepermission.PermissionFrom between @shiftdate +'07:00:0.000' and @shiftdate +'09:00:0.000' 
or emptimepermission.PermissionFrom between @shiftdate +'15:00:0.000' and @shiftdate +'16:00:0.000' 
or emptimepermission.PermissionFrom between @shiftdate +'23:00:0.000' and dateadd(day,1,@shiftdate) +'00:00:0.000' )
AND empassignment.TimeRule =2
GROUP BY EmpAssignment.EmpId


INSERT INTO #temp
SELECT EmpAssignment.EmpId, CASE  WHEN DATEADD(s,-1,min(EmpTimeReadings.AttendTime)) BETWEEN @shiftdate+'05:59:59.000' And @shiftdate+'08:59:59.000' THEN 1 
                                          WHEN DATEADD(s,-1,min(EmpTimeReadings.AttendTime)) BETWEEN @shiftdate+'13:59:59.000' And @shiftdate+'15:59:59.000' THEN 2 
                                          WHEN DATEADD(s,-1,min(EmpTimeReadings.AttendTime)) BETWEEN  @shiftdate+'21:59:59.000' And @shiftdate+'23:59:59.000' THEN 3 
                                  END
FROM EmpTimeReadings 
LEFT JOIN EmpAssignment ON EmpAssignment.EmployeeId = EmpTimeReadings.EmployeeId
WHERE convert(nvarchar(10),DATEADD(s,-1,EmpTimeReadings.AttendTime) ,111) = @shiftdate
AND  EmpTimeReadings.FlagValue='I' AND EmpTimeReadings.Inactive=0
AND ( DATEADD(s,-1,EmpTimeReadings.AttendTime)  BETWEEN @shiftdate+'05:59:59.000' And @shiftdate+'08:59:59.000'
   OR DATEADD(s,-1,EmpTimeReadings.AttendTime)  BETWEEN @shiftdate+'13:59:59.000' And @shiftdate+'15:59:59.000'
   OR DATEADD(s,-1,EmpTimeReadings.AttendTime)  BETWEEN @shiftdate+'21:59:59.000' And @shiftdate+'23:59:59.000' )

AND EmpAssignment.empid NOT IN (SELECT EmpId FROM #temp)
AND empassignment.TimeRule =2
GROUP BY EmpAssignment.EmpId

UPDATE empshift 
SET empshift.ShiftNo = #temp.shiftNo ,
Empshift.ChangeBy =@Profileid,
Empshift.ChangeDate = getdate() 
FROM empshift 
INNER JOIN #temp on empshift.EmpId=#temp.empid
WHERE empshift.ShiftDate=@shiftdate AND #temp.shiftNo IN (1,2,3)

INSERT INTO empshift (EmpId,ShiftDate,ShiftNo,EnterBy,EnterDate)
SELECT #temp.empid,@shiftdate,#temp.shiftno ,@Profileid,getdate()
FROM #temp 
WHERE #temp.empid NOT IN (SELECT Empshift.empid FROM EmpShift  WHERE empshift.ShiftDate =@shiftdate)
AND #temp.shiftNo IN (1,2,3)


DELETE from #temp


 	  UPDATE EmpShift SET ShiftNo = CASE WHEN datepart(dw,@shiftdate )= doffday1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 02:00:00' AND @shiftdate+' 14:00:00'  THEN @FridayShift
 	                                     WHEN datepart(dw,@shiftdate )= doffday1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 14:01:00' AND dateadd(day,1,@shiftdate)+' 01:59:59'  THEN @FridayNight 
 	                                     WHEN datepart(dw,@shiftdate )= doffday2 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 02:00:00' AND @shiftdate+' 14:00:00' THEN @SaturdayShift
 	                                     WHEN datepart(dw,@shiftdate )= doffday2 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 14:01:00' AND dateadd(day,1,@shiftdate)+' 01:59:59' THEN @SaturdayShift
 	                                     WHEN holidays.holiday = 1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 02:00:00' AND @shiftdate+' 14:00:00' THEN @HolidayShift 
 	                                     WHEN holidays.holiday = 1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 14:01:00' AND dateadd(day,1,@shiftdate)+' 01:59:59' THEN @HolidayNight 
 	                                END 
 	                              , ChangeBy = @Profileid ,ChangeDate =GETDATE()
 	  FROM EmpShift
 	  LEFT JOIN empassignment ON empassignment.EmpId = EmpShift.EmpId
 	  LEFT JOIN VacPack ON VacPack.vacpack = empassignment.VacPack
 	  LEFT JOIN Holidays ON Holidays.vacpack = VacPack.vacpack AND holidays.date=@shiftdate
 	  INNER JOIN EmpTimeReadings ON EmpTimeReadings.EmployeeId = empassignment.EmployeeId 
 	  AND convert(nvarchar(10),emptimereadings.AttendTime,111) between @shiftdate AND DATEADD(DAY,1,@shiftdate)
 	  WHERE EmpShift.ShiftDate=@shiftdate 
 	  AND  EmpTimeReadings.FlagValue='I' 
 	  AND (datepart(dw,@shiftdate ) IN (doffday1,doffday2)OR holidays.holiday = 1)
 	  AND empassignment.TimeRule=2
 	  AND EmpTimeReadings.Inactive=0
 	 
 	  INSERT INTO EmpShift (EmpId, ShiftDate, ShiftNo, EnterBy, EnterDate)
 	  SELECT distinct EmpAssignment.EmpId , @shiftdate ,
 	                                CASE WHEN datepart(dw,@shiftdate )= doffday1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 02:00:00' AND @shiftdate+' 14:00:00'  THEN @FridayShift
 	                                     WHEN datepart(dw,@shiftdate )= doffday1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 14:01:00' AND dateadd(day,1,@shiftdate)+' 01:59:59'  THEN @FridayNight 
 	                                     WHEN datepart(dw,@shiftdate )= doffday2 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 02:00:00' AND @shiftdate+' 14:00:00' THEN @SaturdayShift
 	                                     WHEN datepart(dw,@shiftdate )= doffday2 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 14:01:00' AND dateadd(day,1,@shiftdate)+' 01:59:59' THEN @SaturdayNight 
 	                                     WHEN holidays.holiday = 1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 02:00:00' AND @shiftdate+' 14:00:00' THEN @HolidayShift 
 	                                     WHEN holidays.holiday = 1 AND EmpTimeReadings.AttendTime BETWEEN @shiftdate+' 14:01:00' AND dateadd(day,1,@shiftdate)+' 01:59:59' THEN @HolidayShift 
 	                                END  , @Profileid , GETDATE() 
 	  FROM EmpAssignment 
 	  LEFT JOIN VacPack ON VacPack.vacpack = empassignment.VacPack
 	  LEFT JOIN Holidays ON Holidays.vacpack = VacPack.vacpack AND holidays.date=@shiftdate
 	  INNER JOIN EmpTimeReadings ON EmpTimeReadings.EmployeeId = empassignment.EmployeeId 
 	  AND convert(nvarchar(10),emptimereadings.AttendTime,111) between @shiftdate AND DATEADD(DAY,1,@shiftdate)
 	  WHERE  (datepart(dw,@shiftdate ) IN (doffday1,doffday2)OR holidays.holiday = 1)
 	  AND  EmpTimeReadings.FlagValue='I' 
 	  AND  EmpAssignment.EmpId NOT IN (SELECT Empshift.empid FROM EmpShift  WHERE empshift.ShiftDate =@shiftdate AND EmpShift.EmpId= EmpAssignment.EmpId)
      AND empassignment.TimeRule=2
      AND EmpTimeReadings.Inactive=0




SET @shiftdate = dateadd(day,1,@shiftdate)

	
	end
DROP TABLE #temp
END

GO

