
CREATE PROCEDURE [dbo].[BatchWP_GetExternalAdditionalTraining]
    (
      @actiontype AS SMALLINT ,
      @tablename AS NVARCHAR(150) ,
      @actual AS SMALLINT ,
      @Where AS NVARCHAR(MAX) ,
      @Parameters AS NVARCHAR(MAX) ,
      @outputstr AS NVARCHAR(MAX) OUTPUT
    )
AS -- Add the parameters for the stored procedure here
    DECLARE @select AS NVARCHAR(MAX)
    DECLARE @errormsg AS NVARCHAR(MAX) ,
        @updateRemarks AS NVARCHAR(MAX)
    DECLARE @error AS INT 
    SELECT  @error = 0 ,
            @errormsg = ''
    DECLARE @DecimalScale AS INT
    SELECT  @DecimalScale = DecimalScale
    FROM    SysParam 

	PRINT '@orgpar' + @Parameters
	
	DECLARE @lang AS NCHAR(1)
			--SET @lang = @Parameters
			--PRINT '@lang=' + @lang

	

    DECLARE @Row_Number AS INT 
    
    DECLARE @Cursor_Post BIT ,
        @Cursor_Remarks NVARCHAR(20)
    DECLARE @count AS INT
    DECLARE @ErrorValue AS INT
    
	 DECLARE @DateFormat AS int
 SELECT @DateFormat= dateformat FROM SysParam 
   IF @DateFormat=1 SET @DateFormat=103
  IF @DateFormat=2 SET @DateFormat=101
  IF @DateFormat=0 SET @DateFormat=111

  	DECLARE @enableAttachments AS BIT
	DECLARE @enableRef AS BIT
	SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 
--Post


    IF @actiontype = 1
        BEGIN
	 --Declaration of the reference and attachements 
            DECLARE @Parameter1 AS NVARCHAR(100)
            DECLARE @RefYear AS NVARCHAR(100)--RefYear
            DECLARE @RefNum AS NVARCHAR(10)--RefNum
            DECLARE @IssueDate AS NVARCHAR(100)--IssueDate
            DECLARE @ExecDate AS NVARCHAR(100)--ExecDate
            DECLARE @RefStatus AS NVARCHAR(100)--RefStatus
            DECLARE @RefSource AS NVARCHAR(100)--RefSource
            DECLARE @RrfDesc AS NVARCHAR(MAX)--RrfDesc
            DECLARE @AttachmentPath AS NVARCHAR(MAX)--AttachmentPath
            DECLARE @AttachmentDesc AS NVARCHAR(120)--Desc
            DECLARE @AttachmentADesc AS NVARCHAR(120)--ADesc
            DECLARE @EnterDate AS NVARCHAR(100)--EnterDate
            DECLARE @EnterBy AS INT --EnterBy
            --DECLARE @enableAttachments AS BIT
            --DECLARE @enableRef AS BIT
	
	--Declaration of the Values
            DECLARE @StartIndex AS INT
            DECLARE @AdditionalTraining AS NVARCHAR(MAX)
            DECLARE @EnrollStatus AS INT
            DECLARE @CEnrollStatus AS NVARCHAR(100)
            DECLARE @FromDate AS SMALLDATETIME
            DECLARE @ToDate AS SMALLDATETIME
            DECLARE @Method AS INT
            DECLARE @CMethod AS NVARCHAR(100)
            DECLARE @Currency AS INT
            DECLARE @CCurrency AS NVARCHAR(100)
            DECLARE @TotalHours AS NVARCHAR(MAX)
            DECLARE @EnrollCost AS NVARCHAR(MAX)
            DECLARE @Score AS NVARCHAR(MAX)
            DECLARE @PostTestScore AS NVARCHAR(MAX)
            DECLARE @AttendanceDays AS NVARCHAR(MAX)
            DECLARE @PreTestScore AS NVARCHAR(MAX)
            DECLARE @TrainingPlan AS INT
            DECLARE @CTrainingPlan AS NCHAR(100)
            DECLARE @TrainingActivity AS INT
            DECLARE @CTrainingActivity AS NVARCHAR(100)
            DECLARE @Location AS NVARCHAR(MAX)
            DECLARE @Provider AS NVARCHAR(MAX)
            DECLARE @otherInformation AS NVARCHAR(MAX)
            DECLARE @Login AS INT 

            DECLARE @EmpId AS INT
            DECLARE @name AS NVARCHAR(256)
            DECLARE @DocumentNo AS INT
    --        DECLARE @DateFormat AS INT

			 --SELECT  @DateFormat = CASE WHEN ( SELECT    [DateFormat]
    --                                          FROM      dbo.SysParam
    --                                        ) = 1 THEN 103
    --                                   WHEN ( SELECT    [DateFormat]
    --                                          FROM      dbo.SysParam
    --                                        ) = 2 THEN 101
    --                                   ELSE 111
    --                              END

			
			

            --SELECT  @enableRef = EnableReferences ,
            --        @enableAttachments = EnableAttachments
            --FROM    SysParam 
	
            --SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 
	
	DECLARE @index AS smallint
	
	SET @index=CHARINDEX(',',@Parameters)
	SET @lang= case when (substring (@Parameters,0,@index) <>'') THEN substring (@Parameters,0,@index) ELSE 'E' END
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))

	SET @index=charindex(',',@Parameters)	
	SET @Parameter1=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@Parameter1='+@Parameter1
	PRINT @Parameters
	
	
	--Enable Refrence params
	SET @index=charindex('@referenceNostart',@Parameters)	
	PRINT @Parameters
	SET @RefYear=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceNostart'),len(@Parameters))
	PRINT '@RefYear='+@RefYear
	PRINT @Parameters
	
	SET @index=charindex('@referenceNoEnd',@Parameters)	
	SET @RefNum=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceNoEnd'),len(@Parameters))
	PRINT '@RefNum='+@RefNum
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @IssueDate=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@IssueDate='+@IssueDate
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @ExecDate=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@ExecDate='+@ExecDate
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @RefStatus=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@RefStatus='+@RefStatus
	PRINT @Parameters
	
	SET @index=charindex('@referenceDescstart',@Parameters)	
	SET @RefSource=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceDescstart'),len(@Parameters))
	PRINT '@RefSource='+@RefSource
	PRINT @Parameters
	


IF @enableAttachments=1
BEGIN


		SET @index=charindex('@referenceDescEnd',@Parameters)	
	SET @RrfDesc=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@referenceDescEnd'),len(@Parameters))
	PRINT '@RrfDesc='+@RrfDesc
	PRINT @Parameters
	
	SET @index=charindex('@AttachmentPathEnd',@Parameters)	
	SET @AttachmentPath=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@AttachmentPathEnd'),len(@Parameters))
	PRINT '@AttachmentPath='+@AttachmentPath
	PRINT @Parameters
	
	SET @index=charindex('@AttachmentDesEnd',@Parameters)	
	SET @AttachmentDesc=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@AttachmentDesEnd'),len(@Parameters))
	PRINT '@AttachmentDesc='+@AttachmentDesc
	PRINT @Parameters
	
	SET @index=charindex('@AttachmentADesEnd',@Parameters)	
	SET @AttachmentADesc=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+len('@AttachmentADesEnd'),len(@Parameters))
	PRINT '@AttachmentADesc='+@AttachmentADesc
	PRINT @Parameters
	
	SET @index=charindex(',',@Parameters)	
	SET @EnterDate=substring(@Parameters,0,@index)
	SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
	PRINT '@EnterDate='+@EnterDate
	PRINT @Parameters
	
	SET @EnterBy=@Parameters
	PRINT '@EnterBy='+STR(@EnterBy)
	
END
ELSE
	BEGIN
		SET @RrfDesc=@Parameters
		PRINT '@RrfDesc='+@RrfDesc
	END
		--SELECT @TrainingActivity = TrainingActivity FROM dbo.TrainingActivities WHERE TrainingActivityName = @TrainingActivity
	
   --         PRINT 'Post'
			--PRINT '@Where= ' + STR(@Where)
			--PRINT '@lang= ' + STR(@lang)

			


	--SELECT @Currency = cur FROM dbo.Currency WHERE CurName = @CCurrency
	--SELECT @Method = TrainingMethod FROM dbo.TrainingMethods WHERE TrainingMethodName = @CMethod 
	--SELECT @EnrollStatus = EnrollStatus FROM dbo.TrainingEnrollStatus WHERE EnrollStatusName = @CEnrollStatus 
	--SELECT @TrainingPlan = TrainingPlan FROM dbo.TrainingPlans WHERE TrainingPlanName = @CTrainingPlan 

	DECLARE @Cur_RYear AS SMALLINT=null, @Cur_RNo AS nvarchar(10)=null, @Cur_IssueDate as nvarchar (100)=null, @Cur_ExecDate AS nvarchar (100)=null
					,@Cur_RStatus AS SMALLINT=null, @Cur_RSource  AS SMALLINT =null, @Cur_RDesc nvarchar(max) =null
					,@cur_AttachDesc nvarchar(max) , @cur_AttachPath nvarchar(max) ,@cur_str NVARCHAR(MAX)='',@cur_str2 NVARCHAR(MAX)=''
					 
					IF   @enableRef = 1
 begin
 SET @cur_str= ' , t.[RYear], t.[RNo], t.[RIssueDate] , t.[RExecDate] 
				,NasArraysStatus.itemno [RStatus], NasArraysSource.itemno [RSource] , t.[RDesc] '

				
 SET @cur_str2='LEFT JOIN NasArrays NasArraysStatus ON t.[RStatus] = case when '''+@lang+'''= ''E'' then ltrim(rtrim(NasArraysStatus.edesc)) else ltrim(rtrim(NasArraysStatus.adesc)) end 
AND NasArraysStatus.arrayname=''RStatus'' 
LEFT JOIN NasArrays NasArraysSource ON t.[RSource] = case when '''+@lang+'''= ''E'' then ltrim(rtrim(NasArraysSource.edesc)) else ltrim(rtrim(NasArraysSource.adesc)) end  
AND NasArraysSource.arrayname=''RSource'' '
end
ELSE
SET @cur_str= ' , null, null, null , null,null,null , null '

IF @enableAttachments=1
SET @cur_str= @cur_str +' ,t.AttDesc, t.AttPath '
ELSE
SET @cur_str= @cur_str + ' , null, null '

            EXEC(' DECLARE empTrainingCursor CURSOR FOR SELECT DISTINCT EmpAssignment.EmpId ,
            t.AdditionalTraining,
            t.EnrollStatus, 
            t.FromDate,
            t.ToDate,
            t.Method, t.Currency ,t.TotalHours,t.EnrollCost,
            t.Score,t.AttendanceDays,t.PreTestScore,t.PostTestScore,t.TrainingPlan,t.TrainingActivity
            ,t.Location,t.Provider,t.otherInformation,t.Post,t.remarks,t.Row_Number'+@cur_str +' 
            FROM '+@tablename+' t 
			INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId = rtrim(ltrim(isnull(t.empid,'''')))
			'+@cur_str2  +'
            where t.Post=1 and (rtrim(ltrim(isnull(t.remarks,'''')))=''''
            )')

			PRINT 'Open Cursor'

			

            OPEN empTrainingCursor
            FETCH NEXT FROM empTrainingCursor
INTO @EmpId, @AdditionalTraining, @CEnrollStatus, @FromDate, @ToDate, @CMethod,
                @CCurrency, @TotalHours, @EnrollCost, @Score, @AttendanceDays,
                @PreTestScore, @PostTestScore, @CTrainingPlan,
                @CTrainingActivity, @Location, @Provider, @otherInformation,
                @Cursor_Post, @Cursor_Remarks,@Row_Number,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath
            WHILE @@FETCH_STATUS = 0
                BEGIN
				--SET @AdditionalTraining=ISNULL(@AdditionalTraining,'')
                    
                            PRINT ' @EmpId= ' + STR(@EmpId)

							PRINT 'Insert'
                            SET @DocumentNo = dbo.GetDocumentNo(@EmpId, 9)
							---besho---
							SELECT @Currency = cur FROM Currency WHERE CurName = LTRIM(RTRIM(@CCurrency)) OR CurAName = LTRIM(RTRIM(@CCurrency))
							SELECT @Method = TrainingMethod FROM TrainingMethods WHERE TrainingMethodName = LTRIM(RTRIM(@CMethod)) OR TrainingMethodAName = LTRIM(RTRIM(@Currency))
							SELECT @TrainingPlan = TrainingPlan FROM TrainingPlans WHERE TrainingPlanName = LTRIM(RTRIM(@CTrainingPlan)) OR TrainingPlanAName = LTRIM(RTRIM(@CTrainingPlan))
							SELECT @EnrollStatus = EnrollStatus FROM TrainingEnrollStatus WHERE EnrollStatusName = LTRIM(RTRIM(@CEnrollStatus)) OR EnrollStatusAName = LTRIM(RTRIM(@CEnrollStatus))
							SELECT @TrainingActivity = TrainingActivity FROM TrainingActivities WHERE TrainingActivityName = LTRIM(RTRIM(@CTrainingActivity)) OR TrainingActivityAName = LTRIM(RTRIM(@CTrainingActivity))

--IF @AdditionalTraining IS null
--	SET @AdditionalTraining=''
--IF @EnrollStatus IS NULL
--	SET @EnrollStatus=1	
--IF @TotalHours IS NULL
--	SET @TotalHours=0
--IF @EnrollCost IS NULL
--	SET @EnrollCost=0
--IF @Score IS NULL
--	SET @Score=0
--IF @PreTestScore IS NULL
-- 	SET @PreTestScore=0
--IF @AttendanceDays IS NULL
--	SET @AttendanceDays=0
--IF @PostTestScore IS NULL
--	SET @PostTestScore=0
--IF @Location IS NULL
--	SET @Location=''
--IF @Provider IS NULL
--	SET @Provider=''
--IF @otherInformation IS NULL
--	SET @otherInformation=''


                            PRINT ' @DocumentNo= ' + STR(@DocumentNo)

                         
                                    PRINT 'Inserting English'
                                    INSERT INTO EmpTraining
                                            ( EmpId ,
                                              DocumentNo ,
                                              EnrollStatus ,
                                              TrainingCost ,
                                              CostCurrency ,
                                              TrainingScore ,
                                              PreTestScore ,
                                              PostTestScore ,
                                              AttendanceDays ,
                                              AdditionalTraining ,
                                              AdditionalTrainingName ,
											  AdditionalTrainingAName ,
                                              AdditionalTrainingMethod ,
                                              AdditionalTrainingPlan ,
                                              AdditionalTrainingActivity ,
                                              AdditionalTrainingProvider ,
                                              AdditionalTrainingLocation ,
                                              AdditionalTrainingALocation ,
                                              AdditionalTrainingFrom ,
                                              AdditionalTrainingTo ,
                                              AdditionalTrainingTotalHours ,
                                              TrainingInfo ,
                                              EnterBy ,
                                              EnterDate ,
                                              EmpTrainingRYear ,
                                              EmpTrainingRNo ,
                                              EmpTrainingRIssueDate ,
                                              EmpTrainingRExecDate ,
                                              EmpTrainingRStatus ,
                                              EmpTrainingRSource ,
                                              EmpTrainingRDesc
                                            )
                                    VALUES  ( @EmpId ,
                                              @DocumentNo ,
                                              ISNULL(@EnrollStatus, 1) ,
                                              ISNULL(@EnrollCost, 0.0) ,
                                              @Currency ,
                                              ISNULL(@Score, 0.0) ,
                                              ISNULL(@PreTestScore, 0) ,
                                              ISNULL(@PostTestScore, 0) ,
                                              ISNULL(@AttendanceDays, 0) ,
                                              1 ,
                                              ISNULL(@AdditionalTraining, '') ,
											  ISNULL(@AdditionalTraining, '') ,
                                              @Method ,
                                              @TrainingPlan ,
                                              @TrainingActivity ,
                                              ISNULL(@Provider, '') ,
                                              ISNULL(@Location, '') ,
                                              ISNULL(@Location, '') ,
                                              CONVERT(SMALLDATETIME, @FromDate, @DateFormat) ,
                                              CONVERT(SMALLDATETIME, @ToDate, @DateFormat) ,
                                              ISNULL(@TotalHours, 0) ,
                                              ISNULL(@otherInformation, '') ,
                                              @Parameter1 ,
                                              GETDATE() ,
                                             	ISNULL(lTRIM(@Cur_RYear),@RefYear) ,ISNULL(@Cur_RNo,@RefNum)
					,ISNULL(@Cur_IssueDate,CASE WHEN @IssueDate='NULL' THEN NULL ELSE @IssueDate END)
					,ISNULL(@Cur_ExecDate,CASE WHEN @ExecDate='NULL' THEN NULL ELSE @ExecDate END)
		,ISNULL(lTRIM(@Cur_RStatus),CASE WHEN @RefStatus='NULL' THEN NULL ELSE @RefStatus END)
		,ISNULL(lTRIM(@Cur_RSource),CASE WHEN @RefSource='NULL' THEN NULL ELSE @RefSource END) 
		, ISNULL(@Cur_RDesc,@RrfDesc)
                                            )
                                

                             

                            SET @ErrorValue = @@ERROR
                            PRINT STR(@@ERROR) + 'error' + STR(@ErrorValue)
                             IF @enableAttachments=1 AND ISNULL(@cur_AttachPath,@AttachmentPath)<>'' AND @ErrorValue=0 
                                BEGIN
					
							
                                    INSERT  INTO Attachments
                                            ( -- AttachmentId -- this column value is auto-generated,
                                              EmpId ,
                                              FormNo ,
                                              DocumentNo ,
                                              SubDocumentNo ,
                                              SubDocumentIdentity ,
                                              AttachmentDescription ,
                                              AttachmentADescription ,
                                              AttachmentPath ,
                                              EnterBy ,
                                              EnterDate
					                        )
                                    VALUES  ( @EmpId ,
                                              9 ,
                                              @DocumentNo ,
                                              0 ,
                                              0 ,
                                             ISNULL(@cur_AttachDesc,@AttachmentDesc)
					                       ,ISNULL(@cur_AttachDesc,@AttachmentDesc),
					                        ISNULL(@cur_AttachPath,@AttachmentPath),
                                              @Parameter1 ,
                                              CONVERT(SMALLDATETIME, @EnterDate, @DateFormat)
					                        )
					
                                END 



                    FETCH NEXT FROM empTrainingCursor
					INTO @EmpId, @AdditionalTraining, @CEnrollStatus, @FromDate, @ToDate, @CMethod,
						@CCurrency, @TotalHours, @EnrollCost, @Score, @AttendanceDays,
						@PreTestScore, @PostTestScore, @CTrainingPlan,
						@CTrainingActivity, @Location, @Provider, @otherInformation,
						@Cursor_Post, @Cursor_Remarks,@Row_Number,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath
                END
            CLOSE empTrainingCursor
            DEALLOCATE empTrainingCursor

        END

--Import
    IF @actiontype = 2
        BEGIN
            DECLARE @str AS NVARCHAR(MAX) ,
                @t AS NVARCHAR(150)
            SET @t = @tablename
            SET @t = REPLACE(@t, 'dbo.[', '')
            SET @t = REPLACE(@t, ']', '')
            SELECT  @count = COUNT(*)
            FROM    sysobjects s
            WHERE   s.name = @t
		
	
            IF @actual > 0
                BEGIN
                    SET @str = 'select 0 as empid,'''' as name,0.00 as inputamount,'''' as AdditionalTraining ,'''' as EnrollStatus ,''1900/01/01'' as FromDate,''1900/01/01'' as ToDate,'''' as Method ,'''' as Currency
			 ,0.00 as TotalHours,0.00 as EnrollCost,0.00 as Score,
			 '''' as PostTestScore,'''' as AttendanceDays,
			 '''' as PreTestScore,'''' as TrainingPlan,'''' as TrainingActivity,'''' as Location,'''' as Provider,'''' as  OtherInformation,0 as Post,'''' as remarks WHERE 1<>1'
                END
		
            ELSE
                IF @count = 1
                    SET @str = 'select * FROM ' + @tablename
                ELSE
                    BEGIN
				
                        SET @str = 'select 0 as empid,'''' as name,0.00 as inputamount,'''' as AdditionalTraining ,'''' as EnrollStatus ,'''' as FromDate,'''' as ToDate,'''' as Method ,'''' as Currency
			 ,0.00 as TotalHours,0.00 as EnrollCost,0.00 as Score,
			 '''' as PostTestScore,'''' as AttendanceDays,
			 '''' as PreTestScore,'''' as TrainingPlan,'''' as TrainingActivity,'''' as Location,'''' as Provider,'''' as  OtherInformation,0 as Post,'''' as remarks WHERE 1<>1'
					
                    END
				
            EXEC sp_executesql @str
	
        END

--Export
    IF @actiontype = 3
        BEGIN
	   SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 
            DECLARE @updatestr AS NVARCHAR(MAX) ,
                @insertstr AS NVARCHAR(MAX) ,
                @deletestr AS NVARCHAR(MAX) ,
                @selectstr AS NVARCHAR(MAX) ,
                @DisabledColStr AS NVARCHAR(100)
				, @CreateStrRefAttach AS nvarchar(max)='', @SelectStrRefAttach AS nvarchar(max)='', @InsertStrRefAttach AS nvarchar(max)='', @UpdateStrRefAttach AS nvarchar(max)=''
            IF RTRIM(LTRIM(@tablename)) <> ''
                BEGIN
                    DECLARE @TableNamelen AS INT 
                    SET @TableNamelen = LEN(@tablename)
                        - CHARINDEX('[nasbatch', @tablename) - 1
			  IF  @enableRef = 1
		SET @CreateStrRefAttach='[RYear] [smallint],[RNo] [nvarchar](10),[RIssueDate] [datetime],[RExecDate] [datetime]
					,[RStatus] [nvarchar](30),[RSource] [nvarchar](30),[RDesc] [nvarchar](max) ,'

		IF @enableAttachments=1
		SET @CreateStrRefAttach= @CreateStrRefAttach+' AttDesc [nvarchar](max), AttPath [nvarchar](max),'

			  
                    SET @select = 'IF not EXISTS(SELECT top 1 1 
              FROM ' + PARSENAME(@tablename, 3)
                        + '.INFORMATION_SCHEMA.Columns 
              WHERE ' + PARSENAME(@tablename, 3)
                        + '.INFORMATION_SCHEMA.Columns.TABLE_NAME='''
                        + PARSENAME(@tablename, 1) + ''')' + ' CREATE TABLE '
                        + @tablename
                        + ' ( empid [nvarchar](256) ,name [nvarchar](256)  collate database_default ,
 			 AdditionalTraining	[nvarchar](256) ,EnrollStatus [nvarchar](256) ,FromDate datetime,ToDate datetime ,Method [nvarchar](256),Currency [nvarchar](256)
			 ,TotalHours [numeric](9, 3), EnrollCost [numeric](18, 3), Score [numeric](9, 3),
			 PostTestScore [nvarchar](256), AttendanceDays [nvarchar](256),
			 PreTestScore [nvarchar](256), TrainingPlan [nvarchar](256), TrainingActivity [nvarchar](256), Location [nvarchar](max), Provider [nvarchar](max), 
			 OtherInformation [nvarchar](max),'+ @CreateStrRefAttach + 'Post bit,remarks [nvarchar](max),[Row_Number] int Identity(1,1) NOT NULL Primary Key)'
			  
                END
            
            ELSE
                BEGIN
                    SET @tablename = '  '
                    BEGIN
					 IF  @enableRef = 1
		 SET @SelectStrRefAttach=' 0  as [RYear] ,'''' as [RNo], '''' as [RIssueDate] , '''' as [RExecDate] 
	, ''''  as [RStatus] ,''''  as [RSource] ,'''' as [RDesc] ,'

		IF @enableAttachments=1
		SET @SelectStrRefAttach= @SelectStrRefAttach+' ''''  as AttDesc , ''''  as AttPath ,'

                        SET @selectstr = 'select 0 as empid,'''' as name,0.00 as inputamount,'''' as AdditionalTraining ,'''' as EnrollStatus ,''1900/01/01'' as FromDate,''1900/01/01'' as ToDate,'''' as Method ,'''' as Currency
			 ,0.00 as TotalHours,0.00 as EnrollCost,0.00 as Score,
			 '''' as PostTestScore,'''' as AttendanceDays,
			 '''' as PreTestScore,'''' as TrainingPlan,'''' as TrainingActivity,'''' as Location,'''' as Provider,'''' as  OtherInformation,'+ @SelectStrRefAttach+' 0 as post,'''' as remarks, 0 as Row_Number'
                    END
                END
		
            --BEGIN
			PRINT 'begin update'
			 IF  @enableRef = 1 
  SET @UpdateStrRefAttach=' RYear=ltrim(rtrim(@RYear)), RNo=ltrim(rtrim(@RNo))
, RIssueDate=convert(datetime,@RIssueDate,'+ltrim(rtrim(str(@DateFormat)))+')
, RExecDate =convert(datetime,@RExecDate,'+ltrim(rtrim(str(@DateFormat)))+')
,RStatus=ltrim(rtrim(@RStatus)), RSource=ltrim(rtrim(@RSource)), RDesc=ltrim(rtrim(@RDesc)),'

IF @enableAttachments=1
  SET @UpdateStrRefAttach= @UpdateStrRefAttach+' AttDesc=ltrim(rtrim(@AttDesc)) , AttPath=ltrim(rtrim(@AttPath)) ,'


			SET @updatestr = ''
                SET @updatestr = 'Update ' + @tablename
                    + ' SET AdditionalTraining=@AdditionalTraining
			,EnrollStatus= @EnrollStatus  
			,FromDate=convert(datetime,@FromDate,'+ltrim(rtrim(str(@DateFormat)))+')
			,ToDate=convert(datetime,@ToDate,'+ltrim(rtrim(str(@DateFormat)))+')
			,Method=@Method
			,Currency=@Currency
			,TotalHours=@TotalHours
			,EnrollCost=@EnrollCost
			,Score=@Score
			,PostTestScore=@PostTestScore
			,AttendanceDays=@AttendanceDays
			,PreTestScore=@PreTestScore
			,TrainingPlan=@TrainingPlan
			,TrainingActivity=@TrainingActivity
			,Location=@Location
			,Provider=@Provider
			,otherInformation=@otherInformation
			, '+@UpdateStrRefAttach  +'Post=@Post
			where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'
			
			--exec [Batch_Validate] '''+@tablename+''',''' + @LogonName +''',@originalRow_Number,''WP_GetExternalAdditionalEvents'',''' + @lang+''''

			
			PRINT @updatestr

            IF  @enableRef = 1  
	SET @InsertStrRefAttach=' @RYear, @RNo, @RIssueDate, @RExecDate 
					,@RStatus, @RSource, @RDesc, '
IF @enableAttachments=1
	SET @InsertStrRefAttach= @InsertStrRefAttach+' @AttDesc , @AttPath ,'
	   
            --BEGIN
                SET @insertstr = ' insert into ' + @tablename
                    + ' select @empid ,
 	@name ,@AdditionalTraining ,@EnrollStatus ,convert(datetime,@FromDate,'+ltrim(rtrim(str(@DateFormat)))+') ,convert(datetime,@ToDate,'+ltrim(rtrim(str(@DateFormat)))+') ,@Method, @Currency, @TotalHours, @EnrollCost,
 	@Score,@AttendanceDays,@PreTestScore,@PostTestScore,@TrainingPlan,@TrainingActivity,@Location,@Provider,@otherInformation,'+@InsertStrRefAttach+'@Post ,@remarks,@originalRow_Number'
            --END

			PRINT @insertstr


            SET @deletestr = ' DELETE FROM  ' + @tablename
                + ' where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'

				PRINT @deletestr

	--	IF @lang='A' SET @hidecolstr='1,2,4,5'
	--	ELSE
	 IF  @enableRef = 1  SET @count=@count+7
	  IF  @enableAttachments = 1  SET @count=@count+2
            SET @DisabledColStr = '1,2,30'

            EXEC sp_executesql @select

            SELECT  @updatestr AS updatestr ,
                    @insertstr AS insertstr ,
                    @deletestr AS deletestr ,
                    @DisabledColStr AS DisabledColStr
        END

GO

