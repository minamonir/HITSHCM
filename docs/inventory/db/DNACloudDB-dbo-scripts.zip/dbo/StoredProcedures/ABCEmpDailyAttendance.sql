
CREATE PROCEDURE [dbo].[ABCEmpDailyAttendance] (@from as datetime,@to as datetime,@filterwhere as Nvarchar(max),@selectgroups as Nvarchar(max))  
AS
BEGIN
	
--test 1234567891214456
declare @date as datetime
declare @Query as Nvarchar(max)

set @date=@from
--create a table contains the values for the date 
Create table #Date
([Date]  datetime) 	
	--fill yhe date table
	while @to >= @date 
		begin
			insert into  #Date values(@date)
			set @date= dateadd(d, 1, @date )
		end	

--create table to hold all the data
create table #EmpAttend 
( EmpId int,
EmployeeId NVARCHAR(50),
Name nvarchar(88),
AName nvarchar(88),
JobName nvarchar(250),
JobAName nvarchar(250),
OrganizationName nvarchar(250),
OrganizationAName nvarchar(250),
vaccode INT,
ShiftIn NVARCHAR(5),
ShiftOut NVARCHAR(5),
TimeIn DATETIME,
TIMEOUT DATETIME,
Date SmallDATETIME,
VacType INT,  --  1-vacation 2-Absent 3-DayOff 4-Holiday
VacTypeName nvarchar(60),
VacTypeAName nvarchar(60),
WorkingSecs int
)

set @Query = 'Select distinct Empassignment.Empid,Empassignment.Employeeid,
Profile.Name,Profile.AName,Jobs.JobName, Jobs.JobAName,
Organization.OrganizationName,Organization.OrganizationAName,NULL,NULL,NULL,NULL,NULL,
#Date.Date,NULL,NULL,NULL,0
From Empassignment 
LEFT JOIN profile on empassignment.empid=profile.profileid 
LEFT JOIN EmpVacat on EmpVacat.Empid = EmpAssignment.Empid 
LEFT JOIN Vacation ON EmpVacat.VacCode = Vacation.vaccode 
LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname =''Status'' 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade
LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
CROSS JOIN SysParam 
CROSS JOIN #Date where 1=1 '+ @filterwhere



	
INSERT into #EmpAttend  execute( @Query)

UPDATE #EmpAttend SET #EmpAttend.TimeIn = dbo.GetShiftTime(#EmpAttend.EmpId, #EmpAttend.Date,1),
    #EmpAttend.TIMEOUT = dbo.GetShiftTime(#EmpAttend.EmpId, #EmpAttend.Date,2),
    #EmpAttend.ShiftIn = TimeShifts.FromTime ,
    #EmpAttend.ShiftOut =TimeShifts.ToTime,
    WorkingSecs=(Select SUM(esio.WorkSeconds) FROM EmpShiftInOut esio
                 WHERE esio.EmpId=#EmpAttend.EmpId AND esio.EntryDate=#EmpAttend.Date)
FROM #EmpAttend 
	LEFT join EmpShift ON EmpShift.EmpId=#EmpAttend.EmpId AND #EmpAttend.Date=EmpShift.ShiftDate 
	LEFT JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo



update #EmpAttend 
	SET vaccode = vacation.vaccode,VacTypeName = vacation.VacationName,
	VacTypeAName = vacation.VacationAName, VacType=1	
from empvacat 
	INNER JOIN #EmpAttend ON #EmpAttend.EmpId = empvacat.EmpId
	LEFT JOIN vacation on empvacat.vaccode=vacation.vaccode  
where Date between empvacat.fromdate and empvacat.Todate and EmpVacat.VacStatus=1

UPDATE #EmpAttend SET VacTypeName = 'Absent',VacTypeAName = N'غائب', VacType=2
WHERE #EmpAttend.TimeIn IS NULL 
AND #EmpAttend.TIMEOUT IS NULL 
AND #EmpAttend.ShiftIn IS NOT NULL
AND #EmpAttend.ShiftOut IS NOT NULL 
AND #EmpAttend.vacCode IS NULL

UPDATE  #EmpAttend SET VacTypeName = 'Holidays',VacTypeAName=N'عطلات', VacType=4
        from holidays
        LEFT JOIN VacPack ON VacPack.vacpack = holidays.vacpack
        LEFT JOIN EmpAssignment  ON EmpAssignment.VacPack = vacpack.vacpack
        INNER JOIN #EmpAttend ON #EmpAttend.EmpId = EmpAssignment.EmpId
        where holidays.vacpack=EmpAssignment.VacPack 
        and holidays.holiday=1 
        and holidays.date = #EmpAttend.Date

        
UPDATE  #EmpAttend SET VacTypeName = 'Day Off',VacTypeAName=N'اسبوعية' , VacType=3
FROM vacpack
LEFT JOIN EmpAssignment  ON EmpAssignment.VacPack = vacpack.vacpack
INNER JOIN #EmpAttend ON #EmpAttend.EmpId = EmpAssignment.EmpId
where vacpack.vacpack=EmpAssignment.vacpack and vacpack.dofftype=1
AND (DATEPART(dw,#EmpAttend.Date) =  vacpack.doffday1 OR DATEPART(dw,#EmpAttend.Date) =  vacpack.doffday2)


declare @from2 as Nvarchar(max)

Set @from2 = ' From #EmpAttend 
 left join EmpAssignment on EmpAssignment.empid=#EmpAttend.empid 
 left join Profile on EmpAssignment.empid=profile.profileid 
 LEFT JOIN  Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
 LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
 LEFT JOIN  JobCat ON JobCat.jobcat=Jobs.jobcat 
 LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
 LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
 LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
 LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
 LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
 LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
 LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup
 LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType '
Set @Query =' Select #EmpAttend.* '+
 @selectgroups + @from2
exec sp_executesql @Query

DROP TABLE #Date
DROP TABLE #EmpAttend

END

GO

