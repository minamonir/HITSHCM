
CREATE PROCEDURE  [dbo].[BatchWP_ExternalSystemsBatchPosting]
(
	    @actiontype AS SMALLINT,
	    @tablename as nvarchar(150),
		@actual AS SMALLINT,
		@Where AS NVARCHAR(MAX),
		@Paramaters AS NVARCHAR(MAX),
		@outputstr AS NVARCHAR(MAX)OUTPUT)
AS
BEGIN
DECLARE 
	@StartIndex AS INT,
	@PayrollGroup AS smallint,
	@periodyear AS smallint=0,
	@periodmonth AS SMALLINT=0,
	@RunNo AS SMALLINT=1,
	@LogonName  AS varchar (100),
	@lang AS nCHAR(1),
	@CurrentEmpID as int,
	@CurrentEmployeeID as nvarchar(50),
	@CurrentFormBatch as nvarchar(250),
	@CurrentEmp901tax as numeric(18,3)

declare @select nvarchar(max)
IF @actiontype=1
BEGIN


IF LTRIM(RTRIM(@Paramaters))<>''
BEGIN

	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @PayrollGroup= substring (@Paramaters,0,@StartIndex) 
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')
	
	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @periodyear=isnull(substring(@Paramaters,0,@StartIndex),0)
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')

	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @periodmonth=isnull(substring(@Paramaters,0,@StartIndex),0)
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')

	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @RunNo=isnull(substring(@Paramaters,0,@StartIndex),1)
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')
	
	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @LogonName=isnull(substring(@Paramaters,0,@StartIndex),'')
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')

	SET @lang = isnull(@Paramaters,'E')


end

if RTRIM(LTRIM(@tablename))<>'' 
begin

create table #Result(ResultRecord nvarchar(100))

set @select=('
declare @Message nvarchar(max) ='''',@CurrentEmployeeID NVARCHAR(255), @CurrentEmpID int , @CurrentEmp901tax numeric(18,3)  ,@CurrentFormBatch nvarchar(100) ,@RunNo smallint = '+cast(@RunNo as nvarchar)+'
DECLARE Emp901Taxs CURSOR FOR 
SELECT EmployeeId, Emp901tax ,FormBatch FROM '+@tablename+'  where post = 1
')
exec (@select)

OPEN Emp901Taxs
FETCH next FROM Emp901Taxs  INTO  @CurrentEmployeeID , @CurrentEmp901tax , @CurrentFormBatch

WHILE @@FETCH_STATUS=0
BEGIN


select @CurrentEmpID = Empid from Empassignment where employeeid = @CurrentEmployeeID

if exists(select * from MonthlyTransaction where empid = @CurrentEmpID and paycode = 901 and runno = @RunNo)
begin

if exists(
select * from EmpETaxResults where empid = @CurrentEmpID  
and payrollgroup = @PayrollGroup and Year = @periodyear 
and month = @periodmonth and runno = @RunNo
and batchid = @CurrentFormBatch
)

begin

    insert into #Result select 'Employee' +@CurrentEmployeeID +' has been updated before' + CHAR(13)+CHAR(10)

end
else
begin

update MonthlyTransaction set  Amount = @CurrentEmp901tax , InputAmnt = @CurrentEmp901tax  where EmpID = @CurrentEmpID and RunNo = @RunNo  and paycode = 901

BEGIN TRY  

insert into EmpETaxResults (payrollgroup,year,month,runno,batchid,batchdate,empid,p901amount,username,otherinfo) 
values (@PayrollGroup, @periodyear,@periodmonth, @RunNo,@CurrentFormBatch  ,GetDate(),@CurrentEmpID,@CurrentEmp901tax,@logonname,'Success')
 
    insert into #Result select 'Employee ' + @CurrentEmployeeID + ' tax has been updated successfully' + CHAR(13)+CHAR(10)

END TRY  
BEGIN CATCH  

   insert into #Result select ERROR_MESSAGE() + CHAR(13)+CHAR(10)

END CATCH;   

end

end

else
begin

if exists(
select * from EmpETaxResults where empid = @CurrentEmpID  
and payrollgroup = @PayrollGroup and Year = @periodyear
and month = @periodmonth and runno = @RunNo  
and batchid = @CurrentFormBatch
)

begin

    insert into #Result select 'Employee '+@CurrentEmployeeID +' has been inserted before' + CHAR(13)+CHAR(10)

end
else
begin

insert into MonthlyTransaction(EmpId,RunNo,Paycode,InputAmnt,Amount) values (@CurrentEmpID,@RunNo,901,@CurrentEmp901tax,@CurrentEmp901tax)


--exec Pay_CalcEmployee @Empid = @CurrentEmpID

BEGIN TRY  

insert into EmpETaxResults (payrollgroup,year,month,runno,batchid,batchdate,empid,p901amount,username,otherinfo) 
values (@PayrollGroup,@periodyear,@periodmonth, @RunNo, @CurrentFormBatch, GetDate(),@CurrentEmpID,@CurrentEmp901tax,@logonname,'Success')

     insert into #Result select 'Employee ' + @CurrentEmployeeID + ' tax has been inserted successfully' + CHAR(13)+CHAR(10)

END TRY  
BEGIN CATCH  

    insert into #Result select ERROR_MESSAGE() + CHAR(13)+CHAR(10)

END CATCH;   

end
end
  

FETCH next FROM Emp901Taxs  INTO  @CurrentEmployeeID , @CurrentEmp901tax , @CurrentFormBatch

end	

close Emp901Taxs
deallocate Emp901Taxs

select * from #Result

END

end
drop table #Result
IF @actiontype=3
BEGIN

    DECLARE @updatestr       AS NVARCHAR(MAX)
           ,@insertstr       AS NVARCHAR(MAX)
           ,@deletestr       AS NVARCHAR(MAX)
           ,@selectstr       AS NVARCHAR(MAX)
           ,@DisabledColStr  AS NVARCHAR(100)


		   IF RTRIM(LTRIM(@tablename))<>'' 
		BEGIN
			DECLARE @TableNamelen AS INT 
			SET @TableNamelen = LEN(@TableName)-CHARINDEX('[nasbatch' ,@TableName)-1
			SET @select = 'IF not EXISTS(SELECT top 1 1
						FROM '+SUBSTRING(@tablename ,0 ,CHARINDEX('.dbo' ,@tablename))+
						'.INFORMATION_SCHEMA.Columns 
						WHERE  '+SUBSTRING(@tablename ,0 ,CHARINDEX('.dbo' ,@tablename))+
						'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+SUBSTRING(
						@TableName
						,CHARINDEX('[nasbatch' ,@TableName)+1
						,@TableNamelen
						)+''')'
						+'CREATE TABLE '+@tablename+
						'(EmployeeId NVARCHAR(50) default ''0'' 
						,Emp901tax numeric(18,3)
						,FormBatch NVARCHAR(100)
						,processed			nvarchar(MAX) 
						,Post				bit
						,[Row_Number] int identity(1,1) PRIMARY KEY) '
		END
		else
		begin
		SET @tablename='  '
		SET @selectstr='SELECT ''0'' as  EmployeeId
						,0 as Emp901tax
						,'''' as FormBatch
						,'''' as processed
						,0 as Post
						 WHERE 1<>1'
		END
		SET @updatestr=' 	
	update '+@tablename+'
	set Emp901tax=@Emp901tax
	,EmployeeId=@EmpID
	,FormBatch=@FormBatch
	, Post=@post
	,processed=@remarks
	where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'

	SET @insertstr=' insert into '+@tablename+' select isnull(@EmpID,''0'')
				,@Emp901tax
				,@FormBatch
				,@remarks
				,@post
					)'
	SET @deletestr=' delete from  '+@tablename+' where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'
	SET @DisabledColStr='2'
	exec sp_executesql @select
	SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr
end

end

GO

