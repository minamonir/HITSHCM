
Create   PROCEDURE [dbo].[Batch_Save_Integration] (@tablename as nvarchar(150),@tabletype as nvarchar(100),@Where AS nvarchar(max),@Paramaters AS nvarchar(max)) AS
BEGIN 
DECLARE @outstr AS nvarchar(max)
DECLARE @str AS nvarchar(max)
DECLARE @actualtablename AS nvarchar(150)
SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName LIKE @tabletype
--------------------------------2019-09-24 paycodes------------------------------

IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExternalSystemsBatchPosting%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_ExternalSystemsBatchPosting_ar%' EXEC [BatchWP_ExternalSystemsBatchPosting] 1,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
	begin
set @str = 'EXEC [hits_importexport] 1,''' +@actualtablename+''','''+ @tablename  +''',0,@formulaOutput output'
PRINT @str
	exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
end
END

GO

