
CREATE PROCEDURE [dbo].[Batch_InsertEmpVacat] AS 
--Custom DTS
DECLARE @employeeid AS NVARCHAR(50) ,@Vaccode AS SMALLINT,@empid int ,@fromvac AS nVARCHAR(255)
,@tovac AS nVARCHAR(255), @Insert1 AS NVARCHAR(max),@DocumentNo AS INT 
,@Count as smallint ,@Error AS INT,@ErrMsg AS nvarchar (max),@str AS NVARCHAR(500) ,@VacSql AS NVARCHAR(max)
,@dateformat AS SMALLINT 



 SELECT @DateFormat= dateformat FROM SysParam 
   IF @DateFormat=1 SET @DateFormat=103
  IF @DateFormat=2 SET @DateFormat=101
  IF @DateFormat=0 SET @DateFormat=111

          
-----------start the cursor----------------
Execute ('DECLARE TempVacation_cursor CURSOR FOR select  v.[Employee ID] as employeeid,ea.empid
,v.[Vacation Code],v.[From],v.[To]
FROM TempEmpVacat v
inner JOIN Empassignment ea ON v.[Employee ID] =ea.Employeeid
 WHERE  (Processedtime is NULL OR Processedtime='''') 
               order by dbo.hitssort(v.[Employee ID],''''),v.[From] desc')
OPEN TempVacation_cursor
FETCH NEXT FROM TempVacation_cursor
INTO @employeeid,@empid,@Vaccode,@fromvac,@tovac
WHILE @@FETCH_STATUS = 0 
BEGIN
SELECT @ErrMsg=''
--========if process time is not empty will not insert--------------
---------------if vacation or from or to is null or '' will not insert and print processmsg--------------
IF ((LTRIM(RTRIM(@Vaccode))= '' or LTRIM(RTRIM(@Vaccode))IS NULL OR  LTRIM(RTRIM(@Vaccode))=0)
or ((ltrim(rtrim(@fromvac))= '') or LTRIM(RTRIM(@fromvac)) IS NULL) 
or ((ltrim(rtrim(@tovac))='') or LTRIM(rtrim(@tovac)) IS NULL )
OR (@employeeid='0') OR (ISNULL(@employeeid,'')='') )
BEGIN
 
   UPDATE  TempEmpVacat
	SET
		Processedtime=GETDATE(),
		processmsg = 'Can not insert empty fields'
	WHERE [Employee ID]=@employeeid  AND  isnull(ltrim(rtrim(@fromvac)),'')=ISNULL(LTRIM(RTRIM([From])),'')  
	and ISNULL(LTRIM(RTRIM([Vacation Code])),'')=isnull(ltrim(rtrim(@Vaccode)),'') 
	AND ISNULL(LTRIM(RTRIM([To])),'') =ISNULL(ltrim(rtrim(@tovac)),'')
	 
END
ELSE 
	BEGIN 
		
-------------==============insert into the empvacat table===================-----------------------
----------------Count of the employees(it is the where of the insert in empvacat) ---------------

set @VacSql = 'select @Count=count(ea.employeeid) from
Empvacat EV
Left join EmpAssignment ea on EV.empid = ea.empid
INNER JOIN profile P ON p.ProfileId=ea.empid 
where ((CONVERT(DATETIME, '''+@fromvac+''','+str(@dateformat)+') between EV.Fromdate and EV.ToDate)
or( CONVERT(DATETIME, '''+@tovac+''','+str(@dateformat)+') between EV.FromDate and EV.ToDate)
or (EV.Fromdate between (CONVERT(DATETIME, '''+@fromvac+''','+str(@dateformat)+'))and (CONVERT(DATETIME, '''+@tovac+''','+str(@dateformat)+')))
or (EV.Todate between (CONVERT(DATETIME, '''+@fromvac+''','+str(@dateformat)+'))and (CONVERT(DATETIME, '''+@tovac+''','+str(@dateformat)+')))
or ((CONVERT(DATETIME, '''+@fromvac+''','+str(@dateformat)+'))>(CONVERT(DATETIME, '''+@tovac+''','+str(@dateformat)+')))
or (isnull(p.firstHiredDate,ea.hiredate) > (CONVERT(DATETIME, '''+@fromvac+''','+str(@dateformat)+'))))
and '+LTRIM(RTRIM(@employeeid))+'= ea.employeeid
and EV.VacStatus= 1'

EXECUTE sp_executesql @VacSql,N'@Count smallint output',@Count OUTput 

PRINT @VacSql
PRINT @Count
-------------------------------------------------------------------
IF (@Count >= 1)
BEGIN
	PRINT 'Update'
	UPDATE TempEmpVacat
    SET Processedtime=getdate(),
    processmsg='This record or these dates already exist or From Date is greater than To Date or ( from date is before First Hire date)  '
    WHERE TempEmpVacat.[Employee ID] = @employeeid
   AND  isnull(ltrim(rtrim([From])),'')=ISNULL(LTRIM(RTRIM(@fromvac)),'')  
	and ISNULL(LTRIM(RTRIM([Vacation Code])),'')=isnull(ltrim(rtrim(@Vaccode)),'') 
	AND ISNULL(LTRIM(RTRIM([To])),'') =ISNULL(ltrim(rtrim(@tovac)),'')
    AND ((ltrim(rtrim(Processedtime)) ='') OR (Processedtime IS NULL))
END
Else
BEGIN
 SET @DocumentNo=dbo.GetDocumentNo(@empid ,3)	
		PRINT @DocumentNo 
Set @Insert1 ='INSERT INTO EmpVacat (empid,DocumentNo,VacStatus,Vaccode,FromDate,Todate,VacDate,enterby,enterdate)
                                                          SELECT ltrim(rtrim('+str(@empid)+'))
                                                          ,ltrim(rtrim('+str(@DocumentNo)+'))
                                                          ,1 
                                                          ,ltrim(rtrim('+str(@Vaccode)+')), 
                                                          CONVERT(DATETIME,'''+@fromvac+''','+str(@dateformat)+'), 
                                                          CONVERT(DATETIME,'''+@tovac+''','+str(@dateformat)+'),
                                                          CONVERT(DATETIME,'''+@fromvac+''','+str(@dateformat)+')
                                                          ,99999999
                                                          ,getdate()'
                                               	
                                               	
  PRINT  @Insert1                                            	
EXECUTE (@Insert1)
	
 END 	
	
SET @Error=@@ERROR

select @ErrMsg =@ErrMsg+' '+ltrim(rtrim(str(@Error)))+': '+description 
FROM SQLmessages 
WHERE error=@Error


		
UPDATE TempEmpVacat
SET Processedtime=getdate(),
processmsg=isnull(cast(@ErrMsg AS nvarchar (max)),'')
WHERE TempEmpVacat.[Employee ID] = @employeeid
AND LTRIM(RTRIM(TempEmpVacat.[Vacation Code]))=LTRIM(RTRIM(@VacCode ))
AND TempEmpVacat.[From] =@fromvac  
and TempEmpVacat.[To] =@tovac
AND ((ltrim(rtrim(Processedtime)) ='') OR (Processedtime IS NULL))

end	
FETCH NEXT FROM TempVacation_cursor
INTO @employeeid,@empid,@VacCode,@fromvac,@tovac

END

CLOSE TempVacation_cursor;
DEALLOCATE TempVacation_cursor;

set @str =' UPDATE TempEmpVacat
            SET Processedtime=getdate(),
            processmsg= ''Employee does not exist''
            WHERE [Employee ID] not IN (SELECT employeeid FROM EmpAssignment ) 
            AND ( Processedtime IS NULL OR Processedtime='''') '  

execute ( @str)


--SELECT * FROM TempEmpVacat

GO

