
CREATE  PROCEDURE [dbo].[AI_SendGoogleFormsLink](@LogonName as nvarchar(max),@TableName as nvarchar(max),@GoogleFormsId as int,@Manager as nvarchar(max),@Lang as nchar(1))
AS
BEGIN



DECLARE  
@empid AS int,@rowno as int
,@ErrorList AS nvarchar(250),@emailto as nvarchar(80),@jobName as nvarchar(max)='',@GoogleFormsLink as nvarchar(2083)='',@subject as nvarchar(max)='',@Tempbody as nvarchar(max)='',@name as nvarchar(max)=''

select @jobName= LTRIM(RTRIM(jobname)),@GoogleFormsLink=LTRIM(RTRIM(URL)) from GoogleForms where id=@GoogleFormsId

DECLARE @ErrorValue AS int

 exec(' declare tempemployee cursor for select distinct t1.profileid,LTRIM(RTRIM(companyemail)) ,profile.name,t1.Row_Number
 from '+ @TableName+'  t1 
 inner join Profile on t1.profileid=Profile.ProfileId
 where Checked=1' )
 OPEN tempemployee
 FETCH NEXT FROM tempemployee
 INTO  @empid,@emailto,@name,@rowno
 WHILE @@FETCH_STATUS = 0
 BEGIN
 SELECT @ErrorList=''
 BEGIN TRY
 select @subject=isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Subject',@Lang),(case when @Lang='E' then 'Assessment Link for' else N'Assessment Link for ' end))+' '+@jobName,
		@Tempbody=dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Tempbodyp1',@Lang)+' '+dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Tempbodyp2',@Lang)+' '+dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Tempbodyp3',@Lang)
select @Tempbody=REPLACE(@Tempbody,'@name',@name)
select @Tempbody=REPLACE(@Tempbody,'@job',@jobName)
select @Tempbody=@Tempbody+@GoogleFormsLink
--select @emailto='abanoube@hitstechnology.com'

 INSERT INTO [dbo].[SQLMailLog] ([SQLMailTo],[SQLMailSubject],[SQLMailBody])
select @emailto,@subject,@Tempbody
END TRY
BEGIN CATCH
SELECT @ErrorList=ERROR_MESSAGE()
END CATCH

print str(@empid)

	declare @updatetablestr as Nvarchar(max)
	set @updatetablestr = 'update '+@TableName+' set processtime = getdate() ,Processed=N'''+@ErrorList+N''' where profileid = ' + str(@empid)+' and Row_Number=' + str(@rowno)+' AND checked=1 '
	execute (@updatetablestr  )
	FETCH NEXT FROM tempemployee INTO  @empid,@emailto,@name,@rowno
	END
 CLOSE tempemployee
 DEALLOCATE tempemployee

	---- ================================================================
 --   -- MANAGER EMAIL: Send HTML results table after all emails are sent
 --   -- ================================================================
 --   DECLARE 
	--	@ManagerName  AS NVARCHAR(MAX),
 --       @ManagerSubject  AS NVARCHAR(MAX),
 --       @ManagerBody     AS NVARCHAR(MAX),
 --       @ManagerEmail    AS NVARCHAR(MAX),
 --       @HtmlTable       AS NVARCHAR(MAX) = ''

	--	SELECT @ManagerEmail = LTRIM(RTRIM(p.companyemail)), 
	--		   @ManagerName = CASE WHEN @Lang='E' THEN LTRIM(RTRIM(p.Name)) ELSE LTRIM(RTRIM(p.AName)) END
	--	FROM EmpAssignment ea
	--	INNER JOIN Profile p ON LTRIM(RTRIM(p.ProfileId)) = LTRIM(RTRIM(ea.EmpId))
	--	WHERE ea.EmployeeId = @Manager

 --   -- Build HTML table header
	--DECLARE 
	--	@HeaderMsg  AS NVARCHAR(MAX),
	--	@Dear AS NVARCHAR(MAX),
	--	@RespondentEmailmsg AS NVARCHAR(MAX),
	--	@TotalQuestionsmsg AS NVARCHAR(MAX),
	--	@CorrectQuestionsmsg AS NVARCHAR(MAX),
	--	@OverallScoremsg AS NVARCHAR(MAX)


	--select 
	--	@HeaderMsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Header',@Lang),(case when @Lang='E' then N'Please find below the assessment results summary for the position:' else N'يرجى الاطلاع أدناه على ملخص نتائج التقييم للوظيفة:' end)),
	--	@Dear = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Dear',@Lang),(case when @Lang='E' then N'Dear' else N'عزيزي' end)),
	--	@RespondentEmailmsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','RespondentEmail',@Lang),(case when @Lang='E' then N'Respondent Email' else N'بريد المستجيب' end)),
	--	@TotalQuestionsmsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','TotalQuestions',@Lang),(case when @Lang='E' then N'Total Questions' else N'مجموع الأسئلة' end)),
	--	@CorrectQuestionsmsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','CorrectQuestions',@Lang),(case when @Lang='E' then N'Correct Questions' else N'الأسئلة الصحيحة' end)),
	--	@OverallScoremsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','OverallScore',@Lang),(case when @Lang='E' then N'Overall Score' else N'النتيجة الإجمالية' end))
		
 --   SET @HtmlTable = '
 --   <html><body>
 --   <p>' + CASE WHEN @Lang='E' THEN @Dear + ' ' + @ManagerName ELSE @ManagerName + ' ' + @Dear END + ',</p>
 --   <p>' + CASE WHEN @Lang='E' THEN @HeaderMsg + ' <strong>' + @jobName + '</strong>' ELSE '<strong>' + @jobName + '</strong> ' + @HeaderMsg END + '</p>
 --   <table border="1" cellpadding="6" cellspacing="0" 
 --          style="border-collapse:collapse; font-family:Arial, sans-serif; font-size:13px; ' + case when @Lang='E' then N'' else N'direction: rtl;' end + '">
 --       <thead>
 --           <tr style="background-color:#4472C4; color:#ffffff; text-align:center;">
 --               <th style="padding:8px;">' + @RespondentEmailmsg + '</th>
 --               <th style="padding:8px;">' + @TotalQuestionsmsg +' </th>
 --               <th style="padding:8px;">' + @CorrectQuestionsmsg + '</th>
 --               <th style="padding:8px;">' + @OverallScoremsg + '</th>
 --           </tr>
 --       </thead>
 --       <tbody>'

 --   -- Build HTML rows dynamically from GoogleFormsResults filtered by FormId
 --   DECLARE 
 --       @RespondentEmail    AS NVARCHAR(MAX),
 --       @TotalQuestions     AS INT,
 --       @CorrectQuestions   AS INT,
 --       @OverallScore       AS numeric(18,3),
 --       @RowColor           AS NVARCHAR(20),
 --       @RowCount           AS INT = 0

 --   DECLARE results_cursor CURSOR FOR
 --       SELECT 
 --           RespondentEmail,
 --           TotalQuestions,
 --           CorrectQuestions,
 --           OverallScore
 --       FROM GoogleFormsResult
 --       WHERE FormId = (SELECT FormId FROM GoogleForms WHERE id = @GoogleFormsId)



 --   OPEN results_cursor
 --   FETCH NEXT FROM results_cursor INTO @RespondentEmail, @TotalQuestions, @CorrectQuestions, @OverallScore

 --   WHILE @@FETCH_STATUS = 0
 --   BEGIN
 --       -- Alternate row colors for readability
 --       SET @RowColor = CASE WHEN @RowCount % 2 = 0 THEN '#ffffff' ELSE '#dce6f1' END

 --       SET @HtmlTable = @HtmlTable + '
 --           <tr style="background-color:' + @RowColor + ';">
 --               <td style="padding:7px;">' + ISNULL(@RespondentEmail, '') + '</td>
 --               <td style="padding:7px; text-align:center;">' + CAST(@TotalQuestions AS NVARCHAR) + '</td>
 --               <td style="padding:7px; text-align:center;">' + CAST(@CorrectQuestions AS NVARCHAR) + '</td>
 --               <td style="padding:7px; text-align:center;">' + CAST(ROUND(@OverallScore, 3) AS NVARCHAR) + '</td>
 --           </tr>'

 --       SET @RowCount = @RowCount + 1
 --       FETCH NEXT FROM results_cursor INTO @RespondentEmail, @TotalQuestions, @CorrectQuestions, @OverallScore
 --   END

 --   CLOSE results_cursor
 --   DEALLOCATE results_cursor

 --   -- Close HTML
	--SET @HtmlTable = @HtmlTable + '
 --       </tbody>
 --   </table>
 --   </body></html>'

 --   --SET @HtmlTable = @HtmlTable + '
 --   --    </tbody>
 --   --</table>
 --   --<br/><p>Regards,<br/>HR System</p>
 --   --</body></html>'

 --   -- Set manager email subject
 --   SET @ManagerSubject = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','ManagerSub',@Lang),(case when @Lang='E' then  N'Assessment Results Summary -' else N'ملخص نتائج التقييم -' end)) + ' ' + @jobName

 --   -- Insert manager email into mail log
 --   IF @ManagerEmail IS NOT NULL AND @RowCount > 0
 --   BEGIN
 --       INSERT INTO [dbo].[SQLMailLog] ([SQLMailTo], [SQLMailSubject], [SQLMailBody])
 --       VALUES (@ManagerEmail, @ManagerSubject, @HtmlTable)
 --   END

END

GO

