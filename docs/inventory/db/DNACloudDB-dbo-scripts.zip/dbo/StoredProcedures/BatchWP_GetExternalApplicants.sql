

CREATE PROCEDURE [dbo].[BatchWP_GetExternalApplicants]
    (
      @actiontype AS SMALLINT ,
      @tablename AS NVARCHAR(150) ,
      @actual AS SMALLINT ,
      @Where AS NVARCHAR(MAX) ,
      @Paramaters AS NVARCHAR(MAX) ,
      @outputstr AS NVARCHAR(MAX) OUTPUT
    )
AS

--declare @actiontype AS SMALLINT=1,
--		 @tablename AS NVARCHAR(150)= 'DNACLOUDDBBatchTemp.dbo.[Nasbatch23285820221123025411bb44c6d8bf414e50a9e3d0c63ea3141c]',
--		@actual AS SMALLINT= 0,
--		@Where AS NVARCHAR(MAX),
--		@Paramaters AS NVARCHAR(MAX)=N'232858,0,E,1,tony'
		--update DNACLOUDDBBatchTemp.dbo.[Nasbatch23285820221123025411bb44c6d8bf414e50a9e3d0c63ea3141c] set remarks='',name ='david test z'
		--select * from DNACLOUDDBBatchTemp.dbo.[Nasbatch23285820221123025411bb44c6d8bf414e50a9e3d0c63ea3141c]

SET NOCOUNT ON

DECLARE @STR NVARCHAR(MAX) ,
@StartIndex AS INT ,
@EnterBy AS VARCHAR(100) ,
@Consolidation AS BIT ,
@DisableTriggers AS BIT ,
@lang AS NCHAR(1),
@CreateSetUp AS BIT = 0
-------- change organization validation--------------------------------------------------------
,@userOrganization AS NVARCHAR(max),
	@enableOrgSetup AS BIT ,
	@LogonName  AS varchar(100)


---------------------------------------------------------------------------------------------

IF LTRIM(RTRIM(@Paramaters))<>''
BEGIN
	SET @StartIndex = CHARINDEX(',', @Paramaters)
	SET @EnterBy = SUBSTRING(@Paramaters, 0, @StartIndex)
	PRINT '@EnterBy=' + @EnterBy
	SET @Consolidation = ISNULL(SUBSTRING(@Paramaters, @StartIndex + 1, 1), 1)
	PRINT '@Consolidation=' + STR(@Consolidation)

	SET @StartIndex = CHARINDEX(',', @Paramaters, @StartIndex + 1)
	SET @lang = ISNULL(SUBSTRING(@Paramaters, @StartIndex + 1, 1), 'E')
	PRINT '@lang=' + @lang

	SET @StartIndex=CHARINDEX(',',@Paramaters,@StartIndex+1)

	SET @CreateSetUp=isnull(substring(@Paramaters,@StartIndex+1,1),0)
	PRINT '@CreateSetUp='+STR(@CreateSetUp)
	-------- change organization validation--------------------------------------------------------
	SET @StartIndex=CHARINDEX(',',@Paramaters,@StartIndex+1)
	SET @LogonName=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
	print @LogonName
	select @userOrganization =UserOrganization,@enableOrgSetup=enableorgsetup 
from nasusers
CROSS JOIN SysParam
where @LogonName=LogonName



	------------------------------------------------------------------------------------------------
END


SET @DisableTriggers = 0
PRINT '@DisableTriggers=' + STR(@DisableTriggers)

DECLARE @DateFormat AS INT
SELECT @DateFormat= dateformat FROM SysParam 
   IF @DateFormat=1 SET @DateFormat=103
   IF @DateFormat=2 SET @DateFormat=101
   IF @DateFormat=0 SET @DateFormat=111

    DECLARE @Remarks NVARCHAR(MAX) ,
        @Post BIT ,
        @Name NVARCHAR(255) ,
        @FirstName NVARCHAR(255) ,
        @MidName NVARCHAR(255) ,
        @LastName NVARCHAR(255) ,
        @FourthName NVARCHAR(255) ,
        @FirstAName NVARCHAR(255) ,
        @MidAName NVARCHAR(255) ,
        @LastAName NVARCHAR(255) ,
        @FourthAName NVARCHAR(255) ,
        @NatnlNo NVARCHAR(255) ,
        @CGender NVARCHAR(255) ,
        @BirthDate NVARCHAR(255) ,
        @Mobile NVARCHAR(255) ,
        @TeleNo1 NVARCHAR(255) ,
        @Address NVARCHAR(255) ,
        @PrivateEmail NVARCHAR(255) ,
        @CompanyEmail NVARCHAR(255) ,
        @CNationId NVARCHAR(255) ,
        @SupplierNo SMALLINT ,
        @IdRegOff NVARCHAR(255) ,
        @IdIssDate NVARCHAR(255) ,
        @ForPassNo NVARCHAR(255) ,
        @ForPasFrm NVARCHAR(255) ,
        @ForPasDt NVARCHAR(255) ,
        @ForPasExp NVARCHAR(255) ,
        @CSocStatus NVARCHAR(255) ,
        @HrSsAppl BIT ,
        @ContBasSal numeric(18, 3) ,
        @ContInfo NVARCHAR(255) ,
        @CApplicationStatus NVARCHAR(255) ,
        @ApplicationStart NVARCHAR(255) ,
        @ApplicationEnd NVARCHAR(255) ,
        @CApplicationSource NVARCHAR(255) ,
        @CRecruitmentActivity NVARCHAR(255) ,
        @CVacancyNo NVARCHAR(255) ,
        @CLocationNo NVARCHAR(255) ,
        @CPositionNo NVARCHAR(255) ,
        @CGrade NVARCHAR(255) ,
        @COrg1 NVARCHAR(255) ,
        @COrg2 NVARCHAR(255) ,
        @COrg3 NVARCHAR(255) ,
        @COrg4 NVARCHAR(255) ,
        @COrg5 NVARCHAR(255) ,
        @COrg6 NVARCHAR(255) ,
        @COrg7 NVARCHAR(255) ,
        @CJob NVARCHAR(255) ,
       -- @CPrivacy NVARCHAR(255) ,
        --@CSSGroup NVARCHAR(255) ,
        @CContBasCur NVARCHAR(255) ,
        @CHrCurrency NVARCHAR(255) ,
        @ContNet BIT ,
        @HrSsFixVal numeric(18, 3) ,
        @HrBasicSal numeric(18, 3) ,
        @HrSsVarVal numeric(18, 3) ,
        @HrBenefit numeric(18, 3) ,
        @HrSsBonVal numeric(18, 3) ,
        @CVacPack NVARCHAR(255) ,
        @CHrScStatus NVARCHAR(255) ,
        @CTimeRule NVARCHAR(255) ,
        @CEmployerId NVARCHAR(255) ,
        @ContStart NVARCHAR(255) ,
        @CContractType NVARCHAR(255) ,
        @ContEnd NVARCHAR(255) ,
        @ProbDate NVARCHAR(255) ,
        @Error INT ,
        @ErrMsg NVARCHAR(MAX) ,
		@Profileid	INT,
        @CNT INT ,
        @Row_Number INT	,
        @Gender SMALLINT ,
        @CityId SMALLINT ,
        @CityId1 SMALLINT ,
        @NationId SMALLINT ,
        @SocStatus SMALLINT ,
        @ApplicationStatus SMALLINT ,
        @ApplicationSource SMALLINT ,
        @RecruitmentActivity SMALLINT ,
        @VacancyNo SMALLINT ,
        @LocationNo SMALLINT ,
        @PositionNo SMALLINT ,
        @Grade SMALLINT ,
        @Org1 SMALLINT ,
        @Org2 SMALLINT ,
        @Org3 SMALLINT ,
        @Org4 SMALLINT ,
        @Org5 SMALLINT ,
        @Org6 SMALLINT ,
        @Org7 SMALLINT ,
		@Organization SMALLINT,
        @Job SMALLINT ,
        @Privacy SMALLINT ,
        --@SSGroup int ,
        @ContBasCur SMALLINT ,
        @HrCurrency SMALLINT ,
        @VacPack SMALLINT ,
        @HrScStatus SMALLINT ,
        @TimeRule SMALLINT ,
        @EmployerId SMALLINT,
		@ContractType SMALLINT,
		@OrgParent SMALLINT; 


IF @actiontype=1
BEGIN
IF @DisableTriggers = 1
BEGIN
	CREATE Table  #Triggers(triggername nchar(100),tablename nchar(100))
	declare @triggername nchar(100),@tablename1 nchar(100),@selectcommand NVARCHAR(4000)
	insert into  #Triggers 
	SELECT t.name AS triggername,tt.name AS tablename
	FROM dbo.sysobjects t 
	INNER JOIN dbo.sysobjects tt ON t.parent_obj = tt.id
	WHERE (t.xtype = N'TR') AND (tt.xtype = N'U') 
	AND ( t.name LIKE '%audit%' OR t.name = 'Ins_SalaryGradePaycode')

	--AND OBJECTPROPERTY(t.id,'ExecIsTriggerDisabled') =1

	declare Triggers cursor 
	for SELECT * from #Triggers
	      
	OPEN Triggers
	FETCH NEXT FROM Triggers into  @triggername ,@tablename1 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		  set @selectcommand ='ALTER TABLE ' +  @tablename1+ ' DISABLE TRIGGER ' +@triggername
		  --print @selectcommand
		  execute sp_executesql @selectcommand
	FETCH NEXT FROM Triggers into @triggername ,@tablename1 
	end
	CLOSE Triggers

END

--Adjust Defalt Currency
IF NOT EXISTS (SELECT * FROM Currency)
BEGIN
	INSERT INTO Currency (cur, CurName, CurAName)
	SELECT 1,'Egyptian Pound',N'جنية مصري' WHERE 1 NOT IN (SELECT cur FROM Currency)
END

UPDATE sysparam SET syscur = (select top 1 cur from currency) WHERE ISNULL(syscur,0)=0

--Adjust Defauld Organization Types
INSERT INTO OrganizationType(OrganizationType, OrganizationTypeName, OrganizationTypeAName)
SELECT 1,'1.Company',N'1.شركة' WHERE 1 NOT IN (SELECT OrganizationType FROM OrganizationType) UNION
SELECT 2,'2.Branch',N'2.فرع' WHERE 2 NOT IN (SELECT OrganizationType FROM OrganizationType) UNION
SELECT 3,'3.Divisoin',N'3.قطاع ' WHERE 3 NOT IN (SELECT OrganizationType FROM OrganizationType) UNION
SELECT 4,'4.Department',N'4.ادارة' WHERE 4 NOT IN (SELECT OrganizationType FROM OrganizationType) UNION
SELECT 5,'5.Section',N'5.قسم' WHERE 5 NOT IN (SELECT OrganizationType FROM OrganizationType) UNION
SELECT 6,'6.Sub Section',N'6.قسم فرعى' WHERE 6 NOT IN (SELECT OrganizationType FROM OrganizationType) UNION
SELECT 7,'7.Small Section',N'7.قسم صغير' WHERE 7 NOT IN (SELECT OrganizationType FROM OrganizationType)

SELECT @STR ='Declare EmployeesCursor Cursor For 
SELECT 
[Name]	
,[NatnlNo]				
,[CGender]				
,[BirthDate]	
,[Mobile]				
,[TeleNo1]				
,[Address]				
,[PrivateEmail]		
,[CompanyEmail]		
,[CNationId]			
,[CApplicationStatus]	
,[ApplicationStart]	
,[ApplicationEnd]		
,[CApplicationSource]	
,[CRecruitmentActivity] 
,[CVacancyNo]			
,[CLocationNo]			
,[CPositionNo]			
,[CGrade]				
,[COrg1]				
,[COrg2]				
,[COrg3]				
,[COrg4]				
,[COrg5]				
,[COrg6]				
,[COrg7]				
,[CJob]				
,[Privacy]			
,[IdRegOff]				
,[IdIssDate]			
,[ForPassNo]			
,[ForPasFrm]			
,[ForPasDt]			
,[ForPasExp]			
,[CSocStatus]			
,[HrSsAppl]				
,[ContBasSal]		
,[ContInfo]				
,[CContBasCur]			
,[CHrCurrency]			
,[ContNet]				 
,[HrSsFixVal]			
,[HrBasicSal]			
,[HrSsVarVal]			
,[HrBenefit]			
,[HrSsBonVal]			
,[CVacPack]			
,[CHrScStatus]			
,[CTimeRule]					
,[CEmployerId]			
,[ContStart]		
,[CContractType]		
,[ContEnd]				
,[ProbDate]	 
,[Row_Number] FROM ' + @tablename +  ' t where t.post=1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' '

PRINT @STR
EXEC (@STR)

OPEN EmployeesCursor
FETCH next FROM EmployeesCursor
INTO @Name
,@NatnlNo				
,@CGender				
,@BirthDate			
,@Mobile				
,@TeleNo1				
,@Address				
,@PrivateEmail		
,@CompanyEmail		
,@CNationId			
,@CApplicationStatus	
,@ApplicationStart	
,@ApplicationEnd		
,@CApplicationSource	
,@CRecruitmentActivity 
,@CVacancyNo			
,@CLocationNo			
,@CPositionNo			
,@CGrade				
,@COrg1				
,@COrg2				
,@COrg3				
,@COrg4				
,@COrg5				
,@COrg6				
,@COrg7				
,@CJob				
,@Privacy			
--,@CSSGroup 			
,@IdRegOff				
,@IdIssDate					
,@ForPassNo			
,@ForPasFrm			
,@ForPasDt			
,@ForPasExp			
,@CSocStatus			
,@HrSsAppl			
,@ContBasSal			
,@ContInfo		
,@CContBasCur			
,@CHrCurrency			
,@ContNet				 
,@HrSsFixVal			
,@HrBasicSal			
,@HrSsVarVal			
,@HrBenefit			
,@HrSsBonVal			
,@CVacPack			
,@CHrScStatus			
,@CTimeRule					
,@CEmployerId			
,@ContStart			
,@CContractType		
,@ContEnd				
,@ProbDate		
	,@Row_Number		
WHILE @@FETCH_STATUS=0
BEGIN

SELECT @ErrMsg = '',@Error = 0 , @Gender = 0 , @CityId = NULL , @CityId1 = NULL , @NationId = NULL ,
       @SocStatus = 0 ,
       @ContBasSal = 0 , @ApplicationStatus = 1 , @ApplicationSource = NULL ,
       @RecruitmentActivity = NULL , @VacancyNo = NULL , @LocationNo = NULL , @PositionNo = NULL ,
       @Grade = NULL , @Org1 = 0 , @Org2 = 0 , @Org3 = 0 , @Org4 = 0 , @Org5 = 0 ,
       @Org6 = 0 , @Org7 = 0 , @Organization = 0 , @Job = NULL , --@SSGroup = NULL ,
       @ContBasCur = NULL , @HrCurrency = NULL ,
       @VacPack = NULL , @HrScStatus = 0 , @TimeRule = NULL, @EmployerId = NULL , @ContractType = NULL,
	   @HrSsFixVal = 0 , @HrSsVarVal = 0 , @HrSsBonVal = 0 , @HrBenefit = 0 

-- Adjust Name

SELECT @FirstName = dbo.BreakName(@Name,1),
	   @MidName	  = dbo.BreakName(@Name,2),
	   @LastName  = dbo.BreakName(@Name,3),
	   @FourthName= dbo.BreakName(@Name,4)
IF @CreateSetUp = 1 
BEGIN

		-- Adjust Organization Structure
		--add UEnterBy
		-- Org 1

		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 1)
		BEGIN
		PRINT 'Fetching Org1'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg1,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg1,''))) AS NVARCHAR(250)),1,
		CAST(LTRIM(RTRIM(ISNULL(@COrg1,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg1,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg1,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg1,'')))) AS NVARCHAR(250)) NOT IN 
		(SELECT case when @Consolidation =1 THEN CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END 
		 ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END END 
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 1 AND OrganizationStructure.OrganizationParent IS null)
  
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		INSERT INTO OrganizationStructure(Organization)
		SELECT Organization FROM Organization
		WHERE case when @Consolidation =1 THEN CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg1,'')))) AS NVARCHAR(250)) AND OrganizationType = 1
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org1 = Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END  END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg1,'')))) AS NVARCHAR(250)) AND OrganizationType = 1 AND OrganizationStructure.OrganizationParent IS NULL 	
		END 
	   
		-- Org 2
		--add Uenterby
		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 2)
		BEGIN
		PRINT 'Fetching Org2'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg2,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg2,''))) AS NVARCHAR(250)),2,
		CAST(LTRIM(RTRIM(ISNULL(@COrg2,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg2,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg2,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg2,'')))) AS NVARCHAR(250)) NOT IN 
(SELECT case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END 
        ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END END 
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 2 AND OrganizationStructure.OrganizationParent = @Org1)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		INSERT INTO OrganizationStructure(Organization,OrganizationParent)
		SELECT Organization,@Org1 FROM Organization
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationName))) END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg2,'')))) AS NVARCHAR(250)) AND OrganizationType = 2
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org2 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
 ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END  END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg2,'')))) AS NVARCHAR(250)) AND OrganizationType = 2 AND OrganizationStructure.OrganizationParent = @Org1
		END 
	   	   
	   
		-- Org 3
		--add UenterBy
		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 3)
		BEGIN
		PRINT 'Fetching Org3'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg3,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg3,''))) AS NVARCHAR(250)),3,
		CAST(LTRIM(RTRIM(ISNULL(@COrg3,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg3,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg3,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg3,'')))) AS NVARCHAR(250)) NOT IN 
(SELECT case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END  
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END  END 
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 3 AND OrganizationStructure.OrganizationParent = @Org2)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		INSERT INTO OrganizationStructure(Organization,OrganizationParent)
		SELECT Organization,@Org2 FROM Organization
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationNameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg3,'')))) AS NVARCHAR(250)) AND OrganizationType = 3
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org3 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END  
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg3,'')))) AS NVARCHAR(250)) AND OrganizationType = 3 AND OrganizationStructure.OrganizationParent = @Org2
		END 

		-- Org 4
		--add UenterBy
		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 4)
		BEGIN
		PRINT 'Fetching Org4'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg4,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg4,''))) AS NVARCHAR(250)),4,
		CAST(LTRIM(RTRIM(ISNULL(@COrg4,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg4,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg4,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg4,'')))) AS NVARCHAR(250)) NOT IN 
(SELECT case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END END
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 4 AND OrganizationStructure.OrganizationParent = @Org3)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		INSERT INTO OrganizationStructure(Organization,OrganizationParent)
		SELECT Organization,@Org3 FROM Organization
WHERE case when @Consolidation =1 THEN CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg4,'')))) AS NVARCHAR(250)) AND OrganizationType = 4
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org4 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
WHERE case when @Consolidation =1 then  CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg4,'')))) AS NVARCHAR(250)) AND OrganizationType = 4 AND OrganizationStructure.OrganizationParent = @Org3
		END 

		-- Org 5
		-- add UEnterBy
		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 5)
		BEGIN
		PRINT 'Fetching Org5'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg5,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg5,''))) AS NVARCHAR(250)),5,
		CAST(LTRIM(RTRIM(ISNULL(@COrg5,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg5,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg5,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg5,'')))) AS NVARCHAR(250)) NOT IN 
(SELECT case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END  
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END END 
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 5 AND OrganizationStructure.OrganizationParent = @Org4)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		INSERT INTO OrganizationStructure(Organization,OrganizationParent)
		SELECT Organization,@Org4 FROM Organization
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons)))  END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg5,'')))) AS NVARCHAR(250)) AND OrganizationType = 5
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org5 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg5,'')))) AS NVARCHAR(250)) AND OrganizationType = 5 AND OrganizationStructure.OrganizationParent = @Org4
		END 

		-- Org 6
		-- add UEnterBy
		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 6)
		BEGIN
		PRINT 'Fetching Org6'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg6,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg6,''))) AS NVARCHAR(250)),6,
		CAST(LTRIM(RTRIM(ISNULL(@COrg6,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg6,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg6,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg6,'')))) AS NVARCHAR(250)) NOT IN 
(SELECT case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END 
 ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END END 
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 6 AND OrganizationStructure.OrganizationParent = @Org5)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		INSERT INTO OrganizationStructure(Organization,OrganizationParent)
		SELECT Organization,@Org5 FROM Organization
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END  END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg6,'')))) AS NVARCHAR(250)) AND OrganizationType = 6
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org6 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
WHERE case when @Consolidation =1 THEN CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg6,'')))) AS NVARCHAR(250)) AND OrganizationType = 6 AND OrganizationStructure.OrganizationParent = @Org5
		END 

		-- Org 7
		-- add UEnterBy
		IF EXISTS (SELECT * FROM OrganizationType WHERE OrganizationType = 7)
		BEGIN
		PRINT 'Fetching Org7'
		INSERT INTO Organization(Organization,OrganizationName,OrganizationAName,OrganizationType,OrganizationNameCons,OrganizationANameCons,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Organization),0)+1 FROM Organization T1),
		CAST(LTRIM(RTRIM(ISNULL(@COrg7,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg7,''))) AS NVARCHAR(250)),7,
		CAST(LTRIM(RTRIM(ISNULL(@COrg7,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@COrg7,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@COrg7,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg7,'')))) AS NVARCHAR(250)) NOT IN 
(SELECT case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.OrganizationName))) ELSE UPPER(LTRIM(RTRIM(T2.OrganizationAName))) END END 
		 FROM Organization T2
		 LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = T2.Organization
		  WHERE T2.OrganizationType = 7 AND OrganizationStructure.OrganizationParent = @Org6)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		 -- Adjust OrganizationStructure
		PRINT 'Fetching OrganizationStructure'
		INSERT INTO OrganizationStructure(Organization,OrganizationParent)
		SELECT Organization,@Org6 FROM Organization
WHERE case when @Consolidation =1 then CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName)))END END=CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg7,'')))) AS NVARCHAR(250)) AND OrganizationType = 7
		AND Organization NOT IN (SELECT Organization FROM OrganizationStructure)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		SELECT @Org7 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
WHERE case when @Consolidation =1 THEN CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(OrganizationANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(OrganizationName))) ELSE UPPER(LTRIM(RTRIM(OrganizationAName))) END END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg7,'')))) AS NVARCHAR(250)) AND OrganizationType = 7 AND OrganizationStructure.OrganizationParent = @Org6
		END 	

---- add org
---- add UEnterBy
		 -- Adjust Nationality
		PRINT 'Fetching Nationality'
		INSERT INTO Nations(nationid,NationName,NationAName,NationNameCons,NationANameCons,NationsOrgs,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.nationid),0)+1 FROM Nations T1),
		CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(60)),
		CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(60)),
		CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(250)),
		case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end                 ---------------------
		,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@CNationId,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CNationId,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 then
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.NationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.NationANameCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.NationName))) ELSE UPPER(LTRIM(RTRIM(T2.NationAName))) END END  FROM Nations T2)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		-- For search before insert according to the entered @lang 
		--INSERT INTO Nations(nationid,NationName,NationAName,NationNameCons,NationANameCons)
		--SELECT(SELECT ISNULL(MAX(T1.nationid),0)+1 FROM Nations T1),
		--CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(60)),
		--CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(60)),
		--CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(250)),
		--CAST(LTRIM(RTRIM(ISNULL(@CNationId,''))) AS NVARCHAR(250))
		--WHERE LTRIM(RTRIM(ISNULL(@CNationId,''))) <>''
		--AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CNationId,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 then 
		
		--CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.NationNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.NationANameCons))) END ELSE 
		--CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.NationName))) ELSE UPPER(LTRIM(RTRIM(T2.NationAName))) END END  FROM Nations T2)
		--SET @Error=@@ERROR
		--IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error


----------- add org 
--- add UEnterBy
		-- Adjust Job
	   			PRINT 'Fetching Job'
		INSERT INTO Jobs(job,JobName,JobAName,JobNameCons,JobANameCons,JobsOrgs,UEnterBy,UEnterDate)
		SELECT (SELECT ISNULL(MAX(T1.[job]),0)+1 FROM Jobs T1),
		CAST(LTRIM(RTRIM(ISNULL(@CJob,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CJob,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CJob,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CJob,''))) AS NVARCHAR(250)),
		case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end                   ------------------------------
		,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@CJob,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CJob,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 THEN 
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.JobNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.JobANameCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.JobName))) ELSE UPPER(LTRIM(RTRIM(T2.JobAName))) END END FROM Jobs T2)

		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error
		
--- add org	
--- add UenterBy
		-- Adjust Grade	
		   			PRINT 'Fetching Grade'	
		INSERT INTO Grades(Grade,GradeName,GradeAName,GradeNameCons,GradeANameCons,GradesOrgs,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.Grade),0)+1 FROM Grades T1),
		CAST(LTRIM(RTRIM(ISNULL(@CGrade,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CGrade,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CGrade,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CGrade,''))) AS NVARCHAR(250)),
		case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end         -------------------------------------------------
		,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@CGrade,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CGrade,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 then 
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.GradeNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.GradeANameCons))) END 
		ELSE  CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.GradeName))) ELSE UPPER(LTRIM(RTRIM(T2.GradeAName))) END END FROM Grades T2)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error	

		-- Adjust Self Service Group	
		PRINT 'Fetching Self Service Group'
		--INSERT INTO SSGroup(SSGroup,SSGroupName,SSGroupAName)
		--SELECT(SELECT ISNULL(MAX(T1.SSGroup),0)+1 FROM SSGroup T1),
		--CAST(LTRIM(RTRIM(ISNULL(@CSSGroup,''))) AS NVARCHAR(60)),
		--CAST(LTRIM(RTRIM(ISNULL(@CSSGroup,''))) AS NVARCHAR(60))
		--WHERE LTRIM(RTRIM(ISNULL(@CSSGroup,''))) <>''
		--AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CSSGroup,'')))) AS NVARCHAR(60)) NOT IN (SELECT  UPPER(LTRIM(RTRIM(T2.SSGroupName)))  FROM SSGroup T2)
		--SET @Error=@@ERROR
		--IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		--New 


-- add org
--- add uEnterBy
		-- Adjust TimeRules
	   	PRINT 'Fetching TimeRules'
		INSERT INTO TimeRules (TimeRule , TRuleDesc , TRuleADesc, TRuleDescCons , TRuleADescCons,TimeRulesOrgs,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.TimeRule),0)+1 FROM TimeRules T1),
		CAST(LTRIM(RTRIM(ISNULL(@CTimeRule,''))) AS NVARCHAR(30)),
		CAST(LTRIM(RTRIM(ISNULL(@CTimeRule,''))) AS NVARCHAR(30)),
		CAST(LTRIM(RTRIM(ISNULL(@CTimeRule,''))) AS NVARCHAR(250)),
		CAST(LTRIM(RTRIM(ISNULL(@CTimeRule,''))) AS NVARCHAR(250)),
		case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end            ----------------------------
		,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@CTimeRule,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CTimeRule,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 then 
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.TRuleDescCons))) ELSE UPPER(LTRIM(RTRIM(T2.TRuleADescCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.TRuleDesc))) ELSE UPPER(LTRIM(RTRIM(T2.TRuleADesc))) END END FROM TimeRules T2)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

		---- Adjust HR Status
		--PRINT 'Fetching HR Status'	
		--INSERT INTO HrStatus(hrstatus,HrstatusAName,HrstatusName,paystatus,HrStatusNameCons,HrStatusANameCons)
		--SELECT(SELECT ISNULL(MAX(T1.hrstatus),0)+1 FROM HrStatus T1),
		--CAST(LTRIM(RTRIM(ISNULL(@CHrScStatus,''))) AS NVARCHAR(20)),
		--CAST(LTRIM(RTRIM(ISNULL(@CHrScStatus,''))) AS NVARCHAR(20)),
		--1,CAST(LTRIM(RTRIM(ISNULL(@CHrScStatus,''))) AS NVARCHAR(250)),
		--CAST(LTRIM(RTRIM(ISNULL(@CHrScStatus,''))) AS NVARCHAR(250))
		--WHERE LTRIM(RTRIM(ISNULL(@CHrScStatus,''))) <>''
		--AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CHrScStatus,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 then UPPER(LTRIM(RTRIM(T2.HrStatusNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.HrstatusName))) END FROM HrStatus T2)
		--SET @Error=@@ERROR
		--IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error
-- add org
-- add UenterBy
		-- Adjust AppSource
		PRINT 'Fetching AppSource'	
		INSERT INTO ApplicationSource(ApplicationSource ,ApplicationSourceName ,ApplicationSourceAName ,ApplicationSourceCons ,ApplicationSourceNameCons,ApplicationSourceOrgs,UEnterBy,UEnterDate )
		SELECT(SELECT ISNULL(MAX(T1.ApplicationSource),0)+1 FROM ApplicationSource T1),
		CAST(LTRIM(RTRIM(ISNULL(@CApplicationSource,''))) AS NVARCHAR(20)),
		CAST(LTRIM(RTRIM(ISNULL(@CApplicationSource,''))) AS NVARCHAR(20)),
		1,CAST(LTRIM(RTRIM(ISNULL(@CApplicationSource,''))) AS NVARCHAR(250)),
		case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end            ----------------------------
		,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@CApplicationSource,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CApplicationSource,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 then 
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.ApplicationSourceNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.ApplicationSourceANameCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.ApplicationSourceName))) ELSE UPPER(LTRIM(RTRIM(T2.ApplicationSourceAName))) END END FROM ApplicationSource T2)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

--add org
-- add UEnterBy
		-- Adjust RecruitmentActivities
		PRINT 'Fetching RecruitmentActivities'	
		INSERT INTO RecruitmentActivities( RecruitmentActivity ,RecruitmentActivityName ,RecruitmentActivityAName ,RecruitmentActivityCons ,RecruitmentActivityNameCons,RecruitmentActivitiesOrgs,UEnterBy,UEnterDate)
		SELECT(SELECT ISNULL(MAX(T1.RecruitmentActivity),0)+1 FROM RecruitmentActivities T1),
		CAST(LTRIM(RTRIM(ISNULL(@CRecruitmentActivity,''))) AS NVARCHAR(20)),
		CAST(LTRIM(RTRIM(ISNULL(@CRecruitmentActivity,''))) AS NVARCHAR(20)),
		1,CAST(LTRIM(RTRIM(ISNULL(@CRecruitmentActivity,''))) AS NVARCHAR(250)),
		case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end            ----------------------------
		,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
		WHERE LTRIM(RTRIM(ISNULL(@CRecruitmentActivity,''))) <>''
		AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CRecruitmentActivity,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 THEN
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.RecruitmentActivityNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.RecruitmentActivityANameCons))) END 
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.RecruitmentActivityName))) ELSE UPPER(LTRIM(RTRIM(T2.RecruitmentActivityAName))) END END FROM RecruitmentActivities T2)
		SET @Error=@@ERROR
		IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error
END	
ELSE
BEGIN
		-----------------------------------New Read ----------------------------------------
		SELECT @Org1 = Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg1,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 1 
		AND OrganizationStructure.OrganizationParent IS NULL 

		SELECT @Org2 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg2,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 2 
		AND ISNULL(OrganizationStructure.OrganizationParent,0) = CASE 
																WHEN isnull(@Org1,0) <> 0  THEN @Org1 ELSE 0 END

		SELECT @Org3 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg3,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 3 
		AND ISNULL(OrganizationStructure.OrganizationParent,0) = CASE 
																WHEN isnull(@Org2,0) <> 0  THEN @Org2 
																WHEN isnull(@Org1,0) <> 0  THEN @Org1  ELSE 0 END 


		SELECT @Org4 =  Organization.Organization 
		FROM Organization 
		LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg4,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 4 
		AND ISNULL(OrganizationStructure.OrganizationParent,0) = CASE 
																WHEN isnull(@Org3,0) <> 0 THEN @Org3 
																WHEN isnull(@Org2,0) <> 0 THEN @Org2 
																WHEN isnull(@Org1,0) <> 0 THEN @Org1  ELSE 0 END 

		SELECT @Org5 =  Organization.Organization 
		FROM Organization 
		LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg5,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 5 
		AND ISNULL(OrganizationStructure.OrganizationParent,0) = CASE 
																WHEN isnull(@Org4,0) <> 0 THEN @Org4 
																WHEN isnull(@Org3,0) <> 0 THEN @Org3 
																WHEN isnull(@Org2,0) <> 0 THEN @Org2 
																WHEN isnull(@Org1,0) <> 0 THEN @Org1  ELSE 0 END 

		SELECT @Org6 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg6,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 6 
		AND ISNULL(OrganizationStructure.OrganizationParent,0) = CASE
																WHEN isnull(@Org5,0) <> 0 THEN @Org5 
																WHEN isnull(@Org4,0) <> 0 THEN @Org4 
																WHEN isnull(@Org3,0) <> 0 THEN @Org3 
																WHEN isnull(@Org2,0) <> 0 THEN @Org2 
																WHEN isnull(@Org1,0) <> 0 THEN @Org1  ELSE 0 END 


		SELECT @Org7 =  Organization.Organization 
		FROM Organization LEFT JOIN OrganizationStructure ON OrganizationStructure.Organization = Organization.Organization 
		WHERE case when @Consolidation =1 then UPPER(LTRIM(RTRIM(Organization.OrganizationNameCons))) ELSE UPPER(LTRIM(RTRIM(Organization.OrganizationName))) END = CAST(UPPER(LTRIM(RTRIM(ISNULL(@COrg7,'')))) AS NVARCHAR(250)) AND Organization.OrganizationType = 7 
		AND ISNULL(OrganizationStructure.OrganizationParent,0) = CASE
																WHEN isnull(@Org6,0) <> 0 THEN @Org6 
																WHEN isnull(@Org5,0) <> 0 THEN @Org5 
																WHEN isnull(@Org4,0) <> 0 THEN @Org4 
																WHEN isnull(@Org3,0) <> 0 THEN @Org3 
																WHEN isnull(@Org2,0) <> 0 THEN @Org2 
																WHEN isnull(@Org1,0) <> 0 THEN @Org1 ELSE 0 
																END 
END

SELECT @Organization = CASE WHEN isnull(@Org7,0) <> 0 THEN @Org7
							WHEN isnull(@Org6,0) <> 0 THEN @Org6
							WHEN isnull(@Org5,0) <> 0 THEN @Org5
							WHEN isnull(@Org4,0) <> 0 THEN @Org4
							WHEN isnull(@Org3,0) <> 0 THEN @Org3
							WHEN isnull(@Org2,0) <> 0 THEN @Org2
							WHEN isnull(@Org1,0) <> 0 THEN @Org1 END
-- Adjust NasArrays Items
		   	PRINT 'Adjust NasArrays Items'	
SELECT @SocStatus  = itemno FROM NasArrays WHERE upper(ltrim(rtrim(NasArrays.arrayname))) = 'SOCSTATUS' AND upper(ltrim(rtrim(NasArrays.edesc))) = upper(ltrim(rtrim(@CSocStatus)))
SELECT @Gender     = itemno FROM NasArrays WHERE upper(ltrim(rtrim(NasArrays.arrayname))) = 'GENDER'	AND upper(ltrim(rtrim(NasArrays.edesc))) = upper(ltrim(RTRIM(@CGender)))
SELECT @HrScStatus = itemno FROM NasArrays WHERE upper(ltrim(rtrim(NasArrays.arrayname))) = 'SCSTATUS'	AND upper(ltrim(rtrim(NasArrays.edesc))) = upper(ltrim(RTRIM(@CHrScStatus)))     
--Update 20250615
--SELECT @ApplicationStatus = itemno FROM dbo.NasArrays WHERE upper(ltrim(rtrim(NasArrays.arrayname))) = 'APPLSTATUS' AND upper(ltrim(rtrim(NasArrays.edesc))) = upper(ltrim(rtrim(@CApplicationStatus)))
SELECT @ApplicationStatus = ApplicationStatus FROM dbo.ApplicationStatus WHERE upper(ltrim(rtrim(ApplicationStatus.ApplicationStatusName))) = upper(ltrim(rtrim(@CApplicationStatus)))

IF @Consolidation = 1
BEGIN
	SELECT @NationId = nationid FROM Nations WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN  NationNameCons ELSE NationANameCons END ))) = UPPER(LTRIM(RTRIM(@CNationId))) 	
	SELECT @Job = Job FROM Jobs WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN JobNameCons ELSE JobANameCons END ))) = UPPER(LTRIM(RTRIM(@CJob))) 	
	SELECT @Grade = Grade FROM Grades WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN GradeNameCons ELSE GradeANameCons END ))) = UPPER(LTRIM(RTRIM(@CGrade))) 	 	
	SELECT @ContractType = ContractType FROM ContractType WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN ContractNameCons ELSE ContractANameCons END ))) = UPPER(LTRIM(RTRIM(@CContractType))) 	
	SELECT @VacPack = vacpack FROM VacPack WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN VacPackNameCons ELSE VacPackANameCons END ))) = UPPER(LTRIM(RTRIM(@CVacPack))) 
	SELECT @TimeRule = TimeRule FROM TimeRules WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN TRuleDescCons ELSE TRuleADescCons END ))) = UPPER(LTRIM(RTRIM(@CTimeRule))) 
	SELECT @LocationNo = LocationNo FROM Location WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN LocationNameCons ELSE LocationANameCons END ))) = UPPER(LTRIM(RTRIM(@CLocationNo))) 
	
	SELECT @ApplicationSource = ApplicationSource FROM ApplicationSource WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN ApplicationSourceNameCons ELSE ApplicationSourceANameCons END ))) = UPPER(LTRIM(RTRIM(@CApplicationSource))) 
	SELECT @RecruitmentActivity = RecruitmentActivity FROM RecruitmentActivities WHERE UPPER(LTRIM(RTRIM(CASE WHEN @lang = 'E' THEN RecruitmentActivityNameCons ELSE RecruitmentActivityANameCons END ))) = UPPER(LTRIM(RTRIM(@CRecruitmentActivity))) 
	SELECT @VacancyNo = VacancyNo FROM Vacancies WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN VacancyNameCons ELSE VacancyAnameCons END ))) = UPPER(LTRIM(RTRIM(@CVacancyNo))) 
END
ELSE
BEGIN
	SELECT @NationId = nationid FROM Nations WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN NationName ELSE NationAName END ))) = UPPER(LTRIM(RTRIM(@CNationId))) 
	SELECT @Job = Job FROM Jobs WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN JobName ELSE JobAName END ))) = UPPER(LTRIM(RTRIM(@CJob))) 	
	SELECT @Grade = Grade FROM Grades WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN GradeName ELSE GradeAName END ))) = UPPER(LTRIM(RTRIM(@CGrade))) 	
	SELECT @ContractType = ContractType FROM ContractType WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN ContractName ELSE ContractAName END ))) = UPPER(LTRIM(RTRIM(@CContractType))) 
	SELECT @VacPack = vacpack FROM VacPack WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN VacPackName ELSE VacPackAName END ))) = UPPER(LTRIM(RTRIM(@CVacPack))) 
	SELECT @TimeRule = TimeRule FROM TimeRules WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN TRuleDesc ELSE TRuleADesc END ))) = UPPER(LTRIM(RTRIM(@CTimeRule))) 
	SELECT @LocationNo = LocationNo FROM Location WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN LocationName ELSE LocationAName END ))) = UPPER(LTRIM(RTRIM(@CLocationNo))) 	
	
	SELECT @ApplicationSource = ApplicationSource FROM ApplicationSource WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN ApplicationSourceName ELSE ApplicationSourceAName END ))) = UPPER(LTRIM(RTRIM(@CApplicationSource))) 
	SELECT @RecruitmentActivity = RecruitmentActivity FROM RecruitmentActivities WHERE UPPER(LTRIM(RTRIM( CASE WHEN @lang = 'E' THEN  RecruitmentActivityName ELSE RecruitmentActivityName END ))) = UPPER(LTRIM(RTRIM(@CRecruitmentActivity))) 
	SELECT @VacancyNo = VacancyNo FROM Vacancies WHERE UPPER(LTRIM(RTRIM(CASE WHEN @lang = 'E' THEN  VacancyName ELSE VacancyAname END ))) = UPPER(LTRIM(RTRIM(@CVacancyNo))) 

END
PRINT 'loca'+STR(ISNULL(@LocationNo,''))

IF ISNULL(@NationId,0)= 0 SELECT @NationId = defnation FROM SysParam
IF @CreateSetup = 1
Begin
--add org
-- add UEnterBy		
-- Adjust Position
IF ISNULL(@Organization,0)<>0 AND ISNULL(@Job,0)<>0
BEGIN
   	PRINT 'Fetching Position'
INSERT INTO Positions(PositionNo,PositionName,PositionAName,Organization,Job,PositionNoNameCons,PositionNoANameCons,PositionsOrgs,UEnterBy,UEnterDate)
SELECT (SELECT ISNULL(MAX(T1.PositionNo),0)+1 FROM Positions T1),
CAST(LTRIM(RTRIM(ISNULL(@CPositionNo,''))) AS NVARCHAR(250)),
CAST(LTRIM(RTRIM(ISNULL(@CPositionNo,''))) AS NVARCHAR(250)),
ISNULL(@Organization,0),ISNULL(@Job,0),
CAST(LTRIM(RTRIM(ISNULL(@CPositionNo,''))) AS NVARCHAR(250)),
CAST(LTRIM(RTRIM(ISNULL(@CPositionNo,''))) AS NVARCHAR(250)),
case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end
,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
WHERE LTRIM(RTRIM(ISNULL(@CPositionNo,''))) <>''
AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CPositionNo,'')))) AS NVARCHAR(250)) 
NOT IN (SELECT case when @Consolidation =1 THEN 
		CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.PositionNoNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.PositionNoANameCons))) END  
		ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.PositionName))) ELSE UPPER(LTRIM(RTRIM(T2.PositionAName))) END END FROM Positions T2 WHERE T2.Organization = @Organization AND T2.JOB = @Job)
SET @Error=@@ERROR
IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
IF @Consolidation =1
	SELECT @PositionNo = PositionNo FROM Positions WHERE UPPER(LTRIM(RTRIM(PositionNoNameCons))) = UPPER(LTRIM(RTRIM(@CPositionNo))) AND Organization = @Organization AND JOB = @Job 
ELSE
	SELECT @PositionNo = PositionNo FROM Positions WHERE UPPER(LTRIM(RTRIM(PositionName))) = UPPER(LTRIM(RTRIM(@CPositionNo))) AND Organization = @Organization AND JOB = @Job 

IF ISNULL(@PositionNo,0)<>0 AND NOT EXISTS (SELECT * FROM PositionsStructure WHERE VersionNo=1 AND PositionNo = @PositionNo)
BEGIN
	insert INTO PositionsStructure (VersionNo,PositionNo,PositionParent,PositionOrder)
	VALUES(1,@PositionNo,NULL,0)
	SET @Error=@@ERROR
	IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error
END

END


END
--Adjust Location

SET @OrgParent=@Organization
WHILE isnull(@LocationNo,0)=0  
BEGIN 
	SET @LocationNo =(SELECT Locationno FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	IF isnull(@LocationNo,0)=0  AND isnull(@OrgParent,0)=0 
	BEGIN
		SET @LocationNo=(SELECT Locationno FROM SysParam) break
	END
END


--Adjust Employer
IF isnull(@EmployerId,0)=0 
BEGIN 
	SET @EmployerId =(SELECT EmployerId FROM Positions WHERE PositionNo = @PositionNo )
END
SET @OrgParent=@Organization
WHILE isnull(@EmployerId,0)=0 
BEGIN 
	SET @EmployerId =(SELECT EmployerId FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	IF isnull(@EmployerId,0)=0 AND isnull(@OrgParent,0)=0
	BEGIN
		SET @EmployerId=(SELECT EmployerId FROM SysParam) break
	END
END


--SELECT @SSGroup = SSGroup FROM SSGroup WHERE UPPER(LTRIM(RTRIM(SSGroupName))) = UPPER(LTRIM(RTRIM(@CSSGroup))) 
	

SET @OrgParent=@Organization
--IF isnull(@SSGroup,0)=0 
--BEGIN 
--	WHILE isnull(@OrgParent,0)<> 0 AND isnull(@SSGroup,0)=0 
--BEGIN 
--	SET @SSGroup =(SELECT SSGroup FROM Organization WHERE Organization=@OrgParent)
--	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
--	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
--END
--END

------------- Time Rule ---------------
IF @TimeRule IS NULL
BEGIN
	SET @TimeRule =(SELECT TimeRule FROM Positions WHERE PositionNo = @PositionNo )
END
IF @TimeRule IS NULL
BEGIN 
	SET @OrgParent=@Organization
	WHILE @OrgParent IS not NULL AND @TimeRule IS null
	BEGIN 
		SET @TimeRule =(SELECT TimeRule FROM Organization WHERE Organization=@OrgParent)
		SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
		WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	END
END
IF @TimeRule IS NULL
BEGIN 
	SET @TimeRule=(SELECT deftrule FROM sysparam)
END

------------- Vacation Package ---------------
IF @VacPack IS NULL
BEGIN 
	SET @VacPack =(SELECT VacPack FROM Positions WHERE PositionNo = @PositionNo )
END
IF @VacPack IS NULL
BEGIN 
	SET @OrgParent=@Organization
	WHILE @OrgParent IS not NULL AND @VacPack IS null
	BEGIN 
		SET @VacPack =(SELECT VacPack FROM Organization WHERE Organization=@OrgParent)
		SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
		WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	END
END
IF @VacPack IS NULL
BEGIN 
	SET @VacPack=(SELECT defvacpack FROM sysparam)
END

-- Adjust Contract Type
		   	PRINT 'Fetching Contract Type'	
INSERT INTO ContractType(ContractType,ContractName,ContractAName,ContractNameCons,ContractANameCons,ContractTypeOrgs,UEnterBy,UEnterDate)
SELECT(SELECT ISNULL(MAX(T1.ContractType),0)+1 FROM ContractType T1),
CAST(LTRIM(RTRIM(ISNULL(@CContractType,''))) AS NVARCHAR(60)),
CAST(LTRIM(RTRIM(ISNULL(@CContractType,''))) AS NVARCHAR(60)),
CAST(LTRIM(RTRIM(ISNULL(@CContractType,''))) AS NVARCHAR(250)),
CAST(LTRIM(RTRIM(ISNULL(@CContractType,''))) AS NVARCHAR(250)),
case when @EnableOrgSetup =1 and @userOrganization <> ''then @userOrganization else ''end
,CAST(LTRIM(RTRIM(ISNULL(@LogonName,''))) AS NVARCHAR),CAST(GETDATE() AS smalldatetime)
WHERE LTRIM(RTRIM(ISNULL(@CContractType,''))) <>''
AND CAST(UPPER(LTRIM(RTRIM(ISNULL(@CContractType,'')))) AS NVARCHAR(250)) NOT IN (SELECT case when @Consolidation =1 THEN  
CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.ContractNameCons))) ELSE UPPER(LTRIM(RTRIM(T2.ContractANameCons))) END 
ELSE CASE WHEN @lang = 'E' THEN UPPER(LTRIM(RTRIM(T2.ContractName))) ELSE UPPER(LTRIM(RTRIM(T2.ContractAName))) END END FROM ContractType T2)
SET @Error=@@ERROR
IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error

IF @Consolidation =1
	SELECT @ContractType = ContractType FROM ContractType WHERE UPPER(LTRIM(RTRIM(ContractNameCons))) = UPPER(LTRIM(RTRIM(@CContractType))) 
ELSE
	SELECT @ContractType = ContractType FROM ContractType WHERE UPPER(LTRIM(RTRIM(ContractName))) = UPPER(LTRIM(RTRIM(@CContractType))) 


-- Adjust Employee 
--Name
-- Adjust Applicant Name
		   	PRINT 'Adjust Applicant Name'	
SELECT @CNT=COUNT(*) FROM Profile WHERE Name=cast(@Name AS NVARCHAR(50))
IF @CNT=0
BEGIN
declare @ErrorSum as int
select @ErrorSum=0

begin transaction
---------------------------------------------------------add sec V_Applicants--------------------------------------------------------------
INSERT INTO V_Applicants( ProfileId,
AssignmentId
    ,
	NamePrefix,
	FirstName,
	MidName,
	LastName,
	FourthName,
	FirstAName,
	MidAName, 
	LastAName,
	FourthAName
      , NatnlNo
	  , Gender,
	  BirthDate,	  Mobile,	  TeleNo1    , Address,
	PrivateEmail,
	CompanyEmail
    , NationId,
	IdRegOff,
	IdIssDate,
	ForPassNo,
	ForPasFrm,
	ForPasDt,
	ForPasExp, 
	SocStatus,
	HrSsAppl,
	ContBasSal,
	ContInfo,
	ApplicationStatus
	, ApplicationStart, 
	ApplicationEnd,
	ApplicationSource
    , RecruitmentActivity,
	VacancyNo,
	LocationNo    
    , PositionNo
	, Organization
	, Job, 
	Privacy,
	SSGroup  
	, Grade,
	ContBasCur    
    , HrCurrency
	, ContNet
	, HrSsFixVal
	, HrBasicSal, 
	HrSsVarVal, 
	HrBenefit,
	HrSsBonVal,
	VacPack 
    , HrScStatus,
	TimeRule, 
	EmployerId, 
	ContStart, 
	ContractType,
	ContEnd, 
	ProbDate    
    , ProfileEnterBy
	, ProfileEnterDate,
	ProfileChangeBy, 
	EnterBy, 
	ChangeBy, 
	EmpId, 
	BirthAddress
	,SupplierNo
	)
	
	select 0,0,0,
  case when @lang = 'A' then dbo.TranslateName(ISNULL(@FirstName,''),@Lang) else ISNULL(@FirstName,'') END ,
  case when @lang = 'A' then dbo.TranslateName(ISNULL(@MidName,''),@Lang) else ISNULL(@MidName,'') END ,
  case when @lang = 'A' then dbo.TranslateName(ISNULL(@LastName,''),@Lang) else ISNULL(@LastName,'') END ,
  case when @lang = 'A' then dbo.TranslateName(ISNULL(@FourthName,''),@Lang) else ISNULL(@FourthName,'') END ,
  case when @lang = 'E' then dbo.TranslateName(ISNULL(@FirstName,''),@Lang) else ISNULL(@FirstName,'') END ,
  case when @lang = 'E' then dbo.TranslateName(ISNULL(@MidName,''),@Lang) else ISNULL(@MidName,'') END ,
  case when @lang = 'E' then dbo.TranslateName(ISNULL(@LastName,''),@Lang) else ISNULL(@LastName,'') END ,
  case when @lang = 'E' then dbo.TranslateName(ISNULL(@FourthName,''),@Lang) else ISNULL(@FourthName,'') END ,
  ISNULL(cast(@NatnlNo AS NVARCHAR(20)),''),
  isnull(@Gender,0), 
  convert(datetime,@Birthdate,@DateFormat),
  ISNULL(cast(@Mobile AS NVARCHAR(20)),''),
  ISNULL(cast(@TeleNo1 AS NVARCHAR(20)),''),
  ISNULL(cast(@Address AS NVARCHAR(254)),''),

  ISNULL(cast(@PrivateEmail AS NVARCHAR(80)),''),
  ISNULL(cast(@CompanyEmail AS NVARCHAR(80)),''),
  ISNULL(@NationId,(SELECT defnation FROM sysparam)),

  ISNULL(cast(@IdRegOff AS NVARCHAR(20)),''),

  convert(datetime,@IdIssDate,@DateFormat),

  ISNULL(cast(@ForPassNo AS NVARCHAR(15)),''),
  ISNULL(cast(@ForPasFrm AS NVARCHAR(15)),''),
  convert(datetime,@ForPasDt,@DateFormat),
  convert(datetime,@ForPasExp,@DateFormat),

  isnull(@SocStatus,0), 

  ISNULL(@HrSsAppl,0) , -- HrSsAppl - bit

  ISNULL(@ContBasSal,0) , -- ContBasSal - numeric
  ISNULL(@ContInfo,'') , -- ContInfo - nvarchar(max)

  @ApplicationStatus , -- ApplicationStatus - smallint
  convert(datetime,@ApplicationStart,@DateFormat) , -- ApplicationStart - smalldatetime
  convert(datetime,@ApplicationEnd,@DateFormat) , -- ApplicationEnd - smalldatetime
   @ApplicationSource , -- ApplicationSource - smallint
   @RecruitmentActivity , -- RecruitmentActivity - int
   @VacancyNo , -- VacancyNo - int
   @LocationNo , -- LocationNo - smallint
   @PositionNo , -- PositionNo - smallint
   @Organization , -- Organization - smallint
   @Job , -- Job - smallint
   ISNULL(@Privacy,0) , -- Privacy - smallint
   null,   -- ssgroup

   @Grade , -- Grade - smallint
   @CContBasCur , -- ContBasCur - smallint
   @HrCurrency , -- HrCurrency - smallint
   ISNULL(@ContNet,0) , -- ContNet - bit
   ISNULL(@HrSsFixVal,0) , -- HrSsFixVal - numeric
   ISNULL(@HrBasicSal,0) , -- HrBasicSal - numeric
   ISNULL(@HrSsVarVal,0) , -- HrSsVarVal - numeric
   ISNULL(@HrBenefit,0) , -- HrBenefit - numeric
   ISNULL(@HrSsBonVal,0) , -- HrSsBonVal - numeric
   @VacPack , -- VacPack - smallint
   ISNULL(@HrScStatus,1) , -- HrScStatus - smallint
   @TimeRule , -- TimeRule - smallint
   @EmployerId , -- EmployerId - smallint
   convert(datetime,@ContStart,@DateFormat) , -- ContStart - smalldatetime
   @ContractType , -- ContractType - smallint
   convert(datetime,@ContEnd,@DateFormat), -- ContEnd - smalldatetime
   convert(datetime,@ProbDate,@DateFormat), -- ProbDate - smalldatetime
   isnull(@EnterBy,0),
   GETDATE(),
   null,
   isnull(@EnterBy,0),
   null,0,N'',null
-- Insert New Profile

--EXEC hits_getprofileid @Profileid OUTPUT
--		   	PRINT 'Insert New Profile'	

--INSERT INTO PROFILE
--     (
--       ProfileId,
--       FirstHiredDate,
--       FirstName,
--       MidName,
--       LastName,
--       FourthName,
--       FirstAName,
--       MidAName,
--       LastAName,
--       FourthAName,
--       SocStatus,
--       Mobile,
--       TeleNo1,
--       ADDRESS,
--       PrivateEmail,
--       CompanyEmail,
--       Gender,
--       NatnlNo,
--       BirthDate,
--       NationId,
--       ForPassNo,
--       ForPasDt,
--       ForPasExp,
--       ForPasFrm,
--       IdIssDate,
--       IdRegOff,
--       ProfileEnterBy,
--       ProfileEnterDate,
--       ProfileChangeBy
--     )
--SELECT 
--  @Profileid ,  
--  NULL,
--  case when @lang = 'A' then dbo.TranslateName(ISNULL(@FirstName,''),@Lang) else ISNULL(@FirstName,'') END ,
--  case when @lang = 'A' then dbo.TranslateName(ISNULL(@MidName,''),@Lang) else ISNULL(@MidName,'') END ,
--  case when @lang = 'A' then dbo.TranslateName(ISNULL(@LastName,''),@Lang) else ISNULL(@LastName,'') END ,
--  case when @lang = 'A' then dbo.TranslateName(ISNULL(@FourthName,''),@Lang) else ISNULL(@FourthName,'') END ,
--  case when @lang = 'E' then dbo.TranslateName(ISNULL(@FirstName,''),@Lang) else ISNULL(@FirstName,'') END ,
--  case when @lang = 'E' then dbo.TranslateName(ISNULL(@MidName,''),@Lang) else ISNULL(@MidName,'') END ,
--  case when @lang = 'E' then dbo.TranslateName(ISNULL(@LastName,''),@Lang) else ISNULL(@LastName,'') END ,
--  case when @lang = 'E' then dbo.TranslateName(ISNULL(@FourthName,''),@Lang) else ISNULL(@FourthName,'') END ,
--  isnull(@SocStatus,0), 
--  ISNULL(cast(@Mobile AS NVARCHAR(20)),''),
--  ISNULL(cast(@TeleNo1 AS NVARCHAR(20)),''),
--  ISNULL(cast(@Address AS NVARCHAR(254)),''),
--  ISNULL(cast(@PrivateEmail AS NVARCHAR(80)),''),
--  ISNULL(cast(@CompanyEmail AS NVARCHAR(80)),''),
--  isnull(@Gender,0), 
--  ISNULL(cast(@NatnlNo AS NVARCHAR(20)),''),
--  convert(datetime,@Birthdate,@DateFormat),
--  ISNULL(@NationId,(SELECT defnation FROM sysparam)), 
--  ISNULL(cast(@ForPassNo AS NVARCHAR(15)),''),
--  convert(datetime,@ForPasDt,@DateFormat),
--  convert(datetime,@ForPasExp,@DateFormat),
--  ISNULL(cast(@ForPasFrm AS NVARCHAR(15)),''),
--  convert(datetime,@IdIssDate,@DateFormat),
--  ISNULL(cast(@IdRegOff AS NVARCHAR(20)),''),
--  isnull(@EnterBy,0),
--  GETDATE(),
--  NULL

--SET @ErrorSum=@@ERROR+@ErrorSum
--SET @Error=@ErrorSum
--IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error 


---- Insert New AppAssignment
--PRINT 'Insert New Applicant'

--INSERT INTO dbo.AppAssignment
--        ( EmpId ,
--          AssignmentId ,
--          ApplicationStatus ,
--          ApplicationStart ,
--          ApplicationEnd ,
--          ApplicationSource ,
--          RecruitmentActivity ,
--          VacancyNo ,
--          HrScStatus ,
--          PositionNo ,
--          Job ,
--          Organization ,
--          LocationNo ,
--          Grade ,
--   --       SSGroup ,
--          ContractType ,
--          HrSsAppl ,
--          HrSsFixVal ,
--          HrSsVarVal ,
--          HrSsBonVal ,
--          EmployerId ,
--          HrCurrency ,
--          HrBenefit ,
--          HrBasicSal ,
--          ContBasSal ,
--          ContBasCur ,
--          ContNet ,
--          ContInfo ,
--          ContStart ,
--          ContEnd ,
--          ProbDate ,
--          VacPack ,
--          Privacy ,
--          TimeRule ,
--          EnterBy ,
--          EnterDate ,
--          ChangeBy ,
--          LastEffectiveDate
--        )
--select @Profileid , -- EmpId - int
--          0 , -- AssignmentId - int
--          @ApplicationStatus , -- ApplicationStatus - smallint
--          convert(datetime,@ApplicationStart,@DateFormat) , -- ApplicationStart - smalldatetime
--          convert(datetime,@ApplicationEnd,@DateFormat) , -- ApplicationEnd - smalldatetime
--          @ApplicationSource , -- ApplicationSource - smallint
--          @RecruitmentActivity , -- RecruitmentActivity - int
--          @VacancyNo , -- VacancyNo - int
--          ISNULL(@HrScStatus,1) , -- HrScStatus - smallint
--          @PositionNo , -- PositionNo - smallint
--          @Job , -- Job - smallint
--          @Organization , -- Organization - smallint
--          @LocationNo , -- LocationNo - smallint
--          @Grade , -- Grade - smallint
-- --         ISNULL(@SSGroup,1) , -- SSGroup - smallint
--          @ContractType , -- ContractType - smallint
--          ISNULL(@HrSsAppl,0) , -- HrSsAppl - bit
--          ISNULL(@HrSsFixVal,0) , -- HrSsFixVal - numeric
--          ISNULL(@HrSsVarVal,0) , -- HrSsVarVal - numeric
--          ISNULL(@HrSsBonVal,0) , -- HrSsBonVal - numeric
--          @EmployerId , -- EmployerId - smallint
--          @HrCurrency , -- HrCurrency - smallint
--          ISNULL(@HrBenefit,0) , -- HrBenefit - numeric
--          ISNULL(@HrBasicSal,0) , -- HrBasicSal - numeric
--          ISNULL(@ContBasSal,0) , -- ContBasSal - numeric
--          @CContBasCur , -- ContBasCur - smallint
--          ISNULL(@ContNet,0) , -- ContNet - bit
--          ISNULL(@ContInfo,'') , -- ContInfo - nvarchar(max)
--          @ContStart , -- ContStart - smalldatetime
--          @ContEnd , -- ContEnd - smalldatetime
--          @ProbDate , -- ProbDate - smalldatetime
--          @VacPack , -- VacPack - smallint
--          ISNULL(@Privacy,0) , -- Privacy - smallint
--          @TimeRule , -- TimeRule - smallint
--          isnull(@EnterBy,0) , -- EnterBy - int
--          GETDATE() , -- EnterDate - smalldatetime
--          NULL , -- ChangeBy - int
--          NULL  -- LastEffectiveDate - smalldatetime

SET @ErrorSum=@@ERROR+@ErrorSum
SET @Error=@ErrorSum
IF @error <>0 SELECT @ErrMsg=@ErrMsg+' '+ case when @Lang ='E' then '/ error: '+sqlmessages.[description] WHEN @Lang='A' THEN N'/ خطأ: '+sqlmessages.Adescription ELSE '/ erreur: '+ sqlmessages.Fdescription END  FROM SQLmessages WHERE [error]=@error
PRINT 'Error Msg : ' + @ErrMsg

if @ErrorSum=0 commit else rollback 
END


SELECT @STR ='UPDATE ' + @tablename + ' SET remarks = ''' + 
REPLACE(CASE WHEN @ErrMsg = '' THEN 
case when @Lang ='E' then 'Applicant inserted successfully' WHEN @Lang='A' THEN N'تم ادخال المتقدم بنجاح' END ELSE @ErrMsg
 end,'''','''''') + '''
 where row_Number = ' + str(@Row_Number)
PRINT @STR
EXECUTE(@STR)    

FETCH next FROM EmployeesCursor
INTO @Name		
,@NatnlNo				
,@CGender				
,@BirthDate				
,@Mobile				
,@TeleNo1				
,@Address				
,@PrivateEmail		
,@CompanyEmail		
,@CNationId			
,@CApplicationStatus	
,@ApplicationStart	
,@ApplicationEnd		
,@CApplicationSource	
,@CRecruitmentActivity 
,@CVacancyNo			
,@CLocationNo			
,@CPositionNo			
,@CGrade				
,@COrg1				
,@COrg2				
,@COrg3				
,@COrg4				
,@COrg5				
,@COrg6				
,@COrg7				
,@CJob				
,@privacy					
,@IdRegOff				
,@IdIssDate				
,@ForPassNo			
,@ForPasFrm			
,@ForPasDt			
,@ForPasExp			
,@CSocStatus			
,@HrSsAppl				
,@ContBasSal			
,@ContInfo		
,@CContBasCur			
,@CHrCurrency			
,@ContNet				 
,@HrSsFixVal			
,@HrBasicSal			
,@HrSsVarVal			
,@HrBenefit			
,@HrSsBonVal			
,@CVacPack			
,@CHrScStatus			
,@CTimeRule					
,@CEmployerId			
,@ContStart			
,@CContractType		
,@ContEnd				
,@ProbDate		
,@Row_Number

END 
CLOSE EmployeesCursor
DEALLOCATE EmployeesCursor

IF @DisableTriggers = 1
BEGIN
	OPEN Triggers
	FETCH NEXT FROM Triggers into  @triggername ,@tablename 
	WHILE @@FETCH_STATUS = 0
	BEGIN
		  set @selectcommand ='ALTER TABLE '+ @tablename+ ' ENABLE TRIGGER ' +@triggername
		  ----print @selectcommand
		  execute sp_executesql @selectcommand
		  FETCH NEXT FROM Triggers into @triggername ,@tablename 
	 end
	CLOSE Triggers

	DEALLOCATE Triggers
	DROP TABLE #Triggers

END

END

    IF @actiontype = 3
        BEGIN
            DECLARE @updatestr AS NVARCHAR(MAX) ,
                @insertstr AS NVARCHAR(MAX) ,
                @deletestr AS NVARCHAR(MAX) ,
                @selectstr AS NVARCHAR(MAX) ,
                @DisabledColStr AS NVARCHAR(100) ,
                @select AS NVARCHAR(MAX);
            IF RTRIM(LTRIM(@tablename)) <> ''
                BEGIN
                    DECLARE @TableNamelen AS INT; 
                    SET @TableNamelen = LEN(@tablename)
                        - CHARINDEX('[nasbatch', @tablename) - 1;
                    SET @select = 'IF not EXISTS(SELECT top 1 1
						FROM ' + SUBSTRING(@tablename, 0,CHARINDEX('.dbo', @tablename))+ '.INFORMATION_SCHEMA.Columns 
						WHERE  ' + SUBSTRING(@tablename, 0,CHARINDEX('.dbo', @tablename))+ '.INFORMATION_SCHEMA.Columns.TABLE_NAME='''
                        + SUBSTRING(@tablename,CHARINDEX('[nasbatch', @tablename) + 1,@TableNamelen) + ''')' 
						+ 'CREATE TABLE '+ @tablename + 
							'(Remarks			NVARCHAR(MAX) ,
							Post				BIT ,
							Name				NVARCHAR(255) ,
							NatnlNo				NVARCHAR(255) ,
							CGender				NVARCHAR(255) ,
							BirthDate			NVARCHAR(255) ,
							Mobile				NVARCHAR(255) ,
							TeleNo1				NVARCHAR(255) ,
							Address				NVARCHAR(255) ,
							PrivateEmail		NVARCHAR(255) ,
							CompanyEmail		NVARCHAR(255) ,
							CNationId			NVARCHAR(255) ,
							CApplicationStatus	NVARCHAR(255) ,
							ApplicationStart	NVARCHAR(255) ,
							ApplicationEnd		NVARCHAR(255) ,
							CApplicationSource	NVARCHAR(255) ,
							CRecruitmentActivity NVARCHAR(255) ,
							CVacancyNo			NVARCHAR(255) ,
							CLocationNo			NVARCHAR(255) ,
							CPositionNo			NVARCHAR(255) ,
							CGrade				NVARCHAR(255) ,
							COrg1				NVARCHAR(255) ,
							COrg2				NVARCHAR(255) ,
							COrg3				NVARCHAR(255) ,
							COrg4				NVARCHAR(255) ,
							COrg5				NVARCHAR(255) ,
							COrg6				NVARCHAR(255) ,
							COrg7				NVARCHAR(255) ,
							CJob				NVARCHAR(255) ,
							Privacy		     	NVARCHAR(255) ,
							IdRegOff			NVARCHAR(255) ,
							IdIssDate			NVARCHAR(255) ,
							ForPassNo			NVARCHAR(255) ,
							ForPasFrm			NVARCHAR(255) ,
							ForPasDt			NVARCHAR(255) ,
							ForPasExp			NVARCHAR(255) ,
							CSocStatus			NVARCHAR(255) ,
							HrSsAppl			BIT ,
							ContBasSal			numeric(18, 3) ,
							ContInfo			NVARCHAR(255) ,
							CContBasCur			NVARCHAR(255) ,
							CHrCurrency			NVARCHAR(255) ,
							ContNet				BIT ,
							HrSsFixVal			numeric(18, 3) ,
							HrBasicSal			numeric(18, 3) ,
							HrSsVarVal			numeric(18, 3) ,
							HrBenefit			numeric(18, 3) ,
							HrSsBonVal			numeric(18, 3) ,
							CVacPack			NVARCHAR(255) ,
							CHrScStatus			NVARCHAR(255) ,
							CTimeRule			NVARCHAR(255) ,
							CEmployerId			NVARCHAR(255) ,
							ContStart			NVARCHAR(255) ,
							CContractType		NVARCHAR(255) ,
							ContEnd				NVARCHAR(255) ,
							ProbDate			NVARCHAR(255) 
							,[Row_Number]		int identity(1,1) PRIMARY KEY) ';
                END;
            ELSE
                BEGIN
                    SET @tablename = '  ';
                    SET @selectstr = 'SELECT
							'''' as Remarks
							,0 as Post
							,'''' AS Name			
							,'''' AS NatnlNo				
							,'''' AS CGender				
							,'''' AS BirthDate			
							,'''' AS Mobile				
							,'''' AS TeleNo1				
							,'''' AS Address				
							,'''' AS PrivateEmail		
							,'''' AS CompanyEmail		
							,'''' AS CNationId			
							,'''' AS CApplicationStatus	
							,'''' AS ApplicationStart	
							,'''' AS ApplicationEnd		
							,'''' AS CApplicationSource	
							,'''' AS CRecruitmentActivity 
							,'''' AS CVacancyNo			
							,'''' AS CLocationNo			
							,'''' AS CPositionNo			
							,'''' AS CGrade				
							,'''' AS COrg1				
							,'''' AS COrg2				
							,'''' AS COrg3				
							,'''' AS COrg4				
							,'''' AS COrg5				
							,'''' AS COrg6				
							,'''' AS COrg7				
							,'''' AS CJob				
							,'''' AS Privacy			
							,'''' AS IdRegOff			
							,'''' AS IdIssDate				
							,'''' AS ForPassNo			
							,'''' AS ForPasFrm			
							,'''' AS ForPasDt			
							,'''' AS ForPasExp			
							,'''' AS CSocStatus				
							,0 AS HrSsAppl			
							,'''' AS ContBasSal			
							,'''' AS ContInfo			
							,'''' AS CContBasCur			
							,'''' AS CHrCurrency			
							,0 AS ContNet				 
							,'''' AS HrSsFixVal			
							,'''' AS HrBasicSal			
							,'''' AS HrSsVarVal			
							,'''' AS HrBenefit			
							,'''' AS HrSsBonVal			
							,'''' AS CVacPack			
							,'''' AS CHrScStatus			
							,'''' AS CTimeRule				
							,'''' AS CEmployerId			
							,'''' AS ContStart			
							,'''' AS CContractType		
							,'''' AS ContEnd				
							,'''' AS ProbDate
								WHERE 1<>1';
                END;
            SET @updatestr = 'update ' + @tablename
						  + 'set Post=@Post
							,Remarks = @Remarks
							,Name= @Name			
							,NatnlNo = @NatnlNo				
							,CGender = @CGender				
							,BirthDate = @BirthDate				
							,Mobile = @Mobile				
							,TeleNo1 = @TeleNo1				
							,Address = @Address				
							,PrivateEmail = @PrivateEmail		
							,CompanyEmail = @CompanyEmail		
							,CNationId = @CNationId			
							,CApplicationStatus = @CApplicationStatus	
							,ApplicationStart = @ApplicationStart	
							,ApplicationEnd = @ApplicationEnd		
							,CApplicationSource = @CApplicationSource	
							,CRecruitmentActivity = @CRecruitmentActivity 
							,CVacancyNo = @CVacancyNo			
							,CLocationNo = @CLocationNo			
							,CPositionNo = @CPositionNo			
							,CGrade = @CGrade				
							,COrg1 = @COrg1				
							,COrg2 = @COrg2				
							,COrg3 = @COrg3				
							,COrg4 = @COrg4				
							,COrg5 = @COrg5				
							,COrg6 = @COrg6				
							,COrg7 = @COrg7				
							,CJob = @CJob				
							,Privacy = @Privacy			
							,IdRegOff = @IdRegOff				
							,IdIssDate = @IdIssDate				
							,ForPassNo = @ForPassNo			
							,ForPasFrm = @ForPasFrm			
							,ForPasDt = @ForPasDt			
							,ForPasExp = @ForPasExp			
							,CSocStatus = @CSocStatus		
							,HrSsAppl = @HrSsAppl				
							,ContBasSal = @ContBasSal			
							,ContInfo = @ContInfo		
							,CContBasCur = @CContBasCur			
							,CHrCurrency = @CHrCurrency			
							,ContNet = @ContNet				 
							,HrSsFixVal = @HrSsFixVal			
							,HrBasicSal = @HrBasicSal			
							,HrSsVarVal = @HrSsVarVal			
							,HrBenefit = @HrBenefit			
							,HrSsBonVal = @HrSsBonVal			
							,CVacPack = @CVacPack			
							,CHrScStatus = @CHrScStatus			
							,CTimeRule = @CTimeRule					
							,CEmployerId = @CEmployerId			
							,ContStart = @ContStart			
							,CContractType = @CContractType		
							,ContEnd = @ContEnd				
							,ProbDate = @ProbDate
							where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'

							-- exec [Batch_Validate] '''+@tablename+''','''',@originalRow_Number,''WP_GetExternalApplicants?'+ LTRIM(@CreateSetUp)+' '',' + @lang

            SET @insertstr = ' insert into ' + @tablename + ' select 
				@Remarks
				,@Post
				,@Name		
				,@NatnlNo				
				,@CGender				
				,@BirthDate			
				,@Mobile				
				,@TeleNo1				
				,@Address				
				,@PrivateEmail		
				,@CompanyEmail		
				,@CNationId			
				,@CApplicationStatus	
				,@ApplicationStart	
				,@ApplicationEnd		
				,@CApplicationSource	
				,@CRecruitmentActivity 
				,@CVacancyNo			
				,@CLocationNo			
				,@CPositionNo			
				,@CGrade				
				,@COrg1				
				,@COrg2				
				,@COrg3				
				,@COrg4				
				,@COrg5				
				,@COrg6				
				,@COrg7				
				,@CJob				
				,@Privacy			
				,@IdRegOff				
				,@IdIssDate				
				,@ForPassNo			
				,@ForPasFrm			
				,@ForPasDt			
				,@ForPasExp			
				,@CSocStatus				
				,@HrSsAppl			
				,@ContBasSal			
				,@ContInfo		
				,@CContBasCur			
				,@CHrCurrency			
				,@ContNet				 
				,@HrSsFixVal			
				,@HrBasicSal			
				,@HrSsVarVal			
				,@HrBenefit			
				,@HrSsBonVal			
				,@CVacPack			
				,@CHrScStatus			
				,@CTimeRule			
				,@CEmployerId			
				,@ContStart			
				,@CContractType		
				,@ContEnd				
				,@ProbDate
				 )';
            SET @deletestr = ' delete from  ' + @tablename
                + ' where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)';
            SET @DisabledColStr = '1,3,115';
            EXEC sp_executesql @select;
            SELECT  @updatestr AS updatestr ,
                    @insertstr AS insertstr ,
                    @deletestr AS deletestr ,
                    @DisabledColStr AS DisabledColStr;
	
        END;

GO

