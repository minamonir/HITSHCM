

CREATE PROCEDURE [dbo].[AI_BuildApplicantFromJSON] 
    @JsonString NVARCHAR(MAX),
    @LogonName NVARCHAR(80),
	@ApplicantId INT OUTPUT,
	@AllErrors NVARCHAR(MAX) = '' OUTPUT 
AS
BEGIN
    SET NOCOUNT ON;
	SET XACT_ABORT OFF;  

	SET @AllErrors = '';

	declare @MinuteOffset INT = 0,
			@date smalldatetime,
			@ErrorMessage NVARCHAR(4000),
			@ErrorSeverity INT,
			@ErrorState INT,
			@EnterBy int
			select @date=cast(Getdate() as date)
			select @EnterBy=empid from nasusers where LogonName=@LogonName
		declare @currentdate smalldatetime = cast(getdate() as smalldatetime);
    BEGIN TRY
        -- Validate JSON
        IF ISJSON(@JsonString) = 0
        BEGIN
            RAISERROR ('Invalid JSON input', 16, 1);
            RETURN;
        END

        -- Extract JSON sections
        DECLARE 
            @PersonalInfoQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.PersonalInformation'),
            @WorkExperienceQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.WorkExperience'),
            @EducationQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Education'),
            @TrainingQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Training'),
            @CertificatesQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Certificates'),
            @ProjectsQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Projects'),
            @PersonalSkillsQuery NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.PersonalSkills'),
		    @StartDate DATETIME = TRY_CAST(JSON_VALUE(@JsonString, '$.StartDate') AS DATETIME),
            @EndDate DATETIME = TRY_CAST(JSON_VALUE(@JsonString, '$.EndDate') AS DATETIME),
            @AppStatus INT = TRY_CAST(JSON_VALUE(@JsonString, '$.AppStatus') AS INT),
			@Vacancy   INT = TRY_CAST(JSON_VALUE(@JsonString, '$.Vacancy') AS INT),
			@AppSource INT = TRY_CAST(JSON_VALUE(@JsonString, '$.AppSource') AS INT),
            @ApplicantNo INT = 0

        -- Personal information fields
        DECLARE 
            @Name NVARCHAR(200) = NULL,
            @Address NVARCHAR(4000) = NULL,
            @Phone NVARCHAR(50) = NULL,
            @Email NVARCHAR(200) = NULL,
            @DateOfBirth SMALLDATETIME = NULL,
            @Nationality NVARCHAR(100) = NULL,
            @Gender NVARCHAR(50) = NULL,
            @LinkedInProfile NVARCHAR(400) = NULL,
            @FacebookPage NVARCHAR(400) = NULL,
            @OtherSocialLinks NVARCHAR(MAX) = NULL,
			@GenderId SMALLINT = 0;



        IF @PersonalInfoQuery IS NOT NULL
        BEGIN
            select @Name = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.Name'), '')
            select @Address = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.Address'), '')
            select @Phone = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.Phone'), '')
            select @Email = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.Email'), '')
            --select @DateOfBirth = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.DateOfBirth'), '')
			select @DateOfBirth = dbo.ParseAIDate(JSON_VALUE(@PersonalInfoQuery, '$.DateOfBirth'))
            select @Nationality = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.Nationality'), '')
            select @Gender = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.Gender'), '')
            select @LinkedInProfile = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.LinkedInProfile'), '')
            select @FacebookPage = NULLIF(JSON_VALUE(@PersonalInfoQuery, '$.FacebookPage'), '')
			select @OtherSocialLinks =COALESCE(JSON_VALUE(@PersonalInfoQuery, '$.OtherSocialLinksString'),'');
			select @GenderId = CASE WHEN UPPER(LTRIM(RTRIM(ISNULL(@Gender, '')))) = 'MALE' THEN 1	WHEN UPPER(LTRIM(RTRIM(ISNULL(@Gender, '')))) = 'FEMALE' THEN 2 ELSE 0   END;
        END

        -- -------------------------
        -- Insert Applicant if not exists
        -- -------------------------
        BEGIN TRY
            IF NOT EXISTS (  SELECT 1  FROM dbo.V_Applicants WHERE (Mobile = @Phone AND @Phone IS NOT NULL) OR (PrivateEmail = @Email AND @Email IS NOT NULL) )
            BEGIN
                -- Insert new applicant
          DECLARE @FirstName NVARCHAR(50),
				  @LastName NVARCHAR(50);

		select @FirstName = CASE WHEN @Name IS NULL OR LTRIM(RTRIM(@Name)) = '' THEN 'N/A'ELSE LEFT(LTRIM(RTRIM(@Name)), CHARINDEX(' ', LTRIM(RTRIM(@Name)) + ' ') - 1)END
		select @LastName = CASE  WHEN @Name IS NULL OR LTRIM(RTRIM(@Name)) = '' THEN 'N/A'  ELSE
							  RIGHT( LTRIM(RTRIM(@Name)), CHARINDEX(' ', REVERSE(LTRIM(RTRIM(@Name))) + ' ') - 1  )END

	EXEC AI_InsertApplicant
		 @ProfileId = 0,
		 @PersonType = 1,
		 @Name = @Name,
		 @FirstName = @FirstName,
		 @LastName = @LastName,
		 @AName = N'',
		 @FirstAName = N'',
		 @MidAName = N'',
		 @LastAName = N'',
		 @Mobile = @Phone,
		 @PrivateEmail = @Email,
		 @Gender = @GenderId,
		 @NatnlNo = NULL,
		 @BirthDate = @DateOfBirth,
		 @BirthPlace = N'',
		 @Country = N'',
		 @CityId = 0,
		 @Address = @Address,
		 @ApplicationStatus = @AppStatus,
		 @ApplicationStart =@StartDate,
		 @ApplicationEnd=@EndDate,
		 @VacancyNo =@Vacancy,
		 @ApplicationSource=@AppSource,
		 @EnterBy = @EnterBy,
		 @NewApplicantNo = @ApplicantNo OUTPUT;

		   SET @ApplicantId = @ApplicantNo;
		END
		ELSE  
			BEGIN
				SELECT   @ApplicantId = EmpId
				FROM dbo.V_Applicants
				WHERE (Mobile = @Phone AND @Phone IS NOT NULL)
				   OR (PrivateEmail = @Email AND @Email IS NOT NULL);
			END
        END TRY
        BEGIN CATCH
            SELECT 
                @ErrorMessage = ERROR_MESSAGE(),
                @ErrorSeverity = ERROR_SEVERITY(),
                @ErrorState = ERROR_STATE();
                
		 SET @AllErrors = @AllErrors + 'Applicant Creation: ' + @ErrorMessage + CHAR(13) + CHAR(10);
            PRINT 'Error in Applicant Creation: ' + @ErrorMessage;
            RETURN;
        END CATCH
        IF @ApplicantId > 0
        BEGIN
			DECLARE @Param NVARCHAR(MAX),@Param2 NVARCHAR(MAX)

				SELECT @Param = Param1,@Param2=param2
				FROM aiconfig
				WHERE ItemNo = 32574;

			-- Check if configuration exists and has all 9 sections
			DECLARE @ParamCount INT = 0;
			DECLARE @ExpectedCount INT = 9; 
		
			IF @Param IS NOT NULL AND @Param != ''
			BEGIN
				
				---- Count how many items separated by commas (each should be "name:number")
				SELECT @ParamCount = COUNT(*)
				FROM HITSStringSplit(@Param, ',')
				WHERE value LIKE '%:%';
			END

			-- If configuration is missing or incomplete (not exactly 9 sections)
			IF @Param IS NULL OR @Param = '' OR @Param2 IS NULL OR @Param2 = '' OR @ParamCount != @ExpectedCount
			BEGIN
				-- Generate CV configuration automatically
				EXEC dbo.AI_GenerateCvConfiguration @LogonName = @LogonName;
				
				-- Get the newly created configuration
				SELECT @Param = Param1, @Param2 = param2
				FROM aiconfig
				WHERE ItemNo = 32574;
			END

		-- Declare variables for each key
		DECLARE 
			@workexperienceNo INT,
			@educationNo INT,
			@TrainingNo INT,
			@CertificatesNo INT,
			@ProjectsNo INT,
			@lanuageNo INT,
			@ComputerSkillsNo INT,
			@JobRelatedSkillsNo INT,
			@DigitalSkillsNo INT
			, @udf1 int
			,@udf2 int
			,@udf3 int
	
		
	SELECT @workexperienceNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'workexperience:%';
	--SELECT @workexperienceNo

	SELECT @educationNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'education:%';

	SELECT @TrainingNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'Training:%';

	SELECT @CertificatesNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'Certificates:%';

	SELECT @ProjectsNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'Projects:%';

	SELECT @lanuageNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'lanuage:%';

	SELECT @ComputerSkillsNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'ComputerSkills:%';

	SELECT @JobRelatedSkillsNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'JobRelatedSkills:%';

	SELECT @DigitalSkillsNo = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param, ',') 
	WHERE value LIKE 'DigitalSkills:%';

		SELECT @udf1 = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param2, ',') 
	WHERE value LIKE 'udf1:%'

			SELECT @udf2 = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param2, ',') 
	WHERE value LIKE 'udf2:%'
				SELECT @udf3 = CAST(SUBSTRING(value, CHARINDEX(':', value) + 1, LEN(value)) AS INT)
	FROM HITSStringSplit(@Param2, ',') 
	WHERE value LIKE 'udf3:%'
	

	DECLARE @QualificationNo SMALLINT

            -- ===============================================
-- EDUCATION
-- ===============================================
BEGIN TRY
IF @EducationQuery IS NOT NULL AND EXISTS(SELECT 1 FROM OPENJSON(@EducationQuery))
BEGIN
		select @MinuteOffset = 0

    DECLARE 
        @Degree NVARCHAR(100),
        @FieldOfStudy NVARCHAR(200),
        @Institution NVARCHAR(300),
        @StartYear SMALLDATETIME,
        @EndYear SMALLDATETIME,
        @GPA NUMERIC(18,3),
        @Grade NVARCHAR(50),
        @School NVARCHAR(200),
        @YearCompleted SMALLDATETIME,
	    @update INT; -- 1=UPDATE, 0=INSERT


    DECLARE @QualificationGrade SMALLINT;
    DECLARE @QualificationMajor SMALLINT;
    DECLARE @Establishment SMALLINT;

	--need to filter with type
	DECLARE 
    @SetupEstablishmentType     INT,
    @SetupGradeType				INT,
    @SetupMajorType				INT;


	SELECT
		@SetupEstablishmentType = EstablishmentFromType,
		@SetupGradeType     = GradeFromType,
		@SetupMajorType     = MajorFromType
	FROM Qualification
	WHERE QualificationNo = @educationNo;


		DECLARE @AttendFromDateValue SMALLDATETIME;

    DECLARE edu_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT 
            JSON_VALUE(value,'$.Degree'),
            JSON_VALUE(value,'$.FieldOfStudy'),
            JSON_VALUE(value,'$.Institution'),
			dbo.ParseAIDate(JSON_VALUE(value,'$.StartYear')),
			dbo.ParseAIDate(JSON_VALUE(value,'$.EndYear')),
			TRY_CAST(JSON_VALUE(value,'$.GPA') AS NUMERIC(18,3)),
			COALESCE(NULLIF(JSON_VALUE(value,'$.Grade'), ''), 'Unknown'),
            JSON_VALUE(value,'$.School'),
			TRY_CAST(NULLIF(JSON_VALUE(value,'$.YearCompleted'),'') AS datetime)
        FROM OPENJSON(@EducationQuery);

    OPEN edu_cursor;
    FETCH NEXT FROM edu_cursor INTO 
        @Degree,@FieldOfStudy,@Institution,@StartYear,@EndYear,@GPA,@Grade,@School,@YearCompleted;

    WHILE @@FETCH_STATUS = 0
    BEGIN
		--select   @AttendFromDateValue = DATEADD( Day, @MinuteOffset, @date )
		--select @StartYear =isnull( @StartYear, DATEADD( Day, @MinuteOffset, @date ))
		--SELECT @StartYear = ISNULL( @StartYear,DATEADD(DAY, 1, MAX(AttendFromDate)))
		--					FROM EmpQualification
		--					WHERE EmpId = @ApplicantId
		--					  AND QualificationNo = @EducationNo;

							  SELECT @StartYear = ISNULL(@StartYear, DATEADD(DAY, 1, ISNULL(MAX(AttendFromDate), @date)))
								FROM EmpQualification
								WHERE EmpId = @ApplicantId
								AND QualificationNo = @EducationNo;
	
		print 'startYear' + cast( @StartYear as nvarchar(max))


		 select @update = 0; 
		 select @QualificationGrade = NULL;
		 select @QualificationMajor = NULL;
		 select @Establishment = NULL;

	print 'degree='+@Degree
	print 'major='+@FieldOfStudy
   	print 'est='+@Institution


		select @GPA = ISNULL (@GPA, 0)
        SELECT @QualificationGrade = QualificationGrade
        FROM QualificationGrade
        WHERE QualificationGradeName = CAST(LTRIM(RTRIM (@Degree)) AS NVARCHAR(30)) and QualificationGradeType= @SetupGradeType;

        SELECT @QualificationMajor = QualificationMajor
        FROM QualificationMajor
        WHERE QualificationMajorName = CAST(LTRIM(RTRIM( @FieldOfStudy)) AS NVARCHAR(60)) and QualificationMajorType=@SetupMajorType;

        SELECT @Establishment = Establishment   
        FROM Establishment
        WHERE EstablishmentName =CAST(LTRIM(RTRIM( @Institution))  AS NVARCHAR(60)) and EstablishmentType=@SetupEstablishmentType;
		
			print @QualificationGrade 
	print @QualificationMajor
	print @Establishment

		--	DECLARE @NewGUID UNIQUEIDENTIFIER = NEWID();
		--	print 'grade='+@Grade
		select @Degree= cast(@Degree as nvarchar(30))
		EXEC dbo.AI_InsertQualificationGrade
			@QualificationGrade          = @QualificationGrade OUTPUT,
			@QualificationGradeType      = @SetupGradeType ,
			@QualificationGradeName      = @Degree,
			@QualificationGradeAName     = @Degree,
			@UEnterBy                    = @LogonName,
			@UEnterDate                  = @CurrentDate,
			@UChangeBy                   = @LogonName,
			@UchangeDate                 = @CurrentDate
				
					print '@QualificationGrade='+ ltrim(@QualificationGrade)
	
		select @FieldOfStudy= cast(@FieldOfStudy as nvarchar(60))
		EXEC dbo.AI_InsertQualificationMajor
						@QualificationMajor          = @QualificationMajor OUTPUT,
						@QualificationMajorType     =@SetupMajorType,
						@QualificationMajorName      = @FieldOfStudy,
						@QualificationMajorAName      = @FieldOfStudy,
						@UEnterBy                    = @LogonName,
						@UChangeBy                   = @LogonName,
						@UchangeDate                 = @CurrentDate,
						@UEnterDate                  = @CurrentDate,
						@ReviewedBy                  = @LogonName,
						@ApprovedBy                  = @LogonName;		

	print '@QualificationMajor='+ltrim(@QualificationMajor)
	
	select @Institution= cast(@Institution as nvarchar(60))
			EXEC [dbo].[AI_InsertEstablishment]
					@Establishment = @Establishment OUTPUT ,  
					@EstablishmentName = @Institution,  
					@EstablishmentAName = @Institution,  
					@EstablishmentType = @SetupEstablishmentType,  
					@UEnterBy = @LogonName,  
					@UChangeBy = @LogonName,  
					@ReviewedBy =@LogonName,  
					@ApprovedBy = @LogonName,
					@UchangeDate = @CurrentDate,
					@UEnterDate   = @CurrentDate;


	print '@Establishment='+ ltrim(@Establishment)


		


		IF EXISTS(
            SELECT * 
            FROM EmpQualification 
            WHERE EmpId = @ApplicantId
              AND QualificationNo = @educationNo
			  AND AttendFromDate = @StartYear 

     --         AND isnull(QualificationGrade,0) = isnull(@QualificationGrade,0)
     --         AND isnull(QualificationMajor,0) =isnull( @QualificationMajor,0)
			  --and isnull(Establishment,0)=isnull(@Establishment,0)
        )
        BEGIN
            select @update = 1; -- UPDATE
       
			  UPDATE EmpQualification
				SET 
					AttendToDate = COALESCE(@EndYear, AttendToDate),
					QualificationApprovedDate = COALESCE(@YearCompleted, QualificationApprovedDate),
					Establishment = COALESCE(@Establishment, Establishment),
					QualificationGrade = COALESCE(@QualificationGrade, QualificationGrade),
					QualificationMajor = COALESCE(@QualificationMajor, QualificationMajor),
					QualificationInfo = COALESCE(@Grade, QualificationInfo)  ,
					QualificationTotalScore = COALESCE(@GPA, QualificationTotalScore)
				WHERE EmpId = @ApplicantId
				  AND QualificationNo = @educationNo
				  AND AttendFromDate = @StartYear
				 -- AND QualificationGrade = @QualificationGrade
				 -- AND QualificationMajor = @QualificationMajor
				 --and  Establishment=@Establishment
				  ;
  
		END
	ELSE
        BEGIN
            select @update = 0; -- INSERT



        EXEC dbo.AI_InsertEmpQualification
			@EmpId = @ApplicantId,
            @QualificationNo = @educationNo,
            @AttendFromDate = @StartYear,
            @AttendToDate = @EndYear,
            @QualificationScore = @GPA,
			@QualificationTotalScore=@GPA,
			@QualificationApprovedDate=@YearCompleted,
			@LicenseNo =N'',
			@QualificationInfo=N'',
			@QualificationSalary=0.000,
			@QualificationBenefit=0.000,
            @Establishment = @Establishment,
            @QualificationGrade = @QualificationGrade,
            @QualificationMajor = @QualificationMajor;
     END
	select @MinuteOffset = @MinuteOffset+1
        FETCH NEXT FROM edu_cursor INTO 
            @Degree,@FieldOfStudy,@Institution,@StartYear,@EndYear,@GPA,@Grade,@School,@YearCompleted;
    END

    CLOSE edu_cursor;
    DEALLOCATE edu_cursor;
END
END TRY
BEGIN CATCH
    -- Log education error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
	  SET @AllErrors = @AllErrors + 'Education: ' + @ErrorMessage + CHAR(13) + CHAR(10);
	    --RAISERROR ('Error processing Education section: %s', 10, 1, @ErrorMessage);
END CATCH

-- ===============================================
-- WORK EXPERIENCE
--===============================================
BEGIN TRY
IF @WorkExperienceQuery IS NOT NULL 
	   AND EXISTS (SELECT 1 FROM OPENJSON(@WorkExperienceQuery))
	BEGIN
	    DECLARE
	        @Position NVARCHAR(200),
	        @Department NVARCHAR(200),
	        @Company NVARCHAR(300),
	        @StartDateExp SMALLDATETIME,
	        @EndDateExp SMALLDATETIME,
	        @Responsibilities NVARCHAR(MAX),
			@updateWork INT;

	    DECLARE 
	        @WE_QualificationGrade SMALLINT,
	        @WE_QualificationMajor SMALLINT,
	        @WE_Establishment SMALLINT;

	    -- Get setup types from Qualification table
	    DECLARE
	        @SetupEstablishmentType2 INT,
	        @SetupGradeType2 INT,
	        @SetupMajorType2 INT;

	    SELECT
	        @SetupEstablishmentType2 = EstablishmentFromType,
	        @SetupGradeType2 = GradeFromType,
	        @SetupMajorType2 = MajorFromType
	    FROM Qualification
	    WHERE QualificationNo = @workexperienceNo;

		 select @MinuteOffset = 0
	    DECLARE work_cursor CURSOR LOCAL FAST_FORWARD FOR
	        SELECT
                JSON_VALUE(value,'$.Position'),
	            JSON_VALUE(value,'$.Department'),
	            JSON_VALUE(value,'$.Company'),
				--NULLIF(JSON_VALUE(value,'$.StartDate'),'') ,
	   --         NULLIF(JSON_VALUE(value,'$.EndDate'),''),
	           dbo.ParseAIDate(JSON_VALUE(value,'$.StartDate')),
			   dbo.ParseAIDate(JSON_VALUE(value,'$.EndDate')),
	            (SELECT STRING_AGG(value,' ; ') 
	             FROM OPENJSON(JSON_QUERY(value,'$.Responsibilities')))
	        FROM OPENJSON(@WorkExperienceQuery);

	    OPEN work_cursor;
	    FETCH NEXT FROM work_cursor INTO
	        @Position, @Department, @Company,
	        @StartDateExp, @EndDateExp, @Responsibilities;

		WHILE @@FETCH_STATUS = 0
			BEGIN
			
			
			
			--select @StartDateExp =isnull( @StartDateExp, DATEADD( Day, @MinuteOffset, @date ))
			--SELECT @StartDateExp = ISNULL(@StartDateExp, DATEADD(DAY, 1, MAX(AttendFromDate)) )
			--						FROM EmpQualification
			--						WHERE EmpId = @ApplicantId
			--						  AND QualificationNo = @workexperienceNo;

					SELECT @StartDateExp = ISNULL(@StartDateExp,  DATEADD(DAY, 1,  ISNULL(MAX(AttendFromDate), @date)))
					FROM EmpQualification
					WHERE EmpId = @ApplicantId
					  AND QualificationNo = @workexperienceNo;

			-- Reset values (MANDATORY)
			select @updateWork =0;
			select @WE_QualificationGrade = NULL;
			select @WE_QualificationMajor = NULL;
			select @WE_Establishment = NULL;

			-- Lookups
			SELECT @WE_QualificationGrade = QualificationGrade
			FROM QualificationGrade
			WHERE QualificationGradeName = cast(LTRIM(RTRIM(@Department))as nvarchar(30))
			  AND QualificationGradeType = @SetupGradeType2;

			SELECT @WE_QualificationMajor = QualificationMajor
			FROM QualificationMajor
			WHERE QualificationMajorName = cast(LTRIM(RTRIM(@Position))as nvarchar(60))
			  AND QualificationMajorType = @SetupMajorType2;

			SELECT @WE_Establishment = Establishment
			FROM Establishment
			WHERE EstablishmentName = cast(LTRIM(RTRIM(@Company))as nvarchar(60))
			  AND EstablishmentType = @SetupEstablishmentType2;

			  --select @SetupGradeType2,@Position, @WE_Establishment, @WE_QualificationGrade, @WE_QualificationMajor

			  print 'work exp setup'
			  print @WE_QualificationGrade
			  print @WE_QualificationMajor
			  print @WE_Establishment
				print '---end work exp setup'
		 
			
	  	  	    	select @Position= cast(@Position as nvarchar(30))

				EXEC dbo.AI_InsertQualificationGrade
					 @QualificationGrade = @WE_QualificationGrade OUTPUT
					,@QualificationGradeType = @SetupGradeType2
					,@QualificationGradeName =  @Department
					,@QualificationGradeAName =  @Department
					,@UEnterBy = @LogonName
					,@UChangeBy = @LogonName
				    ,@UchangeDate = @CurrentDate
					,@UEnterDate   = @CurrentDate;
	
		
					select @Department= cast(@Department as nvarchar(60))

					EXEC dbo.AI_InsertQualificationMajor 
					     @QualificationMajor = @WE_QualificationMajor OUTPUT
						,@QualificationMajorType = @SetupMajorType2
						,@QualificationMajorName = @Position
						,@QualificationMajorAName = @Position
						,@UEnterBy = @LogonName
						,@UChangeBy = @LogonName
						,@ReviewedBy = @LogonName
						,@ApprovedBy = @LogonName;

					select @Company= cast(@Company as nvarchar(60))

						EXEC [dbo].[AI_InsertEstablishment] 
						     @Establishment = @WE_Establishment OUTPUT
							,@EstablishmentName = @Company
							,@EstablishmentAName = @Company
							,@EstablishmentType = @SetupEstablishmentType2
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@ReviewedBy = @LogonName
							,@ApprovedBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;
				
			-- Safety
			select @Responsibilities = COALESCE(@Responsibilities, '');
  
				--DECLARE @WE_AttendFromDateValue SMALLDATETIME;
				--	select  @WE_AttendFromDateValue = COALESCE(@StartDateExp, GETDATE())
	 IF EXISTS(
            SELECT * 
            FROM EmpQualification 
           WHERE EmpId = @ApplicantId
              AND QualificationNo = @workexperienceNo
			  AND AttendFromDate = @StartDateExp  

       --       AND isnull(QualificationGrade,0) = isnull(@WE_QualificationGrade,0)
       --       AND isnull(QualificationMajor,0) = isnull(@WE_QualificationMajor,0)
			    --and isnull(Establishment,0)=isnull(@WE_Establishment,0)
        )
        BEGIN
            select @updateWork = 1; -- UPDATE
            
            -- UPDATE ONLY DATES 
            UPDATE EmpQualification
            SET 
                AttendToDate = COALESCE(@EndDateExp, AttendToDate),
			    QualificationGrade =COALESCE( @WE_QualificationGrade, QualificationGrade),
                QualificationMajor = COALESCE(@WE_QualificationMajor ,QualificationMajor),
				Establishment=COALESCE(@WE_Establishment,Establishment),
				QualificationInfo = COALESCE(@Responsibilities, QualificationInfo)

			   WHERE EmpId = @ApplicantId
              AND QualificationNo = @workexperienceNo
			 AND AttendFromDate = @StartDateExp
        END
      ELSE
        BEGIN
            select @updateWork = 0; -- INSERT


			


			--IF @WE_QualificationGrade IS NULL SET @WE_QualificationGrade = 0;
			--IF @WE_QualificationMajor IS NULL SET @WE_QualificationMajor = 0;
			--IF @WE_Establishment IS NULL SET @WE_Establishment = 0;


			EXEC dbo.AI_InsertEmpQualification
				@EmpId = @ApplicantId,
				@QualificationNo = @workexperienceNo,
				@AttendFromDate =@StartDateExp,
				@AttendToDate = @EndDateExp,
				@QualificationInfo = @Responsibilities,
				@QualificationScore = @GPA,
			    @QualificationTotalScore=@GPA,
				@QualificationSalary = 0.000,
				@QualificationBenefit = 0.000,		
				@LicenseNo =N'',
				@Establishment = @WE_Establishment,
				@QualificationGrade = @WE_QualificationGrade,
				@QualificationMajor = @WE_QualificationMajor;
		END
		select @MinuteOffset = @MinuteOffset+1
			FETCH NEXT FROM work_cursor INTO
				@Position, @Department, @Company,
				@StartDateExp, @EndDateExp, @Responsibilities;
		END

	    CLOSE work_cursor;
	    DEALLOCATE work_cursor;
	END
END TRY
BEGIN CATCH
    -- Log work experience error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
	SET @AllErrors = @AllErrors + 'Work Experience: ' + @ErrorMessage + CHAR(13) + CHAR(10);
    --RAISERROR ('Error processing Work Experience section: %s', 10, 1, @ErrorMessage);
END CATCH
	-- ===============================================
-- TRAINING
-- ===============================================
BEGIN TRY
IF @TrainingQuery IS NOT NULL
   AND EXISTS (SELECT 1 FROM OPENJSON(@TrainingQuery))
		BEGIN
			DECLARE
				@TrainingName NVARCHAR(200),
				@FieldOfStudyTr NVARCHAR(200),
				@InstitutionTr NVARCHAR(300),
				@StartYearTr SMALLDATETIME,
				@EndYearTr SMALLDATETIME,
				@GradeTr NVARCHAR(50),
				@TrainingDetails NVARCHAR(MAX),
				@YearCompletedTr SMALLDATETIME,
				@updateTraining INT;

			DECLARE
				@TR_QualificationGrade SMALLINT,
				@TR_QualificationMajor SMALLINT,
				@TR_Establishment SMALLINT;

			-- Get setup types for TRAINING qualification
			DECLARE
				@SetupEstablishmentTypeTr INT,
				@SetupGradeTypeTr INT,
				@SetupMajorTypeTr INT;

			SELECT
				@SetupEstablishmentTypeTr = EstablishmentFromType,
				@SetupGradeTypeTr = GradeFromType,
				@SetupMajorTypeTr = MajorFromType
			FROM Qualification
			WHERE QualificationNo = @TrainingNo;

			print '2'
			print @SetupEstablishmentTypeTr
			print @SetupGradeTypeTr
			print @SetupMajorTypeTr
			print '2'

			DECLARE @TR_AttendFromDate SMALLDATETIME;
			  select @MinuteOffset = 0

			DECLARE training_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT
					JSON_VALUE(value,'$.TrainingName'),
					JSON_VALUE(value,'$.FieldOfStudy'),
					JSON_VALUE(value,'$.Institution'),
					dbo.ParseAIDate(JSON_VALUE(value,'$.StartYear')),
					dbo.ParseAIDate(JSON_VALUE(value,'$.EndYear')),
					COALESCE(NULLIF(JSON_VALUE(value,'$.Grade'), ''), 'Unknown'),
					JSON_VALUE(value,'$.TrainingDetails'),
					TRY_CAST(NULLIF(JSON_VALUE(value,'$.YearCompleted'),'') AS SMALLDATETIME)
				FROM OPENJSON(@TrainingQuery);

			OPEN training_cursor;
			FETCH NEXT FROM training_cursor INTO
				@TrainingName,
				@FieldOfStudyTr,
				@InstitutionTr,
				@StartYearTr,
				@EndYearTr,
				@GradeTr,
				@TrainingDetails,
				@YearCompletedTr;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				--select   @TR_AttendFromDate = DATEADD( Day, @MinuteOffset, @date )
				--select @StartYearTr =isnull( @StartYearTr, DATEADD( Day, @MinuteOffset, @date ))
				--SELECT @StartYearTr = ISNULL( @StartYearTr, DATEADD(DAY, 1, MAX(AttendFromDate)))
				--				FROM EmpQualification
				--				WHERE EmpId = @ApplicantId
				--				  AND QualificationNo = @TrainingNo;


					SELECT @StartYearTr = ISNULL(@StartYearTr, DATEADD(DAY, 1, ISNULL(MAX(AttendFromDate), @date)))
					FROM EmpQualification
					WHERE EmpId = @ApplicantId
					  AND QualificationNo = @TrainingNo;

				print '@StartYearTr=' + cast(@StartYearTr as nvarchar(max))

				-- Reset lookup values
				select @updateTraining =0;
				select @TR_QualificationGrade = NULL;
				select @TR_QualificationMajor = NULL;
				select @TR_Establishment = NULL;

				-- Lookup Qualification Grade
				SELECT @TR_QualificationGrade = QualificationGrade
				FROM QualificationGrade
				WHERE QualificationGradeName = CAST(LTRIM(RTRIM(@FieldOfStudyTr)) AS NVARCHAR(30))
				  AND QualificationGradeType = @SetupGradeTypeTr;

				-- Lookup Qualification Major
				SELECT @TR_QualificationMajor = QualificationMajor
				FROM QualificationMajor
				WHERE QualificationMajorName = CAST( LTRIM(RTRIM(@TrainingName)) AS NVARCHAR(60))
				  AND QualificationMajorType = @SetupMajorTypeTr;

				-- Lookup Establishment
				SELECT @TR_Establishment = Establishment
				FROM Establishment
				WHERE EstablishmentName = CAST( LTRIM(RTRIM(@InstitutionTr)) AS NVARCHAR(60))
				  AND EstablishmentType = @SetupEstablishmentTypeTr;

				---- set defaults
				--IF @TR_QualificationGrade IS NULL SET @TR_QualificationGrade = 0;
				--IF @TR_QualificationMajor IS NULL SET @TR_QualificationMajor = 0;
				--IF @TR_Establishment IS NULL SET @TR_Establishment = 0;

						select @TrainingName= cast(@TrainingName as nvarchar(30))

						EXEC dbo.AI_InsertQualificationGrade 
						     @QualificationGrade = @TR_QualificationGrade OUTPUT
							,@QualificationGradeType = @SetupGradeTypeTr
							,@QualificationGradeName = @TrainingName
							,@QualificationGradeAName = @TrainingName
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;

						select @FieldOfStudyTr= cast(@FieldOfStudyTr as nvarchar(60))

						EXEC dbo.AI_InsertQualificationMajor 
						     @QualificationMajor = @TR_QualificationMajor OUTPUT
							,@QualificationMajorType = @SetupMajorTypeTr
							,@QualificationMajorName = @FieldOfStudyTr
							,@QualificationMajorAName = @FieldOfStudyTr
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@ReviewedBy = @LogonName
							,@ApprovedBy = @LogonName
							,@UchangeDate = @CurrentDate
					        ,@UEnterDate   = @CurrentDate; 


						select @InstitutionTr= cast(@InstitutionTr as nvarchar(60))

							EXEC [dbo].[AI_InsertEstablishment] 
							     @Establishment = @TR_Establishment OUTPUT
								,@EstablishmentName = @InstitutionTr
								,@EstablishmentAName = @InstitutionTr
								,@EstablishmentType = @SetupEstablishmentTypeTr
								,@UEnterBy = @LogonName
								,@UChangeBy = @LogonName
								,@ReviewedBy = @LogonName
								,@ApprovedBy = @LogonName
								,@UchangeDate = @CurrentDate
							    ,@UEnterDate   = @CurrentDate;



				select @TrainingDetails = COALESCE(@TrainingDetails, '');
			--	print 'treeeeee'
			--print @TR_QualificationGrade
			--print @TR_QualificationMajor
			--print 'treee2'
				     IF EXISTS(
								SELECT * 
								FROM EmpQualification 
								WHERE EmpId = @ApplicantId
								  AND QualificationNo = @TrainingNo
								   AND AttendFromDate=@StartYearTr
								  --AND isnull(QualificationGrade,0) = isnull(@TR_QualificationGrade,0)
								  --AND isnull (QualificationMajor,0) = isnull(@TR_QualificationMajor,0)
							   --   AND isnull(Establishment,0)=isnull(@TR_Establishment,0)
							)
        BEGIN
            select @updateTraining = 1; -- UPDATE
          
            -- UPDATE ONLY DATES
            UPDATE EmpQualification
            SET 
                AttendToDate = COALESCE(@EndYearTr, AttendToDate),
                QualificationApprovedDate = COALESCE(@YearCompletedTr, QualificationApprovedDate),
                Establishment = COALESCE(@TR_Establishment, Establishment),
				QualificationGrade = COALESCE(@TR_QualificationGrade, QualificationGrade),
				QualificationMajor = COALESCE(@TR_QualificationMajor, QualificationMajor),
				QualificationInfo = COALESCE(@TrainingDetails, QualificationInfo)

            WHERE EmpId = @ApplicantId
			      AND QualificationNo = @TrainingNo
					AND AttendFromDate=@StartYearTr;


     --         AND QualificationGrade = @TR_QualificationGrade
     --         AND QualificationMajor = @TR_QualificationMajor
			  --AND Establishment  =@TR_Establishment;
        END
     ELSE
        BEGIN
            select @updateTraining = 0; -- INSERT


				-- Insert Training qualification
				EXEC dbo.AI_InsertEmpQualification
					@EmpId = @ApplicantId,
					@QualificationNo = @TrainingNo,
					@AttendFromDate = @StartYearTr,
					@AttendToDate = @EndYearTr,
					@QualificationScore = 0,
					@QualificationTotalScore = 0,
					@QualificationApprovedDate = @YearCompletedTr,
					@QualificationInfo = @TrainingDetails,
					@QualificationSalary = 0.000,
					@QualificationBenefit = 0.000,
					@LicenseNo = N'',
					@Establishment = @TR_Establishment,
					@QualificationGrade = @TR_QualificationGrade,
					@QualificationMajor = @TR_QualificationMajor;

				END
				select @MinuteOffset = @MinuteOffset+1
				FETCH NEXT FROM training_cursor INTO
					@TrainingName,
					@FieldOfStudyTr,
					@InstitutionTr,
					@StartYearTr,
					@EndYearTr,
					@GradeTr,
					@TrainingDetails,
					@YearCompletedTr;
			END

			CLOSE training_cursor;
			DEALLOCATE training_cursor;
		END
END TRY
BEGIN CATCH
    -- Log training error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
	 SET @AllErrors = @AllErrors + 'Training: ' + @ErrorMessage + CHAR(13) + CHAR(10);
    --RAISERROR ('Error processing Training section: %s', 10, 1, @ErrorMessage);
END CATCH

-- ===============================================
-- END TRAINING SECTION
-- ===============================================
-- ===============================================
-- CERTIFICATES 
-- ===============================================
BEGIN TRY
IF @CertificatesQuery IS NOT NULL
   AND EXISTS (SELECT 1 FROM OPENJSON(@CertificatesQuery))
		BEGIN
			DECLARE
				@CertificateName NVARCHAR(200),
				@FieldOfStudyCert NVARCHAR(200),
				@InstitutionCert NVARCHAR(300),
				@StartYearCert SMALLDATETIME,
				@EndYearCert SMALLDATETIME,
				@GradeCert NVARCHAR(50),
				@CertificateDetails NVARCHAR(MAX),
				@YearCompletedCert SMALLDATETIME,
				@updateCert INT; --  1=UPDATE, 0=INSERT



			DECLARE
				@CERT_QualificationGrade SMALLINT,
				@CERT_QualificationMajor SMALLINT,
				@CERT_Establishment SMALLINT;


			-- Setup types (same pattern as Training)
			DECLARE
				@SetupEstablishmentTypeCert INT,
				@SetupGradeTypeCert INT,
				@SetupMajorTypeCert INT;

			SELECT
				@SetupEstablishmentTypeCert = EstablishmentFromType,
				@SetupGradeTypeCert = GradeFromType,
				@SetupMajorTypeCert = MajorFromType
			FROM Qualification
			WHERE QualificationNo = @CertificatesNo;

			DECLARE @CERT_AttendFromDate SMALLDATETIME;
			select @MinuteOffset = 0

			DECLARE certificate_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT
					JSON_VALUE(value,'$.CertificateName'),
					JSON_VALUE(value,'$.FieldOfStudy'),
					JSON_VALUE(value,'$.Institution'),
					dbo.ParseAIDate(JSON_VALUE(value,'$.StartYear')),
					dbo.ParseAIDate(JSON_VALUE(value,'$.EndYear')),
					COALESCE(NULLIF(JSON_VALUE(value,'$.Grade'), ''), 'Unknown'),
					JSON_VALUE(value,'$.CertificateDetails'),
					TRY_CAST(NULLIF(JSON_VALUE(value,'$.YearCompleted'),'') AS SMALLDATETIME)
				FROM OPENJSON(@CertificatesQuery);

			OPEN certificate_cursor;
			FETCH NEXT FROM certificate_cursor INTO
				@CertificateName,
				@FieldOfStudyCert,
				@InstitutionCert,
				@StartYearCert,
				@EndYearCert,
				@GradeCert,
				@CertificateDetails,
				@YearCompletedCert;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				--select   @CERT_AttendFromDate = DATEADD( Day, @MinuteOffset, @date )
				--select @StartYearCert =isnull( @StartYearCert, DATEADD( Day, @MinuteOffset, @date ))

				--SELECT @StartYearCert = ISNULL( @StartYearCert, DATEADD(DAY, 1, MAX(AttendFromDate)))
				--	FROM EmpQualification
				--	WHERE EmpId = @ApplicantId
				--	  AND QualificationNo = @CertificatesNo;


			SELECT @StartYearCert = ISNULL(@StartYearCert, DATEADD(DAY, 1, ISNULL(MAX(AttendFromDate), @date)))
					FROM EmpQualification
					WHERE EmpId = @ApplicantId
					AND QualificationNo = @CertificatesNo;


			    select @updateCert = 0; 
				select @CERT_QualificationGrade = NULL;
				select @CERT_QualificationMajor = NULL;
				select @CERT_Establishment = NULL;

				-- Grade (lookup only)
				SELECT @CERT_QualificationGrade = QualificationGrade
				FROM QualificationGrade
				WHERE QualificationGradeName = CAST(LTRIM(RTRIM(@CertificateName))AS NVARCHAR(30))
				  AND QualificationGradeType = @SetupGradeTypeCert;

				-- Major (lookup only)
				SELECT @CERT_QualificationMajor = QualificationMajor
				FROM QualificationMajor
				WHERE QualificationMajorName =CAST(LTRIM(RTRIM(@FieldOfStudyCert))AS NVARCHAR(60))
				  AND QualificationMajorType = @SetupMajorTypeCert;

				-- Establishment (lookup only)
				SELECT @CERT_Establishment = Establishment
				FROM Establishment
				WHERE EstablishmentName = CAST(LTRIM(RTRIM(@InstitutionCert))AS NVARCHAR(60))
				  AND EstablishmentType = @SetupEstablishmentTypeCert;


				  	    	select @CertificateName= cast(@CertificateName as nvarchar(30))

							EXEC dbo.AI_InsertQualificationGrade 
							     @QualificationGrade = @CERT_QualificationGrade OUTPUT
								,@QualificationGradeType = @SetupGradeTypeCert
								,@QualificationGradeName = @CertificateName
								,@QualificationGradeAName = @CertificateName
								,@UEnterBy = @LogonName
								,@UChangeBy = @LogonName
								,@UchangeDate = @CurrentDate
								,@UEnterDate   = @CurrentDate;


							select @FieldOfStudyCert= cast(@FieldOfStudyCert as nvarchar(60))

							EXEC dbo.AI_InsertQualificationMajor 
							     @QualificationMajor = @CERT_QualificationMajor OUTPUT
								,@QualificationMajorType = @SetupMajorTypeCert
								,@QualificationMajorName = @FieldOfStudyCert
								,@QualificationMajorAName = @FieldOfStudyCert
								,@UEnterBy = @LogonName
								,@UChangeBy = @LogonName
								,@ReviewedBy = @LogonName
								,@ApprovedBy = @LogonName
								,@UchangeDate = @CurrentDate
								,@UEnterDate   = @CurrentDate;
						


								select @InstitutionCert= cast(@InstitutionCert as nvarchar(60))

								EXEC [dbo].[AI_InsertEstablishment]
								    @Establishment = @CERT_Establishment OUTPUT
									,@EstablishmentName = @InstitutionCert
									,@EstablishmentAName = @InstitutionCert
									,@EstablishmentType = @SetupEstablishmentTypeCert
									,@UEnterBy = @LogonName
									,@UChangeBy = @LogonName
									,@ReviewedBy = @LogonName
									,@ApprovedBy = @LogonName
									,@UchangeDate = @CurrentDate
									,@UEnterDate   = @CurrentDate;

				---- IMPORTANT: same Training rule
				--IF @CERT_QualificationGrade IS NULL SET @CERT_QualificationGrade = 0;
				--IF @CERT_QualificationMajor IS NULL SET @CERT_QualificationMajor = 0;
				--IF @CERT_Establishment IS NULL SET @CERT_Establishment = 0;

				select @CertificateDetails = COALESCE(@CertificateDetails, '');

				      IF EXISTS(
								SELECT * 
								FROM EmpQualification 
								WHERE EmpId = @ApplicantId
								  AND QualificationNo = @CertificatesNo
								  AND AttendFromDate =@StartYearCert
								  --AND isnull(QualificationGrade,0) = isnull(@CERT_QualificationGrade,0)
								  --AND isnull(QualificationMajor,0) = isnull(@CERT_QualificationMajor,0)
								  --  and isnull(Establishment,0)=isnull(@CERT_Establishment,0)
        )
        BEGIN
            select @updateCert = 1; -- UPDATE
            
            -- UPDATE ONLY DATES
            UPDATE EmpQualification
            SET 
                AttendToDate = COALESCE(@EndYearCert, AttendToDate),
                QualificationApprovedDate = COALESCE(@YearCompletedCert, QualificationApprovedDate),
				QualificationGrade =COALESCE( @CERT_QualificationGrade, QualificationGrade),
                QualificationMajor = COALESCE(@CERT_QualificationMajor ,QualificationMajor),
				Establishment=COALESCE(@CERT_Establishment,Establishment),
               QualificationInfo =COALESCE( @CertificateDetails , QualificationInfo)
            WHERE EmpId = @ApplicantId
              AND QualificationNo = @CertificatesNo
			    AND AttendFromDate =@StartYearCert

     --         AND QualificationGrade = @CERT_QualificationGrade
     --         AND QualificationMajor = @CERT_QualificationMajor
			  --AND Establishment =@CERT_Establishment;
        END
        ELSE
        BEGIN
            SET @updateCert = 0; -- INSERT


				EXEC dbo.AI_InsertEmpQualification
					@EmpId = @ApplicantId,
					@QualificationNo = @CertificatesNo,
					@AttendFromDate = @StartYearCert,
					@AttendToDate = @EndYearCert,
					@QualificationScore = 0,
					@QualificationTotalScore = 0,
					@QualificationApprovedDate = @YearCompletedCert,
					@QualificationInfo = @CertificateDetails,
					@QualificationSalary = 0.000,
					@QualificationBenefit = 0.000,
					@LicenseNo = N'',
					@Establishment = @CERT_Establishment,
					@QualificationGrade = @CERT_QualificationGrade,
					@QualificationMajor = @CERT_QualificationMajor;
		END
		select @MinuteOffset = @MinuteOffset+1
				FETCH NEXT FROM certificate_cursor INTO
					@CertificateName,
					@FieldOfStudyCert,
					@InstitutionCert,
					@StartYearCert,
					@EndYearCert,
					@GradeCert,
					@CertificateDetails,
					@YearCompletedCert;
			END

			CLOSE certificate_cursor;
			DEALLOCATE certificate_cursor;
END
END TRY
BEGIN CATCH
    -- Log certificates error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
		 SET @AllErrors = @AllErrors + 'Certificates: ' + @ErrorMessage + CHAR(13) + CHAR(10);
    --RAISERROR ('Error processing Certificates section: %s', 10, 1, @ErrorMessage);
END CATCH

-- ===============================================
-- END CERTIFICATES
-- ===============================================
	-- ===============================================
-- PROJECTS
-- ===============================================
BEGIN TRY
IF @ProjectsQuery IS NOT NULL
   AND EXISTS (SELECT 1 FROM OPENJSON(@ProjectsQuery))
		BEGIN
			DECLARE
				@ProjectName NVARCHAR(200),
				@Technologies NVARCHAR(MAX),
				@TechnologiesString NVARCHAR(MAX),
				@ProjectDescription NVARCHAR(MAX),
				@updateProjects INT;

			DECLARE
				@PR_QualificationGrade SMALLINT,
				@PR_QualificationMajor SMALLINT,
				@PR_Establishment SMALLINT;

			-- Get setup types for PROJECT qualification
			DECLARE
				@SetupEstablishmentTypePr INT,
				@SetupGradeTypePr INT,
				@SetupMajorTypePr INT;

			SELECT
				@SetupEstablishmentTypePr = EstablishmentFromType,
				@SetupGradeTypePr = GradeFromType,
				@SetupMajorTypePr = MajorFromType
			FROM Qualification
			WHERE QualificationNo = @ProjectsNo;

			 DECLARE @PR_AttendFromDate SMALLDATETIME
			 select @MinuteOffset = 0
			DECLARE project_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT
					JSON_VALUE(value,'$.Name'),
					JSON_QUERY(value,'$.Technologies'),
					JSON_VALUE(value,'$.TechnologiesString'),
					JSON_VALUE(value,'$.Description')
				FROM OPENJSON(@ProjectsQuery);
			OPEN project_cursor;
			FETCH NEXT FROM project_cursor INTO
				@ProjectName,
				@Technologies,
				@TechnologiesString,
				@ProjectDescription;

			WHILE @@FETCH_STATUS = 0
			BEGIN
			
				--select   @PR_AttendFromDate = DATEADD( Day, @MinuteOffset, @date )
				SELECT @PR_AttendFromDate = ISNULL( DATEADD(DAY, 1, MAX(AttendFromDate)), @date  )
												FROM EmpQualification
												WHERE EmpId = @ApplicantId
												  AND QualificationNo = @ProjectsNo;

			

				-- Reset lookup values
				 select @updateProjects = 0;
				select @PR_QualificationGrade = NULL;
				select @PR_QualificationMajor = NULL;
				select @PR_Establishment = NULL;

				-- Lookup Qualification Grade
				SELECT @PR_QualificationGrade = QualificationGrade
				FROM QualificationGrade
				WHERE QualificationGradeName =CAST(LTRIM(RTRIM(@ProjectName)) AS NVARCHAR(30))
				  AND QualificationGradeType = @SetupGradeTypePr;


				  print 'PR_QualificationGrade'
				  print  @PR_QualificationGrade
				-- Lookup Qualification Major
				--SELECT @PR_QualificationMajor = QualificationMajor
				--FROM QualificationMajor
				--WHERE QualificationMajorName = LTRIM(RTRIM(@Technologies))
				--  AND QualificationMajorType = @SetupMajorTypePr;

				-- Lookup Establishment
				--SELECT @PR_Establishment = Establishment
				--FROM Establishment
				--WHERE EstablishmentName = LTRIM(RTRIM(@ProjectName))
				--  AND EstablishmentType = @SetupEstablishmentTypePr;

				---- Set defaults if null
				--IF @PR_QualificationGrade IS NULL SET @PR_QualificationGrade = 0;
				--IF @PR_QualificationMajor IS NULL SET @PR_QualificationMajor = 0;
				--IF @PR_Establishment IS NULL SET @PR_Establishment = 0;

						select @ProjectName= cast(@ProjectName as nvarchar(30))

						EXEC dbo.AI_InsertQualificationGrade 
							 @QualificationGrade = @PR_QualificationGrade OUTPUT
							,@QualificationGradeType = @SetupGradeTypePr
							,@QualificationGradeName = @ProjectName
							,@QualificationGradeAName = @ProjectName
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;

				-- Ensure non-null strings
				select @ProjectDescription = COALESCE(@ProjectDescription, '');
				select @TechnologiesString = COALESCE(@TechnologiesString, '');


				IF EXISTS(
							SELECT * 
							FROM EmpQualification 
							WHERE EmpId = @ApplicantId
							  AND QualificationNo = @ProjectsNo
					 	     AND isnull(QualificationGrade,0) = isnull(@PR_QualificationGrade,0)					  
						)
						BEGIN
										print 'testttttt'	

							-- UPDATE existing project instead of inserting
							UPDATE EmpQualification
							SET 
								QualificationInfo = @ProjectDescription,
								LicenseNo =SUBSTRING(@TechnologiesString, 1, 20)
								WHERE EmpId = @ApplicantId
							  AND QualificationNo = @ProjectsNo
							  AND QualificationGrade = @PR_QualificationGrade
						END
				ELSE
					BEGIN

						    

							--SELECT @PR_AttendFromDate = DATEADD(DAY, 1, ISNULL(MAX(AttendFromDate), GETDATE()))
							--FROM EmpQualification
							--WHERE EmpId = @ApplicantId
							--AND QualificationNo = @ProjectsNo;

							         --SELECT @PR_AttendFromDate = DATEADD(DAY,@MinuteOffset,@date)
									 --DATEADD(DAY, 
										--										ISNULL((SELECT COUNT(*) + 1 
										--												FROM EmpQualification 
										--												WHERE EmpId = @ApplicantId 
										--												  AND QualificationNo = @ProjectsNo), 1), 
										--										CAST(GETDATE() AS SMALLDATETIME));
				---	SELECT @MinuteOffset,@PR_AttendFromDate
					-- Insert Project qualification
						EXEC dbo.AI_InsertEmpQualification
							@EmpId = @ApplicantId,
							@QualificationNo = @ProjectsNo,
							@AttendFromDate = @PR_AttendFromDate,
							@AttendToDate = NULL,
							@QualificationScore = 0,
							@QualificationTotalScore = 0,
							@QualificationApprovedDate = NULL,
							@QualificationInfo = @ProjectDescription,
							@QualificationSalary = 0.000,
							@QualificationBenefit = 0.000,
							@LicenseNo = @TechnologiesString,
							@Establishment = Null,
							@QualificationGrade = @PR_QualificationGrade,
							@QualificationMajor = Null;
					END
					select @MinuteOffset = @MinuteOffset+1
					----SELECT '2',@MinuteOffset,@PR_AttendFromDate
				FETCH NEXT FROM project_cursor INTO
					@ProjectName,
					@Technologies,
					@TechnologiesString,
					@ProjectDescription;
					
			END
			
			CLOSE project_cursor;
			DEALLOCATE project_cursor;
		END
END TRY
BEGIN CATCH
    -- Log projects error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
		 SET @AllErrors = @AllErrors + 'Projects: ' + @ErrorMessage + CHAR(13) + CHAR(10);
    --RAISERROR ('Error processing Projects section: %s', 10, 1, @ErrorMessage);
END CATCH

-- ===============================================
-- END PROJECTS
-- ===============================================

-- ===============================================
-- PERSONAL SKILLS
-- ===============================================
BEGIN TRY
IF @PersonalSkillsQuery IS NOT NULL
		BEGIN

			-- ============================================================
			-- LANGUAGES
			-- QualificationNo = @lanuageNo
			-- ============================================================
			BEGIN TRY
			IF JSON_QUERY(@PersonalSkillsQuery, '$.Languages') IS NOT NULL
			   AND EXISTS (SELECT 1 FROM OPENJSON(@PersonalSkillsQuery, '$.Languages'))
			BEGIN
				DECLARE
					@LanguageName NVARCHAR(200),
					@LanguageLevel NVARCHAR(200);

				DECLARE
					@LG_QualificationGrade SMALLINT,
					@LG_QualificationMajor SMALLINT,
					@LG_Establishment SMALLINT;

				DECLARE
					@SetupEstablishmentTypeLang INT,
					@SetupGradeTypeLang INT,
					@SetupMajorTypeLang INT;

				SELECT
					@SetupEstablishmentTypeLang = EstablishmentFromType,
					@SetupGradeTypeLang = GradeFromType,
					@SetupMajorTypeLang = MajorFromType
				FROM Qualification
				WHERE QualificationNo = @lanuageNo;

				select @MinuteOffset = 0
			DECLARE @AttendFromDateValueLG SMALLDATETIME;

				DECLARE language_cursor CURSOR LOCAL FAST_FORWARD FOR
					SELECT
						JSON_VALUE(value,'$.Language'),
						JSON_VALUE(value,'$.LanguageLevel')
					FROM OPENJSON(@PersonalSkillsQuery, '$.Languages');

				OPEN language_cursor;
				FETCH NEXT FROM language_cursor INTO
					@LanguageName, @LanguageLevel;

				WHILE @@FETCH_STATUS = 0
				BEGIN
			
			--select @AttendFromDateValueLG= DATEADD( Day, @MinuteOffset, @date )
					SELECT @AttendFromDateValueLG = ISNULL( DATEADD(DAY, 1, MAX(AttendFromDate)), @date  )
												FROM EmpQualification
												WHERE EmpId = @ApplicantId
												  AND QualificationNo = @lanuageNo;

					select @LG_QualificationGrade = NULL;
					select @LG_QualificationMajor = NULL;
					select @LG_Establishment = NULL;

					SELECT @LG_QualificationMajor = QualificationMajor
					FROM QualificationMajor
					WHERE QualificationMajorName=CAST(LTRIM(RTRIM(@LanguageName))AS NVARCHAR(60))
						  AND QualificationMajorType = @SetupMajorTypeLang;


					SELECT @LG_QualificationGrade = QualificationGrade
					FROM QualificationGrade
					WHERE QualificationGradeName = CAST(LTRIM(RTRIM(@LanguageLevel))AS NVARCHAR(30))
					  AND QualificationGradeType = @SetupGradeTypeLang;


					  select @LanguageLevel= cast(@LanguageLevel as nvarchar(30))

					EXEC dbo.AI_InsertQualificationGrade
							 @QualificationGrade = @LG_QualificationGrade OUTPUT
							,@QualificationGradeType = @SetupGradeTypeLang
							,@QualificationGradeName = @LanguageLevel
							,@QualificationGradeAName = @LanguageLevel
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;


						select @LanguageName= cast(@LanguageName as nvarchar(60))

						EXEC dbo.AI_InsertQualificationMajor 
						     @QualificationMajor = @LG_QualificationMajor OUTPUT
							,@QualificationMajorType = @SetupMajorTypeLang
							,@QualificationMajorName = @LanguageName
							,@QualificationMajorAName = @LanguageName
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@ReviewedBy = @LogonName
							,@ApprovedBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;

					--IF @LG_QualificationGrade IS NULL SET @LG_QualificationGrade = 0;
					--IF @LG_QualificationMajor IS NULL SET @LG_QualificationMajor = 0;
					--IF @LG_Establishment IS NULL SET @LG_Establishment = 0;

					      -- CHECK if this language already exists for this applicant
			IF NOT EXISTS(
				SELECT * 
				FROM EmpQualification 
				WHERE EmpId = @ApplicantId
					AND QualificationNo = @lanuageNo
					--AND QualificationGrade = @LG_QualificationGrade
					AND isnull(QualificationMajor,0) = isnull(@LG_QualificationMajor,0)
			)
			  BEGIN
					
				--SET @MinuteOffset2 += 1;
				--SET @AttendFromDateValueLG = DATEADD( DAY, @MinuteOffset2, CAST(GETDATE() AS SMALLDATETIME) );
				
					EXEC dbo.AI_InsertEmpQualification
						@EmpId = @ApplicantId,
						@QualificationNo = @lanuageNo,      -- 91
						@AttendFromDate = @AttendFromDateValueLG,
						@AttendToDate = NULL,
						@QualificationScore = 0,
						@QualificationTotalScore = 0,
						@QualificationInfo = '',
						@QualificationSalary = 0,
						@QualificationBenefit = 0,
						@LicenseNo = '',
						@Establishment = null,     
						@QualificationGrade = @LG_QualificationGrade, -- LanguageLevel
						@QualificationMajor = @LG_QualificationMajor;  -- Language

				 END
				 ELSE
					BEGIN
						-- UPDATE ONLY skill level
						UPDATE EmpQualification
						SET QualificationGrade = @LG_QualificationGrade
						WHERE EmpId = @ApplicantId
						  AND QualificationNo = @lanuageNo
						  AND QualificationMajor = @LG_QualificationMajor;
					END
					select @MinuteOffset = @MinuteOffset+1
					FETCH NEXT FROM language_cursor INTO
						@LanguageName, @LanguageLevel;
				END

				CLOSE language_cursor;
				DEALLOCATE language_cursor;
			END
			END TRY
			BEGIN CATCH
				-- Log languages error but continue
				SELECT @ErrorMessage = ERROR_MESSAGE();
				SET @AllErrors = @AllErrors + 'Language: ' + @ErrorMessage + CHAR(13) + CHAR(10);
				 --RAISERROR ('Error processing Language section: %s', 10, 1, @ErrorMessage);
			END CATCH

    -- ============================================================
    -- END LANGUAGES
    -- ============================================================


    -- ============================================================
    -- COMPUTER SKILLS
    -- QualificationNo = @ComputerSkillsNo
    -- ============================================================
    BEGIN TRY
    IF JSON_QUERY(@PersonalSkillsQuery, '$.ComputerSkills') IS NOT NULL
       AND EXISTS (SELECT 1 FROM OPENJSON(@PersonalSkillsQuery, '$.ComputerSkills'))
    BEGIN
        DECLARE
            @SkillName NVARCHAR(200),
            @SkillLevel NVARCHAR(200);

        DECLARE
            @CS_QualificationGrade SMALLINT,
            @CS_QualificationMajor SMALLINT,
            @CS_Establishment SMALLINT;

        DECLARE
            @SetupEstablishmentTypeCS INT,
            @SetupGradeTypeCS INT,
            @SetupMajorTypeCS INT;

        SELECT
            @SetupEstablishmentTypeCS = EstablishmentFromType,
            @SetupGradeTypeCS = GradeFromType,
            @SetupMajorTypeCS = MajorFromType
        FROM Qualification
        WHERE QualificationNo = @ComputerSkillsNo;

		select @MinuteOffset = 0
			DECLARE @AttendFromDateValueCS SMALLDATETIME;
				
				
        DECLARE computer_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT
                JSON_VALUE(value,'$.Skill'),
                JSON_VALUE(value,'$.SkillLevel')
            FROM OPENJSON(@PersonalSkillsQuery, '$.ComputerSkills');

        OPEN computer_cursor;
        FETCH NEXT FROM computer_cursor INTO
            @SkillName, @SkillLevel;

        WHILE @@FETCH_STATUS = 0
        BEGIN
		--select @AttendFromDateValueCS = DATEADD( Day, @MinuteOffset, @date )
		SELECT @AttendFromDateValueCS = ISNULL( DATEADD(DAY, 1, MAX(AttendFromDate)), @date  )
												FROM EmpQualification
												WHERE EmpId = @ApplicantId
												  AND QualificationNo = @ComputerSkillsNo;
            select @CS_QualificationGrade = NULL;
            select @CS_QualificationMajor = NULL;
            select @CS_Establishment = NULL;

            SELECT @CS_QualificationGrade = QualificationGrade
            FROM QualificationGrade
            WHERE QualificationGradeName = CAST( LTRIM(RTRIM(@SkillLevel))AS NVARCHAR(30))
              AND QualificationGradeType = @SetupGradeTypeCS;

			  SELECT @CS_QualificationMajor = QualificationMajor 
		      FROM QualificationMajor
			  WHERE QualificationMajorName = CAST( LTRIM(RTRIM(@SkillName))AS NVARCHAR(60))
					  AND QualificationMajorType = @SetupMajorTypeCS;


				    	select @SkillLevel= cast(@SkillLevel as nvarchar(30))

						EXEC dbo.AI_InsertQualificationGrade 
							@QualificationGrade = @CS_QualificationGrade OUTPUT
							,@QualificationGradeType = @SetupGradeTypeCS
							,@QualificationGradeName = @SkillLevel
							,@QualificationGradeAName = @SkillLevel
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;
					

						select @SkillName= cast(@SkillName as nvarchar(60))

					    EXEC dbo.AI_InsertQualificationMajor 
							     @QualificationMajor = @CS_QualificationMajor OUTPUT
								,@QualificationMajorType = @SetupMajorTypeCS
								,@QualificationMajorName = @SkillName
								,@QualificationMajorAName = @SkillName
								,@UEnterBy = @LogonName
								,@UChangeBy = @LogonName
								,@ReviewedBy = @LogonName
								,@ApprovedBy = @LogonName
								,@UchangeDate = @CurrentDate
								,@UEnterDate   = @CurrentDate;
						


			--SELECT @CS_Establishment = Establishment
			--FROM Establishment
			--WHERE EstablishmentName = LTRIM(RTRIM(@SkillName))
			--	 AND EstablishmentType = @SetupEstablishmentTypeCS;

            --IF @CS_QualificationGrade IS NULL SET @CS_QualificationGrade = 0;
            --IF @CS_QualificationMajor IS NULL SET @CS_QualificationMajor = 0;
            --IF @CS_Establishment IS NULL SET @CS_Establishment = 0;

			 -- CHECK if this computer skill already exists for this applicant
        IF NOT EXISTS(
            SELECT * 
            FROM EmpQualification 
            WHERE EmpId = @ApplicantId
              AND QualificationNo = @ComputerSkillsNo
              --AND QualificationGrade = @CS_QualificationGrade
              AND isnull(QualificationMajor,0) =isnull( @CS_QualificationMajor,0)
        )
        BEGIN

		

            EXEC dbo.AI_InsertEmpQualification
                @EmpId = @ApplicantId,
                @QualificationNo = @ComputerSkillsNo,
                @AttendFromDate = @AttendFromDateValueCS,
                @AttendToDate = NULL,
                @QualificationScore = 0,
                @QualificationTotalScore = 0,
                @QualificationInfo = N'',
                @QualificationSalary = 0.000,
                @QualificationBenefit = 0.000,
                @LicenseNo = N'',
                @Establishment = null,
                @QualificationGrade = @CS_QualificationGrade,
                @QualificationMajor = @CS_QualificationMajor;
	  END
	  ELSE
			BEGIN
				-- UPDATE ONLY skill level
				UPDATE EmpQualification
				SET QualificationGrade = @CS_QualificationGrade
				WHERE EmpId = @ApplicantId
				  AND QualificationNo = @ComputerSkillsNo
				  AND QualificationMajor = @CS_QualificationMajor;
			END
			select @MinuteOffset = @MinuteOffset+1
            FETCH NEXT FROM computer_cursor INTO
                @SkillName, @SkillLevel;
        END

        CLOSE computer_cursor;
        DEALLOCATE computer_cursor;
    END
    END TRY
    BEGIN CATCH
        -- Log computer skills error but continue
        SELECT @ErrorMessage = ERROR_MESSAGE();
		 SET @AllErrors = @AllErrors + 'computer skills: ' + @ErrorMessage + CHAR(13) + CHAR(10);
		 --RAISERROR ('Error processing computer skills section: %s', 10, 1, @ErrorMessage);
    END CATCH

    -- ============================================================
    -- END COMPUTER SKILLS
    -- ============================================================


    -- ============================================================
    -- JOB RELATED SKILLS
    -- QualificationNo = @JobRelatedSkillsNo
    -- ============================================================

  -- =========================
-- Process JobRelatedSkills
-- =========================
-- =========================
-- Process JobRelatedSkills
-- =========================
BEGIN TRY
IF JSON_QUERY(@PersonalSkillsQuery, '$.JobRelatedSkills') IS NOT NULL
   AND EXISTS (SELECT 1 FROM OPENJSON(@PersonalSkillsQuery, '$.JobRelatedSkills'))
		BEGIN
			DECLARE
				@JobSkill NVARCHAR(200),
				@JobSkillLevel NVARCHAR(200),
				@JR_QualificationGrade SMALLINT,
				@JR_QualificationMajor SMALLINT,
				@JR_Establishment SMALLINT,
				@SetupEstablishmentTypeJR INT,
				@SetupGradeTypeJR INT,
				@SetupMajorTypeJR INT,
				@AttendFromDateValueJR SMALLDATETIME;

				select @MinuteOffset = 0
			--DECLARE @MinuteOffset4 INT = 0;


			-- Get setup types from Qualification table
			SELECT
				@SetupEstablishmentTypeJR = EstablishmentFromType,
				@SetupGradeTypeJR = GradeFromType,
				@SetupMajorTypeJR = MajorFromType
			FROM Qualification
			WHERE QualificationNo = @JobRelatedSkillsNo;


			-- Cursor to iterate over JobRelatedSkills from JSON
			DECLARE job_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT
					JSON_VALUE(value,'$.Skill'),
					JSON_VALUE(value,'$.SkillLevel')
				FROM OPENJSON(@PersonalSkillsQuery, '$.JobRelatedSkills');

			OPEN job_cursor;
			FETCH NEXT FROM job_cursor INTO @JobSkill, @JobSkillLevel;

			WHILE @@FETCH_STATUS = 0
			BEGIN
			--	select @AttendFromDateValueJR = DATEADD( Day, @MinuteOffset, @date )
					SELECT @AttendFromDateValueJR = ISNULL( DATEADD(DAY, 1, MAX(AttendFromDate)), @date  )
												FROM EmpQualification
												WHERE EmpId = @ApplicantId
												  AND QualificationNo = @JobRelatedSkillsNo;
				-- Reset variables for each skill
				select @JR_QualificationGrade = NULL;
				select @JR_QualificationMajor = NULL;
				select @JR_Establishment = NULL;

				-- Lookup QualificationGrade
				SELECT @JR_QualificationGrade = QualificationGrade
				FROM QualificationGrade
				WHERE QualificationGradeName = CAST( LTRIM(RTRIM(@JobSkillLevel))AS NVARCHAR(30))
				  AND QualificationGradeType = @SetupGradeTypeJR;

				-- Lookup Establishment (skill level)
				--SELECT @JR_Establishment = Establishment
				--FROM Establishment
				--WHERE EstablishmentName = LTRIM(RTRIM(@JobSkill))
				--  AND EstablishmentType = @SetupEstablishmentTypeJR;

				SELECT @JR_QualificationMajor = QualificationMajor
				FROM QualificationMajor
				WHERE QualificationMajorName = CAST( LTRIM(RTRIM(@JobSkill))AS NVARCHAR(60))
				  AND QualificationMajorType = @SetupMajorTypeJR;


				  	select @JobSkillLevel= cast(@JobSkillLevel as nvarchar(30))

						EXEC dbo.AI_InsertQualificationGrade 
							     @QualificationGrade = @JR_QualificationGrade OUTPUT
								,@QualificationGradeType = @SetupGradeTypeJR
								,@QualificationGradeName = @JobSkillLevel
								,@QualificationGradeAName = @JobSkillLevel
								,@UEnterBy = @LogonName
								,@UChangeBy = @LogonName
								,@UchangeDate = @CurrentDate
								,@UEnterDate   = @CurrentDate;

						select @JobSkill= cast(@JobSkill as nvarchar(60))

						EXEC dbo.AI_InsertQualificationMajor
						     @QualificationMajor = @JR_QualificationMajor OUTPUT
							,@QualificationMajorType = @SetupMajorTypeJR
							,@QualificationMajorName = @JobSkill
							,@QualificationMajorAName = @JobSkill
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@ReviewedBy = @LogonName
							,@ApprovedBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;
					
			  -- CHECK if this job skill already exists for this applicant
		IF NOT EXISTS(
			SELECT * 
			FROM EmpQualification 
			WHERE EmpId = @ApplicantId
				AND QualificationNo = @JobRelatedSkillsNo
				--AND QualificationGrade = @JR_QualificationGrade
				AND isnull(QualificationMajor,0) = isnull(@JR_QualificationMajor,0)
		)
        BEGIN

				-- Default values if NULL
				--IF @JR_QualificationGrade IS NULL SET @JR_QualificationGrade = 0;
				--IF @JR_QualificationMajor IS NULL SET @JR_QualificationMajor = 0;
				--IF @JR_Establishment IS NULL SET @JR_Establishment = 0;
			--SET @MinuteOffset4 += 1;
			--SET @AttendFromDateValueJR = DATEADD( DAY, @MinuteOffset4, CAST(GETDATE() AS SMALLDATETIME) );
		
				-- Insert into EmpQualification
				EXEC dbo.AI_InsertEmpQualification
					@EmpId = @ApplicantId,
					@QualificationNo = @JobRelatedSkillsNo,
					@AttendFromDate = @AttendFromDateValueJR,
					@AttendToDate = NULL,
					@QualificationScore = 0,
					@QualificationTotalScore = 0,
					@QualificationInfo = @JobSkill,
					@QualificationSalary = 0.000,
					@QualificationBenefit = 0.000,
					@LicenseNo = N'',
					@Establishment = null,
					@QualificationGrade = @JR_QualificationGrade,
					@QualificationMajor = @JR_QualificationMajor;
			End
			ELSE
				BEGIN
					-- UPDATE ONLY skill level
					UPDATE EmpQualification
					SET QualificationGrade = @JR_QualificationGrade
					WHERE EmpId = @ApplicantId
					  AND QualificationNo = @JobRelatedSkillsNo
					  AND QualificationMajor = @JR_QualificationMajor;
				END
				select @MinuteOffset = @MinuteOffset+1
				FETCH NEXT FROM job_cursor INTO @JobSkill, @JobSkillLevel;
			END

    CLOSE job_cursor;
    DEALLOCATE job_cursor;
END
END TRY
BEGIN CATCH
    -- Log job related skills error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
	 SET @AllErrors = @AllErrors + 'job related skills: ' + @ErrorMessage + CHAR(13) + CHAR(10);
	--RAISERROR ('Error processing job related skills section: %s', 10, 1, @ErrorMessage);
END CATCH

    -- ============================================================
    -- END JOB RELATED SKILLS
    -- ============================================================


    -- ============================================================
    -- DIGITAL SKILLS
    -- QualificationNo = @DigitalSkillsNo
    -- ============================================================
   BEGIN TRY
   IF JSON_QUERY(@PersonalSkillsQuery, '$.DigitalSkills') IS NOT NULL
   AND EXISTS (SELECT 1 FROM OPENJSON(@PersonalSkillsQuery, '$.DigitalSkills'))
		BEGIN
			DECLARE
				@SkillNameDS NVARCHAR(200),
				@SkillLevelDS NVARCHAR(200);

			DECLARE
				@DS_QualificationGrade SMALLINT,
				@DS_QualificationMajor SMALLINT,
				@DS_Establishment SMALLINT;
				DECLARE @AttendFromDateValueDS SMALLDATETIME;
			DECLARE
				@SetupEstablishmentTypeDS INT,
				@SetupGradeTypeDS INT,
				@SetupMajorTypeDS INT;

			SELECT
				@SetupEstablishmentTypeDS = EstablishmentFromType,
				@SetupGradeTypeDS = GradeFromType,
				@SetupMajorTypeDS = MajorFromType
			FROM Qualification
			WHERE QualificationNo = @DigitalSkillsNo;

			select @MinuteOffset = 0
			--DECLARE @MinuteOffset5 INT = 0;

			DECLARE digital_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT
					JSON_VALUE(value,'$.Skill'),
					JSON_VALUE(value,'$.SkillLevel')
				FROM OPENJSON(@PersonalSkillsQuery, '$.DigitalSkills');

			OPEN digital_cursor;
			FETCH NEXT FROM digital_cursor INTO
				@SkillNameDS, @SkillLevelDS;

			WHILE @@FETCH_STATUS = 0
			BEGIN
			
			--	select @AttendFromDateValueDS = DATEADD( Day, @MinuteOffset, @date )
					SELECT @AttendFromDateValueDS = ISNULL( DATEADD(DAY, 1, MAX(AttendFromDate)), @date  )
												FROM EmpQualification
												WHERE EmpId = @ApplicantId
												  AND QualificationNo = @DigitalSkillsNo;
				select @DS_QualificationGrade = NULL;
				select @DS_QualificationMajor = NULL;
				select @DS_Establishment = NULL;

				SELECT @DS_QualificationGrade = QualificationGrade
				FROM QualificationGrade
				WHERE QualificationGradeName = CAST( LTRIM(RTRIM(@SkillLevelDS))AS NVARCHAR(30))
				  AND QualificationGradeType = @SetupGradeTypeDS;

	
				SELECT @DS_QualificationMajor = QualificationMajor
					   FROM QualificationMajor
					   WHERE QualificationMajorName = CAST( LTRIM(RTRIM(@SkillNameDS))AS NVARCHAR(60))
					     AND QualificationMajorType = @SetupMajorTypeDS;

					select @SkillLevelDS= cast(@SkillLevelDS as nvarchar(30))

					EXEC dbo.AI_InsertQualificationGrade
						     @QualificationGrade = @DS_QualificationGrade OUTPUT
							,@QualificationGradeType = @SetupGradeTypeDS
							,@QualificationGradeName = @SkillLevelDS
							,@QualificationGradeAName = @SkillLevelDS
							,@UEnterBy = @LogonName
							,@UChangeBy = @LogonName
							,@UchangeDate = @CurrentDate
							,@UEnterDate   = @CurrentDate;

					select @SkillNameDS= cast(@SkillNameDS as nvarchar(60))

					EXEC dbo.AI_InsertQualificationMajor
					    @QualificationMajor = @DS_QualificationMajor OUTPUT
						,@QualificationMajorType = @SetupMajorTypeDS
						,@QualificationMajorName = @SkillNameDS
						,@QualificationMajorAName = @SkillNameDS
						,@UEnterBy = @LogonName
						,@UChangeBy = @LogonName
						,@ReviewedBy = @LogonName
						,@ApprovedBy = @LogonName
						,@UchangeDate = @CurrentDate
						,@UEnterDate   = @CurrentDate;


					 -- CHECK if this digital skill already exists for this applicant
		IF NOT EXISTS(
			SELECT * 
			FROM EmpQualification 
			WHERE EmpId = @ApplicantId
				AND QualificationNo = @DigitalSkillsNo
				--AND QualificationGrade = @DS_QualificationGrade
				AND isnull(QualificationMajor,0) = isnull(@DS_QualificationMajor,0)
		)
        BEGIN

				--SELECT @DS_Establishment = Establishment
				--FROM Establishment
				--WHERE EstablishmentName = LTRIM(RTRIM(@SkillNameDS))
				--  AND EstablishmentType = @SetupEstablishmentTypeDS;

				--IF @DS_QualificationGrade IS NULL SET @DS_QualificationGrade = 0;
				--IF @DS_QualificationMajor IS NULL SET @DS_QualificationMajor = 0;
				--IF @DS_Establishment IS NULL SET @DS_Establishment = 0;
			

				
				--SET @MinuteOffset5 += 1;
				--SET @AttendFromDateValueDS =DATEADD( Day, @MinuteOffset5, CAST(GETDATE() AS date) );

				EXEC dbo.AI_InsertEmpQualification
					@EmpId = @ApplicantId,
					@QualificationNo = @DigitalSkillsNo,
					@AttendFromDate = @AttendFromDateValueDS,
					@AttendToDate = NULL,
					@QualificationScore = 0,
					@QualificationTotalScore = 0,
					@QualificationInfo = N'',
					@QualificationSalary = 0.000,
					@QualificationBenefit = 0.000,
					@LicenseNo = N'',
					@Establishment = null,
					@QualificationGrade = @DS_QualificationGrade,
					@QualificationMajor = @DS_QualificationMajor;
			End
			ELSE
				BEGIN
					-- UPDATE ONLY skill level
					UPDATE EmpQualification
					SET QualificationGrade = @DS_QualificationGrade
					WHERE EmpId = @ApplicantId
					  AND QualificationNo = @DigitalSkillsNo
					  AND QualificationMajor = @DS_QualificationMajor;
				END
				select @MinuteOffset = @MinuteOffset+1
				FETCH NEXT FROM digital_cursor INTO
					@SkillNameDS, @SkillLevelDS;
			END

			CLOSE digital_cursor;
			DEALLOCATE digital_cursor;
END
END TRY
BEGIN CATCH
    -- Log digital skills error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
	 SET @AllErrors = @AllErrors + 'digital skills: ' + @ErrorMessage + CHAR(13) + CHAR(10);
	--RAISERROR ('Error processing digital skills section: %s', 10, 1, @ErrorMessage);
END CATCH

    -- ============================================================
    -- END DIGITAL SKILLS
    -- ============================================================


	--UDF
	--linkedin profiled 
	BEGIN TRY
	EXEC dbo.AI_SaveApplicantUDFs
			@userlogonname = @LogonName,
			@empid = @ApplicantId,
			@fieldno = @udf1	,
			@fieldvalue = @LinkedInProfile;
	END TRY
	BEGIN CATCH
	    SELECT @ErrorMessage = ERROR_MESSAGE();
		SET @AllErrors = @AllErrors + 'LinkedIn: ' + @ErrorMessage + CHAR(13) + CHAR(10);
			--RAISERROR('Error saving LinkedIn: %s', 10, 1, @ErrorMessage);
	END CATCH

	--facbook profike 
   BEGIN TRY
   EXEC dbo.AI_SaveApplicantUDFs
		@userlogonname = @LogonName,
		@empid = @ApplicantId,
		@fieldno = @udf2	,
		@fieldvalue = @FacebookPage;
	END TRY
	BEGIN CATCH
		SELECT @ErrorMessage = ERROR_MESSAGE();
		SET @AllErrors = @AllErrors + 'Facebook: ' + @ErrorMessage + CHAR(13) + CHAR(10);
		--RAISERROR('Error saving Facebook: %s', 10, 1, @ErrorMessage);
	END CATCH


	--OtherSocialLinks
	   BEGIN TRY
	   EXEC dbo.AI_SaveApplicantUDFs
			@userlogonname = @LogonName,
			@empid = @ApplicantId,
			@fieldno = @udf3	,
			@fieldvalue = @OtherSocialLinks;
		END TRY
		BEGIN CATCH
			SELECT @ErrorMessage = ERROR_MESSAGE();
			SET @AllErrors = @AllErrors + 'Other Social Links: ' + @ErrorMessage + CHAR(13) + CHAR(10);
				--RAISERROR('Error saving Other Social Links: %s', 10, 1, @ErrorMessage);
		END CATCH


END
END TRY
BEGIN CATCH
    -- Log personal skills error but continue
    SELECT @ErrorMessage = ERROR_MESSAGE();
	SET @AllErrors = @AllErrors + 'Personal Skill: ' + @ErrorMessage + CHAR(13) + CHAR(10);
   --RAISERROR('Error processing Personal Skills section: %s', 10, 1, @ErrorMessage);
END CATCH

-- ===============================================
-- END PERSONAL SKILLS
-- ===============================================

        END
    END TRY
    BEGIN CATCH
        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();
        SET @AllErrors = @AllErrors + @ErrorMessage + CHAR(13) + CHAR(10);
        --RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
        RETURN;
    END CATCH;
END

GO

