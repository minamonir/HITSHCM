CREATE PROCEDURE [dbo].[Audit_CreateHeader] (@AduitType as int , @AduitInformation as nvarchar(max) ,@AuditCode uniqueidentifier OUTPUT)
AS
SET @AuditCode = NEWID()
DECLARE @hitshost_id  as char(8) ,@hitsHOST_NAME as nvarchar(128)

select @hitsHOST_NAME = '' , @hitshost_id = ''
--select @hitsHOST_NAME = HOST_NAME() , @hitshost_id = host_id()

declare @ComputerName as nvarchar(50), @ApplicationName AS nvarchar(128) , 
@UserName AS nvarchar(265) , @UserProfileId as int , @SessionExist as int 
set @SessionExist = 0 
select @SessionExist = count(*) FROM UserAuditSession  
where ApplicationName = APP_NAME() and HostId=@hitshost_id

iF  APP_NAME()='HITSDNA-Mobile' AND @AduitType=4
BEGIN
		SELECT @UserName=LTRIM(RTRIM(@AduitInformation)),@UserProfileId=empid
		,@AduitInformation='Logon',@ApplicationName=APP_NAME()
		,@ComputerName=''
		FROM dbo.NasUsers WHERE LTRIM(RTRIM(LogonName))=LTRIM(RTRIM(@AduitInformation))

		--SELECT @UserName,@UserProfileId,@AduitInformation
END
ELSE
BEGIN
	if @SessionExist >= 1
	BEGIN
		SELECT TOP 1  @ComputerName=ComputerName
		,@ApplicationName=ApplicationName
		,@UserName = UserName
		,@UserProfileId = UserProfileId  
		FROM UserAuditSession 
		where ApplicationName = APP_NAME() and HostId=@hitshost_id
		ORDER BY SessionStart DESC
	END
ELSE
	BEGIN
	   SELECT @ComputerName=@hitsHOST_NAME
	   ,@ApplicationName=APP_NAME()
	   ,@UserName = SUSER_SNAME() 
	   --,@UserProfileId = Null
	END
End

--INSERT INTO aaaudit
--SELECT @ComputerName,APP_NAME(),@hitshost_id,GETDATE(),''

INSERT INTO UserAuditHeader (AuditCode, AuditDate, AuditType, ComputerName, ApplicationName, UserName, UserProfileId, ActionInformation)
SELECT @AuditCode, getdate(), @AduitType, CAST(LTRIM(RTRIM(@ComputerName)) + CASE WHEN @ComputerName='' THEN '' ELSE ' - ' END + HOST_NAME() AS NVARCHAR(50)), @ApplicationName, @UserName, @UserProfileId,@AduitInformation

UPDATE  UserAuditSession
SET lastaccesstime = getdate()  
where ApplicationName = APP_NAME() and HostId=@hitshost_id 
AND SessionStart = (SELECT TOP 1 us2.SessionStart 
					FROM UserAuditSession us2 
					where us2.ApplicationName = APP_NAME() and us2.HostId=@hitshost_id 
					ORDER BY us2.SessionStart DESC)

GO

