CREATE   PROCEDURE [dbo].[Batch_CreateTempTable]  ( @tablename AS nvarchar(150),@tabletype AS nvarchar(max)) 
-- test
AS
DECLARE @lang AS nchar(1)
SET @lang='E'
BEGIN
	DECLARE @str AS nvarchar(max),@updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),@t AS nvarchar(150),
	@selectstr AS nvarchar(max),@hidecolstr AS nvarchar(100)
	DECLARE @outstr AS nvarchar(max)
	
DECLARE @actualtablename AS nvarchar(150)


SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName like cast(@tabletype as VARCHAR(8000))

SET @actualtablename=isnull(@actualtablename,'')

DECLARE @Parameters AS NVARCHAR(90)

Print @tabletype

IF charindex( 'WP_JobRequisitionBatchPosting',ltrim(rtrim(@tabletype)) ) <> 0 
BEGIN
DECLARE @StartIndex2 AS int
DECLARE @budgetno AS NVARCHAR(100)
DECLARE @date AS NVARCHAR(10)
DECLARE @wf AS BIT
DECLARE @where AS NVARCHAR(100) 

IF charindex( 'WP_JobRequisitionBatchPosting_ar',ltrim(rtrim(@tabletype)) ) <> 0 
BEGIN
	SET  @lang='A'
END
ELSE
	BEGIN
		SET  @lang='E'
	END

 

SET @StartIndex2=CHARINDEX(':',@TableType)
SET @TableType=substring (@tabletype,@StartIndex2+1,len(@tabletype)-len(substring(@tabletype,0,@startindex2)))

SET @StartIndex2=CHARINDEX(',',@TableType)
SET @budgetno=substring (@TableType,0,@StartIndex2)

SET @tabletype=substring(@tabletype,@StartIndex2+1,len(@tabletype))
SET @StartIndex2=CHARINDEX(',',@tabletype)
SET @date=substring(@tabletype,0,@StartIndex2)

SET @tabletype=substring(@tabletype,@StartIndex2+1,len(@tabletype))
 SET @wf= @tabletype

 --print ' @tabletype' + @tabletype
SET @where=' and HRBudget.BudgetNo= '+@budgetno+' '
--SELECT 2,@date  , 'G' ,' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  ' ,'           and  1=1 ' ,@where,'E',@tablename,@wf,1
EXEC [Hits_GetBudgetsnew] 2,@date  , 'G' ,' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  ' ,'           and  1=1 ' ,@where,@lang,@tablename,@wf,1
	
END



IF charindex( 'WP_WFVacationManageAll',ltrim(rtrim(@tabletype)) ) <> 0  OR  charindex( 'WP_WFBenefitManageAll',ltrim(rtrim(@tabletype)) ) <> 0
BEGIN

	DECLARE @StartIndex_val AS INT, @RoleProfileid_val as int , @where_val as nvarchar(max) , @ssdoctype_val as smallint , @action_val as nvarchar(10),
	@p_sort_str nvarchar(max),
	@p_page_number int,
	@p_batch_size INT,
	@tabletype_val NVARCHAR(max),
	@tableAction AS SMALLINT

	IF charindex( 'WP_WFVacationManageAll_ar',ltrim(rtrim(@tabletype)) ) <> 0 OR  charindex( 'WP_WFBenefitManageAll_ar',ltrim(rtrim(@tabletype)) ) <> 0
	BEGIN
		SET  @lang='A'
	END
	ELSE
	BEGIN
		SET  @lang='E'
	END

	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @tabletype_val = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @RoleProfileid_val = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @where_val = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))
	
	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @ssdoctype_val = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @action_val = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))
	
	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @p_sort_str = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))
	
	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @p_page_number = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))
	
	SET @StartIndex_val=CHARINDEX('$',@tabletype)
	SET @p_batch_size = substring(@tabletype,0,@StartIndex_val)
	SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

	SET @tableAction = @tabletype

END



IF ltrim(rtrim(@tabletype)) ='WP_JVSetup' OR ltrim(rtrim(@tabletype)) ='WP_JVSetup_ar' EXEC [BatchWP_JVSetup] 3,@tablename ,0,'',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords'  EXEC [BatchWP_GetExternalTimeKeepingRecords] 3,@tablename ,0,'',',E',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords_ar' EXEC [BatchWP_GetExternalTimeKeepingRecords] 3,@tablename ,0,'',',A',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmployees%' EXEC BatchWP_GetExternalEmployees 3,@tablename ,0,'','',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExternalSystemsBatchPosting%' EXEC BatchWP_ExternalSystemsBatchPosting1 3,@tablename ,0,'','',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPayrollfromExternalSystem%' EXEC BatchWP_ExternalSystemsBatchPostingPage1 3,@tablename ,0,'','',0,@outstr OUTPUT
ELSE 
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalApplicants%'  EXEC BatchWP_GetExternalApplicants 3,@tablename ,0,'','',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalAppraisalWMR_ar%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalAppraisalWMR%' 
 EXEC BatchWP_GetExternalAppraisalWMR 3,@tablename ,0,' ','',@tabletype

IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalAppraisalWMR_ar%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalAppraisalWMR%' 
 EXEC BatchWP_GetExternalAppraisalWMR 3,@tablename ,0,' ','',@tabletype
ELSE IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalDataFile%'
BEGIN
	SELECT @tabletype= SUBSTRING(@tabletype, CharIndex('?',@tabletype)+1,len (@tabletype))  
	EXEC BatchWP_GetExternalDataFile 3,@tablename ,0,'',@tabletype,@outstr OUTPUT
end

else
IF ltrim(rtrim(@tabletype))LIKE 'WP_GetExternalPayrollDetails%' EXEC BatchWP_GetExternalPayrollDetails 3,@tablename ,0,' ','',@tabletype,@outstr OUTPUT
ELSE 
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalData' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalData_ar' EXEC BatchWP_getExternalData 3,@tablename ,0,' ',' ',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalVacDueAdjust' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalVacDueAdjust_ar' EXEC BatchWP_GetExternalVacDueAdjust 3,@tablename ,0,' ',' ',@outstr output
ELSE IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimePermission' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalTimePermission_ar' 
EXEC BatchWP_GetExternalTimePerm 3,@tablename ,0,' ',' ',@outstr output

ELSE IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalProfilePhone%'  EXEC BatchWP_GetExternalProfilePhone 3,@tablename ,0,' ',' ',@outstr output

ELSE IF  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalVacRecords_ar%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalVacRecords%' 
EXEC BatchWP_GetExternalVacRecords 3,@tablename ,0,' ',' ',@tabletype ,@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype_val)) = 'WP_WFVacationManageAll' OR ltrim(rtrim(@tabletype_val)) = 'WP_WFVacationManageAll_ar' EXEC hits_GetWFVacActionRequiredWithPagingAll @RoleProfileid_val,@where_val,@ssdoctype_val,@action_val,@p_sort_str,@p_page_number,@p_batch_size,@tablename,@tableAction
ELSE
IF ltrim(rtrim(@tabletype_val)) = 'WP_WFBenefitManageAll' OR ltrim(rtrim(@tabletype_val)) = 'WP_WFBenefitManageAll_ar' EXEC hits_GetWFBenefitActionRequiredWithPagingAll @RoleProfileid_val,@where_val,@ssdoctype_val,@action_val,@p_sort_str,@p_page_number,@p_batch_size,@tablename,@tableAction
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
else
IF ltrim(rtrim(@tabletype)) ='WP_GetCostCenterAllocation' OR ltrim(rtrim(@tabletype)) ='WP_GetCostCenterAllocation_ar' EXEC BatchWP_GetCostCenterAllocation 3,@tablename ,0,' ',' ',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_LoadPaymentData' OR ltrim(rtrim(@tabletype)) ='WP_LoadPaymentData_ar' EXEC BatchWP_LoadPaymentData 3,@tablename ,0,' ',' ',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_ApplyExtFinanceChanges' OR ltrim(rtrim(@tabletype)) ='WP_ApplyExtFinanceChanges_ar' EXEC BatchWP_ApplyExtFinanceChanges 3,@tablename ,0,' ',' ',@outstr output
ELSE	
IF ltrim(rtrim(@tabletype)) ='WP_HrBudgetEntry' EXEC BatchWP_HrBudgetEntry 3,@tablename ,0,' ',',,,,,,E',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_HrBudgetEntry_ar' EXEC BatchWP_HrBudgetEntry 3,@tablename ,0,' ',',,,,,,A',@outstr output
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanCostItems%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanCostItems_ar%' EXEC BatchWP_TrainingPlanCostItems 3,@tablename ,@tabletype,' ',' ',@outstr output
-------------------- 07/03/2016 Get External Objective ---------------------------------

ELSE IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalObjective_ar%' OR ltrim(rtrim(@tabletype)) LIKE  '%WP_GetExternalObjective%' 
EXEC BatchWP_GetExternalObjective 3,@tablename ,0,' ',' ',@outstr OUTPUT

  ------------------------ Get External Additional training
-----------------------------------------------------------------------------------------
ELSE IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalAdditionalEvents_ar%' OR  ltrim(rtrim(@tabletype)) LIKE  '%WP_GetExternalAdditionalEvents%' 
EXEC BatchWP_GetExternalAdditionalTraining 3,@tablename ,0,' ',' ',@outstr OUTPUT


-------------------------------------------------------------
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingNeedsCollection%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingNeedsCollection_ar%' EXEC BatchWP_TrainingNeedsCollection 3,@tablename ,' ',@tabletype,@outstr OUTPUT
ELSE 
IF  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalProfileUserDefinedFields%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalProfileUserDefinedFields_ar%' EXEC BatchWP_GetExternalProfileUserDefinedFields 3,@tablename,@tabletype,@outstr OUTPUT
ELSE	
IF ltrim(rtrim(@tabletype)) ='WP_AssignSelfServiceGroups' EXEC [BatchWP_AssignRole] 3,@tablename ,0,'','E, ',@outstr output
ELSE 
IF ltrim(rtrim(@tabletype)) ='WP_AssignSelfServiceGroups_ar' EXEC [BatchWP_AssignRole] 3,@tablename ,0,' ','A, ',@outstr output	
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanActivities%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_TrainingPlanActivities_ar%' EXEC BatchWP_TrainingPlanActivities 3, @tablename ,@tabletype,' ',' ',@outstr OUTPUT

ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_PostTrainingPlanActivitytoTrainingEvent%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_PostTrainingPlanActivitytoTrainingEvent_ar%' EXEC BatchWP_GetTrainingPlanActivitiesasEvent 3, @tablename ,@tabletype,' ',' ',@outstr output

ELSE	
IF ltrim(rtrim(@tabletype)) ='WP_GetPayrollDataFromExternalSystem' OR ltrim(rtrim(@tabletype)) ='WP_GetPayrollDataFromExternalSystem_ar' EXEC BatchWP_getPayrollDataFromExternalSystem 3,@tablename ,0,' ',' ',@outstr output
ELSE

IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmpShift_ar'  EXEC BatchWP_GetExternalEmpShift 3,@tablename , 0 ,' ','A',@outstr output
ELSE

IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmpShift'  EXEC BatchWP_GetExternalEmpShift 3,@tablename , 0 ,' ','E',@outstr output
ELSE

--IF ltrim(rtrim(@tabletype)) ='WP_GetExternalChangeOfStatus' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalChangeOfStatus_ar' EXEC BatchWP_getExternalChangeOfStatus 3,@tablename ,0,' ',' ',@outstr output
IF ltrim(rtrim(@tabletype))LIKE 'WP_GetExternalChangeOfStatus%' EXEC BatchWP_getExternalChangeOfStatus 3,@tablename ,0,' ',' ',@tabletype,@outstr output

--ELSE
--IF ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems_ar' EXEC BatchWP_getExternalBenefitItems 3,@tablename ,0,' ',' ',@outstr OUTPUT

ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems' EXEC BatchWP_getExternalBenefitItems 3,@tablename ,0,'','E, ',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems_ar' EXEC BatchWP_getExternalBenefitItems 3,@tablename ,0,' ','A, ',@outstr OUTPUT
ELSE
-----WP_GetExternalBenefitItems

---BatchWP_GetExternalNassUsers -------

IF ltrim(rtrim(@tabletype)) = 'WP_GetExternalNasUsers' EXEC BatchWP_GetExternalNassUsers 3,@tablename ,0,' ','E',@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) = 'WP_GetExternalNasUsers_ar' EXEC BatchWP_GetExternalNassUsers 3,@tablename ,0,' ','A',@outstr OUTPUT
---BatchWP_GetExternalNassUsers -------

ELSE
IF  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalMisconduct_ar%' EXEC BatchWP_getExternalMisconduct 3,@tablename ,0,' ','A, ',@tabletype,@outstr OUTPUT
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalMisconduct%' EXEC BatchWP_getExternalMisconduct 3,@tablename ,0,'','E, ',@tabletype,@outstr OUTPUT



ELSE
	IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalBenefitPlan%' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitPlan_ar%'  EXEC BatchWP_GetExternalBenefitPlan 3,@tablename ,0,@tabletype,' ',' ',@outstr OUTPUT
    
------
--saeed
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalHistoryPaycodes_ar%'  EXEC BatchWP_getExternalHistoryPaycodes 3,@tablename ,0,' ','A',@tabletype,@outstr output
ELSE	
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalHistoryPaycodes%'  EXEC BatchWP_getExternalHistoryPaycodes 3,@tablename ,0,' ','E',@tabletype,@outstr output
else
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPaycodes_ar%' EXEC BatchWP_GetExternalPaycodes 3,@tablename ,0,' ','A',@tabletype,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPaycodes%' EXEC BatchWP_GetExternalPaycodes 3,@tablename ,0,' ','E',@tabletype,@outstr OUTPUT

else
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmpSSGroupRoles_ar%' EXEC BatchWP_GetExternalEmpSSGroupRoles 3,@tablename ,0,' ','A',@tabletype,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalEmpSSGroupRoles%' EXEC BatchWP_GetExternalEmpSSGroupRoles 3,@tablename ,0,' ','E',@tabletype,@outstr OUTPUT


-----------------------------------------------
---------------WP_GetExternalCompetencies------------
ELSE
IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalCompetencies_ar%' OR  LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalCompetencies%'
EXEC BatchWP_GetExternalCompetencies 3,@tablename ,0,' ',' ',@outstr OUTPUT

--------
ELSE IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalHousingItems_ar%' OR LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalHousingItems%' 
EXEC BatchWP_GetExternalHousingItems 3,@tablename ,0,' ',' ' ,@tabletype ,@outstr OUTPUT

 

-------------------------------------	
-------WP_GetExternalDocuments-------
ELSE IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalDocuments_ar%' OR LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalDocuments%' 
EXEC BatchWP_GetExternalDocuments 3,@tablename ,0,' ',' ' ,@tabletype ,@outstr OUTPUT

 

------------------------------------
--------------------Get External Training
ELSE IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalevents_ar%' OR LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalevents%' 
EXEC BatchWP_GetExternalevents 3,@tablename ,0,' ',' ' ,@tabletype ,@outstr OUTPUT

----------------------------------------------------------
-------------------- 27/09/2016 Export Salary Scale Benefits ---------------------------------

ELSE IF ltrim(rtrim(@tabletype)) LIKE '%WP_ExportBenefitSalaryScales_ar%' OR ltrim(rtrim(@tabletype)) LIKE  '%WP_ExportBenefitSalaryScales%' 
EXEC BatchWP_ExportBenefitSalaryScales 3,@tablename ,0,' ',' ',@tabletype,@outstr OUTPUT

-------------------------------------------------------------- 
-------------------- Export Salary Scale Details ---------------------------------

ELSE IF ltrim(rtrim(@tabletype)) LIKE '%WP_ExportSalaryScalesDetails_ar%' OR ltrim(rtrim(@tabletype)) LIKE  '%WP_ExportSalaryScalesDetails%' 
EXEC dbo.BatchWP_ExportSalaryScalesDetails 3,@tablename ,0,' ',' ',@tabletype,@outstr OUTPUT
-----------------------------------------------------------------	
ELSE 
IF charindex( 'Pay_GetWithPaging',ltrim(rtrim(@tabletype)) ) <> 0 EXEC BatchWP_Pay_GetWithPaging @tablename,@tabletype,'Create'
ELSE 
 
----------------------------------------------------------------------
-------------------- Get External HR Request -----------------------------
IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalHRRequests%'
BEGIN 

EXEC BatchWP_GetExternalHRRequests 3,@tablename ,0,'','',@tabletype ,@outstr OUTPUT


END 
ELSE 
 
----------------------------------------------------------------------
-------------------- Get External Tasks -----------------------------
IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalTasks%'
BEGIN 

EXEC BatchWP_GetExternalTasks 3,@tablename ,0,'','',@tabletype ,@outstr OUTPUT

END 
----------------------------------------------------------------------
----------------------------------------------------------------------
ELSE 
-------------------------------------------- TailorAssessment -------------------------------------------------
IF ltrim(rtrim(@tabletype)) ='WP_TailorAssessment' EXEC BatchWP_TailorAssessment 3,@tablename ,0,'','E, ',@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_TailorAssessment' EXEC BatchWP_TailorAssessment 3,@tablename ,0,' ','A, ',@outstr OUTPUT
---------------------------------------------------------------------------------------------------------------
ELSE
IF charindex( 'WP_DeployReports',ltrim(rtrim(@tabletype)) ) <> 0 EXEC dbo.BatchWP_DeployReports @tablename,@tabletype

ELSE
IF charindex( 'Pay_GetTerminateEmp',ltrim(rtrim(@tabletype)) ) <> 0 
  BEGIN 
  	  --DECLARE @DisabledColStr1 AS nvarchar(100)
  	  DECLARE @TableNamelen1 AS int 
      SET @TableNamelen1=len(@TableName)-charindex('[nasbatch',@TableName)-1
--       SET @selectstr ='IF not EXISTS(SELECT top 1 1
--		    FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
--		    WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
--      +'  BEGIN CREATE TABLE ' + @tablename+ '(Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY, NonWorkingDaysTxt int,BalanceTillTermDateTxt NUMERIC (18,3), Sel bit, EmployeeId nvarchar(50) collate database_default ,Name nchar(88) collate database_default ,AName nchar(88) collate database_default, TermDate datetime 
--,PayOrganization int , NonWorkingDays int, BalanceTillTermDate NUMERIC (18,3) ,EmpId int , GradeName nchar(60) collate database_default,GradeAName nchar(60) collate database_default
--,OrganizationName nchar(60) collate database_default, OrganizationAName nchar(60) collate database_default,JobName nchar(60) collate database_default,JobAName nchar(60) collate database_default
--,HrStatusName nchar(60) collate database_default,HrStatusAName nchar(60) collate database_default,LocationName nchar(60) collate database_default,LocationAName nchar(60) collate database_default,ProcessTime datetime ,Processed nvarchar(max) collate database_default)  
--insert into ' +   @tablename 
--+'(Sel,EmployeeId,Name,AName,TermDate,h_TermDate,PayOrganization,NonWorkingDays,BalanceTillTermDate,EmpId,GradeName,GradeAName,OrganizationName,OrganizationAName
--,JobName,JobAName,HrStatusName,HrStatusAName,LocationName,LocationAName)  exec ' + @tabletype+' 
-- Update '+@tablename+' set NonWorkingDaysTxt=NonWorkingDays ,BalanceTillTermDateTxt=BalanceTillTermDate END '
--  PRINT (@selectstr)
--       exec sp_executesql @selectstr
       
   SET @selectstr ='IF not EXISTS(SELECT top 1 1
		    FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
		    WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'  BEGIN CREATE TABLE ' + @tablename+ '(Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY
       , Sel bit
       ,EmpId int
       ,EmployeeId nvarchar(50) collate database_default 
       ,Name nchar(88) collate database_default 
       ,AName nchar(88) collate database_default 
       ,GradeName nvarchar(250) collate database_default
       ,GradeAName nvarchar(250) collate database_default
       ,PayOrganization smallint 
       ,OrganizationName nvarchar(250) collate database_default
       ,OrganizationAName nvarchar(250) collate database_default
       ,JobName nvarchar(250) collate database_default
       ,JobAName nvarchar(250) collate database_default
       ,HrStatusName nchar(60) collate database_default
       ,HrStatusAName nchar(60) collate database_default
       ,LocationName nvarchar(250) collate database_default
       ,LocationAName nvarchar(250) collate database_default
       ,TermDate smalldatetime 
       ,NonWorkingDays smallint
       ,BalanceTillTermDate NUMERIC (18,3) 
       ,ProcessTime datetime 
       ,Processed nvarchar(max) collate database_default)  
        insert into ' +   @tablename 
+'(Sel,EmployeeId,Name,AName,TermDate,PayOrganization,NonWorkingDays,BalanceTillTermDate,EmpId,GradeName,GradeAName,OrganizationName,OrganizationAName
,JobName,JobAName,HrStatusName,HrStatusAName,LocationName,LocationAName)  exec ' + @tabletype +' END '

exec sp_executesql @selectstr     

  END
ELSE
IF CHARINDEX('WFActionAll',ltrim(rtrim(@tabletype)) ) <> 0 
BEGIN
		SET @selectstr='   CREATE TABLE ' + @tablename + ' (Row_Number [INT] IDENTITY(1,1) NOT NULL, 
		[EmpId] [INT] NOT NULL,
		[DocumentNo] [INT],
		[SSDocNo] [SMALLINT]
		,ProcessTime datetime ,ProcessMsg nvarchar(max),ErrorCode int
		) Alter Table '+@tablename+' Add Primary Key (Row_Number )'
		exec sp_executesql @selectstr
END

ELSE
IF CHARINDEX('MCApprovals',ltrim(rtrim(@tabletype)) ) <> 0 
BEGIN
		SET @selectstr='   CREATE TABLE ' + @tablename + ' (Row_Number [INT] IDENTITY(1,1) NOT NULL, 
		[EmpId] [INT] NOT NULL,
		[EmployeeID] nvarchar(50) ,
		[Name] nvarchar(88),
		[AName] nvarchar(88),
		[MCDocNo] [INT],
		[MCID] UNIQUEIDENTIFIER  NULL,
		[MakerAction] smallint  NULL,
		[RunNo] SMALLINT NOT NULL ,
		[Paycode] SMALLINT NOT NULL,
		[InputAmnt] numeric (18, 3) NOT NULL,
		[Organization] smallint,
		[OrganizationName] nvarchar(250),
		[OrganizationAName] nvarchar(250),
		[job] smallint,
		[JobName] nvarchar(250),
		[JobAName] nvarchar(250),
		[HrStatus] smallint,
		[HrstatusName] nvarchar(60),
		[HrstatusAName] nvarchar(60),
		[CheckedItemName] nvarchar(60),
		[CheckedItemAName] nvarchar(60),
		processtime datetime ,processed nvarchar(max)
		) Alter Table '+@tablename+' Add Primary Key (Row_Number )'
		exec sp_executesql @selectstr
END

ELSE
IF charindex( 'Pay_GetNewHired',ltrim(rtrim(@tabletype)) ) <> 0 
  BEGIN 
  	  DECLARE @DisabledColStr AS nvarchar(100)
  	  DECLARE @TableNamelen AS int 
      SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
       SET @selectstr ='IF not EXISTS(SELECT top 1 1
		    FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
		    WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'  BEGIN CREATE TABLE ' + @tablename+ '(Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY, HireDaysTxt numeric(18,3), Sel bit, EmployeeId nvarchar(50) collate database_default ,Name nchar(88) collate database_default ,AName nchar(88) collate database_default,Center int , HireDate datetime 
,h_HireDate nchar(10) collate database_default,PayOrganization int , HireDays numeric(18,3) ,EmpId int , GradeName nvarchar(250) collate database_default,GradeAName nvarchar(250) collate database_default
,OrganizationName nvarchar(250) collate database_default, OrganizationAName nvarchar(250) collate database_default,JobName nvarchar(250) collate database_default,JobAName nvarchar(250) collate database_default
,HrStatusName nchar(60) collate database_default,HrStatusAName nchar(60) collate database_default,LocationName nvarchar(250) collate database_default,LocationAName nvarchar(250) collate database_default,ProcessTime datetime ,Processed nvarchar(max) collate database_default)  
insert into ' +   @tablename 
+'(Sel,EmployeeId,Name,AName,Center,HireDate,h_HireDate,PayOrganization,HireDays,EmpId,GradeName,GradeAName,OrganizationName,OrganizationAName
,JobName,JobAName,HrStatusName,HrStatusAName,LocationName,LocationAName)  exec ' + @tabletype+' 
 Update '+@tablename+' set HireDaysTxt=HireDays END '

       exec sp_executesql @selectstr
  END
  
  ELSE
  	IF charindex( 'Pay_GetProratedChanges',ltrim(rtrim(@tabletype)) ) <> 0 
  	BEGIN
  	  --DECLARE @DisabledColStr AS nvarchar(100)
  	  --DECLARE @TableNamelen AS int 
      SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
       SET @selectstr ='IF not EXISTS(SELECT top 1 1
		    FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
		    WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'  BEGIN CREATE TABLE ' + @tablename+ '(Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY, empid int, EmployeeId nvarchar(50) collate database_default,Name nchar(88) collate database_default ,AName nchar(88) collate database_default,
      InputAmnt numeric(18,3) , amount numeric(18,3),paycode int, pay_name nchar(60) collate database_default,pay_aname nchar(60) collate database_default, Act_InputAmnt numeric(18,3), Post bit,
      HrStatusName nchar(60) collate database_default,HrStatusAName nchar(60) collate database_default,JobName nvarchar(250) collate database_default,JobAName nvarchar(250) collate database_default,
      OrganizationName nvarchar(250) collate database_default, OrganizationAName nvarchar(250) collate database_default,ProcessTime datetime ,Processed nvarchar(max) collate database_default)  
insert into ' +   @tablename 
+'( empid, EmployeeId, Name, AName, InputAmnt, amount, paycode,pay_name,pay_aname,Act_InputAmnt)  exec ' + @tabletype+'  
update '+@tablename+' set Post=1  '
+'update '+@tablename+' set HrStatusName=HrStatus.HrStatusName,HrStatusAName=HrStatus.HrStatusAName,JobName=jobs.JobName,JobAName=jobs.JobAName,OrganizationName=Organization.OrganizationName,OrganizationAName=Organization.OrganizationAName
  from '+@tablename+' temp inner join empassignment on temp.empid=empassignment.empid inner join HrStatus on empassignment.HrStatus=HrStatus.HrStatus 
inner join jobs on empassignment.job=jobs.job 
inner join Organization on empassignment.Organization=Organization.Organization 
  
      END'
PRINT @selectstr
       exec sp_executesql @selectstr
  	END
  
  ELSE 
  	IF charindex('DeleteJournalVoucher',ltrim(rtrim(@tabletype)))<>0
  	BEGIN
  		DECLARE @year int
  		DECLARE @month int
  		DECLARE @payrollgroup int
  		DECLARE @StartIndex AS int
  		SET @StartIndex=CHARINDEX(':',@TableType)
SET @TableType=substring (@tabletype,@StartIndex+1,len(@tabletype)-len(substring(@tabletype,0,@startindex)))

 SET @StartIndex=CHARINDEX(',',@tabletype)
 SET @year=substring(@tabletype,0,@StartIndex)

 SET @TableType=substring(@tabletype,@StartIndex+1,len(@tabletype))
 SET @StartIndex=CHARINDEX(',',@tabletype)
 SET @month=substring(@tabletype,0,@StartIndex)


 SET @TableType=substring(@tabletype,@StartIndex+1,len(@tabletype))
 SET @payrollgroup= @tabletype

  	  DECLARE @TableNamelen2 AS int 
      SET @TableNamelen2=len(@TableName)-charindex('[nasbatch',@TableName)-1
       SET @selectstr ='IF not EXISTS(SELECT top 1 1
		    FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
		    WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'  BEGIN CREATE TABLE ' + @tablename+ '(Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY, EmployeeId nvarchar(50),HrStatusName nchar(20),HrStatusAName nchar(20),JobName nvarchar(250),JobAName nvarchar(250) ,OrganizationName nvarchar(250),OrganizationAName nvarchar(250), PostedDate datetime,PostedBy int,Name nchar(88),AName nchar(88),EmployeeCount int ,del bit ,ProcessTime datetime ,Processed nvarchar(max)) 
insert into ' +   @tablename 
+'(EmployeeId,HrStatusName,HrStatusAName,JobName,JobAName,OrganizationName,OrganizationAName ,PostedDate,PostedBy,Name,AName,EmployeeCount,del)  
SELECT EA.EmployeeId,HrStatus.HrStatusName,HrStatus.HrStatusAName,Jobs.JobName,Jobs.JobAName
,Organization.OrganizationName,Organization.OrganizationAName, DailyJournal.PostedDate, DailyJournal.PostedBy, Profile.Name,Profile.AName, COUNT(DISTINCT DailyJournal.EmpId), 0 
 FROM DailyJournal 
 INNER JOIN EmpAssignment ON DailyJournal.EmpId = EmpAssignment.EmpId  
   LEFT JOIN EmpAssignment EA ON DailyJournal.PostedBy = EA.EmpId   
LEFT OUTER JOIN Profile ON DailyJournal.PostedBy = Profile.ProfileId  
left Join HrStatus on EA.HrStatus=HrStatus.HrStatus 
left join Jobs on Jobs.Job=EA.Job   
left join Organization on Organization.Organization=EA.Organization                                                                                                              
where DailyJournal.[Year]='+str(@Year)
+'  and DailyJournal.[Month]='+str(@Month) +' and EmpAssignment.payrollgroup='+str(@PayrollGroup)
+'  GROUP BY DailyJournal.PostedDate, DailyJournal.PostedBy, Profile.Name,Profile.AName, DailyJournal.[Year], DailyJournal.[Month],EA.EmployeeId,HrStatus.HrStatusName,HrStatusAName  
 ,Jobs.JobName,Jobs.JobAName,Organization.OrganizationName,Organization.OrganizationAName
order by DailyJournal.PostedDate DESC  end ' 
       exec sp_executesql @selectstr
       
  	END
  
ELSE
IF charindex( '@reportNo = 4007',ltrim(rtrim(@tabletype)) ) <> 0 
begin

EXEC [BatchWP_Pay_GetVacations] 3,@tablename ,@outstr output
execute( 'insert into ' +   @tablename  
+ ' ( Checked, profileid,  EmployeeId, Name, AName, Documentno ,VacCode , 
VacationName  , VacationAName  , VacationFrom   , VacationTo  , Vacationdays )  ' 


+ @tabletype)
	

end

ELSE

IF charindex( '[hits_BuildReportQuery]',ltrim(rtrim(@tabletype)) ) <> 0 
BEGIN
	
	PRINT '1235'
		----   creating and filling the temptable for the web batches ( app , doc , vac , ... ) batch posting
		declare @select as nvarchar(max)
		SET @select='   CREATE TABLE ' + @tablename + ' (Row_Number int IDENTITY(1,1) NOT NULL , Checked bit , 
		profileid int NOT NULL  , AssignmentID int null , EmployeeID  nvarchar(50),
		[EmpAppId] nvarchar(250) null, [Name]  nvarchar(250) , [AName]  nvarchar(250)
		, HrstatusName  nvarchar(250) , HrstatusAName  nvarchar(250)  
		,  JobName  nvarchar(250) , JobAName  nvarchar(250)  
		, OrganizationName  nvarchar(250) , OrganizationAName  nvarchar(250)  , Rank int default (0)
		,processed  nvarchar(max) DEFAULT ('''')
		,processtime  datetime NULL
		) Alter Table '+@tablename+' Add Primary Key (Row_Number ,profileid)'
	--print @select
	print 'tet' 
		exec sp_executesql @select
		--execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid  , AssignmentID , EmployeeID  , EmpAppId , [Name]  , [AName] ,  Rank) ' + @tabletype)
		execute( 'insert into ' +   @tablename + ' ( Checked, profileid,  AssignmentID, EmployeeID, EmpAppID, [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,RANK) ' + @tabletype)
		
		
		print @select
		print 'tet' 
END
ELSE IF charindex( '[BuildEmpApp]',ltrim(rtrim(@tabletype)) ) <> 0 AND charindex( '@reportNo = 4013',ltrim(rtrim(@tabletype)) ) <> 0
BEGIN
	DECLARE @tableEmpAssessment AS nvarchar(max),@tableAppAssessment AS nvarchar(max)
	
	-------------------------------------------------------------------
if charindex('Employeesonly',ltrim(rtrim(@tabletype)) )<> 0
begin

  set @tabletype=replace(@tabletype,'Employeesonly',' ')
  SET @tableAppAssessment='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )+10,8000)
end

else if charindex('Applicantsonly',ltrim(rtrim(@tabletype)) )<> 0
begin

  set @tabletype=replace(@tabletype,'Applicantsonly',' ')
  SET @tableEmpAssessment='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,14,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )-14)
end 
--------------------------------------------------------------------
ELSE
	begin
         SET @tableEmpAssessment='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,14,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )-14)

         SET @tableAppAssessment='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )+10,8000)
     end

		SET @select='   CREATE TABLE ' + @tablename + ' (Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY , Checked bit , 
		profileid int , AssignmentID int NULL , EmployeeID  nvarchar(50),
		[EmpAppId] nvarchar(250) null, [Name]  nvarchar(250) , [AName]  nvarchar(250)
		, HrstatusName  nvarchar(250) , HrstatusAName  nvarchar(250)  
		,  JobName  nvarchar(250) , JobAName  nvarchar(250)  
		, OrganizationName  nvarchar(250) , OrganizationAName  nvarchar(250)
		,InstrumentId nvarchar(50) , InstrumentName nvarchar(200) ,InstrumentAName nvarchar(200)
		,SessionID nvarchar(50) ,ScorePerc numeric (18,3) , CompleteDate smalldatetime , Status nvarchar(30),ElaspsedTime time(7)
		,PersonTypeName nvarchar(250), PersonTypeAName nvarchar(250)
		 , Rank numeric(18, 3) default (0.00)
		,processed  nvarchar(max) DEFAULT ('''')
		,processtime  datetime NULL
		)'
--PRINT @tableApp
--PRINT @tableEmp
		exec sp_executesql @select
		----------------------------------------------------------------------------------
		  IF @tableEmpAssessment IS not null
          begin
		     execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName, Rank) ' + @tableEmpAssessment)
		  end
		IF @tableAppAssessment IS NOT null
          begin
		      execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName ,Rank) ' + @tableAppAssessment)
          END
          ----------------------------------------------------------------------------------------------
--		execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName, Rank) ' + @tableEmp)
--		execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName ,Rank) ' + @tableApp)
end	
ELSE IF charindex( '[BuildEmpApp]',ltrim(rtrim(@tabletype)) ) <> 0  
BEGIN
	DECLARE @tableEmp AS nvarchar(max),@tableApp AS nvarchar(max)
	
	-------------------------------------------------------------------
if charindex('Employeesonly',ltrim(rtrim(@tabletype)) )<> 0
begin

  set @tabletype=replace(@tabletype,'Employeesonly',' ')
  SET @tableApp='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )+10,8000)
end

else if charindex('Applicantsonly',ltrim(rtrim(@tabletype)) )<> 0
begin

  set @tabletype=replace(@tabletype,'Applicantsonly',' ')
  SET @tableEmp='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,14,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )-14)
end 
--------------------------------------------------------------------
ELSE
	begin
         SET @tableEmp='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,14,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )-14)

         SET @tableApp='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )+10,8000)
     end

--SET @tableEmp='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,14,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )-14)
--
--SET @tableApp='exec [hits_BuildReportQuery]'+SUBSTRING(@tabletype,charindex( '[BuildApp]',ltrim(rtrim(@tabletype)) )+10,8000)

		SET @select='   CREATE TABLE ' + @tablename + ' (Row_Number int IDENTITY(1,1) NOT NULL PRIMARY KEY , Checked bit , 
		profileid int , AssignmentID int NULL , EmployeeID  nvarchar(50),
		[EmpAppId] nvarchar(250) null, [Name]  nvarchar(250) , [AName]  nvarchar(250)
		, HrstatusName  nvarchar(250) , HrstatusAName  nvarchar(250)  
		,  JobName  nvarchar(250) , JobAName  nvarchar(250)  
		, OrganizationName  nvarchar(250) , OrganizationAName  nvarchar(250) 
		,PersonTypeName nvarchar(250), PersonTypeAName nvarchar(250)
		 , Rank numeric(18, 3) default (0.00)
		,processed  nvarchar(max) DEFAULT ('''')
		,processtime  datetime NULL
		)'
--PRINT @tableApp
--PRINT @tableEmp
		exec sp_executesql @select
		----------------------------------------------------------------------------------
		  IF @tableEmp IS not null
          begin
		     execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName, Rank) ' + @tableEmp)
		  end
		IF @tableApp IS NOT null
          begin
		      execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName ,Rank) ' + @tableApp)
          END
          ----------------------------------------------------------------------------------------------
--		execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName, Rank) ' + @tableEmp)
--		execute( 'insert into ' +   @tablename + ' ( Checked  ,   profileid ,AssignmentID ,EmployeeID  , EmpAppId , [Name]  , [AName] , HrstatusName  , HrstatusAName  , JobName   , JobAName  , OrganizationName   , OrganizationAName,PersonTypeName,PersonTypeAName ,Rank) ' + @tableApp)
end	

ELSE IF charindex( 'WBUpdatePayrollProfile',ltrim(rtrim(@tabletype)) ) <> 0  
	BEGIN

			SET @select='CREATE TABLE '+@tablename+' (
			[Row_Number] int IDENTITY(1,1) NOT NULL PRIMARY KEY ,
			[Checked] bit NULL,
			[ChgFieldNo] [int] NOT NULL ,
			[EmpID] [int] NOT NULL ,
			[AName] nvarchar(88) NULL ,
			[Name] nvarchar(88) NULL ,
			[Hrvalue] numeric(18, 3) NULL ,
			[Payvalue] numeric(18, 3) NULL, [Inactive] nvarchar(80) DEFAULT ('''') ,
			[Employeeid] nvarchar(50) NULL ,
			[Hr_Desc] nvarchar(80) NULL ,
			[Hr_ADesc] nvarchar(80) NULL ,
			[Pay_Desc] nvarchar(80) NULL ,
			[Pay_ADesc] nvarchar(80) NULL ,
			[ChangedData] nvarchar(80) NULL ,
			[HrstatusName]  nvarchar(250) NULL ,
			[HrstatusAName]  nvarchar(250)  NULL , 
			[JobName]  nvarchar(250) NULL ,
			[JobAName]  nvarchar(250)   NULL ,
			[OrganizationAName]  nvarchar(250) NULL ,
			[OrganizationName]  nvarchar(250) NULL ,
			[Rank] int default (0) NULL ,
			[processed]  nvarchar(max) DEFAULT (''''),
			[processtime]  datetime NULL
			) '

				PRINT @tabletype+' , '''+@tablename+''''
			exec sp_executesql @select
			EXECUTE(@tabletype+' , '''+@tablename+'''')
		
	end	
ELSE IF charindex( 'Pay_LeaveWizard',ltrim(rtrim(@tabletype)) ) <> 0  
	BEGIN

			SET @select='CREATE TABLE '+@tablename+' (
			[Row_Number] int IDENTITY(1,1) NOT NULL PRIMARY KEY ,
			[profileid] [int] NULL ,
			[DocumentNo] [int] NULL ,
			[PlanNo] [int] NULL ,
			[OptionNo] [int] NULL ,
			[BenefitItem] [int] NULL ,
			[ActivityDate] datetime NULL  ,
			[ActivityAmount] Decimal(18,3) NULL  ,
			[ActivityQty] Decimal(18,3) NULL  ,
			[Checked] bit NULL,
			[processed]  nvarchar(max) DEFAULT (''''),
			[processtime]  datetime NULL,
			[Change] bit NULL
			) '

				PRINT @tabletype+' , '''+@tablename+''''
			exec sp_executesql @select
			EXECUTE(@tabletype+' , '''+@tablename+'''')
		
	end	
	
ELSE IF charindex( 'Pay_TerminateWizard',ltrim(rtrim(@tabletype)) ) <> 0  
	BEGIN

			SET @select='CREATE TABLE '+@tablename+' (
			[Row_Number] int IDENTITY(1,1) NOT NULL PRIMARY KEY ,
			[profileid] [int] NULL ,
			[DocumentNo] [int] NULL ,
			[PlanNo] [int] NULL ,
			[OptionNo] [int] NULL ,
			[BenefitItem] [int] NULL ,
			[ActivityDate] datetime NULL  ,
			[ActivityAmount] Decimal(18,3) NULL  ,
			[ActivityQty] Decimal(18,3) NULL  ,
			[Checked] bit NULL,
			[Close] bit NULL,
			[processed]  nvarchar(max) DEFAULT (''''),
			[processtime]  datetime NULL,
			[Change] bit NULL
			) '

				PRINT @tabletype+' , '''+@tablename+''''
			exec sp_executesql @select
			EXECUTE(@tabletype+' , '''+@tablename+'''')
		
	end		
	
	---Omniaaa
--ELSE IF charindex( 'TerminateEmployee',ltrim(rtrim(@tabletype)) ) <> 0  
--	BEGIN

--			SET @select='CREATE TABLE '+@tablename+' (
--			[Row_Number] int IDENTITY(1,1) NOT NULL PRIMARY KEY,
--			[profileid] [int] NULL,
--			[Employeeid] nvarchar(50) NULL,
--			[PayrollGroup] int,
--			[Name] nvarchar(max) NULL,
--			[AName] nvarchar(max) NULL,
--			[EmpVacBal] numeric(18,3) NULL,
--			[Termdate] smalldatetime,
--			[Checked] bit NULL,
--			[processed]  nvarchar(max) DEFAULT (''''),
--			[processtime]  datetime NULL,
--			) '

--				PRINT @tabletype+' , '''+@tablename+''''
--			exec sp_executesql @select
--			--PRINT 'test'
--			--EXECUTE(@tabletype+' , '''+@tablename+'''')
		
--	end	
else
BEGIN
PRINT 'vvv'

print '@@actualtablename'
print @actualtablename


SET @actualtablename=isnull(@tabletype,'')

set @str = 'EXEC [hits_importexport] 3,''' +@actualtablename+''','''+ @tablename  +''',0,@formulaOutput output'

	--set @str = 'EXEC [batch'+ltrim(rtrim(@tabletype))+'] 3,''' + @tablename  +''',0,@formulaOutput output'
	--set @str = 'EXEC [GenericBatch'+ltrim(rtrim(@tabletype))+'] 3,''' + @tablename  +''',0,@formulaOutput output'


	exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
PRINT @str
-- 	IF ltrim(rtrim(@tabletype)) ='WP_BankData' EXEC [batch_BankData] 3,@tablename ,0,@outstr output
-- 	IF ltrim(rtrim(@tabletype)) ='WP_JVSetup' EXEC [batch_JV] 3,@tablename ,0,@outstr output
end	

END

GO

