
CREATE PROCEDURE [dbo].[AI_AddJobQulafication]
	@logonName NVARCHAR(MAX),
	@job AS SMALLINT,
	@qualificationTitle AS NVARCHAR(60),
	@minYears AS decimal,
	@maxYears AS decimal,
	@minGrade AS SMALLINT, 
	@maxGrade AS SMALLINT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @qualificationNo AS SMALLINT;
	SELECT @qualificationNo = QualificationNo FROM Qualification WHERE RTRIM(LTRIM(LOWER(@qualificationTitle))) = QualificationTitle
	IF @qualificationNo IS NULL
	BEGIN
		CREATE TABLE #StoredResult (
			PrimaryKey INT,
			IsUEnterByExists INT,
			OrgsColumn INT
		);

		INSERT INTO #StoredResult
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Qualification', @PkFieldName = N'QualificationNo', @LogonName = @logonName;

		SELECT @qualificationNo = PrimaryKey FROM #StoredResult;

		INSERT INTO Qualification (
		QualificationNo, QualificationTitle, QualificationType, QualificationRank, EnterEstablishment, 
		EnterGrade, EnterMajor, EnterExpirationDate, EnterLicense, EnterSalary, EnterBenefit, EnterComment, 
		EnterJob, EstablishmentFromType, GradeFromType, MajorFromType, LengthComment, CaptionJob, 
		CaptionEstablishment, CaptionGrade, CaptionMajor, CaptionExpirationDate, CaptionLicense, CaptionSalary, 
		CaptionBenefit, CaptionComment, RequireJob, RequireEstablishment, RequireGrade, RequireMajor, 
		RequireExpirationDate, RequireLicense, RequireSalary, RequireBenefit, RequireComment, QualificationNoCons, 
		QualificationTitleCons, QualificationFromDate, QualificationToDate, QualificationRDesc, 
		QualificationRSource, QualificationRStatus, QualificationRExecDate, QualificationRIssueDate, 
		QualificationRNo, QualificationRYear, EnterScore, EnterTotalScore, CaptionScore, CaptionTotalScore, 
		RequireScore, RequireTotalScore, EnterApprovedDate, CaptionApprovedDate, RequireApprovedDate, 
		QualificationOrder, uenterby, uenterdate, Qualificationorgs
		) 
		VALUES (
			@qualificationNo, @qualificationTitle, NULL, 0, 0,
			0, 0, 0, 0, 0, 0, 0,
			0, NULL, NULL, NULL, 0, N'', N'',
			N'', N'', N'', N'', N'', N'',
			N'', 0, 0, 0, 0, 
			0, 0, 0, 0, 0, 0, 
			N'', NULL, NULL, N'', 
			NULL, NULL, NULL, NULL, 
			N'', 0, 0, 0, N'', N'', 
			0, 0, 0, N'', 0,
			0, @logonName, GETDATE(), ''
		);
	END

	IF EXISTS(SELECT Job FROM JobQualification WHERE Job = @job AND QualificationNo = @qualificationNo)
	BEGIN
		UPDATE JobQualification SET MinYears = @minYears, MaxYears = @maxYears, MinGrade = @minGrade, MaxGrade = @maxGrade WHERE Job = @job AND QualificationNo = @qualificationNo;
	END
	ELSE
	BEGIN
		INSERT INTO JobQualification (
		Job, QualificationNo, MinYears, MaxYears, MinGrade, MaxGrade, Required, QualificationOrder
		) 
		VALUES (
			@job, @qualificationNo, @minYears, @maxYears, @minGrade, @maxGrade, 0, 0
		);
	END
END

GO

