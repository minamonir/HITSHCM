CREATE PROCEDURE [dbo].[BatchWP_AssignShiftsAccordingtoWH] (@tablename AS NVARCHAR(max), @EnterBy AS INT, @lang AS nCHAR(1))
AS
BEGIN
       DECLARE @SickShift AS  INT = 0, @OFFShift AS INT= 0, @SickAbsentShift AS INT = 0
       , @UPLAbsentShift AS INT = 0, @DeathAbsentShift AS INT = 0, @UPLShift AS INT= 0
       , @MiliatryserviceShift AS INT = 0, @AnnualShift AS INT = 0, @DeathCaseAbsentShift AS INT = 0
       , @AppproblemShift AS INT = 0, @SupportPDVShift AS INT = 0, @ExamAbsentShift AS INT= 0
       , @SupportShift AS INT = 0, @RecoveryTaskShift AS INT = 0, @militaryAbsentShift AS INT = 0
       , @TeacnicalShift AS INT = 0, @investigationAbsentShift AS INT = 0, @CancelledOffShift AS INT =38

       DECLARE @SickVac AS  INT = 11 , @OFFVac AS INT=12, @SickAbsentVac AS INT = 13
       , @UPLAbsentVac AS INT = 14, @DeathAbsentVac AS INT = 15, @UPLVac AS INT= 16
       , @MiliatryserviceVac AS INT = 17, @AnnualVac AS INT = 18 , @DeathCaseAbsentVac AS INT = 19
       , @AppproblemVac AS INT = 20 , @SupportPDVVac AS INT = 21, @ExamAbsentVac AS INT= 22
       , @SupportVac AS INT = 23 , @RecoveryTaskVac AS INT = 24 , @militaryAbsentVac AS INT = 25
       , @TeacnicalVac AS INT = 26, @investigationAbsentVac AS INT = 27, @CancelledOffVac AS INT = 28

       DECLARE @PartTime AS INT = 6
       DECLARE @dummydate AS SMALLDATETIME, @FromTime NVARCHAR(5)='', @ToTime NVARCHAR(5)=''

       DECLARE @select NVARCHAR(MAX)
       DECLARE @empid NVARCHAR(MAX)='' , @WH NVARCHAR(MAX)='', @AttTime AS NVARCHAR(MAX)='', @attDate AS NVARCHAR(MAX)='' , @amount AS NVARCHAR(max), @shiftNo AS INT, @documentno AS INT

       DECLARE @Cursor_Cols AS NVARCHAR(MAX), @SelectStr AS NVARCHAR(MAX) = '', @StrHearders AS NVARCHAR(MAX)='', @StrSelectF AS NVARCHAR(MAX)='', @stmt AS NVARCHAR(MAX)=''
       ,@StrDate AS NVARCHAR(MAX), @TotalAttTime AS NVARCHAR(MAX)=''

       DECLARE @strAmount AS NVARCHAR(MAX), @StrHeardersDates AS NVARCHAR(MAX)='', @StrHeardersAmount AS NVARCHAR(MAX)='', @StrSelectFAmount AS NVARCHAR(MAX)=''

       DECLARE  @headr nvarchar(100),@str NVARCHAR(max), @count INT = 0

       DECLARE @vaccodeAll AS SMALLINT ,@shiftnoAll AS SMALLINT

       DECLARE @str1 AS NVARCHAR(MAX)='', @str2 AS NVARCHAR(MAX)='', @str3 AS NVARCHAR(MAX)='', @str4 AS NVARCHAR(MAX)='', @str5 AS NVARCHAR(MAX)='', @str6 AS NVARCHAR(MAX)=''

	   DECLARE @vacCodeUpdate AS SMALLINT, @statusUpdate AS SMALLINT, @FromDateUpdate AS SMALLDATETIME, @ToDateUpdate AS SMALLDATETIME

       CREATE TABLE #TempFHeaders(FHdr NVARCHAR(8))
       CREATE TABLE #TempDates(TDate NVARCHAR(MAX))
       CREATE TABLE #TempAmount(TAmount NVARCHAR(MAX))

       SET @select ='INSERT INTO #TempFHeaders (FHdr) SELECT COLUMN_NAME 
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME Like ''F%'' '
	   

       EXECUTE(@select)
     

       EXEC('DECLARE TempTable_cursor CURSOR FOR SELECT FHdr
       FROM #TempFHeaders where FHdr not in (''F001'',''F002'') ')
       OPEN TempTable_cursor
         FETCH NEXT FROM TempTable_cursor INTO @Cursor_Cols
              WHILE @@FETCH_STATUS = 0
                BEGIN 
                      SET @str='Select top 1 @SelectHeader =  '+@Cursor_Cols +' FROM '+@tablename +' where '+ LTRIM(RTRIM(ISNULL(@Cursor_Cols,''))) + ' <>'''' '
                      exec sp_executesql @str , N' @SelectHeader varchar(max) OUTPUT',  @SelectHeader = @SelectStr  OUT 
                      
                     IF LTRIM(RTRIM(ISNULL(@SelectStr,''))) NOT LIKE '%amount%'
                     BEGIN
                    
                       IF LTRIM(RTRIM(ISNULL(@SelectStr,''))) <> ''
                        BEGIN
                           SELECT @StrHeardersDates = @StrHeardersDates +'['+ @SelectStr +']'  +' nvarchar(max) ,'
                           SELECT @StrDate = ISNULL(@StrDate + ', ', '') + '[' + @SelectStr+ ']'
                           SELECT @StrSelectF =@StrSelectF + @Cursor_Cols +','
                           INSERT INTO #TempDates  SELECT @SelectStr     
                       END
                       ELSE BREAK
                     END 
                     
                      ELSE IF LTRIM(RTRIM(ISNULL(@SelectStr,''))) LIKE '%amount%'
                     BEGIN
                           IF LTRIM(RTRIM(ISNULL(@SelectStr,''))) <> ''
                           BEGIN
                           SELECT @StrHeardersAmount = @StrHeardersAmount +'['+ REPLACE(@SelectStr,'amount' ,'') +']'  +' nvarchar(max) ,'
                           SELECT @strAmount = ISNULL(@strAmount + ', ', '') + '[' + REPLACE(@SelectStr,'amount' ,'')+ ']'    
                           SELECT @StrSelectFAmount =@StrSelectFAmount + @Cursor_Cols +','
                           INSERT INTO #TempAmount SELECT @SelectStr
                           END
                           ELSE BREAK
                    END
              ELSE BREAK
              SELECT @SelectStr=NULL            
       FETCH NEXT FROM TempTable_cursor into @Cursor_Cols
              END
       CLOSE TempTable_cursor
       DEALLOCATE TempTable_cursor
	   
       SELECT @StrHeardersDates= substring(@StrHeardersDates ,1,len(@StrHeardersDates)-1)
       select @StrHeardersAmount= substring(@StrHeardersAmount ,1,len(@StrHeardersAmount)-1)
       SELECT @StrSelectF= substring(@StrSelectF ,1,len(@StrSelectF)-1)
       select @StrSelectFAmount= substring(@StrSelectFAmount ,1,len(@StrSelectFAmount)-1)

    --EXECUTE  ('create Table ##Temp(EmpID nvarchar(max),WH nvarchar(max),'+@StrHeardersDates+')')
    --EXEC('INSERT into ##Temp select F001 ,F002,'+ @StrSelectF+ ' from ' +@tableName +'t where t.post = 1 and (rtrim(ltrim(isnull(t.remarks,'''')))='''' ) ')
    --DELETE TOP (1) FROM ##Temp
    
    create Table #Temp(EmpID nvarchar(max),WH nvarchar(max))
    exec('ALTER TABLE #Temp ADD '+@StrHeardersDates)
    EXEC('INSERT into #Temp select F001 ,F002,'+ @StrSelectF+ ' from ' +@tableName +'t where t.post = 1 and (rtrim(ltrim(isnull(t.remarks,'''')))='''' ) ')
	 DELETE TOP (1) FROM #Temp

	 
    --EXECUTE  ('create Table ##TempAmount(EmpID nvarchar(max),'+@StrHeardersAmount+')')
    --EXEC('INSERT into ##TempAmount select F001,'+ @StrSelectFAmount+ ' from ' +@tableName +'t where t.post = 1 and (rtrim(ltrim(isnull(t.remarks,'''')))='''' ) ')       
    --   DELETE TOP (1) FROM ##TempAmount
	 create Table #TAmount(EmpID nvarchar(max))
    exec('ALTER TABLE #TAmount ADD '+@StrHeardersAmount)
	 DELETE TOP (1) FROM #TAmount


       CREATE TABLE #TempMain (employeeid nvarchar(max), wh nvarchar(max), AttTime nvarchar(max), AttDate nvarchar(max))

       EXEC ('insert into #TempMain select distinct * from (select  empid,wh, '+@StrDate+'
       from #Temp
       cross join #TempDates) as x
       UNPIVOT( AttTime FOR TDate IN('+@StrDate+')) AS pvt')
       CREATE TABLE #TempMainAmount (employeeid nvarchar(max), Amount NVARCHAR(MAX) ,AmountDate NVARCHAR(max))
     
       EXEC ('insert into #TempMainAmount select distinct * from (select  empid, '+@strAmount+'
       from #TAmount) as x
       UNPIVOT( AmountDate FOR TAmount IN('+@strAmount+')) AS pvt')

       EXEC('DECLARE TempTable_cursor2 CURSOR FOR SELECT empassignment.empid, wh, AttTime, AttDate, Amount
       FROM #TempMain
       LEFT JOIN #TempMainAmount ON #TempMainAmount.employeeid = #TempMain.employeeid AND ltrim(rtrim(#TempMain.AttDate)) = ltrim(rtrim(#TempMainAmount.AmountDate))
       left join empassignment on empassignment.employeeid = ltrim(rtrim(#TempMain.employeeid))')
       OPEN TempTable_cursor2
            FETCH NEXT FROM TempTable_cursor2 INTO @empid, @wh, @AttTime, @attDate,@amount
              WHILE @@FETCH_STATUS = 0
                   BEGIN 
                          SELECT @documentno = dbo.GetDocumentNo(@empid, 3)
                          SELECT  @vaccodeAll=0,@shiftnoAll=0,@shiftno=0,@FromTime='', @ToTime=''

                          IF LTRIM(RTRIM(@AttTime))='Sick'
						  BEGIN
						      SELECT @vaccodeAll=@SickVac , @shiftnoAll=@SickShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='OFF' 
						  BEGIN
						      SELECT @vaccodeAll=@OFFVac , @shiftnoAll=@OFFShift
						  END
                          ELSE IF LTRIM(RTRIM(@AttTime))='Sick & Absent' 
						  BEGIN
						      SELECT @vaccodeAll=@SickAbsentVac , @shiftnoAll=@SickAbsentShift
						  END
                          ELSE IF LTRIM(RTRIM(@AttTime))='UPL & Absent' 
						  BEGIN
						      SELECT @vaccodeAll=@UPLAbsentVac , @shiftnoAll=@UPLAbsentShift
						  END
                          ELSE IF LTRIM(RTRIM(@AttTime))='Death & Absent' 
						  BEGIN
						      SELECT @vaccodeAll=@DeathAbsentVac , @shiftnoAll=@DeathAbsentShift
						  END
                          ELSE IF LTRIM(RTRIM(@AttTime))='UPL'
						  BEGIN
						      SELECT @vaccodeAll=@UPLVac , @shiftnoAll=@UPLShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Miliatry service'
						  BEGIN
						      SELECT @vaccodeAll=@MiliatryserviceVac , @shiftnoAll=@MiliatryserviceShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Annual'
						  BEGIN
						      SELECT @vaccodeAll=@AnnualVac , @shiftnoAll=@AnnualShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Death Case & Absent'
						  BEGIN
						      SELECT @vaccodeAll=@DeathCaseAbsentVac , @shiftnoAll=@DeathCaseAbsentShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='App problem'
						  BEGIN
						      SELECT @vaccodeAll=@AppproblemVac , @shiftnoAll=@AppproblemShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Support PDV'
						  BEGIN
						      SELECT @vaccodeAll=@SupportPDVVac , @shiftnoAll=@SupportPDVShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Exam & Absent'
						  BEGIN
						      SELECT @vaccodeAll=@ExamAbsentVac , @shiftnoAll=@ExamAbsentShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Support'
						  BEGIN
						      SELECT @vaccodeAll=@SupportVac , @shiftnoAll=@SupportShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Recovery Task'
						  BEGIN
						      SELECT @vaccodeAll=@RecoveryTaskVac , @shiftnoAll=@RecoveryTaskShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='military & absent'
						  BEGIN
						      SELECT @vaccodeAll=@militaryAbsentVac , @shiftnoAll=@militaryAbsentShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='Teacnical'
						  BEGIN
						      SELECT @vaccodeAll=@TeacnicalVac , @shiftnoAll=@TeacnicalShift
						  END 
                          ELSE IF LTRIM(RTRIM(@AttTime))='investigation & Absent'
						  BEGIN
						      SELECT @vaccodeAll=@investigationAbsentVac , @shiftnoAll=@investigationAbsentShift
						  END 
						  ELSE IF LTRIM(RTRIM(@AttTime))='Cancelled Off'
						  BEGIN
						      SELECT @vaccodeAll=@CancelledOffVac , @shiftnoAll=@CancelledOffShift
						  END 
						  -- if not time part and there is wrong vacation/shift  spelling
						  ELSE IF  CHARINDEX(':',@AttTime) <=0 or ISNUMERIC(REPLACE(@AttTime,':',''))=0
						 SELECT @vaccodeAll=-1 , @shiftnoAll=-1

                          IF @vaccodeAll NOT IN (-1,0) OR @shiftnoAll NOT IN (-1,0) 
							BEGIN
								IF @shiftnoAll <> 0 
								BEGIN
								 IF EXISTS (SELECT * FROM dbo.TimeShifts WHERE ShiftNo =@shiftnoAll)
								 BEGIN
									IF NOT EXISTS (SELECT * FROM dbo.EmpShift WHERE EmpId = @empid AND ShiftDate = CONVERT(smalldatetime, @attDate, 111))
										BEGIN
											   INSERT INTO dbo.EmpShift( EmpId , ShiftDate , ShiftNo , EnterBy ,EnterDate)
											   SELECT @empid, CONVERT(smalldatetime, @attDate, 111), @shiftnoAll, @EnterBy,  GETDATE()
										END
                                ELSE
									BEGIN
                                       UPDATE empshift 
                                       SET ShiftNo = @shiftnoAll, ChangeBy = @EnterBy, ChangeDate = GETDATE()
                                       WHERE empid = @empid AND ShiftDate = CONVERT(smalldatetime, @attDate, 111)
									 END
								END
								ELSE
								BEGIN
								     SELECT @str5 = 'UPDATE '+ @tablename +'SET remarks =  isnull(remarks,'''') + char(13) + N'''  +ISNULL(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidShiftNo',@lang),
                                  (CASE WHEN @lang='A' THEN N'أدخل رقم الودرية صحيح في' ELSE N'Enter a Valid Shift No.'  END))+' ' + ISNULL(@AttTime,'')+ '''
                                       ,post=0  from '+@tablename+'
                                         left join empassignment on '+@tablename+'.f001 = empassignment.employeeid 
                                               where empassignment.empid='+@empid
                                EXEC (@str5)
								END
                                
							    
                                  
							END
                                IF @vaccodeAll <> 0
							    BEGIN
							       IF EXISTS (SELECT * FROM vacation WHERE vaccode =@vaccodeAll)
									  BEGIN
										IF NOT EXISTS (SELECT * FROM dbo.EmpVacat WHERE EmpId = @empid AND CONVERT(SMALLDATETIME, @attDate, 111) BETWEEN FromDate AND ToDate)
											BEGIN
												   INSERT INTO dbo.EmpVacat( EmpId , DocumentNo , VacStatus , VacCode , VacDate , FromDate ,ToDate, enterby, enterdate )
												   SELECT @empid, @documentno, 1, @vaccodeAll, CONVERT(smalldatetime,CONVERT(VARCHAR(10),GETDATE(), 111)),
												   CONVERT(SMALLDATETIME, @attDate, 111), CONVERT(SMALLDATETIME, @attDate, 111),@EnterBy,  GETDATE()
											END
										ELSE
											BEGIN
												   UPDATE dbo.EmpVacat
												   SET VacCode = @vaccodeAll, chngby = @EnterBy, chngdate = GETDATE(), VacStatus=1
												   WHERE EmpId = @empid AND CONVERT(SMALLDATETIME, @attDate, 111) between fromdate and todate
												   AND VacCode <> @vaccodeAll
											END
									   END
									   ELSE
										BEGIN
											 SELECT @str6 = 'UPDATE '+ @tablename +'SET remarks =  isnull(remarks,'''') + char(13) + N'''  +ISNULL(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidVacationNo',@lang),
										  (CASE WHEN @lang='A' THEN N'أدخل رقم اجازه في' ELSE N'Enter a Valid Vacation No.'  END))+' ' + ISNULL(@AttTime,'')+ '''
											   ,post=0  from '+@tablename+'
												 left join empassignment on '+@tablename+'.f001 = empassignment.employeeid 
													   where empassignment.empid='+@empid
										EXEC (@str6)
										END
                                END 
							 END
                          ELSE IF ISDATE(@attDate + ' '+@AttTime ) =1 
							BEGIN
						  --SELECT 3
                            IF ISNUMERIC(@wh)=1 OR LTRIM(RTRIM(@WH))='Part time /2'
                            BEGIN 
								IF ISNUMERIC(@Amount)=1 OR LTRIM(RTRIM(ISNULL(@amount,'')))=''
								BEGIN
								     SET @dummydate=CONVERT(SMALLDATETIME ,@attDate + ' '+@AttTime )
                                SELECT @FromTime= CONVERT(VARCHAR(5), @dummydate, 8)
                                iF LTRIM(RTRIM(@WH))='Part time /2' SELECT @totime= CONVERT(VARCHAR(5), DATEADD(HOUR,@PartTime,@dummydate),8)

                                ELSE SELECT @totime= CONVERT(VARCHAR(5), DATEADD(MINUTE,CAST(@wh AS NUMERIC(18,3))*60,@dummydate),8)

                                SELECT TOP 1 @shiftno = ShiftNo 
                                FROM dbo.TimeShifts WHERE LTRIM(RTRIM(FromTime)) =@FromTime AND LTRIM(RTRIM(ToTime)) =  @totime 
                                AND ISNULL(allowamnt,0) = ISNULL(@amount,0)
							
                                IF ISNULL(@shiftNo,0)=0
                                BEGIN
                                  SELECT @str1 = 'UPDATE '+ @tablename +'SET remarks = isnull(remarks,'''') + char(13) + N''' +isnull(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidShift',@lang),
                                  (case when @lang='A' then N'ليس هناك ورديات في هذه الأوقات' ELSE N'There is no shift at these times '  end))+' ' + @AttTime+ ' '+
								  ISNULL(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidAmount',@lang),
                                  (case when @lang='A' then N'مع هذه القيم ' ELSE N'with these amounts '  end))+' '+ISNULL(@amount,0)+  '''
                                              ,post=0  from '+@tablename+'
                                              left join empassignment on '+@tablename+'.f001 = empassignment.employeeid 
                                               where empassignment.empid='+@empid
                                       EXEC (@str1)
                                END
                                ELSE
                                BEGIN
                                       IF exists (SELECT * FROM empshift WHERE empid=@empid AND ShiftDate=CONVERT(smallDATETIME, @attDate, 111))
                                              UPDATE empshift 
                                              SET shiftNo=@shiftNo, ChangeBy = @EnterBy, ChangeDate = GETDATE()
                                              WHERE empid=@empid AND ShiftDate=CONVERT(smallDATETIME, @attDate, 111)
                                       ELSE 
                                              INSERT INTO dbo.EmpShift( EmpId , ShiftDate , ShiftNo , EnterBy ,EnterDate)
                                              SELECT @empid, CONVERT(smallDATETIME, @attDate, 111), @shiftno,@EnterBy,GETDATE()
                                       END 
								END
                               ELSE 
							   BEGIN
							          SELECT @str4 = 'UPDATE '+ @tablename +'SET remarks = isnull(remarks,'''') + char(13) + N'''  +isnull(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidAmountNumber',@lang),
                                  (case when @lang='A' then N'أدخل قيم صالحة في' ELSE N'Enter a Valid amount at '  end))+' ' + ISNULL(@amount,'')+ '''
                                       ,post=0  from '+@tablename+'
                                         left join empassignment on '+@tablename+'.f001 = empassignment.employeeid 
                                               where empassignment.empid='+@empid
                                EXEC (@str4)
							   END
                                END 
                          ELSE
                          BEGIN
                                SELECT @str2 = 'UPDATE '+ @tablename +'SET remarks =  N'''  +isnull(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidWH',@lang),
                                  (case when @lang='A' then N'أدخل ساعات عمل صالحة في' ELSE N'Enter a Valid Working Hours at '  end))+' ' + ISNULL(@wh,'')+ '''
                                       ,post=0  from '+@tablename+'
                                         left join empassignment on '+@tablename+'.f001 = empassignment.employeeid 
                                               where empassignment.empid='+@empid
                                EXEC (@str2)
                          END 
						END 
						  ELSE 
							BEGIN
								IF @vaccodeAll = -1 OR @shiftnoAll = -1
									BEGIN
									    SELECT @str3 = 'UPDATE '+ @tablename +'SET remarks = isnull(remarks,'''') + char(13) + N''' +isnull(dbo.Hits_GetDCCaption('WP_AssignShiftsAccordingtoWH','NotValidTime',@lang),
										(case when @lang='A' then N'أدخل أوقات صالحه في' ELSE N'Enter a Valid Time at '  end))+' ' + @AttTime+ ''' ,post=0  from '+@tablename+'    
										left join empassignment on '+@tablename+'.f001 = empassignment.employeeid 
																   where empassignment.empid='+@empid
									   EXEC (@str3)
									END 
							 END 
       FETCH NEXT FROM TempTable_cursor2 into @empid, @wh, @AttTime, @attDate,@amount
       END
       CLOSE TempTable_cursor2
       DEALLOCATE TempTable_cursor2

       DROP TABLE #TempDates
       DROP TABLE #TempAmount
       DROP TABLE #TempMain
       DROP TABLE #TempMainAmount
       DROP TABLE #TempFHeaders
       DROP TABLE #Temp
       DROP TABLE #TAmount
       --EXEC('DROP TABLE ##Temp')
       --EXEC('DROP TABLE ##TempAmount')
END

GO

