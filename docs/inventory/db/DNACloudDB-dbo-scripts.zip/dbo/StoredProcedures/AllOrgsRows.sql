-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[AllOrgsRows]
	-- Add the parameters for the stored procedure here
	@Tablename nvarchar(max),
	@LogonName nvarchar(max)

AS
SET FMTONLY OFF
BEGIN
	SET NOCOUNT ON;

	CREATE TABLE #orgsFromView (
	[EmpId] int not null
      ,[UserGroup] smallint not null
      ,[pw] nvarchar(250) not null
      ,[LogonName] nvarchar(80) not null
      ,[ProfileRights] nchar(10) not null
      ,[JobRights] nchar(10) not null
      ,[FinanceRights] nchar(10) not null
      ,[InsuranceRights] nchar(10) not null
      ,[PrivacyLevelFrom] smallint not null
      ,[PrivacyLevelTo] smallint not null
      ,[ApplySSGroups] bit not null
      ,[DefaultCalendar] smallint not null
      ,[WindowsOnly] bit not null
      ,[PasswordRequired] bit not null
      ,[ProfileId] int not null
      ,[NamePrefix] smallint not null
      ,[ProfileLang] smallint not null
      ,[Name] nvarchar(88) not null
      ,[NickName] nvarchar(30) not null
      ,[NickAName] nvarchar(30) not null
      ,[FirstName] nvarchar(20) not null
      ,[MidName] nvarchar(25) not null
      ,[LastName] nvarchar(20) not null
      ,[FourthName] nvarchar(20) not null
      ,[AName] nvarchar(88) not null
      ,[FirstAName] nvarchar(20) not null
      ,[MidAName] nvarchar(25) not null
      ,[LastAName] nvarchar(20) not null
      ,[FourthAName] nvarchar(20) not null
      ,[SocStatus] smallint not null
      ,[Mobile] nvarchar(20) not null
      ,[TeleNo1] nvarchar(20) not null
      ,[Address] nvarchar(254) not null
      ,[CityId] smallint null
      ,[Country] nvarchar(20) not null
      ,[Zipcode] nvarchar(10) not null
      ,[PrivateEmail] nvarchar(80) not null
      ,[CompanyEmail] nvarchar(80) not null
      ,[Gender] smallint not null
      ,[BirthDate] smalldatetime null
      ,[NationId] smallint null
      ,[NatnlNo] nvarchar(20) not null
      ,[FstPR] bit not null
      ,[secPR] bit not null
      ,[ThrdPR] bit not null
      ,[FothPR] bit not null
      ,[FithPR] bit not null
      ,[SithPR] bit not null
      ,[SevthPR] bit not null
      ,[EithPR] bit not null
      ,[FstJR] nvarchar(1) null
      ,[secJR] nvarchar(1) null
      ,[ThrdJR] nvarchar(1) null
      ,[FothJR] nvarchar(1) null
      ,[FithJR] nvarchar(1) null
      ,[SithJR] nvarchar(1) null
      ,[SevthJR] nvarchar(1) null
      ,[EithJR] nvarchar(1) null
      ,[NithJR] nvarchar(1) null
      ,[TethJR] nvarchar(1) null
      ,[FstFR] nvarchar(1) null
      ,[secFR] nvarchar(1) null
      ,[ThrdFR] nvarchar(1) null
      ,[FothFR] nvarchar(1) null
      ,[FithFR] nvarchar(1) null
      ,[SithFR] nvarchar(1) null
      ,[SevthFR] nvarchar(1) null
      ,[EithFR] nvarchar(1) null
      ,[NithFR] nvarchar(1) null
      ,[TethFR] nvarchar(1) null
      ,[FstIR] nvarchar(1) null
      ,[secIR] nvarchar(1) null
      ,[ThrdIR] nvarchar(1) null
      ,[FothIR] nvarchar(1) null
      ,[FithIR] nvarchar(1) null
      ,[SithIR] nvarchar(1) null
      ,[SevthIR] nvarchar(1) null
      ,[EithIR] nvarchar(1) null
      ,[NithIR] nvarchar(1) null
      ,[TethIR] nvarchar(1) null
      ,[ProfileEnterBy] int not null
      ,[ProfileChangeBy] int null
      ,[DefCalendar] nchar(30) null
      ,[DefACalendar] nchar(30) null
      ,[DefFCalendar] nchar(30) null
      ,[AddressId] int null
      ,[InActive] bit not null
      ,[PasswordDate] smalldatetime null
      ,[PasswordNeverExpire] bit not null
      ,[LastLogonDate] smalldatetime null
      ,[DisableFeatures] nvarchar(max) not null
      ,[ConsecutiveAttempts] int not null
      ,[DisableWebParts] bit not null
      ,[MobileMFA] bit not null
      ,[UserOrganization] nvarchar(max) not null
      ,[RepPropertyName1] nvarchar(250) not null
      ,[RepPropertyName2] nvarchar(250) not null
      ,[ARepPropertyName1] nvarchar(250) not null
      ,[ARepPropertyName2] nvarchar(250) not null
      ,[CurrentUser] nvarchar(80) null
      ,[UEnterBy] nvarchar(80) not null
      ,[UEnterDate] smalldatetime null
      ,[UChangeBy] nvarchar(80) not null
      ,[UChangeDate] smalldatetime null
      ,[ReviewedBy] nvarchar(80) not null
      ,[ReviewedDate] smalldatetime null
      ,[ApprovedBy] nvarchar(80) not null
      ,[ApprovedDate] smalldatetime null
      ,[CodeStatus] int null
      ,[NasUsersOrder] int not null 
      ,[UserOrgsValid] nvarchar(max) null
	  ,[UserGroupName] nvarchar(60) not null
	  ,[UserGroupAName] nvarchar(60) not null
	,[Row_Number] int identity(1,1))	



declare @StrQuery nvarchar(max)=''
	set @StrQuery='insert into #orgsFromView select VU.[EmpId]
      ,VU.[UserGroup]
      ,VU.[pw]
      ,VU.[LogonName]
      ,VU.[ProfileRights]
      ,VU.[JobRights]
      ,VU.[FinanceRights]
      ,VU.[InsuranceRights]
      ,VU.[PrivacyLevelFrom]
      ,VU.[PrivacyLevelTo]
      ,VU.[ApplySSGroups]
      ,VU.[DefaultCalendar]
      ,VU.[WindowsOnly]
      ,VU.[PasswordRequired]
      ,VU.[ProfileId]
      ,VU.[NamePrefix]
      ,VU.[ProfileLang]
      ,VU.[Name]
      ,VU.[NickName]
      ,VU.[NickAName]
      ,VU.[FirstName]
      ,VU.[MidName]
      ,VU.[LastName]
      ,VU.[FourthName]
      ,VU.[AName]
      ,VU.[FirstAName]
      ,VU.[MidAName]
      ,VU.[LastAName]
      ,VU.[FourthAName]
      ,VU.[SocStatus]
      ,VU.[Mobile]
      ,VU.[TeleNo1]
      ,VU.[Address]
      ,VU.[CityId]
      ,VU.[Country]
      ,VU.[Zipcode]
      ,VU.[PrivateEmail]
      ,VU.[CompanyEmail]
      ,VU.[Gender]
      ,VU.[BirthDate]
      ,VU.[NationId]
      ,VU.[NatnlNo]
      ,VU.[FstPR]
      ,VU.[secPR]
      ,VU.[ThrdPR]
      ,VU.[FothPR]
      ,VU.[FithPR]
      ,VU.[SithPR]
      ,VU.[SevthPR]
      ,VU.[EithPR]
      ,VU.[FstJR]
      ,VU.[secJR]
      ,VU.[ThrdJR]
      ,VU.[FothJR]
      ,VU.[FithJR]
      ,VU.[SithJR]
      ,VU.[SevthJR]
      ,VU.[EithJR]
      ,VU.[NithJR]
      ,VU.[TethJR]
      ,VU.[FstFR]
      ,VU.[secFR]
      ,VU.[ThrdFR]
      ,VU.[FothFR]
      ,VU.[FithFR]
      ,VU.[SithFR]
      ,VU.[SevthFR]
      ,VU.[EithFR]
      ,VU.[NithFR]
      ,VU.[TethFR]
      ,VU.[FstIR]
      ,VU.[secIR]
      ,VU.[ThrdIR]
      ,VU.[FothIR]
      ,VU.[FithIR]
      ,VU.[SithIR]
      ,VU.[SevthIR]
      ,VU.[EithIR]
      ,VU.[NithIR]
      ,VU.[TethIR]
      ,VU.[ProfileEnterBy]
      ,VU.[ProfileChangeBy]
      ,VU.[DefCalendar]
      ,VU.[DefACalendar]
      ,VU.[DefFCalendar]
      ,VU.[AddressId]
      ,VU.[InActive]
      ,VU.[PasswordDate]
      ,VU.[PasswordNeverExpire]
      ,VU.[LastLogonDate]
      ,VU.[DisableFeatures]
      ,VU.[ConsecutiveAttempts]
      ,VU.[DisableWebParts]
      ,VU.[MobileMFA]
      ,VU.[UserOrganization]
      ,VU.[RepPropertyName1]
      ,VU.[RepPropertyName2]
      ,VU.[ARepPropertyName1]
      ,VU.[ARepPropertyName2]
      ,VU.[CurrentUser]
      ,VU.[UEnterBy]
      ,VU.[UEnterDate]
      ,VU.[UChangeBy]
      ,VU.[UChangeDate]
      ,VU.[ReviewedBy]
      ,VU.[ReviewedDate]
      ,VU.[ApprovedBy]
      ,VU.[ApprovedDate]
      ,VU.[CodeStatus]
      ,VU.[NasUsersOrder]
      ,VU.[UserOrgsValid],
	  [UserGroupName], 
	  [UserGroupAName] from '+@Tablename + '   VU left join UserGroup UG on UG.UserGroup=VU.UserGroup where VU.UserOrgsValid in (select ''#''+cast(nasusersorgs.Organization as nvarchar(max))+''#'' from nasusersorgs where NasUsersOrgs.LogonName=N'''+@LogonName+''') or (VU.UserOrgsValid =N'''')'
    print @StrQuery
	exec(@StrQuery);
	select * from #orgsFromView
	drop table  #orgsFromView
END

GO

