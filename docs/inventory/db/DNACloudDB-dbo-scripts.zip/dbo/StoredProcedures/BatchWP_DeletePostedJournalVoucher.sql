-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[BatchWP_DeletePostedJournalVoucher]
	
( @tablename as nvarchar(150) ,@year int , @month int)
	 AS
   BEGIN 
   	DECLARE @Cursor_PostedBy AS int
   	DECLARE @Cursor_PostedDate AS smalldatetime
   	DECLARE @select AS nvarchar(max)
   	DECLARE @selectstr AS nvarchar(max)
   	DECLARE @Error AS int
   	DECLARE @ErrMsg AS nvarchar(max)
   	SET @ErrMsg=''
   	SET @select ='SELECT PostedBy ,PostedDate FROM '+@tablename +' where Del=1'
   	EXEC ('DECLARE records_cursor CURSOR FOR '+@Select)
      OPEN records_cursor
      FETCH NEXT FROM records_cursor into @Cursor_PostedBy,@Cursor_PostedDate
      WHILE @@FETCH_STATUS = 0
        BEGIN
        	   
        	SET @selectstr='delete from DailyJournal where PostedBy= '+str(@Cursor_PostedBy)+ ' And PostedDate='''+CONVERT(nvarchar(25),@Cursor_PostedDate,120) +''' and Year='+str(@year)+' and Month='+str(@month)
          EXECUTE(@selectstr)
         
          SET @Error=@@ERROR 
          select @ErrMsg=@ErrMsg+CASE when @ErrMsg ='' THEN '' ELSE ' , ' END +ltrim(rtrim(str(@Error)))+'N : '+replace (description,'''','''''') 
          FROM hitssysmessages
          WHERE error=@Error 
          
         set @selectstr = 'update '+@TableName+' set processtime = getdate() ,Processed=N'''+@ErrMsg+N''' where Postedby = ' + str(@Cursor_PostedBy)+' and PostedDate='''+CONVERT(nvarchar(25),@Cursor_PostedDate,120)+''''
         EXECUTE(@selectstr)
        FETCH NEXT FROM records_cursor into @Cursor_PostedBy,@Cursor_PostedDate
        END
      CLOSE records_cursor
      DEALLOCATE records_cursor		
   	
   END

GO

