
CREATE    PROCEDURE [dbo].[Batch_Validate]  (@tablename AS nvarchar(150),@LogonName nchar(80),@Paycode AS int,@tabletype AS nvarchar(max),@lang AS nchar(1)) 
AS


--exec [Batch_Validate] 'DNACLOUDDBBatchTemp.dbo.[Nasbatch40420240214102336c0344c2748ea40e69904b4c567af47a8]','1',51,'WP_GetExternalChangeOfStatus' , 'E'


--Update DNACLOUDDBBatchTemp.dbo.[Nasbatch40420240214103644b4c406eb9647426eb10c3af686429856] set remarks = null , post = null


--declare @tablename AS nvarchar(150),@LogonName nchar(80),@Paycode AS int,@tabletype AS nvarchar(max),@lang AS nchar(1)

--select @tablename='DNACLOUDDBBatchTemp.dbo.[Nasbatch40420240214103644b4c406eb9647426eb10c3af686429856]',@LogonName='1',
--@Paycode=51,@tabletype='WP_GetExternalChangeOfStatus' , @lang='E'



--update DNACLOUDDBBatchTemp.dbo.[Nasbatch40420221227034938ec604c2c75094e6f9075dec4d826c397] set remarks = ''
--declare @tablename AS nvarchar(150) = 'DNACLOUDDBBatchTemp.dbo.[Nasbatch40420221227034938ec604c2c75094e6f9075dec4d826c397]',@LogonName nchar(80)='1',@Paycode AS int=0,@tabletype AS nvarchar(max)='WP_ExternalSystemsBatchPosting',@lang AS nchar(1)='E'
--test
--exec [Batch_Validate] 'DNACLOUDDBBatchTemp.dbo.[Nasbatch232858202211211025521587735cf75c4f24b3bc36475e1f7009]','tony',0,'WP_GetExternalApplicants?0,0' , 'E'
 --update DNACLOUDDBBatchTemp.dbo.[Nasbatch232858202211211139073c7a57e8812e4d8aa492c0e24e0b9981] set cJob='Job 855563',corg1='',cgrade='Grade551',CNationId='david nations',CRecruitmentActivity='fgdhj                                                                                                                   '
 --,CApplicationSource='Via Internet                                                ',CTimeRule='',,,CNationId='',post=1


--declare @tablename AS nvarchar(150)= 'DNACLOUDDBBatchTemp.dbo.[Nasbatch232858202211211139073c7a57e8812e4d8aa492c0e24e0b9981]',@LogonName nchar(80)='tony'
--,@Paycode AS int=0,
--@tabletype AS nvarchar(max)='WP_GetExternalApplicants?0,1' ,@lang AS nchar(1)='E'
--exec [Batch_Validate] 'DNACLOUDDBBatchTemp.dbo.[Nasbatch40420221002021554904fcee1209942e894fab8b91435d49a]','1',0,'WP_GetExternalEmployees?0,0' , 'E'
--declare @tablename AS nvarchar(150)='DNACLOUDDBBatchTemp.dbo.[Nasbatch23285820221005041830fdbe4500d0c54971a99e2478e473959d]',@LogonName nchar(80)='1',@Paycode AS int=0,
--@tabletype AS nvarchar(max)='WP_ExternalSystemsBatchPosting?0,0'  ,@lang AS nchar(1)='E'
BEGIN

	DECLARE @DateFormat AS INT
	DECLARE @pcodeno AS INT , @payrollgroup AS INT 
	
	DECLARE @DecimalScale AS INT
	DECLARE @EnableRef AS BIT

    SELECT  @DecimalScale= decimalscale, @DateFormat =DateFormat, @EnableRef= EnableReferences	FROM SysParam

	DECLARE @empid AS int,@ApplySSGroups AS bit,@PrivacyLevelFrom AS int,@PrivacyLevelTo AS int,@str AS nvarchar(max) ,@userOrganization AS NVARCHAR(max),@enableOrgSetup AS BIT 
	DECLARE @errormsg AS nvarchar(max)
	DECLARE @CreateSetp INT , @StartIndex INT  , @Consolidation AS INT, @subtabletype as nvarchar (20)
	SET @errormsg=N''


	---

	-----Custom for new capital customer-------------------------------------------------------------------------------
declare @customrestriction as smallint=0
DECLARE @EmergencyVaccode as SMALLINT, @AnnualVaccode as SMALLINT ,@EmergencyBeforeAnnualExist as int=0 ,@AnnualAfterEmeregncyExist as int=02

select @customrestriction=0,   @EmergencyVaccode=2,   @AnnualVaccode=1
-----------------------------------------------------------------------------------------------------------

    DECLARE @StartIndex1 AS INT
 --   if ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalEmployees%' 
 --   begin
	--SET @StartIndex1=CHARINDEX('?',@tabletype)
	--SET @Consolidation=isnull(substring(@tabletype,@StartIndex+1,1),1)
 --   END 
	DECLARE @NatnNoMandatory INT =0             -- National Number Required Validation
	, @NatnNoUnique INT =0             -- National Number Unique Validation
	, @NatnNolength INT =0             -- National Number length
	,@NatnNoChar INT =0					-- National Number contain char
	, @SSNumRequired INT =0                    -- Social Insurance Number Required Validation
	, @SSNumExistAndUnique INT =0              -- Social Insurance Number Unique Validation
	,@FileNoRequired INT = 0                     
	,@FileNoExistAndUnique INT = 0,
	@BirthdateNatnlNoConflict  AS INT = 0	     -- Birthdate NatnlNo Validation
	,@NatnlNoUniqueActiveInsertOnly AS INT = 0
	,@GradeRequired AS INT = 0						-- Grade Required Validation
	,@CompanyEmailRequired AS INT = 0						-- Company Email Required Validation
    ,@SalaryScaleRequired AS INT = 0                        -- Salary Scale Required Validation
    ,@HiringDate_WorkReceivingDateRequired  AS INT = 0		-- Hire Date Not Equal Work Receiving Date Validation
    ,@AddressRequired INT = 0							-- Address Required Validation
	,@MobileLength INT = 0								-- Mobile Length Validation
	,@PassportorNatnlnoRequired as int = 0					-- Passport is required for all nations except Egyptians , for Egyptians National no. is required
	,@validategradewithjob AS INT=0
	,@PositionRequired as int = 0                           --position required
	,@BirthdateRequired as int = 0                          --Birth date Required
	,@validatehirebirthtemp AS INT = 0
	,@GenderRequired   as int = 0 
	,@LocationRequired as int = 0 
	,@NatnlNoFirstDigitCheck  AS INT = 0					-- NatnlNo Check First Digit  Validation
	,@BirthHireTermValidation as int =0
	,@GenderNatnlNoConflict AS INT=0                       --Narional number digit  (The number before the last) matches Gender  (even number : female  odd: male)
	,@MilitaryRequiredBasedOnGender AS INT =0		--Military Required Based On Gender
	,@MilitaryStatusMandatory AS INT = 0			-- Military Status Required Validation
    ,@MobileMandatory As INT = 0  						-- Mobile Required Validation
    ,@VacPackMandatory AS INT = 0  							-- Vacation Package Required Validation 
    ,@TimeRuleRequired As INT = 0  						-- Time Keeping Rule Required Validation	
	,@ContractStartMandatory AS INT = 0  					-- Contract Start Required Validation
    ,@ContractEndMandatory AS INT = 0 					-- Contract End Required Validation
	declare @RequiredOrUniqueFields as nvarchar(max)='00000000000000000000000000'
	select @RequiredOrUniqueFields=isnull(configvalue,'00000000000000000000000000') from sysparamconfig where configid='RequiredOrUniqueFields'

		DECLARE @ValidateNatnlNo AS NVARCHAR(20)=''
		
	SELECT @ValidateNatnlNo= ConfigValue FROM sysparamconfig WHERE ConfigID='ValidateNatnlNo'
	IF LTRIM(RTRIM(@ValidateNatnlNo))<>''
	BEGIN
		SELECT @ValidateNatnlNo =','+@ValidateNatnlNo+',' 
	END


select @NatnNoMandatory = substring(@RequiredOrUniqueFields,1,1)
select @NatnNoUnique =substring(@RequiredOrUniqueFields,2,1)
select @SSNumRequired =substring(@RequiredOrUniqueFields,3,1)
select @SSNumExistAndUnique =substring(@RequiredOrUniqueFields,4,1)
select @FileNoRequired =substring(@RequiredOrUniqueFields,5,1)
select @FileNoExistAndUnique =substring(@RequiredOrUniqueFields,6,1)
select @BirthdateNatnlNoConflict =substring(@RequiredOrUniqueFields,7,1)
select @NatnlNoUniqueActiveInsertOnly =substring(@RequiredOrUniqueFields,8,1)
select @GradeRequired = substring(@RequiredOrUniqueFields,9,1)
select @CompanyEmailRequired = substring(@RequiredOrUniqueFields,10,1)
select @SalaryScaleRequired = substring(@RequiredOrUniqueFields,11,1)
select @HiringDate_WorkReceivingDateRequired = substring(@RequiredOrUniqueFields,12,1)
SELECT @NatnNolength = substring(@RequiredOrUniqueFields,13,1)
select @AddressRequired =substring(@RequiredOrUniqueFields,14,1)
select @MobileLength =substring(@RequiredOrUniqueFields,16,1)
select @PassportorNatnlnoRequired = substring(@RequiredOrUniqueFields,18,1)
select @validategradewithjob =substring(@RequiredOrUniqueFields,19,1)
select @PositionRequired = substring(@RequiredOrUniqueFields,20,1)
select @BirthdateRequired = substring(@RequiredOrUniqueFields,21,1)
select @GenderRequired = substring(@RequiredOrUniqueFields,22,1)
select @LocationRequired=  SUBSTRING(@RequiredOrUniqueFields,25,1)

select @validatehirebirthtemp =substring(@RequiredOrUniqueFields,24,1)
select @MilitaryRequiredBasedOnGender = substring(@RequiredOrUniqueFields,30,1)

SELECT @NatnNoChar = substring(@RequiredOrUniqueFields,26,1)
select @NatnlNoFirstDigitCheck = substring(@RequiredOrUniqueFields,27,1)
select @BirthHireTermValidation = substring(@RequiredOrUniqueFields,31,1)
SELECT @GenderNatnlNoConflict =substring(@RequiredOrUniqueFields,32,1)
select @MobileMandatory =substring(@RequiredOrUniqueFields,33,1)
select @VacPackMandatory =substring(@RequiredOrUniqueFields,34,1)
select @TimeRuleRequired =substring(@RequiredOrUniqueFields,35,1)
select @ContractStartMandatory =substring(@RequiredOrUniqueFields,36,1)
select @ContractEndMandatory =substring(@RequiredOrUniqueFields,37,1)
select @MilitaryStatusMandatory =substring(@RequiredOrUniqueFields,38,1)
---=====================validate text=====================================================================================================
	DECLARE @EnableTextValidation AS NVARCHAR(MAX) = '0', 
	@RegularExpressionError AS NVARCHAR(MAX)=N''
	SELECT @EnableTextValidation = ConfigValue 
	FROM dbo.SysParamConfig WHERE ConfigID = 'EnableTextValidation'

	if @EnableTextValidation='1'
	begin
    SELECT @RegularExpressionError = ISNULL(CASE WHEN @lang = 'A' THEN RegExAMessage WHEN @lang = 'F' THEN RegEXFMessage ELSE RegExmessage END , CASE @lang  WHEN 'A' THEN N'لا يسمح بإدخال هذة الرموز (+،-،@،=)' ELSE 'Cannot insert these symbols (+,-,@,=)' END) FROM dbo.SysParamRegEX WHERE RegEXID = 'SQLFields.ValidateInput'
	end	
--=========================================================================================================================================

select @userOrganization =UserOrganization,@enableOrgSetup=enableorgsetup 
from nasusers
CROSS JOIN SysParam
where @logonname=logonname 


	  
	  IF @enableOrgSetup=1 AND @userOrganization <>''
	  BEGIN     
	  	DECLARE @Orgs AS NVARCHAR(max)=''
	    ------------------------Create Org Tree--------------------------------------------
			CREATE TABLE #OrgTree(VOrganization INT )	
			INSERT INTO #OrgTree
			select distinct OrganizationParentOrChild from OrganizationParentChild o where @userOrganization LIKE '%#'+ltrim(rtrim(o.organization))+'#%'
			
			SELECT @Orgs =@Orgs +ltrim(rtrim(str(max(organizationParentorChild))))+',' 
		                  from OrganizationParentChild 
		                  where OrgRelation IN (2,3) 
		                  and @UserOrganization LIKE '%#'+ltrim(rtrim(OrganizationParentChild.organization))+'#%'  
						group by organizationParentorChild
			set @Orgs=case when @Orgs<>'' then left(@Orgs,len(@Orgs)-1)else @Orgs end		
	 END 
-------------------------------------------------------------

IF ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalHousingItems%' OR ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalHousingItems_ar%'
OR ltrim(rtrim(@tabletype))LIKE '%GetExternalVacRecords%'  OR ltrim(rtrim(@tabletype))LIKE '%GetExternalVacRecords_ar%'  
OR  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalMisconduct%'
OR ltrim(rtrim(@tabletype))LIKE '%GetExternalAppraisalWMR%'  OR ltrim(rtrim(@tabletype))LIKE '%GetExternalAppraisalWMR_ar%'
OR ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalObjective%'  OR ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalObjective_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalDocuments%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalDocuments_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalevents%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalevents_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalAdditionalevents%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalAdditionalevents_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalCompetencies%'
OR LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalBenefitPlan%' 
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalEmpSSGroupRoles%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalEmpSSGroupRoles_ar%' 
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalProfileUserDefinedFields%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalProfileUserDefinedFields_ar%' 
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalTimePermission%' 
OR LTRIM(rtrim(@tabletype)) LIKE '%WP_GetExternalBenefitItems%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalBenefitItems_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalHRRequests%' 
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalTasks%' 
OR ltrim(rtrim(@tabletype)) like'%WP_LoadPaymentData%' 
OR LTRIM(rtrim(@tabletype)) LIKE '%WP_GetExternalNASUsers%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalNASUsers_ar%'

BEGIN

	 	select @str='UPDATE '+@tablename+' set post= 1
	    FROM '+@tablename+' temptable where (post is null or '+ltrim(rtrim(str(@Paycode)))+'<>0)  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
	    EXECUTE(@str)
	
	 	select  @empid=empid , @ApplySSGroups =ApplySSGroups , @PrivacyLevelFrom=PrivacyLevelFrom,@PrivacyLevelTo=PrivacyLevelTo,@userOrganization =UserOrganization,@enableOrgSetup=enableorgsetup 
	    from nasusers
	    CROSS JOIN SysParam
	     where @logonname=logonname 

        SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not a valid employee'  end))                          
		
	   select @str='UPDATE '+@tablename+' set remarks= N''''  FROM '+@tablename+' temptable where   temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end ' 
	 print @str
	   EXECUTE(@str)	
	--Update invalid Employees

	select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+'''))+char(13) ,post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END +
	'WHERE EmpAssignment.empid IS null  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '  

	PRINT '111-------------'
	PRINT @str
	EXECUTE(@str)
	
	--Update Name 
		IF @Paycode=0
		begin
    select @str='UPDATE '+@tablename+' set name='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
	FROM '+@tablename+' temptable
	inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	left join profile on profile.profileid=empassignment.empid 
	where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	PRINT @str
	EXECUTE(@str)	
	      end
	   --check on Employee Status	
	SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang,@LogonName),(case when @lang='A' then N'حالة الموظف لا يعمل' ELSE N'Not an active employee'  end))                           
	




	--select @str='UPDATE '+@tablename+' set remarks = ltrim(rtrim(remarks)) + N'''+ltrim(rtrim(@errormsg))+'''+char(13)'+'
	--	,post=0
 --               FROM ' + @tablename + '  temptable  
	--Inner JOIN EmpAssignment ON temptable.empid=empassignment.EmployeeId 
	--and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	--+' inner join hrstatus on hrstatus.hrstatus=empassignment.hrstatus'
	--+' WHERE  hrstatus.paystatus <> 1  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '  
	
	--PRINT @str
 --EXECUTE(@str)

	
	
	--===========================================================================================================================================
	


	IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalMisconduct%' 
		BEGIN
	--		SET @errormsg=N''
	--	 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang),(case when @lang='A' then N'حالة الموظف لا يعمل' ELSE N'Not an active employee'  end))                          
		
	
	----SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not a valid employee'  end)) 
 --   SELECT @str='UPDATE ' +@tablename+ ' set amount=round(amount,'+STR(@DecimalScale)+') where Remarks=rtrim(ltrim('''+@errormsg+'''))'
 --   PRINT @str
 --   EXECUTE(@str)
	IF (SELECT SysParam.EnableDateValidation FROM dbo.SysParam) = 1
	BEGIN
	 SELECT @str='UPDATE ' +@tablename+ '  set post=0 , 
	  remarks=remarks+N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','DateValidation',@lang,@LogonName),(case when @lang='A' then  N'تاريخ غير صحيح لهذا الجزاء' ELSE N'invalid date for this misconduct'  end))+ ''' FROM dbo.Mscondct WHERE LTRIM(RTRIM(Mscondct.MiscondName))=LTRIM(RTRIM(MiscName))
	and  post=1 and MiscDate not between isnull([MscondctFromDate], MiscDate)  and isnull( [MscondctToDate] ,MiscDate )  '
    PRINT @str
    EXECUTE(@str)
	END

IF EXISTS( SELECT * FROM NasUsers CROSS JOIN SysParam WHERE LogonName=@LogonName AND NasUsers.ApplySSGroups = 1 AND SysParam.EnableRoleValidation = 1)
BEGIN 
	DECLARE @mscRoles AS NVARCHAR(MAX)
	SELECT @mscRoles=dbo.ReportRoles(0,'Mscondct.MscondctRoles',EmpId ) FROM dbo.NasUsers WHERE LogonName=@LogonName
	select @str='UPDATE '+@tablename+' set post= 0 , remarks= ltrim(rtrim(remarks)) + N'' ' +LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','RoleValidation',@lang,@LogonName),(case when @lang=N'A' then N'التحقق من القائميين بالمهام' ELSE N'Check Role Validate for this misconduct'  end))))
	+''' FROM Mscondct WHERE '+@mscRoles+' and post=1 and LTRIM(RTRIM(Mscondct.MiscondName))=LTRIM(RTRIM(MiscName)) '
	EXECUTE(@str)
END

 
	

	select @str='UPDATE '+@tablename+' set  remarks=remarks+N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','MiscNameValidation',@lang,@LogonName),(case when @lang='A' then N'-اسم الجزاء غير صحيح' ELSE N' -Misconduct Name IS Invalid'  end))+ '''
	FROM '+@tablename+' temptable
	where temptable.MiscName not in (select '+CASE WHEN  @lang='A' THEN 'MiscondAName' ELSE 'MiscondName' END+' from Mscondct) and post=1'

	PRINT @str
	EXECUTE(@str)

	select @str='UPDATE '+@tablename+' set  remarks=remarks+N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','ActionNameValidation',@lang,@LogonName),(case when @lang='A' then N'-اسم الاجراء المتخذ غير صحيح' ELSE N' -Action Name IS Invalid'  end))+''' 
	FROM '+@tablename+' temptable
	where temptable.ActionName not in (SELECT '+CASE WHEN @lang='A' THEN 'adesc' ELSE 'edesc' END+'  FROM NasArrays WHERE arrayname =''misaction'') and post=1'

	PRINT @str
	EXECUTE(@str)


	select @str='UPDATE '+@tablename+' set  remarks=remarks+N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','AmountTypeValidation',@lang,@LogonName),(case when @lang='A' then N'-اسم نوع الغرامه غير صحيح' ELSE N' -AmountType Name IS Invalid'  end))+''' 
	FROM '+@tablename+' temptable
	where temptable.AmountType not in (SELECT  '+CASE WHEN @lang='A' THEN 'adesc' ELSE 'edesc' END+'  FROM NasArrays WHERE arrayname =''finetype'') and post=1'

	PRINT @str
	EXECUTE(@str)
	

	SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','StatusError',@lang,@LogonName),  (case when @lang='A' then N'إسم حالة غير صحيح' ELSE 'Not Valid Status'  end))
  	
	SELECT @str='UPDATE '+@tablename+' set  post = 0 ,remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))

	FROM '+@tablename+' temptable 
	LEFT JOIN SSDocumentStatus on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(SSDocumentStatus.SSDocAStatus))  else LTRIM(rtrim(SSDocumentStatus.SSDocStatus)) end ) = LTRIM(rtrim(temptable.Status))
	WHERE SSDocumentStatus.ssdocstatusno  is null'
	
	PRINT @str
	EXECUTE(@str)
	

	IF @EnableTextValidation = '1' 
	 BEGIN

	 DECLARE @InvestResCaption NVARCHAR(max)=N'' , @OtherDisciplineCaption NVARCHAR(max)=N'' ,@DescriptionCaption NVARCHAR(max)=N''

	 SELECT @InvestResCaption =  isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','InvistResult',@lang,@LogonName),N''),
	 @OtherDisciplineCaption = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','Otherdiscipline',@lang,@LogonName),N''),
	 @DescriptionCaption = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','Description',@lang,@LogonName),N'')


	 ----- OtherDiscipline
	 --SELECT @RegularExpressionError AS err
	SELECT @str='UPDATE '+@tablename+ N' set  remarks = rtrim(ltrim(remarks)) +  CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' - '' END +
	 N'''+@OtherDisciplineCaption+' '+@RegularExpressionError+N'''
	FROM '+@tablename+' temptable
	Where (temptable.post = 1 )
	and dbo.validateText(''Misconduct'',''OtherDiscipline'',ISNULL(temptable.Otherdiscipline,N'''')) = 0
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '

	PRINT @str
	EXECUTE(@str)



	----- InvestResult
		SELECT @str='UPDATE '+@tablename+ N' set  remarks = rtrim(ltrim(remarks)) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' - '' END + 
             N'''+@InvestResCaption+ ' '+@RegularExpressionError+N'''
	FROM '+@tablename+' temptable 
	Where (temptable.post = 1 ) and  dbo.validateText(''Misconduct'',''InvistResult'',ISNULL(temptable.InvistResult,N'''')) = 0 
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
	'

	PRINT @str
	EXECUTE(@str)

	----- Description
		SELECT @str='UPDATE '+@tablename+ N' set  remarks= rtrim(ltrim(remarks)) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' - '' END +
	 N'''+@DescriptionCaption+@RegularExpressionError+N''' 
	FROM '+@tablename+' temptable 
	Where (temptable.post = 1 ) and dbo.validateText(''Misconduct'',''Description'',ISNULL(temptable.Description,N'''')) = 0  
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	PRINT @str
	EXECUTE(@str)

	END
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	BEGIN 
		select @str='UPDATE '+@tablename+' set remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalMisconduct','MiscOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الجزاء' ELSE N'Check Org. Validation for this misconduct'  end))+ '''
		FROM '+@tablename+' temptable
		LEFT JOIN Mscondct on ltrim(rtrim(temptable.MiscName collate database_default))= case when '''+@lang+'''= ''e'' then  ltrim(rtrim(Mscondct.MiscondName collate database_default)) else ltrim(rtrim(Mscondct.MiscondAName collate database_default)) end
		where temptable.Post=1 
		and ( not exists ( select * from #OrgTree where Mscondct.MscondctOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Mscondct.MscondctOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
		EXECUTE(@str)
		print (@str) 
	END   

		select @str='UPDATE '+@tablename+' set post=0
	FROM '+@tablename+' temptable
	where LTRIM(RTRIM(temptable.remarks))<>'''''

	PRINT @str
	EXECUTE(@str)
	
		END
	----------------------------------------------------------------------------------------------------------------------------
	

		----- custom case WP_GetExternalNASUsers
	IF LTRIM(rtrim(@tabletype)) LIKE '%WP_GetExternalNASUsers%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalNASUsers_ar%'
	BEGIN

	-- check logonaname is empty
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','CheckLogonName',@lang,@LogonName),
	                        case when @lang='A' then N'اسم تسجيل الدخول غير صالح' ELSE 'Invalid LogonName'  end)

	select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0
				FROM '+@tablename+' t
			 WHERE  isnull(t.logonName,'''')='''' and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '

  exec (@str)


  --- check is logon name is Duplicated 
   SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','DuplicateLogonName',@lang,@LogonName),
                        case when @lang='A' then N'اسم المستخدم مكرر' ELSE 'Duplicate Logon Name'  end)

	select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0
				FROM '+@tablename+' t
				where ltrim(rtrim(t.LogonName)) in (select ltrim(rtrim(tt.LogonName)) FROM '+@tablename+' tt 
				--where tt.empid = t.empid 
				GROUP BY LogonName having COUNT(LogonName)>1)
			   and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 
			'
			 --WHERE ltrim(rtrim(t.empid)) not in(select EmployeeId from EmpAssignment em inner join NasUsers ns on em.EmpId=ns.EmpId where ltrim(rtrim(LogonName))=ltrim(rtrim(t.LogonName)))
			 -- and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
			
  exec (@str)

	
   --end
  	-- set password = '' when upload file
		select @str='UPDATE '+@tablename+'  set password='''' 
				FROM '+@tablename+' t
			 WHERE   (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end)   '
		       exec (@str)

			   --check the usergroup
			   SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','CheckUserGroup',@lang,@LogonName),
			                   case when @lang='A' then N'مجموعة مستخدمي النظام غير صالحة' ELSE 'Invalid UserGroup'  end)

				select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0  
				FROM '+@tablename+' t'  +
				' WHERE ltrim(rtrim(t.usergroup)) not in
				(select case when '''+@lang+''' =  ''E'' then ltrim(rtrim(n.UserGroupName)) else ltrim(rtrim(n.UserGroupAName)) end from usergroup n)
				 and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end)  and t.post=1 '
 		       exec (@str)

    declare @uncomm as int =0 , @StrTempTable as nvarchar(max)
	
	    select @uncomm=ConfigValue from SysParamConfig where ConfigID='NasUsersUncommitted'

		  --@errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('RegisterUser','1',@Lang),
		  --(CASE WHEN @Lang='E' THEN 'User Name already exists.' ELSE N'اسم المستخدم موجود بالفعل' END))

		  		--SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('RegisterUser','1',@lang)
      --              ,(case when @lang='A' then N'اسم المستخدم موجود بالفعل' ELSE 'User Name already exists.'  end))

	   --       SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','AlreadyExists',@lang,@LogonName),'')
				--		print 'update nass user'
				--select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0  ,UserPWD=''''
				--FROM '+@tablename+' t
				--inner join  NasUsers n on ltrim(rtrim(n.LogonName))=ltrim(rtrim(t.LogonName)) '  +
			 --  ' inner join  UserGroup ug on ltrim(rtrim(t.usergroup)) =
				--case when '''+@lang+''' = ''E''    then ltrim(rtrim(ug.UserGroupName)) else ltrim(rtrim(ug.UserGroupAName)) end         '+
				--' WHERE n.UserGroup=ug.UserGroup and   (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
				--print @str
 		 --      exec (@str)
			

			 --  select @StrTempTable='Select LogonName FROM '+@tablename+' t
			 --  WHERE   (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '

			 --   exec (@StrTempTable)

				--print '------' + @StrTempTable
			   

		if @uncomm =1 
			begin
			 SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','AlreadyExistsWithDifferentEmpid',@lang,@LogonName),
			                      case when @lang='A' then N'اسم المستخدم لا يطابق رقم الموظف' ELSE 'Logon Name does not match Employee Id'  end)

			select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0
						FROM '+@tablename+' t
					inner join dbo.NasUsersUncommitted nu on ltrim(rtrim(t.LogonName))=ltrim(rtrim(nu.LogonName))
					LEFT JOIN dbo.EmpAssignment ea ON ea.EmpId = nu.EmpId
					where ea.EmployeeId<>t.empid
					and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 
					'
					 --WHERE ltrim(rtrim(t.empid)) not in(select EmployeeId from EmpAssignment em inner join NasUsers ns on em.EmpId=ns.EmpId where ltrim(rtrim(LogonName))=ltrim(rtrim(t.LogonName)))
					 -- and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
		        exec (@str)

			  SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','SubmittedRequestExists',@lang,@LogonName),
			                          case when @lang='A' then N'يوجد بالفعل طلب تم إرساله لاسم تسجيل الدخول هذا' ELSE 'A submitted request for this Logon Name already exists'  end)

			   select @str='UPDATE '+@tablename+'  set remarks=ltrim(rtrim(remarks)) + char(13) + rtrim(ltrim(N'''+@errormsg+''')) ,post=0 ,password='''' 
				FROM '+@tablename+' t
				inner join  NasUsersUncommitted n on ltrim(rtrim(n.LogonName)) COLLATE DATABASE_DEFAULT=ltrim(rtrim(t.LogonName)) COLLATE DATABASE_DEFAULT'  +
				' left join  UserGroup ug on ltrim(rtrim(t.usergroup)) =
				case when '''+@lang+''' = ''E''    then ltrim(rtrim(ug.UserGroupName)) else ltrim(rtrim(ug.UserGroupAName)) end         '+
				' WHERE ((n.UserGroup=ug.UserGroup ) OR (t.UserGroup is NULL) ) and n.DocumentStatus IN(5) and   (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
		        exec (@str)

			   SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','AlreadyExists',@lang,@LogonName),
			                    case when @lang='A' then N'اسم تسجيل الدخول موجود بالفعل'  ELSE 'Logon Name already Exists'  end)


			  select @str='UPDATE '+@tablename+'  set remarks=ltrim(rtrim(remarks)) + char(13) + rtrim(ltrim(N'''+@errormsg+''')) ,post=0 ,password='''' 
				FROM '+@tablename+' t
				inner join  NasUsersUncommitted n on ltrim(rtrim(n.LogonName)) COLLATE DATABASE_DEFAULT=ltrim(rtrim(t.LogonName)) COLLATE DATABASE_DEFAULT'  +
				' left join  UserGroup ug on ltrim(rtrim(t.usergroup)) =
				case when '''+@lang+''' = ''E''    then ltrim(rtrim(ug.UserGroupName)) else ltrim(rtrim(ug.UserGroupAName)) end         '+
				' WHERE ((n.UserGroup=ug.UserGroup ) OR (t.UserGroup is NULL) ) and n.DocumentStatus IN(1) 
				and EffectiveDate=(select top 1 nu.EffectiveDate from NasUsersUncommitted nu
			where nu.LogonName=n.LogonName
			order by nu.EffectiveDate desc)
				and   (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
		     exec (@str)
			 --new case (2023/5/30)
			 --new case when logon name doesn't in nasuser & nasuseruncommited but empid is found in nasuser & nasuseruncommited -->show the following error
			  SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','AlreadyExistsWithDifferentEmpid',@lang,@LogonName),
			      case when @lang='A' then  N'اسم المستخدم لا يطابق رقم الموظف' ELSE 'Logon Name does not match Employee Id'  end)
					select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0
						FROM '+@tablename+' t
					inner join dbo.NasUsersUncommitted nu on ltrim(rtrim(t.LogonName))=ltrim(rtrim(nu.LogonName))
					LEFT JOIN dbo.EmpAssignment ea ON ea.EmpId = nu.EmpId
					where ea.EmployeeId<>t.empid and ltrim(rtrim(t.LogonName)) not in(select LogonName from NasUsers)
					and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 
					'
					 --WHERE ltrim(rtrim(t.empid)) not in(select EmployeeId from EmpAssignment em inner join NasUsers ns on em.EmpId=ns.EmpId where ltrim(rtrim(LogonName))=ltrim(rtrim(t.LogonName)))
					 -- and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
					 print('ahmdad++1')
					 print(@str)
					 print(@errormsg);
		        exec (@str)
			 ---
			end
		else
			begin
			  -- check logonname and his empid are exist in db
			 SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','AlreadyExistsWithDifferentEmpid',@lang,@LogonName),
			                      case when @lang='A' then N'اسم المستخدم لا يطابق رقم الموظف' ELSE 'Logon Name does not match Employee Id'  end)
					
					select @str='UPDATE '+@tablename+'  set remarks=rtrim(ltrim(N'''+@errormsg+''')) ,post=0
						FROM '+@tablename+' t
					inner join dbo.NasUsers nu on ltrim(rtrim(t.LogonName))=ltrim(rtrim(nu.LogonName))
					LEFT JOIN dbo.EmpAssignment ea ON ea.EmpId = nu.EmpId
					where ea.EmployeeId<>t.empid
					and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 
					'
					 --WHERE ltrim(rtrim(t.empid)) not in(select EmployeeId from EmpAssignment em inner join NasUsers ns on em.EmpId=ns.EmpId where ltrim(rtrim(LogonName))=ltrim(rtrim(t.LogonName)))
					 -- and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1 '
		        exec (@str)
					   SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('NasUsersUncommitted','AlreadyExists',@lang,@LogonName),
			                    case when @lang='A' then N'اسم تسجيل الدخول موجود بالفعل' ELSE 'Logon Name already Exists'  end)

				select @str='UPDATE '+@tablename+'  set remarks=ltrim(rtrim(remarks)) + char(13) + rtrim(ltrim(N'''+@errormsg+''')) ,post=0  ,password=''''
				FROM '+@tablename+' t
				inner join  NasUsers n on ltrim(rtrim(n.LogonName)) COLLATE DATABASE_DEFAULT=ltrim(rtrim(t.LogonName)) COLLATE DATABASE_DEFAULT'  +
			   ' left join  UserGroup ug on ltrim(rtrim(t.usergroup)) =
				case when '''+@lang+''' = ''E''    then ltrim(rtrim(ug.UserGroupName)) else ltrim(rtrim(ug.UserGroupAName)) end         '+
				' WHERE ((n.UserGroup=ug.UserGroup ) OR (t.UserGroup is NULL) ) and   (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and t.post=1'
 		       exec (@str)		
	      
			end

		
	END

	------------------------------- ExternalSystemsBatchPosting --------------------------------


	------------------------------ Housing Items ----------------------------------------
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalHousingItems' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalHousingItems_ar'
BEGIN		
	DECLARE @HKItemError NVARCHAR(MAX), @CountError NVARCHAR(MAX) , @RecievedDateError NVARCHAR(max), @ReturnDateError NVARCHAR(max) ,@DateDiffError NVARCHAR(max), @DuplicatedRecordsError NVARCHAR(MAX)
	SELECT @HKItemError = ISNULL(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalhousingitems','hkitemerror',@lang,@LogonName),CASE @lang  WHEN 'A' THEN N'اسم بند التسكين غير صحيح' ELSE 'Invalid housing item name' END)
	SELECT @CountError = ISNULL(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalhousingitems','CountError',@lang,@LogonName),CASE @lang  WHEN 'A' THEN N'خانة العدد يجب أن تكون أرقام صحيحة' ELSE 'Count is possitive numeric field' END)
	SELECT @RecievedDateError = ISNULL(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalhousingitems','RecievedDateError',@lang,@LogonName),CASE @lang  WHEN 'A' THEN N'تاريخ الاستلام فارغ أو ليس بالشكل الصحيح' ELSE 'Recieved Date is empty or in incorrect format' END)
	SELECT @ReturnDateError = ISNULL(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalhousingitems','ReturnDateError',@lang,@LogonName),CASE @lang  WHEN 'A' THEN N'تاريخ الاسترداد ليس بالشكل الصحيح' ELSE 'Return Date is in incorrect format' END)
	SELECT @DateDiffError =ISNULL(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalhousingitems','DateDiffError',@lang,@LogonName),CASE @lang  WHEN 'A' THEN N'تاريخ الاسترداد يجب أن يكون أكبر من تاريخ الاستلام' ELSE 'Return date should be grater than Recieved Date' END)
	SELECT @DuplicatedRecordsError = ISNULL(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalhousingitems','DuplicatedRecordsError',@lang,@LogonName),CASE @lang  WHEN 'A' THEN N'لا يمكن اضافة نفس بند التسكين لنفس الموظف فى نفس تاريخ الإستلام' ELSE 'Can not insert the same item to the same employee in the same recieved date' END)
	
	
	 --Dublicated records
     SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks =LTRIM(RTRIM(Remarks)) +case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end+ + N''' + LTRIM(RTRIM(@DuplicatedRecordsError)) + '''
                    FROM ' + @tablename + ' Tmptbl 
                    INNER JOIN EmpAssignment ON Tmptbl.Empid collate database_default=empassignment.EmployeeId collate database_default
                    INNER JOIN HKItems ON  RTRIM(LTRIM(Tmptbl.HKItem collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang))    WHEN 'A' THEN 'RTRIM(LTRIM(HKItems.HKItemAName collate database_default))' ELSE 'RTRIM(LTRIM(HKItems.HKItemName collate database_default))' END +
                    'INNER JOIN EmpHKItems ON ((EmpHKItems.EmpID = EmpAssignment.EmpID) AND (Tmptbl.RecievedDate = EmpHKItems.RecievedDate) AND (EmpHKItems.HKItem = HKItems.HKItem))                    
                    WHERE Tmptbl.Post=1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
    
	PRINT @Str
	EXEC(@Str) 
	-- Validate HKItemname
	SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + N''' + LTRIM(RTRIM(@HKItemError)) + '''
	                FROM ' + @tablename + ' Tmptbl
	               LEFT JOIN HKItems ON  RTRIM(LTRIM(Tmptbl.HKItem collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang))    WHEN 'A' THEN 'RTRIM(LTRIM(HKItems.HKItemAName collate database_default))' ELSE 'RTRIM(LTRIM(HKItems.HKItemName collate database_default))' END +
	               ' WHERE HKItems.HKItem IS NULL and Tmptbl.Post=1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	PRINT @str
	exec(@Str) 
	-- Validate Count 
	SELECT @Str = 'UPDATE ' + @tablename +' SET HKCount = 1  FROM ' + @tablename + ' Tmptbl WHERE (HKCount IS NULL OR HKCount = 0)  and Tmptbl.Post=1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	EXEC (@Str)            
	SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end  + N''' + LTRIM(RTRIM(@CountError)) + '''
	                   FROM ' + @tablename + ' Tmptbl WHERE HKCount < 0 and Tmptbl.Post=1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '         
	
	PRINT @Str
	EXEC(@Str)
	--Validate RecievedDate 
	SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end+ N''' + LTRIM(RTRIM(@RecievedDateError)) + '''
	                   FROM ' + @tablename + ' Tmptbl WHERE RecievedDate is null and Tmptbl.Post=1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '   
   
   PRINT @Str
    exec(@Str)	 
 
    --Compare RecievedDate and ReturnDate
    SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) +case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + N''' + LTRIM(RTRIM(@DateDiffError)) + '''
                       FROM ' + @tablename + ' Tmptbl WHERE isnull(ReturnDate,RecievedDate) < RecievedDate and Tmptbl.Post=1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
   
   PRINT @Str
    EXEC(@Str) 

	IF @EnableTextValidation = '1' 
	BEGIN
		DECLARE @RecievedText AS NVARCHAR(max), @ReturnText AS NVARCHAR(max) , @OtherInfo AS NVARCHAR(max), @HKItemStatus AS NVARCHAR(max)
		--SELECT @RegularExpressionError = ISNULL(CASE WHEN @lang = 'A' THEN RegExAMessage WHEN @lang = 'F' THEN RegEXFMessage ELSE RegExmessage END , CASE @lang  WHEN 'A' THEN N'لا يسمح بإدخال هذة الرموز (+،-،@،=)' ELSE 'Cannot insert these symbols (+,-,@,=)' END) FROM dbo.SysParamRegEX WHERE RegEXID = 'SQLFields.ValidateInput'
		SELECT @RecievedText = ISNULL(dbo.Hits_GetDCCaptionWzLogon('EmpHKItems', 'RecievedText', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات الأستلام' ELSE 'Recieved Text' END)
		SELECT @ReturnText = ISNULL(dbo.Hits_GetDCCaptionWzLogon('EmpHKItems', 'ReturnText', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات الارجاع' ELSE 'Return Text' END) 
		SELECT @OtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('EmpHKItems', 'HKITEMINFO', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات اخرى' ELSE 'Other Information' END)
		SELECT @HKItemStatus = ISNULL(dbo.Hits_GetDCCaptionWzLogon('EmpHKItems', 'HKITEMSTATUS', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الحالة' ELSE 'Status' END)


		--Validate Recieved Text
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) +case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + N''' + @RecievedText + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''EmpHKItems'', ''RecievedText'', RecievedText) = 0 
                       and Tmptbl.Post = 1 
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		
		PRINT @Str
		EXEC(@Str) 
		--Validate Return Text
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end  + N''' + @ReturnText + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''EmpHKItems'', ''ReturnText'', ReturnText) = 0 
                       and Tmptbl.Post = 1 
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		
		PRINT @Str
		EXEC(@Str)

		--Validate Other Info
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end  + N''' + @OtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''EmpHKItems'', ''HKItemInfo'', HKItemInfo) = 0 
                       and Tmptbl.Post = 1 
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		
		PRINT @Str
		EXEC(@Str)

		--Validate Asset Item Status
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end  + N''' + @HKItemStatus + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''EmpHKItems'', ''HKItemStatus'', HKItemStatus) = 0 
                       and Tmptbl.Post = 1 
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
	
		PRINT @Str
		EXEC(@Str)
		
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	select @str='UPDATE '+@tablename+' set  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHousingItems','HKItemsOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا العنصر' ELSE N'Check Org. Validation for this HKItems'  end))+ '''
	FROM '+@tablename+' temptable
	 LEFT JOIN HKItems ON  RTRIM(LTRIM(temptable.HKItem collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang)) WHEN 'A' THEN 'RTRIM(LTRIM(HKItems.HKItemAName collate database_default))' ELSE 'RTRIM(LTRIM(HKItems.HKItemName collate database_default))' END +'
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where HKItems.HKItemsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or HKItems.HKItemsOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	end    
		
		
	END                                           
END
-------------------------------------------------------------------------------------
--------------------------------------- GetExternalObjective ------------------------
 
IF ltrim(rtrim(@tabletype))  LIKE '%WP_GetExternalObjective%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalObjective_ar%'
BEGIN	
--SELECT 1 
	DECLARE @strObj AS nvarchar(max)
	DECLARE @DateFormatObj AS INT 
	DECLARE @errormsgObj AS nvarchar(MAX)
	SET @errormsgObj=''

    SELECT @DateFormatObj= dateformat FROM SysParam 
    IF @DateFormatObj=1 SET @DateFormatObj=103
    IF @DateFormatObj=2 SET @DateFormatObj=101
    IF @DateFormatObj=0 SET @DateFormatObj=111
	
	

	-- --- Check Duplicate Record
	--SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Duplicate Record',@lang),(case when @lang='A' then N'الموظف مكرر' ELSE N'Duplicate Record'  end))                          
	--select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsgObj+'''))+'' / ''+rtrim(ltrim(remarks))  , Post=0
	--FROM '+@tablename+' temptable
	--WHERE  (temptable.post=1) and isnull(temptable.empid,''0'') <> ''0''  
	--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	--and temptable.empid in (SELECT t.empid
 --  FROM '+@tablename+' t  GROUP BY empid having COUNT(empid)>1) '		
	----PRINT 'duplicate employees'
	--PRINT @strObj
	--EXECUTE(@strObj)



  --SET Default Value for From Date
	select @strObj='UPDATE '+@tablename+' set FromDate='''+ CONVERT(NVARCHAR,(cast (YEAR(GETDATE()) AS nvarchar(4)) + '/01/01' ),@DateFormatObj) +''' 
	FROM '+@tablename+' temptable
	where (temptable.post=1) and (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 	+ ' end)
	and (isnull(temptable.FromDate,'''') = '''') '	
	PRINT @strObj
	
	EXECUTE(@strObj)
	
	--SET Default Value for  Apprassial Start Date
	select @strObj='UPDATE '+@tablename+' set  AppraisalStartDate =''' + CONVERT(NVARCHAR,(cast (YEAR(GETDATE()) AS nvarchar(4)) + '/01/01' ),@DateFormatObj) + '''
	FROM '+@tablename+' temptable
	where (temptable.post=1) and  (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 	+ ' end )
    and  (isnull(temptable.AppraisalStartDate,'''') = '''')  '	
	PRINT @strObj
	EXECUTE(@strObj)
	
	--SET Default Value for  Apprassial End Date 
	select @strObj='UPDATE '+@tablename+' set AppraisalEndDate = ''' +CONVERT(NVARCHAR,(cast (YEAR(GETDATE()) AS nvarchar(4)) + '/12/31' ),@DateFormatObj) +'''
	FROM '+@tablename+' temptable
	where (temptable.post=1) and  (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 	+ ' end )  
	and   (isnull(temptable.AppraisalEndDate,'''') = '''')  '	
	PRINT @strObj
	EXECUTE(@strObj)
	
	-- Check Objective Category 
    SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective','ObjCatError',@lang,@LogonName),(case when @lang='A' then N'فئة الهدف غير صالحة ' ELSE 'Not Valid Objective Category'  end))                      
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + rtrim(ltrim(N'''+@errormsgObj+'''))
  
	FROM '+@tablename+' temptable
	left join  Objectives on ((CASE WHEN '''+ @lang +''' = ''A''   then LTRIM(rtrim(Objectives.ObjectiveAName collate database_default))  else LTRIM(rtrim(Objectives.ObjectiveName collate database_default)) end )  = LTRIM(rtrim(temptable.ObjectiveCategory collate database_default)))  AND (Objectives.ObjectiveParentId is  Null)
    where (temptable.post=1) and  (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end )
	and (temptable.ObjectiveCategory='''' or (CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(Objectives.ObjectiveAName))  else LTRIM(rtrim(Objectives.ObjectiveName)) end )  is  null )'		
	--PRINT @str1 and isnull(position,'''')=''''  
	PRINT  'Error 1 ...'+@strObj
	EXECUTE(@strObj)	

		-- Check Objective Name 
    SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective','ObjNameError',@lang,@LogonName),(case when @lang='A' then N'اسم الهدف غير صالح ' ELSE 'Not Valid Objective Name'  end))                
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + rtrim(ltrim(N'''+@errormsgObj+'''))  
	FROM '+@tablename+' temptable
	left join  Objectives on (CASE WHEN ''' + @lang + ''' = ''A''   then LTRIM(rtrim(Objectives.ObjectiveAName collate database_default))  else LTRIM(rtrim(Objectives.ObjectiveName collate database_default)) end )  = LTRIM(rtrim(temptable.Objective collate database_default))
	where (temptable.post=1) and  isnull(temptable.Objective,'''')='''' 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	PRINT  'Error 2 ...'+@strObj
	EXECUTE(@strObj)	

		-- Check Objective Status 
	SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective','ObjStatusError',@lang,@LogonName),(case when @lang='A' then N'الحالة غير صالحة' ELSE 'Not Valid Objective Status'  end))                      
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end +rtrim(ltrim(N'''+@errormsgObj+''')) 
  
	FROM '+@tablename+' temptable
	left join  SSDocumentStatus on (CASE WHEN ''' + @lang + '''= ''A''   then LTRIM(rtrim(SSDocumentStatus.SSDocAStatus))  else LTRIM(rtrim(SSDocumentStatus.SSDocStatus)) end )  = LTRIM(rtrim(temptable.ObjectiveStatus))
	where (temptable.post=1) and  (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end )
	and (temptable.ObjectiveStatus='''' or (CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(SSDocumentStatus.SSDocAStatus))  else LTRIM(rtrim(SSDocumentStatus.SSDocStatus)) end )  is  null )'	
	--PRINT @str1 and isnull(position,'''')=''''  
	PRINT  'Error 1 ...'+@strObj
	EXECUTE(@strObj)	
	
	
	--Check hiredate > Assign from date
	PRINT 'hiredate'
	SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('COMMON','ErrMsgFHireDate',@lang,@LogonName),(case when @lang='A' then N'(أدخل التاريخ الصحيح (تاريخ الادخال اقل من بداية تاريخ التعيين' ELSE 'Enter a valid date ( from date is before First Hire date)'  end))     
	PRINT @errormsgObj
	PRINT 'test '+ STR(@DateFormatObj)                 
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + rtrim(ltrim(N'''+@errormsgObj+'''))

	FROM '+@tablename+' temptable 
	inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default
	left join profile on profile.profileid=empassignment.empid
	where (temptable.post=1) and  isnull(convert(SMALLDATETIME,LTRIM(RTRIM(PROFILE.FirstHiredDate)),'+str(@DateFormatObj)+'), convert(SMALLDATETIME,LTRIM(RTRIM(EmpAssignment.HireDate)),'+str(@DateFormatObj)+')) > convert(SMALLDATETIME,LTRIM(RTRIM(temptable.FromDate)),'+str(@DateFormatObj)+')
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	
	PRINT  'Error 1 ...'+@strObj
	EXECUTE(@strObj)	
	

	--Check Assign from date > Appraisal Start Date
	SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective','ObjFDate>ObjAppStDate',@lang,@LogonName),(case when @lang='A' then N'إدخل التاريخ الصحيح(تاريخ بداية التقييم قبل تاريخ البدء )' ELSE 'Enter a valid date (Apprasial Start Date is before From Date)'  end))                      
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + rtrim(ltrim(N'''+@errormsgObj+'''))

	FROM '+@tablename+' temptable 
	where  (temptable.post=1) and convert(SMALLDATETIME,LTRIM(RTRIM(temptable.FromDate)),'+str(@DateFormatObj)+') > convert(SMALLDATETIME,LTRIM(RTRIM(temptable.AppraisalStartDate)),'+str(@DateFormatObj)+')
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	--PRINT @str1 and isnull(position,'''')=''''  
	PRINT  'Error 1 ...'+@strObj
	EXECUTE(@strObj)	


	--Check Assign from date> ISNULL(End Date,From Date)
	SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective','ObjFDate>ObjEDate',@lang,@LogonName),(case when @lang='A' then N'إدخل التاريخ الصحيح(تاريخ الإنتهاء قبل تاريخ البدء )' ELSE 'Enter a valid date (End Date is before From Date)'  end))                      
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + rtrim(ltrim(N'''+@errormsgObj+'''))

	FROM '+@tablename+' temptable 
    where (temptable.post=1) and  convert(SMALLDATETIME,LTRIM(RTRIM(temptable.FromDate)),'+str(@DateFormatObj)+') > isnull(convert(SMALLDATETIME,LTRIM(RTRIM(temptable.EndDate)),'+str(@DateFormatObj)+'),convert(SMALLDATETIME,LTRIM(RTRIM(temptable.FromDate)),'+str(@DateFormatObj)+'))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	--PRINT @str1 and isnull(position,'''')=''''  
	PRINT  'Error 1 ...'+@strObj
	EXECUTE(@strObj)	
	
	--check Appraisal Start Date > ISNULL (Appraisal End Date,Appraisal Start Date)  
	SELECT @errormsgObj= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective','ObjAppStDate>ObjAppEnDate',@lang,@LogonName),(case when @lang='A' then N'إدخل التاريخ الصحيح(تاريخ نهاية التقييم قبل تاريخ بداية التقييم )' ELSE 'Enter a valid date (Apprasial End Date is before Apprasial Start Date)'  end))                      
	select @strObj='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + rtrim(ltrim(N'''+@errormsgObj+'''))
 
	FROM '+@tablename+' temptable 
	where (temptable.post=1) and  convert(SMALLDATETIME,LTRIM(RTRIM(temptable.AppraisalStartDate)),'+str(@DateFormat)+') > isnull(convert(SMALLDATETIME,LTRIM(RTRIM(temptable.AppraisalEndDate)),'+str(@DateFormatObj)+'),convert(SMALLDATETIME,LTRIM(RTRIM(temptable.AppraisalStartDate)),'+str(@DateFormatObj)+'))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	--PRINT @str1 and isnull(position,'''')=''''  
	PRINT  'Error 1 ...'+@strObj
	EXECUTE(@strObj)	

	
	IF @EnableTextValidation = '1'
	BEGIN
		DECLARE @ObjNameCap NVARCHAR(max) = N'' 
		SELECT @ObjNameCap = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective', 'ObjectiveName', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'اسم الهدف' ELSE 'Objective Name' END)

		---- Validate ObjectiveName
		SELECT @strObj = 'UPDATE ' + @tablename + '  SET Remarks = rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + N''' + @ObjNameCap + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) +'''
                       FROM ' + @tablename + ' Tmptbl 
		                  WHERE dbo.validateText(''Objectives'', ''ObjectiveName'', Tmptbl.Objective) = 0 
		                  and Tmptbl.Post = 1 
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @strObj
		EXEC(@strObj) 
		
	    DECLARE @DescriptionCap NVARCHAR(max) = N'' 
		SELECT @DescriptionCap = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalObjective', 'Description', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الوصف' ELSE 'Description' END)

		---- Validate Description
		SELECT @strObj = 'UPDATE ' + @tablename + '  SET Remarks =  rtrim(ltrim(remarks)) + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + N''' + @DescriptionCap + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) +'''
                          FROM ' + @tablename + ' Tmptbl 
		                  WHERE dbo.validateText(''Objectives'', ''ObjectiveText'', Tmptbl.Description) = 0 
		                  and Tmptbl.Post = 1 
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @strObj
		EXEC(@strObj) 
	END		
END
-------------------------------------------------------------------------------------
----------------------GetExternalDocuments----------------------
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalDocuments' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalDocuments_ar'
	BEGIN
		DECLARE @DateFormatDoc AS INT
		SELECT @DateFormatDoc= dateformat FROM SysParam 
		IF @DateFormatDoc=0 SET @DateFormatDoc=111
		IF @DateFormatDoc=1 SET @DateFormatDoc=103
		IF @DateFormatDoc=2 SET @DateFormatDoc=101

		--Check of Document Name
		SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments','docNameError',@lang,@LogonName),(case when @lang='A' then N'اسم المستند غير صحيح' ELSE 'Not Valid Document Name'  end))
		SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg+''')) +'' / ''+rtrim(ltrim(remarks))--, post=0  
		FROM '+@tablename+' temptable
		left join Document on LTRIM(rtrim((CASE WHEN ''' + @lang + ''' = ''A'' then Document.DocAName collate database_default  else Document.DocName collate database_default end ))) = LTRIM(rtrim(temptable.DocumentName collate database_default))	 
		where (temptable.Row_Number = case when ' + ltrim(rtrim(STR(@Paycode))) + ' = 0 then temptable.Row_Number else ' +  ltrim(rtrim(STR(@Paycode))) + ' end ) and (temptable.Post=1)
		and (isnull(temptable.DocumentName,'''') = '''' or (CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(Document.DocAName))  else LTRIM(rtrim(Document.DocName)) end )  is  null)'	
		PRINT @str
		PRINT 'docNameError'
		EXECUTE(@str)
		
		--Check of Document Status
		SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments','docStatusError',@lang,@LogonName),(case when @lang='A' then N'حالة المستند غير صحيحة' ELSE 'Not Valid Status'  end))
		select @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg+'''))+ '' / ''+rtrim(ltrim(remarks))--, post=0  
		FROM '+@tablename+' temptable
		left join NasArrays on  arrayname LIKE ''%docStatus%'' and (CASE WHEN ''' + @lang + '''= ''A''   then LTRIM(rtrim(NasArrays.adesc collate database_default))  else LTRIM(rtrim(NasArrays.edesc collate database_default)) end )  = LTRIM(rtrim(temptable.DocumentStatus collate database_default))
		where (temptable.Row_Number = case when ' + ltrim(rtrim(STR(@Paycode))) + ' = 0 then temptable.Row_Number else ' + ltrim(rtrim(STR(@Paycode))) + ' end ) and (temptable.Post=1)
		and (isnull(temptable.DocumentStatus,'''') = '''' or (CASE WHEN ''' + @lang + ''' = ''A''   then LTRIM(rtrim(NasArrays.adesc))  else LTRIM(rtrim(NasArrays.edesc)) end )  is  null)'
		PRINT @str
		PRINT 'docStatusError'
		EXECUTE(@str)	

		--Check Null Document Date
		SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments','nullDocDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ المستند لا يمكن ان يكون بلا قيمه ' ELSE N'Document Date cannot be empty'  end))                    
		select @str = 'UPDATE ' + @tablename +' set remarks=rtrim(ltrim(N'''+@errormsg+'''))+'' / ''+rtrim(ltrim(remarks))--, post=0
        FROM ' + @tablename + '  temptable  
		WHERE (temptable.Row_Number = case when ' + ltrim(rtrim(STR(@Paycode))) + ' = 0 then temptable.Row_Number else ' + ltrim(rtrim(STR(@Paycode))) + ' end ) and (temptable.Post=1)
		and (temptable.DocumentDate is null or temptable.DocumentDate is null) '  
		PRINT @str
		PRINT 'nullDocDateError'
		EXECUTE(@str)	

		--Check if Issue Date > Expire Date
		SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments','expireDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ الإصدار أكبر من تاريخ الإنتهاء' ELSE 'Issue Date is greater than Expire Date'  end))                      
		select @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg+'''))+'' / ''+rtrim(ltrim(remarks))--, post=0
		FROM '+@tablename+' temptable 
		where  (temptable.Row_Number = case when ' + ltrim(rtrim(STR(@Paycode))) + ' = 0 then temptable.Row_Number else ' + ltrim(rtrim(STR(@Paycode))) + ' end ) and (temptable.Post=1)
		and (convert(SMALLDATETIME,LTRIM(RTRIM(temptable.IssueDate)),'+str(@DateFormatDoc)+') > convert(SMALLDATETIME,LTRIM(RTRIM(temptable.ExpireDate)),'+str(@DateFormatDoc)+'))'
		PRINT @str
		PRINT 'expireDateError'
		EXECUTE(@str)	
		
		if	@EnableOrgSetup =1 and @userOrganization <> ''
		begin
		select @str='UPDATE '+@tablename+' set  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments','DocumentOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الملف' ELSE N'Check Org. Validation for this Document'  end))+ '''
		FROM '+@tablename+' temptable
		 LEFT JOIN Document ON  RTRIM(LTRIM(temptable.DocumentName collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang)) WHEN 'A' THEN 'RTRIM(LTRIM(Document.DocAName collate database_default))' ELSE 'RTRIM(LTRIM(Document.DocName collate database_default))' END +'
		where temptable.Post=1 and ( not exists ( select * from #OrgTree where Document.DocumentOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Document.DocumentOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
		EXECUTE(@str)
		print (@str) 
		end
		
		IF @EnableTextValidation = '1'
		BEGIN
			
		    DECLARE @DocDescription NVARCHAR(max), @DocOtherInfo NVARCHAR(max), @DocRecievingInfo NVARCHAR(max), @DocumentNumber NVARCHAR(max)
			SELECT @DocDescription = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments', 'DocumentDesc', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'وصف المستند' ELSE 'DocumentDesc' END)
			,@DocOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments', 'OtherInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'OtherInfo' END)
			,@DocRecievingInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments', 'ReceivingInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'معلومات الاستلام' ELSE 'Receiving Info' END)
			,@DocumentNumber=ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalDocuments', 'DocumentNumber', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رقم المستند' ELSE 'Document Number' END)


			--DocumentNumber
			SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks =  N''' + @DocumentNumber + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks))
							FROM ' + @tablename + ' Tmptbl WHERE  dbo.validateText(''WP_GetExternalDocuments'', ''DocumentNumber'', DocumentNumber) = 0 and (Tmptbl.Post = 1 )  
							and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
			PRINT @str
			EXEC(@str) 
			
			----- DocDescription
			SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks =  N''' + @DocDescription + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks))
							FROM ' + @tablename + ' Tmptbl where dbo.validateText(''WP_GetExternalDocuments'', ''DocumentDesc'', DocumentDesc) = 0 and (Tmptbl.Post = 1 )  
							and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
			PRINT @str
			EXEC(@str) 

			----- DocOtherInfo
			SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks =  N''' + @DocOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks))
							FROM ' + @tablename + ' Tmptbl where dbo.validateText(''WP_GetExternalDocuments'', ''OtherInfo'', Otherinfo) = 0 and (Tmptbl.Post = 1  )  
							and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
			PRINT @str
			EXEC(@str) 

			---- DocRecievingInfo
			SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks =  N''' + @DocRecievingInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks))
							FROM ' + @tablename + ' Tmptbl WHERE  dbo.validateText(''WP_GetExternalDocuments'', ''ReceivingInfo'', ReceivingInfo) = 0 and (Tmptbl.Post = 1 )  
							and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
			PRINT @str
			EXEC(@str) 
			
		END
	END  
	
---------------------------------------------------------------------------------------------------------------------
--------------------------------------------GET EXTERNAL EVENTS------------------------------------------------------
IF LTRIM(RTRIM(@TableType)) like 'WP_GetExternalEvents%' OR LTRIM(RTRIM(@TableType)) like 'WP_GetExternalEvents_ar%'
BEGIN
	DECLARE @sub AS NVARCHAR(1)
	
	--Training Activity Name
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents', 'TrainingActivityNameError',@lang,@LogonName),
					(CASE WHEN @lang = 'A' THEN N'اسم برنامج التدريب غير صالح' ELSE 'Not Valid Training Activity Name' END))
	SELECT @str = 'update ' +@tablename + 'set remarks =  rtrim(ltrim(N'''+@errormsg+''')) + '' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingActivities 
		ON ltrim(rtrim(t.TrainingActivityName collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingActivities.TrainingActivityAName collate database_default' 
																ELSE N'TrainingActivities.TrainingActivityName collate database_default' END+N'))
	where (isnull(t.TrainingActivityName,'''') = '''' or (CASE WHEN ''E'' = ''A''   then LTRIM(rtrim(TrainingActivities.TrainingActivityAName)) 
														 else LTRIM(rtrim(TrainingActivities.TrainingActivityName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)' 

	PRINT @str
	EXECUTE(@str)
	-----------------------------------------------------------------------------------------------------------------------------------------
	----Training Event Status
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents','TrainingEventStatusError', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'حالات الدورات التدريبيه غير صالحه' ELSE 'Not Valid Training Event Status' END))
	SELECT @str = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingEventStatus 
		ON ltrim(rtrim(t.TrainingEventStatus collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingEventStatus.EventStatusAName collate database_default' 
																ELSE N'TrainingEventStatus.EventStatusName collate database_default' END+N'))
	where  (isnull(t.TrainingEventStatus,'''') = '''' or (CASE WHEN ''E'' = ''A''   then LTRIM(rtrim(TrainingEventStatus.EventStatusAName)) 
														 else LTRIM(rtrim(TrainingEventStatus.EventStatusName)) end )  is  null)
		and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)' 
	PRINT @str
	EXECUTE(@str)
	--------------------------------------------------------------------------------------------------------------------------------------------
	----Null Date
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents', 'DateError', @lang,@LogonName),
						 CASE WHEN @lang = 'A' THEN N'من/الي تاريخ غير صالح' ELSE 'Not Valid From/To Date' END)
	SELECT @str = 'update ' +@tablename +'set remarks=  rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	where (isnull(t.FromDate,'''')=''''  OR isnull(t.ToDate, '''')= '''')
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)'
	PRINT @str
	EXECUTE(@str)
	--------------------------------------------------------------------------------------------------------------------------------------------
	--To Date > From Date
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents', 'ToDate>FromDate', @lang,@LogonName),
						CASE WHEN @lang = 'A' THEN N'الي تاريخ > في تاريخ' ELSE 'To Date > From Date'END)
     SELECT @str = 'update '+@tablename +'set remarks = rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	where t.ToDate < t.FromDate and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)'
	PRINT @str
	EXECUTE(@str)
	--------------------------------------------------------------------------------------------------------------------------------------------
	----Training Event
	PRINT @tabletype
	SET @sub =  SUBSTRING(@tabletype, CHARINDEX('?',@tabletype,0 )+1, 2 )
	PRINT @sub
	IF @sub = 0
		BEGIN
			SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents','TrainingEventError', @lang,@LogonName),
							 (CASE WHEN @lang = 'A' THEN N'اسم التدريب غير صالح' ELSE 'Not Valid Training Event Name' END ))
			SELECT @str= 'update ' +@tablename+ 'set remarks= rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks)) 
			from ' +@tablename+' t 
			Left Join TrainingEvents 
			on ltrim(rtrim(t.TrainingEvent collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingEvents.TrainingEventAName collate database_default' 
																ELSE N'TrainingEvents.TrainingEventName collate database_default' END+N'))
			where (isnull(t.TrainingEvent,'''') = '''' or (CASE WHEN ''E'' = ''A''   then LTRIM(rtrim(TrainingEvents.TrainingEventAName)) 
														 else LTRIM(rtrim(TrainingEvents.TrainingEventName)) end )  is  null)
			and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)'
			PRINT @str
	EXECUTE(@str)
		END
	--------------------------------------------------------------------------------------------------------------------------------------------
	--Training Center
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents','TrainingCenterError', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'مركز التدريب غير صالح' ELSE 'Not Valid Training Center' END))
	SELECT @str = 'update ' +@tablename + 'set remarks=  rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingCenters 
		ON ltrim(rtrim(t.TrainingCenter collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingCenters.TrainingCenterAName collate database_default' 
																ELSE N'TrainingCenters.TrainingCenterName collate database_default' END+N'))
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(TrainingCenters.TrainingCenterANAme)) 
													 else LTRIM(rtrim(TrainingCenters.TrainingCenterName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.TrainingCenter <> '''') and (t.post = 1)' 

	PRINT @str
	EXECUTE(@str)
	----------------------------------------------------------------------------------------------------------------------------------------------
	--Enroll Status
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents','EnrollStatusError', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'اسم حاله الالتحاق غير صالحه' ELSE 'Not Valid Enroll Status Name' END))
	SELECT @str = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingEnrollStatus 
		ON ltrim(rtrim(t.EnrollStatusName collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingEnrollStatus.EnrollStatusAName collate database_default' 
																ELSE N'TrainingEnrollStatus.EnrollStatusName collate database_default' END+N'))
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(TrainingEnrollStatus.EnrollStatusAName)) 
													 else LTRIM(rtrim(TrainingEnrollStatus.EnrollStatusName)) end )  is  null)
	and  (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.EnrollStatusName <> '''') and (t.post = 1)'  

	PRINT @str
	EXECUTE(@str)
	----------------------------------------------------------------------------------------------------------------------------------------------
	--Currency
	SELECT @errormsg = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents','CurrencyError', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'العمله غير صالحه' ELSE 'Not Valid Currency' END))
	SELECT @str = 'update ' +@tablename + 'set remarks=  rtrim(ltrim(N'''+@errormsg+''')) +
		'' / ''+rtrim(ltrim(remarks))
	from ' +@tablename+' t 
	LEFT JOIN dbo.Currency 
		ON ltrim(rtrim(t.Currency collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'Currency.CurANAme collate database_default' 
																ELSE N'Currency.CurName collate database_default' END+N'))
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(Currency.CurAName)) 
													 else LTRIM(rtrim(Currency.CurName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.Currency <> '''') and (t.post = 1)'

	PRINT @str
	EXECUTE(@str)
	
		if	@EnableOrgSetup =1 and @userOrganization <> ''
		begin
		select @str='UPDATE '+@tablename+' set  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents','TrainingActivitiesOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا التدريب' ELSE N'Check Org. Validation for this Training Activity'  end))+ '''
		FROM '+@tablename+' temptable
		 LEFT JOIN TrainingActivities ON  RTRIM(LTRIM(temptable.TrainingActivityName collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang)) WHEN 'A' THEN 'RTRIM(LTRIM(TrainingActivities.TrainingActivityAName collate database_default))' ELSE 'RTRIM(LTRIM(TrainingActivities.TrainingActivityName collate database_default))' END +'
		where temptable.Post=1 and ( not exists ( select * from #OrgTree where TrainingActivities.TrainingActivitiesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TrainingActivities.TrainingActivitiesOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
		EXECUTE(@str)
		print (@str) 
		END
		
	
		IF @EnableTextValidation = '1'
	BEGIN

		DECLARE @EventsOtherInfo NVARCHAR(MAX)
		SELECT @EventsOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEvents', 'OtherInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'OtherInfo' END)
		SELECT @EventsOtherInfo,@RegularExpressionError
		----- EventsOtherInfo
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = N''' + @EventsOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks)) 
						FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.Otherinfo)),N'''') <> N''''  AND dbo.validateText(''EmpTraining'', ''OtherInfo'', Tmptbl.Otherinfo) = 0 and Tmptbl.Post = 1  
						and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		
		PRINT @str
		EXEC(@str) 

	END
	END

	-----------------------------------------Get External Additional Training----------------------------------------------------------------------------
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalAdditionalEvents' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalAdditionalEvents_ar'
BEGIN	

	DECLARE @str3 AS nvarchar(max)
	
	DECLARE @errormsg7 AS nvarchar(60)
	SET @errormsg7=''

	--Check of the Additional Training Name
	SELECT @errormsg7= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents','AdditionalTrainingMissing',@lang,@LogonName),(case when @lang='A' then N'بالرجاء ادخال اسم اضافة تدريب صحيح' ELSE N'Please Enter A Valid Additional Training Name'  end))
	select @str3='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg7+'''))+'' / ''+rtrim(ltrim(remarks)) 
	FROM '+@tablename+' t
	where isnull(AdditionalTraining,'''')='''' and (t.post = 1)
	and t.Row_Number = case when ' + str(@Paycode) + ' = 0 then t.Row_Number else ' + str(@Paycode) + ' end '	
	EXECUTE(@str3)

	----Null Date
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents', 'DateError', @lang,@LogonName),
						 CASE WHEN @lang = 'A' THEN N'من/الي تاريخ غير صالح' ELSE 'Not Valid From/To Date' END)
	SELECT @str3 = 'update ' +@tablename +'set remarks=  rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks)) 
	from ' +@tablename+' t 
	where (isnull(t.FromDate,'''')=''''  OR isnull(t.ToDate, '''')= '''')
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)'
	PRINT @str3
	EXECUTE(@str3)

	--To Date > From Date
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents', 'ToDate>FromDate', @lang,@LogonName),
						CASE WHEN @lang = 'A' THEN N'الي تاريخ < من تاريخ' ELSE 'To Date > From Date'END)
     SELECT @str3 = 'update '+@tablename +'set remarks = rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks)) 
	from ' +@tablename+' t 
	where t.ToDate < t.FromDate and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.post = 1)'
	PRINT @str3
	EXECUTE(@str3)

	-----------------------------------------------------------------------------------------------------------------------
	----Training Enroll Status
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents','InValid Enroll Status', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'بالرجاء ادخال حالة تسجيل سحيحة' ELSE 'Please Enter a Valid Enroll Status' END))
	SELECT @str3 = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks)) 
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingEnrollStatus 
		ON ltrim(rtrim(t.EnrollStatus collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingEnrollStatus.EnrollStatusAName collate database_default' 
																ELSE N'TrainingEnrollStatus.EnrollStatusName collate database_default' END+N'))
    
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(TrainingEnrollStatus.EnrollStatusAName)) 
													 else LTRIM(rtrim(TrainingEnrollStatus.EnrollStatusName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.EnrollStatus <> '''') and (t.post = 1)'
	PRINT @str3
	EXECUTE(@str3)


	----Check Training Methods
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents','InValid Training Method', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'بالرجاء ادخال اسلوب تدريب صحيح' ELSE 'Please Enter a Valid Training Method' END))
	SELECT @str3 = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks))   
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingMethods 
		ON ltrim(rtrim(t.Method collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingMethods.TrainingMethodAName collate database_default' 
																ELSE N'TrainingMethods.TrainingMethodName collate database_default' END+N'))
    
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(TrainingMethods.TrainingMethodAName)) 
													 else LTRIM(rtrim(TrainingMethods.TrainingMethodName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.Method <> '''') and (t.post = 1)'
	PRINT @str3
	EXECUTE(@str3)

	-----Check Currency
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents','InValid Currency', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'بالرجاء ادخال عملة صحيحة' ELSE 'Please Enter a Valid Currency' END))
	SELECT @str3 = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks))  
	from ' +@tablename+' t 
	LEFT JOIN dbo.Currency 
		ON ltrim(rtrim(t.Currency collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'Currency.CurAName collate database_default' 
																ELSE N'Currency.CurName collate database_default' END+N'))
    
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(Currency.CurAName)) 
													 else LTRIM(rtrim(Currency.CurName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.Currency <> '''') and (t.post = 1)'	


	PRINT @str3
	EXECUTE(@str3)

	----Check Training Plan
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents','InValid Training Plan', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'بالرجاء ادخال خطة تدريب صحيح' ELSE 'Please Enter a Valid Training plan' END))
	SELECT @str3 = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks))   
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingPlans 
		ON ltrim(rtrim(t.TrainingPlan collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingPlans.TrainingPlanAName collate database_default' 
																ELSE N'TrainingPlans.TrainingPlanName collate database_default' END+N'))
    
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(TrainingPlans.TrainingPlanAName)) 
													 else LTRIM(rtrim(TrainingPlans.TrainingPlanName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.TrainingPlan <> '''') and (t.post = 1)'	
	PRINT @str3
	EXECUTE(@str3)
	
	----Check Training Activity
	SELECT @errormsg7 = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents','InValid Training Activity', @lang,@LogonName),
						 (CASE WHEN @lang = 'A' THEN N'بالرجاء ادخال نشاط تدريب صحيح' ELSE 'Please Enter a Valid Training Activity' END))
	SELECT @str3 = 'update ' +@tablename + 'set remarks= rtrim(ltrim(N'''+@errormsg7+''')) +
		'' / ''+rtrim(ltrim(remarks))   
	from ' +@tablename+' t 
	LEFT JOIN dbo.TrainingActivities 
		ON ltrim(rtrim(t.TrainingActivity collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' 
																THEN N'TrainingActivities.TrainingActivityAName collate database_default' 
																ELSE N'TrainingActivities.TrainingActivityName collate database_default' END+N'))
    
	where ((CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(TrainingActivities.TrainingActivityAName)) 
													 else LTRIM(rtrim(TrainingActivities.TrainingActivityName)) end )  is  null)
	and (t.Row_Number = case when ' + STR(@Paycode) + ' = 0 then t.Row_Number else ' + STR(@Paycode) + ' end) and (t.TrainingActivity <> '''') and (t.post = 1)'	
	PRINT @str3
	EXECUTE(@str3)
	IF @EnableTextValidation = '1'
	BEGIN

		DECLARE @AddEventsOtherInfo NVARCHAR(MAX) ,@AddEventProvider NVARCHAR(MAX),@AddEventLocation NVARCHAR(MAX), @AddEventsAdditionalTraining NVARCHAR(MAX)
		SELECT @AddEventsAdditionalTraining = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents', 'AdditionalTraining', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'إضافة تدريب' ELSE 'AdditionalTraining' END)
		SELECT @AddEventsOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents', 'otherInformation', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'OtherInfo' END)
		SELECT @AddEventProvider = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents', 'Provider', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'مقدم التدريب' ELSE 'Provider' END)
		SELECT @AddEventLocation = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAdditionalEvents', 'Location', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'مكان التدريب' ELSE 'Location' END)


		SELECT @AddEventsOtherInfo,@RegularExpressionError
		
		----- EventsOtherInfo
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = N''' + @AddEventsAdditionalTraining + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks)) 
						FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.AdditionalTraining)),N'''') <> N''''  AND dbo.validateText(''EmpTraining'', ''AdditionalTraining'', Tmptbl.AdditionalTraining) = 0 
						and Tmptbl.Post = 1
						and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 


		----- EventsOtherInfo
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = N''' + @AddEventsOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks)) 
						FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.OtherInformation)),N'''') <> N''''  AND dbo.validateText(''EmpTraining'', ''OtherInfo'', Tmptbl.OtherInformation) = 0 
						and Tmptbl.Post = 1
						and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 


		----- Provider
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = N''' + @AddEventProvider + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks)) 
						FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.Provider)),N'''') <> N''''  AND dbo.validateText(''EmpTraining'', ''Provider'', Tmptbl.Provider) = 0 
						and Tmptbl.Post = 1 
						and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    

		PRINT @str
		EXEC(@str) 

		----- Location
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks =  N''' + @AddEventLocation + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+'' / ''+rtrim(ltrim(remarks)) 
						FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.Location)),N'''') <> N''''  AND dbo.validateText(''EmpTraining'', ''Location'', Tmptbl.Location) = 0 
						and Tmptbl.Post = 1 
						and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		
		PRINT @str
		EXEC(@str) 

	END
END
---------------------------------------------------------------------------------------------------------------------
------------------------------------------Get External Competencies------------------------------------
IF LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalCompetencies' OR LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalCompetencies_ar'
BEGIN

	--Check Competence Name
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalCompetencies','CompNameError',@lang,@LogonName),(case when @lang='A' then N'اسم الكفاءة غير صحيح' ELSE 'Not Valid Competence Name'  end))    
	
	select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks))+ char(13) + ltrim(rtrim(N''' + @errormsg +'''))
	FROM '+@tablename+' temptable 
	left join Competencies on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(Competencies.CompetenceAName collate database_default))  else LTRIM(rtrim(Competencies.CompetenceName collate database_default)) end ) = LTRIM(rtrim(temptable.CompetenceName collate database_default))	 
	
	where Competencies.Competence is null and temptable.Post=1 
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	PRINT @str
	PRINT 'CompetenceName'
	EXECUTE(@str)


	--Check Competence Level Name
	SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalCompetencies','CompLevelNameError',@lang,@LogonName),(case when @lang='A' then N'اسم المستوى غير صحيح' ELSE 'Not Valid Level Name'  end))    
	
	select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks))+ char(13) + ltrim(rtrim(N''' + @errormsg +'''))
	FROM '+@tablename+' temptable 
	left join Competencies on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(Competencies.CompetenceAName collate database_default))  else LTRIM(rtrim(Competencies.CompetenceName collate database_default)) end ) = LTRIM(rtrim(temptable.CompetenceName collate database_default))

	left join LevelsCompetence on Competencies.Competence = LevelsCompetence.Competence  
	AND case when ''' + @lang + ''' = ''E'' then ltrim(rtrim(LevelsCompetence.LevelName)) else ltrim(rtrim(LevelsCompetence.LevelAName)) end = ltrim(rtrim(temptable.CompetenceLevelName))	
	
	where LevelsCompetence.LevelName is null and temptable.Post=1 
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	PRINT @str
	PRINT 'CompetenceLevelName'
	EXECUTE(@str)
	
	--Check Competence Date
	SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalCompetencies','CompDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ الكفاءة ليس في صيغة التاريخ الصحيحة' ELSE 'Competence Date  is not in correct date format'  end))    
	
	select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks))+ char(13) + ltrim(rtrim(N''' + @errormsg +''')) , post=0  
	FROM '+@tablename+' temptable 		 
	
	where  isnull(temptable.CompetenceDate, '''') = '''' and temptable.Post=1 
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	PRINT @str
	PRINT 'CompetenceDate'
	EXECUTE(@str)
	
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	select @str='UPDATE '+@tablename+' set remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalCompetencies','CompetenciesOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا التدريب' ELSE N'Check Org. Validation for this Competence'  end))+ '''
	FROM '+@tablename+' temptable
		LEFT JOIN Competencies ON  RTRIM(LTRIM(temptable.CompetenceName collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang)) WHEN 'A' THEN 'RTRIM(LTRIM(Competencies.CompetenceAName collate database_default))' ELSE 'RTRIM(LTRIM(Competencies.CompetenceName collate database_default))' END +'
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where Competencies.CompetenciesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Competencies.CompetenciesOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	END
	
	IF @EnableTextValidation = '1'
	BEGIN

		DECLARE @ComptenciesOtherInfo NVARCHAR(MAX) 
		SELECT @ComptenciesOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalCompetencies', 'OtherInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'OtherInfo' END)
		---- Other Info
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+ char(13)  + N''' + @ComptenciesOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
				FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.OtherInfo)),N'''') <> N''''  AND dbo.validateText(''EmpComptence'', ''OtherInfo'', Tmptbl.OtherInfo) = 0 
				and Tmptbl.Post = 1 
				and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 

		
	END 
END

---------------------------------------------------------Get External Appraisal WMR----------------------
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalAppraisalWMR' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalAppraisalWMR_ar'
BEGIN
 PRINT 'appraisal' 
SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAppraisalWMR','ApprNameError',@lang,@LogonName)
,(case when @lang='A' then N'إسم التقييم غير صحيح' ELSE 'Not Valid Appraisal Name'  end))

select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks))  + char(13) + N''' + rtrim(ltrim(@errormsg))+'''
	FROM '+@tablename+' temptable 
	LEFT JOIN Appraisals on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(Appraisals.AppraisalAName collate database_default))  else LTRIM(rtrim(Appraisals.AppraisalName collate database_default)) end ) = LTRIM(rtrim(temptable.AppraisalName collate database_default))
    WHERE Appraisals.AppraisalNo is null 
	and temptable.post=1 and temptable.[Row_Number]= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.[Row_Number] else '+ltrim(rtrim(str(@Paycode)))+ ' end'
	EXECUTE(@str)
	
	PRINT @str
	
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAppraisalWMR','RatingLevelError',@lang,@LogonName)
,(case when @lang='A' then N'درجة تقدير غير صحيحة' ELSE 'Not Valid Rating Level'  end))

select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks))  + char(13) + N''' + rtrim(ltrim(@errormsg))+'''
	FROM '+@tablename+' temptable
	LEFT JOIN  Appraisals on LTRIM(RTRIM(temptable.AppraisalName collate database_default))= (CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''E'' THEN Appraisals.AppraisalName  collate database_default
					              ELSE CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''A'' THEN Appraisals.AppraisalAName collate database_default END END)
	LEFT JOIN RatingLevels ON Appraisals.RatingScale = RatingLevels.RatingScale
	and LTRIM(RTRIM(temptable.RatingLevel))= CASE WHEN LTRIM(RTRIM(''' + @lang + '''))=''E'' THEN LTRIM(rtrim(LevelName))
		ELSE CASE WHEN LTRIM(RTRIM(''' + @lang + '''))=''A'' THEN LTRIM(rtrim(LevelAName))END END
	LEFT JOIN EmpAppraisal ON EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo
    WHERE RatingLevels.RatingLevel is null 
	    and temptable.post=1 and temptable.[Row_Number]= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.[Row_Number] else '+ltrim(rtrim(str(@Paycode)))+ ' end'
	    
    PRINT @str       
	EXECUTE(@str)
  
  SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAppraisalWMR','StatusError',@lang,@LogonName),
  (case when @lang='A' then N'إسم حالة غير صحيح' ELSE 'Not Valid Status'  end))
  	select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + char(13) + N''' + rtrim(ltrim(@errormsg))+'''
	FROM '+@tablename+' temptable 
	LEFT JOIN SSDocumentStatus on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(SSDocumentStatus.SSDocAStatus))  else LTRIM(rtrim(SSDocumentStatus.SSDocStatus)) end ) = LTRIM(rtrim(temptable.Status))
	WHERE SSDocumentStatus.ssdocstatusno  is null
	and temptable.post=1 and temptable.[Row_Number]= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.[Row_Number] else '+ltrim(rtrim(str(@Paycode)))+ ' end'
	
	EXECUTE(@str)
	PRINT @str

	SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAppraisalWMR','DateValidate',@lang,@LogonName)
	,(case when @lang='A' then N'التاريخ غير صحيح' ELSE 'Not Valid Date'  end))
	select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + char(13) + N''' + rtrim(ltrim(@errormsg))+'''
	FROM '+@tablename+' temptable 
	WHERE temptable.Date  is null
	and temptable.post=1 and temptable.[Row_Number]= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.[Row_Number] else '+ltrim(rtrim(str(@Paycode)))+ ' end'
	EXECUTE(@str)
	PRINT @str
	
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	select @str='UPDATE '+@tablename+' set   remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAppraisalWMR','AppraisalsOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا التدريب' ELSE N'Check Org. Validation for this Competence'  end))+ '''
	FROM '+@tablename+' temptable
		LEFT JOIN Appraisals ON  RTRIM(LTRIM(temptable.AppraisalName collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang)) WHEN 'A' THEN 'RTRIM(LTRIM(Appraisals.AppraisalAName collate database_default))' ELSE 'RTRIM(LTRIM(Appraisals.AppraisalName collate database_default))' END +'
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where Appraisals.AppraisalsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Appraisals.AppraisalsOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	END
	
	IF @EnableTextValidation = '1'
	BEGIN

		DECLARE @AppraisalWMROtherInfo NVARCHAR(MAX) 
		SELECT @AppraisalWMROtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalAppraisalWMR', 'OtherInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'OtherInfo' END)
		---- Other Info
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))+ char(13)   + N''' + @AppraisalWMROtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
				FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.OtherInfo)),N'''') <> N''''  AND dbo.validateText(''EmpAppraisal'', ''OtherInfo'', Tmptbl.OtherInfo) = 0 
				and Tmptbl.Post = 1 
				and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 

		
	END 
END 



		---------------------Get External time permission-----------------------------

if ltrim(rtrim(@tabletype)) like'%GetExternalTimePermission%' 
begin
print ('time permession')
 SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('COMMON','ErrMsgFHireDate',@lang,@LogonName),(case when @lang='A' then N'(أدخل التاريخ الصحيح (تاريخ الادخال اقل من بداية تاريخ التعيين' ELSE N'Enter a valid date ( from date is before First Hire date)'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  
				inner join empassignment e on e.employeeid collate database_default=temptable.empid collate database_default
				inner join Profile P on P.profileid=e.empid
				WHERE  isnull(firstHiredDate,hiredate) > permfrom  and temptable.Post=1 
				  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)


  SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('COMMON','ErrMsgChkDateRange',@lang,@LogonName),(case when @lang='A' then N'(أدخل التاريخ الصحيح (تاريخ البداية أكبر من تاريخ النهاية' ELSE N'Enter a valid date (From date is greater than To date)	'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  
				inner join empassignment e on e.employeeid collate database_default=temptable.empid collate database_default
				inner join Profile P on P.profileid=e.empid 
				WHERE  permTo < permfrom  and temptable.Post=1 
				  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)
 
   SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('FrmWFPermissionNew','ErrorMsg',@lang,@LogonName),(case when @lang='A' then N'(تأكد من ميعاد الاذن (يوجد أذن بالفعل خلال هذه الفترة' ELSE N'Permission Time Already Exist. Enter A Valid Time	'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  
				inner join empassignment e on e.employeeid collate database_default=temptable.empid collate database_default
				WHERE  e.empid in ((SELECT t.empid   FROM EmpTimePermission t
			                      WHERE t.empid=e.empid and t.documentstatus=1 and 
								  ((temptable.PermFrom >=t.permissionfrom and temptable.PermFrom< t.PermissionTo) 
							    or (temptable.permTo >t.PermissionFrom  and temptable.permTo<=t.PermissionTo) 
								OR (t.PermissionFrom >=temptable.permfrom and t.PermissionFrom<temptable.permTo)  
								OR (t.PermissionTo >temptable.permfrom and t.PermissionTo <=temptable.permTo) ) ))  and temptable.Post=1 
				  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)

  SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTimePerm','ErrorEmptyDates',@lang,@LogonName),(case when @lang='A' then N'لابد من إدخال ميعاد بداية و نهاية الإذن' ELSE N'Permission From and To dates must be inserted'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  
				inner join empassignment e on e.employeeid collate database_default=temptable.empid collate database_default
				WHERE  (isnull(temptable.PermFrom,'''')='''' or isnull(temptable.PermTo,'''')='''')  and temptable.Post=1 
				  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)

 SELECT @Str = 'UPDATE t1  SET t1.Remarks = LTRIM(RTRIM(t1.Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaption('Validate','PermDateintersecterror',@lang),(case when @lang='A' then N'هذا الاذن متقاطع مع اذن اخر فى الكشف' ELSE N'This record intersect with another record in the sheet'  end))))+''' +char(13)
                FROM ' + @tablename + '  t1 
				inner join ' + @tablename + ' t2 on t1.empid=t2.EmpId 
				and (convert(char(19),t1.PermFrom,120) between convert(char(19),t2.PermFrom,120) and convert(char(19),t2.PermTo ,120)
	                    or convert(char(19),t1.PermTo,120) between convert(char(19),t2.PermFrom,120) and convert(char(19),t2.PermTo ,120)
	                    or convert(char(19),t2.PermFrom,120) between convert(char(19),t1.PermFrom,120) and convert(char(19),t1.PermTo ,120)
	                    or convert(char(19),t2.PermTo,120) between convert(char(19),t1.PermFrom,120) and convert(char(19),t1.PermTo,120) ) and t1.row_number <> t2.row_number
				WHERE t1.Post=1 and t2.Post=1 
				and  t1.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  t1.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)

 end

		------------------------------------------------------------------------------

		------------------------------------------Get External VacRecord -----------------------------------------------------------------------

if ltrim(rtrim(@tabletype)) like'%getExternalVacRecords%' or ltrim(rtrim(@tabletype)) like'%getExternalVacRecords_ar%' 
begin
	
--inactive Employee
select @str='UPDATE '+@tablename+' set remarks = ltrim(rtrim(remarks)) + N'''+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang,@LogonName),(case when @lang='A' then N'حالة الموظف لا يعمل' ELSE N'Not an active employee'  end))))+'''+char(13)'+'
		,post=0
	FROM '+@tablename+' temptable
	Inner JOIN EmpAssignment  ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default
    Inner join hrstatus on hrstatus.hrstatus=empassignment.hrstatus
	Inner join Profile P on P.profileid=empassignment.empid'
	+' WHERE (vacfrom > EmpAssignment.termdate) 
	and ((dbo.GetOldValue(EmpAssignment.empid,1, dateadd(day,1,vacfrom),null)<>1  or dbo.GetOldValue(EmpAssignment.empid,1, dateadd(day,1,vacto),null)<>1)) 
	and hrstatus.paystatus <> 1  and temptable.Post=1 
	  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '  
	
	PRINT @str
	EXECUTE (@str)

if @tabletype like'%?%'
begin

 -- declare @vacpolicy  bit,@VacRestriction as nvarchar(200),
  DECLARE @CancelIntersect bit,@vacintersect as nvarchar(200)

   --SET @VacPolicy= isnull(substring(@tabletype, charindex('?',@tabletype,0 )+1, 1),'')
   --PRINT 'VacPolicy ' +str( @VacPolicy)
   select @subtabletype=substring(@tabletype, charindex('?',@tabletype,0 )+1, 3)
   SET  @CancelIntersect=isnull( substring(@subtabletype, charindex(',',@subtabletype,0 )+1, 1),'')  
   PRINT 'CancelIntersect '+ str(@CancelIntersect)

		--if @VacPolicy=1 
  --      begin
		----select @VacRestriction =  dbo.hits_VacationRestriction(@empid,@Parameter1,@VacFrom,@VacTo,@lang,@docno,1,0,0)


  --        select @str= 'UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + ltrim(rtrim(isnull(dbo.hits_VacationRestriction(e.empid,Vacation.VacCode,t.VacFrom,t.VacTo,'''+@lang+''','''',0,0,0),''''))) +char(13)
	 --                   FROM empassignment e inner join '+@tablename+' t on e.employeeid collate database_default=t.empid collate database_default
	 --                   left join Vacation on ltrim(rtrim(t.Vacation collate database_default))= case when '''+@lang+'''= ''e'' 
		--								   then  ltrim(rtrim(Vacation.VacationName collate database_default)) else ltrim(rtrim(Vacation.VacationAName collate database_default)) end
  --                      WHERE t.Post=1 and ltrim(rtrim(isnull(dbo.hits_VacationRestriction(e.empid,Vacation.VacCode,t.VacFrom,t.VacTo,'''+@lang+''','''',0,0,0),''''))) <> ''001'' 
		--				 AND RIGHT(rtrim(substring(ltrim(rtrim(isnull(dbo.hits_VacationRestriction(e.empid,Vacation.VacCode,t.VacFrom,t.VacTo,'''+@lang+''','''',0,0,0),''''))),0,charindex(''-'',ltrim(rtrim(isnull(dbo.hits_VacationRestriction(e.empid,Vacation.VacCode,t.VacFrom,t.VacTo,'''+@lang+''','''',0,0,0),'''')))))),1)=1
	 --                   and Vacation.VacCode is not null
		--				and t.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then t.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
  --        print (@str)
	 --     EXECUTE(@str)
		--  end
 -------------------------------------------------------------
--Customer [ Cleopatra Hospitals Group ]:
--Disallow leaves insertion after the leave from date by certain days:
--Condolence leave: 4 days and Other leaves: 2 days  
--Customer [ New Administrative Capital ]:
--Disallow leaves insertion after 2 days from the leave from date:   
declare @EnableVacInsertAfterFromDate as smallint
set @EnableVacInsertAfterFromDate = isnull((select ConfigValue from SysParamConfig where ConfigID = 'EnableVacInsertAfterFromDate'),0)

if @EnableVacInsertAfterFromDate =1
begin
	 	select *from datadictionary where fieldname = 'ErrMsgVacAfterFourDays'

select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaption('VacationRestriction','ErrMsgVacAfterTwoDays',@lang),(case when @lang='A' then N'لا يمكن ادخال اجازة بعد يومين من تاريخها.' ELSE N'Can not insert Vacation after two days from its date.'  end))))+''' +char(13)
	          FROM '+@tablename+' temptable 
	          LEFT JOIN Vacation on ltrim(rtrim(temptable.Vacation collate database_default))= case when '''+@lang+'''= ''e'' then  
			  ltrim(rtrim(Vacation.VacationName collate database_default)) else ltrim(rtrim(Vacation.VacationAName collate database_default)) end
              WHERE temptable.Post=1 and  convert(smalldatetime,GetDate()) >= DATEADD(DAY, 3,  convert( smalldatetime,temptable.VacFrom )) and Vacation.vaccode  <> 6
			  and Vacation.vaccode IS not null and  temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
 print (@str)
 EXECUTE(@str)

 select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaption('VacationRestriction','ErrMsgVacAfterFourDays',@lang),(case when @lang='A' then N'لا يمكن ادخال اجازة وفاة بعد أربعة أيام من تاريخها.' ELSE N'Can not insert Condolence Vacation after four days from its date.'  end))))+''' +char(13)
	          FROM '+@tablename+' temptable 
	          LEFT JOIN Vacation on ltrim(rtrim(temptable.Vacation collate database_default))= case when '''+@lang+'''= ''e'' then  
			  ltrim(rtrim(Vacation.VacationName collate database_default)) else ltrim(rtrim(Vacation.VacationAName collate database_default)) end
              WHERE temptable.Post=1 and  convert(smalldatetime,GetDate()) >= DATEADD(DAY, 5,  convert( smalldatetime,temptable.VacFrom)) and Vacation.vaccode  = 6
			  and Vacation.vaccode IS not null and  temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
 print (@str)
 EXECUTE(@str)

end
 -------------------------------------------------------------
       

  if @cancelIntersect =0
  begin
		  select @vacintersect =isnull(ltrim(rtrim(dbo.Hits_GetDCCaptionWzLogon('GetExternalVacRecords','Errormesg', @Lang ,@LogonName))), case when  @Lang  ='e' then 'This record intersect with an approved vacation' else 'هذه الاجازه متقاطعة مع اجازة تمت الموافقه عليها مسبقا' end )
		  select @str= 'UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + @Vacintersect+''' +char(13)
	                    FROM empassignment e inner join '+@tablename+' t on e.employeeid collate database_default=t.empid collate database_default
	                    left join EmpVacat on EmpVacat.EmpId =e.EmpId and EmpVacat.VacStatus=1
		                WHERE t.Post=1 and (empVacat.FromDate between t.vacFrom and t.vacTo 
	                    or Empvacat.ToDate between t.VacFrom and t.VacTo 
	                    or t.VacFrom between empVacat.FromDate and Empvacat.ToDate
	                    or t.VacTo between empVacat.FromDate and Empvacat.ToDate   )
						and t.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then t.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
          print (@str)
	      EXECUTE(@str)


  end 
 end

 select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacNameError',@lang,@LogonName),(case when @lang='A' then N' إسم الاجازه غير صحيح' ELSE N'Not Valid Vacation Name'  end))))+''' +char(13)
	          FROM '+@tablename+' temptable 
	          LEFT JOIN Vacation on ltrim(rtrim(temptable.Vacation collate database_default))= case when '''+@lang+'''= ''e'' then  
			  ltrim(rtrim(Vacation.VacationName collate database_default)) else ltrim(rtrim(Vacation.VacationAName collate database_default)) end
              WHERE temptable.Post=1 and Vacation.vaccode IS null and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
 print (@str)
 EXECUTE(@str)
 select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacStatusError',@lang,@LogonName),(case when @lang='A' then N' إسم الحالة غير صحيح ' ELSE N'Not Valid Status'  end))))+''' +char(13)
	          FROM '+@tablename+' temptable 
	          LEFT JOIN SSDocumentStatus on ltrim(rtrim(temptable.Status collate database_default))=case when '''+@lang+'''=''e'' then 
			  ltrim(rtrim(SSDocumentStatus.SSDocStatus collate database_default)) else ltrim(rtrim(SSDocumentStatus.SSDocAStatus collate database_default)) end
              WHERE temptable.Post=1 and SSDocumentStatus.SSDocStatusno IS null 
              and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
 EXECUTE(@str)
 
-- IF @EnableRef =1 
-- BEGIN
--  select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','RefStatusError',@lang),(case when @lang='A' then N' إسم الحالة غير صحيح ' ELSE N'Not Valid Ref Status'  end))))+''' +char(13)
--	          FROM '+@tablename+' temptable 
--			  LEFT JOIN NasArrays NasArraysStatus ON temptable.[RStatus]  collate database_default = case when '''+@lang+'''= ''e'' then 
--			  ltrim(rtrim(NasArraysStatus.edesc))  collate database_default else ltrim(rtrim(NasArraysStatus.adesc))  collate database_default end 
--				AND NasArraysStatus.arrayname=''RStatus'' 
--              WHERE temptable.Post=1 and NasArraysStatus.itemno IS null and temptable.[RStatus] is not null
--              and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
--print (@str)
-- EXECUTE(@str)

--   select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','RefSourceError',@lang),(case when @lang='A' then N' إسم المصدر غير صحيح ' ELSE N'Not Valid Ref Source'  end))))+''' +char(13)
--	          FROM '+@tablename+' temptable 
--			  LEFT JOIN NasArrays NasArraysSource ON temptable.[RSource]  collate database_default= case when '''+@lang+'''= ''e'' then 
--			  ltrim(rtrim(NasArraysSource.edesc)) collate database_default else ltrim(rtrim(NasArraysSource.adesc))  collate database_default end  
--				AND NasArraysSource.arrayname=''RSource'' 
--              WHERE temptable.Post=1 and NasArraysSource.itemno IS null and temptable.[RSource] is not null
--              and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
--print (@str)
-- EXECUTE(@str)

-- end
SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','NullVacDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ البداية او تاريخ النهاية لا يمكن ان يكونوا بلا قيمه ' ELSE N'From date or To date can not be empty'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  WHERE ( vacto is null or vacfrom is null)  
                and  temptable.Post=1 and  temptable .Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str) 
 
 SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ البداية أكبر من تاريخ النهاية' ELSE N'From date is greater than To date	'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  
				WHERE vacto < vacfrom and  temptable.Post=1 
				and  temptable .Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)

 SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacDateBfrHireDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ الاجازه قبل تاريخ التعيين' ELSE N'Vacation date is before employee hiredate'  end))))+''' +char(13)
                FROM ' + @tablename + '  temptable  
				inner join empassignment e on e.employeeid collate database_default=temptable.empid collate database_default
				inner join Profile P on P.profileid=e.empid
				WHERE  isnull(firstHiredDate,hiredate) > vacfrom and  temptable.Post=1 
				and  temptable .Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)
 print (@str)

 SELECT @Str = 'UPDATE t1  SET t1.Remarks = LTRIM(RTRIM(t1.Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacDateintersecterror',@lang,@LogonName),(case when @lang='A' then N'هذه الاجازه متقاطعة مع اجازةاخرى فى الكشف' ELSE N'This record intersect with another record in the sheet'  end))))+''' +char(13)
                FROM ' + @tablename + '  t1 
				inner join ' + @tablename + ' t2 on t1.empid=t2.EmpId 
				and (convert(char(10),t1.vacFrom,111) between convert(char(10),t2.vacFrom,111) and convert(char(10),t2.vacTo ,111)
	                    or convert(char(10),t1.VacTo,111)  between convert(char(10),t2.VacFrom,111) and convert(char(10),t2.VacTo ,111)
	                    or convert(char(10),t2.VacFrom,111) between convert(char(10),t1.vacFrom,111) and convert(char(10),t1.VacTo ,111)
	                    or convert(char(10),t2.VacTo,111) between convert(char(10),t1.vacFrom,111) and convert(char(10),t1.VacTo,111) ) and t1.row_number <> t2.row_number
				WHERE t1.Post=1 and t2.Post=1 
				and  t1.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  t1.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 EXECUTE(@str)

 print (@str)

  IF @EnableTextValidation = '1'
	BEGIN

		DECLARE @VacOtherInfo NVARCHAR(MAX)
		SELECT @VacOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('Wp_GetExternalVacRecords', 'OtherInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'OtherInfo' END)
		
		---- Other Info
		SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))  + N''' + @VacOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
				FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.OtherInfo)),N'''') <> N''''  
				AND dbo.validateText(''EmpVacat'', ''OtherInfo'', Tmptbl.OtherInfo) = 0 
				and (Tmptbl.Post = 1)  
				and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 
				  	

	END 

	/*Custom for new capital customer*/
	IF @customrestriction=1
	BEGIN
	   
	  
	   SELECT @str = 'UPDATE t1  SET t1.Remarks = LTRIM(RTRIM(t1.Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('customrestriction','emergencyresrict',@Lang,@LogonName),(case when @lang='A' then N'لا يجوز للموظف أخذ إجازة سنوية بعد إجازة طارئة' ELSE N'The employee cannot take an annual leave after an emergency leave'  end))))+''' +char(13)
                FROM EmpAssignment
				 Inner Join ' + @tablename + '  t1 on  EmpAssignment.EmployeeId=t1.Empid
				 Inner Join vacation on ltrim(rtrim(t1.Vacation collate database_default))= case when '''+@lang+'''= ''e'' then  
			      ltrim(rtrim(Vacation.VacationName collate database_default)) else ltrim(rtrim(Vacation.VacationAName collate database_default)) end
				 Inner join EmpVacat on EmpAssignment.Empid=EmpVacat.Empid
				 AND EmpVacat.VacCode=' + ltrim(rtrim(str(@EmergencyVaccode))) +'
		         AND EmpVacat.ToDate=(t1.VacFrom-1)
		         AND (EmpVacat.VacStatus=1 or EmpVacat.VacStatus=5)
		         and vacation.VacCode=' + ltrim(rtrim(str(@AnnualVaccode)))+'
				WHERE t1.Post=1 
				and  t1.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  t1.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
 
 
 EXECUTE(@str)
 print (@str)
 
	   SELECT @Str = 'UPDATE t1  SET t1.Remarks = LTRIM(RTRIM(t1.Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('customrestriction','emergencyresrict',@Lang,@LogonName),(case when @lang='A' then N'لا يجوز للموظف أخذ إجازة سنوية بعد إجازة طارئة' ELSE N'The employee cannot take an annual leave after an emergency leave'  end))))+''' +char(13)
                FROM EmpAssignment
				 Inner Join ' + @tablename + '  t1 on  EmpAssignment.EmployeeId=t1.Empid
				 Inner Join vacation on ltrim(rtrim(t1.Vacation collate database_default))= case when '''+@lang+'''= ''e'' then  
			      ltrim(rtrim(Vacation.VacationName collate database_default)) else ltrim(rtrim(Vacation.VacationAName collate database_default)) end
				 Inner join EmpVacat on EmpAssignment.Empid=EmpVacat.Empid
				 AND EmpVacat.VacCode=' + ltrim(rtrim(str(@AnnualVaccode))) +'
		         AND EmpVacat.FromDate=(t1.VacTo+1)
		         AND (EmpVacat.VacStatus=1 or EmpVacat.VacStatus=5)
		         and vacation.VacCode=' + ltrim(rtrim(str(@EmergencyVaccode)))+'
				WHERE t1.Post=1 
				and  t1.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then  t1.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '   
 
 
 EXECUTE(@str)
 print (@str)
	    
    END
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	BEGIN
	select @str='UPDATE '+@tablename+' set   remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacationOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذه الاجازة' ELSE N'Check Org. Validation for this Vacation'  end))+ '''
	FROM '+@tablename+' temptable
	LEFT JOIN Vacation on ltrim(rtrim(temptable.Vacation collate database_default))=   case when '''+@lang+'''= ''e'' then    ltrim(rtrim(Vacation.VacationName collate database_default)) else   ltrim(rtrim(Vacation.VacationAName collate database_default))   end
	where temptable.Post=1 
	and ( not exists ( select * from #OrgTree where Vacation.VacationOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Vacation.VacationOrgs ='''' )) 
	and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
		   

	print (@str) 
	END 
	--if	@EnableOrgSetup =1 and @userOrganization <> ''
	--BEGIN
	--select @str='UPDATE '+@tablename+' set post=0 ,  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacationOrgsValidation',@lang),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذه الاجازة' ELSE N'Check Org. Validation for this Vacation'  end))+ '''
	--FROM '+@tablename+' temptable
	--LEFT JOIN Vacation on ltrim(rtrim(temptable.Vacation collate database_default))=   case when '''+@lang+'''= ''e'' then    ltrim(rtrim(Vacation.VacationName collate database_default)) else   ltrim(rtrim(Vacation.VacationAName collate database_default))   end
	
	--where temptable.Post=1 
	--and Vacation.Vaccode not in (select distinct v.Vaccode 
	--                         from Vacation v
	--                         inner join(select distinct  ltrim(rtrim(vacation)) as Vacation from '+@tablename+' temptable  ) t on t.Vacation=Vacation.vacationname
	--                        Inner join #OrgTree on v.vacationOrgs='''' or v.VacationOrgs like ''%#''+ltrim(rtrim(VOrganization))+''#%'')
	
	--and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	--EXECUTE(@str)
	--print (@str) 
	-- END 
	
	--IF	@EnableOrgSetup =1 and @userOrganization <> ''
	--BEGIN
		
	--DECLARE @selectStmt AS NVARCHAR(max)
		
	--	--select @selectStmt = 'select distinct v.Vaccode 
	-- --                         from Vacation v
	-- --                         inner join '+@tablename+' t  on ltrim(rtrim(t.Vacation))=ltrim(rtrim(v.vacationname))
	-- --                         Inner join #OrgTree on v.vacationOrgs='''' or v.VacationOrgs like ''%#''+ltrim(rtrim(VOrganization))+''#%'''
	 
	-- 	select @selectStmt = 'select distinct temp.Vaccode 
	--                          from (select distinct v.Vaccode,v.vacationorgs  from  Vacation v
	--                          inner join '+@tablename+' t  on ltrim(rtrim(t.Vacation))=ltrim(rtrim(v.vacationname))) temp 
	--                          Inner join #OrgTree on temp.vacationOrgs='''' or temp.VacationOrgs like ''%#''+ltrim(rtrim(VOrganization))+''#%'''
	                          
	                        
	--		select @str='UPDATE '+@tablename+' set post=0 ,  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','VacationOrgsValidation',@lang),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذه الاجازة' ELSE N'Check Org. Validation for this Vacation'  end))+ '''
	--       FROM '+@tablename+' temptable
	--       inner Join Vacation on ltrim(rtrim(Vacation.VacationName))=ltrim(rtrim(temptable.Vacation))
	--       LEFT JOIN ValidVacations ON ValidVacations.vaccode=Vacation.Vaccode
	--	   where temptable.Post=1 
	--       and ValidVacations.vaccode IS NULL 
	--	   and temptable.Row_Number= case when 0=0 then temptable.Row_Number else 0 end'	
		
	--		EXEC ('With ValidVacations as ('+@selectStmt+')'+@str)
	
	-- --  EXEC(@selectStmt)
	

	--	print (';With ValidVacations as ('+@selectStmt+')'+@str)
	--END 
	
		
	
	
END

---------------------------------------------Get External Benefit Plan-----------------------------------------------------
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalBenefitPlan%' 
BEGIN
	DECLARE @DateFormatPlan AS INT 


    SELECT @DateFormatPlan= dateformat FROM SysParam 
    IF @DateFormatPlan=1 SET @DateFormatPlan=103
    IF @DateFormatPlan=2 SET @DateFormatPlan=101
    IF @DateFormatPlan=0 SET @DateFormatPlan=111

	SET @errormsg=N''
	PRINT @lang
	--get Supplier ,Service name if Found
	select @str='UPDATE '+@tablename+' set 
	Supplier = (case when '''+@lang+''' = ''A'' then ( ltrim(rtrim(Supplier.SupplierAName)) ) else  ltrim(rtrim((Supplier.SupplierName ))) end),
	Service = (case when '''+@lang+''' = ''A'' then ltrim(rtrim(( Service.ServiceAName  ))) else  ltrim(rtrim((Service.ServiceName ))) end),
	CoverageAmount=round(CoverageAmount,'+STR(@DecimalScale)+'), LevelAmount=round(LevelAmount,'+STR(@DecimalScale)+')
	FROM '+@tablename+' temptable
	left join Supplier ON ltrim(rtrim(temptable.Supplier collate database_default)) = (case when '''+@lang+''' = ''A'' then ( ltrim(rtrim(Supplier.SupplierAName collate database_default)) ) else  ltrim(rtrim((Supplier.SupplierName collate database_default))) end) 
	left join Service ON ltrim(rtrim(temptable.Service collate database_default)) = (case when '''+@lang+''' = ''A'' then ltrim(rtrim(( Service.ServiceAName collate database_default ))) else  ltrim(rtrim((Service.ServiceName collate database_default))) end)  
	  '

	PRINT @str
	EXECUTE(@str)
	
	
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	BEGIN
			---- supplier orgs validations
	select @str='UPDATE '+@tablename+' set post=0 ,  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('common','SupplierOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا المورد' ELSE N'Check Org. Validation for this Supplier'  end))+ '''
	FROM '+@tablename+' temptable
		left join Supplier ON ltrim(rtrim(temptable.Supplier collate database_default)) = (case when '''+@lang+''' = ''A'' then ( ltrim(rtrim(Supplier.SupplierAName collate database_default)) ) else  ltrim(rtrim((Supplier.SupplierName collate database_default))) end)
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where Supplier.SupplierOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Supplier.SupplierOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
		---- Service orgs validations
	select @str='UPDATE '+@tablename+' set post=0 ,  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('common','ServiceOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذه الخدمة' ELSE N'Check Org. Validation for this Service'  end))+ '''
	FROM '+@tablename+' temptable
	left join Service ON ltrim(rtrim(temptable.Service collate database_default)) = (case when '''+@lang+''' = ''A'' then ltrim(rtrim(( Service.ServiceAName collate database_default ))) else  ltrim(rtrim((Service.ServiceName collate database_default))) end)
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where Service.ServiceOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Service.ServiceOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	end


	
	--Supplier donot supply this service
	SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','ErrMsgsupplierservice',@lang,@LogonName),(case when @lang='A' then N'المورد لا يقدم هذة الخدمة' ELSE N'Supplier does not supply this service'  end))
	
	select @str='UPDATE '+@tablename+' set remarks= remarks + rtrim(ltrim(N'''+@errormsg+''')) 
	FROM '+@tablename+' temptable
	left join Supplier ON ltrim(rtrim(temptable.Supplier collate database_default)) = (case when '''+@lang+''' = ''A'' then ( ltrim(rtrim(Supplier.SupplierAName collate database_default)) ) else  ltrim(rtrim((Supplier.SupplierName collate database_default))) end) 
	left join Service ON ltrim(rtrim(temptable.Service collate database_default)) = (case when '''+@lang+''' = ''A'' then ltrim(rtrim(( Service.ServiceAName collate database_default ))) else  ltrim(rtrim((Service.ServiceName collate database_default))) end)  
	LEFT JOIN SupplierService ON SupplierService.SupplierNo = Supplier.SupplierNo  AND SupplierService.ServiceNo = Service.ServiceNo 
	where SupplierService.SupplierNo is null and SupplierService.ServiceNo is null 
	and 
	(Supplier.SupplierNo is not null  and Service.ServiceNo is not null) and temptable.Post=1 '

	PRINT @str
	EXECUTE(@str)
	
	PRINT 'Supplier donot supply this service'
 
 ------ Check Enroll Date 
	PRINT 'Set Validate on Enroll Date'
	SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitPlan','EnrollDateError',@lang,@LogonName),(case when @lang='A' then N'تاريخ التقديم غير صحيح' ELSE 'Enter a Valid Enroll Date'  end))                      
	select @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg+''')) +'' / ''+rtrim(ltrim(remarks))
	FROM '+@tablename+' temptable
	inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	left join profile on profile.profileid=empassignment.empid
	where (temptable.post=1) 
	and  (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end )
	and (  (temptable.enrolldate='''' or temptable.enrolldate is null ) 
	     or ( ISNULL(convert(SMALLDATETIME,LTRIM(RTRIM(PROFILE.FirstHiredDate)),'+str(@DateFormatPlan)+'), convert(SMALLDATETIME,LTRIM(RTRIM(EmpAssignment.HireDate)),'+str(@DateFormatPlan)+')) > convert(SMALLDATETIME,LTRIM(RTRIM(temptable.enrolldate)),'+str(@DateFormatPlan)+'))
	    )'	
	PRINT  'Error Enrol Date ...'+@str
	PRINT(@str)
	EXECUTE(@str)

	------Check opening plan with the same options
   PRINT 'Set Validate on Opening plan with the same options'

	----SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitPlan','EnrollDateError',@lang),(case when @lang='A' then N'تاريخ التقديم غير صحيح' ELSE 'Enter a Valid Enroll Date'  end))                      
	--SELECT @errormsg = 'Sorry Plan Opening with same options'
	--select @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg+''')) +'' / ''+rtrim(ltrim(remarks))
	--FROM '+@tablename+' temptable
	--inner JOIN EmpAssignment ON temptable.empid=empassignment.EmployeeId 
	--left join EmpBenefit on EmpBenefit.EmpId = empassignment.empid
	--left join BenefitPlans on BenefitPlans.PlanNo = EmpBenefit.PlanNo
	--where (temptable.post=1) 
	--and  (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end )
	--and (EmpBenefit.Closed = 0)
	--and (BenefitPlans.MultiOption = 1 )
	--'	
	--PRINT  'Error in Opening plan with the same options ...'+@str
	--PRINT(@str)
	--EXECUTE(@str)

	----------------Eligible Paln------------------
	DECLARE @Planno AS NVARCHAR(10), @eligiblechecked AS BIT, @pageitemno AS INT, @eligibleqs AS BIT 
	
	PRINT '@tabletype ' + @tabletype
	
	select @subtabletype = substring(@tabletype, charindex('?',@tabletype)+1, LEN(@tabletype))
	PRINT '1----subtabletype ' + @subtabletype
		
	SET @Planno = substring(@subtabletype, 0, charindex(',',@subtabletype))
	PRINT 'Plan no. '+ str(@Planno)
	
	SELECT @subtabletype = SUBSTRING(@subtabletype, CHARINDEX(',',@subtabletype)+1, LEN(@subtabletype))
	PRINT '2----subtabletype ' + @subtabletype
	
	SET  @eligiblechecked = substring(@subtabletype, 0, charindex(',',@subtabletype)) 
	PRINT 'eligiblechecked '+ str(@eligiblechecked)
	
	SELECT @subtabletype = SUBSTRING(@subtabletype, CHARINDEX(',',@subtabletype)+1, LEN(@subtabletype))
	PRINT '3----subtabletype ' + @subtabletype
	
	set @pageitemno = @subtabletype 
	PRINT 'pageitemno '+ str(@pageitemno)
	
	SELECT @eligibleqs = CASE WHEN charindex('applyeligible=', case when @lang ='e' then ltrim(rtrim(ItemProg)) ELSE ltrim(rtrim(ItemAProg)) END) = 0 THEN 0
						 ELSE substring(case when @lang ='e' then ltrim(rtrim(ItemProg)) ELSE ltrim(rtrim(ItemAProg)) END , (charindex('applyeligible=', case when @lang ='e' then ltrim(rtrim(ItemProg)) ELSE ltrim(rtrim(ItemAProg)) END) + LEN('applyeligible=')), 1) END
	FROM NasOptions WHERE ItemNo = @pageitemno
	
	PRINT '@eligibleqs = ' + STR(@eligibleqs)
		
	SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','ErrMsgEligiblePlan',@lang,@LogonName),(case when @lang='A' then N'هذه الخطة غير مستحقة لهذا الموظف' ELSE N'This Plan is not eligible for this employee'  end))

	IF @eligiblechecked = 1 OR @eligibleqs = 1
	BEGIN
		SELECT @str='UPDATE '+ @tablename+' set remarks= remarks + char(13) + rtrim(ltrim(N'''+@errormsg+''')), post = 0 
					  from '+@tablename+' t
		              inner join empassignment on empassignment.employeeid collate database_default=t.empid collate database_default
					  WHERE dbo.Hits_IsBenefitEligible('+@Planno +',t.enrolldate,empassignment.empid) = 0 
					  and t.Post=1'
		
		PRINT @str
		EXECUTE(@str)
	END
		IF @EnableTextValidation = '1'
	BEGIN
		DECLARE @BenefitPlanOtherInfo NVARCHAR(MAX)
		SELECT @BenefitPlanOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitPlan', 'BenefitNote', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات أخرى' ELSE 'Benefit Note' END)
		
		---- benefit Note
		SELECT @str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @BenefitPlanOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
				FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.BenefitNote)),N'''') <> N''''  AND dbo.validateText(''EmpBenefit'', ''BenefitNote'', Tmptbl.BenefitNote) = 0 
				and Tmptbl.Post = 1 
				and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 
	END
END


---------------------------------------------Get External Benefit Items
		
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems_ar'
BEGIN	
	--SET @errormsg=N''
	--	 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Duplicate Record',@lang,@LogonName),(case when @lang='A' then N'الموظف مكرر' ELSE N'Duplicate Record'  end))                          
		
		 
	--select @str='UPDATE '+@tablename+' set  remarks= rtrim(ltrim(N'''+@errormsg+''')) , post=0, amount=round(amount,'+STR(@DecimalScale)+'), Quantity=round(Quantity,'+STR(@DecimalScale)+') 
	--FROM '+@tablename+' temptable
	--left JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default
	--and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	--+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END +
	--'WHERE temptable.empid in (SELECT t.empid
 --  FROM '+@tablename+' t  GROUP BY empid having COUNT(empid)>1)  and ltrim(rtrim(temptable.remarks))= N'''' '

	--PRINT @str
	--EXECUTE(@str)
    
-- check for relative name  
DECLARE @errormsg0 AS NVARCHAR(250)
SELECT @errormsg0= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitItems','InvalidRelativeName',@lang,@LogonName),
(case when @lang=N'A' then N'اسم القريب غير صحيح ' ELSE N'Invalid Relative Name'  end))

select @str=N'UPDATE '+@tablename+N' set  amount=round(amount,'+STR(@DecimalScale)+'),Quantity=round(Quantity,'+STR(@DecimalScale)+'), remarks= remarks +
case when NOT (Relatives.ProfileId is not null or  ltrim(rtrim(isnull(temptable.Relativename,'''')))='''')
then '' -''  + N'''+ltrim(rtrim(@errormsg0))+N'''
else '''' end
FROM '+@tablename+N' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default
left join Relatives on Relatives.ProfileId=EmpAssignment.empid 
AND  Relatives.RelProfileId IN (SELECT TOP 1 profile.profileid FROM profile WHERE ltrim(rtrim(isnull(temptable.Relativename,''''))) collate database_default =ltrim(rtrim('+CASE WHEN @lang='A' THEN N'profile.aname' ELSE N'profile.name' END+N')) collate database_default  ORDER BY profile.profileid DESC )
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+N' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+N')' else N' '  end	
+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END	
PRINT @str
EXECUTE(@str)

SELECT @errormsg0= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitItems','InvalidSupplierName',@lang,@LogonName),
(case when @lang=N'A' then N'اسم المورد غير صحيح ' ELSE N'Invalid Supplier Name'  end))
	
	-- check for Suppliername
select @str=N'UPDATE '+@tablename+N' set post=0 , amount=round(amount,'+STR(@DecimalScale)+'), Quantity=round(Quantity,'+STR(@DecimalScale)+'), remarks=  remarks +'' -''  + N'''+ltrim(rtrim(@errormsg0))+N'''  
	FROM '+@tablename+N' temptable
	left JOIN Supplier on  ltrim(rtrim(temptable.SupplierName collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' THEN N'Supplier.SupplieraName collate database_default' ELSE N'Supplier.SupplierName collate database_default' END+N'))
 
where  ltrim(rtrim(temptable.suppliername))<>'''' and   Supplier.SupplierNo is null
'
	PRINT @str
	EXECUTE(@str)

SELECT @errormsg0= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitItems','InvalidServiceName',@lang,@LogonName),
(case when @lang=N'A' then N'اسم الخدمه غير صحيح ' ELSE N'Invalid Service Name'  end))

	
	-- check for Servicename
select @str=N'UPDATE '+@tablename+N' set post=0 , amount=round(amount,'+STR(@DecimalScale)+'), Quantity=round(Quantity,'+STR(@DecimalScale)+'), remarks= remarks +'' -''  + N'''+ltrim(rtrim(@errormsg0))+N'''  
	FROM '+@tablename+N' temptable
	left JOIN service on  ltrim(rtrim(temptable.serviceName collate database_default)) = ltrim(rtrim('+CASE WHEN @lang=N'A' THEN N'service.serviceaName collate database_default' ELSE N'service.serviceName collate database_default' END+N'))
 
where  ltrim(rtrim(temptable.servicename))<>'''' and   service.serviceNo is null
'
	PRINT @str
	EXECUTE(@str)
	
		IF @EnableTextValidation = '1'
	BEGIN
		DECLARE @BenefitReference NVARCHAR(MAX)
		SELECT @BenefitReference = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitItems', 'Reference', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'المرجع' ELSE 'Reference' END)
		
		---- Reference
		SELECT @str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))   + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + ''' + @BenefitReference + '''+''' +' '+  LTRIM(RTRIM(@RegularExpressionError)) + '''
				FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.Reference)),N'''') <> N''''  
			    AND dbo.validateText(''EmpBenefitItems'', ''Reference'', Tmptbl.Reference) = 0
                and   Tmptbl.Post = 1 
				and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 
		
		
		DECLARE @BenefitItemsOtherInfo NVARCHAR(MAX)
		SELECT @BenefitItemsOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitItems', 'Activitynote', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الوصف' ELSE 'Activity Note' END)
		
		---- Activity Note
		SELECT @str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + case when rtrim(ltrim(remarks))='''' then '''' else  '' / '' end + ''' + @BenefitItemsOtherInfo + '''+''' +' '+  LTRIM(RTRIM(@RegularExpressionError)) + '''
				FROM ' + @tablename + ' Tmptbl WHERE ISNULL(LTRIM(RTRIM(Tmptbl.ActivityNote)),N'''') <> N''''  
				AND dbo.validateText(''EmpBenefitItems'', ''ActivityNote'', Tmptbl.ActivityNote) = 0 
                and   Tmptbl.Post = 1 
				and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		PRINT @str
		EXEC(@str) 
	END
			---- supplier orgs validations
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	select @str='UPDATE '+@tablename+' set post=0 ,  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('common','SupplierOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا المورد' ELSE N'Check Org. Validation for this Supplier'  end))+ '''
	FROM '+@tablename+' temptable
		left join Supplier ON ltrim(rtrim(temptable.SupplierName collate database_default)) = (case when '''+@lang+''' = ''A'' then ( ltrim(rtrim(Supplier.SupplierAName collate database_default)) ) else  ltrim(rtrim((Supplier.SupplierName collate database_default))) end)
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where Supplier.SupplierOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Supplier.SupplierOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	end
END
---------------------------------------------------------------------------------------------------------------------
--------------------------------------------Get External HR Requests-----------------------------------------------------

IF LTRIM(RTRIM(@tabletype)) like'%WP_GetExternalHRRequests%' 
BEGIN

	--Check HR Request Name
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHRRequests','HRReqNameError',@lang,@LogonName),(case when @lang='A' then N'اسم الطلب غير صحيح' ELSE 'Not Valid HR Request Name'  end))    
	
		SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+''')'
		+'FROM '+@tablename+' temptable '
		+'left join HRRequest on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(HRRequest.HRReqAName collate database_default))  else LTRIM(rtrim(HRRequest.HRReqName collate database_default)) end ) = LTRIM(rtrim(temptable.HRReqName collate database_default))'+
		+'where HRRequest.hrreqcode is null and post=1 and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	PRINT @str
	EXECUTE(@str)



	--Check HR Request Status
	 SELECT @errormsg = ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHRRequests','StatusError',@lang,@LogonName),  (case when @lang='A' then N'إسم حالة غير صحيح' ELSE 'Not Valid Status'  end))))

		SELECT @str='UPDATE '+@tablename+' set  Remarks=rtrim(ltrim(Remarks)) + CASE WHEN  RTRIM(ltrim(Remarks)) = '''' THEN '''' ELSE '' / '' END + N'''+@errormsg+'''
		FROM '+@tablename+' temptable 
		LEFT JOIN SSDocumentStatus on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(SSDocumentStatus.SSDocAStatus))  else LTRIM(rtrim(SSDocumentStatus.SSDocStatus)) end ) = LTRIM(rtrim(temptable.HRReqStatus))
		WHERE SSDocumentStatus.ssdocstatusno  is null'
	
	PRINT @str
	EXECUTE(@str)
	IF @EnableTextValidation = '1' BEGIN
		DECLARE  @ProccessInfo AS NVARCHAR(max)
		SELECT @OtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHRRequests', 'OtherInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات اخرى' ELSE 'Other Information' END)
		SELECT @ProccessInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHRRequests', 'CompleteInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'معلومات التفعيل' ELSE 'Process Information' END)
		
		--Validate Other Info
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))  + N''' + @OtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalHRRequests'', ''OtherInfo'', OtherInfo) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)

		--Validate Proccess Info
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))  + N''' + @ProccessInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalHRRequests'', ''CompleteInfo'', CompleteInfo) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)
		EXEC('SELECT * FROM ' + @tablename)
	END 
	
		if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	select @str='UPDATE '+@tablename+' set  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHRRequests','HRRequestOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الطلب' ELSE N'Check Org. Validation for this HR Request'  end))+ '''
	FROM '+@tablename+' temptable
		left join HRRequest ON ltrim(rtrim(temptable.HRReqName collate database_default)) = (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(HRRequest.HRReqAName collate database_default))  else LTRIM(rtrim(HRRequest.HRReqName collate database_default)) end )
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where HRRequest.HRRequestOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or HRRequest.HRRequestOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	end
END
--------------------------------------------Get External Tasks-----------------------------------------------------
IF LTRIM(RTRIM(@tabletype)) like'%WP_GetExternalTasks%' 
BEGIN
    
	----Check Task category
	 SELECT @errormsg = ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','TaskCatError',@lang,@LogonName),  (case when @lang='A' then N'إسم فئة المهمة غير صحيح' ELSE 'Not Valid Task Category'  end))))
     SELECT @str='UPDATE '+@tablename+' set  Remarks=rtrim(ltrim(Remarks)) + CASE WHEN  RTRIM(ltrim(Remarks)) = '''' THEN '''' ELSE '' / '' END + N'''+@errormsg+'''
		FROM '+@tablename+' temptable 
		LEFT JOIN TaskCat on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(TaskCat.TaskCatAName))  else LTRIM(rtrim(TaskCat.TaskCatName)) end ) = LTRIM(rtrim(temptable.taskcat))
		WHERE TaskCat.TaskCat  is null '
	
	PRINT @str
	EXECUTE(@str)
	
    ----Check Document Status
	 SELECT @errormsg = ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','StatusError',@lang,@LogonName),  (case when @lang='A' then N'إسم حالة غير صحيح' ELSE 'Not Valid Status'  end))))
     SELECT @str='UPDATE '+@tablename+' set  Remarks=rtrim(ltrim(Remarks)) + CASE WHEN  RTRIM(ltrim(Remarks)) = '''' THEN '''' ELSE '' / '' END + N'''+@errormsg+'''
		FROM '+@tablename+' temptable 
		LEFT JOIN SSDocumentStatus on CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(SSDocumentStatus.SSDocAStatus))  else LTRIM(rtrim(SSDocumentStatus.SSDocStatus)) end = LTRIM(rtrim(temptable.DocumentStatus))
		WHERE SSDocumentStatus.ssdocstatusno  is null '
	
	PRINT @str
	EXECUTE(@str)
	
		--Check task Priority             
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','taskPriorityError',@lang,@LogonName),(case when @lang='A' then N'إسم أولوية المهمة غير صحيح' ELSE 'Not Valid Task Priority'  end))    
	SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))  , post=0  
					FROM '+@tablename+' temptable
					left JOIN NasArrays ON ltrim(rtrim(temptable.Priority)) collate database_default = '+CASE WHEN @lang = 'E' THEN 'ltrim(rtrim(edesc)) collate database_default' ELSE 'ltrim(rtrim(adesc)) collate database_default' END +' 
					and  ltrim(rtrim(arrayname)) = ''taskPriority''
				    where  NasArrays.itemno is null  '
	PRINT @str
	EXECUTE(@str)

		--Check Task Privacy
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','TaskPrivacyError',@lang,@LogonName),(case when @lang='A' then N'إسم خصوصية المهمة غير صحيح' ELSE 'Not Valid Task Privacy'  end))    
	SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))  , post=0  
					FROM '+@tablename+' temptable
					left JOIN NasArrays ON ltrim(rtrim(temptable.TaskPrivacy)) collate database_default = '+CASE WHEN @lang = 'E' THEN 'ltrim(rtrim(edesc)) collate database_default' ELSE 'ltrim(rtrim(adesc)) collate database_default' END +' 
					and ltrim(rtrim(arrayname)) = ''TaskPrivacy''
				    where  NasArrays.itemno is null '
	PRINT @str
	EXECUTE(@str)

	--Check start date
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','InsertStartDate',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال تاريخ بداية' ELSE 'Must Insert Start Date'  end))    
	SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))  , post=0  
					FROM '+@tablename+' temptable					
				    where  isnull(temptable.startDate,'''')='''' '
	PRINT @str
	EXECUTE(@str)
	--Check completion Perc
	SELECT @errormsg  = isnull(dbo.Hits_GetDCCaptionWzLogon('WF_TaskForm','ValidCompPerc',@lang,@LogonName),(case when @lang='A' then N'قيمة نسبة الإنتهاء لابد أن تكون بين 0 و 100' ELSE 'Value of completion % must be between 0 and 100'  end))    
	SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))  , post=0  
					FROM '+@tablename+' temptable					
				    where  isnull(temptable.CompletionPercent,0) NOT BETWEEN 0 AND 100 '
	PRINT @str
	EXECUTE(@str)
	--Check start date > due date

	SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','DueDateValidation',@lang,@LogonName),(case when @lang='A' then N'إدخل التاريخ الصحيح(تاريخ الإنتهاء قبل تاريخ البدء )' ELSE 'Enter a valid date (End Date is before From Date)'  end))                      
	select @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))  , post=0 

	FROM '+@tablename+' temptable 
    where temptable.StartDate > isnull(temptable.DueDate,temptable.StartDate) '	


    PRINT @str
	EXECUTE(@str)
	
  	--  Task can be Private only if Empid = logonname 
	SELECT @errormsg = ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','PrivateTaskError',@lang,@LogonName),  (case when @lang='A' then N'لا يمكن تعيين مهمة خاصة لموظف اّخر' ELSE 'You can not assign Private Task for another employee'  end))))
	SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+'''))  , post=0  
		 		 FROM '+@tablename+' temptable
				 inner join empassignment on empassignment.employeeid = temptable.empid 
				 left JOIN NasArrays ON ltrim(rtrim(temptable.TaskPrivacy)) collate database_default = '+CASE WHEN @lang = 'E' THEN 'ltrim(rtrim(edesc)) collate database_default' ELSE 'ltrim(rtrim(adesc)) collate database_default' END +' 
				 and ltrim(rtrim(arrayname)) = ''TaskPrivacy''
				 where NasArrays.itemno = 1 and (' +str(@empid) +' <> empassignment.empid )'
	
	PRINT @str
	EXECUTE(@str)
	
		-- check Task Category Orgs
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	select @str='UPDATE '+@tablename+' set   remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTasks','TaskCatOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذه المهمة' ELSE N'Check Org. Validation for this Task Category'  end))+ '''
	FROM '+@tablename+' temptable
		LEFT JOIN TaskCat on (CASE WHEN ''' + @lang + ''' = ''A'' then LTRIM(rtrim(TaskCat.TaskCatAName))  else LTRIM(rtrim(TaskCat.TaskCatName)) end ) = LTRIM(rtrim(temptable.taskcat))
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where TaskCat.TaskCatOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TaskCat.TaskCatOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	
	EXECUTE(@str)
	print (@str) 
	END
	
END

IF LTRIM(RTRIM(@tabletype)) like'%WP_LoadPaymentData%' 
BEGIN
 select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','ValidRStatus',@lang,@LogonName),(case when @lang='A' then N' الحالة غير صحيحه' ELSE N'Not Valid Status'  end))))+''' +char(13)
              FROM '+@tablename+' temptable
              LEFT JOIN NasArrays RStatus on Rstatus.ArrayName=''RStatus'' and  ltrim(rtrim(temptable.RStatus collate database_default))= case when '''+@lang+'''= ''e'' then
              ltrim(rtrim(edesc collate database_default)) else ltrim(rtrim(adesc collate database_default)) end
              WHERE temptable.Post=1 and RStatus.itemno IS NULL 
			  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
 print (@str)
 EXECUTE(@str)

 select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','ValidRSource',@lang,@LogonName),(case when @lang='A' then N' المصدر غير صحيح' ELSE N'Not Valid Source'  end))))+''' +char(13)
              FROM '+@tablename+' temptable
              LEFT JOIN NasArrays RSource on RSource.ArrayName=''RSource'' and  ltrim(rtrim(temptable.RSource collate database_default))= case when '''+@lang+'''= ''e'' then
              ltrim(rtrim(edesc collate database_default)) else ltrim(rtrim(adesc collate database_default)) end
              WHERE temptable.Post=1 and RSource.itemno IS NULL 
			  and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
 print (@str)
 EXECUTE(@str)
       ------- validate Duplication in Employee --------------------------

		SELECT @Str = 'UPDATE '+@tablename +'SET Remarks = LTRIM(RTRIM(ISNULL(Remarks, N''''))) + N''' +   LTRIM(RTrim(ISNULL(dbo.Hits_GetDCCaption('common', 'Duplicate Record', @lang),CASE @lang WHEN 'A' THEN N' Ø§Ù„Ù…ÙˆØ¸Ù Ù…ÙƒØ±Ø±' ELSE N'Duplicate Record' END)))  + ''' + CHAR(13)
               FROM '+@tablename+' temptable
               WHERE temptable.empid in (SELECT InnerTmptbl.empid 
										 FROM '+@tablename+' InnerTmptbl
										 GROUP BY InnerTmptbl.empid 
										 HAVING COUNT(InnerTmptbl.Row_Number)>1)
               AND temptable.Post = 1
               AND (temptable.Row_Number = CASE WHEN ' + LTRIM(RTRIM(STR(@Paycode))) + ' = 0 THEN temptable.Row_Number ELSE ' + LTRIM(RTRIM(STR(@Paycode))) + ' END)';

		EXEC(@Str);
		print (@str)
		 -------End validate Duplication in Employee --------------------------
 IF @EnableTextValidation = '1' 
    
    BEGIN
        DECLARE @bankaccntno AS NVARCHAR(max)
        SELECT @bankaccntno = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_LoadPaymentData', 'PayBankAct', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رقم الحساب' ELSE 'Bank Account no.' END)
        
		DECLARE @paymentinfo AS NVARCHAR(max)
        SELECT @paymentinfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_LoadPaymentData', 'PaymentInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات المدفوعات'  ELSE 'Payment Info.' END)
       
	    DECLARE @swiftcode AS NVARCHAR(max)
        SELECT @swiftcode = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_LoadPaymentData', 'SwiftCode', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'كود السويفت' ELSE 'Swift Code' END)
       
	    DECLARE @accountname AS NVARCHAR(max)
        SELECT @accountname = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_LoadPaymentData', 'AccountName', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'اسم الحساب' ELSE 'Account Name' END)
       
	    DECLARE @rdesc AS NVARCHAR(max)
        SELECT @rdesc = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_LoadPaymentData', 'RDesc', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الوصف' ELSE 'Desc' END)
       
	    DECLARE @rno AS NVARCHAR(max)
        SELECT @rno = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_LoadPaymentData', 'RNo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رقم القرار' ELSE 'Ref No' END)
       
        ------- validate Bank Account No.
            SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(ISNULL(Remarks,N''''))) + N''' + @bankaccntno + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+ Char(13)
                    FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_LoadPaymentData'', ''PayBankAct'', Tmptbl.PayBankAct) = 0 
                    and (Tmptbl.Post = 1)  
					and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '         
            EXEC(@Str)
		------- validate Payment Information.
            SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(ISNULL(Remarks,N''''))) + N''' + @paymentinfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+ Char(13)
                    FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_LoadPaymentData'', ''PaymentInfo'', Tmptbl.PaymentInfo) = 0 
                    and (Tmptbl.Post = 1)  
					and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '           
            EXEC(@Str)	
		------- validate Swift Code.
            SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(ISNULL(Remarks,N''''))) + N''' + @swiftcode + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+ Char(13)
                    FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_LoadPaymentData'', ''SwiftCode'', Tmptbl.SwiftCode) = 0 
                    and (Tmptbl.Post = 1)  
					and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '          
            EXEC(@Str)
		------- validate Account Name.
            SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(ISNULL(Remarks,N''''))) + N''' + @accountname + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+ Char(13)
                    FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_LoadPaymentData'', ''AccountName'', Tmptbl.AccountName) = 0 
                    and (Tmptbl.Post = 1)  
					and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '           
            EXEC(@Str)
		------- validate RDesc.
            SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(ISNULL(Remarks,N''''))) + N''' + @rdesc + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+ Char(13)
                    FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_LoadPaymentData'', ''RDesc'', Tmptbl.RDesc) = 0 
                    and (Tmptbl.Post = 1)  
					and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '            
            EXEC(@Str)
		------- validate RNo.
            SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(ISNULL(Remarks,N''''))) + N''' + @rno + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+ Char(13)
                    FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_LoadPaymentData'', ''RNo'', Tmptbl.RNo) = 0 
                    and (Tmptbl.Post = 1)  
					and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '           
            EXEC(@Str)
	END


END 
	----=================================================UDF Validation=============================================================================
	
	DECLARE  @rowcnt INT
DECLARE @UDFExists  as NVARCHAR(max) = 'SELECT @cnt =count(*) FROM '+ PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns  WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME Like ''UDF%'''
EXEC Sp_executesql @UDFExists ,N'@cnt int out' ,@cnt=@rowcnt output

IF @rowcnt > 0
  BEGIN
      

	
	declare @Employeeid as nvarchar(max)--edited
	declare @params as nvarchar(max)
	declare @SELECT as nvarchar(max)
	declare @Cursor_UDF as nCHAR(4) 
	declare @FieldType as smallint
	declare @NewValueUDF AS nVARCHAR(254)
	declare @Stmt as nvarchar(max)
	declare @Formno as SMALLINT
	declare @RowNo as smallint
    DECLARE @format AS char(3)
	 
     if @DateFormat =0 set @format ='ymd'
     else if @DateFormat =1 set @format ='dmy'
     else if @DateFormat =2 set @format ='mdy'
     SET DATEFORMAT @format


	if ltrim(rtrim(@tabletype)) like '%getExternalVacRecords%' or ltrim(rtrim(@tabletype)) like'%getExternalVacRecords_ar%' 
	set @formno=6
	ELSE IF ltrim(rtrim(@tabletype)) like '%WP_GetExternalBenefitPlan%' or ltrim(rtrim(@tabletype)) like'%WP_GetExternalBenefitPlan_ar%' 
	set @formno=13
	else if ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalDocuments%'
	set @formno=8

	else if ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalevents%'
	set @formno=9
	
	else if ltrim(rtrim(@tabletype)) = 'WP_GetExternalHousingItems' OR ltrim(rtrim(@tabletype))  = 'WP_GetExternalHousingItems_ar'
	set @formno=14
	
	else if ltrim(rtrim(@tabletype)) = 'WP_GetExternalAppraisalWMR' OR ltrim(rtrim(@tabletype))  = 'WP_GetExternalAppraisalWMR_ar'
	set @formno=11

	else if ltrim(rtrim(@tabletype)) = 'WP_GetExternalProfileUserDefinedFields' OR ltrim(rtrim(@tabletype))  = 'WP_GetExternalProfileUserDefinedFields_ar'
	set @formno=1
	else if ltrim(rtrim(@tabletype)) LIKE  '%WP_GetExternalMisconduct%' OR ltrim(rtrim(@tabletype))  LIKE  '%WP_GetExternalMisconduct_ar%'
	set @formno=5
	else if ltrim(rtrim(@tabletype)) LIKE  '%WP_GetExternalHRRequests%' 
	set @formno=20
	else if ltrim(rtrim(@tabletype)) LIKE  '%WP_GetExternalTasks%' 
	set @formno=21
	EXEC('DECLARE EmpCursor CURSOR FOR SELECT e.employeeid ,t.Row_Number
FROM empassignment e inner join '+@tablename+' t on e.employeeid collate database_default=t.empid  collate database_default
where t.post=1  and t.Row_Number= case when '+ @Paycode+'=0 then t.Row_Number else '+@Paycode+ ' end ')
  OPEN EmpCursor
     FETCH NEXT FROM EmpCursor INTO @Employeeid,@RowNo
     WHILE @@FETCH_STATUS = 0
      BEGIN 
	   set   @errormsg =N''
	  ----------------------------------------------------------------------------------
	  set @Stmt= 'DECLARE TempTable_cursor2 CURSOR FOR SELECT substring(COLUMN_NAME ,4,len(COLUMN_NAME))
				  FROM '+ PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
				  WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME Like ''UDF%''' 
	 print @Stmt
	 exec (@Stmt )
     OPEN TempTable_cursor2
     FETCH NEXT FROM TempTable_cursor2 INTO @Cursor_UDF
     WHILE @@FETCH_STATUS = 0
      BEGIN 
      
       select @params = N'@NewValueUDF nvarchar(254)  OUTPUT'  
       SET @SELECT=N'select @NewValueUDF= UDF'+@Cursor_UDF +' from '+@tablename 
                  +'where Row_Number='+ltrim(rtrim(Str(@RowNo)))
                   
   EXEC sp_executesql @SELECT,@Params,@NewValueUDF OUTPUT      
    
 -------------------------------------------------------------------------------
 select @FieldType= UserFieldsNames.FieldType FROM UserFieldsNames  WHERE FieldNo=@Cursor_UDF and UserFieldsNames.formno=@Formno

   IF @EnableTextValidation = '1'  
 BEGIN
     IF  @FieldType= 1 -- Text
	 BEGIN
		
		 IF EXISTS (SELECT UserFieldsNames.FieldNo 
		 FROM dbo.UserFieldsNames 
		 WHERE UserFieldsNames.FormNo = @Formno AND UserFieldsNames.FieldNo = CONVERT(SMALLINT ,@Cursor_UDF) )
			 BEGIN 
			 ------------- Set Validation Text
				DECLARE @UDFValidation NVARCHAR(MAX),@ValidateText BIT
				
				SET @UDFValidation = (CASE WHEN @lang=N'a' THEN N'الحقل رقم ' ELSE N'Field No.' END  )  +@Cursor_UDF+N' '+@RegularExpressionError
				
				----- Update Remarks with Validation
				SELECT @str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))  + N''' + @UDFValidation + N'''+char(13)
								FROM ' + @tablename + ' Tmptbl 
								WHERE ISNULL(LTRIM(RTRIM( '''+LTRIM(RTRIM(@NewValueUDF))+N''')),N'''') <> N''''  AND dbo.validateText(''TextBox'', ''ValidateInput'', '''+LTRIM(RTRIM(@NewValueUDF))+N''') = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number='+ltrim(rtrim(Str(@RowNo)))
				
		
				PRINT @str
				EXEC(@str) 
				END
		 END
 END



 IF  @FieldType =2 --Multiple choice
  begin
  if not exists( select * from   UserFieldsItems 
	             WHERE UserFieldsItems.FieldNo= @Cursor_UDF and UserFieldsItems.formno=@Formno  
	              and ltrim(Rtrim(@NewValueUDF)) =case when @lang = 'e' then ltrim(Rtrim(FieldItemValue)) else ltrim(Rtrim(FieldItemAValue)) end)
                    
	
	 begin
	 set @errormsg=ltrim(rtrim(@errormsg))+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','CommonError',@lang,@LogonName),(case when @lang='A' then N' قيمه بيانات النموذج الخاص ' ELSE N'Value of User defined field'  END))))+' '+@Cursor_UDF+' '+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','MChoiceError',@lang,@LogonName),(case when @lang='A' then N' غير موجوده' ELSE N'does not exist'  end))))+char(13)
	 end
 end
 else IF  @FieldType =3 and isnumeric(@NewValueUDF)=0 --numeric
     begin
      set @errormsg=ltrim(rtrim(@errormsg))+ ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','CommonError',@lang,@LogonName),(case when @lang='A' then N' قيمه بيانات النموذج الخاص ' ELSE N'Value of User defined field'  end))))+' '+@Cursor_UDF+' '+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','NumericError',@lang,@LogonName),(case when @lang='A' then N'ليست رقميه' ELSE N'is not numeric'  end)))) +char(13)
	
     end
 else IF  @FieldType =4 --Date
    BEGIN
	 SELECT @NewValueUDF=LTRIM(RTRIM(REPLACE(@NewValueUDF,'00:00:00','')))
	if  ISDATE(@NewValueUDF) = 0 OR CHARINDEX (':',@NewValueUDF) >0 
	OR (ISDATE(@NewValueUDF) = 1 AND ((@DateFormat=0 AND @NewValueUDF NOT LIKE '[1-2][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]') 
		OR(@DateFormat=1 AND @NewValueUDF NOT LIKE '[0-3][0-9]/[0-1][0-9]/[1-2][0-9][0-9][0-9]') 
		OR(@DateFormat=2 AND @NewValueUDF NOT LIKE '[0-1][0-9]/[0-3][0-9]/[1-2][0-9][0-9][0-9]')) )
	begin 
     set @errormsg=ltrim(rtrim(@errormsg))+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','CommonError',@lang,@LogonName),(case when @lang='A' then N' قيمه بيانات النموذج الخاص ' ELSE N'Value of User defined field'  end))))+' '+@Cursor_UDF+' '+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','DateError',@lang,@LogonName),(case when @lang='A' then N'ليست في صيغة التاريخ الصحيحه' ELSE N' is not in correct date format'  end))))+char(13)
	END

    END
  else   IF  @FieldType =5 --DateTime
    BEGIN
	
	if  ISDATE(@NewValueUDF) = 0 OR CHARINDEX (':',@NewValueUDF) =0 
	OR (ISDATE(@NewValueUDF) = 1 AND ((@DateFormat=0 AND @NewValueUDF NOT LIKE '[1-2][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9] [0-2][0-9]:[0-5][0-9]:[0-5][0-9]') 
		OR(@DateFormat=1 AND @NewValueUDF NOT LIKE '[0-3][0-9]/[0-1][0-9]/[1-2][0-9][0-9][0-9] [0-2][0-9]:[0-5][0-9]:[0-5][0-9]') 
		OR(@DateFormat=2 AND @NewValueUDF NOT LIKE '[0-1][0-9]/[0-3][0-9]/[1-2][0-9][0-9][0-9] [0-2][0-9]:[0-5][0-9]:[0-5][0-9]')) )
	begin 

		
     set @errormsg=ltrim(rtrim(@errormsg))+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','CommonError',@lang,@LogonName),(case when @lang='A' then N' قيمه بيانات النموذج الخاص ' ELSE N'Value of User defined field'  end))))+' '+@Cursor_UDF+' '+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','DateError',@lang,@LogonName),(case when @lang='A' then N'ليست في صيغة التاريخ الصحيحه' ELSE N' is not in correct date format'  end))))+char(13)
	END

    END 

	else   if @FieldType=0 	
	SET @errormsg=ltrim(rtrim(@errormsg)) +ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','FieldError',@lang,@LogonName),(case when @lang='A' then N'الحقل رقم ' ELSE N' Field No. '  end))))+' '+@Cursor_UDF+' '+ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','FieldNumError',@lang,@LogonName),(case when @lang='A' then  N'غير موجود' ELSE N' does not exist'  end))))+char(13)

   ---------------------------------------------------------------------  
   
   
   
   set @FieldType=0 	              
    FETCH NEXT FROM TempTable_cursor2 into @Cursor_UDF
     END
    CLOSE TempTable_cursor2
    DEALLOCATE TempTable_cursor2
    
    
IF @errormsg <>''
begin
		print 'UPDATE '+@tablename+' set remarks= rtrim(ltrim(remarks)) + rtrim(ltrim(N'''+ @errormsg +''')) +char (13) where Row_Number='+ltrim(rtrim(Str(@RowNo)))
		select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(remarks)) + rtrim(ltrim(N'''+ @errormsg +'''))+char (13) where Row_Number='+ltrim(rtrim(Str(@RowNo)))
		print @str
	  exec(@str)
	
END

	  ---------------------------------------------------------------------------------
	  FETCH NEXT FROM EmpCursor into @Employeeid,@RowNo
     END
    CLOSE EmpCursor
    DEALLOCATE EmpCursor
    
    
    
	  END 
 
 
 SELECT @format= date_format FROM sys.dm_exec_sessions WHERE session_id = @@spid
    SET DATEFORMAT @format
	--=================================================================================================================================================
	--EXEC ('update '+@tablename +' set Post =case when '+LTRIM(RTRIM(STR(@Paycode)))+'<>0 and ltrim(rtrim(remarks))='''' then 1
	--                                             when '+LTRIM(RTRIM(STR(@Paycode)))+'=0 then case when ltrim(rtrim(remarks))='''' then post else 0 end end  from ' 
	--                                             +@tablename+' t where ltrim(rtrim(remarks))<>''''' )	
	print ('update '+@tablename +' set Post =0 from '+@tablename+'t 
		       where ltrim(rtrim(remarks))<>''''
		       and ('''+@tabletype+''' not LIKE ''WP_GetExternalBenefitPlan%''  or ('''+@tabletype+'''  LIKE ''WP_GetExternalBenefitPlan%'' and  rtrim(ltrim(isnull(remarks,'''')))<>isnull(dbo.Hits_GetDCCaptionWzLogon(''common'',''ErrMsgsupplierservice'','''+@lang+''','''+@LogonName+'''),(case when '''+@lang+'''=''A'' then N''المورد لا يقدم هذة الخدمة'' ELSE N''Supplier does not supply this service''  end)) ))
		       and t.Row_Number= case when '+ str(@paycode)+'=0 then t.Row_Number else '+str(@paycode)+ ' end' )
		
		exec ('update '+@tablename +' set Post =0 from '+@tablename+'t 
		       where ltrim(rtrim(remarks))<>''''
		       and ('''+@tabletype+''' not LIKE ''WP_GetExternalBenefitPlan%'' or ('''+@tabletype+'''  LIKE ''WP_GetExternalBenefitPlan%''  and  rtrim(ltrim(isnull(remarks,'''')))<>isnull(dbo.Hits_GetDCCaptionWzLogon(''common'',''ErrMsgsupplierservice'','''+@lang+''','''+@LogonName+'''),(case when '''+@lang+'''=''A'' then N''المورد لا يقدم هذة الخدمة'' ELSE N''Supplier does not supply this service''  end)) ))
		       and t.Row_Number= case when '+ @paycode+'=0 then t.Row_Number else '+@paycode+ ' end ' )	

END

IF ltrim(rtrim(@tabletype)) <> 'WP_HrBudgetEntry' and ltrim(rtrim(@tabletype)) <> 'WP_HrBudgetEntry_ar' AND ltrim(rtrim(@tabletype)) <> 'WP_JvSetup' and ltrim(rtrim(@tabletype)) <> 'WP_JvSetup_ar' 
 AND  ltrim(rtrim(@tabletype)) <> 'WP_TrainingPlanCostItems_ar' AND  ltrim(rtrim(@tabletype)) <> 'WP_TrainingPlanCostItems' 
 AND   ltrim(rtrim(@tabletype)) <> 'WP_TrainingPlanActivities_ar' AND   ltrim(rtrim(@tabletype)) <> 'WP_TrainingPlanActivities'
  AND   ltrim(rtrim(@tabletype)) <> 'WP_TrainingNeedsCollection_ar' AND   ltrim(rtrim(@tabletype)) <> 'WP_TrainingNeedsCollection'
  AND   ltrim(rtrim(@tabletype)) <> 'WP_PostTrainingPlanActivitytoTrainingEvent_ar' AND   ltrim(rtrim(@tabletype)) <> 'WP_PostTrainingPlanActivitytoTrainingEvent'
   AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalEmployees%' 
   AND  ltrim(rtrim(@tabletype)) <> 'WP_GetExternalPayrollDetails_ar' AND  ltrim(rtrim(@tabletype)) <> 'WP_GetExternalPayrollDetails' 
   AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalApplicants%'
   AND   ltrim(rtrim(@tabletype)) NOT  LIKE 'WP_GetExternalMisconduct%'
   AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalObjective_ar%' AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalObjective%' 
   AND LTRIM(RTRIM(@tabletype)) <> 'WP_GetExternalDocuments' AND LTRIM(RTRIM(@tabletype)) <> 'WP_GetExternalDocuments_ar'
   AND LTRIM(RTRIM(@tabletype)) NOT LIKE 'WP_GetExternalAdditionalEvents_ar%' AND LTRIM(RTRIM(@tabletype)) NOT LIKE 'WP_GetExternalAdditionalEvents%'
   AND LTRIM(RTRIM(@tabletype)) NOT LIKE 'WP_GetExternalevents_ar%' AND LTRIM(RTRIM(@tabletype)) NOT LIKE  'WP_GetExternalevents%'
   AND LTRIM(RTRIM(@tabletype)) <> 'WP_GetExternalhousingitems_ar' AND LTRIM(RTRIM(@tabletype)) <> 'WP_GetExternalhousingitems'
   AND ltrim(rtrim(@tabletype)) <> 'WP_GetExternalCompetencies' AND ltrim(rtrim(@tabletype)) <>'WP_GetExternalCompetencies_ar'
  AND ltrim(rtrim(@tabletype)) <> 'WP_GetExternalAppraisalWMR' AND ltrim(rtrim(@tabletype)) <>'WP_GetExternalAppraisalWMR_ar'
  and ltrim(rtrim(@tabletype)) NOT LIKE '%GetExternalVacRecords%' and ltrim(rtrim(@tabletype)) NOT LIKE  '%GetExternalVacRecords_ar%' 
    and ltrim(rtrim(@tabletype)) NOT LIKE '%GetExternalTimePermission%' 
  AND  LTRIM(RTRIM(@tabletype)) NOT LIKE 'WP_GetExternalBenefitPlan%'
  AND  LTRIM(RTRIM(@tabletype)) NOT LIKE '%WP_ExportBenefitSalaryScales_ar%' AND  LTRIM(RTRIM(@tabletype)) NOT LIKE '%WP_ExportBenefitSalaryScales%'
  AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_ExportSalaryScalesDetails_ar%' AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_ExportSalaryScalesDetails%'  
  AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalProfileUserDefinedFields_ar%' AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalProfileUserDefinedFields%'  
  AND LTRIM(RTRIM(@tabletype))  NOT LIKE '%WP_GetExternalDataFile%' 
  AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalProfilePhone%'
  AND LTRIM(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalBenefitItems%' AND ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalBenefitItems_ar%'
   AND LTRIM(RTRIM(@tabletype)) NOT LIKE '%WP_GetExternalHRRequests%'
  AND LTRIM(RTRIM(@tabletype)) NOT LIKE '%WP_GetExternalTasks%' AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_LoadPaymentData%'
      AND LTRIM(RTRIM(@tabletype)) NOT LIKE '%WP_GetExternalNASUsers%' AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_GetExternalNASUsers_ar%'
	        AND LTRIM(RTRIM(@tabletype)) NOT LIKE '%WP_ExternalSystemsBatchPosting%' AND  ltrim(rtrim(@tabletype)) NOT LIKE '%WP_ExternalSystemsBatchPosting_ar%'

BEGIN
	PRINT '2'
	SELECT @str='UPDATE '+@tablename+' set post= 1
	FROM '+@tablename+' temptable where post is null'
	EXECUTE(@str)
	 		
	select  @empid=empid , @ApplySSGroups =ApplySSGroups , @PrivacyLevelFrom=PrivacyLevelFrom,@PrivacyLevelTo=PrivacyLevelTo
	from nasusers  
	where @logonname=logonname 

		 
		IF ltrim(rtrim(@tabletype)) <> 'WP_LoadPaymentData' and ltrim(rtrim(@tabletype)) <> 'WP_LoadPaymentData_ar' 
		BEGIN
		 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then N'موظف غير مسموح به'  ELSE N'Not a valid employee'  end))                          
		
			select @str='UPDATE '+@tablename+' set remarks= N'''' 
	FROM '+@tablename+' temptable'
	EXECUTE(@str)
	 
	select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0  --,inputamnt=0 , Amount=0 
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
	'WHERE EmpAssignment.empid IS null'

	PRINT @str
	EXECUTE(@str)
	
IF ltrim(rtrim(@tabletype)) ='WP_getExternalChangeOfStatus' OR ltrim(rtrim(@tabletype)) = 'WP_getExternalChangeOfStatus_ar'
	       BEGIN
		   		 declare @chngintersect as nvarchar(200)

				 	         SELECT @Str = 'UPDATE t1  SET t1.Remarks = LTRIM(RTRIM(t1.Remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','changeofstatusIntersecterror',@lang,@LogonName),(case when @lang='A' then N'هذه الحالة متقاطعة مع حالةاخرى فى الكشف' ELSE N'This record intersect with another record in the sheet'  end))))+', '' +char(13)
                FROM ' + @tablename + '  t1 
				inner join ' + @tablename + ' t2 on t1.empid=t2.EmpId 
				and t1.EffectiveDate = t2.EffectiveDate 
				and t1.row_number <> t2.row_number
				WHERE t1.Post=1 and t2.Post=1 '

         EXECUTE(@str)
         print (@str)



		  select @chngintersect =isnull(ltrim(rtrim(dbo.Hits_GetDCCaptionWzLogon('WP_getExternalChangeOfStatus','Errormesg', @Lang ,@LogonName))), case when  @Lang  ='e' then 'This record intersect with a transaction in the same effictive date' else N'هذه الحالة موجودة مسبقاً على نفس التاريخ الفعلى' end )
		  select @str= 'UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + @chngintersect+', '' +char(13)
	                    FROM empassignment e inner join '+@tablename+' t on e.employeeid collate database_default=t.empid collate database_default
	                    inner join empstatushdr on empstatushdr.EmpId = e .EmpId and 
                                                        empstatushdr.EffectiveDate = t.EffectiveDate and 
														empstatushdr.chgcode = '+str(@Paycode)+ ' and
														empstatushdr.DocumentStatus in (1,5)
														cross join sysparam 
														where isnull(sysparam.nhirechgcd,0) <>'+str(@Paycode) 
														+ 'and t.post= 1'

          print (@str)
	      EXECUTE(@str)
		  


--	    If (select count(fieldNo) from ChngStatFields where ChgCode= @Paycode) <> 0
--           begin

--		   declare @NotexistColumns as nvarchar(max), @NotexistColumnsStr as nvarchar(max)

--		   select @NotexistColumnsStr=N'select  @NotexistColumns  = STUFF((SELECT '','' +  QUOTENAME(LTRIM(rtrim(COLUMN_NAME))) 
--            FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--            WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1) AND  COLUMN_NAME Like ''CH%''
--			and cast(replace(COLUMN_NAME,''ch'','''') as int) not in (select FieldNo from ChngStatFields where ChgCode = '+cast(@Paycode as nvarchar)+')
--            FOR XML PATH(''''), TYPE).value(''.'', ''NVARCHAR(MAX)'') ,1,1,'''') '

--exec sp_executesql @NotexistColumnsStr , N' @NotexistColumns nvarchar(max) OUTPUT', @NotexistColumns=@NotexistColumns OUTPUT
--select @NotexistColumns = REPLACE (@NotexistColumns,',','  ')

--            set @str = 'If Exists(SELECT cast(replace(COLUMN_NAME,''ch'','''') as int)
--                        FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--                        WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1) AND  COLUMN_NAME Like ''CH%'' 
--                        and cast(replace(COLUMN_NAME,''ch'','''') as int) not in (select FieldNo from ChngStatFields where ChgCode = '+cast(@Paycode as nvarchar)+'))
--                        begin
--                        UPDATE '+@tablename+' 
--                            set remarks= LTRIM(RTRIM(Remarks)) + N''' +ltrim(rtrim(@NotexistColumns))+' '+rtrim(ltrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_getExternalChangeOfStatus','RemarkMsgOfChngOfStatus',@lang,@LogonName)
--                            ,(case when @lang='A' then N'توجد اعمدة غير معروفة' ELSE N'Web Form Field Is Not Related to Change Of Status'  end))))+',''+char(13) where post =1 
                        
--                        end'
						
--						print  @str

--						exec (@str)

--		   declare @NotRequiredColumns as nvarchar(max), @NotRequiredColumnsStr as nvarchar(max)

--		   select @NotRequiredColumnsStr=N'select  @NotRequiredColumns  = STUFF((SELECT '','' +  QUOTENAME(LTRIM(rtrim(COLUMN_NAME))) 
--            FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--            WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1) AND  COLUMN_NAME Like ''CH%''
--			and cast(replace(COLUMN_NAME,''ch'','''') as int)  in (select FieldNo from ChngStatFields where ChgCode = '+cast(@Paycode as nvarchar)+' and AcceptNewValue = 0 )
--            FOR XML PATH(''''), TYPE).value(''.'', ''NVARCHAR(MAX)'') ,1,1,'''') '
----select @NotRequiredColumnsStr
--exec sp_executesql @NotRequiredColumnsStr , N' @NotRequiredColumns nvarchar(max) OUTPUT', @NotRequiredColumns=@NotRequiredColumns OUTPUT

--select @NotRequiredColumns = REPLACE (@NotRequiredColumns,',','  ')
----select @NotRequiredColumns 'select @NotRequiredColumns '

--            set @str = 'If Exists(SELECT cast(replace(COLUMN_NAME,''ch'','''') as int)
--                        FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--                        WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1) AND  COLUMN_NAME Like ''CH%'' 
--                        and cast(replace(COLUMN_NAME,''ch'','''') as int)  in (select FieldNo from ChngStatFields where ChgCode = '+cast(@Paycode as nvarchar)+' and AcceptNewValue = 0))
--                        begin
--                        UPDATE '+@tablename+' 
--                            set remarks= LTRIM(RTRIM(Remarks)) + N''' +ltrim(rtrim(@NotRequiredColumns))+' '+rtrim(ltrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_getExternalChangeOfStatus','RemarkMsgOfChngOfStatusforhiddenCol',@lang,@LogonName)
--                            ,(case when @lang='A' then N'هذا الحقل غير مطلوب' ELSE N'Web Form Field Not Accepted'  end))))+',''+char(13) where post =1 
                        
--                        end'
--						--select  @str '@str'
						
--						exec (@str)
--						--exec('select * from '+@tablename)


--	 declare @FieldnoExist as nvarchar(max), @FieldnoExistStr as nvarchar(max)

--            select @FieldnoExistStr=N'select  @FieldnoExist  = 

--			 t.fieldno from ( select fieldno from  ChngStatFields where ChgCode= '+str(@Paycode)+' and AcceptNewValue=1)t where t.fieldno not in (
--			  		select cast(replace(COLUMN_NAME,''ch'','''') as int) from             
--		'+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--            right join ChngStatFields on ChngStatFields.FieldNo=cast(replace(COLUMN_NAME,''ch'','''') as int)
--            and ChgCode= '+str(@Paycode)+' and AcceptNewValue=1
--        WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1)
--		AND  COLUMN_NAME Like ''CH%''
--			)'

--			exec sp_executesql @FieldnoExistStr , N' @FieldnoExist nvarchar(max) OUTPUT', @FieldnoExist=@FieldnoExist OUTPUT
				
--		--if exists (	select t.fieldno from ( select fieldno from  ChngStatFields where ChgCode= @Paycode and AcceptNewValue=1)t where t.fieldno not in (
--		--	  		select cast(replace(COLUMN_NAME,'ch','') as int) from             
--		--DNACLOUDDBBatchTemp.INFORMATION_SCHEMA.Columns
--  --          right join ChngStatFields on ChngStatFields.FieldNo=cast(replace(COLUMN_NAME,'ch','') as int)
--  --          and ChgCode= @Paycode and AcceptNewValue=1
--  --      WHERE TABLE_NAME = PARSENAME(''+@tablename+'',1)
--		--AND  COLUMN_NAME Like 'CH%' 
--		--	))
--		IF @FieldnoExist is not null
--			  begin
--			declare @ColumnRequiredButNotExist as nvarchar(max) = ''
--			declare @ColumnRequiredButNotExistStr as nvarchar(max) = ''

--			 select @ColumnRequiredButNotExistStr=N'select 	@ColumnRequiredButNotExist =@ColumnRequiredButNotExist+''[''+
--			 RIGHT(''CH000''+LTRIM(RTRIM(t.fieldno)),6) +''] ''		
--			 from ( 
--select fieldno from  ChngStatFields where
--              ChgCode= '+str(@Paycode)+' and AcceptNewValue=1)t where t.fieldno not in (
--			  			select cast(replace(COLUMN_NAME,''ch'','''') as int) from             
--			'+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--             right join ChngStatFields on ChngStatFields.FieldNo=cast(replace(COLUMN_NAME,''ch'','''') as int)
--             and ChgCode= '+str(@Paycode)+' and AcceptNewValue=1
--            WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1)
--			AND  COLUMN_NAME Like ''CH%'' 
--			  )'


			  	
--			exec sp_executesql @ColumnRequiredButNotExistStr , N' @ColumnRequiredButNotExist nvarchar(max) OUTPUT', @ColumnRequiredButNotExist=@ColumnRequiredButNotExist OUTPUT
		   
--			  select @ColumnRequiredButNotExist = @ColumnRequiredButNotExist + 
--			 rtrim(ltrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_getExternalChangeOfStatus','RemarkMsgOfChngOfStatusforReqCol',@lang,@LogonName)
--                            ,(case when @lang='A' then  N'هذا الحقل مطلوب'  ELSE N'Web Form Field is required'  end))))+', '''+char(10)+char(13)
				

--			  --select @ColumnRequiredButNotExist '@ColumnRequiredButNotExist'

--			  SET @str = N'UPDATE '+@tablename+'  set remarks= ISNULL(LTRIM(RTRIM(Remarks)),'''') + N'''+@ColumnRequiredButNotExist+' where post =1  '
--			  --select @STR '@STR'
--			  EXEC (@str) 
--			end




--			If exists (select * from ChngStatFields where ChgCode= @Paycode and AcceptNewValue=1 and FieldNo in (1 ,5 ,6 ,7 ,8 ,9 ,10,19,22,23,24,25,26,27,28,29) ) 
--           begin

--		 declare @RequiredColumns as nvarchar(max), @RequiredColumnsStr as nvarchar(max)
--            select @RequiredColumnsStr=N'select  @RequiredColumns  = STUFF((SELECT '' or  ISNULL ('' +  QUOTENAME(LTRIM(rtrim(COLUMN_NAME))) +'' ,'''''''') = '''''''' ''
--            FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--             inner join ChngStatFields on ChngStatFields.FieldNo=cast(replace(COLUMN_NAME,''ch'','''') as int)
--             and ChgCode= '+cast(@Paycode as nvarchar)+' and AcceptNewValue=1
--            WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1) AND  COLUMN_NAME in (''CH0001'' ,''CH0005'' ,''CH0006'' ,''CH0007'' ,''CH0008'' ,''CH0009'' ,''CH0010'',''CH0019'',''CH0022'',''CH0023'',''CH0024'',''CH0025'',''CH0026'',''CH0027'',''CH0028'',''CH0029'')
--            FOR XML PATH(''''), TYPE).value(''.'', ''NVARCHAR(MAX)'') ,1,1,'''') '
			
--			exec sp_executesql @RequiredColumnsStr , N' @RequiredColumns nvarchar(max) OUTPUT', @RequiredColumns=@RequiredColumns OUTPUT
--		    select @RequiredColumns = SUBSTRING(@RequiredColumns,3,len(@RequiredColumns))
		  
--		  --select @RequiredColumns '@RequiredColumns'


--			declare @RequiredColumnsStr2 as nvarchar(max)
--		select @RequiredColumns = 'select  @RequiredColumnsStr2  =  case when ' + @RequiredColumns +  ' then N''' + rtrim(ltrim(isnull(dbo.Hits_GetDCCaptionWzLogon('WP_getExternalChangeOfStatus','RemarkMsgOfChngOfStatusforReqNewval',@lang,@LogonName)
--                           ,(case when @lang='A' then N'مطلوب قيمة جديدة لهذا الحقل' ELSE N'New Value is required for this Web Form Field'  end))))+', '+char(10)+char(13)+''' else '''' end from '+@tablename
  		
--		exec sp_executesql @RequiredColumns , N' @RequiredColumnsStr2 nvarchar(max) OUTPUT', @RequiredColumnsStr2=@RequiredColumnsStr2 OUTPUT
--				  --select @RequiredColumns '@RequiredColumns'

--		--select @RequiredColumnsStr2 '@RequiredColumnsStr2'	
	



--	--Web Form Field is required a new value,   


--	 IF @RequiredColumnsStr2 <> ''
--		  begin
--		   SELECT @STR = ''	   


--		DECLARE @QueryStr AS NVARCHAR(MAX) --,  @Str AS NVARCHAR(MAX) = ''
--  select @QueryStr=N'
--select @Str = @Str+ ' +	N'''case when ISNULL(LTRIM(rtrim('''+
--'+ COLUMN_NAME +'+N''')) ,'''''''') = '''''''' then '' '+'+''N''''[''+ COLUMN_NAME+'']  ''''''   +'+N'''  else '''''''' end +    ''
--           FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns
--             right join ChngStatFields on ChngStatFields.FieldNo=cast(replace(COLUMN_NAME,''ch'','''') as int)
--             and ChgCode= '+str(@Paycode)+' and AcceptNewValue=1
--            WHERE TABLE_NAME = PARSENAME('''+@tablename+''',1) AND  COLUMN_NAME in (''CH0001'' ,''CH0005'' ,''CH0006'' ,''CH0007'' ,''CH0008'' ,''CH0009'' ,''CH0010'',''CH0019'',''CH0022'',''CH0023'',''CH0024'',''CH0025'',''CH0026'',''CH0027'',''CH0028'',''CH0029'')
--			AND  COLUMN_NAME Like ''CH%'''
 
----select @QueryStr '@QueryStr'
 
--			exec sp_executesql @QueryStr , N' @Str nvarchar(max) OUTPUT', @Str=@Str OUTPUT
 
--			--select @str


--	--select @STR = @STR + 
--	--	   'case when ISNULL(LTRIM(rtrim('+COLUMN_NAME+')) ,'''') = '''' then 
--	--		N'''+LTRIM(rtrim('['+COLUMN_NAME+']'))+char(10)+char(13)+''' else '''' end + '
-- --           FROM DNACLOUDDBBatchTemp.INFORMATION_SCHEMA.Columns
-- --            right join ChngStatFields on ChngStatFields.FieldNo=cast(replace(COLUMN_NAME,'ch','') as int)
-- --            and ChgCode= @Paycode and AcceptNewValue=1
-- --           WHERE TABLE_NAME = PARSENAME(''+@tablename+'',1)
--	--		AND  COLUMN_NAME Like 'CH%'
--			--select @STR '@STR'
--select @STR = SUBSTRING(@STR,1,len(@STR)-1)
-- --select @str

-- create table #temp1 (empid nvarchar(50) , remarks nvarchar(256)) 

-- exec( 'insert into #temp1(empid , remarks) select empid, remarks from '+@tablename)

--exec('UPDATE '+@tablename+'  set remarks= ISNULL(LTRIM(RTRIM(Remarks)),'''') + '+
--							''+ @STR +' where post =1  ')


--exec('UPDATE  t1  set t1.remarks=ISNULL(LTRIM(RTRIM(t1.Remarks)),'''') + N'''+ ''+ @RequiredColumnsStr2 +'''
--							from '+@tablename+' t1 inner join #temp1 t2 on t1.empid = t2.empid  
--							where t1.post =1  and 
--							t1.remarks <> t2.remarks
--							')

--drop table #temp1
----exec ('select * from '+@tablename)
--end

--			End

--			End

		select @str='UPDATE '+@tablename+' set IncreaseAmount=round(IncreaseAmount,'+STR(@DecimalScale)+') '
			PRINT @str


	EXECUTE(@str)	
	
	exec ('update '+@tablename +' set Post =0 from '+@tablename+'t 
		       where ltrim(rtrim(remarks))<>''''
			   ')	
	END

	IF ltrim(rtrim(@tabletype)) ='WP_getExternalData' OR ltrim(rtrim(@tabletype)) = 'WP_GetExternalData_ar' 
		BEGIN
			IF @Paycode >= 100000
			BEGIN 
			SELECT @pcodeno = @Paycode/100000
			SELECT @payrollgroup=@Paycode-(@pcodeno*100000)
			END
			ELSE
			BEGIN
				select @pcodeno = @Paycode
				select @payrollgroup=0
			END
			
			--SELECT @pcodeno = SUBSTRING(ltrim(rtrim(str(@paycode))),0,4), @payrollgroup=SUBSTRING(ltrim(rtrim(str(@paycode))),4,5)
		
		PRINT 'paycodeno '+ str(@pcodeno)
		PRINT 'payrollgroup '+ str(@payrollgroup)
		
		--IF @payrollgroup <> 0
		--BEGIN
		
		DECLARE @errormsg2 AS NVARCHAR(60), @errormsg3 AS NVARCHAR(60)
		
		 SET @errormsg2=N''
		 SELECT @errormsg2= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not A Valid Employee Id'  end)) 
		 
		 SET @errormsg3=N''
		 SELECT @errormsg3= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang,@LogonName),(case when @lang='A' then N'حالة الموظف لا يعمل' ELSE N'Not an active employee'  end))                           
	--select 1	
		select @str='UPDATE '+@tablename+' set remarks= case when '+CASE WHEN @payrollgroup <> 0 THEN ' EmpAssignment.PayrollGroup <> '+ str(@payrollgroup) ELSE '1<>1' END +' then rtrim(ltrim(N'''+ @errormsg2+''')) when EmpAssignment.status <> 1 then rtrim(ltrim(N'''+ @errormsg3+''')) end  
		,post=0, inputamnt=Round(temptable.inputamnt,'+STR(@DecimalScale)+') , Balance=Round(temptable.Balance,'+STR(@DecimalScale)+'), ' +
		CASE WHEN @payrollgroup <> 0 THEN 'Amount=Round(0,'+STR(@DecimalScale) ELSE 'Amount=Round(temptable.Amount,'+STR(@DecimalScale) END  +')   --,inputamnt=0 , Amount=0 
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END +
	'WHERE ' + CASE WHEN @payrollgroup <> 0 THEN ' (EmpAssignment.PayrollGroup <> '+  str(@payrollgroup) ELSE '(1<>1' END  +' OR EmpAssignment.status <> 1  ) and ltrim(rtrim(temptable.remarks))= N'''' '
	
	PRINT @str
	EXECUTE(@str)
	
	PRINT 'Different Payrollgroup'
	 --END 		
			
			
	--		SET @errormsg=N''
	--	 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang),(case when @lang='A' then N'حالة الموظف لا يعمل' ELSE N'Not an active employee'  end))                          
		
		 
	--select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0, inputamnt=Round(temptable.inputamnt,'+STR(@DecimalScale)+') , Balance=Round(temptable.Balance,'+STR(@DecimalScale)+'), Amount=Round(temptable.Amount,'+STR(@DecimalScale)+')  --,inputamnt=0 , Amount=0 
	--FROM '+@tablename+' temptable
	--left JOIN EmpAssignment ON temptable.empid=empassignment.EmployeeId 
	--and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	--'WHERE EmpAssignment.status <> 1 and ltrim(rtrim(temptable.remarks))= N'''' '

	--PRINT @str
	--EXECUTE(@str)
	
	PRINT 'inactive employees'
	
	SET @errormsg=N''
		 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Duplicate Record',@lang,@LogonName),(case when @lang='A' then N'الموظف مكرر' ELSE N'Duplicate Record'  end))                          
		
		 
	select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) , post=0,inputamnt=Round(temptable.inputamnt,'+STR(@DecimalScale)+') , Balance=Round(temptable.Balance,'+STR(@DecimalScale)+'), Amount =Round(temptable.Amount,'+STR(@DecimalScale)+') 
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
	'WHERE temptable.empid in (SELECT t.empid
   FROM '+@tablename+' t  where t.empid= temptable.empid GROUP BY empid having COUNT(empid)>1)  and ltrim(rtrim(temptable.remarks))= N'''' '

	PRINT @str
	EXECUTE(@str)
	
	PRINT 'duplicate employees'
	
		END
		
/*Remove benefit item section*/
		
		

		-------------------------------------------------------------------------------------
	--	select @str='UPDATE '+@tablename+' set name='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
	--FROM '+@tablename+' temptable
	--inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	--left join profile on profile.profileid=empassignment.empid 
	--where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	

	--PRINT @str
	--EXECUTE(@str)
	
	END
    select @str='UPDATE '+@tablename+' set name='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
	FROM '+@tablename+' temptable
	inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
	left join profile on profile.profileid=empassignment.empid 
	where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	PRINT @str
	EXECUTE(@str)

END

-------------------------------------------------------
IF ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalHousingItems%' OR ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalHousingItems_ar%'
OR ltrim(rtrim(@tabletype))LIKE '%GetExternalVacRecords%'  OR ltrim(rtrim(@tabletype))LIKE '%GetExternalVacRecords_ar%'  
OR  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalMisconduct%'
OR ltrim(rtrim(@tabletype))LIKE '%GetExternalAppraisalWMR%'  OR ltrim(rtrim(@tabletype))LIKE '%GetExternalAppraisalWMR_ar%'
OR ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalObjective%'  OR ltrim(rtrim(@tabletype))LIKE '%WP_GetExternalObjective_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalDocuments%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalDocuments_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalevents%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalevents_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalAdditionalevents%' OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalAdditionalevents_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalCompetencies%'
OR LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalBenefitPlan%' 
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalTimePermission%' 
OR LTRIM(rtrim(@tabletype)) LIKE '%WP_GetExternalBenefitItems%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalBenefitItems_ar%'
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalHRRequests%' 
OR LTRIM(RTRIM(@tabletype)) LIKE '%WP_GetExternalTasks%' 
OR  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPaycodes%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPaycodes_ar%'
OR ltrim(rtrim(@tabletype))  LIKE '%WP_GetExternalHistoryPaycodes%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalHistoryPaycodes_ar%'
OR ltrim(rtrim(@tabletype)) ='WP_getExternalChangeOfStatus' OR ltrim(rtrim(@tabletype)) = 'WP_getExternalChangeOfStatus_ar'


BEGIN

 IF @EnableRef =1 
 BEGIN
  select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','RefStatusError',@lang,@LogonName),(case when @lang='A' then N' إسم الحالة غير صحيح ' ELSE N'Not Valid Ref Status'  end))))+''' +char(13)
	          FROM '+@tablename+' temptable 
			  LEFT JOIN NasArrays NasArraysStatus ON temptable.[RStatus]  collate database_default = case when '''+@lang+'''= ''e'' then 
			  ltrim(rtrim(NasArraysStatus.edesc))  collate database_default else ltrim(rtrim(NasArraysStatus.adesc))  collate database_default end 
				AND NasArraysStatus.arrayname=''RStatus'' 
              WHERE temptable.Post=1 and NasArraysStatus.itemno IS null and temptable.[RStatus] is not null
              and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
print (@str)
 EXECUTE(@str)

   select @str='UPDATE '+@tablename+' set remarks= ltrim(rtrim(remarks)) + N''' + ltrim(rtrim(isnull(dbo.Hits_GetDCCaptionWzLogon('Validate','RefSourceError',@lang,@LogonName),(case when @lang='A' then N' إسم المصدر غير صحيح ' ELSE N'Not Valid Ref Source'  end))))+''' +char(13)
	          FROM '+@tablename+' temptable 
			  LEFT JOIN NasArrays NasArraysSource ON temptable.[RSource]  collate database_default= case when '''+@lang+'''= ''e'' then 
			  ltrim(rtrim(NasArraysSource.edesc)) collate database_default else ltrim(rtrim(NasArraysSource.adesc))  collate database_default end  
				AND NasArraysSource.arrayname=''RSource'' 
              WHERE temptable.Post=1 and NasArraysSource.itemno IS null and temptable.[RSource] is not null
              and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
print (@str)
 EXECUTE(@str)

 END
 
End
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
	IF ltrim(rtrim(@tabletype)) = 'WP_JvSetup' or ltrim(rtrim(@tabletype)) = 'WP_JvSetup_ar' 
	BEGIN
	
		SET @str ='UPDATE '+@tablename+' set PaycodeName='+CASE WHEN @lang='A' THEN 'Paycode.PaycodeAName ' ELSE 'Paycode.PaycodeName' END+' 
	,CenterName=' +CASE WHEN @lang='A' THEN 'CostCntr.CenterAName ' ELSE 'CostCntr.CenterName' END+' FROM '+@tablename+' temptable
	left JOIN Paycode ON temptable.Paycode=Paycode.code 
	left join CostCntr on temptable.Center=CostCntr.Center '
	EXECUTE(@str)
	END

------------------------------------ WP_ExternalSystemsBatchPosting -----------------------------------------------------

		IF LTRIM(rtrim(@tabletype)) LIKE '%WP_ExternalSystemsBatchPosting%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_ExternalSystemsBatchPosting_ar%'
	BEGIN
		PRINT @tabletype



	DECLARE @str7 AS nvarchar(max)

	select @str7='UPDATE '+@tablename+' set post= 1
	FROM '+@tablename+' temptable'
	--print @str7
	EXECUTE(@str7)

	select @str7='UPDATE '+@tablename+' set remarks= ''''
	FROM '+@tablename+' temptable
	where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	--PRINT @str2
	EXECUTE(@str7)
	
	DECLARE @errormsg6 AS nvarchar(60)
	SET @errormsg6=''
	
	SELECT @errormsg6= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_ExternalSystemsBatchPosting','errormsg1',@lang,@LogonName),(case when @lang='A' then N'هذا الموظف غير موجود' ELSE N'Employee doesnt exist'  end))                          
	SELECT @str7='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg6+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE  EmpID not in (select employeeid from empassignment)
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	PRINT @str7
	EXECUTE(@str7)

	SELECT @errormsg6= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_ExternalSystemsBatchPosting','errormsg2',@lang,@LogonName),(case when @lang='A' then N'الضريبة لا تسمح بدخول حروف'  ELSE N'Emp901Tax should only contain Numbers'  end))                          
	SELECT @str7='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg6+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE  ISNumeric(emp901tax) = 0
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	PRINT @str7
	EXECUTE(@str7)


	--SELECT @errormsg6= isnull(dbo.Hits_GetDCCaptionWzLogon('common','RegExMessagez',@lang,@LogonName),(case when @lang='A' then N'هذا الموظف غير موجود في مجموعة العمل' ELSE N'Employee doesnt exist in payrollgroup'  end))                          
	--SELECT @str7='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg6+'''))  , post=0  
	--FROM '+@tablename+' temptable
	--WHERE  EmpID not in (select employeeid from empassignment)
	--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	--PRINT @str7
	--EXECUTE(@str7)
	--SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','RegExMessage',@lang,@LogonName),(case when @lang='A' then N'الموظف ليس له بند 901' ELSE N'Emp901Tax should only contain Numbers'  end))                          
	--SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	--FROM '+@tablename+' temptable
	--WHERE  EmpID not in
	--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	----PRINT @str2
	--EXECUTE(@str2)

	END

------------------------------------------------------------------if amount, inputAmount, Balance Exist in tablename----------------
IF EXISTS (SELECT * FROM sys.columns  WHERE Name = N'Amount' AND Object_ID = Object_ID(@tablename)) 
AND EXISTS (SELECT * FROM sys.columns  WHERE Name = N'inputamnt' AND Object_ID = Object_ID(@tablename)) 
AND EXISTS (SELECT * FROM sys.columns  WHERE Name = N'Balance' AND Object_ID = Object_ID(@tablename))
AND @paycode <> 0 AND ltrim(rtrim(@tabletype)) <> 'WP_ApplyExtFinanceChanges' and ltrim(rtrim(@tabletype)) <> 'WP_ApplyExtFinanceChanges_ar' AND  ltrim(rtrim(@tabletype)) <>'WP_GetCostCenterAllocation' AND  ltrim(rtrim(@tabletype)) <>'WP_GetCostCenterAllocation_ar' AND ltrim(rtrim(@tabletype)) <> 'WP_getExternalData' AND ltrim(rtrim(@tabletype)) <> 'WP_GetExternalData_ar'
BEGIN
	select @str='UPDATE '+@tablename+' set Amount=dbo.CalcPaycode(empassignment.empid,'+str(@paycode)+',Round(temptable.inputamnt,'+STR(@DecimalScale)+'),Round(temptable.Balance,'+STR(@DecimalScale)+'))
,post=1
FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	PRINT @str
EXECUTE(@str)
END

IF @pcodeno<>0 AND ltrim(rtrim(@tabletype)) ='WP_getExternalData' OR ltrim(rtrim(@tabletype)) = 'WP_GetExternalData_ar'
   BEGIN
   	select @str='UPDATE '+@tablename+' set Amount=dbo.CalcPaycode(empassignment.empid,'+str(@pcodeno)+',Round(temptable.inputamnt,'+STR(@DecimalScale)+'),Round(temptable.Balance,'+STR(@DecimalScale)+')), inputamnt=Round(temptable.inputamnt,'+STR(@DecimalScale)+') , Balance=Round(temptable.Balance,'+STR(@DecimalScale)+')
    ,post=1
    FROM '+@tablename+' temptable
    inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default
    where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' ) and ltrim(rtrim(temptable.remarks))=N'''' ' 
   + case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else ' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	PRINT @str
EXECUTE(@str)

     SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not a valid employee'  end)) 
     SELECT @str='UPDATE ' +@tablename+ ' set Amount=Round(amount,'+STR(@DecimalScale)+'), inputamnt=Round(inputamnt,'+STR(@DecimalScale)+') , Balance=Round(Balance,'+STR(@DecimalScale)+') where Remarks=rtrim(ltrim('''+@errormsg+'''))'
     PRINT @str
     EXECUTE(@str)

	 SELECT @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalData','ExistSamePaycodeErrorMsg',@lang,@LogonName),(case when @lang='A' then N'هذا الموظف لديه نفس البند من قبل' ELSE N'This employee have the same paycode before'  end)) 
	 SELECT @str='UPDATE ' +@tablename+ ' set remarks=rtrim(ltrim(isnull(remarks,'''')) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg+''')), post=0
				  FROM '+@tablename+' temptable
				  inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default 
				  inner JOIN Monthlytransaction ON  Monthlytransaction.empid= empassignment.empid and Monthlytransaction.paycode = '+str(@pcodeno)+' 
				  INNER JOIN dbo.PayrollGroup ON PayrollGroup.RunNo = MonthlyTransaction.RunNo AND PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
				  where EmpAssignment.Status=1 and (temptable.amount<>0 and temptable.amount=Monthlytransaction.amount) '

     PRINT @str
     EXECUTE(@str)


	END

IF ltrim(rtrim(@tabletype)) ='WP_GetPayrollDataFromExternalSystem' OR ltrim(rtrim(@tabletype)) ='WP_GetPayrollDataFromExternalSystem_ar'
BEGIN	

SELECT @str='UPDATE '+@tablename+' set paycode=case when paycode not in (select externalcode from paycode Where ExternalCode<>0) then 0 else (select TOP 1 code from paycode where paycode.externalcode=paycode and ExternalCode<>0 ORDER BY code desc ) end , inputamnt=round(inputamnt,'+STR(@DecimalScale)+'),amount=round(amount,'+STR(@DecimalScale)+') '

PRINT @str
EXECUTE(@str)

 SET @errormsg=N''
 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetPayrollDataFromExternalSystem','errormsg',@lang,@LogonName),(case when @lang='A' then N'البند غير موجود' ELSE N'Paycode Not Found'  end))                          

SELECT @str='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg+''')), post=0, amount=0 , inputamnt=round(inputamnt,'+STR(@DecimalScale)+') where paycode=0'

PRINT @str
EXECUTE(@str)

select @str='UPDATE '+@tablename+' set inputamnt=IsNull(round(Amount,'+STR(@DecimalScale)+'),''0''),Amount=round(Amount,'+STR(@DecimalScale)+') WHERE inputamnt=''0'' or inputamnt Is Null  '
PRINT @str
EXECUTE(@str)

select @str='UPDATE '+@tablename+' set Amount=dbo.CalcPaycode(empassignment.empid,temptable.paycode,round(temptable.inputamnt,'+STR(@DecimalScale)+'),0),inputamnt=round(temptable.inputamnt,'+STR(@DecimalScale)+')
, post=1 
FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId  collate database_default
left join profile on profile.profileid=empassignment.empid
	             where paycode<>0 and ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	PRINT @str
EXECUTE(@str)
SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then 'موظف غير مسموح به' ELSE 'Not a valid employee'  end)) 
SELECT @str='UPDATE ' +@tablename+ ' set Amount=Round(amount,'+STR(@DecimalScale)+'), inputamnt=Round(inputamnt,'+STR(@DecimalScale)+')  where Remarks=rtrim(ltrim('''+@errormsg+'''))'


PRINT @str
EXECUTE(@str)
	IF @EnableTextValidation = '1' 
		BEGIN
		DECLARE @RefDescription AS NVARCHAR(max)
		SELECT @RefDescription = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetPayrollDataFromExternalSystem', 'RDesc', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الوصف' ELSE 'Ref.Description' END)

		--Validate Ref Descripition
		SELECT @Str = 'UPDATE ' + @tablename + '  SET post = 0, Remarks  = LTRIM(RTRIM(Remarks))  + N''' + @RefDescription + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetPayrollDataFromExternalSystem'', ''RDesc'', RDesc) = 0 
						and Tmptbl.Post = 1 
						and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)
		EXEC('select * from ' + @tablename)
	END
END

IF ltrim(rtrim(@tabletype)) ='WP_GetCostCenterAllocation' OR ltrim(rtrim(@tabletype)) ='WP_GetCostCenterAllocation_ar'
BEGIN 
	SELECT @str='UPDATE '+@tablename+' set CostCenterName=(select case when '''+@lang+''' =''A'' THEN ltrim(rtrim(CostCntr.CenterAName))
	else ltrim(rtrim(CostCntr.CenterName))end  from CostCntr where '+@tablename+'.CostCenter=CostCntr.center  ), Percentage=Round(Percentage,'+STR(@DecimalScale)+') '
	
	PRINT @str
EXECUTE(@str)

	                          

SELECT @str='UPDATE '+@tablename+' set remarks= isnull(dbo.Hits_GetDCCaptionWzLogon(''WP_GetCostCenterAllocation'',''errormsg1'','''+@lang+''','''+@LogonName+'''),(case when '''+@lang+N'''=''A'' then N''الموظف غير موجود'' ELSE N''Employee does not exist''  end)) ,post=0 where '+@tablename+'.empid  in
	( SELECT '+@tablename+'.empid FROM '+@tablename+'LEFT JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default='+@tablename+'.empid collate database_default
	LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup=PayrollGroup.PayrollGroup where PayrollGroup.PayrollGroup<>'+ltrim(rtrim(STR(@Paycode)))+' and '+ltrim(rtrim(STR(@Paycode)))+'<>0 ) and (remarks IS NULL or remarks=N'''')'

PRINT @str
EXECUTE(@str)

SELECT @str='UPDATE '+@tablename+' set remarks=isnull(dbo.Hits_GetDCCaptionWzLogon(''WP_GetCostCenterAllocation'',''errormsg2'','''+@lang+''','''+@LogonName+'''),(case when '''+@lang+N''' =''E'' THEN N''Not active employee'' else N''الموظف لا يعمل'' end)),post=0 where '+@tablename+'.empid not in
	( SELECT '+@tablename+'.empid FROM '+@tablename+'LEFT JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default='+@tablename+'.empid collate database_default
	  where EmpAssignment.Status=1)and (remarks IS NULL or remarks=N'''')'

PRINT @str
EXECUTE(@str)

SELECT @str='UPDATE '+@tablename+' set remarks=isnull(dbo.Hits_GetDCCaptionWzLogon(''WP_GetCostCenterAllocation'',''errormsg3'','''+@lang+''','''+@LogonName+'''),(case when '''+@lang+N''' =''E'' THEN N''Cost center does not exist'' else N''مركز التكلفة غير موجود'' end)) ,post=0
			 where '+@tablename+'.post=1 and '+@tablename+'.empid Not in( SELECT '+@tablename+'.empid FROM '+@tablename+' LEFT JOIN CostCntr ON CostCntr.center='+@tablename+'.CostCenter where '+@tablename+'.CostCenter=CostCntr.center)  
			and (remarks IS NULL or remarks=N'''')'
PRINT @str
EXECUTE(@str)

if	@EnableOrgSetup =1 and @userOrganization <> ''
begin
	select @str='UPDATE '+@tablename+' set remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetCostCenterAllocation','CostCntrOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمركز التكلفه' ELSE N'Check Org. Validation for this cost center'  end))+ '''
	FROM '+@tablename+' temptable
	LEFT JOIN CostCntr on ltrim(rtrim(temptable.CostCenterName collate database_default))= case when '''+@lang+'''= ''e'' then  
			  ltrim(rtrim(CostCntr.CenterName collate database_default)) else ltrim(rtrim(CostCntr.CenterAName collate database_default)) end
	where temptable.Post=1 and ( not exists ( select * from #OrgTree where CostCntr.CostCntrOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or CostCntr.CostCntrOrgs ='''' )) '
	EXECUTE(@str)
	print (@str) 
end  
	

END

IF ltrim(rtrim(@tabletype)) = 'WP_TrainingPlanActivities' or ltrim(rtrim(@tabletype)) = 'WP_TrainingPlanActivities_ar' 
	BEGIN
		
	  SELECT @DateFormat= dateformat FROM SysParam 
  IF @DateFormat=1 SET @DateFormat=103
  IF @DateFormat=2 SET @DateFormat=101
  IF @DateFormat=0 SET @DateFormat=111
 SET @str ='UPDATE '+@tablename+' set 
 NoOfExlDays= dbo.ExcludeWeekends(temptable.TrainActEstStDate,temptable.TrainActEstEndDate,0)
 

	FROM '+@tablename+' temptable '
		--SET @str ='UPDATE '+@tablename+' set NoOfExlDays=dbo.ExcludeWeekends(convert(datetime,temptable.TrainActEstStDate,'+ltrim(rtrim(str(@DateFormat)))+'),convert(datetime,temptable.TrainActEstEndDate,'+ltrim(rtrim(str(@DateFormat)))+'),2) 
	PRINT @str
	EXECUTE(@str)
	
if	@EnableOrgSetup =1 and @userOrganization <> ''
begin
select @str='UPDATE '+@tablename+' set  remarks= remarks+'' '' + N'''+isnull(dbo.Hits_GetDCCaptionWzLogon('WP_TrainingPlanActivities','TrainingCategoriesOrgsValidation',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا التدريب' ELSE N'Check Org. Validation for this Training Category'  end))+ '''FROM '+@tablename+' temptable
	LEFT JOIN TrainingActivities ON  
	RTRIM(LTRIM(temptable.TrainingActivity collate database_default)) = ' + CASE  RTRIM(LTRIM(@lang)) WHEN 'A' THEN 'RTRIM(LTRIM(TrainingCategories.TrainingCategoryAName collate database_default))' ELSE 'RTRIM(LTRIM(TrainingCategories.TrainingCategoryName collate database_default))' END +'where temptable.Post=1 and ( not exists ( select * from #OrgTree where TrainingCategories.TrainingCategoriesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TrainingCategories.TrainingCategoriesOrgs ='''' )) and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end'

EXECUTE(@str)
print (@str)
END

	END
	
IF ltrim(rtrim(@tabletype)) ='WP_ApplyExtFinanceChanges' OR ltrim(rtrim(@tabletype)) ='WP_ApplyExtFinanceChanges_ar'
BEGIN	

IF @Paycode=13		----No Of Points
BEGIN
	select @str='UPDATE '+@tablename+' set OldValue=round(empassignment.hrpoints,'+STR(@DecimalScale)+'),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	  END

IF @Paycode=14		----Basic Salary
BEGIN
	select @str='UPDATE '+@tablename+' set OldValue=round(empassignment.hrbasicsal,'+STR(@DecimalScale)+'),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	  END

IF @Paycode=16		----Fixed Insurance
BEGIN
	select @str='UPDATE '+@tablename+' set OldValue=round(empassignment.hrssfixval,'+STR(@DecimalScale)+'),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
END

IF @Paycode=17		----Variable Insurance
BEGIN
	select @str='UPDATE '+@tablename+' set OldValue=round(empassignment.hrssvarval,'+STR(@DecimalScale)+'),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	  END

IF @Paycode=18		----Bonus Salary
BEGIN
	select @str='UPDATE '+@tablename+' set OldValue=round(empassignment.hrssbonval,'+STR(@DecimalScale)+'),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1 

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	  END

IF @Paycode=20		----Agreed Salary
BEGIN
	select @str='UPDATE '+@tablename+' set OldValue=round(empassignment.ContBasSal,'+STR(@DecimalScale)+'),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
	  END

IF @Paycode>1000		------Other Paycodes
BEGIN
--	PRINT 'before'
--	PRINT @Paycode
	
	SET @Paycode= @Paycode-1000
--	
--	PRINT 'after'
--	PRINT @Paycode
select @str='UPDATE '+@tablename+' set OldValue=isnull(round(h.inputamnt,'+STR(@DecimalScale)+'),0),NewValue=round(NewValue,'+STR(@DecimalScale)+'),post=1

FROM '+@tablename+' temptable
inner JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
left join paycode p on P.code='+rtrim(ltrim(@Paycode))+'
left join HrPCodes h on p.code=h.paycode and h.empid=empassignment.empid
	             where  ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
		
END

PRINT @str
EXECUTE(@str)

SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not a valid employee'  end)) 
SELECT @str='UPDATE ' +@tablename+ ' set NewValue=Round(NewValue,'+STR(@DecimalScale)+'),OldValue=Round(OldValue,'+STR(@DecimalScale)+') where Remarks=rtrim(ltrim('''+@errormsg+'''))'
PRINT @str
EXECUTE(@str)

END
	
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords_ar'
BEGIN	


	  SELECT @DateFormat= dateformat FROM SysParam 
  IF @DateFormat=1 SET @DateFormat=103
  IF @DateFormat=2 SET @DateFormat=101
  IF @DateFormat=0 SET @DateFormat=111

DECLARE @errormsg11 AS NVARCHAR(250)
SELECT @errormsg11= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTimeKeepingRecords','Flagreadererror',@lang,@LogonName),
(case when @lang=N'A' then N'لا يمكن ادخال بيانات فارغة'  ELSE N'Can not insert empty Flag and Reader value'  end))

SET  @str=N'UPDATE '+@tablename+' set post=0, remarks=cast(ltrim(rtrim(remarks)) + N''' +' '+ rtrim(ltrim(@errormsg11)) +''' as nchar(250))  where isnull(flag,'''')='''' and isnull(reader,'''')='''' '
PRINT @str
EXECUTE (@str)




--SET @str=N'UPDATE '+@tablename+' set attenddate=convert(datetime,attenddate,'+str(@DateFormat)+')'
--PRINT @str
        
SET  @str=N'UPDATE '+@tablename+' set attenddate=CAST(ltrim(rtrim(attenddate)) AS CHAR(10)) ,attendTIME=convert(CHAR(8),CONVERT(DATETIME ,attendtime ,'+str(@DateFormat)+'),114)'
PRINT @str
EXECUTE (@str)

SELECT @errormsg11= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalTimeKeepingRecords','Dateformaterror',@lang,@LogonName),
(case when @lang=N'A' then N'شكل التاريخ غير متوافق' ELSE N'Wrong Date Time Format'  end))

SET  @str='UPDATE '+@tablename+' set post=0, remarks=cast(ltrim(rtrim(remarks)) + N''' +' '+ rtrim(ltrim(@errormsg11)) +''' as nchar(250)) , attendtime=null where (isdate(CONVERT(DATETIME ,attenddate,'+str(@DateFormat)+'))=0 or attendtime is null) '
PRINT @str

EXECUTE (@str)

END

-------------------------------------------------------------------------------------------------------------------------------
IF ltrim(rtrim(@tabletype)) Like'%WP_GetExternalEmployees%'
BEGIN	

PRINT 'Start'
PRINT @tabletype
	SET @StartIndex = CHARINDEX('?',@tabletype)
	SET @Consolidation = ISNULL(SUBSTRING(@tabletype,@StartIndex+1,1),0)
	PRINT '@Consolidation : ' + STR(@Consolidation)

	SET @StartIndex = CHARINDEX(',',@tabletype)
    SET @CreateSetp = ISNULL(SUBSTRING(@tabletype,@StartIndex+1,1),0)
	PRINT '@CreateSetp : ' + STR(@CreateSetp)

	DECLARE @str1 AS nvarchar(max)
	
	select @str1='UPDATE '+@tablename+' set post= 1
	FROM '+@tablename+' temptable where post is null'
	PRINT '@str11 : ' 
	print @str1
	EXECUTE(@str1)
	
	select @str1='UPDATE '+@tablename+' set remarks= '''' 
	FROM '+@tablename+' temptable
	where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	PRINT '@str12 : ' 
	print @str1
	EXECUTE(@str1)
	
	DECLARE @errormsg1 AS nvarchar(60)
	SET @errormsg1=''

	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Duplicate Record',@lang,@LogonName),(case when @lang='A' then N'الموظف مكرر' ELSE N'Duplicate Record'  end))                          
	select @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim('''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
	FROM '+@tablename+' temptable
	WHERE isnull(temptable.empid,''0'') <> ''0''  
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and temptable.empid in (SELECT t.empid
    FROM '+@tablename+' t  GROUP BY empid having COUNT(empid)>1) '		
	--PRINT 'duplicate employees'
	--PRINT @str1
	EXECUTE(@str1)
	
	
	--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','EmpIDNumeric',@lang),(case when @lang='A' then N'رقم الموظف يحتوي على حروف' ELSE N'Employee ID should be numeric'  end))                          
	--select @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim('''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
	--FROM '+@tablename+' temptable
	--WHERE isnumeric(isnull(temptable.empid,''0''))=0 
	--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '		
	----PRINT 'duplicate employees'
	----PRINT @str1
	--EXECUTE(@str1)
	
	
	DECLARE @EmployeeidType AS SMALLINT,@EmployeeidLength  AS SMALLINT
	SELECT @EmployeeidType=EmployeeidType,@EmployeeidLength=EmployeeidLength FROM SysParam
	IF @EmployeeidType<>1
	begin
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','EmpIDNumeric',@lang,@LogonName),(case when @lang='A' then N'رقم الموظف يحتوي على حروف' ELSE N'Employee ID should be numeric'  end))                          
		select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) +  CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END +  rtrim(ltrim(N'''+@errormsg1+'''))  , post=0  
		FROM '+@tablename+' temptable
		WHERE isnumeric(isnull(temptable.empid,''0''))=0 
		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '		
		EXECUTE(@str1)
		print(@str1)
	END
	ELSE
	BEGIN
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidEmployeeIdLength',@lang,@LogonName),(case when @lang='A' then N'طول كود الموظف غير مطابق' ELSE N'Employee ID Length is Invalid'  end))                          
		select @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks)) +  CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END +  rtrim(ltrim(N'''+@errormsg1+'''))   , post=0  
		FROM '+@tablename+' temptable
		WHERE len(isnull(temptable.empid,''0''))>'+STR(@EmployeeidLength)+' 
		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '		
		EXECUTE(@str1)
			print(@str1)
	END 	 
	--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','EmployeeIDAlreadyExists',@lang),(case when @lang='A' then N'رقم الموظف موجود مسبقأ' ELSE N'Employee ID Already Exists'  end))                          
	--select @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim('''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
	--FROM '+@tablename+' temptable
	--inner JOIN EmpAssignment ON temptable.empid=cast(empassignment.EmployeeId as nvarchar(255)) 
	--WHERE isnull(EmpAssignment.empid,''0'')<>''0'' 
	--	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	----PRINT 'Employee ID Already Exists'
	----PRINT @str1
	--EXECUTE(@str1)
	--7awel kol al name l aname aw name bs 
	select @str1='UPDATE '+@tablename+' set name='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
	FROM '+@tablename+' temptable
	inner JOIN EmpAssignment ON temptable.empid collate database_default=cast(empassignment.EmployeeId collate database_default as nvarchar(255))
	left join profile on profile.profileid=empassignment.empid
	where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
	+ ' end and isnull(temptable.name,'''') = '''' '	
	--PRINT @str1
	PRINT '@profile: ' 
	print @str1
	EXECUTE(@str1)	

	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','RegExMessage',@lang,@LogonName),(case when @lang='A' then N'الأسم لا يسمح بدخول ارقام' ELSE N'Name should not contain Numbers'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE name like ''%[0-9]%''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	--PRINT 'Name should not contain Numbers'
	--PRINT @str1
	PRINT '@RegExMessage : ' 
	print @str1
	EXECUTE(@str1)


	-- Job
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','JobMissing',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال الوظيفة' ELSE N'Job is Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	where ( isnull('+case when @lang = 'A' then ' temptable.Ajob ' else ' temptable.job ' end +','''')='''' or rtrim(ltrim(temptable.job)) = ''-'' )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and empassignment.EmployeeId is null '	
	--PRINT @str1
	PRINT '@Job : ' 
	print @str1
	PRINT '@userorg : ' 
	print @userOrganization
	EXECUTE(@str1)	
	
	PRINT 1
	-- Gender
	--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','GenderNatnlNoConflict',@lang,@LogonName),(case when @lang='A' then N' نوع الموظف (ذكر / انثى)  والرقم القومي غير متطابقين.' ELSE N'The Gender and National ID is not matched.'  end))                          
	--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	--FROM '+@tablename+' temptable
	--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	--LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
	--left join NasArrays on upper(ltrim(rtrim(NasArrays.arrayname))) = ''GENDER'' and upper(ltrim(rtrim((CASE WHEN '''+LTRIM(@lang)+''' = ''E'' THEN NasArrays.edesc ELSE NasArrays.adesc END)))) = temptable.Gender	
	--where 1=CASE WHEN SUBSTRING((isnull(temptable.NationalIDNumber,Profile.NatnlNo)),13,1) % 2 =0 AND isnull(NasArrays.itemno,Profile.Gender) <>2    THEN 1 WHEN SUBSTRING((isnull(temptable.NationalIDNumber,Profile.NatnlNo)),13,1) % 2 <>0 AND isnull(NasArrays.itemno,Profile.Gender) <>1 THEN 1  ELSE 0 END 
	--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	----and empassignment.EmployeeId is null '	
	----PRINT @str1 and isnull(position,'''')=''''  
	--PRINT @str1
	--EXECUTE(@str1)	
	
	-- Currency
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','CurMissing',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال العملة' ELSE N'Currency is Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=CONVERT(NVARCHAR(256),rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+''')))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	where ( ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.ACurrency ' else ' temptable.Currency ' end +','''')))='''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.ACurrency ' else ' temptable.Currency ' end +')) = ''-'' )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and empassignment.EmployeeId is null  '	
	--PRINT @str1 and isnull(position,'''')=''''  
	
	EXECUTE(@str1)	
	PRINT (@str1)
	-- Org
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','OrgMissing',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال الادارة' ELSE N'Organization is Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default= empassignment.EmployeeId collate database_default
	where (isnull(CASE 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg7 ' else ' temptable.Org7 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg7 ' else ' temptable.Org7 ' end +')) <> ''-'' THEN Org7 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg6 ' else ' temptable.Org6 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg6 ' else ' temptable.Org6 ' end +')) <> ''-'' THEN Org6 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg5 ' else ' temptable.Org5 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg5 ' else ' temptable.Org5 ' end +')) <> ''-'' THEN Org5 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg4 ' else ' temptable.Org4 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg4 ' else ' temptable.Org4 ' end +')) <> ''-'' THEN Org4 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg3 ' else ' temptable.Org3 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg3 ' else ' temptable.Org3 ' end +')) <> ''-'' THEN Org3 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg2 ' else ' temptable.Org2 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg2 ' else ' temptable.Org2 ' end +')) <> ''-'' THEN Org2 
	WHEN ltrim(rtrim(isnull('+case when @lang = 'A' then ' temptable.AOrg1 ' else ' temptable.Org1 ' end +',''''))) <> '''' and rtrim(ltrim('+case when @lang = 'A' then ' temptable.AOrg1 ' else ' temptable.Org1 ' end +')) <> ''-'' THEN Org1 
	END,'''') =''''  )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  
	and empassignment.EmployeeId is null '	
	--PRINT @str1 and isnull(position,'''')='''' 
	--PRINT @str1
	EXECUTE(@str1)	
	PRINT (@str1)

	-- Employee Name
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','EmployeeNameMissing',@lang,@LogonName),(case when @lang='A' then N'يجب إدخال اسم الموظف' ELSE N'Employee Name Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default = empassignment.EmployeeId collate database_default
	WHERE ( isnull(temptable.Name,'''')= '''' or rtrim(ltrim(temptable.Name)) = ''-'' )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and empassignment.EmployeeId is null '	
	--PRINT 'Employee Name Missing'
	--PRINT @str1
	EXECUTE(@str1)

	PRINT 'PayrollGroup'
	-- PayrollGroup Insert 
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','PayrollGroupMissing',@lang,@LogonName),(case when @lang='A' then N'يجب إدخال مجموعة المرتبات' ELSE N'PayrollGroup Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default = empassignment.EmployeeId collate database_default
	Inner JOIN NasArrays ON Ltrim(Rtrim('+case when @lang = 'A' then ' temptable.APayrollStatus ' else ' temptable.PayrollStatus ' end +')) collate database_default = '+CASE WHEN @lang = 'E' THEN 'Ltrim(Rtrim(edesc)) collate database_default' ELSE 'Ltrim(Rtrim(adesc)) collate database_default' END +' and  NasArrays.itemno = 1 and NasArrays.ArrayName=''Status''
	WHERE ( isnull('+case when @lang = 'A' then ' temptable.APayrollgroup ' else ' temptable.Payrollgroup ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.APayrollgroup ' else ' temptable.Payrollgroup ' end +')) = ''-'' )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and empassignment.EmployeeId is null and '+case when @lang = 'A' then ' temptable.APayrollGroup ' else ' temptable.PayrollGroup ' end +' is null '	
	--PRINT 'Employee Name Missing'
	PRINT @str1
	EXECUTE(@str1)

    -- PayrollGroup Update 
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','PayrollGroupMissing',@lang,@LogonName),(case when @lang='A' then N'يجب إدخال اسم الموظف' ELSE N'PayrollGroup Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	inner JOIN EmpAssignment ON temptable.empid collate database_default = empassignment.EmployeeId collate database_default
	Inner JOIN NasArrays ON Ltrim(Rtrim('+case when @lang = 'A' then ' temptable.APayrollStatus ' else ' temptable.PayrollStatus ' end +')) collate database_default = '+CASE WHEN @lang = 'E' THEN 'Ltrim(Rtrim(edesc)) collate database_default' ELSE 'Ltrim(Rtrim(adesc collate database_default))' END +' and  NasArrays.itemno = 1 and NasArrays.ArrayName=''Status''
	WHERE ( isnull('+case when @lang = 'A' then ' temptable.APayrollgroup ' else ' temptable.Payrollgroup ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.APayrollgroup ' else ' temptable.Payrollgroup ' end +')) = ''-'' )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and empassignment.PayrollGroup is null and temptable.PayrollGroup is null '	
	--PRINT 'Employee Name Missing'
	PRINT @str1
	EXECUTE(@str1)


	-- HireDate
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','HireDateMissing',@lang,@LogonName),(case when @lang='A' then N'يجب إدخال تاريخ التعيين' ELSE N'Hire Date Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid collate database_default= empassignment.EmployeeId collate database_default
	WHERE (isnull(temptable.HireDate,'''')= '''' or temptable.HireDate=''1900-01-01'' or rtrim(ltrim(temptable.HireDate)) = ''-'' ) 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end and empassignment.EmployeeId is null  '	
	--PRINT 'Hire Date Missing'
	--PRINT @str1
	EXECUTE(@str1)
		PRINT @str1
	
	-- HRStatus
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','HRStatusMissing',@lang,@LogonName),(case when @lang='A' then N'يجب إدخال حالة التعيين' ELSE N'HR Status Missing'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	left JOIN EmpAssignment ON temptable.empid collate database_default= empassignment.EmployeeId collate database_default
	WHERE ( isnull('+case when @lang = 'A' then ' temptable.AHrStatus ' else ' temptable.HrStatus ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.AHrStatus ' else ' temptable.HrStatus ' end +')) = ''-'' )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	 and empassignment.EmployeeId is null'	
	--PRINT 'HR Status Missing'
	--PRINT @str1
	EXECUTE(@str1)
	PRINT @str1


	--Gender Validation
	SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','GenderInvalid',@lang),(CASE WHEN @lang='A' THEN N'النوع غير صالح' ELSE N'Gender Is Not Valid'  END))                          
	SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))   , post=0  
	FROM '+@tablename+' temptable
	left join NasArrays on ltrim(rtrim('+CASE WHEN @lang = 'E' THEN ' NasArrays.edesc ' ELSE ' NasArrays.adesc ' END+')) ='+case when @lang='A' then 'ltrim(rtrim(temptable.AGender))' else 'ltrim(rtrim(temptable.Gender)) ' end +' and upper(ltrim(rtrim(NasArrays.arrayname))) = ''GENDER'' 
	where isnull('+case when @lang='A' then 'temptable.AGender' else 'temptable.Gender' end +' ,'''') <>'''' and NasArrays.itemno is null
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	EXECUTE(@str1)
	PRINT @str1

	-- SCStatus Validation
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'ASCStatus' else 'SCStatus' end ,@lang,@LogonName),(case when @lang='A' then N'حالة رسم الخدمة' ELSE N'SC Status'  end))                          
			+' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))                 
		SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))   , post=0  
		FROM '+@tablename+' temptable
		left join NasArrays on upper(ltrim(rtrim(('+CASE WHEN @lang = 'E' THEN ' NasArrays.edesc ' ELSE ' NasArrays.adesc ' END+')))) = '+case when @lang='A' then 'temptable.ASCStatus' else 'temptable.SCStatus' end +' and upper(ltrim(rtrim(NasArrays.arrayname))) = ''SCStatus'' 
		where isnull('+case when @lang='A' then 'temptable.ASCStatus' else 'temptable.SCStatus' end +' ,'''') <>'''' and NasArrays.itemno is null
		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
		EXECUTE(@str1)
		print(@str1)

	-- Payroll Status Validation
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'APayrollStatus' else  'PayrollStatus' end ,@lang,@LogonName),(case when @lang='A' then N'حالة المرتب' ELSE N'Payroll Status'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		FROM '+@tablename+' temptable
		left join NasArrays on upper(ltrim(rtrim(('+CASE WHEN @lang = 'E' THEN ' NasArrays.edesc ' ELSE ' NasArrays.adesc ' END +')))) = '+case when @lang='A' then 'temptable.APayrollStatus' else 'temptable.PayrollStatus' end +' and upper(ltrim(rtrim(NasArrays.arrayname))) = ''Status'' 
		where isnull('+case when @lang='A' then 'temptable.APayrollStatus' else 'temptable.PayrollStatus' end +' ,'''') <>'''' and NasArrays.itemno is null
		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
		EXECUTE(@str1)
		print(@str1)
		-- Marital Status Validation
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AMaritalStatus' else 'MaritalStatus' end ,@lang,@LogonName),(case when @lang='A' then N'الحالة الإجتماعية' ELSE N'Marital Status'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))   , post=0  
		FROM '+@tablename+' temptable
		left join NasArrays on upper(ltrim(rtrim(('+CASE WHEN @lang = 'E' THEN'  NasArrays.edesc ' ELSE ' NasArrays.adesc ' END+')))) = '+case when @lang='A' then 'temptable.AMaritalStatus' else 'temptable.MaritalStatus' end +' and upper(ltrim(rtrim(NasArrays.arrayname))) = ''SocStatus'' 
		where isnull('+case when @lang='A' then 'temptable.AMaritalStatus' else 'temptable.MaritalStatus' end +' ,'''') <>'''' and NasArrays.itemno is null
		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
		print(@str1)
		EXECUTE(@str1)
		
	--Gender Required
	IF @GenderRequired = 1
		BEGIN
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','GenderValidation',@lang),(CASE WHEN @lang='A' THEN  N'يجب ادخال النوع ' ELSE 'Gender Is Required.'  END))                          
			SELECT @str1=N'UPDATE '+@tablename+' set  remarks= rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))   , post=0  
			FROM '+@tablename+' temptable
			where nullif(ltrim(rtrim(temptable.Gender)), N'''') is null
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			print(@str1)
			EXECUTE(@str1)
					
		END
		                --Location Required
        IF @LocationRequired = 1
                BEGIN
                        SELECT @errormsg1=ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','LocationValidation',@lang,@LogonName), (CASE WHEN @lang = 'A' THEN N'يجب ادخال الموقع ' ELSE 'Location is required . ' END ))                    
                        SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
                        FROM '+@tablename+' temptable
                        left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
                        where ( (isnull('+case when @lang = 'A' then ' temptable.ALocation ' else ' temptable.Location ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.ALocation ' else ' temptable.Location ' end +')) = ''-'' )) 
                        and (empassignment.EmployeeId is null -- or (empassignment.EmployeeId is not null and empassignment.LocationNo is null) ) 
                       )
        and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end
        '        
        PRINT @str1
        EXECUTE(@str1)        
        END        
        
        IF @NatnlNoFirstDigitCheck =1
        BEGIN
                 SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','NatnlNoFirstDigitCheck',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ان يكون الرقم الاول في الرقم القومي 2 او 3.' ELSE 'The National No First Digit must be 2 or 3.' END )
         select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
                     FROM '+@tablename+' temptable
                     WHERE CASE WHEN SUBSTRING((temptable.NationalIDNumber),1,1) NOT IN(2,3) THEN 1 ELSE 0 END =1 and rtrim(ltrim(temptable.NationalIDNumber)) <>''''
                     and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end
                      '            
                     PRINT @str1
                     EXECUTE(@str1)
        END
        
       IF @MobileMandatory=1
        BEGIN
        	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','MobileRequiredValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال رقم الموبايل' ELSE N'Mobile is required .' END )
			 select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
                     FROM '+@tablename+' temptable
                     LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
                     WHERE temptable.MobileNumber IS NULL 
                     AND empassignment.EmployeeId is null
                     AND temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '            
             PRINT @str1
             EXECUTE(@str1)
        END
        
        
        IF @VacPackMandatory =1
        BEGIN
        	       SELECT @errormsg1=ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','VacPackRequiredValidation',@lang,@LogonName), (CASE WHEN @lang = 'A' THEN N'يجب ادخال كود الأجازة' ELSE N'Vacation Package is required .' END ))                    
                   SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
                   FROM '+@tablename+' temptable
                   LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
                   WHERE  isnull('+case when @lang = 'A' then ' temptable.AVacPack ' else ' temptable.VacPack ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.AVacPack ' else ' temptable.VacPack ' end +')) = ''-'' 
                   AND empassignment.EmployeeId is null  
                   AND temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '        
        PRINT @str1
        EXECUTE(@str1) 
        END
        
        IF @TimeRuleRequired =1
        BEGIN
        	       SELECT @errormsg1=ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','TKRuleRequiredValidation',@lang,@LogonName), (CASE WHEN @lang = 'A' THEN N'يجب ادخال كود قاعدة حساب الوقت' ELSE N'Timekeeping Rule is required .' END ))                    
                   SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
                   FROM '+@tablename+' temptable
                   LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
                   WHERE  isnull('+case when @lang = 'A' then ' temptable.ATimeRule ' else ' temptable.TimeRule ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.ATimeRule ' else ' temptable.TimeRule ' end +')) = ''-'' 
                   AND empassignment.EmployeeId is null  
                   AND temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '        
        PRINT @str1
        EXECUTE(@str1) 
        END
        
        IF @ContractStartMandatory=1
        BEGIN
        	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','ContractStartRequiredValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال تاريخ بداية التعاقد' ELSE N'Contract Start Date is required .' END )
			 select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
                     FROM '+@tablename+' temptable
                     LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
                     WHERE temptable.ContractStartDate IS NULL 
                     AND empassignment.EmployeeId is null
                     AND temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '            
             PRINT @str1
             EXECUTE(@str1)
        END
        
        IF @ContractEndMandatory=1
        BEGIN
        	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','ContractEndRequiredValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال تاريخ نهاية التعاقد' ELSE N'Contract End Date is required .' END )
			 select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
                     FROM '+@tablename+' temptable
                     LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
                     WHERE temptable.ContractEndDate IS NULL 
                     AND empassignment.EmployeeId is null
                     AND temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '            
             PRINT @str1
             EXECUTE(@str1)
        END		
        
        
    IF @BirthHireTermValidation = 1
		BEGIN
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','HireBeforeBirth',@lang,@LogonName),(case when @lang='A' then N'  تاريخ التعيين قبل تاريخ الميلاد او يساوى' ELSE 'Hire date before Birth date or equal'  end))                          
			SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
						LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId	
						WHERE isnull(temptable.Birthdate,profile.Birthdate) IS NOT NULL  
						AND cast(isnull(temptable.Birthdate,profile.Birthdate) as smalldatetime) >= cast(isnull(temptable.HireDate,EmpAssignment.HireDate) as smalldatetime)
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
						PRINT @str1
						EXECUTE(@str1)
			
				SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','HireBirthNotMatching',@lang,@LogonName),(case when @lang='A' then N' تاريخ التعيين غير متوافق مع تاريخ الميلاد' ELSE 'Hire date does not match with date of birth'  end))                          
		   		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
							FROM '+@tablename+' temptable
							left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
							LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId	
							WHERE isnull(temptable.Birthdate,profile.Birthdate) IS NOT NULL  
							AND   isnull(temptable.HireDate,EmpAssignment.HireDate) IS NOT NULL  
							AND  DATEDIFF(YEAR,cast(isnull(temptable.Birthdate,profile.Birthdate) as smalldatetime) ,cast(isnull(temptable.HireDate,EmpAssignment.HireDate) as smalldatetime))<18  
							and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
				PRINT @str1
				EXECUTE(@str1)
			
				SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','TermBeforeHire',@lang,@LogonName),(case when @lang='A' then N'تاريخ التوقف قبل تاريخ التعيين' ELSE 'Termination date before Hire date'  end))                          
			 	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
						LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId	
						WHERE isnull(temptable.HireDate,EmpAssignment.HireDate) IS NOT NULL  
						And isnull(temptable.Terminationdate,EmpAssignment.TermDate) IS NOT NULL  
						AND   cast(isnull(temptable.HireDate,EmpAssignment.HireDate) as smalldatetime)>  cast(isnull(temptable.Terminationdate,EmpAssignment.TermDate) as smalldatetime)
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
				PRINT @str1
				EXECUTE(@str1)
			
			
		  END    
		
	IF @GenderNatnlNoConflict = 1
		BEGIN
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','GenderNatnlNoConflict',@lang,@LogonName),(case when @lang='A' then N' نوع الموظف (ذكر / انثى)  والرقم القومي غير متطابقين.' ELSE N'The Gender and National ID is not matched.'  end))                          
			SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
				FROM '+@tablename+' temptable
				left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
				LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
				left join NasArrays on upper(ltrim(rtrim(NasArrays.arrayname))) = ''GENDER'' and upper(ltrim(rtrim((CASE WHEN '''+LTRIM(@lang)+''' = ''E'' THEN NasArrays.edesc ELSE NasArrays.adesc END)))) = temptable.Gender	
				where 1=CASE WHEN SUBSTRING((isnull(temptable.NationalIDNumber,Profile.NatnlNo)),13,1) % 2 =0 AND isnull(NasArrays.itemno,Profile.Gender) <>2  THEN 1 WHEN SUBSTRING((isnull(temptable.NationalIDNumber,Profile.NatnlNo)),13,1) % 2 <>0 AND isnull(NasArrays.itemno,Profile.Gender) <>1 THEN 1  ELSE 0 END 
				and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
				PRINT @str1
				EXECUTE(@str1)
		  END
		
	
	--Religion
	SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaptionWzLogon('V_Employees','ReligionInvalid',@lang,@LogonName),(CASE WHEN @lang='A' THEN N'الديانة غير صالحة' ELSE N'Religion Is Not Valid'  END))                          
	SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))   , post=0  
	FROM '+@tablename+' temptable
	left join NasArrays on upper(ltrim(rtrim(('+CASE WHEN @lang = 'E' THEN ' NasArrays.edesc ' ELSE ' NasArrays.adesc ' END+')))) ='+case when @lang='A' then 'temptable.AReligion' else 'temptable.Religion' end +' and upper(ltrim(rtrim(NasArrays.arrayname))) = ''RELIGION'' 
	where isnull('+case when @lang='A' then 'temptable.AReligion' else 'temptable.Religion' end +' ,'''') <>'''' and NasArrays.itemno is null
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	PRINT @str1
	EXECUTE(@str1)
	
	--MilStatus
	SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaptionWzLogon('V_Employees','MilStatusInvalid',@lang,@LogonName),(CASE WHEN @lang='A' THEN N'حالة الخدمةالعسكرية غير صالحة' ELSE N'Military Status Is Not Valid'  END))                          
	SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left join NasArrays on upper(ltrim(rtrim(('+CASE WHEN @lang = 'E' THEN ' NasArrays.edesc ' ELSE ' NasArrays.adesc ' END+')))) = '+case when @lang='A' then 'temptable.AMilStatus' else 'temptable.MilStatus' end +' and upper(ltrim(rtrim(NasArrays.arrayname))) = ''MILSTATUS'' 
	where isnull('+case when @lang='A' then 'temptable.AMilStatus' else 'temptable.MilStatus' end +' ,'''')<>'''' and NasArrays.itemno is null
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	print @str1
	EXECUTE(@str1)


	IF @MilitaryStatusMandatory = 1
	BEGIN
		-- Required For Male & Not Required For Female
		IF @MilitaryRequiredBasedOnGender = 1
		BEGIN
			--SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaptionWzLogon('V_Employees','MilitaryStatusRequired',@lang,@LogonName),(CASE WHEN @lang='A' THEN N'الموقف من الخدمة مطلوب' ELSE 'Military Status Is Required'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
   --         LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			--left join NasArrays Milstatus on upper(ltrim(rtrim(CASE WHEN '''+@lang+''' = ''E'' THEN Milstatus.edesc ELSE Milstatus.adesc END))) = CASE WHEN '''+@lang+''' = ''E'' THEN temptable.MilStatus ELSE temptable.AMilStatus END and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			--inner join NasArrays Gender  on gender.itemno= profile.Gender 
			--and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(CASE WHEN '''+@lang+''' = ''E'' then temptable.Gender else temptable.AGender end ,CASE WHEN '''+@lang+''' = ''E'' then gender.edesc else gender.adesc end) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			--where nullif(ltrim(rtrim(CASE WHEN '''+@lang+''' = ''E'' THEN temptable.MilStatus ELSE temptable.AMilStatus END)), N'''') is null and Gender.itemno = 1
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			
		    SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			LEFT join NasArrays Milstatus on upper(ltrim(rtrim(CASE WHEN '''+@lang+''' = ''E''  THEN Milstatus.edesc ELSE Milstatus.adesc END))) = nullif(CASE WHEN '''+@lang+''' = ''E'' THEN temptable.MilStatus ELSE temptable.AMilStatus END,'''')  and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			LEFT join NasArrays Gender  on  upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E''  THEN Gender.edesc ELSE Gender.adesc END)))) =      nullif(CASE WHEN '''+@lang+''' = ''E''  then temptable.Gender else temptable.AGender END,'''')  and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			where ISNULL(ISNULL(Milstatus.itemno,PROFILE.milstatus),0) =0 and ISNULL(Gender.itemno,PROFILE.gender) = 1
			and temptable.Row_Number = case when   ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else  ' + STR(@Paycode) + ' end '	

			PRINT @str1
			EXECUTE(@str1)

			--MilCardNo With Gender (Male)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaptionWzLogon('V_Employees','MilitaryCardNumberRequired',@lang,@LogonName),(CASE WHEN @lang='A' THEN N'رقم البطاقة العسكرية مطلوب' ELSE 'Military Card Number Is Required'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
   --         LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			--inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			--where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is null and Gender.itemno = 1
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			
				SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
				FROM '+@tablename+' temptable
				LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
				LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
				LEFT join NasArrays Gender on  upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E''  THEN Gender.edesc ELSE Gender.adesc END)))) =  nullif(CASE WHEN '''+@lang+''' = ''E''  then temptable.Gender else temptable.AGender END,'''')   and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 			
				where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is null and Gender.itemno = 1
			   and temptable.Row_Number = case when    ' + STR(@Paycode) + ' = 0  then temptable.Row_Number else          0 end '

			PRINT @str1
			EXECUTE(@str1)

		    --MilStatus With Gender (FeMale)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaptionWzLogon('V_Employees','MilitaryStatusForGender',@lang,@LogonName),(CASE WHEN @lang='A' THEN N'الموقف من الخدمة غير صالح لهذا النوع' ELSE N'Military Status is not valid for this Gender'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
   --         LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			--left join NasArrays Milstatus on upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Milstatus.edesc ELSE Milstatus.adesc END)))) = temptable.MilStatus and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			--inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			--where nullif(ltrim(rtrim(temptable.MilStatus)), N'''') is not null and Gender.itemno = 2
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			
			 SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			LEFT join NasArrays Milstatus on upper(ltrim(rtrim(CASE WHEN '''+@lang+''' = ''E''  THEN Milstatus.edesc ELSE Milstatus.adesc END))) = nullif(CASE WHEN '''+@lang+''' = ''E'' THEN temptable.MilStatus ELSE temptable.AMilStatus END,'''')  and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			LEFT join NasArrays Gender  on  upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E''  THEN Gender.edesc ELSE Gender.adesc END)))) =      nullif(CASE WHEN '''+@lang+''' = ''E''  then temptable.Gender else temptable.AGender END,'''')  and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			where ISNULL(ISNULL(Milstatus.itemno,PROFILE.milstatus),0) <>0 and ISNULL(Gender.itemno,PROFILE.gender) = 2
			and temptable.Row_Number = case when   ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else  ' + STR(@Paycode) + ' end '	

			PRINT @str1
			EXECUTE(@str1)

			--MilCardNo With Gender (FeMale)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaptionWzLogon('V_Employees','MilitaryCardNumberForGender',@lang,@LogonName),(CASE WHEN @lang='A' THEN N'رقم البطاقة العسكرية غير صالح لهذا النوع' ELSE N'Military Card number is not valid for this Gender'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
   --         LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			--inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			--where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is not null and Gender.itemno = 2
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			
			SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			LEFT join NasArrays Gender on  upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E''  THEN Gender.edesc ELSE Gender.adesc END)))) =  nullif(CASE WHEN '''+@lang+''' = ''E''  then temptable.Gender else temptable.AGender END,'''')   and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 			
			where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is not null and Gender.itemno = 2
			and temptable.Row_Number = case when    ' + STR(@Paycode) + ' = 0  then temptable.Row_Number else 0 end '
			
			PRINT @str1
			EXECUTE(@str1)
		END

		-- Required For Female & Not Required For Male
		IF @MilitaryRequiredBasedOnGender = 2
		BEGIN
			--MilStatus With Gender (Female)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','MilitaryStatusRequired',@lang),(CASE WHEN @lang='A' THEN N'الموقف من الخدمة مطلوب' ELSE 'Military Status Is Required'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
   --         LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			--left join NasArrays Milstatus on upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Milstatus.edesc ELSE Milstatus.adesc END)))) = temptable.MilStatus and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			--inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			--where nullif(ltrim(rtrim(temptable.MilStatus)), N'''') is null and Gender.itemno = 2
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			
				
			 SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			LEFT join NasArrays Milstatus on upper(ltrim(rtrim(CASE WHEN '''+@lang+''' = ''E''  THEN Milstatus.edesc ELSE Milstatus.adesc END))) = nullif(CASE WHEN '''+@lang+''' = ''E'' THEN temptable.MilStatus ELSE temptable.AMilStatus END,'''')  and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			LEFT join NasArrays Gender  on  upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E''  THEN Gender.edesc ELSE Gender.adesc END)))) =      nullif(CASE WHEN '''+@lang+''' = ''E''  then temptable.Gender else temptable.AGender END,'''')  and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			where ISNULL(ISNULL(Milstatus.itemno,PROFILE.milstatus),0) =0 and ISNULL(Gender.itemno,PROFILE.gender) = 2
			and temptable.Row_Number = case when   ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else  ' + STR(@Paycode) + ' end '	
			PRINT @str1
			EXECUTE(@str1)

			--MilCardNo With Gender (Female)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','MilitaryCardNumberRequired',@lang),(CASE WHEN @lang='A' THEN N'رقم البطاقة العسكرية مطلوب' ELSE 'Military Card Number Is Required'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
   --         LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			--inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			--where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is null and Gender.itemno = 2
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
		
				SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			LEFT join NasArrays Gender on  upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E''  THEN Gender.edesc ELSE Gender.adesc END)))) =  nullif(CASE WHEN '''+@lang+''' = ''E''  then temptable.Gender else temptable.AGender END,'''')   and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 			
			where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is null and Gender.itemno = 2
			and temptable.Row_Number = case when    ' + STR(@Paycode) + ' = 0  then temptable.Row_Number else 0 end '
			PRINT @str1
			EXECUTE(@str1)

		    --MilStatus With Gender (Male)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','MilitaryStatusForGender',@lang),(CASE WHEN @lang='A' THEN N'الموقف من الخدمة غير صالح لهذا النوع' ELSE N'Military Status is not valid for this Gender'  END))                          
			SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
            LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			left join NasArrays Milstatus on upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Milstatus.edesc ELSE Milstatus.adesc END)))) = temptable.MilStatus and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			where nullif(ltrim(rtrim(temptable.MilStatus)), N'''') is not null and Gender.itemno = 1
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			PRINT @str1
			EXECUTE(@str1)

			--MilCardNo With Gender (Male)
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','MilitaryCardNumberForGender',@lang),(CASE WHEN @lang='A' THEN N'رقم البطاقة العسكرية غير صالح لهذا النوع' ELSE N'Military Card number is not valid for this Gender'  END))                          
			SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
            LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			inner join NasArrays Gender on gender.itemno= profile.Gender and upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Gender.edesc ELSE Gender.adesc END)))) = ISNULL(temptable.Gender,gender.edesc) and upper(ltrim(rtrim(Gender.arrayname))) = ''GENDER'' 
			where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is not null and Gender.itemno = 1
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			PRINT @str1
			EXECUTE(@str1)
		END

		-- Required Without Take Gender In Considiration
		IF @MilitaryRequiredBasedOnGender = 3
		BEGIN
			--MilStatus
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','MilitaryStatusRequired',@lang),(CASE WHEN @lang='A' THEN N'الموقف من الخدمة مطلوب' ELSE 'Military Status Is Required'  END))                          
			
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--left join NasArrays Milstatus on upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN Milstatus.edesc ELSE Milstatus.adesc END)))) = temptable.MilStatus and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			--where nullif(ltrim(rtrim(temptable.MilStatus)), N'''') is null
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			   SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			LEFT join NasArrays Milstatus on upper(ltrim(rtrim(CASE WHEN '''+@lang+''' = ''E''  THEN Milstatus.edesc ELSE Milstatus.adesc END))) = nullif(CASE WHEN '''+@lang+''' = ''E'' THEN temptable.MilStatus ELSE temptable.AMilStatus END,'''')  and upper(ltrim(rtrim(Milstatus.arrayname))) = ''MILSTATUS'' 
			where ISNULL(ISNULL(Milstatus.itemno,PROFILE.milstatus),0) =0 
			and temptable.Row_Number = case when   ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else  ' + STR(@Paycode) + ' end '	
			EXECUTE(@str1)

			--MilCardNo
			SELECT @errormsg1= ISNULL(dbo.Hits_GetDCCaption('V_Employees','MilitaryCardNumberRequired',@lang),(CASE WHEN @lang='A' THEN N'رقم البطاقة العسكرية مطلوب' ELSE 'Military Card Number Is Required'  END))                          
			--SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--where nullif(ltrim(rtrim(temptable.MilCardNo)), N'''') is null
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			
				
			SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
			LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
			where nullif(ltrim(rtrim(isnull(temptable.MilCardNo,profile.MilCardNo))), N'''') is null 
			and temptable.Row_Number = case when    ' + STR(@Paycode) + ' = 0  then temptable.Row_Number else 0 end '
			EXECUTE(@str1)
		
		END
	END


	-- Privacy		
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','PrivacyMessage',@lang,@LogonName),(case when @lang='A' then N'الخصوصية رقم [0-9]' ELSE N'Privacy only [0-9]'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (temptable.Privacy not like ''%[0-9]%'' or len(temptable.Privacy) > 1)
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	
	--PRINT 'Name should not contain Numbers'
	-- PRINT @str1
	EXECUTE(@str1)


	--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','GenderInvalid',@lang,@LogonName),(case when @lang='A' then N'النوع غير صالح' ELSE N'Gender is not valid'  end))                          
	--		select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
	--		FROM '+@tablename+' temptable
	--		left join NasArrays on upper(ltrim(rtrim((CASE WHEN '''+@lang+''' = ''E'' THEN NasArrays.edesc ELSE NasArrays.adesc END)))) = temptable.Gender and upper(ltrim(rtrim(NasArrays.arrayname))) = ''GENDER'' 
	--		where temptable.Gender is not null and NasArrays.itemno is null
	--		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	--		--PRINT @str1 and isnull(position,'''')=''''  
	--		EXECUTE(@str1)	



		IF @NatnNoMandatory = 1 -- For Mandatory National ID field
		BEGIN 		
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','EmptyNationalNo',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال الرقم القومى' ELSE N'National ID is Empty'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks= rtrim(ltrim(remarks)) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END +  rtrim(ltrim(N'''+@errormsg1+'''))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment on EmpAssignment.employeeId = temptable.empid 
			left join Profile on Profile.ProfileId=EmpAssignment.empid
			where isnull(NationalIDNumber,'''')='''' 
			and( EmpAssignment.employeeId  is null or (EmpAssignment.employeeId  is not null and Profile.NatnlNo =''''))
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			PRINT (@str1)	
			EXECUTE(@str1)	
		END 

		
		IF @NatnNoUnique = 1  -- For National ID already exist
		BEGIN
			--@ValidateNatnlNo is a sysparamconfig to apply this validation on certain nationalities only 
				
            SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','ErrorNationalNo',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى موجود مسبقاً' ELSE N'National ID Already Exists'  end))                          
			--@ValidateNatnlNo for egyptians only
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			inner JOIN Profile ON temptable.NationalIDNumber=cast(Profile.NatnlNo AS nvarchar(20))  
			INNER JOIN EmpAssignment ON EmpAssignment.EmpId = Profile.ProfileId and temptable.EmpID <> EmpAssignment.EmployeeId
			left join Nations on ' + case when @lang='e' then 'ltrim(rtrim(temptable.Nationality))' else 'ltrim(rtrim(temptable.ANationality))' end  +'=' +case when @lang='e' then 'LTRIM(RTRIM(Nations.NationName))' else 'LTRIM(RTRIM(Nations.NationAName))' end + ' 
			WHERE isnull(Profile.NatnlNo,'''') <>''''
			and temptable.empid collate database_default <> empassignment.EmployeeId collate database_default
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end
			 AND ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId))+'',%'''   --i am the egyptian
			 +'or '''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Profile.NationId)) +'',%'''  -- others with same national no are egyptians
			 +' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'') '
		
			PRINT @str1
			EXECUTE(@str1)
			
			---------------------------------------------------
			--@ValidateNatnlNo for egyptians only
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','DuplicateNationalID',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى مكرر' ELSE N'National ID Duplicate'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			left join Nations on ' + case when @lang='e' then 'ltrim(rtrim(temptable.Nationality))' else 'ltrim(rtrim(temptable.ANationality))' end  +'=' +case when @lang='e' then 'LTRIM(RTRIM(Nations.NationName))' else 'LTRIM(RTRIM(Nations.NationAName))' end + ' 
			WHERE isnull(temptable.NationalIDNumber,'''') <> ''''  
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			and temptable.NationalIDNumber in (SELECT t.NationalIDNumber
											   FROM '+@tablename+' t  
											   left join Nations n on '+ case when @lang ='e' then 'ltrim(rtrim(t.Nationality))' else 'ltrim(rtrim(t.ANationality))' end + ' = ' +case when @lang ='e' then 'LTRIM(RTRIM(n.NationName))' else 'LTRIM(RTRIM(n.NationAName))' end + '
			                                   where t.row_number<>temptable.row_number 
			                                   and  ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(n.NationId))+'',%''  '   --if duplicated with egyptians 
											   	 +'or '''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId)) +'',%'''  -- others with same national no are egyptians
												+' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'')
			                                    GROUP BY NationalIDNumber 
			                                    having COUNT(NationalIDNumber)>0)'		
			PRINT 'duplicate employees'
			PRINT @str1
			EXECUTE(@str1)
		END 	
		
	ELSE IF @NatnNoUnique=2
        BEGIN
        	 
    	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','NationalIDExistsIncompany',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى موجود مسبقاً في نفس الشركةً' ELSE N'Same National ID Already Exists in this Company'  end))                          
--			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
--			FROM '+@tablename+' temptable	
--			left join empassignment ea on temptable.EmpID = ea.EmployeeId
--			left join Profile p on ea.EmpID = p.profileid
--			left JOIN EmpAssignment ON temptable.EmpID <> EmpAssignment.EmployeeId
--			left JOIN Profile ON empassignment.empid= profile.profileid
--			WHERE isnull(temptable.NationalIDNumber,p.NatnlNo)=cast(Profile.NatnlNo AS nvarchar(20))  
--			AND dbo.GetOrganizationParent(empassignment.Organization,1,1,0,''e'') = dbo.GetOrganizationParent(
--			( select  isnull(organization10.Organization,isnull(organization9.Organization, isnull(organization8.Organization, ISNULL(organization7.Organization,ISNULL(organization6.Organization,ISNULL(organization5.Organization
--			,ISNULL(organization4.Organization,ISNULL(organization3.Organization,ISNULL(organization2.Organization,ISNULL(organization1.Organization,ea.organization))))))))))
							
--			from '+@tablename+' temptable 
--				            left JOIN Organization as organization1 ON ltrim(rtrim(temptable.Org1)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization1.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization1.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization1.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization1.OrganizationName))'  END END )+'

--							   left JOIN Organization as organization2 ON ltrim(rtrim(temptable.Org2)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization2.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization2.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization2.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization2.OrganizationName))'  END END )+'

							
--							 left JOIN Organization as organization3 ON ltrim(rtrim(temptable.Org3)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization3.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization3.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization3.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization3.OrganizationName))'  END END )+'
							
							
--							   left JOIN Organization as organization4 ON ltrim(rtrim(temptable.Org4)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization4.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization4.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization4.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization4.OrganizationName))'  END END )+'
							
							
--							   left JOIN Organization as organization5 ON ltrim(rtrim(temptable.Org5)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization5.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization5.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization5.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization5.OrganizationName))'  END END )+'
							
						
--							   left JOIN Organization as organization6 ON ltrim(rtrim(temptable.Org6)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization6.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization6.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization6.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization6.OrganizationName))'  END END )+'
							
						
--							   left JOIN Organization as organization7 ON ltrim(rtrim(temptable.Org7)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization7.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization7.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization7.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization7.OrganizationName))'  END END )+'
							
						
--							   left JOIN Organization as organization8 ON ltrim(rtrim(temptable.Org8)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization8.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization8.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization8.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization8.OrganizationName))'  END END )+'
							
						
--							   left JOIN Organization as organization9 ON ltrim(rtrim(temptable.Org9)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization9.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization9.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization9.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization9.OrganizationName))'  END END )+'
							
						
--							   left JOIN Organization as organization10 ON ltrim(rtrim(temptable.Org10)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
--'ltrim(rtrim(organization10.OrganizationANameCons)) collate database_default' 
--ELSE 'ltrim(rtrim(organization10.OrganizationAName)) collate database_default' END 
--						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization10.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization10.OrganizationName))'  END END )+'
							
--							),1,1,0,''e'') 
--			and temptable.empid collate database_default <> empassignment.EmployeeId collate database_default
--			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
			
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable	
			left join empassignment ea on temptable.EmpID = ea.EmployeeId
			left join Profile p on ea.EmpID = p.profileid
			left JOIN EmpAssignment ON temptable.EmpID <> EmpAssignment.EmployeeId
			left JOIN Profile ON empassignment.empid= profile.profileid
			WHERE isnull(temptable.NationalIDNumber,p.NatnlNo)=cast(Profile.NatnlNo AS nvarchar(20))  
			AND dbo.GetOrganizationParent(empassignment.Organization,1,1,0,''e'') in(select dbo.GetOrganizationParent(
		 isnull(organization10.Organization,isnull(organization9.Organization, isnull(organization8.Organization, ISNULL(organization7.Organization,ISNULL(organization6.Organization,ISNULL(organization5.Organization
			,ISNULL(organization4.Organization,ISNULL(organization3.Organization,ISNULL(organization2.Organization,ISNULL(organization1.Organization,ea.organization)))))))))),1,1,0,''e'')
							
			from '+@tablename+' temptable 
			left JOIN Organization as organization1 ON ltrim(rtrim(temptable.Org1)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization1.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization1.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization1.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization1.OrganizationName))'  END END )+'

							   left JOIN Organization as organization2 ON ltrim(rtrim(temptable.Org2)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization2.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization2.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization2.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization2.OrganizationName))'  END END )+'

							
							 left JOIN Organization as organization3 ON ltrim(rtrim(temptable.Org3)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization3.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization3.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization3.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization3.OrganizationName))'  END END )+'
							
							
							   left JOIN Organization as organization4 ON ltrim(rtrim(temptable.Org4)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization4.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization4.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization4.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization4.OrganizationName))'  END END )+'
							
							
							   left JOIN Organization as organization5 ON ltrim(rtrim(temptable.Org5)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization5.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization5.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization5.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization5.OrganizationName))'  END END )+'
							
						
							   left JOIN Organization as organization6 ON ltrim(rtrim(temptable.Org6)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization6.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization6.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization6.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization6.OrganizationName))'  END END )+'
							
						
							   left JOIN Organization as organization7 ON ltrim(rtrim(temptable.Org7)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization7.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization7.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization7.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization7.OrganizationName))'  END END )+'
							
						
							   left JOIN Organization as organization8 ON ltrim(rtrim(temptable.Org8)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization8.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization8.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization8.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization8.OrganizationName))'  END END )+'
							
						
							   left JOIN Organization as organization9 ON ltrim(rtrim(temptable.Org9)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization9.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization9.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization9.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization9.OrganizationName))'  END END )+'
							
						
							   left JOIN Organization as organization10 ON ltrim(rtrim(temptable.Org10)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 
'ltrim(rtrim(organization10.OrganizationANameCons)) collate database_default' 
ELSE 'ltrim(rtrim(organization10.OrganizationAName)) collate database_default' END 
						       ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(organization10.OrganizationNameCons))' ELSE 'ltrim(rtrim(organization10.OrganizationName))'  END END )+'
							
							) 
			and temptable.empid collate database_default <> empassignment.EmployeeId collate database_default
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '		
			
			PRINT @str1		
			EXECUTE(@str1)
		 
		
		
		
		
		
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','DuplicateCompNationalID',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى مكرر في نفس الشركة' ELSE N'National ID Duplicate in same company'  end))                          
			--select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			--FROM '+@tablename+' temptable
			--WHERE isnull(temptable.NationalIDNumber,'''') <> ''''  
			--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			--and temptable.NationalIDNumber in (SELECT t.NationalIDNumber
		 --                                      FROM '+@tablename+' t  
			--								   GROUP BY NationalIDNumber 
			--								   having COUNT(NationalIDNumber)>1)
		 --   and  ISNULL(temptable.Org1, ISNULL(temptable.Org2, ISNULL(temptable.Org3, ISNULL(temptable.Org4,ISNULL(temptable.Org5,ISNULL(temptable.Org6
			--	,ISNULL(temptable.Org7,ISNULL(temptable.Org8,ISNULL(temptable.Org9
			--	,ISNULL(temptable.Org10,'''')))))))))) in (select distinct  ISNULL(t.Org1,ISNULL(t.Org2,ISNULL(t.Org3,ISNULL(t.Org4,ISNULL(t.Org5,ISNULL(t.Org6
			--												,ISNULL(t.Org7,ISNULL(t.Org8,ISNULL(t.Org9,ISNULL(t.Org10,''''))))))))))
			--												 FROM '+@tablename+' t 
			--												)
		    --'		

			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			WHERE isnull(temptable.NationalIDNumber,'''') <> ''''  
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			and temptable.NationalIDNumber in (SELECT distinct t.NationalIDNumber
		                                       FROM '+@tablename+' t  
											   GROUP BY t.NationalIDNumber, ' + case when @lang='e' then + 'ISNULL(t.Org1, ISNULL(t.Org2, ISNULL(t.Org3, ISNULL(t.Org4,ISNULL(t.Org5,ISNULL(t.Org6
												,ISNULL(t.Org7,ISNULL(t.Org8,ISNULL(t.Org9,ISNULL(t.Org10,'''')))))))))) ' else 
												'ISNULL(t.AOrg1, ISNULL(t.AOrg2, ISNULL(t.AOrg3, ISNULL(t.AOrg4,ISNULL(t.AOrg5,ISNULL(t.AOrg6
												,ISNULL(t.AOrg7,ISNULL(t.AOrg8,ISNULL(t.AOrg9,ISNULL(t.AOrg10,'''')))))))))) ' end +'
											     having COUNT(NationalIDNumber)>1)'
		 

			PRINT 'duplicate employees in same company'
			
			PRINT @str1
			EXECUTE(@str1)	
		
       END
		--------National id with length 14
		IF @NatnNolength = 1  -- National id with length 14
		BEGIN

			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','LenNationalID',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى يجب ان يكون 14 رقم' ELSE N'National ID Length should be 14 digits'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			left join Nations on ltrim(rtrim(case when '''+@lang+'''=''e'' then temptable.Nationality else temptable.ANationality end ))= ' + case when @lang='e' then case when @Consolidation =0 then 'LTRIM(RTRIM(Nations.NationName))' else 'LTRIM(RTRIM(Nations.NationNameCons))' end else case when @Consolidation =0 then 'LTRIM(RTRIM(Nations.NationAName))' else 'LTRIM(RTRIM(Nations.NationANameCons))' end  end  +'
			WHERE len(rtrim(ltrim(temptable.NationalIDNumber))) <> 14 
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			 AND ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId))+'',%'' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'')  '		
			--PRINT 'duplicate employees'
			print 123
			PRINT @str1
			EXECUTE(@str1)
		END 	
		 
		--------National id with char
              IF @NatnNoChar = 1  -- National id with char
              BEGIN

                     SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','LenNationalID1',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى يجب ان لا يحتوى على حروف' ELSE N'National ID should not contains characters'  end))
                                               
                     select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
                     FROM '+@tablename+' temptable
					 WHERE ISNUMERIC(case when rtrim(ltrim(isnull(temptable.NationalIDNumber,'''')))='''' then ''0'' else rtrim(ltrim(temptable.NationalIDNumber)) end ) <> 1 
                     and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
                      '            
                     
                     PRINT @str1
                     EXECUTE(@str1)
              END 


		IF @NatnlNoUniqueActiveInsertOnly = 1  -- For National ID already exist
		BEGIN
			
			--@ValidateNatnlNo is a sysparamconfig to apply this validation on certain nationalities only 
			
			---@ValidateNatnlNo for egyptians only
            SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','ErrorNationalNo',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى موجود مسبقاً' ELSE N'National ID Already Exists'  end))                          
			SELECT @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			inner JOIN Profile ON temptable.NationalIDNumber=cast(Profile.NatnlNo AS nvarchar(20))  
			INNER JOIN EmpAssignment ON EmpAssignment.EmpId = Profile.ProfileId and temptable.EmpID <> EmpAssignment.EmployeeId
			left join Nations on '+case when @lang='e' then 'ltrim(rtrim(temptable.Nationality))' else 'ltrim(rtrim(temptable.ANationality))' end +' = '+case when @lang='e' then 'LTRIM(RTRIM(Nations.NationName))' else 'LTRIM(RTRIM(Nations.NationAName))' end +'
			LEFT JOIN HrStatus ON HrStatus.hrstatus = empassignment.HrStatus
			WHERE isnull(Profile.NatnlNo,'''') <>''''  AND HrStatus.paystatus = 1 
			and temptable.empid collate database_default <> empassignment.EmployeeId collate database_default
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			 AND ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId))+'',%'''   --i am the egyptian
			 +'or '''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Profile.NationId)) +'',%'''  -- others with same national no are egyptians
			 +' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'') '
			PRINT @str1
			EXECUTE(@str1)


			---@ValidateNatnlNo for egyptians only
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','DuplicateNationalID',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى مكرر' ELSE N'National ID Duplicate'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			left join Nations on ltrim(rtrim(temptable.Nationality))=case when '''+@lang+'''=''e'' then LTRIM(RTRIM(Nations.NationName)) else LTRIM(RTRIM(Nations.NationAName)) end 
			WHERE isnull(temptable.NationalIDNumber,'''') <> ''''  
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			and temptable.NationalIDNumber in (SELECT t.NationalIDNumber
											   FROM '+@tablename+' t  
											   left join Nations n on ltrim(rtrim(t.Nationality))=case when '''+@lang+'''=''e'' then LTRIM(RTRIM(n.NationName)) else LTRIM(RTRIM(n.NationAName)) end 
			                                   where t.row_number<>temptable.row_number 
			                                   and  ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(n.NationId))+'',%''  '   --if duplicated with egyptians 
											   	 +'or '''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId)) +'',%'''  -- others with same national no are egyptians
												+' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'')
			                                    GROUP BY NationalIDNumber 
			                                    having COUNT(NationalIDNumber)>0)'	
			PRINT 'duplicate employees'
			PRINT @str1
			EXECUTE(@str1)
			
			
		END 	

		IF @validategradewithjob = 1  -- For grade validate with job
		BEGIN
            SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','Validategradewithjob',@lang,@LogonName),(case when @lang='A' then N'لا ترتبط هذه الدرجة مع الوظيفة' ELSE N'This Grade is not linked with Job'  end))                          

				SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON temptable.Grade collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Grades.GradeANameCons collate database_default' ELSE 'Grades.GradeAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Grades.GradeNameCons' ELSE 'Grades.GradeName'  END END )+' 
						left JOIN Jobs ON temptable.JOB collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Jobs.JobANameCons collate database_default' ELSE 'Jobs.JobAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Jobs.JobNameCons' ELSE 'Jobs.JobName' END  END)+'
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.Grade,'''') <> '''' and rtrim(ltrim(temptable.Grade)) <> ''-'' 
						and isnull(temptable.Job,'''') <> '''' and rtrim(ltrim(temptable.Job)) <> ''-''	 
						AND Grades.grade NOT IN (SELECT JobGrades.grade FROM dbo.JobGrades WHERE JobGrades.job =Jobs.job)'	
			PRINT @str1
			EXECUTE(@str1)
		END 	
		
		IF @PositionRequired =1
		BEGIN
				SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','PositionValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN 'يجب ادخال المركز ' ELSE 'Position is required . ' END )
				SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
				FROM '+@tablename+' temptable
				left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
				where (isnull('+case when @lang = 'A' then ' temptable.APosition ' else ' temptable.Position ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.APosition ' else ' temptable.Position ' end +')) = ''-'') 
				and (empassignment.EmployeeId is null --or (empassignment.EmployeeId is not null and empassignment.positionno is null))
				) 
				and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
				'	
	PRINT @str1
	EXECUTE(@str1)	
		END
		IF @BirthdateRequired=1
		BEGIN
				SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','BirthdateValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال تاريخ الميلاد ' ELSE 'Birthdate is required . ' END )
				SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
				FROM '+@tablename+' temptable
				left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
				left join Profile on profile.profileid = EmpAssignment.EmpId
				where temptable.Birthdate is NULL and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and profile.Birthdate is NULL))
				and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
				'	
				PRINT @str1
				EXECUTE(@str1)	
		END
	IF @SSNumRequired = 1 -- For Mandatory SSNum field
		BEGIN 		
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','SSNumCustomValidation',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال الرقم التأميني ' ELSE N'Social Insurance No. is required. '  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			LEFT JOIN EmpAssignment on EmpAssignment.employeeId = temptable.empid 
			where isnull(temptable.SsNum,'''')='''' and EmpAssignment.employeeId  is null
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			--PRINT @str1 and isnull(position,'''')=''''  
			EXECUTE(@str1)	
		END 


	IF @SSNumExistAndUnique  = 1  -- For SSNum already exist
		BEGIN
            SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','SSNumberCustomValidation',@lang,@LogonName),(case when @lang='A' then N'الرقم التأميني موجود بالفعل' ELSE N'Social Insurance No. already exists. '  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			INNER JOIN EmpAssignment ON temptable.SsNum = cast(EmpAssignment.SsNum AS nvarchar(15))  and temptable.EmpID <> EmpAssignment.EmployeeId 
			LEFT JOIN HrStatus ON HrStatus.hrstatus = empassignment.HrStatus
			WHERE isnull(empassignment.SsNum,'''') <>''''  AND HrStatus.paystatus = 1 
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
			PRINT @str1
			EXECUTE(@str1)

			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','SSNumberCustomValidation',@lang,@LogonName),(case when @lang='A' then N'الرقم التأميني موجود بالفعل' ELSE N'Social Insurance No. already exists. '  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			WHERE isnull(temptable.SsNum,'''') <> ''''  
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			and temptable.SsNum in (SELECT t.SsNum
		    FROM '+@tablename+' t  GROUP BY t.SsNum having COUNT(t.SsNum)>1) '		
			PRINT 'duplicate employees'
			PRINT @str1
			EXECUTE(@str1)
		END 	


		IF @FileNoRequired = 1 -- For Mandatory File No field
		BEGIN 		
			SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','EmptyFileNo',@lang,@LogonName), (CASE WHEN @lang = 'A' THEN N'يجب ادخال رقم الملف' ELSE 'File No is Empty' END ))
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			where isnull(FileNumber,'''')=''''
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			EXECUTE(@str1)	
		END 

		IF @FileNoExistAndUnique = 1  -- For FileNo already exist
		BEGIN
            SELECT @errormsg1= 	 ISNULL(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','FileNoAlreadyExists',@lang,@LogonName),( CASE WHEN @lang = 'A' THEN N'رقم الملف موجود مسبقاً' ELSE 'File No Already Exists' END ))
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			INNER JOIN EmpAssignment ON temptable.FileNumber= cast(EmpAssignment.FileNumber AS nvarchar(30)) 
			LEFT JOIN HrStatus ON HrStatus.hrstatus = empassignment.HrStatus
			WHERE  temptable.empid <>EmpAssignment.employeeid  and isnull(EmpAssignment.FileNumber,'''') <>''''  AND HrStatus.paystatus = 1 
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
			PRINT @str1
			EXECUTE(@str1)

			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','DuplicateFileNo',@lang,@LogonName),(case when @lang='A' then N'رقم الملف مكرر' ELSE N'File No Duplicate'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			WHERE isnull(temptable.FileNumber,'''') <> ''''  
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			and temptable.FileNumber in (SELECT t.FileNumber
		    FROM '+@tablename+' t  GROUP BY FileNumber having COUNT(FileNumber)>1) '		
			PRINT 'duplicate employees'
			PRINT @str1
			EXECUTE(@str1)
		END 	
			-- Birthdate NatnlNo Conflict
	IF @BirthdateNatnlNoConflict = 1
		BEGIN 
	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','BirthdateNatnlNoConflict',@lang,@LogonName), (CASE WHEN @lang = 'A' THEN N'الرقم القومي ، تاريخ الميلاد غير متطابقين.' ELSE 'National No and Birthdate are not matching.' END ))
	select @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
	FROM '+@tablename+' temptable
	where (  SUBSTRING((temptable.NationalIDNumber),2,6) <> CONVERT(VARCHAR(6),CAST(temptable.BirthDate AS DATETIME), 12) OR temptable.BirthDate IS NULL )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '		
	
	PRINT @str1
	EXECUTE(@str1)
		END
		
				
	-- Grade required
	IF @GradeRequired =1
	BEGIN 
		SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','GradeValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال الدرجة ' ELSE 'Grade is required . ' END )            
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		FROM '+@tablename+' temptable
		left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
		where (( isnull('+case when @lang = 'A' then ' temptable.AGrade ' else ' temptable.Grade ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.AGrade ' else ' temptable.Grade ' end +')) = ''-'') 
		and (empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and empassignment.grade is null) 
		))
		and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
		PRINT @str1
		EXECUTE(@str1)	
	END 
	
	--Company Email Required
	IF @CompanyEmailRequired=1
	BEGIN
	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','CompanyEmailValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال أيميل الشركة ' ELSE 'Comp. E-mail is required . ' END )   
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	left join Profile on profile.profileid = EmpAssignment.EmpId
	where (( isnull(temptable.CompanyEmail,'''')='''' or rtrim(ltrim(temptable.CompanyEmail)) = ''-'' ) 
	and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and profile.companyemail ='''')
	))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	'	
	PRINT @str1
	EXECUTE(@str1)	
	END
	
	--Salary Scale required
	IF @SalaryScaleRequired =1
	BEGIN
	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','SalaryScaleValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال مقياس الراتب ' ELSE 'Salary Scale is required . ' END ) 
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	where ((  isnull('+case when @lang = 'A' then ' temptable.ASalaryScale ' else ' temptable.SalaryScale  ' end +','''')= '''' or rtrim(ltrim('+case when @lang = 'A' then ' temptable.ASalaryScale ' else ' temptable.SalaryScale ' end +')) = ''-'' ) 
	and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and empassignment.salaryscaleid is null)
	) )
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	'	
	PRINT @str1
	EXECUTE(@str1)	
	END
	
	-- Hire Date work receiving date Validation
	IF @HiringDate_WorkReceivingDateRequired =1
	BEGIN
	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','HiringDate_WorkReceivingDateValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'تاريخ التعيين لا يساوي تاريخ إستلام العمل.' ELSE 'Hiring Date is not equal to Work Receiving Date.' END )
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	where  cast(ISNULL(isnull(temptable.HireDate,EmpAssignment.HireDate),''1900/01/01'')as smalldatetime) <> cast(ISNULL(isnull(temptable.WorkReceivingDate,EmpAssignment.WorkReceivingDate)  ,''1900/01/01'') as smalldatetime)
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	'
	PRINT @str1
	EXECUTE(@str1)		
	END	
	
	IF @AddressRequired =1
	BEGIN
	SELECT @errormsg1= ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','AddressCustomValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN 'يجب ادخال العنوان ' ELSE 'Address is required . ' END ) 
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	left join Profile on profile.profileid = EmpAssignment.EmpId
	where (( isnull(temptable.Address,'''')='''' or rtrim(ltrim(temptable.Address)) = ''-'' ) and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and profile.Address ='''')))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	'	
	PRINT @str1
	EXECUTE(@str1)	
	END
	
	IF @MobileLength=1
	BEGIN
	SELECT @errormsg1=  ISNULL( dbo.Hits_GetDCCaptionWzLogon('V_Employees','MobileCustomValidation',@lang,@LogonName), CASE WHEN @lang = 'A' THEN 'رقم الموبيل يجب ان يكون 11 رقم' ELSE 'Mobile must be 11 characters . ' END )  
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	left join Profile on profile.profileid = EmpAssignment.EmpId
	where (( LEN(isnull(temptable.MobileNumber,'''')) <> 11 ) and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and profile.mobile ='''')))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
		'	
	PRINT @str1
	EXECUTE(@str1)	
	END
	
	IF @PassportorNatnlnoRequired =1
	BEGIN
	SELECT @errormsg1=ISNULL(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','EmptyNationalNo',@lang,@LogonName), CASE WHEN @lang = 'A' THEN N'يجب ادخال الرقم القومى' ELSE 'National ID is Empty' END )  
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	left join Profile on profile.profileid = EmpAssignment.EmpId
    left JOIN Nations ON '+ case when @lang='E' then  'temptable.Nationality collate database_default ' else 'temptable.ANationality collate database_default' END+' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Nations.NationANameCons collate database_default' ELSE  'Nations.NationAName collate database_default' END 
	ELSE CASE when @Consolidation = 1 THEN 'Nations.NationNameCons' ELSE  'Nations.NationName' END END)+'	where (( (isnull(temptable.NationalIDNumber,'''')='''' or rtrim(ltrim(temptable.NationalIDNumber)) = ''-'') and isnull(nations.nationid,profile.nationid) = 1) and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and profile.NatnlNo ='''')))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	'	
	PRINT @str1
	EXECUTE(@str1)	
	
	SELECT @errormsg1=ISNULL( dbo.Hits_GetDCCaption('TR_InsertEmployee','EmptyPassportNo',@lang), CASE WHEN @lang = 'A' THEN N'يجب ادخال رقم جواز السفر' ELSE 'Passport No. is Empty' END ) 
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable
	left JOIN EmpAssignment ON temptable.empid  collate database_default= empassignment.EmployeeId collate database_default
	left join Profile on profile.profileid = EmpAssignment.EmpId
    left JOIN Nations ON temptable.Nationality collate database_default=  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Nations.NationANameCons collate database_default' ELSE  'Nations.NationAName collate database_default' END 
	ELSE CASE when @Consolidation = 1 THEN 'Nations.NationNameCons' ELSE  'Nations.NationName' END END)+
	' where (( (isnull(temptable.passportNo,'''')='''' or rtrim(ltrim(temptable.passportNo)) = ''-'') and isnull(nations.nationid,profile.nationid) <> 1) and ( empassignment.EmployeeId is null or (empassignment.EmployeeId is not null and profile.ForPassNo ='''')))
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	'	
	PRINT @str1
	EXECUTE(@str1)	
	END
	
		
		

		IF @validatehirebirthtemp = 1 -- For termdate>hiredate>bithdate
		BEGIN 		
			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','HireBeforeBirth',@lang,@LogonName),(case when @lang='A' then N'تاريخ التعيين قبل تاريخ الميلاد او يساوى' ELSE N'Hire date before Birth date or equal'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			where (temptable.BirthDate IS not NULL and temptable.BirthDate >= temptable.HireDate)
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			--PRINT @str1 and isnull(position,'''')=''''  
			EXECUTE(@str1)	

			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','HireBirthNotMatching',@lang,@LogonName),(case when @lang='A' then N' تاريخ التعيين غير متوافق مع تاريخ الميلاد ' ELSE N'Hire date does not match with date of birth'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			where (temptable.BirthDate IS not NULL and temptable.HireDate IS NOT null   AND DATEDIFF(YEAR,temptable.BirthDate,temptable.HireDate)<18 )
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			--PRINT @str1 and isnull(position,'''')=''''  
			EXECUTE(@str1)	

			SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('TR_InsertEmployee','TermBeforeHire',@lang,@LogonName),(case when @lang='A' then N'تاريخ التوقف قبل تاريخ التعيين' ELSE N'Termination date before Hire date'  end))                          
			select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			where (temptable.TerminationDate IS not NULL and temptable.HireDate > temptable.TerminationDate)
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
			--PRINT @str1 and isnull(position,'''')=''''  
			EXECUTE(@str1)	
		END 

		--IF( @GenderRequired = 1 )
		--BEGIN
		--	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('V_Employees','GenderValidation',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال النوع' ELSE N'Gender is required .'  end))                          
		--	select @str1=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg1+'''))+'' / ''+rtrim(ltrim(remarks))  , post=0  
		--	FROM '+@tablename+' temptable
		--	where temptable.Gender is null
		--	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
		--	--PRINT @str1 and isnull(position,'''')=''''  
		--	EXECUTE(@str1)	
		--END

	IF @CreateSetp = 0
	BEGIN 
			--Nationality
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', case when @lang='A' then 'ANationality' else 'Nationality' end ,@lang,@LogonName),(case when @lang='A' then N'الجنسية' ELSE N'Nationality'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Nations ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ANationality)) collate database_default' else 'ltrim(rtrim(temptable.Nationality)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Nations.NationANameCons)) collate database_default' ELSE  'ltrim(rtrim(Nations.NationAName)) collate database_default' END

					ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Nations.NationNameCons))' ELSE  'ltrim(rtrim(Nations.NationName))' END END)+'
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ANationality)) collate database_default' else 'ltrim(rtrim(temptable.Nationality)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ANationality)) collate database_default' else 'ltrim(rtrim(temptable.Nationality)) collate database_default' end +')) <> ''-''  AND Nations.NationName IS null '	
		EXECUTE(@str1)
		PRINT(@str1)

		--CostCenter
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'ACostCenter' else 'CostCenter' end ,@lang,@LogonName),(case when @lang='A' then N'مركز التكلفة' ELSE N'Cost Center'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN CostCntr ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ACostCenter)) collate database_default' else 'ltrim(rtrim(temptable.CostCenter)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(CostCntr.CenterANameCons)) collate database_default' ELSE 'ltrim(rtrim(CostCntr.CenterAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(CostCntr.CenterNameCons))' ELSE  'ltrim(rtrim(CostCntr.CenterName))' END END)+'
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ACostCenter)) collate database_default' else 'ltrim(rtrim(temptable.CostCenter)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ACostCenter)) collate database_default' else 'ltrim(rtrim(temptable.CostCenter)) collate database_default' end +')) <> ''-''	AND CostCntr.center IS null '	
		EXECUTE(@str1)
		PRINT(@str1)
		--Job
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AJob' else 'Job' end ,@lang,@LogonName),(case when @lang='A' then N'الوظيفة' ELSE N'Job'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))


		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Jobs ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AJOB)) collate database_default' else 'ltrim(rtrim(temptable.JOB)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Jobs.JobANameCons)) collate database_default' ELSE 'ltrim(rtrim(Jobs.JobAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Jobs.JobNameCons))' ELSE 'ltrim(rtrim(Jobs.JobName))' END  END)+'
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AJOB)) collate database_default' else 'ltrim(rtrim(temptable.JOB)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AJOB)) collate database_default' else 'ltrim(rtrim(temptable.JOB)) collate database_default' end +')) <> ''-''	AND Jobs.Job IS null '	
		EXECUTE(@str1)
		
		--Position
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'APosition' else 'Position' end ,@lang,@LogonName),(case when @lang='A' then N'المركز' ELSE N'Position'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Positions ON '+case when @lang='A' then 'ltrim(rtrim(temptable.APOSITION)) collate database_default' else 'ltrim(rtrim(temptable.POSITION)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Positions.PositionNoANameCons)) collate database_default' ELSE 'ltrim(rtrim(Positions.PositionAName)) collate database_default' END
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Positions.PositionNoNameCons))' ELSE 'ltrim(rtrim(Positions.PositionName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.APOSITION)) collate database_default' else 'ltrim(rtrim(temptable.POSITION)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.APOSITION)) collate database_default' else 'ltrim(rtrim(temptable.POSITION)) collate database_default' end +')) <> ''-''	AND Positions.PositionNo IS null '	
		EXECUTE(@str1)
		
		--Grade
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AGrade' else 'Grade' end ,@lang,@LogonName),(case when @lang='A' then N'الدرجة' ELSE N'Grade'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AGrade)) collate database_default' else 'ltrim(rtrim(temptable.Grade)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Grades.GradeANameCons)) collate database_default' ELSE 'ltrim(rtrim(Grades.GradeAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Grades.GradeNameCons))' ELSE 'ltrim(rtrim(Grades.GradeName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AGrade)) collate database_default' else 'ltrim(rtrim(temptable.Grade)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AGrade)) collate database_default' else 'ltrim(rtrim(temptable.Grade)) collate database_default' end +')) <> ''-'' AND Grades.Grade IS null '	
		PRINT @str1
		EXECUTE(@str1)


		--Currency
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'ACurrency' else 'Currency' end ,@lang,@LogonName),(case when @lang='A' then N'العملة' ELSE N'Currency'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=CONVERT(NVARCHAR(256),rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+''')))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Currency ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Currency.CurANameCons)) collate database_default' ELSE 'ltrim(rtrim(Currency.CurAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Currency.CurNameCons))' ELSE 'ltrim(rtrim(Currency.CurName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +')) collate database_default' else 'ltrim(rtrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +')) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +')) <> ''-'' AND Currency.cur IS null '	
		PRINT @str1
		EXECUTE(@str1)

		--PayrollGroup
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'APayrollGroup' else 'PayrollGroup' end ,@lang,@LogonName),(case when @lang='A' then N'مجموعة المرتبات' ELSE N'Payroll Group'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN PayrollGroup ON '+case when @lang='A' then 'ltrim(rtrim(temptable.APayrollGroup)) collate database_default' else 'ltrim(rtrim(temptable.PayrollGroup)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(PayrollGroup.PayrollGroupANameCons)) collate database_default' ELSE 'ltrim(rtrim(PayrollGroup.PayrollGroupAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(PayrollGroup.PayrollGroupNameCons))' ELSE  'ltrim(rtrim(PayrollGroup.PayrollGroupName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.APayrollGroup)) collate database_default' else 'ltrim(rtrim(temptable.PayrollGroup)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.APayrollGroup)) collate database_default' else 'ltrim(rtrim(temptable.PayrollGroup)) collate database_default' end +')) <> ''-''	AND PayrollGroup.PayrollGroup IS null '	
		EXECUTE(@str1)
		print (@str1)
		
		-- Org1
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg1' else 'Org1' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 1' ELSE N'Organization 1'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg1)) collate database_default' else 'ltrim(rtrim(temptable.Org1)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg1)) collate database_default' else 'ltrim(rtrim(temptable.Org1)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg1)) collate database_default' else 'ltrim(rtrim(temptable.Org1)) collate database_default' end +')) <> ''-''	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		-- Org2
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg2' else 'Org2' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 2' ELSE N'Organization 2'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg2)) collate database_default' else 'ltrim(rtrim(temptable.Org2)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull( '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg2)) collate database_default' else 'ltrim(rtrim(temptable.Org2)) collate database_default' end +','''') <> '''' And ltrim(rtrim( '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg2)) collate database_default' else 'ltrim(rtrim(temptable.Org2)) collate database_default' end +')) <> ''-''	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		-- Org3
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg3' else 'Org3' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 3' ELSE N'Organization 3'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg3)) collate database_default' else 'ltrim(rtrim(temptable.Org3)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg3)) collate database_default' else 'ltrim(rtrim(temptable.Org3)) collate database_default' end +' ,'''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg3)) collate database_default' else 'ltrim(rtrim(temptable.Org3)) collate database_default' end +' )) <> ''-'' AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		-- Org4
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then'AOrg4' else 'Org4' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 4' ELSE N'Organization 4'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg4)) collate database_default' else 'ltrim(rtrim(temptable.Org4)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg4)) collate database_default' else 'ltrim(rtrim(temptable.Org4)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg4)) collate database_default' else 'ltrim(rtrim(temptable.Org4)) collate database_default' end +')) <> ''-'' AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		-- Org5
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg5' else 'Org5' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 5' ELSE N'Organization 5'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg5)) collate database_default' else 'ltrim(rtrim(temptable.Org5)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg5)) collate database_default' else 'ltrim(rtrim(temptable.Org5)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg5)) collate database_default' else 'ltrim(rtrim(temptable.Org5)) collate database_default' end +')) <> ''-'' AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		-- Org6
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg6' else 'Org6' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 6' ELSE N'Organization 6'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg6)) collate database_default' else 'ltrim(rtrim(temptable.Org6)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg6)) collate database_default' else 'ltrim(rtrim(temptable.Org6)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg6)) collate database_default' else 'ltrim(rtrim(temptable.Org6)) collate database_default' end +')) <> ''-'' 	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		-- Org7
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg7' else 'Org7' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 7' ELSE N'Organization 7'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg7)) collate database_default' else 'ltrim(rtrim(temptable.Org7)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg7)) collate database_default' else 'ltrim(rtrim(temptable.Org7)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg7)) collate database_default' else 'ltrim(rtrim(temptable.Org7)) collate database_default' end +')) <> ''-''	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		
		-- Org8
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg8' else 'Org8' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 8' ELSE N'Organization 8'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg8)) collate database_default' else 'ltrim(rtrim(temptable.Org8)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg8)) collate database_default' else 'ltrim(rtrim(temptable.Org8)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg8)) collate database_default' else 'ltrim(rtrim(temptable.Org8)) collate database_default' end +')) <> ''-''	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		
		-- Org9
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg9' else 'Org9' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 9' ELSE N'Organization 9'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg9)) collate database_default' else 'ltrim(rtrim(temptable.Org9)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg9)) collate database_default' else 'ltrim(rtrim(temptable.Org9)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg9)) collate database_default' else 'ltrim(rtrim(temptable.Org9)) collate database_default' end +')) <> ''-''	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		
		-- Org10
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AOrg10' else 'Org10' end ,@lang,@LogonName),(case when @lang='A' then N'الادارة 10' ELSE N'Organization 10'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg10)) collate database_default' else 'ltrim(rtrim(temptable.Org10)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg10)) collate database_default' else 'ltrim(rtrim(temptable.Org10)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg10)) collate database_default' else 'ltrim(rtrim(temptable.Org10)) collate database_default' end +')) <> ''-''	AND Organization.Organization IS null '	
		EXECUTE(@str1)
		print (@str1)
		
		-- HRStatus
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AHRStatus' else 'HRStatus' end ,@lang,@LogonName),(case when @lang='A' then N'حالة التعيين' ELSE N'HR Status'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN HRStatus ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AHRStatus)) collate database_default' else 'ltrim(rtrim(temptable.HRStatus)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(HrStatus.HrStatusANameCons)) collate database_default' ELSE 'ltrim(rtrim(HrStatus.HrStatusAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(HrStatus.HrStatusNameCons))' ELSE 'ltrim(rtrim(HrStatus.HrStatusName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AHRStatus)) collate database_default' else 'ltrim(rtrim(temptable.HRStatus)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AHRStatus)) collate database_default' else 'ltrim(rtrim(temptable.HRStatus)) collate database_default' end +')) <> ''-'' AND HrStatus.HrStatus IS null '	
		EXECUTE(@str1)
		PRINT @str1
		

		
		-- ContractType
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AContractType' else 'ContractType' end ,@lang,@LogonName),(case when @lang='A' then N'نوع العقد' ELSE N'Contract Type'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ContractType ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AContractType)) collate database_default' else 'ltrim(rtrim(temptable.ContractType)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(ContractType.ContractANameCons)) collate database_default' ELSE 'ltrim(rtrim(ContractType.ContractAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(ContractType.ContractNameCons))' ELSE 'ltrim(rtrim(ContractType.ContractName))' END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AContractType)) collate database_default' else 'ltrim(rtrim(temptable.ContractType)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AContractType)) collate database_default' else 'ltrim(rtrim(temptable.ContractType)) collate database_default' end +')) <> ''-'' AND ContractType.ContractType IS null '	
		EXECUTE(@str1)

		-- Location
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'ALocation' else 'Location' end ,@lang,@LogonName),(case when @lang='A' then N'الموقع' ELSE N'Location'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Location ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ALocation)) collate database_default' else 'ltrim(rtrim(temptable.Location)) collate database_default' end +' =  '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Location.LocationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Location.LocationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Location.LocationNameCons))' ELSE 'ltrim(rtrim(Location.LocationName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ALocation)) collate database_default' else 'ltrim(rtrim(temptable.Location)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ALocation)) collate database_default' else 'ltrim(rtrim(temptable.Location)) collate database_default' end +')) <> ''-''	AND Location.LocationNo IS null '	
		EXECUTE(@str1)
		
		-- Employer
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AEmployer' else 'Employer' end ,@lang,@LogonName),(case when @lang='A' then N' مكتب التأمينات' ELSE N'Employer'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Employer ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AEmployer)) collate database_default' else 'ltrim(rtrim(temptable.Employer)) collate database_default' end +' =  '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Employer.EmployerANameCons)) collate database_default' ELSE 'ltrim(rtrim(Employer.EmployerAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Employer.EmployerNameCons))' ELSE 'ltrim(rtrim(Employer.EmployerName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AEmployer)) collate database_default' else 'ltrim(rtrim(temptable.Employer)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AEmployer)) collate database_default' else 'ltrim(rtrim(temptable.Employer)) collate database_default' end +')) <> ''-''	AND Employer.EmployerId IS null '	
		EXECUTE(@str1)
		
		
		
		-- Salary Scale
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'ASalaryScale' else 'SalaryScale' end ,@lang,@LogonName),(case when @lang='A' then N'مقياس المرتب' ELSE N'Salary Scale'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN SalaryScales ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ASalaryScale)) collate database_default' else 'ltrim(rtrim(temptable.SalaryScale)) collate database_default' end +' =  '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(SalaryScales.SalaryScaleANameCons)) collate database_default' ELSE 'ltrim(rtrim(SalaryScales.SalaryScaleAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(SalaryScales.SalaryScaleNameCons))' ELSE  'ltrim(rtrim(SalaryScales.SalaryScaleName))'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ASalaryScale)) collate database_default' else 'ltrim(rtrim(temptable.SalaryScale)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ASalaryScale)) collate database_default' else 'ltrim(rtrim(temptable.SalaryScale)) collate database_default' end +')) <> ''-''	AND SalaryScales.SalaryScaleid IS null '	
		EXECUTE(@str1)	
		-- Vacpac
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'Avacpack' else  'vacpack' end ,@lang,@LogonName),(case when @lang='A' then N'طريقة حساب الأجازة' ELSE N'Vacation Package'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN vacpack ON '+case when @lang='A' then 'ltrim(rtrim(temptable.Avacpack)) collate database_default' else 'ltrim(rtrim(temptable.vacpack)) collate database_default' end +' =  '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(VacPack.VacPackANameCons)) collate database_default' ELSE 'ltrim(rtrim(VacPack.vacpackAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(VacPack.VacPackNameCons))' ELSE 'ltrim(rtrim(VacPack.vacpackName))'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.Avacpack)) collate database_default' else 'ltrim(rtrim(temptable.vacpack)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.Avacpack)) collate database_default' else 'ltrim(rtrim(temptable.vacpack)) collate database_default' end +')) <> ''-'' AND vacpack.vacpack IS null '	
		EXECUTE(@str1)
		-- TimeRule
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'ATimeRule' else  'TimeRule' end ,@lang,@LogonName),(case when @lang='A' then N'قاعدة حساب الوقت' ELSE N'Time keeping Rule'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable\
						
						left JOIN TimeRules ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ATimeRule)) collate database_default' else 'ltrim(rtrim(temptable.TimeRule)) collate database_default' end +' =  '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(TimeRules.TRuleADescCons)) collate database_default' ELSE 'ltrim(rtrim(TimeRules.TRuleADesc)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(TimeRules.TRuleDescCons)) collate database_default' ELSE 'ltrim(rtrim(TimeRules.TRuleDesc)) collate database_default'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ATimeRule)) collate database_default' else 'ltrim(rtrim(temptable.TimeRule)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ATimeRule)) collate database_default' else 'ltrim(rtrim(temptable.TimeRule)) collate database_default' end +')) <> ''-'' AND TimeRules.TimeRule IS null '	
		EXECUTE(@str1)
		
		
		-- Graduation
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees',case when @lang='A' then 'AGraduation' else  'Graduation' end ,@lang,@LogonName),(case when @lang='A' then N'التخرج' ELSE N'Graduation'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Graduate ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AGraduation)) collate database_default' else 'ltrim(rtrim(temptable.Graduation)) collate database_default' end +' =  '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'rtrim(ltrim(Graduate.GraduateANameCons)) collate database_default' ELSE 'rtrim(ltrim(Graduate.GraduateAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'rtrim(ltrim(Graduate.GraduateNameCons)) collate database_default' ELSE 'rtrim(ltrim(Graduate.GraduateName)) collate database_default'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AGraduation)) collate database_default' else 'ltrim(rtrim(temptable.Graduation)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AGraduation)) collate database_default' else 'ltrim(rtrim(temptable.Graduation)) collate database_default' end +')) <> ''-'' AND Graduate.Graduate IS null '	
		EXECUTE(@str1)


--		---------------------------------------add validation for organizations --------------------------------------------------------------
	--select @EnableOrgSetup , @userOrganization
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	
		--Nationality
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','NationalityOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذاالجنسية'
		ELSE N'Check Org. Validation for this Nationality'  end))                          

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Nations ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ANationality)) collate database_default' else 'ltrim(rtrim(temptable.Nationality)) collate database_default' end +' =  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Nations.NationANameCons)) collate database_default' 
						ELSE  'ltrim(rtrim(Nations.NationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Nations.NationNameCons))' ELSE  'ltrim(rtrim(Nations.NationName))' END END)+'
						where  ( not exists ( select * from #OrgTree where Nations.NationsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Nations.NationsOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ 
						' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ANationality)) collate database_default' else 'ltrim(rtrim(temptable.Nationality)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ANationality)) collate database_default' else 'ltrim(rtrim(temptable.Nationality)) collate database_default' end +')) <> ''-'' '
					
		EXECUTE(@str1)
		PRINT(@str1)
	
		--CostCenter
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','CostCenterOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمركز التكلفة'
		ELSE N'Check Org. Validation for Cost Center'  end))                          
 	 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN CostCntr ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ACostCenter)) collate database_default' else 'ltrim(rtrim(temptable.CostCenter)) collate database_default' end +'= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(CostCntr.CenterANameCons)) collate database_default' ELSE 'ltrim(rtrim(CostCntr.CenterAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(CostCntr.CenterNameCons))' ELSE  'ltrim(rtrim(CostCntr.CenterName))' END END)+'
						where  ( not exists ( select * from #OrgTree where CostCntr.CostCntrOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or CostCntr.CostCntrOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ACostCenter)) collate database_default' else 'ltrim(rtrim(temptable.CostCenter)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ACostCenter)) collate database_default' else 'ltrim(rtrim(temptable.CostCenter)) collate database_default' end +')) <> ''-''	'
		EXECUTE(@str1)
		PRINT(@str1)
		--Job
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','JobOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذةالوظيفة'
		ELSE N'Check Org. Validation for Job'  end))                          
			  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Jobs ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AJOB)) collate database_default' else 'ltrim(rtrim(temptable.JOB)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 
						THEN 'ltrim(rtrim(Jobs.JobANameCons)) collate database_default' ELSE 'ltrim(rtrim(Jobs.JobAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Jobs.JobNameCons))' ELSE 'ltrim(rtrim(Jobs.JobName))' END  END)+'
						where  ( not exists ( select * from #OrgTree where Jobs.JobsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Jobs.JobsOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AJOB)) collate database_default' else 'ltrim(rtrim(temptable.JOB)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AJOB)) collate database_default' else 'ltrim(rtrim(temptable.JOB)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
		--Position
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','PositionOrgs',@lang,@LogonName),(case when @lang='A' then N' برجاء التحقق من الهيكل الإداري لهذاالمركز' 
		ELSE N'Check Org. Validation for Position'  end))                          
					 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Positions ON '+case when @lang='A' then 'ltrim(rtrim(temptable.APOSITION)) collate database_default' else 'ltrim(rtrim(temptable.POSITION)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Positions.PositionNoANameCons)) collate database_default' ELSE 'ltrim(rtrim(Positions.PositionAName)) collate database_default' END
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Positions.PositionNoNameCons))' ELSE 'ltrim(rtrim(Positions.PositionName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Positions.PositionsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Positions.PositionsOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.APOSITION)) collate database_default' else 'ltrim(rtrim(temptable.POSITION)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.APOSITION)) collate database_default' else 'ltrim(rtrim(temptable.POSITION)) collate database_default' end +')) <> ''-''	 '	
		EXECUTE(@str1)
		PRINT(@str1)
		--Grade
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','GradeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة الدرجة' 
		ELSE N'Check Org. Validation for this Grade'  end))                          
					  

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AGrade)) collate database_default' else 'ltrim(rtrim(temptable.Grade)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Grades.GradeANameCons)) collate database_default' ELSE 'ltrim(rtrim(Grades.GradeAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Grades.GradeNameCons))' ELSE 'ltrim(rtrim(Grades.GradeName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Grades.GradesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Grades.GradesOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AGrade)) collate database_default' else 'ltrim(rtrim(temptable.Grade)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AGrade)) collate database_default' else 'ltrim(rtrim(temptable.Grade)) collate database_default' end +')) <> ''-'' '	
		EXECUTE(@str1)
		PRINT(@str1)

		--Currency
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','CurrencyOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة العملة'
		ELSE N'Check Org. Validation for this Currency'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=CONVERT(NVARCHAR(256),rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+''')))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Currency ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Currency.CurANameCons)) collate database_default' ELSE 'ltrim(rtrim(Currency.CurAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Currency.CurNameCons))' ELSE 'ltrim(rtrim(Currency.CurName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Currency.CurrencyOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Currency.CurrencyOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ACurrency)) collate database_default' else 'ltrim(rtrim(temptable.Currency)) collate database_default' end +')) <> ''-''  '	
		EXECUTE(@str1)
		PRINT(@str1)

		--PayrollGroup
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','PayrollGroupOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمجموعة المرتبات' 
		ELSE N'Check Org. Validation for Payroll Group'  end))                          
					 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN PayrollGroup ON '+case when @lang='A' then 'ltrim(rtrim(temptable.APayrollGroup)) collate database_default' else 'ltrim(rtrim(temptable.PayrollGroup)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(PayrollGroup.PayrollGroupANameCons)) collate database_default' ELSE 'ltrim(rtrim(PayrollGroup.PayrollGroupAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(PayrollGroup.PayrollGroupNameCons))' ELSE  'ltrim(rtrim(PayrollGroup.PayrollGroupName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where PayrollGroup.PayrollGroupOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or PayrollGroup.PayrollGroupOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.APayrollGroup)) collate database_default' else 'ltrim(rtrim(temptable.PayrollGroup)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.APayrollGroup)) collate database_default' else 'ltrim(rtrim(temptable.PayrollGroup)) collate database_default' end +')) <> ''-''	 '	
		
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org1
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org1Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 1' 
		ELSE N'Check Org. Validation for Organization 1'  end))                          
					 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg1)) collate database_default' else 'ltrim(rtrim(temptable.Org1)) collate database_default' end +'= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
					where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg1)) collate database_default' else 'ltrim(rtrim(temptable.Org1)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg1)) collate database_default' else 'ltrim(rtrim(temptable.Org1)) collate database_default' end +')) <> ''-'' '		
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org2
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org2Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 2'  
		ELSE N'Check Org. Validation for Organization 2'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg2)) collate database_default' else 'ltrim(rtrim(temptable.Org2)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg2)) collate database_default' else 'ltrim(rtrim(temptable.Org2)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg2)) collate database_default' else 'ltrim(rtrim(temptable.Org2)) collate database_default' end +')) <> ''-'' '	
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org3
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org3Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 3' 
		ELSE N'Check Org. Validation for Organization 3'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg3)) collate database_default' else 'ltrim(rtrim(temptable.Org3)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg3)) collate database_default' else 'ltrim(rtrim(temptable.Org3)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg3)) collate database_default' else 'ltrim(rtrim(temptable.Org3)) collate database_default' end +')) <> ''-'' '		
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org4
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org4Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 4'  
		ELSE N'Check Org. Validation for Organization 4'  end))                          
					
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg4)) collate database_default' else 'ltrim(rtrim(temptable.Org4)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg4)) collate database_default' else 'ltrim(rtrim(temptable.Org4)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg4)) collate database_default' else 'ltrim(rtrim(temptable.Org4)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org5
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org5Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 5'  
		ELSE N'Check Org. Validation for Organization 5'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg5)) collate database_default' else 'ltrim(rtrim(temptable.Org5)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg5)) collate database_default' else 'ltrim(rtrim(temptable.Org5)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg5)) collate database_default' else 'ltrim(rtrim(temptable.Org5)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org6
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org6Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 6' 
		ELSE N'Check Org. Validation for Organization 6'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg6)) collate database_default' else 'ltrim(rtrim(temptable.Org6)) collate database_default' end +' = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg6)) collate database_default' else 'ltrim(rtrim(temptable.Org6)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg6)) collate database_default' else 'ltrim(rtrim(temptable.Org6)) collate database_default' end +')) <> ''-'' '	
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org7
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org7Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 7' 
		ELSE N'Check Org. Validation for Organization 7'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg7)) collate database_default' else 'ltrim(rtrim(temptable.Org7)) collate database_default' end +'= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg7)) collate database_default' else 'ltrim(rtrim(temptable.Org7)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg7)) collate database_default' else 'ltrim(rtrim(temptable.Org7)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org8
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org8Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 8' 
		ELSE N'Check Org. Validation for Organization 8'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg8)) collate database_default' else 'ltrim(rtrim(temptable.Org8)) collate database_default' end +'='+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg8)) collate database_default' else 'ltrim(rtrim(temptable.Org8)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg8)) collate database_default' else 'ltrim(rtrim(temptable.Org8)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
		-- Org9
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org9Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 9' 
		ELSE N'Check Org. Validation for Organization 9'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg9)) collate database_default' else 'ltrim(rtrim(temptable.Org9)) collate database_default' end +'='+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg9)) collate database_default' else 'ltrim(rtrim(temptable.Org9)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg9)) collate database_default' else 'ltrim(rtrim(temptable.Org9)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
	-- Org10
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org10Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للإدارة 10' 
		ELSE N'Check Org. Validation for Organization 10'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg10)) collate database_default' else 'ltrim(rtrim(temptable.Org10)) collate database_default' end +'='+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
						and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg10)) collate database_default' else 'ltrim(rtrim(temptable.Org10)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AOrg10)) collate database_default' else 'ltrim(rtrim(temptable.Org10)) collate database_default' end +')) <> ''-'' '
		EXECUTE(@str1)
		PRINT(@str1)
		
		-- HRStatus
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','HRStatusOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لحالة التعيين' 
		ELSE N'Check Org. Validation for HR Status'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN HRStatus ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AHRStatus)) collate database_default' else 'ltrim(rtrim(temptable.HRStatus)) collate database_default' end +'='+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(HrStatus.HrStatusANameCons)) collate database_default' ELSE 'ltrim(rtrim(HrStatus.HrStatusAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(HrStatus.HrStatusNameCons))' ELSE 'ltrim(rtrim(HrStatus.HrStatusName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where HRStatus.HrStatusOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or HRStatus.HrStatusOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AHRStatus)) collate database_default' else 'ltrim(rtrim(temptable.HRStatus)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AHRStatus)) collate database_default' else 'ltrim(rtrim(temptable.HRStatus)) collate database_default' end +')) <> ''-''  '	
		EXECUTE(@str1)
		PRINT(@str1)
		-- ContractType
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','ContractTypeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لنوع العقد' 
		ELSE N'Check Org. Validation for Contract Type'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ContractType ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AContractType)) collate database_default' else 'ltrim(rtrim(temptable.ContractType)) collate database_default' end +'='+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(ContractType.ContractANameCons)) collate database_default' ELSE 'ltrim(rtrim(ContractType.ContractAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(ContractType.ContractNameCons))' ELSE 'ltrim(rtrim(ContractType.ContractName))' END END )+' 
						where  ( not exists ( select * from #OrgTree where ContractType.ContractTypeOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or ContractType.ContractTypeOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AContractType)) collate database_default' else 'ltrim(rtrim(temptable.ContractType)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AContractType)) collate database_default' else 'ltrim(rtrim(temptable.ContractType)) collate database_default' end +')) <> ''-'' '
			EXECUTE(@str1)
		PRINT(@str1)
		
		-- Location
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','LocationOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الموقع' 
		ELSE N'Check Org. Validation for Location'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Location ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ALocation)) collate database_default' else 'ltrim(rtrim(temptable.Location)) collate database_default' end +'= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Location.LocationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Location.LocationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Location.LocationNameCons))' ELSE 'ltrim(rtrim(Location.LocationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Location.LocationOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Location.LocationOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ALocation)) collate database_default' else 'ltrim(rtrim(temptable.Location)) collate database_default' end +','''') <> '''' and rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ALocation)) collate database_default' else 'ltrim(rtrim(temptable.Location)) collate database_default' end +')) <> ''-''	 '
		EXECUTE(@str1)
		PRINT(@str1)
		-- Salary Scale
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','SalaryScaleOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمقياس المرتب' 
		ELSE N'Check Org. Validation for Salary Scale'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN SalaryScales ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ASalaryScale)) collate database_default' else 'ltrim(rtrim(temptable.SalaryScale)) collate database_default' end +'='+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(SalaryScales.SalaryScaleANameCons)) collate database_default' ELSE 'ltrim(rtrim(SalaryScales.SalaryScaleAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(SalaryScales.SalaryScaleNameCons))' ELSE  'ltrim(rtrim(SalaryScales.SalaryScaleName))'  END END)+' 
						where  ( not exists ( select * from #OrgTree where SalaryScales.SalaryScalesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or SalaryScales.SalaryScalesOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ASalaryScale)) collate database_default' else 'ltrim(rtrim(temptable.SalaryScale)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ASalaryScale)) collate database_default' else 'ltrim(rtrim(temptable.SalaryScale)) collate database_default' end +')) <> ''-''	 '
		EXECUTE(@str1)	
		PRINT(@str1)
		-- Vacpack
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','vacpackOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لطريقة حساب الأجازة'
		ELSE N'Check Org. Validation for Vacation Package'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN vacpack ON '+case when @lang='A' then 'ltrim(rtrim(temptable.Avacpack)) collate database_default' else 'ltrim(rtrim(temptable.vacpack)) collate database_default' end +'='+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(VacPack.VacPackANameCons)) collate database_default' ELSE 'ltrim(rtrim(VacPack.vacpackAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(VacPack.VacPackNameCons))' ELSE 'ltrim(rtrim(VacPack.vacpackName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where vacpack.VacPackOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or vacpack.VacPackOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.Avacpack)) collate database_default' else 'ltrim(rtrim(temptable.vacpack)) collate database_default' end +','''') <> '''' AND rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.Avacpack)) collate database_default' else 'ltrim(rtrim(temptable.vacpack)) collate database_default' end +')) <> ''-''  '	
		EXECUTE(@str1)
		PRINT(@str1)
		-- TimeRule
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','TimeRuleOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لقاعدة حساب الوقت' 
		ELSE N'Check Org. Validation for Time keeping Rule'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN TimeRules ON '+case when @lang='A' then 'ltrim(rtrim(temptable.ATimeRule)) collate database_default' else 'ltrim(rtrim(temptable.TimeRule)) collate database_default' end +'= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(TimeRules.TRuleADescCons)) collate database_default' ELSE 'ltrim(rtrim(TimeRules.TRuleADesc)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(TimeRules.TRuleDescCons)) collate database_default' ELSE 'ltrim(rtrim(TimeRules.TRuleDesc)) collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where TimeRules.TimeRulesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TimeRules.TimeRulesOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.ATimeRule)) collate database_default' else 'ltrim(rtrim(temptable.TimeRule)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.ATimeRule)) collate database_default' else 'ltrim(rtrim(temptable.TimeRule)) collate database_default' end +')) <> ''-'' '	
		EXECUTE(@str1)
		PRINT(@str1)
		-- Employer
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','EmployerOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمكتب التأمينات' 
		ELSE N'Check Org. Validation for Employer'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Employer ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AEmployer)) collate database_default' else 'ltrim(rtrim(temptable.Employer)) collate database_default' end +'= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Employer.EmployerANameCons)) collate database_default' ELSE 'ltrim(rtrim(Employer.EmployerAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Employer.EmployerNameCons)) collate database_default' ELSE 'ltrim(rtrim(Employer.EmployerName)) collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Employer.EmployerOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Employer.EmployerOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AEmployer)) collate database_default' else 'ltrim(rtrim(temptable.Employer)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AEmployer)) collate database_default' else 'ltrim(rtrim(temptable.Employer)) collate database_default' end +')) <> ''-'' '	
		EXECUTE(@str1)
		PRINT(@str1)
		-- Graduate
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','GraduateOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري للتخرج' 
		ELSE N'Check Org. Validation for Graduate'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Graduate ON '+case when @lang='A' then 'ltrim(rtrim(temptable.AGraduation)) collate database_default' else 'ltrim(rtrim(temptable.Graduation)) collate database_default' end +' = '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Graduate.GraduateANameCons)) collate database_default' ELSE 'ltrim(rtrim(Graduate.GraduateAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Graduate.GraduateNameCons)) collate database_default' ELSE 'ltrim(rtrim(Graduate.GraduateName)) collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Graduate.GraduateOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Graduate.GraduateOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull('+case when @lang='A' then 'ltrim(rtrim(temptable.AGraduation)) collate database_default' else 'ltrim(rtrim(temptable.Graduation)) collate database_default' end +','''') <> '''' And rtrim(ltrim('+case when @lang='A' then 'ltrim(rtrim(temptable.AGraduation)) collate database_default' else 'ltrim(rtrim(temptable.Graduation)) collate database_default' end +')) <> ''-'' '	
		EXECUTE(@str1)
		PRINT(@str1)		
	END
--		---------------------------------------end validation---------------------------------------------------------------------------		
	END
	else
	begin
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	
			--Nationality
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','NationalityOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذاالجنسية'
		ELSE N'Check Org. Validation for this Nationality'  end))                          

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Nations ON ltrim(rtrim(temptable.Nationality)) collate database_default=  '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Nations.NationANameCons)) collate database_default' 
						ELSE  'ltrim(rtrim(Nations.NationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Nations.NationNameCons))' ELSE  'ltrim(rtrim(Nations.NationName))' END END)+'
						where  ( not exists ( select * from #OrgTree where Nations.NationsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Nations.NationsOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+' end and isnull(ltrim(rtrim(temptable.Nationality)),'''') <> '''' and rtrim(ltrim(temptable.Nationality)) <> ''-'' AND Nations.NationName IS not null'
					

		EXECUTE(@str1)

	
		--CostCenter
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','CostCenterOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمركز التكلفة'
		ELSE N'Check Org. Validation for Cost Center'  end))                          
 	 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN CostCntr ON ltrim(rtrim(temptable.CostCenter)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(CostCntr.CenterANameCons)) collate database_default' ELSE 'ltrim(rtrim(CostCntr.CenterAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(CostCntr.CenterNameCons))' ELSE  'ltrim(rtrim(CostCntr.CenterName))' END END)+'
						where  ( not exists ( select * from #OrgTree where CostCntr.CostCntrOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or CostCntr.CostCntrOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.CostCenter)),'''') <> '''' and rtrim(ltrim(temptable.CostCenter)) <> ''-''	and CostCntr.CenterName is not null'
		EXECUTE(@str1)
		--Job
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','JobOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذةالوظيفة'
		ELSE N'Check Org. Validation for Job'  end))                          
			  


		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Jobs ON ltrim(rtrim(temptable.JOB)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 
						THEN 'ltrim(rtrim(Jobs.JobANameCons)) collate database_default' ELSE 'ltrim(rtrim(Jobs.JobAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Jobs.JobNameCons))' ELSE 'ltrim(rtrim(Jobs.JobName))' END  END)+'
						where  ( not exists ( select * from #OrgTree where Jobs.JobsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Jobs.JobsOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Job)),'''') <> '''' and rtrim(ltrim(temptable.Job)) <> ''-'' and Jobs.JobName is not null '
		EXECUTE(@str1)

		--Position
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','PositionOrgs',@lang,@LogonName),(case when @lang='A' then N' برجاء التحقق من الهيكل الإداري لهذاالمركز' 
		ELSE N'Check Org. Validation for Position'  end))                          
					 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Positions ON ltrim(rtrim(temptable.POSITION)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Positions.PositionNoANameCons)) collate database_default' ELSE 'ltrim(rtrim(Positions.PositionAName)) collate database_default' END
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Positions.PositionNoNameCons))' ELSE 'ltrim(rtrim(Positions.PositionName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Positions.PositionsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Positions.PositionsOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Position)),'''') <> '''' and rtrim(ltrim(temptable.Position)) <> ''-'' and Positions.PositionName is not null  '	
		EXECUTE(@str1)

		--Grade
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','GradeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة الدرجة' 
		ELSE N'Check Org. Validation for this Grade'  end))                          
					  

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON ltrim(rtrim(temptable.Grade)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Grades.GradeANameCons)) collate database_default' ELSE 'ltrim(rtrim(Grades.GradeAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Grades.GradeNameCons))' ELSE 'ltrim(rtrim(Grades.GradeName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Grades.GradesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Grades.GradesOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Grade)),'''') <> '''' and rtrim(ltrim(temptable.Grade)) <> ''-''  and Grades.GradeName is not null '	
		EXECUTE(@str1)


		--Currency
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','CurrencyOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة العملة'
		ELSE N'Check Org. Validation for this Currency'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=CONVERT(NVARCHAR(256),rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+''')))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Currency ON ltrim(rtrim(temptable.Currency)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Currency.CurANameCons)) collate database_default' ELSE 'ltrim(rtrim(Currency.CurAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Currency.CurNameCons))' ELSE 'ltrim(rtrim(Currency.CurName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Currency.CurrencyOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Currency.CurrencyOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Currency)),'''') <> '''' and rtrim(ltrim(temptable.Currency)) <> ''-'' and Currency.CurName is not null  '	
		EXECUTE(@str1)


		--PayrollGroup
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','PayrollGroupOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمجموعة المرتبات' 
		ELSE N'Check Org. Validation for Payroll Group'  end))                          
					 

		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN PayrollGroup ON ltrim(rtrim(temptable.PayrollGroup)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(PayrollGroup.PayrollGroupANameCons)) collate database_default' ELSE 'ltrim(rtrim(PayrollGroup.PayrollGroupAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(PayrollGroup.PayrollGroupNameCons))' ELSE  'ltrim(rtrim(PayrollGroup.PayrollGroupName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where PayrollGroup.PayrollGroupOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or PayrollGroup.PayrollGroupOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.PayrollGroup)),'''') <> '''' and rtrim(ltrim(temptable.PayrollGroup)) <> ''-''	and PayrollGroup.PayrollGroupName is not null '	
		
		EXECUTE(@str1)

		-- Org1
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org1Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 1' 
		--ELSE N'Check Org. Validation for Organization 1'  end))                          
					 

		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org1)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--			where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org1)),'''') <> '''' AND rtrim(ltrim(temptable.Org1)) <> ''-'' AND Organization.Organization IS not null'		
		--EXECUTE(@str1)

		---- Org2
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org2Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 2'  
		--ELSE N'Check Org. Validation for Organization 2'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org2)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org2)),'''') <> '''' AND rtrim(ltrim(temptable.Org2)) <> ''-'' AND Organization.Organization IS not null'	
		--EXECUTE(@str1)
		---- Org3
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org3Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 3' 
		--ELSE N'Check Org. Validation for Organization 3'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org3)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org3)),'''') <> '''' AND rtrim(ltrim(temptable.Org3)) <> ''-'' AND Organization.Organization IS not null'		
		--EXECUTE(@str1)
		---- Org4
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org4Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 4'  
		--ELSE N'Check Org. Validation for Organization 4'  end))                          
					
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org4)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org4)),'''') <> '''' AND rtrim(ltrim(temptable.Org4)) <> ''-'' AND Organization.Organization IS not null'
		--EXECUTE(@str1)
		---- Org5
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org5Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 5'  
		--ELSE N'Check Org. Validation for Organization 5'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org5)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org5)),'''') <> '''' AND rtrim(ltrim(temptable.Org5)) <> ''-'' AND Organization.Organization IS not null'
		--EXECUTE(@str1)
		---- Org6
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org6Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 6' 
		--ELSE N'Check Org. Validation for Organization 6'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org6)) collate database_default = '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org6)),'''') <> '''' AND rtrim(ltrim(temptable.Org6)) <> ''-'' AND Organization.Organization IS not null'	
		--EXECUTE(@str1)
		---- Org7
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org7Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 7' 
		--ELSE N'Check Org. Validation for Organization 7'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org7)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org7)),'''') <> '''' AND rtrim(ltrim(temptable.Org7)) <> ''-'' AND Organization.Organization IS not null'
		--EXECUTE(@str1)
		
		---- Org8
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org8Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 8' 
		--ELSE N'Check Org. Validation for Organization 8'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org8)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org8)),'''') <> '''' AND rtrim(ltrim(temptable.Org8)) <> ''-'' AND Organization.Organization IS not null'
		--EXECUTE(@str1)
		
		---- Org9
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org9Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 9' 
		--ELSE N'Check Org. Validation for Organization 9'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org9)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org9)),'''') <> '''' AND rtrim(ltrim(temptable.Org9)) <> ''-'' AND Organization.Organization IS not null'
		--EXECUTE(@str1)
		
		---- Org10
		--SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','Org10Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 10' 
		--ELSE N'Check Org. Validation for Organization 10'  end))                          
					 
		--SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN Organization ON ltrim(rtrim(temptable.Org10)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Organization.OrganizationAName)) collate database_default' END 
		--				ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Organization.OrganizationNameCons))' ELSE 'ltrim(rtrim(Organization.OrganizationName))'  END END )+' 
		--				where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) and 
		--                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end 
		--				and isnull(ltrim(rtrim(temptable.Org10)),'''') <> '''' AND rtrim(ltrim(temptable.Org10)) <> ''-'' AND Organization.Organization IS not null'
		--EXECUTE(@str1)
			
		-- HRStatus
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','HRStatusOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لحالة التعيين' 
		ELSE N'Check Org. Validation for HR Status'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN HRStatus ON ltrim(rtrim(temptable.HRStatus)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(HrStatus.HrStatusANameCons)) collate database_default' ELSE 'ltrim(rtrim(HrStatus.HrStatusAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(HrStatus.HrStatusNameCons))' ELSE 'ltrim(rtrim(HrStatus.HrStatusName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where HRStatus.HrStatusOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or HRStatus.HrStatusOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.HRStatus)),'''') <> '''' and rtrim(ltrim(temptable.HRStatus)) <> ''-'' and HrStatus.HrStatusName is not null '	
		EXECUTE(@str1)
		
		
		-- ContractType
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','ContractTypeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لنوع العقد' 
		ELSE N'Check Org. Validation for Contract Type'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ContractType ON ltrim(rtrim(temptable.ContractType)) collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ltrim(rtrim(ContractType.ContractANameCons)) collate database_default' ELSE 'ltrim(rtrim(ContractType.ContractAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(ContractType.ContractNameCons))' ELSE 'ltrim(rtrim(ContractType.ContractName))' END END )+' 
						where  ( not exists ( select * from #OrgTree where ContractType.ContractTypeOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or ContractType.ContractTypeOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.ContractType)),'''') <> '''' and rtrim(ltrim(temptable.ContractType)) <> ''-'' and ContractType.ContractName is not null '
	
		-- Location
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','LocationOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الموقع' 
		ELSE N'Check Org. Validation for Location'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Location ON ltrim(rtrim(temptable.Location)) collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Location.LocationANameCons)) collate database_default' ELSE 'ltrim(rtrim(Location.LocationAName)) collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Location.LocationNameCons))' ELSE 'ltrim(rtrim(Location.LocationName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where Location.LocationOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Location.LocationOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Location)),'''') <> '''' and rtrim(ltrim(temptable.Location)) <> ''-'' and Location.LocationName is not null	 '
		EXECUTE(@str1)
		-- Salary Scale
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','SalaryScaleOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمقياس المرتب' 
		ELSE N'Check Org. Validation for Salary Scale'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN SalaryScales ON ltrim(rtrim(temptable.SalaryScale)) collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(SalaryScales.SalaryScaleANameCons)) collate database_default' ELSE 'ltrim(rtrim(SalaryScales.SalaryScaleAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(SalaryScales.SalaryScaleNameCons))' ELSE  'ltrim(rtrim(SalaryScales.SalaryScaleName))'  END END)+' 
						where  ( not exists ( select * from #OrgTree where SalaryScales.SalaryScalesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or SalaryScales.SalaryScalesOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.SalaryScale)),'''') <> '''' AND rtrim(ltrim(temptable.SalaryScale)) <> ''-''	and SalaryScales.SalaryScaleName is not null '
		EXECUTE(@str1)	
		-- Vacpack
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','vacpackOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لطريقة حساب الأجازة'
		ELSE N'Check Org. Validation for Vacation Package'  end))                          
					 
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN vacpack ON ltrim(rtrim(temptable.vacpack)) collate database_default = '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(VacPack.VacPackANameCons)) collate database_default' ELSE 'ltrim(rtrim(VacPack.vacpackAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(VacPack.VacPackNameCons))' ELSE 'ltrim(rtrim(VacPack.vacpackName))'  END END )+' 
						where  ( not exists ( select * from #OrgTree where vacpack.VacPackOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or vacpack.VacPackOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.vacpack)),'''') <> '''' AND rtrim(ltrim(temptable.vacpack)) <> ''-'' AND vacpack.vacpack IS not null '	
		EXECUTE(@str1)
		-- TimeRule
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','TimeRuleOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لقاعدة حساب الوقت' 
		ELSE N'Check Org. Validation for Time keeping Rule'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN TimeRules ON ltrim(rtrim(temptable.TimeRule)) collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(TimeRules.TRuleADescCons)) collate database_default' ELSE 'ltrim(rtrim(TimeRules.TRuleADesc)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(TimeRules.TRuleDescCons)) collate database_default' ELSE 'ltrim(rtrim(TimeRules.TRuleDesc)) collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where TimeRules.TimeRulesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TimeRules.TimeRulesOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.TimeRule)),'''') <> '''' And rtrim(ltrim(temptable.TimeRule)) <> ''-'' and TimeRules.TRuleDesc is not null '	
		EXECUTE(@str1)

		-- Employer
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','EmployerOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري  لمكتب التأمينات' 
		ELSE N'Check Org. Validation for Employer'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Employer ON ltrim(rtrim(temptable.Employer)) collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Employer.EmployerANameCons)) collate database_default' ELSE 'ltrim(rtrim(Employer.EmployerAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Employer.EmployerNameCons)) collate database_default' ELSE 'ltrim(rtrim(Employer.EmployerName)) collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Employer.EmployerOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Employer.EmployerOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Employer)),'''') <> '''' And rtrim(ltrim(temptable.Employer)) <> ''-'' and Employer.EmployerId is not null '	
		EXECUTE(@str1)
		
	 -- Graduate
		SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','GraduateOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري  للتخرج' 
		ELSE N'Check Org. Validation for Graduate'  end))                          
					  
		SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Graduate ON ltrim(rtrim(temptable.Graduate)) collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Graduate.GraduateANameCons)) collate database_default' ELSE 'ltrim(rtrim(Graduate.GraduateAName)) collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'ltrim(rtrim(Graduate.GraduateNameCons)) collate database_default' ELSE 'ltrim(rtrim(Graduate.GraduateName)) collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Graduate.GraduateOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Graduate.GraduateOrgs ='''' )) and 
		                temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))
						+ ' end and isnull(ltrim(rtrim(temptable.Graduate)),'''') <> '''' And rtrim(ltrim(temptable.Graduate)) <> ''-'' and Graduate.GraduateId is not null '	
		EXECUTE(@str1)
				
	END
	end

	
	-- Kids No.	
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidKidsNo',@lang,@LogonName),(case when @lang='A' then N'عدد الأطفال لابد ان يكون أرقام' ELSE 'Kids No. must be Numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(isnull(temptable.KidsNum,0))=0
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)

		-- HR Ins. Appl		
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','InValidHRSSApp',@lang,@LogonName),(case when @lang='A' then N'قيمة مؤمن عليه غير صحيحة' ELSE 'invaid HR Ins. App'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnull(temptable.HrSsAppl,''0'') not in (''0'',''1'') 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	-- VacPrvBal1		
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','InValidVaCPrvBal1',@lang,@LogonName),(case when @lang='A' then N'رصيد الأجازات السابق 1 لابد أن يكون أرقام' ELSE 'Vacation Previous Balance 1 must be numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(temptable.vacprvBal1)=0 and ltrim(rtrim(temptable.vacprvBal1))<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)

	
	-- VacPrvBal2	
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','InValidVaCPrvBal2',@lang,@LogonName),(case when @lang='A' then N'رصيد الأجازات السابق 2 لابد أن يكون أرقام' ELSE 'Vacation Previous Balance 3 must be numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(temptable.vacprvBal2)=0 and ltrim(rtrim(temptable.vacprvBal2))<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	 -- VacPrvBal3	
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('common','InValidVaCPrvBal3',@lang,@LogonName),(case when @lang='A' then N'رصيد الأجازات السابق 3 لابد أن يكون أرقام' ELSE 'Vacation Previous Balance 3 must be numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(temptable.vacprvBal3)=0 and ltrim(rtrim(temptable.vacprvBal3))<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	--handicap validation		
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InValidHandicap',@lang,@LogonName),(case when @lang='A' then N'قيمة الإعاقة غير صحيحة' ELSE 'Invalid handicap Value'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnull(temptable.Handicap,''0'') not in (''0'',''1'') 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	-- Mil. Service Years validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InValidMilServiceYears',@lang,@LogonName),(case when @lang='A' then N'عدد سنوات الخدمة في الجيش لابد أن يكون أرقام' ELSE 'Military Service Years must be numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(isnull(temptable.MilServYears,0))=0 and ltrim(rtrim(temptable.MilServYears))<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	-- Mil. Service Months validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InValidMilServiceMonths',@lang,@LogonName),(case when @lang='A' then N'عدد شهور الخدمة في الجيش لابد أن يكون أرقام' ELSE 'Military Service Months must be numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(isnull(temptable.MilServMonths,0))=0 and ltrim(rtrim(temptable.MilServMonths))<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	-- Mil. Service Days validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InValidMilServiceDays',@lang,@LogonName),(case when @lang='A' then N'عدد أيام الخدمة في الجيش لابد أن يكون أرقام' ELSE 'Military Service Days must be numeric'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE isnumeric(isnull(temptable.MilServDays,0))=0 and ltrim(rtrim(temptable.MilServDays))<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	
	--------------------------Dates Validations--------------------------------
	
	-- Hire Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidHireDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ التعيين بشكل صحيح' ELSE 'Enter a Valid Hire Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate( SUBSTRING(temptable.HireDate,1,10))=0 or  SUBSTRING(temptable.HireDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.HireDate,'''')<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)
	
	-- Termination Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidTermDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ الإنتهاء بشكل صحيح' ELSE 'Enter a Valid Termination Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.TerminationDate,1,10))=0 or SUBSTRING(temptable.TerminationDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.TerminationDate,'''')<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	-- Birth Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidBirthDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ الميلاد بشكل صحيح' ELSE 'Enter a Valid Birth Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.BirthDate,1,10))=0 or SUBSTRING(temptable.BirthDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.BirthDate,'''')<>''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	-- National Id Issue Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidNationalIdIssueDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ اصدار الرقم القومي بشكل صحيح' ELSE 'Enter a Valid  National Id Issue Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	              WHERE ( isdate(SUBSTRING(temptable.NationalIdIssueDate,1,10))=0 or SUBSTRING(temptable.NationalIdIssueDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'') AND ISNULL(temptable.NationalIdIssueDate,'''')<>'''' 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	-- Contract Start Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidContractStartDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ بداية العقد بشكل صحيح' ELSE 'Enter a Valid  Contract Start Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.ContractStartDate,1,10))=0 or SUBSTRING(temptable.ContractStartDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.ContractStartDate,'''')<>'''' 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	-- Propation Period Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidProbationPeriodDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إنتهاء فترة الإختبار بشكل صحيح' ELSE 'Enter a Valid  Probation Period Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.ProbabationPeriodDate,1,10))=0 or SUBSTRING(temptable.ProbabationPeriodDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.ProbabationPeriodDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	--Contract End Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidContractEndDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إنتهاءالعقد بشكل صحيح' ELSE 'Enter a Valid  Contract End Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.ContractEndDate,1,10))=0 or SUBSTRING(temptable.ContractEndDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  	 AND ISNULL(temptable.ContractEndDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	--Passport Issue Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidPassportIssueDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إصدار جواز السفر بشكل صحيح' ELSE 'Enter a Valid  Passport Issue Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.PassportIssueDate,1,10))=0 or SUBSTRING(temptable.PassportIssueDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'' )  AND ISNULL(temptable.PassportIssueDate,'''')<>'''' 		
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)

	--Passport Expiry Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidPassportExpiryDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إنتهاء جواز السفر بشكل صحيح' ELSE 'Enter a Valid  Passport Expiry Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.PassportExpiryDate,1,10))=0 or SUBSTRING(temptable.PassportExpiryDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  	AND ISNULL(temptable.PassportExpiryDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)
	
	--SSStart Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidSSStartDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ بداية التأمين الإجنماعي بشكل صحيح' ELSE 'Enter a Valid Social insurance Start Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.SSStartDate,1,10))=0 or SUBSTRING(temptable.SSStartDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'') AND ISNULL(temptable.SSStartDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)	
	--Military Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidMilDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ الخدمة العسكرية بشكل صحيح' ELSE 'Enter a Valid Military Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.MilDate,1,10))=0 or SUBSTRING(temptable.MilDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]''  	) AND ISNULL(temptable.MilDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)	
	--Military Expiration Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidMilExpirationDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إنتهاءالحالة العسكرية بشكل صحيح' ELSE 'Enter a Valid Military Expiration Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.MilExpDate,1,10))=0 or SUBSTRING(temptable.MilExpDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.MilExpDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)	
	PRINT (@str1)	

	--Reservation Start Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidReservationStartDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إصدار تصريح الإقامة بشكل صحيح' ELSE 'Enter a Valid Reservation Start Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.ReservationStartDate,1,10))=0 or SUBSTRING(temptable.ReservationStartDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.ReservationStartDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)	
	PRINT (@str1)	
	--Reservation End Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidReservationEndDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إنتهاء تصريح الإقامة بشكل صحيح' ELSE 'Enter a Valid Reservation End Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.ReservationEndDate,1,10))=0 or SUBSTRING(temptable.ReservationEndDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'')  AND ISNULL(temptable.ReservationEndDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)
	PRINT (@str1)	
	--Work Receiving Date validation
	SELECT @errormsg1= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees','InvalidWorkReceivingDate',@lang,@LogonName),(case when @lang='A' then N'قم بإدخال تاريخ إستلام العمل بشكل صحيح' ELSE 'Enter a Valid Work Receiving Date'  end))                          
	SELECT @str1='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg1+'''))  , post=0  
	FROM '+@tablename+' temptable 
	WHERE (isdate(SUBSTRING(temptable.WorkReceivingDate,1,10))=0 or SUBSTRING(temptable.WorkReceivingDate,1,10)  NOT LIKE ''[1-9][0-9][0-9][0-9]/[0-1][0-9]/[0-3][0-9]'' )  AND ISNULL(temptable.WorkReceivingDate,'''')<>'''' 	
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str1)		
	PRINT (@str1)	
	
	---------------------------------------------------
		
	IF @EnableTextValidation = '1' 
	BEGIN
		
		DECLARE @PayrollStatus AS NVARCHAR(max), @Address AS NVARCHAR(max) , @HomeCountryAddress AS NVARCHAR(MAX), @cEmail AS NVARCHAR(max), @pEmail AS NVARCHAR(max), @passportNo AS NVARCHAR(max), @PassportIssue AS NVARCHAR(max), @IdInfo AS NVARCHAR(max), @VacBalType1 AS NVARCHAR(max), @VacBalType2 AS NVARCHAR(max) , @VacBalType3 AS NVARCHAR(max), @MartialStatus AS NVARCHAR(max), @Gender AS NVARCHAR(max), @MilStatus AS NVARCHAR(max), @Name AS NVARCHAR(max)
		--SELECT @PayrollStatus = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'PayrollStatus', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'حالة المرتب' ELSE 'Payroll Status' END)
		SELECT @Address = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'Address', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'العنوان' ELSE 'Address' END)
		SELECT @HomeCountryAddress = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'HomeCountryAddress', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'عنوان الوطن' ELSE 'Home Country Address' END)
		SELECT @cEmail = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'CompanyEmail', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'(البريد الالكتروني (الشركة' ELSE 'Company Email' END)
		SELECT @pEmail = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'PrivateEmail', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'البريد الالكتروني الشخصى' ELSE 'Private Email' END)
		SELECT @passportNo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'PassportNo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رقم جواز السفر' ELSE 'Passport No' END)
		SELECT @PassportIssue = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'PassportIssuePlace', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'جهة إصدار جواز السفر' ELSE 'Passport Issue Place' END)
		SELECT @IdInfo =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'IDINFO', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات البطاقة' ELSE 'ID Info.' END)
		--SELECT @VacBalType1 =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'VacPrvBal1', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رصيد أجازات سابق نوع1' ELSE 'Vacation Previous Balance Type1' END)
		--SELECT @VacBalType2 =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'VacPrvBal2', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رصيد أجازات سابق نوع2' ELSE 'Vacation Previous Balance Type2' END)
		--SELECT @VacBalType3 =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'VacPrvBal3', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'رصيد أجازات سابق نوع3' ELSE 'Vacation Previous Balance Type3' END)
		--SELECT @MartialStatus =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'MaritalStatus', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الحالة الإجتماعية'  ELSE 'Marital Status' END)
		--SELECT @Gender =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'Gender', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'النوع' ELSE 'Gender' END)
		--SELECT @MilStatus =  ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'MilStatus', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'حالة الخدمة العسكرية' ELSE 'Military Status' END)

		SELECT @Name = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmployees', 'Name', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'الاسم' ELSE 'Name' END)
		
		----Validate Payroll Satus
		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @PayrollStatus + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''PayrollStatus'', PayrollStatus) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		--EXEC(@Str) 

		--Validate Address
		SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @Address + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''Address'', Address) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)

		--Validate Home Country Address
		SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @HomeCountryAddress + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''HomeCountryAddress'', HomeCountryAddress) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)


		--Validate Passport Issue Place
		SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @PassportIssue + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''PassportIssuePlace'', PassportIssuePlace) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)

		--Validate Id Info
		SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @IdInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''IDINFO'', IDINFO) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)
		
--		----Validate VacPrvBal1
--		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @VacBalType1 + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
--  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''VacPrvBal1'', VacPrvBal1) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
--		--EXEC(@Str)

--		----Validate VacPrvBal2
--		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @VacBalType2 + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
--  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''VacPrvBal2'', VacPrvBal2) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
--		--EXEC(@Str)

--		----Validate VacPrvBal3
--		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @VacBalType3 + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
--  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''VacPrvBal3'', VacPrvBal3) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
--		--EXEC(@Str)

--		----Validate MaritalStatus
--		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @MartialStatus + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
--  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''SocStatus'', SocStatus) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
--		--EXEC(@Str)

--		----Validate Gender
--		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @Gender + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
--  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''Gender'', Gender) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
--		--EXEC(@Str)
		


		--Validate Name
		SELECT @Str = 'UPDATE ' + @tablename + '  SET  Remarks = LTRIM(RTRIM(Remarks))  + N''' + @Name + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalEmployees'', ''Name'', Name) = 0 and Tmptbl.Post = 1 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)
		
	END
END    


---------------------------------------------------------------------------------------------------------------------------	


IF ltrim(rtrim(@tabletype)) ='WP_GetExternalPayrollDetails' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalPayrollDetails_ar'
BEGIN
	DECLARE @str11 AS nvarchar(max)
	select @str11='UPDATE '+@tablename+' set post= 1 FROM '+@tablename+' temptable where post is null'
	EXECUTE(@str11)

	select @str11='UPDATE '+@tablename+' set remarks= '''' FROM '+@tablename+' temptable
				   where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	PRINT 'update empty = '+ @str11
	EXECUTE(@str11)


	select @str11='UPDATE '+@tablename+' set name='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
					FROM '+@tablename+' temptable
					inner JOIN EmpAssignment ON temptable.empid collate database_default=cast(empassignment.EmployeeId collate database_default AS nvarchar(255))
					left join profile on profile.profileid=empassignment.empid
					where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.name,'''') = '''' '	
					PRINT	@str11
	EXECUTE(@str11)	

	DECLARE @errormsg22 AS nvarchar(250)
	SET @errormsg22=''

	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','Empid',@lang,@LogonName),(case when @lang='A' then N'رقم الموظف' ELSE N'Emp Id'  end))                          
				  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

	--SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) +'' / ''+ ltrim(N'''+@errormsg22+'''))  , post=0  
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))  , post=0  
					, Name = '''' FROM '+@tablename+' temptable
					left JOIN EmpAssignment ON temptable.empid collate database_default=empassignment.EmployeeId collate database_default
					where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.ContBasCur,'''') <> '''' 	AND empassignment.EmployeeId IS null '	
					PRINT	@str11
	EXECUTE(@str11)

	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','ContBasCur',@lang,@LogonName),(case when @lang='A' then N'العملة' ELSE N'Currency'  end))                          
				  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid2',@lang,@LogonName),(case when @lang='A' then N'غير صحيحة ' ELSE N' Not Valid'  end))
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))  
					FROM '+@tablename+' temptable
					left JOIN Currency ON temptable.ContBasCur collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Currency.CurANameCons collate database_default' ELSE 'Currency.CurAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'Currency.CurNameCons' ELSE  'Currency.CurName' END END)+'
					where temptable.post = 1 and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.ContBasCur,'''') <> ''''  and rtrim(ltrim(temptable.ContBasCur)) <> ''-''   AND Currency.Cur IS null '	
					PRINT	@str11
	EXECUTE(@str11)	

	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','TaxStatus',@lang,@LogonName),(case when @lang='A' then N'الحالة الضريبية' ELSE N'Tax Status'  end))  
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid2',@lang,@LogonName),(case when @lang='A' then N'غير صحيحة ' ELSE N' Not Valid'  end))                        
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))
					FROM '+@tablename+' temptable
					left JOIN NasArrays ON temptable.TaxStatus collate database_default = '+CASE WHEN @lang = 'E' THEN 'edesc collate database_default' ELSE 'adesc collate database_default' END +' 
					and arrayname = ''TaxStatus'' 
					where temptable.post = 1 and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.TaxStatus,'''') <> '''' and rtrim(ltrim(temptable.TaxStatus)) <> ''-''  and NasArrays.itemno is null '	
					PRINT	@str11
	EXECUTE(@str11)	
	----PaySCSTATUS ----
	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','PaySCSTATUS',@lang,@LogonName),(case when @lang='A' then N'رسم الخدمة (ش م )' ELSE N'Pay S.C. Status'  end))  
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid2',@lang,@LogonName),(case when @lang='A' then N'غير صحيحة ' ELSE N' Not Valid'  end))                        
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))  
					FROM '+@tablename+' temptable
					left JOIN NasArrays ON temptable.PaySCSTATUS collate database_default = '+CASE WHEN @lang = 'E' THEN 'edesc collate database_default' ELSE 'adesc collate database_default' END +' 
					and arrayname = ''scstatus'' 
					where temptable.post = 1 and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.PaySCSTATUS,'''') <> '''' and rtrim(ltrim(temptable.PaySCSTATUS)) <> ''-''  and NasArrays.itemno is null '	
					PRINT	@str11
	EXECUTE(@str11)	

	----FixedBonus ----
	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','FixedBonus',@lang,@LogonName),(case when @lang='A' then N'نقاط ثابتة' ELSE N'Fixed Bonus'  end))  
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid2',@lang,@LogonName),(case when @lang='A' then N'غير صحيحة ' ELSE N' Not Valid'  end))                        
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))
					FROM '+@tablename+' temptable
					left JOIN NasArrays ON temptable.FixedBonus collate database_default= '+CASE WHEN @lang = 'E' THEN 'edesc collate database_default' ELSE 'adesc collate database_default' END +' 
					and arrayname = ''Bonus Rate'' 
					where temptable.post = 1 and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.FixedBonus,'''') <> '''' and rtrim(ltrim(temptable.FixedBonus)) <> ''-''  and NasArrays.itemno is null '	
					PRINT	@str11
	EXECUTE(@str11)	

	-------TaxRules--------
	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','TaxRules',@lang,@LogonName),(case when @lang='A' then N'ضرائب' ELSE N'Tax'  end))                          
				  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid2',@lang,@LogonName),(case when @lang='A' then N'غير صحيحة ' ELSE N' Not Valid'  end))
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))
					FROM '+@tablename+' temptable
					left JOIN TaxRules ON temptable.TaxRules  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'TaxRules.TaxANameCons collate database_default' ELSE 'TaxRules.TaxAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'TaxRules.TaxNameCons' ELSE  'TaxRules.TaxName' END END)+'
					where temptable.post = 1 and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.TaxRules,'''') <> ''''  and rtrim(ltrim(temptable.TaxRules)) <> ''-''   AND TaxRules.taxcode IS null '	
					PRINT	@str11
	EXECUTE(@str11)	

	--------InsuranceRule------
	SELECT @errormsg22= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails','InsuranceRule',@lang,@LogonName),(case when @lang='A' then N'قاعدة التأمينات' ELSE N'Social Insurance'  end))                          
				  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid2',@lang,@LogonName),(case when @lang='A' then N'غير صحيحة ' ELSE N' Not Valid'  end))
	SELECT @str11='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg22+'''))
					FROM '+@tablename+' temptable
					left JOIN SsRules ON temptable.InsuranceRule collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'SsRules.SInsurANameCons collate database_default' ELSE 'SsRules.SInsurAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'SsRules.SInsurNameCons' ELSE  'SsRules.SInsurName' END END)+'
					where temptable.post = 1 and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end and isnull(temptable.InsuranceRule,'''') <> ''''  and rtrim(ltrim(temptable.InsuranceRule)) <> ''-''   AND SsRules.sscode IS null '	
					PRINT	@str11
	EXECUTE(@str11)	

	IF @EnableTextValidation = '1' BEGIN
		
		DECLARE @AgreementInfo AS NVARCHAR(max)
		SELECT @AgreementInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalPayrollDetails', 'AgreementInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'بيانات الإتفاق على المرتب' ELSE 'Agreement Info' END)

		--Validate Other Info
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))  + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + N''' + @AgreementInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl 
					   WHERE dbo.validateText(''WP_GetExternalPayrollDetails'', ''AgreementInfo'', AgreementInfo) = 0 
					   and  Tmptbl.Post = 1  
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)

		EXEC ('select * from ' + @tablename)
	END

	select @str='UPDATE '+@tablename+' set post=0
	FROM '+@tablename+' temptable
	where LTRIM(RTRIM(temptable.remarks))<>'''''

	PRINT @str
	EXECUTE(@str)
END

----------------------------------------------------------------------------
IF ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalApplicants%'
BEGIN	
	PRINT @tabletype
	SET @StartIndex = CHARINDEX('?',@tabletype)
	SET @Consolidation = ISNULL(SUBSTRING(@tabletype,@StartIndex+1,1),0)
	PRINT '@Consolidation : ' + STR(@Consolidation)

	SET @StartIndex = CHARINDEX(',',@tabletype)
	SET @CreateSetp = ISNULL(SUBSTRING(@tabletype,@StartIndex+1,1),0)
	PRINT '@CreateSetp : ' + STR(@CreateSetp)

	DECLARE @str2 AS nvarchar(max)
	--select @str2='UPDATE '+@tablename+' set post= 1
	--FROM '+@tablename+' temptable where post is null'
	--PRINT @str2
	--EXECUTE(@str2)
	
	select @str2='UPDATE '+@tablename+' set remarks= '''' 
	FROM '+@tablename+' temptable
	where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	--PRINT @str2
	EXECUTE(@str2)
	
	DECLARE @errormsg5 AS nvarchar(60)
	SET @errormsg5=''

	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Duplicate Record',@lang,@LogonName),(case when @lang='A' then N'الموظف مكرر' ELSE N'Duplicate Record'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE isnull(temptable.Name,''0'') <> ''0''  
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
	and temptable.Name in (SELECT t.Name
    FROM '+@tablename+' t  GROUP BY Name having COUNT(Name)>1) '		
	--PRINT @str2
	EXECUTE(@str2)
	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','RegExMessage',@lang,@LogonName),(case when @lang='A' then N'الأسم لا يسمح بدخول ارقام' ELSE N'Name should not contain Numbers'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE name like ''%[0-9]%''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	--PRINT @str2
	EXECUTE(@str2)

	--SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','JobMissing',@lang),(case when @lang='A' then N'يجب ادخال الوظيفة' ELSE N'Job is Missing'  end))     
			                
	--SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	--FROM '+@tablename+' temptable
	--where isnull(CJob,'''')=''''
	--and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	--EXECUTE(@str2)	
	
	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','OrgMissing',@lang,@LogonName),(case when @lang='A' then N'يجب ادخال الادارة' ELSE N'Organization is Missing'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	where isnull(CASE WHEN isnull(COrg7,'''') <> '''' THEN COrg7 WHEN isnull(COrg6,'''') <> '''' THEN COrg6 WHEN isnull(COrg5,'''') <> '''' THEN COrg5 WHEN isnull(COrg4,'''') <> '''' THEN COrg4 WHEN isnull(COrg3,'''') <> '''' THEN COrg3 WHEN isnull(COrg2,'''') <> '''' THEN COrg2 WHEN isnull(COrg1,'''') <> '''' THEN COrg1 END,'''') ='''' 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '	
	--PRINT @str2
	EXECUTE(@str2)	

	
	
	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','EmployeeNameMissing',@lang,@LogonName),(case when @lang='A' then N'يجب إدخال اسم الموظف'  ELSE N'Employee Name Missing'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE isnull(temptable.Name,'''')= '''' 
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end '
	EXECUTE(@str2)
	
		
	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('common','PrivacyMessage',@lang,@LogonName),(case when @lang='A' then N'الخصوصية رقم [0-9]' ELSE N'Privacy only [0-9]'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE (Privacy not like ''%[0-9]%'' or len(Privacy) > 1)
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str2)

	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ApplicationStartmissing',@lang,@LogonName),(case when @lang='A' then N'أدخل تاريخ بدء الاستمارة' ELSE N'Application Start is Missing'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE isnull(ApplicationStart,'''')=''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str2)

	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ApplicantStatusmissing',@lang,@LogonName),(case when @lang='A' then N'أدخل حالة المتقدم' ELSE N'Applicant Status is Missing'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE isnull(CApplicationStatus,'''')=''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str2)



	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ApplicationSourcemissing',@lang,@LogonName),(case when @lang='A' then N'أدخل مصدر الاستمارة' ELSE N'Application Source is Missing'  end))                          
	SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
	FROM '+@tablename+' temptable
	WHERE isnull(CApplicationSource,'''')=''''
	and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end  '
	EXECUTE(@str2)
	
		--TR_InsertEmployee

	IF @NatnNoMandatory = 1 -- For Mandatory National ID field
		BEGIN 		
			SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('V_EMPLOYEES','EmptyNationalNo',@lang,@LogonName),(case when @lang='A' then  N'يجب ادخال الرقم القومى' ELSE N'National ID is Empty'  end))                          
		select @str2=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg5+'''))+CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
				left join Nations on ltrim(rtrim(temptable.CNationId))=case when '''+@lang+'''=''e'' then LTRIM(RTRIM(Nations.NationName)) else LTRIM(RTRIM(Nations.NationAName)) end 
			where isnull(NatnlNo,'''')='''' 
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
				 AND ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId))+'',%'''   --i am the egyptian
			 +' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'') '		
			--PRINT @str1 and isnull(position,'''')=''''  
			EXECUTE(@str2)	
		END 

		IF @NatnNoUnique = 1  -- For National ID already exist
		BEGIN
	      -- @ValidateNatnlNo for Egyptians only
            SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('V_EMPLOYEES','NationalIDAlreadyExists',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى موجود مسبقاً' ELSE N'National ID Already Exists'  end))                          
		select @str2=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg5+'''))+CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
			left join Nations on ltrim(rtrim(temptable.CNationId))=case when '''+@lang+'''=''e'' then LTRIM(RTRIM(Nations.NationName)) else LTRIM(RTRIM(Nations.NationAName)) end 
			inner JOIN Profile ON temptable.NatnlNo=cast(Profile.NatnlNo AS nvarchar(20))  
			 and ltrim(rtrim(temptable.Name)) <> ltrim(rtrim(Profile.Name))
			WHERE isnull(Profile.NatnlNo,'''') <>''''
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			 	 AND ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId))+'',%'''   --i am the egyptian
			 +'or '''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Profile.NationId)) +'',%'''  -- others with same national no are egyptians
			 +' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'') '
			PRINT @str2
			EXECUTE(@str2)
			

			 -- @ValidateNatnlNo for Egyptians only
			SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','DuplicateNationalID',@lang,@LogonName),(case when @lang='A' then N'الرقم القومى مكرر' ELSE N'National ID Duplicate'  end))                          
			select @str2=N'UPDATE '+@tablename+' set remarks=rtrim(ltrim(N'''+@errormsg5+'''))+CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END+rtrim(ltrim(remarks))  , post=0  
			FROM '+@tablename+' temptable
				left join Nations on ltrim(rtrim(temptable.CNationId))=case when '''+@lang+'''=''e'' then LTRIM(RTRIM(Nations.NationName)) else LTRIM(RTRIM(Nations.NationAName)) end 
			WHERE isnull(temptable.NatnlNo,'''') <> ''''  
			and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end 
			and temptable.NatnlNo in (SELECT t.NatnlNo
											   FROM '+@tablename+' t  
											   left join Nations n on ltrim(rtrim(t.CNationId))=case when '''+@lang+'''=''e'' then LTRIM(RTRIM(n.NationName)) else LTRIM(RTRIM(n.NationAName)) end 
			                                   where t.row_number<>temptable.row_number 
			                                   and  ('''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(n.NationId))+'',%''  '   --if duplicated with egyptians 
											   	 +'or '''+@ValidateNatnlNo+''' LIKE ''%,''+rtrim(ltrim(Nations.NationId)) +'',%'''  -- others with same national no are egyptians
												+' or ISNULL('''+@ValidateNatnlNo+''','''')='''' or '''+@ValidateNatnlNo+''' =''0'')
			                                    GROUP BY NatnlNo 
			                                    having COUNT(NatnlNo)>0)'
			PRINT 'duplicate employees'
			PRINT @str2
			EXECUTE(@str2)

			
END 
---------------------------------Validate Entered Data-------------------------	
	IF @CreateSetp = 0
	BEGIN
		PRINT 'Create setup'
		-- Org1
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org1',@lang,@LogonName),(case when @lang='A' then N'الادارة 1' ELSE N'Organization 1'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح '  ELSE N' Not Valid'  end))
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
		     			FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg1 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg1,'''') <> '''' 	AND Organization.Organization IS null '	
						PRINT @str2
		EXECUTE(@str2)
		-- Org2
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org2',@lang,@LogonName),(case when @lang='A' then N'الادارة 2' ELSE N'Organization 2'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg2 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg2,'''') <> '''' 	AND Organization.Organization IS null '	
						PRINT @str2
		EXECUTE(@str2)
		-- Org3
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org3',@lang,@LogonName),(case when @lang='A' then N'الادارة 3' ELSE N'Organization 3'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح '  ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg3 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons collate database_default' ELSE 'Organization.OrganizationName collate database_default'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg3,'''') <> '''' 	AND Organization.Organization IS null '	
		EXECUTE(@str2)
		-- Org4
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org4',@lang,@LogonName),(case when @lang='A' then N'الادارة 4' ELSE N'Organization 4'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg4 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg4,'''') <> '''' 	AND Organization.Organization IS null '	
		EXECUTE(@str2)
		-- Org5
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org5',@lang,@LogonName),(case when @lang='A' then N'الادارة 5' ELSE N'Organization 5'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg5 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg5,'''') <> '''' 	AND Organization.Organization IS null '	
		EXECUTE(@str2)
		-- Org6
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org6',@lang,@LogonName),(case when @lang='A' then N'الادارة 6' ELSE N'Organization 6'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg6 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg6,'''') <> '''' 	AND Organization.Organization IS null '	
		EXECUTE(@str2)
		-- Org7
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org7',@lang,@LogonName),(case when @lang='A' then N'الادارة 7' ELSE N'Organization 7'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg7 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg7,'''') <> '''' 	AND Organization.Organization IS null '	
		EXECUTE(@str2)

		-- Nationality
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CNationId',@lang,@LogonName),(case when @lang='A' then N'الجنسية 7' ELSE N'Nationality 7'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Nations ON temptable.CNationId  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Nations.NationANameCons collate database_default' ELSE  'Nations.NationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Nations.NationNameCons' ELSE  'Nations.NationName' END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CNationId,'''') <> '''' 	AND Nations.NationId IS null '	
		EXECUTE(@str2)

		--Job
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CJob',@lang,@LogonName),(case when @lang='A' then N'الوظيفة' ELSE N'Job'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Jobs ON temptable.CJob collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Jobs.JobANameCons collate database_default' ELSE 'Jobs.JobAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Jobs.JobNameCons' ELSE 'Jobs.JobName' END  END)+'
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CJob,'''') <> '''' 	AND Jobs.Job IS null '	
		EXECUTE(@str2)
		--Grade
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CGrade',@lang,@LogonName),(case when @lang='A' then N'الدرجة' ELSE N'Grade'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON temptable.CGrade collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Grades.GradeANameCons collate database_default' ELSE 'Grades.GradeAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Grades.GradeNameCons' ELSE 'Grades.GradeName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CGrade,'''') <> '''' 	AND Grades.Grade IS null '	
		EXECUTE(@str2)
		
		-- SSGroup
		--SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','SSGroup',@lang),(case when @lang='A' then N'مجموعة الخدمة الذاتية' ELSE N'Self Service Group'  end))                          
		--			  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		--SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
		--				FROM '+@tablename+' temptable
		--				left JOIN SSGroup ON temptable.CSSGroup collate database_default = '+(case when @lang='A' then 'SSGroupAName collate database_default' ELSE 'SSGroupName collate database_default'  end)+' 
		--				where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
		--				+ ' end and isnull(temptable.CSSGroup,'''') <> '''' 	AND SSGroup.SSGroup IS null '	
		--EXECUTE(@str2)

		-- time rule 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CTimeRule',@lang,@LogonName),(case when @lang='A' then N'قانون الوقت' ELSE N'Time Rule'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN TimeRules ON temptable.CTimeRule collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'TimeRules.TRuleADescCons collate database_default' ELSE 'TimeRules.TRuleADesc collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'TimeRules.TRuleDescCons' ELSE 'TimeRules.TRuleDesc'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CTimeRule,'''') <> '''' 	AND TimeRules.TimeRule IS null '	
		EXECUTE(@str2)
		PRINT @str2

		-- HRStatus
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CSocStatus',@lang,@LogonName),(case when @lang='A' then N'الحالة الاجتماعية' ELSE N'Social Status'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN HRStatus ON temptable.CHrScStatus collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'HrStatus.HrStatusANameCons collate database_default' ELSE 'HrStatus.HrStatusAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'HrStatus.HrStatusNameCons collate database_default' ELSE 'HrStatus.HrStatusName collate database_default'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CHrScStatus,'''') <> '''' 	AND HrStatus.HrStatus IS null '	
		EXECUTE(@str2)
		PRINT @str2

		--App Source 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CApplicationSource',@lang,@LogonName),(case when @lang='A' then N'مصدر الاستمارة' ELSE N'Application Source'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ApplicationSource ON temptable.CApplicationSource collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ApplicationSource.ApplicationSourceANameCons collate database_default' ELSE 'ApplicationSource.ApplicationSourceAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ApplicationSource.ApplicationSourceNameCons collate database_default' ELSE 'ApplicationSource.ApplicationSourceName collate database_default'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CApplicationSource,'''') <> '''' 	AND ApplicationSource.ApplicationSource IS null '	
						PRINT '1'
		EXECUTE(@str2)
		--PRINT '2'
		--PRINT @str2
		--Rec Activities 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CRecruitmentActivity',@lang,@LogonName),(case when @lang='A' then N'نشاط التعيين' ELSE N'Recruitment Activity'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN RecruitmentActivities ON temptable.CRecruitmentActivity  collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'RecruitmentActivities.RecruitmentActivityANameCons collate database_default' ELSE 'RecruitmentActivities.RecruitmentActivityAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'RecruitmentActivities.RecruitmentActivityNameCons' ELSE 'RecruitmentActivities.RecruitmentActivityName'  END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CRecruitmentActivity,'''') <> '''' 	AND RecruitmentActivities.RecruitmentActivity IS null '	
		EXECUTE(@str2)
		--PRINT @str2

		--Position
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CPositionNo',@lang,@LogonName),(case when @lang='A' then N'المركز' ELSE N'Position'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Positions ON temptable.CPositionNo collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Positions.PositionNoANameCons collate database_default' ELSE 'Positions.PositionAName collate database_default' END
						ELSE CASE when @Consolidation = 1 THEN 'Positions.PositionNoNameCons' ELSE 'Positions.PositionName'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CPositionNo,'''') <> '''' 	AND Positions.PositionNo IS null '	
		EXECUTE(@str2)
		-- Location
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CLocationNo',@lang,@LogonName),(case when @lang='A' then N'الموقع' ELSE N'Location'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح '  ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Location ON temptable.CLocationNo collate database_default = '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'Location.LocationANameCons collate database_default' ELSE 'Location.LocationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Location.LocationNameCons collate database_default' ELSE 'Location.LocationName collate database_default'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CLocationNo,'''') <> '''' 	AND Location.LocationNo IS null '	
		EXECUTE(@str2)

		-- VacPac
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','VacPacK',@lang,@LogonName),(case when @lang='A' then N'قاعدة أجازات' ELSE N'Vacation Package'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN vacpack ON temptable.CVacPack  collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'VacPack.VacPackANameCons collate database_default' ELSE 'VacPack.vacpackAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'VacPack.VacPackNameCons collate database_default' ELSE 'VacPack.vacpackName collate database_default'  END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CVacPack,'''') <> '''' 	AND vacpack.vacpack IS null '	
		EXECUTE(@str2)
		--PRINT @str2

		-- Currency
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','HrCurrency',@lang,@LogonName),(case when @lang='A' then N'العملة' ELSE N'Currency'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Currency ON temptable.CHrCurrency collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'Currency.CurANameCons collate database_default' ELSE 'Currency.CurAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'Currency.CurNameCons' ELSE 'Currency.CurName' END END )+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CHrCurrency,'''') <> '''' 	AND Currency.Cur IS null '	
		EXECUTE(@str2)

		-- Contract Type 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CContractType',@lang,@LogonName),(case when @lang='A' then N'نوع العقد' ELSE N'Contract Type'  end))                          
					  +' '+ isnull(dbo.Hits_GetDCCaptionWzLogon('Common','NotValid',@lang,@LogonName),(case when @lang='A' then N'غير صحيح ' ELSE N' Not Valid'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ContractType ON temptable.CContractType  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ContractType.ContractANameCons collate database_default' ELSE 'ContractType.ContractAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ContractType.ContractNameCons' ELSE 'ContractType.ContractName' END END)+' 
						where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CContractType,'''') <> '''' 	AND ContractType.ContractType IS null '	
		EXECUTE(@str2)




			---------------------------------------add validation for organizations --------------------------------------------------------------

 
	if	@EnableOrgSetup =1 and @userOrganization <> ''
	begin
	-- Org1


		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org1Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 1' 
		ELSE N'Check Org. Validation for Organization 1'  end))  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
		     			FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg1 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg1,'''') <> '''' 	 '	
						PRINT 'da applicants'
						PRINT @str2
		EXECUTE(@str2)
		-- Org2
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org2Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 2'   
		ELSE N'Check Org. Validation for Organization 2'  end)) 

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg2 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg2,'''') <> '''' 	 '	
						PRINT @str2
		EXECUTE(@str2)
		-- Org3
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org3Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 3' 
		ELSE N'Check Org. Validation for Organization 3'  end))       

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg3 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons collate database_default' ELSE 'Organization.OrganizationName collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%''))  
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg3,'''') <> '''' 	 '	
		EXECUTE(@str2)
		-- Org4
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org4Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 4'  
		ELSE N'Check Org. Validation for Organization 4'  end))                          
					

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg4 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg4,'''') <> '''' 	 '	
		EXECUTE(@str2)
		-- Org5
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org5Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 5'  
		ELSE N'Check Org. Validation for Organization 5'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg5 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg5,'''') <> '''' 	 '	
		EXECUTE(@str2)
		-- Org6
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org6Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 6' 
		ELSE N'Check Org. Validation for Organization 6'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg6 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg6,'''') <> '''' 	 '	
		EXECUTE(@str2)
		-- Org7
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org7Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 7' 
		ELSE N'Check Org. Validation for Organization 7'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg7 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg7,'''') <> '''' 	 '	
		EXECUTE(@str2)

		-- Nationality
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','NationalityOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذاالجنسية'
		ELSE N'Check Org. Validation for this Nationality'  end))                          

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Nations ON temptable.CNationId  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Nations.NationANameCons collate database_default' ELSE  'Nations.NationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Nations.NationNameCons' ELSE  'Nations.NationName' END END)+' 
						where  ( not exists ( select * from #OrgTree where Nations.NationsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Nations.NationsOrgs ='''' )) and
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CNationId,'''') <> '''' 	 '	
		EXECUTE(@str2)

		--Job
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','JobOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذةالوظيفة'
		ELSE N'Check Org. Validation for Job'  end))                          
			  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Jobs ON temptable.CJob collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Jobs.JobANameCons collate database_default' ELSE 'Jobs.JobAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Jobs.JobNameCons' ELSE 'Jobs.JobName' END  END)+'
						where ( not exists ( select * from #OrgTree where Jobs.JobsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Jobs.JobsOrgs ='''' )) and 
						  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CJob,'''') <> '''' 	 '	
		EXECUTE(@str2)
		--Grade
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','GradeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة الدرجة' 
		ELSE N'Check Org. Validation for this Grade'  end))                          
					  

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON temptable.CGrade collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Grades.GradeANameCons collate database_default' ELSE 'Grades.GradeAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Grades.GradeNameCons' ELSE 'Grades.GradeName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Grades.GradesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Grades.GradesOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CGrade,'''') <> '''' 	  '	
		EXECUTE(@str2)
		
	
		-- time rule 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','TimeRuleOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لقاعدة حساب الوقت' 
		ELSE N'Check Org. Validation for Time keeping Rule'  end))                          
					  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN TimeRules ON temptable.CTimeRule collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'TimeRules.TRuleADescCons collate database_default' ELSE 'TimeRules.TRuleADesc collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'TimeRules.TRuleDescCons' ELSE 'TimeRules.TRuleDesc'  END END)+' 
						where  ( not exists ( select * from #OrgTree where TimeRules.TimeRulesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TimeRules.TimeRulesOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CTimeRule,'''') <> '''' 	 '	
		EXECUTE(@str2)
		PRINT @str2

		-- HRStatus
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','HRStatusOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لحالة التعيين' 
		ELSE N'Check Org. Validation for HR Status'  end))                          
					  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN HRStatus ON temptable.CHrScStatus collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'HrStatus.HrStatusANameCons collate database_default' ELSE 'HrStatus.HrStatusAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'HrStatus.HrStatusNameCons collate database_default' ELSE 'HrStatus.HrStatusName collate database_default'  END END)+' 
						where ( not exists ( select * from #OrgTree where HRStatus.HrStatusOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or HRStatus.HrStatusOrgs ='''' )) and  
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CHrScStatus,'''') <> '''' 	 '	
		EXECUTE(@str2)
		PRINT @str2

		--App Source 
		    
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ApplicationSourceOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمصدر الاستمارة' 
		ELSE N'Check Org. Validation for Application Source'  end))   

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ApplicationSource ON temptable.CApplicationSource collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ApplicationSource.ApplicationSourceANameCons collate database_default' ELSE 'ApplicationSource.ApplicationSourceAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ApplicationSource.ApplicationSourceNameCons collate database_default' ELSE 'ApplicationSource.ApplicationSourceName collate database_default'  END END )+' 
						where ( not exists ( select * from #OrgTree where ApplicationSource.ApplicationSourceOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or ApplicationSource.ApplicationSourceOrgs ='''' )) and  
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CApplicationSource,'''') <> '''' 	 '	
						PRINT '1'
		EXECUTE(@str2)
		--PRINT '2'
		--PRINT @str2
		--Rec Activities 
		       
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','RecruitmentActivityOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لنشاط التعيين' 
		ELSE N'Check Org. Validation for Recruitment Activity'  end)) 

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN RecruitmentActivities ON temptable.CRecruitmentActivity  collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'RecruitmentActivities.RecruitmentActivityANameCons collate database_default' ELSE 'RecruitmentActivities.RecruitmentActivityAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'RecruitmentActivities.RecruitmentActivityNameCons' ELSE 'RecruitmentActivities.RecruitmentActivityName'  END END )+' 
						where  ( not exists ( select * from #OrgTree where RecruitmentActivities.RecruitmentActivitiesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or RecruitmentActivities.RecruitmentActivitiesOrgs ='''' )) and  
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CRecruitmentActivity,'''') <> '''' 	 '	
		EXECUTE(@str2)
		--PRINT @str2

		--Position
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','PositionOrgs',@lang,@LogonName),(case when @lang='A' then N' برجاء التحقق من الهيكل الإداري لهذاالمركز' 
		ELSE N'Check Org. Validation for Position'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Positions ON temptable.CPositionNo collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Positions.PositionNoANameCons collate database_default' ELSE 'Positions.PositionAName collate database_default' END
						ELSE CASE when @Consolidation = 1 THEN 'Positions.PositionNoNameCons' ELSE 'Positions.PositionName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Positions.PositionsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Positions.PositionsOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CPositionNo,'''') <> '''' 	 '	
		EXECUTE(@str2)
		-- Location
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','LocationOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الموقع' 
		ELSE N'Check Org. Validation for Location'  end))                          
					  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Location ON temptable.CLocationNo collate database_default = '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'Location.LocationANameCons collate database_default' ELSE 'Location.LocationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Location.LocationNameCons collate database_default' ELSE 'Location.LocationName collate database_default'  END END)+' 
						where ( not exists ( select * from #OrgTree where Location.LocationOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Location.LocationOrgs ='''' )) and 
		               	temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CLocationNo,'''') <> '''' 	'	
		EXECUTE(@str2)

		-- VacPac
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','vacpackOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لطريقة حساب الأجازة'
		ELSE N'Check Org. Validation for Vacation Package'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN vacpack ON temptable.CVacPack  collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'VacPack.VacPackANameCons collate database_default' ELSE 'VacPack.vacpackAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'VacPack.VacPackNameCons collate database_default' ELSE 'VacPack.vacpackName collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where vacpack.VacPackOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or vacpack.VacPackOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CVacPack,'''') <> '''' 	 '	
		EXECUTE(@str2)
		--PRINT @str2

		-- Currency
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CurrencyOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة العملة'
		ELSE N'Check Org. Validation for this Currency'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Currency ON temptable.CHrCurrency collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'Currency.CurANameCons collate database_default' ELSE 'Currency.CurAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'Currency.CurNameCons' ELSE 'Currency.CurName' END END )+' 
						where ( not exists ( select * from #OrgTree where Currency.CurrencyOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Currency.CurrencyOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CHrCurrency,'''') <> '''' 	 '	
		EXECUTE(@str2)

		-- Contract Type 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ContractTypeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لنوع العقد' 
		ELSE N'Check Org. Validation for Contract Type'  end))              

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ContractType ON temptable.CContractType  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ContractType.ContractANameCons collate database_default' ELSE 'ContractType.ContractAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ContractType.ContractNameCons' ELSE 'ContractType.ContractName' END END)+' 
						where ( not exists ( select * from #OrgTree where ContractType.ContractTypeOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or ContractType.ContractTypeOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CContractType,'''') <> '''' 	 '	
		EXECUTE(@str2)
	end
		---------------------------------------end validation---------------------------------------------------------------------------		

	End 
	else
		begin
	-- Org1
		
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org1Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 1' 
		ELSE N'Check Org. Validation for Organization 1'  end))  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
		     			FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg1 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg1,'''') <> '''' 	AND Organization.Organization IS not null '	
						PRINT @str2
		EXECUTE(@str2)
		-- Org2
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org2Org',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 2'  
		ELSE N'Check Org. Validation for Organization 2'  end)) 

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg2 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg2,'''') <> '''' 	AND Organization.Organization IS not null '	
						PRINT @str2
		EXECUTE(@str2)
		-- Org3
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org3Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 3' 
		ELSE N'Check Org. Validation for Organization 3'  end))       

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg3 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons collate database_default' ELSE 'Organization.OrganizationName collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%''))  
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg3,'''') <> '''' 	AND Organization.Organization IS not null '	
		EXECUTE(@str2)
		-- Org4
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org4Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 4'  
		ELSE N'Check Org. Validation for Organization 4'  end))                          
					

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg4 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg4,'''') <> '''' 	AND Organization.Organization IS not null '	
		EXECUTE(@str2)
		-- Org5
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org5Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 5'  
		ELSE N'Check Org. Validation for Organization 5'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg5 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg5,'''') <> '''' 	AND Organization.Organization IS not null '	
		EXECUTE(@str2)
		-- Org6
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org6Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 6' 
		ELSE N'Check Org. Validation for Organization 6'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg6 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg6,'''') <> '''' 	AND Organization.Organization IS not null '	
		EXECUTE(@str2)
		-- Org7
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','Org7Orgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لالادارة 7' 
		ELSE N'Check Org. Validation for Organization 7'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Organization ON temptable.COrg7 collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Organization.OrganizationANameCons collate database_default' ELSE 'Organization.OrganizationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Organization.OrganizationNameCons' ELSE 'Organization.OrganizationName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Organization.Organization LIKE ''%''+ltrim(rtrim(VOrganization))+''%'')) 
						and  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.COrg7,'''') <> '''' 	AND Organization.Organization IS  not null '	
		EXECUTE(@str2)

		-- Nationality
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','NationalityOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذاالجنسية'
		ELSE N'Check Org. Validation for this Nationality'  end))                          

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Nations ON temptable.CNationId  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Nations.NationANameCons collate database_default' ELSE  'Nations.NationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Nations.NationNameCons' ELSE  'Nations.NationName' END END)+' 
						where  ( not exists ( select * from #OrgTree where Nations.NationsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Nations.NationsOrgs ='''' )) and
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CNationId,'''') <> '''' 	AND Nations.NationId IS not null '	
		EXECUTE(@str2)

		--Job
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','JobOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذةالوظيفة'
		ELSE N'Check Org. Validation for Job'  end))                          
			  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Jobs ON temptable.CJob collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Jobs.JobANameCons collate database_default' ELSE 'Jobs.JobAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Jobs.JobNameCons' ELSE 'Jobs.JobName' END  END)+'
						where ( not exists ( select * from #OrgTree where Jobs.JobsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Jobs.JobsOrgs ='''' )) and 
						  temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CJob,'''') <> '''' 	AND Jobs.Job IS not null '	
		EXECUTE(@str2)
		--Grade
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','GradeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة الدرجة' 
		ELSE N'Check Org. Validation for this Grade'  end))                          
					  

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Grades ON temptable.CGrade collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Grades.GradeANameCons collate database_default' ELSE 'Grades.GradeAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Grades.GradeNameCons' ELSE 'Grades.GradeName'  END END)+' 
						where ( not exists ( select * from #OrgTree where Grades.GradesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Grades.GradesOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CGrade,'''') <> '''' 	AND Grades.Grade IS not null '	
		EXECUTE(@str2)
		
	
		-- time rule 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','TimeRuleOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لقاعدة حساب الوقت' 
		ELSE N'Check Org. Validation for Time keeping Rule'  end))                          
					  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN TimeRules ON temptable.CTimeRule collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'TimeRules.TRuleADescCons collate database_default' ELSE 'TimeRules.TRuleADesc collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'TimeRules.TRuleDescCons' ELSE 'TimeRules.TRuleDesc'  END END)+' 
						where  ( not exists ( select * from #OrgTree where TimeRules.TimeRulesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TimeRules.TimeRulesOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CTimeRule,'''') <> '''' 	AND TimeRules.TimeRule IS not null '	
		EXECUTE(@str2)
		PRINT @str2

		-- HRStatus
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','HRStatusOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لحالة التعيين' 
		ELSE N'Check Org. Validation for HR Status'  end))                          
					  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN HRStatus ON temptable.CHrScStatus collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'HrStatus.HrStatusANameCons collate database_default' ELSE 'HrStatus.HrStatusAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'HrStatus.HrStatusNameCons collate database_default' ELSE 'HrStatus.HrStatusName collate database_default'  END END)+' 
						where ( not exists ( select * from #OrgTree where HRStatus.HrStatusOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or HRStatus.HrStatusOrgs ='''' )) and  
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CHrScStatus,'''') <> '''' 	AND HrStatus.HrStatus IS not null '	
		EXECUTE(@str2)
		PRINT @str2

		--App Source 
	SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ApplicationSourceOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لمصدر الاستمارة' 
		ELSE N'Check Org. Validation for Application Source'  end))   
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ApplicationSource ON temptable.CApplicationSource collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ApplicationSource.ApplicationSourceANameCons collate database_default' ELSE 'ApplicationSource.ApplicationSourceAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ApplicationSource.ApplicationSourceNameCons collate database_default' ELSE 'ApplicationSource.ApplicationSourceName collate database_default'  END END )+' 
						where ( not exists ( select * from #OrgTree where ApplicationSource.ApplicationSourceOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or ApplicationSource.ApplicationSourceOrgs ='''' )) and  
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CApplicationSource,'''') <> '''' 	AND ApplicationSource.ApplicationSource IS not null '	
						PRINT '1'
		EXECUTE(@str2)
		--PRINT '2'
		--PRINT @str2
		--Rec Activities 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','RecruitmentActivityOrg',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لنشاط التعيين' 
		ELSE N'Check Org. Validation for Recruitment Activity'  end)) 

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN RecruitmentActivities ON temptable.CRecruitmentActivity  collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'RecruitmentActivities.RecruitmentActivityANameCons collate database_default' ELSE 'RecruitmentActivities.RecruitmentActivityAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'RecruitmentActivities.RecruitmentActivityNameCons' ELSE 'RecruitmentActivities.RecruitmentActivityName'  END END )+' 
						where ( not exists ( select * from #OrgTree where RecruitmentActivities.RecruitmentActivitiesOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or RecruitmentActivities.RecruitmentActivitiesOrgs ='''' )) and  
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CRecruitmentActivity,'''') <> '''' 	AND RecruitmentActivities.RecruitmentActivity IS not null '	
		EXECUTE(@str2)
		--PRINT @str2

		--Position
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','PositionOrgs',@lang,@LogonName),(case when @lang='A' then N' برجاء التحقق من الهيكل الإداري لهذاالمركز' 
		ELSE N'Check Org. Validation for Position'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Positions ON temptable.CPositionNo collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'Positions.PositionNoANameCons collate database_default' ELSE 'Positions.PositionAName collate database_default' END
						ELSE CASE when @Consolidation = 1 THEN 'Positions.PositionNoNameCons' ELSE 'Positions.PositionName'  END END)+' 
						where  ( not exists ( select * from #OrgTree where Positions.PositionsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Positions.PositionsOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CPositionNo,'''') <> '''' 	AND Positions.PositionNo IS not  null '	
		EXECUTE(@str2)
		-- Location
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','LocationOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذا الموقع' 
		ELSE N'Check Org. Validation for Location'  end))                          
					  
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Location ON temptable.CLocationNo collate database_default = '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'Location.LocationANameCons collate database_default' ELSE 'Location.LocationAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'Location.LocationNameCons collate database_default' ELSE 'Location.LocationName collate database_default'  END END)+' 
						where ( not exists ( select * from #OrgTree where Location.LocationOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Location.LocationOrgs ='''' )) and 
		               	temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CLocationNo,'''') <> '''' 	AND Location.LocationNo IS not null '	
		EXECUTE(@str2)

		-- VacPac
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','vacpackOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لطريقة حساب الأجازة'
		ELSE N'Check Org. Validation for Vacation Package'  end))                          
					 
		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN vacpack ON temptable.CVacPack  collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'VacPack.VacPackANameCons collate database_default' ELSE 'VacPack.vacpackAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'VacPack.VacPackNameCons collate database_default' ELSE 'VacPack.vacpackName collate database_default'  END END)+' 
						where  ( not exists ( select * from #OrgTree where vacpack.VacPackOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or vacpack.VacPackOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CVacPack,'''') <> '''' 	AND vacpack.vacpack IS not null '	
		EXECUTE(@str2)
		--PRINT @str2

		-- Currency
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','CurrencyOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لهذة العملة'
		ELSE N'Check Org. Validation for this Currency'  end))

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN Currency ON temptable.CHrCurrency collate database_default= '+(case when @lang='A' THEN CASE when @Consolidation = 1 THEN 'Currency.CurANameCons collate database_default' ELSE 'Currency.CurAName collate database_default' END  
						ELSE CASE when @Consolidation = 1 THEN 'Currency.CurNameCons' ELSE 'Currency.CurName' END END )+' 
						where ( not exists ( select * from #OrgTree where Currency.CurrencyOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or Currency.CurrencyOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CHrCurrency,'''') <> '''' 	AND Currency.Cur IS not null '	
		EXECUTE(@str2)

		-- Contract Type 
		SELECT @errormsg5= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants','ContractTypeOrgs',@lang,@LogonName),(case when @lang='A' then N'برجاء التحقق من الهيكل الإداري لنوع العقد' 
		ELSE N'Check Org. Validation for Contract Type'  end))              

		SELECT @str2='UPDATE '+@tablename+' set remarks=rtrim(ltrim(remarks) + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + ltrim(N'''+@errormsg5+'''))  , post=0  
						FROM '+@tablename+' temptable
						left JOIN ContractType ON temptable.CContractType  collate database_default= '+(case when @lang='A' then CASE when @Consolidation = 1 THEN 'ContractType.ContractANameCons collate database_default' ELSE 'ContractType.ContractAName collate database_default' END 
						ELSE CASE when @Consolidation = 1 THEN 'ContractType.ContractNameCons' ELSE 'ContractType.ContractName' END END)+' 
						where ( not exists ( select * from #OrgTree where ContractType.ContractTypeOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or ContractType.ContractTypeOrgs ='''' )) and 
						temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
						+ ' end and isnull(temptable.CContractType,'''') <> '''' 	AND ContractType.ContractType IS not null '	
		EXECUTE(@str2)
	end
	
		IF @EnableTextValidation = '1' BEGIN
		DECLARE @ContractInfo AS NVARCHAR(MAX)
		--SELECT @Address = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants', 'Address', @lang) , CASE @lang  WHEN 'A' THEN N'العنوان'  ELSE 'Address' END)
		--SELECT @Name = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants', 'Name', @lang) , CASE @lang  WHEN 'A' THEN  N'الإسم' ELSE 'Name' END)
		SELECT @PassportIssue = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants', 'ForPasFrm', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'مكان اصدار جواز السفر' ELSE 'Passport Issue Place' END)
		SELECT @ContractInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalApplicants', 'ContInfo', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'معلومات العقد' ELSE 'Contract information' END)

		----Validate Address
		--SELECT @Str = 'UPDATE ' + @tablename + '  SET post = 0, Remarks = LTRIM(RTRIM(Remarks)) + N'' ' + @Address + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalApplicants'', ''Address'', Address) = 0 and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		--EXEC(@Str)

		----Validate Name
		--SELECT @Str = 'UPDATE ' + @tablename + '  SET  post = 0, Remarks = LTRIM(RTRIM(Remarks))  + N'' ' + @Name + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
  --                     FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalApplicants'', ''Name'', Name) = 0  and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		--EXEC(@Str)

		--Validate PassportIssuePlace
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = CONVERT(NVARCHAR(256),LTRIM(RTRIM(Remarks))  +CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + N'' ' + @PassportIssue + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13))
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalApplicants'', ''ForPasFrm'', ForPasFrm) = 0 
					   and (Tmptbl.Post = 1 OR (Tmptbl.Post = 0 AND LTRIM(RTRIM(Tmptbl.Remarks)) <> N'''' ) )  
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)

		--Validate ContractInfo
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = CONVERT(NVARCHAR(256),LTRIM(RTRIM(Remarks))  + CASE WHEN  RTRIM(ltrim(remarks)) = '''' THEN '''' ELSE '' / '' END + N'' ' + @ContractInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13))
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalApplicants'', ''ContInfo'', ContInfo) = 0 
					   and Tmptbl.Post = 1   
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)
		
	END 
	
END 
----------------------------------------------------------------	


--DECLARE @errormsg0 AS NVARCHAR(250)
--SELECT @errormsg0= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalBenefitItems','InvalidRelativeName','e'),
--(case when 'e' =N'A' then N'اسم غير صحيح ' ELSE N'Invalid Relative Name'  end))
--SELECT @errormsg0

	
/*Remove benefit item section*/

--------------------------------------------ExportSalarySacleBenefits---------------------------------------------------------------
IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales_ar%' OR  LTRIM(RTRIM(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales%' 
BEGIN 
print 'Check On GradeName and grade no '
DECLARE @errormsgGrade AS NVARCHAR(max), @strSalScale AS NVARCHAR(max)
    SELECT @errormsgGrade= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_ExportBenefitSalaryScales','GradeNameError',@lang,@LogonName),(case when @lang='A' then N'الدرجة غير صالحة'  ELSE 'Not a Valid Grade'  end))  
	select @strSalScale='UPDATE '+@tablename+' set Remarks= rtrim(ltrim(N'''+@errormsgGrade+'''))   ,  Post =0
	FROM '+@tablename+' temptable
	left join  Grades on (CASE WHEN ''' + @lang + ''' = ''A''   then LTRIM(rtrim(Grades.GradeAName collate database_default))  else LTRIM(rtrim(Grades.GradeName collate database_default)) end )  = LTRIM(rtrim(temptable.Grade collate database_default))
	where (temptable.post=1) 
	     and (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end )
		  
		 and ((temptable.Grade =''''  or
		   (CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(Grades.GradeAname))  else LTRIM(rtrim(Grades.GradeName)) end )  is  null   )
			or temptable.GradeNo <> (select top 1 Grade from grades where temptable.Grade = CASE WHEN ''' + @lang + ''' = ''A''   then LTRIM(rtrim(Grades.GradeAName))  else LTRIM(rtrim(Grades.GradeName)) end  ))								 '	
	PRINT  'Grades Error ...'+@strSalScale
	EXECUTE(@strSalScale)	
---------------------------------------------------------------------------------------------------------------------------------------------------

END

IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails_ar%' OR  LTRIM(RTRIM(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails%' 
BEGIN 
print 'Check On GradeName and grade no '
DECLARE @errormsgGradedetails AS NVARCHAR(max), @strSalScaledetails AS NVARCHAR(max)
    SELECT @errormsgGradedetails= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_ExportSalaryScalesDetails','GradeNameError',@lang,@LogonName),(case when @lang='A' then N'الدرجة غير صالحة' ELSE 'Not a Valid Grade'  end))  
	select @strSalScaledetails='UPDATE '+@tablename+' set Remarks= rtrim(ltrim(N'''+@errormsgGradedetails+'''))  ,  Post =0
	FROM '+@tablename+' temptable
	left join  Grades on (CASE WHEN ''' + @lang + ''' = ''A''   then LTRIM(rtrim(Grades.GradeAName collate database_default))  else LTRIM(rtrim(Grades.GradeName collate database_default)) end )  = LTRIM(rtrim(temptable.Grade collate database_default))
	where (temptable.post=1)
	     and (temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) + ' end)
		 and ((temptable.Grade =''''  or
		 (CASE WHEN ''' + @lang + '''  = ''A''   then LTRIM(rtrim(Grades.GradeAname))  else LTRIM(rtrim(Grades.GradeName)) end )  is  null   )
			or temptable.GradeNo <> (select top 1 Grade from grades where temptable.Grade = CASE WHEN ''' + @lang + ''' = ''A''   then LTRIM(rtrim(Grades.GradeAName))  else LTRIM(rtrim(Grades.GradeName)) end  ))								 '	
	PRINT  'Grades Error ...'+@strSalScaledetails
	EXECUTE(@strSalScaledetails)	

END

-------------------------------------------------------------------------------------------------------------------------------------------------

IF ltrim(rtrim(@tabletype)) ='WP_GetExternalEmpShift' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalEmpShift_ar'
BEGIN
DECLARE @errormsgShiftName AS NVARCHAR(256)
DECLARE @errormsgShiftDate AS NVARCHAR(256)
DECLARE @errormsgDatevalidate AS NVARCHAR(256)
DECLARE @errormsgRolevalidate AS NVARCHAR(256)
DECLARE @ShiftRoles AS NVARCHAR(MAX)

SELECT @DateFormat= dateformat FROM SysParam 
  IF @DateFormat=1 SET @DateFormat=103
  IF @DateFormat=2 SET @DateFormat=101
  IF @DateFormat=0 SET @DateFormat=111

SELECT @errormsgShiftName= LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpShift','ShiftNameErorr',@lang,@LogonName),
(case when @lang=N'A' then N'قم بإدخل إسم الوردية صحيح' ELSE N'Enter Valid Shift Name '  end))))
 select @str='UPDATE '+@tablename+' set post= 0 , remarks= ltrim(rtrim(remarks)) + N'' ' +@errormsgShiftName+' ''
 FROM '+@tablename+' temptable
 inner JOIN EmpAssignment ON temptable.empid collate database_default=Empassignment.EmployeeId collate database_default
 LEFT JOIN TimeShifts on ltrim(rtrim(temptable.ShiftName collate database_default))= case when '''+@lang+'''= ''e'' then  
 ltrim(rtrim(TimeShifts.ShiftName collate database_default)) else ltrim(rtrim(TimeShifts.ShiftAName collate database_default)) end
 WHERE  TimeShifts.shiftno IS null and ltrim(rtrim(temptable.ShiftName collate database_default)) <>'''''

-- --print @str
 EXECUTE(@str)

 SELECT @errormsgShiftDate= isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpShift','ShiftDateErorr',@lang,@LogonName),
(case when @lang=N'A' then N' قم بإدخال التاريخ بشكل صحيح ' ELSE N'Enter Valid Date Format '  end))
SET  @str='UPDATE '+@tablename+' set post=0, remarks=cast(  N'' ' + rtrim(ltrim(@errormsgShiftDate)) +' '' as nchar(250))  where (isdate(CONVERT(DATETIME ,ShiftDate,'+str(@DateFormat)+'))=0 or ShiftDate is null) '

 --print @str
 EXECUTE(@str)

IF (SELECT SysParam.EnableDateValidation FROM dbo.SysParam) = 1
BEGIN
 SELECT @errormsgDatevalidate= LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpShift','ShiftDatevalidate',@lang,@LogonName),
(case when @lang=N'A' then N'هذه الوردية غير فعالة' ELSE N'This shift isn''t valid '  end))))
 select @str='UPDATE '+@tablename+' set post= 0 , remarks= ltrim(rtrim(remarks)) + N'' ' +@errormsgDatevalidate+' ''
 FROM '+@tablename+' temptable
 inner JOIN EmpAssignment ON temptable.empid collate database_default=Empassignment.EmployeeId collate database_default
 LEFT JOIN TimeShifts on ltrim(rtrim(temptable.ShiftName collate database_default))= case when '''+@lang+'''= ''e'' then  
 ltrim(rtrim(TimeShifts.ShiftName collate database_default)) else ltrim(rtrim(TimeShifts.ShiftAName collate database_default)) end
 WHERE  convert(nchar(10),temptable.ShiftDate,111) not between isnull(TimeShifts.TimeShiftFromDate,  convert(nchar(10),temptable.ShiftDate,111)) and isnull(TimeShifts.TimeShiftToDate, convert(nchar(10),temptable.ShiftDate,111)) '
 --print @str
 EXECUTE(@str)
 END 

IF EXISTS( SELECT * FROM NasUsers CROSS JOIN SysParam WHERE LogonName=@LogonName AND NasUsers.ApplySSGroups = 1 AND SysParam.EnableRoleValidation = 1)
BEGIN 
 SELECT @ShiftRoles=dbo.ReportRoles(0,'TimeShifts.TimeShiftsRoles',EmpId ) FROM dbo.NasUsers WHERE LogonName=@LogonName

 SELECT @errormsgRolevalidate= LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpShift','ShifRolevalidate',@lang,@LogonName),
(case when @lang=N'A' then N'التحقق من القائميين بالمهام' ELSE N'Check Role Validate for this shift '  end))))
 select @str='UPDATE '+@tablename+' set post= 0 , remarks= ltrim(rtrim(remarks)) + N'' ' +@errormsgRolevalidate+' ''
 FROM '+@tablename+' temptable
 inner JOIN EmpAssignment ON temptable.empid collate database_default=Empassignment.EmployeeId collate database_default
 LEFT JOIN TimeShifts on ltrim(rtrim(temptable.ShiftName collate database_default))= case when '''+@lang+'''= ''e'' then  
 ltrim(rtrim(TimeShifts.ShiftName collate database_default)) else ltrim(rtrim(TimeShifts.ShiftAName collate database_default)) end
 WHERE '+@ShiftRoles
 --print @str
 EXECUTE(@str)
 END

IF @enableOrgSetup=1 AND @userOrganization <>''
BEGIN 
	 select @str='UPDATE '+@tablename+' set post= 0 , remarks= ltrim(rtrim(remarks)) + '' ''+N'''+ LTRIM(RTRIM(ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpShift','ShiftOrgvalidate',@lang,@LogonName),(case when @lang=N'A' then N'التحقق من الهيكل التنظيمي ' ELSE N'Check Org. Validate for this shift '  end))))+'''
	 FROM '+@tablename+' temptable
	 LEFT JOIN TimeShifts on ltrim(rtrim(temptable.ShiftName collate database_default))= case when '''+@lang+'''= ''e'' then ltrim(rtrim(TimeShifts.ShiftName collate database_default)) else ltrim(rtrim(TimeShifts.ShiftAName collate database_default)) end
	 WHERE temptable.Post=1  and   not exists ( select * from #OrgTree where TimeShifts.TimeShiftsOrgs LIKE ''%#''+ltrim(rtrim(VOrganization))+''#%'' or TimeShifts.TimeShiftsOrgs ='''' )and temptable.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'=0 then temptable.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '
	 EXECUTE(@str)
END  
   
	
END
------------------------------------------------------------------------------------------------------------------------------------
IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPaycodes%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPaycodes_ar%'
BEGIN	
DECLARE @paycodes nvarchar(max), @roles NVARCHAR(max)='',@DateWhere AS NVARCHAR(max)

IF (SELECT EnableDateValidation FROM dbo.SysParam) = 1
BEGIN
SET @DateWhere = N' AND CONVERT(nchar(10),GETDATE(),111)  
BETWEEN isnull(PaycodeFromDate, convert(nchar(10),GETDATE(),111))AND isnull(PaycodeToDate, CONVERT(nchar(10),GETDATE(),111)) '
END
ELSE 
BEGIN
SET @DateWhere = ''
END

IF EXISTS( SELECT * FROM NasUsers CROSS JOIN SysParam WHERE LogonName=@LogonName AND NasUsers.ApplySSGroups = 1 AND SysParam.EnableRoleValidation = 1)
BEGIN 
	SELECT @roles=dbo.ReportRoles(0,'Paycodes',EmpId ) FROM dbo.NasUsers WHERE LogonName=@LogonName
END
ELSE 
BEGIN 
	SET @roles = ''
END 


CREATE TABLE paycoderoletemp(paycodesroles int)

DECLARE @insert AS NVARCHAR(max)
DECLARE @exist AS NVARCHAR(max)
DECLARE @code AS INT=0

SELECT @insert='INSERT INTO paycoderoletemp
              select code from paycode where (Code=100 OR TYPE NOT IN(3)) ' + @roles + @DateWhere
              PRINT (@insert)
              EXECUTE (@insert)
DECLARE paycoderolecursor CURSOR FOR  
SELECT code 
FROM Paycode WHERE code NOT IN (select paycodesroles from paycoderoletemp)
OPEN paycoderolecursor   
FETCH NEXT FROM paycoderolecursor INTO @code 
WHILE @@FETCH_STATUS = 0   
BEGIN   
SET @exist='


  IF EXISTS(SELECT *
FROM '+ PARSENAME(@tablename,3)+'.information_schema.columns c
WHERE table_name ='''+ PARSENAME(@tablename,1) +''' AND c.COLUMN_NAME=''P'+CAST(@code AS NVARCHAR(max))+''' )
BEGIN

alter table '+@tablename+' drop column   P'+ CAST(@code AS NVARCHAR(max))+' 
END
ELSE
BEGIN
PRINT ''' +CAST(@code AS NVARCHAR(max))+'  not exists'''+CHAR(10)+CHAR(13)+'
end'

EXEC (@exist)

FETCH NEXT FROM paycoderolecursor INTO @code  
end
CLOSE paycoderolecursor 
DEALLOCATE paycoderolecursor 
 DROP TABLE paycoderoletemp

 END 
---------------------------------------------------------------------------------------------------------------------------------------
IF LTRIM(RTRIM(@tabletype)) like 'WP_GetExternalDataFile%' 
BEGIN
	DECLARE @index AS SMALLINT 

	IF EXISTS(SELECT * FROM Nasoptions WHERE ItemNo=20584 AND (CHARINDEX('pagename=AssigningShifts',Itemprog)>0 OR CHARINDEX('pagename=EmpGroups',Itemprog)>0  or CHARINDEX('pagename=UDF',Itemprog)>0 OR   CHARINDEX('pagename=Installments',Itemprog)>0) )
	BEGIN	
	    SELECT @index= CHARINDEX('pagename=EmpGroups',Itemprog) FROM Nasoptions WHERE ItemNo=20584 

		IF @index=0
		BEGIN
			  SELECT @index= CHARINDEX('pagename=UDF',Itemprog) FROM Nasoptions WHERE ItemNo=20584 
		END

		SELECT  @empid=empid , @ApplySSGroups =ApplySSGroups , @PrivacyLevelFrom=PrivacyLevelFrom,@PrivacyLevelTo=PrivacyLevelTo
		FROM nasusers WHERE @logonname=logonname 

		IF @index>0
		BEGIN
			select @str='UPDATE '+@tablename+' set f002='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
			FROM '+@tablename+' temptable
			inner JOIN EmpAssignment ON temptable.f001 collate database_default=empassignment.EmployeeId collate database_default
			left join profile on profile.profileid=empassignment.empid 
			where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
			+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END
				EXEC(@str)
		END 
	
		SELECT @str='UPDATE '+@tablename+' set post= 1
		FROM '+@tablename+' temptable where post is null'
		EXECUTE(@str)
	 		
		

		SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang,@LogonName),(case when @lang='A' then N'موظف غير مسموح به' ELSE N'Not a valid employee'  end))                          
		
		SELECT @str='UPDATE '+@tablename+' set remarks= N'''' FROM '+@tablename+' temptable'
		EXECUTE(@str)
		

		IF EXISTS (SELECT * FROM NasOptions WHERE NasOptions.ItemNo = 20584 AND CHARINDEX('pagename=Installments',Itemprog)>0) ----->> For Installments
		BEGIN
			select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0 
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.f003=empassignment.EmployeeId 
			and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
			+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	        + CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
				'WHERE EmpAssignment.empid IS null and Row_Number > 1'
		END
		ELSE --->> Normal cases
		BEGIN
			select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0 
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.f001=empassignment.EmployeeId 
			and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
			+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	       + CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
		'WHERE EmpAssignment.empid IS null and Row_Number > 1'
		END

		PRINT @str
		EXECUTE(@str)
		
		--------------------------------------------------Not an active employee
	     SET @errormsg = ''
		 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang,@LogonName),(case when @lang='A' then N'حالة الموظف لا يعمل' ELSE N'Not an active employee'  end))
		 
		                            
		IF EXISTS (SELECT * FROM NasOptions WHERE NasOptions.ItemNo = 20584 AND CHARINDEX('pagename=Installments',Itemprog)>0) ----->> For Installments
		BEGIN
			select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.f003=empassignment.EmployeeId 
			and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
			+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
			'WHERE EmpAssignment.status <> 1 and ltrim(rtrim(temptable.remarks))= N'''' and Row_Number > 1 '
		END
		ELSE --->> Normal cases
        BEGIN
			select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.f001=empassignment.EmployeeId 
			and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
			+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
				'WHERE EmpAssignment.status <> 1 and ltrim(rtrim(temptable.remarks))= N'''' and Row_Number > 1 '
        END

		PRINT @str
		EXECUTE(@str)
	--sELECT @index= CHARINDEX('pagename=UDF',Itemprog) FROM Nasoptions WHERE ItemNo=20584 
	--IF @index>0
	--BEGIN
	--	DECLARE @count AS SMALLINT=0,@postindex AS NVARCHAR(4) ,@remarksindex AS NVARCHAR(4),@SelectStr AS NVARCHAR(254)='',@Statement AS NVARCHAR(max)=''
	--	WHILE @count <150
	--	 BEGIN
	--	 	     SELECT @count=@count+1
	--	 	     PRINT '@count='+REPLACE(STR(@count,3),' ','0')
	--	 	     SET @Statement='Select top 1 @SelectHeader =  F'+REPLACE(STR(@count,3),' ','0') +' FROM '+@tablename 
	--             EXEC sp_executesql @Statement , N' @SelectHeader varchar(max) OUTPUT',  @SelectHeader = @SelectStr  OUT 
	             
	--             PRINT @SelectStr
	--             IF isnull(@SelectStr,'')='' 
	--             BEGIN
	             
	--             select @remarksindex=REPLACE(STR(@count-2,3),' ','0'),@postindex=REPLACE(STR(@count-1,3),' ','0')
	--            break
	--             END 
	--	 END
	--	 PRINT @remarksindex
	--	 PRINT @postindex
	--	 EXEC('update '+@tablename+' set F'+@remarksindex+' =isnull(F'+@remarksindex+','''')+'' ''+ isnull(Remarks,'''') where isnull(Remarks ,'''')<>''''')
	--	 EXEC('update '+@tablename+' set F'+@postindex+' =Post where  F'+@postindex+' =''1''')
	--END
	
	
	END

	------------------Appraisal Competencies---------------------------------
	
	DECLARE  @Program as NVARCHAR(10),@Parameters AS NVARCHAR(max)=''
	SELECT @Parameters =SUBSTRING(@tabletype,CHARINDEX('?',@tabletype)+1,LEN(@tabletype))
	PRINT @Parameters

	SELECT @Parameters =SUBSTRING(@Parameters,CHARINDEX(',',@Parameters)+1 ,LEN(@Parameters))
	SELECT @Parameters =SUBSTRING(@Parameters,CHARINDEX(',',@Parameters)+1 ,LEN(@Parameters))
		SELECT @Parameters =SUBSTRING(@Parameters,CHARINDEX(',',@Parameters)+1 ,LEN(@Parameters))
	SELECT @Parameters =SUBSTRING(@Parameters,CHARINDEX(',',@Parameters)+1 ,LEN(@Parameters))
	set @Program = substring(@Parameters,0,CHARINDEX(',',@Parameters))

	IF EXISTS (SELECT * FROM GetExtDataFilePrograms WHERE ProgramId =@Program AND LTRIM(RTRIM(ProgramCode))='AppraisalComp')
	BEGIN
		 SET @errormsg = ''
		 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang,@LogonName),(case when @lang='A' then N'حالة الموظف غير صالحة' ELSE N'Not an active employee'  end))
		 
		 select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0
			FROM '+@tablename+' temptable
			left JOIN EmpAssignment ON temptable.f003=empassignment.EmployeeId 
			and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
			+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
			+ CASE WHEN @enableOrgSetup=1 AND @userOrganization <>'' THEN  ' and  empassignment.Organization in ('+@Orgs+' )' ELSE ' ' END+
			'WHERE EmpAssignment.status <> 1 and ltrim(rtrim(temptable.remarks))= N'''' and Row_Number > 1 '
			
			EXEC(@str)
			
	select @str='UPDATE '+@tablename+' set name='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
					FROM '+@tablename+' temptable
					inner JOIN EmpAssignment ON temptable.empid collate database_default=cast(empassignment.EmployeeId collate database_default AS nvarchar(255))
					left join profile on profile.profileid=empassignment.empid
					where temptable.Row_Number = case when ' + STR(@Paycode) + ' = 0 then temptable.Row_Number else ' + STR(@Paycode) 
					+ ' end '	
				EXEC(@str)
  
	END
	----------------------------------------------------------------------


	--IF EXISTS(SELECT * FROM Nasoptions WHERE ItemNo=20584 AND (CHARINDEX('pagename=GetExternalRoles',Itemprog)>0 ) )
	--BEGIN	
	--    --SELECT @index= CHARINDEX('pagename=GetExternalRoles',Itemprog) FROM Nasoptions WHERE ItemNo=20584 

		
	--	SELECT  @empid=empid , @ApplySSGroups =ApplySSGroups , @PrivacyLevelFrom=PrivacyLevelFrom,@PrivacyLevelTo=PrivacyLevelTo
	--	FROM nasusers WHERE @logonname=logonname 

	--	--IF @index>0
	--	--BEGIN
	--		select @str='UPDATE '+@tablename+' set f002='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
	--		FROM '+@tablename+' temptable
	--		inner JOIN EmpAssignment ON temptable.f001 collate database_default=empassignment.EmployeeId collate database_default
	--		left join profile on profile.profileid=empassignment.empid 
	--		where( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--		+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	

	--		EXEC(@str)
	--	--END 
	
	--	SELECT @str='UPDATE '+@tablename+' set post= 1
	--	FROM '+@tablename+' temptable where post is null'
	--	EXECUTE(@str)
	 		
		

	--	SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','errormsg',@lang),(case when @lang='A' then N'???? ??? ????? ??' ELSE N'Not a valid employee'  end))                          
		
	--	SELECT @str='UPDATE '+@tablename+' set remarks= N'''' FROM '+@tablename+' temptable'
	--	EXECUTE(@str)
				
	--		select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0 
	--		FROM '+@tablename+' temptable
	--		left JOIN EmpAssignment ON temptable.f001=empassignment.EmployeeId 
	--		and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--		+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	--		'WHERE EmpAssignment.empid IS null and Row_Number > 1'
		

	--	PRINT @str
	--	EXECUTE(@str)
		
	--	--------------------------------------------------Not an active employee
	--     SET @errormsg = ''
	--	 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('common','Inactive Employee',@lang),(case when @lang='A' then N'???? ?????? ?? ????' ELSE N'Not an active employee'  end))
		           
	--		select @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+''')) ,post=0
	--		FROM '+@tablename+' temptable
	--		left JOIN EmpAssignment ON temptable.f001=empassignment.EmployeeId 
	--		and( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	--		+ case when @ApplySSGroups=1  then ' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	+
	--		'WHERE EmpAssignment.status <> 1 and ltrim(rtrim(temptable.remarks))= N'''' and Row_Number > 1 '
    

	--	PRINT @str
	--	EXECUTE(@str)

	
	--END

END

IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalProfilePhone%'
BEGIN
	
	                            
		select @str='UPDATE '+@tablename+' set post= 1
	    FROM '+@tablename+' temptable where post is null '
	    EXECUTE(@str)
	   
	   SET @errormsg = ''
		 SELECT @errormsg= isnull(dbo.Hits_GetDCCaptionWzLogon('wp_getexternalphone','InactivePhoneNo',@lang,@LogonName),(case when @lang='A' then N'رقم التليفون غير موجود' ELSE N'Not a valid Phone NO.'  end)) 
	   select @str=N'UPDATE '+@tablename+N' set post= 0 ,remarks=N'''+LTRIM(RTRIM(@errormsg))+N'''
	    FROM '+@tablename+N' temptable 
	    left join ProfilePhones on ProfilePhones.phone=temptable.Phone
	    where ProfilePhones.Phone is null '
	    EXECUTE(@str) 
	    
END

IF ltrim(rtrim(@tabletype)) Like 'WP_GetExternalEmpSSGroupRoles%' OR ltrim(rtrim(@tabletype)) Like 'WP_GetExternalEmpSSGroupRoles_ar%'
BEGIN
	
	DECLARE  @RoleColumns AS NVARCHAR(MAX)=''
    DECLARE @RolesStmt AS NVARCHAR(max)=''
	DECLARE @ProfileNameOrId As BIT
    Declare @ProfileJoin as Nvarchar(max)=''
	Declare @SingleOrMultipleRoles as BIT

--------------------------------------------------------------------------------------------------------------------------------------------------------------
set @ProfileNameOrId = isnull((select ConfigValue from SysParamConfig where ConfigID='ProfileNameOrId'),0)
set @SingleOrMultipleRoles = isnull((select ConfigValue from SysParamConfig where ConfigID='SingleOrMultipleRoles'),0)

select @RolesStmt ='SELECT @RoleColumnsStr=@RoleColumnsStr +'',''+
Column_Name FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''EmpId'' , ''NAME'' , ''Post'' ,''Remarks'' ,''Row_Number'')'
      
EXECUTE sp_executesql @RolesStmt, N'@RoleColumnsStr NVARCHAR(max) OUT',  
                      @RoleColumnsStr  = @RoleColumns OUTPUT    
      
 SELECT @RoleColumns =SUBSTRING (@RoleColumns,2,LEN(@RoleColumns))

 CREATE TABLE #Temp ( Row_Number int ,Employeeid NVARCHAR(max) ,RoleId SMALLINT , ProfileCol NVARCHAR(88))
 	 if @ProfileNameOrId = 1 
	 begin
	 Alter table #Temp Alter Column ProfileCol NVARCHAR(50) 
	 end
 INSERT INTO #temp 
exec('SELECT Row_Number, EmpId, replace(RoleId,''R'','''') as RoleId, ProfileCol    
FROM   
   (SELECT * FROM '+@Tablename+') p  
UNPIVOT  
   (ProfileCol FOR RoleId IN   ('+@RoleColumns+')  
)AS unpvt  where profilecol <>'''' ')
If @ProfileNameOrId =0
 BEGIN
   set @ProfileJoin = N' left join Profile on case when '''+@lang +''' = ''e'' then  ltrim(rtrim(Profile.Name)) else ltrim(rtrim(Profile.AName)) end = ltrim(rtrim(#temp.ProfileCol)) '
 End
 ELSE If @ProfileNameOrId =1
 BEGIN
   set @ProfileJoin = N' left join EmpAssignment RoleEmpAssignment on ltrim(rtrim(RoleEmpAssignment.Employeeid)) = ltrim(rtrim(#temp.ProfileCol))
         left join Profile on Profile.ProfileId = RoleEmpAssignment.EmpId '
 End

Declare @Action as nvarchar(5)
SET @Action = ISNULL(SUBSTRING(@tabletype,CHARINDEX('?',@tabletype)+1,1),'0')

if @Action = '0' --insert errors
begin

SELECT @errormsg=isnull(dbo.Hits_GetDCCaption('WP_GetExternalEmpSSGroupRoles','DuplicateRecord',@lang),(CASE WHEN @lang = 'A' THEN  N'لا يمكن ادخال بيانات متكررة' ELSE 'Can not insert duplicate record' END) ) 
 EXEC (' update '+@tableName +' set Post=0 , Remarks =  remarks + '' - '' + rtrim(ltrim(N'''+@errormsg+'''))+char(13) 
         from '+@Tablename +'
         inner join #Temp on #Temp.Row_Number = '+@Tablename+'.Row_Number
		  left join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=ltrim(rtrim('+@tableName+'.Empid))'
         +@ProfileJoin+
         'left join SSGroupRoleRecords on SSGroupRoleRecords.SSGroup =EmpAssignment.SSGroup and SSGroupRoleRecords.RoleId =#Temp.RoleId and SSGroupRoleRecords.ProfileId=Profile.ProfileId
         and SSGroupRoleRecords.StartDate=CAST( GETDATE() AS DATE)
         where Post=1 and  SSGroupRoleRecords.SSgroup IS NOT NULL')
         

   SELECT @errormsg=isnull(dbo.Hits_GetDCCaption('WP_GetExternalEmpSSGroupRoles','ActiveRecord',@lang),(CASE WHEN @lang = 'A' THEN  N' لا يمكن ادخال هذا السجل , يوجد سجل حيوي بالفعل ' ELSE 'Cannot insert this record, there is already active record' END))

		  EXEC (' update '+@tableName +' set Post=0 , Remarks = remarks + '' - '' + rtrim(ltrim(N'''+@errormsg+'''))+char(13) 
         from '+@Tablename +'
         inner join #Temp on #Temp.Row_Number = '+@Tablename+'.Row_Number
		  left join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=ltrim(rtrim('+@tableName+'.Empid))'
         +@ProfileJoin+
         'left join SSGroupRoleRecords on SSGroupRoleRecords.SSGroup =EmpAssignment.SSGroup and SSGroupRoleRecords.RoleId =#Temp.RoleId and SSGroupRoleRecords.ProfileId=Profile.ProfileId
         AND (CAST( GETDATE() AS DATE)  BETWEEN dbo.SSGroupRoleRecords.StartDate AND ISNULL(SSGroupRoleRecords.EndDate,CAST( GETDATE() AS DATE)))
         where Post=1 and  SSGroupRoleRecords.SSgroup IS NOT NULL')
   
     if @ProfileNameOrId = 0
	 begin
   SELECT @errormsg=isnull(dbo.Hits_GetDCCaption('WP_GetExternalEmpSSGroupRoles','RoleDoesnotExist',@lang),(CASE WHEN @lang = 'A' THEN  N' اسم الدور غير موجود ' ELSE 'Role Name Does not exists' END))
	 end
	 else if @ProfileNameOrId = 1
	 begin
	    SELECT @errormsg=isnull(dbo.Hits_GetDCCaption('WP_GetExternalEmpSSGroupRoles','RoleDoesnotExist2',@lang),(CASE WHEN @lang = 'A' THEN  N' رقم موظف الدور غير موجود ' ELSE 'Role Employee Id Does not exists' END))
	 end
		  EXEC (' update '+@tableName +' set Post=0 , Remarks = remarks + '' - '' + rtrim(ltrim(N'''+@errormsg+'''))+char(13) 
         from '+@Tablename +'
         inner join #Temp on #Temp.Row_Number = '+@Tablename+'.Row_Number
		  left join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=ltrim(rtrim('+@tableName+'.Empid))'
         +@ProfileJoin+
         ' where Post=1 and  Profile.profileId IS  NULL')
 
         
 
If @SingleOrMultipleRoles = 1
Begin

CREATE TABLE #RoleCount (Employeeid NVARCHAR(MAX),RoleId Smallint,EmpCount int)

insert into #RoleCount
select Employeeid,RoleId,count(ProfileCol) from #Temp group by EmployeeId,RoleId having count(ProfileCol)>1

EXEC (' update '+ @tableName +' set Post=0 , 
Remarks = remarks + '' - '' + isnull(dbo.Hits_GetDCCaption(''WP_GetExternalEmpSSGroupRoles'',''SingleRoleMsgPart1'','''+@lang+'''),
(CASE WHEN '''+ @lang +'''= ''A'' THEN N''لا يمكن ادخال الدور :'' Else
''Can not insert Role :'' End)) + '' '' + CASE WHEN '''+@lang +'''=''A'' THEN SSRole.RoleAName ELSE SSRole.RoleName END
+'' ''+
+ isnull(dbo.Hits_GetDCCaption(''WP_GetExternalEmpSSGroupRoles'',''SingleRoleMsgPart2'','''+@lang+'''),
(CASE WHEN '''+ @lang +'''= ''A'' THEN N''لأكثر من لاعب دور على'' Else
''with multiple Role Players on'' END  )) +'' '' + ' +@tableName+'.Name

from '+ @tableName +' inner join #temp on '+ @tableName+'.Row_Number = #Temp.Row_Number and ' +@tableName+'.EmpId = #Temp.EmployeeId
inner join #RoleCount on #Temp.RoleId = #RoleCount.RoleId and #Temp.EmployeeId = #RoleCount.EmployeeId
left join SSRole on #RoleCount.RoleId = SSRole.RoleId
')

End


end

else if @Action = '1' --delete errors
begin
	
   SELECT @errormsg=isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpSSGroupRoles','DeleteRecord',@lang,@LogonName),(CASE WHEN @lang = 'A' THEN  N' لا يمكن مسح هذا السجل لا يوجد سجل له بالفعل ' ELSE 'Cannot delete this record, there is no record for it' END))

		  EXEC (' update '+@tableName +' set Post=0 , Remarks = rtrim(ltrim(N'''+@errormsg+'''))+char(13) 
         from '+@Tablename +'
         inner join #Temp on #Temp.Row_Number = '+@Tablename+'.Row_Number
         left join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=ltrim(rtrim('+@tableName+'.Empid))
         left join Profile on case when '''+@lang +''' = ''e'' then  ltrim(rtrim(Profile.Name)) else ltrim(rtrim(Profile.AName)) end = ltrim(rtrim(#temp.ProfileName))
         left join SSGroupRoleRecords on SSGroupRoleRecords.SSGroup =EmpAssignment.SSGroup and SSGroupRoleRecords.RoleId =#Temp.RoleId and SSGroupRoleRecords.ProfileId=Profile.ProfileId
         where Post=1 and  SSGroupRoleRecords.SSgroup IS NULL')
	
end

else if @Action = '2' --deactivate errors
begin

	   SELECT @errormsg=isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpSSGroupRoles','DeactivateRecord',@lang,@LogonName),(CASE WHEN @lang = 'A' THEN  N' لا يمكن الغاء هذا السجل لا يوجد سجل له بالفعل ' ELSE 'Cannot deactivate this record, there is no record for it' END))

		  EXEC (' update '+@tableName +' set Post=0 , Remarks = rtrim(ltrim(N'''+@errormsg+'''))+char(13) 
         from '+@Tablename +'
         inner join #Temp on #Temp.Row_Number = '+@Tablename+'.Row_Number
         left join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=ltrim(rtrim('+@tableName+'.Empid))
         left join Profile on case when '''+@lang +''' = ''e'' then  ltrim(rtrim(Profile.Name)) else ltrim(rtrim(Profile.AName)) end = ltrim(rtrim(#temp.ProfileName))
         left join SSGroupRoleRecords on SSGroupRoleRecords.SSGroup =EmpAssignment.SSGroup and SSGroupRoleRecords.RoleId =#Temp.RoleId and SSGroupRoleRecords.ProfileId=Profile.ProfileId and (SSGroupRoleRecords.EndDate is null  or SSGroupRoleRecords.EndDate >= cast(GETDATE() as date))
         where Post=1 and  SSGroupRoleRecords.SSgroup IS NULL')
	
end

   SELECT @errormsg=isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalEmpSSGroupRoles','RoleDoesnotExist',@lang,@LogonName),(CASE WHEN @lang = 'A' THEN  N' اسم الدور غير موجود ' ELSE 'Role Name Does not exists' END))

		  EXEC (' update '+@tableName +' set Post=0 , Remarks = rtrim(ltrim(N'''+@errormsg+'''))+char(13) 
         from '+@Tablename +'
         inner join #Temp on #Temp.Row_Number = '+@Tablename+'.Row_Number
         left join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=ltrim(rtrim('+@tableName+'.Empid))
         left join Profile on case when '''+@lang +''' = ''e'' then  ltrim(rtrim(Profile.Name)) else ltrim(rtrim(Profile.AName)) end = ltrim(rtrim(#temp.ProfileName))
         
         where Post=1 and  Profile.profileId IS NULL')
           
         
 
 DROP TABLE #temp 
 
	 
--			DECLARE @Cursor_RoleName AS NVARCHAR (60)
--			DECLARE @Cursor_RoleId AS SMALLINT
--			DECLARE @curProfileID AS INT
--			DECLARE @SSGroupId AS INT  
--			declare @Employeeid1 as nvarchar(max)
--			DECLARE @RowNo1 AS SMALLINT

--	  CREATE TABLE #Temp ( RoleName NVARCHAR (60), RoleID SMALLINT,RoleProfileName  NVARCHAR(88),profileid  BIGINT)

--	SET @select = 'INSERT INTO #Temp (RoleName, RoleID,RoleProfileName,profileid) SELECT rtrim(ltrim(COLUMN_NAME)), ssrole.RoleId , '''',0
--	FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns   INNER JOIN ssrole ON ssrole.RoleId  =  CAST (replace(rtrim(ltrim(COLUMN_NAME)),''R'','''') AS SMALLINT)
--    WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''EmpId'' , ''NAME'' , ''Post'' , ''Remarks'' ,''Row_Number'') '
--	EXEC (@select)

--	EXEC('DECLARE EmpCursor CURSOR FOR SELECT t.empid ,t.Row_Number
--FROM  '+@tablename+' t where t.post=1')
--  OPEN EmpCursor
--     FETCH NEXT FROM EmpCursor INTO @Employeeid1,@RowNo1
--     WHILE @@FETCH_STATUS = 0
--      BEGIN 
--	  SELECT @SSGroupId =ssgroup FROM dbo.EmpAssignment WHERE EmployeeId=@Employeeid1

--					DECLARE TempCursor CURSOR FOR SELECT t.RoleName , t.RoleID
--					                                FROM #Temp AS t ORDER BY t.RoleID
--					OPEN TempCursor
--					FETCH NEXT FROM TempCursor INTO @Cursor_RoleName , @Cursor_RoleId
--					WHILE @@FETCH_STATUS = 0
--					BEGIN
						
--						set @str = 'UPDATE #Temp SET RoleProfileName = (SELECT isnull('+@Cursor_RoleName+','''') from '+@tablename+' where ltrim(rtrim(empid)) = ltrim(rtrim('''+@Employeeid1+''')) )
--						            where RoleName = '''+@Cursor_RoleName+''''
--						EXEC (@str)


--						SET @str = 'select @curProfileID = isnull(p.profileid,0) 
--						            FROM [Profile] AS p left join  #Temp AS t  ON '+(CASE WHEN @lang = 'A' THEN ' LTRIM(RTRIM(p.AName))' 
--									ELSE ' LTRIM(RTRIM(p.Name))' END )+' = LTRIM(RTRIM(isnull(t.RoleProfileName,''''))) 
--									where t.RoleName = '''+@Cursor_RoleName+''' and t.RoleProfileName <> '''''
--						exec sp_executesql @str  , N' @curProfileID int OUTPUT ' , @curProfileID  OUTPUT


--						SET @curProfileID=ISNULL(@curProfileID,0)
--						EXEC ('UPDATE #Temp
--							   SET profileid = '+@curProfileID+'
--						       where RoleName = '''+@Cursor_RoleName+'''')

--						SET @curProfileID=0

--	   IF EXISTS(SELECT * FROM dbo.SSGroupRoleRecords 
--	    INNER JOIN #Temp ON #Temp.profileid = SSGroupRoleRecords.ProfileId AND #Temp.RoleID = SSGroupRoleRecords.RoleId
--	   WHERE  SSGroup=@SSGroupId AND   dbo.SSGroupRoleRecords.StartDate =CAST( GETDATE() AS DATE))
--	    BEGIN
--		    SELECT @errormsg=(CASE WHEN @lang = 'A' THEN  N'لا يمكن ادخال بيانات متكررة' ELSE 'Can not insert duplicate record' END)
--	     	SELECT @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+'''))+char(13) ,post=0  
--			where '+@tablename+'.empid= '+@Employeeid1+' and '+@tablename+'.row_number= '+STR(@RowNo1)+''
--   	PRINT @str
--EXECUTE(@str)
--	    END
--	   ELSE IF EXISTS(SELECT * FROM dbo.SSGroupRoleRecords 
--	    INNER JOIN #Temp ON #Temp.profileid = SSGroupRoleRecords.ProfileId AND #Temp.RoleID = SSGroupRoleRecords.RoleId
--	   WHERE  SSGroup=@SSGroupId AND  (CAST( GETDATE() AS DATE)  BETWEEN dbo.SSGroupRoleRecords.StartDate AND ISNULL(SSGroupRoleRecords.EndDate,CAST( GETDATE() AS DATE))) )
--	    BEGIN
--             SELECT @errormsg=(CASE WHEN @lang = 'A' THEN N' لا يمكن ادخال هذا السجل , يوجد سجل حيوي بالفعل '  ELSE 'Cannot insert this record, there is already active record' END)
-- 	     	SELECT @str='UPDATE '+@tablename+' set remarks= rtrim(ltrim(N'''+@errormsg+'''))+char(13) ,post=0  
--			where '+@tablename+'.empid= '+@Employeeid1+' and '+@tablename+'.row_number= '+STR(@RowNo1)+''
--   	PRINT '123'+@str
--EXECUTE(@str)
--	    END
						
--	FETCH NEXT FROM TempCursor INTO  @Cursor_RoleName , @Cursor_RoleId	
--	END
--	CLOSE TempCursor
--	DEALLOCATE TempCursor
--						UPDATE #Temp
--					SET
--						RoleProfileName = '',
--						profileid = 0
--	  FETCH NEXT FROM EmpCursor into @Employeeid1,@RowNo1
--     END
--    CLOSE EmpCursor
--    DEALLOCATE EmpCursor
	


END

IF ltrim(rtrim(@tabletype)) like'%WP_GetExternalVacDueAdjust%'  
BEGIN
	IF @EnableTextValidation = '1' 
	BEGIN
		DECLARE @VacDueOtherInfo NVARCHAR(max)
		SELECT @VacDueOtherInfo = ISNULL(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalVacDueAdjust', 'other_info', @lang,@LogonName) , CASE @lang  WHEN 'A' THEN N'معلومات أخرى' ELSE 'Other Information' END)

		--Validate Other Info
		SELECT @Str = 'UPDATE ' + @tablename + '  SET Remarks = LTRIM(RTRIM(Remarks))  + N''' + @VacDueOtherInfo + ' ' +  LTRIM(RTRIM(@RegularExpressionError)) + '''+char(13)
                       FROM ' + @tablename + ' Tmptbl WHERE dbo.validateText(''WP_GetExternalVacDueAdjust'', ''other_info'', other_info) = 0 
					   and  (Tmptbl.Post = 1)  
					   and Tmptbl.Row_Number= case when '+ ltrim(rtrim(str(@Paycode)))+'= 0 then Tmptbl.Row_Number else '+ltrim(rtrim(str(@Paycode)))+ ' end '    
		EXEC(@Str)
		PRINT(@str)
	END
END

IF ltrim(rtrim(@tabletype))  LIKE '%WP_GetExternalHistoryPaycodes%' OR ltrim(rtrim(@tabletype)) LIKE '%WP_GetExternalHistoryPaycodes_ar%'
BEGIN	

declare @enableHigiri as int , @DefaultCalendar as int
select @enableHigiri = EnableHijri from SysParam
select @DefaultCalendar = DefaultCalendar from nasusers  where @logonname=logonname 

			select @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_GetExternalHistoryPaycodes','YearMonthErrorMsg',@lang,@LogonName) , 
							(case when @lang = 'A' then N'من فضلك راجع الشهر او السنة' else 'Please check year or month' end))

			EXEC (' update '+@tableName +' set Post=0 , Remarks = rtrim(ltrim(N'''+@errormsg+'''))+char(13)
			 where (len(LTRIM(RTRIM(Year))) < 4) or (len(LTRIM(RTRIM(Month))) > 2) or (Month > 12) or 
			 (' +@enableHigiri +' = 0 and '+ @DefaultCalendar +' = 0 and Year < 1900 )')
		
end 

IF ltrim(rtrim(@tabletype)) like'%WP_HrBudgetEntry%' 
BEGIN
declare @CountRows as int = 0 ,@CountNoError as int = 0,@cmd as nvarchar(max) =''
		SELECT @cmd =  '
			 select @CountNoError = count(*) from ' + @tablename + '  
			 where ((case when isnull(MaxAmnt,0) = 0 then  99999999 else MaxAmnt end) >=
			(case when isnull(MidAmnt,0) = 0 then  
	(case when isnull(MaxAmnt,0)  =isnull(MinAmnt,0) then isnull(MaxAmnt,0) else (case when isnull(MaxAmnt,0) = 0 then  99999999 else MaxAmnt end)-1  end )
	else MidAmnt end)) and 
			((case when isnull(MidAmnt,0) = 0 then  
	(case when isnull(MaxAmnt,0)  =isnull(MinAmnt,0) then isnull(MaxAmnt,0) else (case when isnull(MaxAmnt,0) = 0 then  99999999 else MaxAmnt end)-1  end )
		else MidAmnt end) >=
			(case when isnull(MinAmnt,0) = 0 then  -99999999 else MinAmnt end))'
		EXEC sp_executesql  @cmd, N'@CountNoError int OUTPUT', @CountNoError=@CountNoError OUTPUT
		PRINT(@cmd)
		SELECT @cmd = '
			 select @CountRows = count(*) from ' + @tablename 
		EXEC sp_executesql  @cmd, N'@CountRows int OUTPUT', @CountRows=@CountRows OUTPUT

		if @CountNoError <> @CountRows
		begin
			select @errormsg = isnull(dbo.Hits_GetDCCaptionWzLogon('WP_HrBudgetEntry','MinMaxErrorMsg',@lang,@LogonName) , 
							(case when @lang = 'A' then N'من فضلك راجع ترتيب قيم الحد الأدنى/المتوسط/الأقصى.' else 'Please check Min/Mid/Max amounts sequence.' end))
			RAISERROR(@errormsg,16,1);
		end	

END

IF @enableOrgSetup=1 AND @userOrganization <>''
BEGIN
	DROP TABLE #OrgTree
END
END


--select * from DNACLOUDDBBatchTemp.dbo.[Nasbatch40420240214103644b4c406eb9647426eb10c3af686429856]

GO

