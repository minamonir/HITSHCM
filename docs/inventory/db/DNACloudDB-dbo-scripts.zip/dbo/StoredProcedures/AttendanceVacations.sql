
CREATE  PROCEDURE [dbo].[AttendanceVacations](@CutoffDate nCHAR(10),@AbsentCode Int,@LateCode Int,@InCompCode Int,@Late nChar(5)='10:30',@MaxInComp Int=10,@Before Int=0,@Safety Int=80)
AS  
Begin
	
--EXEC AttendanceVacations @CutoffDate = '2012-01-22'
--    ,@AbsentCode = 40
--    ,@LateCode = 5
--    ,@InCompCode =4
--    ,@Late = '10:30'
--    ,@MaxInComp = 10
--    ,@Before = 0
--    ,@Safety = 45
	
--OTH--
--Posts vacations for Absent,Late & InComplete records for active empolyees with shifts every day.
--=================================================================================================

--@CutoffDate Announcement Start Date for 2012 only else 01/01/20..
--@AbsentCode vacation code for absence day.
--@LateCode vacation code for late half day.
--@InCompCode vacation code for InComplete half day.
--@Late Late flexibily Time.
--@MaxInComp max no of incomplete per calendar year.
--@Before execution day (Today=>0,Yesterday=>-1,etc....).
--@Safety (max no of absent or incomplete for all employees per day) for time machine failure => no insertion .
--===========================================================================================================
Declare @EmpID Int,@AttStatus Int,@InCompCnt Int,@DocNo Int ,@VacDate nChar(10)	
Select @VacDate=Convert(nChar(10),Dateadd(d,@Before,Getdate()),120)

CREATE TABLE #Temp(EmpID INT,AttStatus Int)

--5320,5026 removed 29.05.2012
--5005 removed 18.09.2012

Insert into #Temp
Select EmpShiftInOut.EmpID
,Case
When (EmpAssignment.EmployeeId not in ('5405','5488','5330','5487','5546','10002','10001','10000','5230','5306','5261','5565','5335')) 
AND  (dbo.EmpVacOrNot(EmpShiftInOut.EmpID,EntryDate)=0) 
Then 0 --Absent

When (EmpAssignment.EmployeeId not in ('5405','5488','5330','5487','5050','10002','10001','10000','5230','5306','5261','9210','9211','5562','5563','5564','5565','5335')) 
AND  (EmpAssignment.Grade not in (10,11,20,30,32,40,42,50,52,190,200,210,300,301,310))
AND  (Convert(nChar(5),TimeIn,108)>@Late) 
Then 1 --LateIn

When (EmpAssignment.EmployeeId not in ('5405','5488','5330','5487','5050','10002','10001','10000','5230','5306','5261','9211','5565','5335')) 
AND  (EmpAssignment.Grade not in (10,11,20,30,32,40,42,50,52,190,200,210,300,301,310))
AND  ((TimeIn Is Null And [TimeOut] Is Not null) Or ([TimeOut] Is Null And TimeIn Is Not null))
Then 2 --InComplete
Else Null End As [AttStatus]
From EmpShiftInOut
Inner Join EmpAssignment On EmpAssignment.EmpID = EmpShiftInOut.EmpID
Inner Join HrStatus On HrStatus.HrStatus = EmpAssignment.HrStatus
Where ShiftSeconds<>0
And EntryDate=@VacDate
AND Convert(nchar(10),EmpShiftInOut.EntryDate,112) Not In  
(SELECT Convert(nchar(10),Holidays.date,112) FROM Holidays WHERE holidays.vacpack=EmpAssignment.vacpack AND holidays.holiday=1)
AND EmpAssignment.EmpId NOT IN (SELECT EmpVacat.EmpId 
								FROM EmpVacat 
								WHERE  @VacDate BETWEEN EmpVacat.FromDate AND EmpVacat.ToDate 
								AND EmpVacat.VacStatus IN (1,5))

------AND EmpAssignment.EmpId NOT IN (SELECT EmpVacat.EmpId 
------								FROM EmpVacat 
------								WHERE  @VacDate BETWEEN EmpVacat.FromDate AND EmpVacat.ToDate 
------								AND EmpVacat.VacStatus IN (3) AND EmpVacat.VacCode IN (4,5,40))
								

AND ISNULL(dbo.GetOrganizationParent(EmpAssignment.Organization,2,1,0,'E'),0)=7000
AND EmpAssignment.Organization<>7409
AND HRStatus.PayStatus = 1
AND HRStatus.HRStatus not in (4)
AND TimeRule is not null
AND EmpAssignment.EmployeeId <> '5032' --Finger Print not working
--AND EmpAssignment.EmployeeId  IN (9072,9180,9099)

DECLARE @AbsCnt AS INT,@InCnt AS INT,@LateCnt INT
SELECT @AbsCnt=	Count(*) From #Temp Where AttStatus=0
SELECT @LateCnt = Count(*) From #Temp Where AttStatus=1
SELECT @InCnt = Count(*) From #Temp Where AttStatus=2
PRINT 'Total Absence: '+STR(@AbsCnt)
PRINT 'Total Late: '+STR(@LateCnt)
PRINT 'Total InComplete: '+STR(@InCnt)
	
If @AbsCnt>@Safety Or @InCnt>@Safety
BEGIN
	 PRINT 'Total employees exceeded Safety'
END
ELSE 
Begin
	DECLARE EmpCursor CURSOR  
	For Select EmpID,AttStatus From #Temp Where AttStatus In (0,1,2)
	OPEN EmpCursor
	FETCH NEXT FROM EmpCursor INTO @EmpID,@AttStatus
	WHILE @@FETCH_STATUS=0
	Begin
		Select @DocNo=dbo.GetDocumentNo(@EmpID,3)
		
		If @AttStatus =1 --LateIn
		BEGIN
			Print 'EmpID: '+Str(@EmpID,8) +' Status: '+Str(@AttStatus,1)
			Insert into EmpVacat(EmpID, DocumentNo, VacStatus, VacCode, VacDate, FromDate, ToDate, enterby, enterdate)
			Values(@EmpID,@DocNo,1,@LateCode,@VacDate,@VacDate,@VacDate,99999999,Getdate())
		End
		ELSE If @AttStatus =2 --InComplete
		Begin
			Select @InCompCnt = Count(*)
			From EmpShiftInOut
			Inner Join EmpAssignment On EmpAssignment.EmpID = EmpShiftInOut.EmpID
			LEFT JOIN dbo.PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup
			Where EmpShiftInOut.EmpID=@EmpID
			And ShiftSeconds<>0
			And ((TimeIn Is Null And [TimeOut] Is Not null) Or ([TimeOut] Is Null And TimeIn Is Not null)) 
			And EntryDate Between (Case when Year(@VacDate)=2012 Then @CutoffDate Else STR(Year(@VacDate),4)+'-01-01' 
			END) And @VacDate --Getdate()
			AND Convert(nchar(10),EmpShiftInOut.EntryDate,112) Not In  
			(SELECT Convert(char(10),Holidays.date,112) FROM Holidays WHERE holidays.vacpack=EmpAssignment.vacpack AND holidays.holiday=1)
			AND NOT EXISTS(SELECT EmpVacat.FromDate
                           FROM EmpVacat 
                           WHERE EmpVacat.EmpId=@EmpID 
							AND EmpShiftInOut.EntryDate BETWEEN EmpVacat.FromDate AND EmpVacat.ToDate
							AND EmpVacat.VacStatus IN (1,5))
			
			If @InCompCnt>@MaxInComp
			BEGIN
				Print 'EmpID: '+Str(@EmpID,8) +' Status: '+Str(@AttStatus,1)+ ' InCompCnt: '+Str(@InCompCnt,5)
				Insert into EmpVacat(EmpID, DocumentNo, VacStatus, VacCode, VacDate, FromDate, ToDate, enterby, enterdate)
				Values(@EmpID,@DocNo,1,@InCompCode,@VacDate,@VacDate,@VacDate,99999999,Getdate())
			End
		End
		ELSE --Absent
		BEGIN
			Print 'EmpID: '+Str(@EmpID,8) +' Status: '+Str(@AttStatus,1)
			Insert into EmpVacat(EmpID, DocumentNo, VacStatus, VacCode, VacDate, FromDate, ToDate, enterby, enterdate)
			Values(@EmpID,@DocNo,1,@AbsentCode,@VacDate,@VacDate,@VacDate,99999999,Getdate())
		End
	FETCH NEXT FROM EmpCursor INTO @EmpID,@AttStatus
	END
	CLOSE EmpCursor
	DEALLOCATE EmpCursor
END

	
Drop table #Temp
End

GO

