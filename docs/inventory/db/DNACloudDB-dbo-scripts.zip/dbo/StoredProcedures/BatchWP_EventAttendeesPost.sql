-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[BatchWP_EventAttendeesPost]
	
(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS int , @lang as nchar(1)) AS

    DECLARE @SELECT AS nvarchar(max)--,@SELECT2 AS nvarchar(max)
  DECLARE @empid AS int	, @ErrMsg nvarchar(max) , @documentno INT, @Enterby AS int
 DECLARE @updatetablestr AS nvarchar(max)
 SET @updatetablestr=''
    SET @SELECT=''
     SET @ErrMsg=''
  --  SET @SELECT2=''
  
IF @actiontype=2			--------Batch Actions--------Update Competence-----------
BEGIN

	EXEC (' declare tempemployee cursor for select t.profileid,EmpTraining.DocumentNo, EmpTraining.EnterBy from '+ @TableName +' t
inner JOIN EmpTraining ON EmpTraining.EmpId=t.profileid 
where Checked=1 and EmpTraining.TrainingEvent='+@actual  )

OPEN tempemployee
FETCH NEXT FROM tempemployee
INTO  @empid, @documentno, @Enterby
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @empid
       
  exec [dbo].[hits_UpdateCompetence] @empid, @documentno, @Enterby
  
    
       SET @updatetablestr = 'update '+@TableName+' set processtime = getdate() where profileid = ' + str(@empid)
    EXECUTE (@updatetablestr  )
    
    SET @updatetablestr = 'update '+@TableName+' set processed = N'''+replace(@ErrMsg,'''','''''')+N''' where profileid = ' + str(@empid)
    EXECUTE(@updatetablestr)
    
    FETCH NEXT FROM tempemployee
    INTO  @empid, @documentno, @Enterby
END
CLOSE tempemployee
DEALLOCATE tempemployee
						
	
END

IF @actiontype=3			--------Batch Actions--------Delete Emp With Out Competence
BEGIN

	EXEC (' declare tempemployee cursor for select t.profileid,EmpTraining.DocumentNo from '+ @TableName +' t
inner JOIN EmpTraining ON EmpTraining.EmpId=t.profileid 
where Checked=1 and EmpTraining.TrainingEvent='+@actual  )

OPEN tempemployee
FETCH NEXT FROM tempemployee
INTO  @empid, @documentno
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @empid
    
    SET @SELECT=' DELETE FROM EmpTraining WHERE empid='+str(@empid)+' AND DocumentNo='+str(@documentno) 
    
        PRINT @SELECT
           exec sp_executesql @SELECT	
  

    SET @updatetablestr = 'update '+@TableName+' set processtime = getdate() where profileid = ' + str(@empid)
    EXECUTE (@updatetablestr  )
    
    SET @updatetablestr = 'update '+@TableName+' set processed = N'''+replace(@ErrMsg,'''','''''')+N''' where profileid = ' + str(@empid)
    EXECUTE(@updatetablestr)
    
    FETCH NEXT FROM tempemployee
    INTO  @empid, @documentno
END
CLOSE tempemployee
DEALLOCATE tempemployee
						
	
END

IF @actiontype=4			--------Batch Actions--------Delete Emp With Competence
BEGIN

	EXEC (' declare tempemployee cursor for select t.profileid,EmpTraining.DocumentNo from '+ @TableName +' t
inner JOIN EmpTraining ON EmpTraining.EmpId=t.profileid 
where Checked=1 and EmpTraining.TrainingEvent='+@actual  )

OPEN tempemployee
FETCH NEXT FROM tempemployee
INTO  @empid, @documentno
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT @empid
    
      SET @SELECT=' DELETE FROM EmpCompetence WHERE empid='+str(@empid)+' AND SourceDocumentNo='+str(@documentno) + ' and RatingSource=3 '
   
        PRINT @SELECT
           exec sp_executesql @SELECT	
   
    SET @SELECT=' DELETE FROM EmpTraining WHERE empid='+str(@empid)+' AND DocumentNo='+str(@documentno) 
    
        PRINT @SELECT
           exec sp_executesql @SELECT	
  

    SET @updatetablestr = 'update '+@TableName+' set processtime = getdate() where profileid = ' + str(@empid)
    EXECUTE (@updatetablestr  )
    
    SET @updatetablestr = 'update '+@TableName+' set processed = N'''+replace(@ErrMsg,'''','''''')+N''' where profileid = ' + str(@empid)
    EXECUTE(@updatetablestr)
    
    FETCH NEXT FROM tempemployee
    INTO  @empid, @documentno
END
CLOSE tempemployee
DEALLOCATE tempemployee
						
	
END

--IF @actiontype=5			--------Batch Actions--------Post Attach
--BEGIN

--DECLARE @enableAttachments AS BIT
--SELECT @enableAttachments=enableattachments FROM SysParam 

--	EXEC (' declare tempemployee cursor for select t.profileid,EmpTraining.DocumentNo from '+ @TableName +' t
--inner JOIN EmpTraining ON EmpTraining.EmpId=t.profileid 
--where Checked=1 and EmpTraining.TrainingEvent='+@actual  )

--OPEN tempemployee
--FETCH NEXT FROM tempemployee
--INTO  @empid, @documentno
--WHILE @@FETCH_STATUS = 0
--BEGIN
--    PRINT @empid
    
--    IF @enableAttachments=1
--			BEGIN

--			--IF  @AttachmentPath<>''
--			--		BEGIN
						
					
--			--			INSERT INTO Attachments
--			--			(
						
--			--			EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,	AttachmentPath,EnterBy,EnterDate
--			--			)
--			--			VALUES
--			--			(@EmpId,9,@DocumentNo,0,0,@AttachmentDescription,@AttachmentADescription,@AttachmentPath,@enterby,@IssueDate
--			--			)
						
--			--		END 
				
--			END
  

--    SET @updatetablestr = 'update '+@TableName+' set processtime = getdate() where profileid = ' + str(@empid)
--    EXECUTE (@updatetablestr  )
    
--    SET @updatetablestr = 'update '+@TableName+' set processed = N'''+replace(@ErrMsg,'''','''''')+N''' where profileid = ' + str(@empid)
--    EXECUTE(@updatetablestr)
    
--    FETCH NEXT FROM tempemployee
--    INTO  @empid, @documentno
--END
--CLOSE tempemployee
--DEALLOCATE tempemployee
						
	
--END

IF @actiontype=1				-------Export------
								-------create temp table with same structure as Excel Sheet

	BEGIN
		DECLARE @updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
	@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(max)

DECLARE @TableNamelen AS int 
SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1

PRINT 'actual TE' + str(@actual)
--SET @ActTrainEvent= substring(@actual, charindex('?',@actual,0 )+1, len(@actual)  )


		IF rtrim(ltrim(@tablename))<>'' 

	BEGIN
		IF @lang='a'
		BEGIN
		 SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
  + ' CREATE TABLE ' + @tablename+ '( 
										profileid [int] , AName nchar(88)collate database_default, Checked bit, [Row_Number] int identity(1,1) NOT NULL PRIMARY KEY ,ProcessTime datetime 
										,employeeid NVARCHAR(50), HrStatusAName nvarchar(250)  collate database_default, JobAName nvarchar(250)  collate database_default
										,OrganizationAName nvarchar(250)  collate database_default,EnrollStatusAName nvarchar(250)  collate database_default, Processed nvarchar(max) DEFAULT ('''') 
										) '
			PRINT @SELECT							
	exec sp_executesql @select
			
			
			  SET @SELECT='insert into '+@tablename +' (profileid,AName,Checked,employeeid,JobAName,OrganizationAName,HrStatusAName,EnrollStatusAName)  SELECT  V_EmpTraining.empid,
			 AName  ,1
			,V_EmpTraining.EMPLOYEEID , Jobs.JobAName  ,
			 Organization.OrganizationAName  ,
			 HrStatus.HrstatusAName  ,
			 EnrollStatusAName   
FROM V_EmpTraining 
LEFT JOIN empassignment ON empassignment.EmpId = V_EmpTraining.EmpId 
LEFT JOIN jobs ON jobs.job = empassignment.Job 
LEFT JOIN Organization ON Organization.Organization = empassignment.Organization 
LEFT JOIN HrStatus ON HrStatus.hrstatus = empassignment.HrStatus 
WHERE TrainingEvent='+str(@actual)
	          
           PRINT @SELECT
           exec sp_executesql @SELECT	
		END
		ELSE
			BEGIN
				 SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
  + ' CREATE TABLE ' + @tablename+ '( 
										profileid [int] , Name nCHAR(88)collate database_default, Checked bit, [Row_Number] int identity(1,1) NOT NULL PRIMARY KEY ,ProcessTime datetime 
										,employeeid NVARCHAR(50), HrStatusName nvarchar(250)  collate database_default, JobName nvarchar(250)  collate database_default
										,OrganizationName nvarchar(250)  collate database_default,EnrollStatusName nvarchar(250)  collate database_default, Processed nvarchar(max) DEFAULT ('''') 
										) '
			PRINT @SELECT							
	exec sp_executesql @select
			
	---set @SELECT2= ' #temp2.TrainCentr,' + CASE WHEN @lang='e' THEN '  #temp2.TrainCentrName ' ELSE ' #temp2.TrainCentrAName ' END + ' AS TrainCentrName , '
			
			  SET @SELECT='insert into '+@tablename +' (profileid,Name,Checked,employeeid,JobName,OrganizationName,HrStatusName,EnrollStatusName)  SELECT  V_EmpTraining.empid,
			 Name  ,1
			,V_EmpTraining.EMPLOYEEID , Jobs.JobName  ,
			 Organization.OrganizationName  ,
			HrStatus.HrstatusName  ,
			 EnrollStatusName 
FROM V_EmpTraining 
LEFT JOIN empassignment ON empassignment.EmpId = V_EmpTraining.EmpId 
LEFT JOIN jobs ON jobs.job = empassignment.Job 
LEFT JOIN Organization ON Organization.Organization = empassignment.Organization 
LEFT JOIN HrStatus ON HrStatus.hrstatus = empassignment.HrStatus 
WHERE TrainingEvent='+str(@actual)
	          
           PRINT @SELECT
           exec sp_executesql @SELECT
			END
		  
           
           SET @DisabledColStr='1,2'
           SET @updatestr=' update '+@tablename+' set Checked=@Checked  ,profileid=@profileid, Name=@Name 
											 where isnull(ltrim(rtrim(profileid)),0)=isnull(ltrim(rtrim(@originalprofileid)),0) '
	   SET @deletestr=' delete from '+@tablename+' where isnull(ltrim(rtrim(profileid)),0)=isnull(ltrim(rtrim(@originalprofileid)),0) '
	 
			SELECT @updatestr AS updatestr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr
	END
     

			
 

	END

GO

