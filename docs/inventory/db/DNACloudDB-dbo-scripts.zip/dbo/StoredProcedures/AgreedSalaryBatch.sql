
CREATE PROCEDURE [dbo].[AgreedSalaryBatch](@Percentage nchar(100),@CalculatedOn nchar(100), @filterselect nvarchar(max)='',@filterwhere nvarchar(max)='',@filtergroup nvarchar(max)='')
AS

declare @where nvarchar(max)
--declare @CalculatedOn nchar(100)
--declare @Percentage nchar(100)
--
--set @CalculatedOn='SsFixVal'
--set @Percentage='0.7'

declare @empid nChar(100)
declare EmpCursor Cursor for
Select EmpId from EmpAssignment
where EmpAssignment.Status=1 

OPEN EmpCursor
FETCH NEXT FROM EmpCursor into @empid

WHILE @@FETCH_STATUS = 0
BEGIN
--print @empid
if(Select count(*) from UserAuditDetail INNER JOIN UserAuditHeader ON UserAuditDetail.AuditCode = UserAuditHeader.AuditCode
     where UserAuditDetail.TableName='EmpAssignment' 
     and UserAuditDetail.FieldName='ContBasSal' and UserAuditDetail.ProfileId=@empid
     and Year(UserAuditHeader.AuditDate)=Year(Getdate()))=0
begin
exec('UPDATE    EmpAssignment
SET       ContBasSal = ContBasSal +'+ @Percentage + '*' +@CalculatedOn+
'where EmpAssignment.empid='+@empid)

end

FETCH NEXT FROM EmpCursor into @empid
END

CLOSE EmpCursor

DEALLOCATE EmpCursor

set @where=' where UserAuditDetail.TableName=''EmpAssignment''  
and UserAuditDetail.FieldName=''ContBasSal'' 
and Year(UserAuditHeader.AuditDate)=Year(Getdate()) '
EXEC('Select  
UserAuditHeader.AuditDate, 
dbo.Greg2Hijri(UserAuditHeader.AuditDate,''E'')as h_AuditDate,
UserAuditHeader.AuditType,
UserAuditHeader.UserProfileId, 
UserProfile.Name AS UserProfileName, 
UserProfile.AName AS UserProfileAName, 
case when DataDictTable.Description <>''''  then DataDictTable.Description else UserAuditDetail.TableName end as TableName,
case when DataDictionary.Description <>'''' then DataDictionary.Description else UserAuditDetail.FieldName end as FieldName,
case when DataDictionary.ADescription <>'''' then DataDictionary.ADescription else UserAuditDetail.FieldName end as FieldAName,
UserAuditDetail.OldValue, 
UserAuditDetail.NewValue, 
isnull(empassignment.employeeid,cast(UserAuditDetail.ProfileId as nvarchar(50))) as chngEmployeeid, 
Profile.Name AS ChngprofileName,
Profile.AName AS ChngprofileAName, 
UserAuditDetail.DocumentNo,
cast (UserAuditHeader.AuditCode as nvarchar (max)) as TableId,
UserAuditHeader.AuditCode '+@filterselect+
' from UserAuditDetail
inner join UserAuditHeader on UserAuditHeader.AuditCode=UserAuditDetail.AuditCode
left join UserAuditType On UserAuditType.AuditType=UserAuditHeader.AuditType
Left join Profile UserProfile on UserProfile.Profileid=UserAuditHeader.UserProfileId
left join Empassignment UserEmpassignment on UserEmpassignment.empid=UserAuditHeader.UserProfileId
left join PersonType on PersonType.PersonType=UserProfile.PersonType
left join DataDictionary on DataDictionary.TableName=UserAuditDetail.TableName and DataDictionary.FieldName=UserAuditDetail.FieldName
left join DataDictionary DataDictTable on DataDictTable.TableName=UserAuditDetail.TableName and DataDictTable.Fieldname =''''
left join Profile on Profile.profileid=UserAuditDetail.ProfileId
left join empassignment on empassignment.empid=UserAuditDetail.ProfileId
left join Organization ON Organization .Organization =empassignment .Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center 
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId '
+@where)


--Select UserAuditDetail.TableName, UserAuditDetail.FieldName, 
--       UserAuditDetail.NewValue as AfterModification, 
--       UserAuditDetail.OldValue as BeforeModification, 
--       UserAuditDetail.ProfileId, 
--       Profile.Name as UserProfileName, Profile.AName as UserProfileAName, 
--       UserAuditHeader.AuditDate as ModificationDate
--From UserAuditDetail INNER JOIN UserAuditHeader ON UserAuditDetail.AuditCode = UserAuditHeader.AuditCode Left join Profile  on Profile.Profileid=UserAuditHeader.UserProfileId
--        where UserAuditDetail.TableName='EmpAssignment'  
--        and UserAuditDetail.FieldName='ContBasSal' 
--        and Year(UserAuditHeader.AuditDate)=Year(Getdate())

GO

