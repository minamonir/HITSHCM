
Create   PROCEDURE [dbo].[Batch_CreateTempTable_Integration]  (
@tablename AS nvarchar(150),@tabletype AS nvarchar(max)) 
AS
BEGIN
DECLARE @lang AS nchar(1)
SET @lang='E'
	DECLARE @str AS nvarchar(max)
	DECLARE @outstr AS nvarchar(max)
	
DECLARE @actualtablename AS nvarchar(150)

SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName like cast(@tabletype as VARCHAR(8000))

SET @actualtablename=isnull(@actualtablename,'')

IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExternalSystemsBatchPosting%' EXEC BatchWP_ExternalSystemsBatchPostingPage1 3,@tablename ,0,'','',0,@outstr OUTPUT
ELSE IF ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalPayrollfromExternalSystem%' EXEC BatchWP_ExternalSystemsBatchPostingPage1 3,@tablename ,0,'','',0,@outstr OUTPUT

else
BEGIN
set @str = 'EXEC [hits_importexport] 3,''' +@actualtablename+''','''+ @tablename  +''',0,@formulaOutput output'
exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
end	
END

GO

