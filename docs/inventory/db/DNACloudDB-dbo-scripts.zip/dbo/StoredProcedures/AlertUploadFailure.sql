
CREATE PROCEDURE AlertUploadFailure
AS
BEGIN

SELECT 'Dears,' AS header 
,'Kindly be informed that there is a failure in uploading time keeping records to the cloud Today.' AS body
,'Thanks & best regards' AS footer
WHERE NOT EXISTS  
(SELECT  CONVERT(CHAR(10),ProcessTime,111)FROM dbo.EmpTimeReadings WHERE CONVERT(CHAR(10),ProcessTime,111) =CONVERT(CHAR(10),GETDATE(),111) 
AND cast (ProcessTime AS TIME) >=  CASE WHEN CAST (GETDATE() AS TIME) <= '12:00:00.0000000' THEN  '00:00:00.0000000' ELSE '12:00:00.0000000' END )

END

GO

