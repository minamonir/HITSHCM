CREATE PROCEDURE [dbo].[Alert_AppSendJobOffer]
 ( 
 @TableName nvarchar(250)='DNACLOUDDBBatchTemp.dbo.[NasbatchWB_20658_404202502091010447b136e9548a34758a951cabc74939135]',
 @EnterBy as int=404,@EnterDate as datetime=N'2025/02/09 10:14:26',@Lang as nvarchar(10)='e',@action as int='1'
 )
as
BEGIN


DECLARE  @empid AS int,@assignmentid as int
,@ErrorList AS nvarchar(250)


DECLARE @ErrorValue AS int

 exec(' declare tempemployee cursor for select distinct profileid,AssignmentID from '+ @TableName+' where Checked=1' )
 OPEN tempemployee
 FETCH NEXT FROM tempemployee
 INTO  @empid,@assignmentid
 WHILE @@FETCH_STATUS = 0
 BEGIN
 SELECT @ErrorList=''
 
 --select @assignmentid
  --select @mailBody
 --insert into SQLMailLog (SQLMailSubject ,SQLMailBody,SQLMailCreatedDate,sqlMailto)
 -- values (@mailsubject,@mailBody,getdate(),@candidatemail)
  
  insert into AppJobOffer(empid,AssignmentId,CreatedDate,Lang)
  values(@empid,@assignmentid,@EnterDate,@Lang)

	declare @updatetablestr as Nvarchar(max)
	set @updatetablestr = 'update '+@TableName+' set processtime = getdate() ,Processed=N'''+@ErrorList+N''' where profileid = ' + str(@empid)+' and assignmentid=' + str(@assignmentid)+' AND checked=1 '
	execute (@updatetablestr  )
	FETCH NEXT FROM tempemployee INTO  @empid,@assignmentid
	END
 CLOSE tempemployee
 DEALLOCATE tempemployee

 	
	end

GO

