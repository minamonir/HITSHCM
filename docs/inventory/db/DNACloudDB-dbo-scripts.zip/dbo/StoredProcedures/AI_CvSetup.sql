CREATE PROCEDURE [dbo].[AI_CvSetup]
    @QualificationTypeName NVARCHAR(100) = '',
    @QualificationMajorTypeName NVARCHAR(100) = '',
    @QualificationGradeTypeName NVARCHAR(100) = '',
    @EstablishmentTypeName NVARCHAR(100) = '',
	@CaptionGrade NVARCHAR(60),
	@CaptionMajor NVARCHAR(60),
	@CaptionEstablishment NVARCHAR(60),
	@CaptionAGrade NVARCHAR(60),
	@CaptionAMajor NVARCHAR(60),
	@CaptionAEstablishment NVARCHAR(60),
    @SectionTitle NVARCHAR(200) = '',
    @LogonName NVARCHAR(80) = '',
	@EnterGrade bit=1,
	@EnterEstablishment bit=1,
	@EnterMajor bit=1,
    @SectionQualificationNo INT OUTPUT  
AS
BEGIN
    SET NOCOUNT ON;
    
    
    DECLARE 
        @QualificationType SMALLINT,
        @QualificationMajorType SMALLINT,
        @QualificationGradeType SMALLINT,
        @EstablishmentType SMALLINT;

    SELECT 
        @QualificationType = NULL,
        @QualificationMajorType = NULL,
        @QualificationGradeType = NULL,
        @EstablishmentType = NULL;

    DECLARE @PrimaryKeyResult TABLE (
        PrimaryKey INT,
        IsUEnterByExists INT,
        OrgsColumn INT
    );

    -- 1. SETUP QualificationType
    SELECT @QualificationType = QualificationType
    FROM dbo.QualificationType
    WHERE QualificationTypeName = @QualificationTypeName;

    IF @QualificationType IS NULL
    BEGIN
        DELETE FROM @PrimaryKeyResult;
        
        INSERT INTO @PrimaryKeyResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName   = N'QualificationType',
            @PkFieldName = N'QualificationType',
            @LogonName   = @LogonName;

        SELECT @QualificationType = PrimaryKey
        FROM @PrimaryKeyResult;

        INSERT INTO dbo.QualificationType
        (
            QualificationType,
            QualificationTypeName,
            QualificationTypeAName,
            QualificationTypeFName,
			UEnterBy,
            UEnterDate
        )
        SELECT 
            @QualificationType, 
            @QualificationTypeName, 
            @QualificationTypeName, 
            @QualificationTypeName,
			@LogonName,
            GETDATE();
    END

    -- 2. SETUP QualificationMajorType
    SELECT @QualificationMajorType = QualificationMajorType
    FROM dbo.QualificationMajorType
    WHERE QualificationMajorTypeName = @QualificationMajorTypeName;

    IF @QualificationMajorType IS NULL
    BEGIN
        DELETE FROM @PrimaryKeyResult;
        
        INSERT INTO @PrimaryKeyResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName   = N'QualificationMajorType',
            @PkFieldName = N'QualificationMajorType',
            @LogonName   = @LogonName;

        SELECT @QualificationMajorType = PrimaryKey
        FROM @PrimaryKeyResult;

        INSERT INTO dbo.QualificationMajorType
        (
            QualificationMajorType,
            QualificationMajorTypeName,
            QualificationMajorTypeAName,
            QualificationMajorTypeFName,    
			UEnterBy,
            UEnterDate
        )
        SELECT 
            @QualificationMajorType, 
            @QualificationMajorTypeName, 
            @QualificationMajorTypeName, 
            @QualificationMajorTypeName,
			@LogonName,
            GETDATE();
    END

    -- 3. SETUP QualificationGradeType
    SELECT @QualificationGradeType = QualificationGradeType
    FROM dbo.QualificationGradeType
    WHERE QualificationGradeTypeName = @QualificationGradeTypeName;

    IF @QualificationGradeType IS NULL
    BEGIN
        DELETE FROM @PrimaryKeyResult;
        
        INSERT INTO @PrimaryKeyResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName   = N'QualificationGradeType',
            @PkFieldName = N'QualificationGradeType',
            @LogonName   = @LogonName;

        SELECT @QualificationGradeType = PrimaryKey
        FROM @PrimaryKeyResult;

        INSERT INTO dbo.QualificationGradeType
        (
            QualificationGradeType,
            QualificationGradeTypeName,
            QualificationGradeTypeAName,
            QualificationGradeTypeFName,
			UEnterBy,
            UEnterDate
        )
        SELECT 
            @QualificationGradeType, 
            @QualificationGradeTypeName, 
            @QualificationGradeTypeName, 
            @QualificationGradeTypeName,
			@LogonName,
            GETDATE();
    END

    -- 4. SETUP EstablishmentType
    SELECT @EstablishmentType = EstablishmentType
    FROM dbo.EstablishmentType
    WHERE EstablishmentTypeName = @EstablishmentTypeName;

    IF @EstablishmentType IS NULL
    BEGIN
        DELETE FROM @PrimaryKeyResult;
        
        INSERT INTO @PrimaryKeyResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName   = N'EstablishmentType',
            @PkFieldName = N'EstablishmentType',
            @LogonName   = @LogonName;

        SELECT @EstablishmentType = PrimaryKey
        FROM @PrimaryKeyResult;

        INSERT INTO dbo.EstablishmentType
        (
            EstablishmentType,
            EstablishmentTypeName,
            EstablishmentTypeAName,
            EstablishmentTypeFName,   
			UEnterBy,
            UEnterDate
        )
        SELECT 
            @EstablishmentType, 
            @EstablishmentTypeName, 
            @EstablishmentTypeName, 
            @EstablishmentTypeName,
			@LogonName,
            GETDATE();
    END

    -- 5. CREATE the main Qualification 
    DELETE FROM @PrimaryKeyResult;
    
    INSERT INTO @PrimaryKeyResult
    EXEC dbo.GetMaxPrimaryKey
        @TableName   = N'Qualification',
        @PkFieldName = N'QualificationNo',
        @LogonName   = @LogonName;

    SELECT @SectionQualificationNo = PrimaryKey  
    FROM @PrimaryKeyResult;

    -- Check if qualification already exists
    IF NOT EXISTS (
        SELECT 1 
        FROM dbo.Qualification 
        WHERE QualificationTitle = @SectionTitle
          AND QualificationType = @QualificationType
    )
    BEGIN
        INSERT INTO dbo.Qualification
        (
            [QualificationNo],
            QualificationType,
            [QualificationTitle],
            [QualificationATitle],
            [QualificationFTitle],       
            UEnterDate,
			UEnterBy,
            [EnterJob], 
            [EnterEstablishment], 
            [EstablishmentFromType], 
			[CaptionGrade],
			[CaptionMajor],
			[CaptionEstablishment],
			[CaptionAGrade],
			[CaptionAMajor],
			[CaptionAEstablishment],
            [EnterGrade], 
            [GradeFromType], 
            [EnterMajor], 
            [MajorFromType]
        )
        SELECT 
            @SectionQualificationNo, 
            @QualificationType, 
            @SectionTitle, 
            @SectionTitle, 
            @SectionTitle,
            GETDATE(),
			@LogonName,
            1, 
		    @EnterEstablishment, 
            @EstablishmentType, 
			@CaptionGrade,
			@CaptionMajor,
			@CaptionEstablishment,
			@CaptionAGrade,
			@CaptionAMajor,
			@CaptionAEstablishment,
            @EnterGrade, 
            @QualificationGradeType, 
            @EnterMajor, 
            @QualificationMajorType;
    END
    ELSE
    BEGIN
        SELECT @SectionQualificationNo = QualificationNo  
        FROM dbo.Qualification 
        WHERE QualificationTitle = @SectionTitle
          AND QualificationType = @QualificationType;
    END
END

GO

