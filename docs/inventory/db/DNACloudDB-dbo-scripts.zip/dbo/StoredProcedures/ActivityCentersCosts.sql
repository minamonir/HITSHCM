CREATE PROCEDURE [dbo].[ActivityCentersCosts] (@filterwhere as nvarchar(max))  AS

	Declare @Select1 as nvarchar(max), @Select2 as nvarchar(max),@Select3 as nvarchar(max)
	Declare @from  as nvarchar(max) ,@Groupby AS NVARCHAR(max),@where NVARCHAR (200)
	--All Trainees
	Set @Select1 = 'Select TrainingEvents.TrainingEvent ,
					count( DISTINCT EmpTraining.EmpId) AS EmpCount,
					TrainingCategories.TrainingCategory,
					TrainingCategories.TrainingCategoryAName,
					TrainingCenters.TrainingCenter,
					TrainingCenters.TrainingCenterAName
					,dbo.TrainingCostCalc(TrainingEvents.TrainingEvent,NULL,NULL,NULL,NULL,NULL,TrainingEvents.PriceCurrency,0,0) AS EventCost
					,0 AS EmpCostDedit ,0 AS EmpCostCredit , 1 AS TYPE '
					
	Set @from =' FROM EmpTraining  
	LEFT JOIN EmpAssignment ON EmpAssignment.EmpId=EmpTraining.EmpId 
	LEFT join EmpTrainingView on EmpTrainingView.empid=EmpTraining.empid and EmpTrainingView.DocumentNo=EmpTraining.DocumentNo 
	LEFT JOIN TrainingEvents ON EmpTraining.TrainingEvent = TrainingEvents.TrainingEvent
	LEFT JOIN trainingcenters ON trainingcenters.TrainingCenter = TrainingEvents.TrainingCenter 
	LEFT JOIN TrainingActivities ON TrainingEvents.TrainingActivity = TrainingActivities.TrainingActivity 
	LEFT JOIN TrainingEnrollStatus On EmpTraining.EnrollStatus=TrainingEnrollStatus.EnrollStatus 
	LEFT JOIN TrainingActivitiesCategories ON TrainingActivitiesCategories.TrainingActivity = TrainingActivities.TrainingActivity 
	LEFT JOIN TrainingCategories ON TrainingActivitiesCategories.TrainingCategory = TrainingCategories.TrainingCategory 
	LEFT JOIN TrainingEventStatus ON TrainingEventStatus.EventStatus = TrainingEvents.EventStatus 
	LEFT JOIN TrainingActivityAttachments ON TrainingActivityAttachments.TrainingActivity = TrainingActivities.TrainingActivity 
	LEFT JOIN TrainingActivityCompetence ON TrainingActivities.TrainingActivity = TrainingActivityCompetence.TrainingActivity 
	LEFT JOIN TrainingActivityEvaluation ON TrainingActivityEvaluation.TrainingActivity = TrainingActivities.TrainingActivity 
	LEFT JOIN TrainingEvaluations ON TrainingActivityEvaluation.TrainingEvaluation = TrainingEvaluations.TrainingEvaluation  
	LEFT JOIN TrainingMethods ON TrainingMethods.TrainingMethod = TrainingActivities.TrainingMethod 
	LEFT JOIN TrainingResourcesBooking ON TrainingEvents.TrainingEvent = TrainingResourcesBooking.TrainingEvent 
	LEFT JOIN TrainingResources ON TrainingResources.TrainingResource = TrainingResourcesBooking.TrainingResource AND TrainingResources.ResourceCategory = TrainingResourcesBooking.ResourceCategory 
	LEFT JOIN TrainingResourceTypes ON TrainingResourceTypes.TrainingResourceType  =TrainingResources.TrainingResourceType 
	LEFT JOIN TrainingSessions ON TrainingEvents.TrainingEvent = TrainingSessions.TrainingEvent 
	LEFT JOIN TrainingResourcesBooking L ON L.TrainingEvent = TrainingSessions.TrainingEvent AND L.TrainingSession = TrainingSessions.TrainingSession 
	LEFT JOIN TrainingBlockReasons ON TrainingResourcesBooking.BlockReason = TrainingBlockReasons.BlockReason 
	LEFT JOIN Supplier ON TrainingActivities.SupplierNo = Supplier.SupplierNo 
	LEFT JOIN Supplier EventSupplier ON TrainingEvents.SupplierNo = Eventsupplier.SupplierNo 
	LEFT Join TrainingMethods AdditionalTrainingMethods ON AdditionalTrainingMethods.TrainingMethod = EmpTraining.AdditionalTrainingMethod 
	LEFT JOIN Currency ON EmpTraining.CostCurrency=Currency.Cur 
	LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
	LEFT JOIN JobCat ON JobCat.JobCat=Jobs.JobCat 
	LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
	LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
	LEFT JOIN GradeGroups ON GradeGroups.GradeGroup = Grades.GradeGroup  
	LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
	LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
	LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center 
	LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
	LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
	LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
	LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
	LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
	LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType 
	LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
	LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
	LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
	LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
	LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
	LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
	LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
	LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
	LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus''
	LEFT JOIN NasArrays HrTaxStat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus''
	LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus'' 
	LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus''
	LEFT JOIN NasArrays EnrollStatus ON EnrollStatus.itemno=TrainingEnrollStatus.SystemEnrollStatus AND EnrollStatus.arrayname=''EnrollStatus''
	LEFT JOIN NasArrays ResourceCategory ON ResourceCategory.itemno = TrainingResourceTypes.ResourceCategory AND ResourceCategory.arrayname = ''ResourceCategory'' ' 
--Employees Trainees
SET @Select2='UNION Select TrainingEvents.TrainingEvent, 
	count(DISTINCT EmpTraining.EmpId),
	TrainingCategories.TrainingCategory,
	TrainingCategories.TrainingCategoryAName,
	TrainingCenters.TrainingCenter,
	TrainingCenters.TrainingCenterAName,
	dbo.TrainingCostCalc(TrainingEvents.TrainingEvent,NULL,NULL,NULL,NULL,NULL,TrainingEvents.PriceCurrency,0,0)
	,0,0,2 '
--External Trainees
SET @Select3='UNION SELECT TrainingEvents.TrainingEvent ,
	Count(Distinct EmpTraining.EmpId),
	TrainingCategories.TrainingCategory,
	TrainingCategories.TrainingCategoryAName,
	TrainingCenters.TrainingCenter,
	TrainingCenters.TrainingCenterAName,0,dbo.GetEmpCost(1,TrainingEvents.TrainingEvent),dbo.GetEmpCost(2,TrainingEvents.TrainingEvent),3 '
	
SET @Groupby = ' GROUP BY TrainingCategories.TrainingCategory,
	TrainingCategories.TrainingCategoryAName,
	TrainingCenters.TrainingCenter,
	TrainingCenters.TrainingCenterAName,
	TrainingEvents.TrainingEvent,
	TrainingEvents.PriceCurrency '
SET @where =' where TrainingEnrollStatus.SystemEnrollStatus IN (2,4) AND EmpTraining.TrainingEvent IS NOT NULL '
 
	  		
exec (@Select1+@from+' INNER JOIN Profile ON Profile.ProfileId=EmpTraining.EmpId '+@where+@filterwhere+@Groupby+
	  @Select2+@from+' INNER JOIN Profile ON Profile.ProfileId=EmpTraining.EmpId AND PROFILE.PersonType<>8 '+@where+@filterwhere+@Groupby+
	  @Select3+@from+' INNER JOIN Profile ON Profile.ProfileId=EmpTraining.EmpId and PROFILE.PersonType=8 '+@where+@filterwhere+@Groupby)

GO

