
CREATE PROCEDURE [dbo].[BatchWP_ExportBenefitSalaryScales]
(
 @actiontype AS SMALLINT
,@tablename AS NVARCHAR(150)
,@actual AS SMALLINT
,@Where AS NVARCHAR(MAX)
,@Parameters  AS NVARCHAR(MAX)
,@ColumnsStr AS NVARCHAR(MAX) 
,@outputstr AS NVARCHAR(MAX) OUTPUT) 
 AS 
BEGIN

DECLARE @Countfilter AS INT = 0
--DECLARE @DateFormat AS INT

--SELECT  @DateFormat =  
--CASE WHEN (SELECT [DateFormat] FROM dbo.SysParam) = 1 THEN 103
--WHEN (SELECT [DateFormat] FROM dbo.SysParam) = 2 THEN 101
--ELSE 111 END  
              
 DECLARE @select AS NVARCHAR(MAX)
DECLARE @DecimalScale AS SMALLINT 
SELECT @DecimalScale=SysParam.DecimalScale FROM SysParam
--PRINT '@DecimalScale = ' + STR(@DecimalScale)

 -----------------Parameters for Load ,Save,Delete ----------------
 DECLARE @type AS INT ,@Lang AS CHAR(1) 
,@StartIndex AS INT , @SalaryScaleId AS INT , @StartDate AS NCHAR(12)
, @GradeWhere  AS NVARCHAR(MAX), @PlanOptionWhere AS NVARCHAR(MAX)
, @CapCoverageAmount AS NVARCHAR(MAX),@CapLevelAmount AS NVARCHAR(MAX)

SET @CapCoverageAmount= 'Coverage_Amount'
SET @CapLevelAmount = 'Level_Amount'


IF @actiontype IN (1,5)   --  (1 --> load,Save) && (5 -->  Delete)
BEGIN 
--PRINT 'arameters for Load ,Save,Delete ...' + @Parameters 

SET @StartIndex = CHARINDEX('?',@Parameters)
SET @type=SUBSTRING (@Parameters,0,@StartIndex)
SET @Parameters=SUBSTRING(@Parameters,@StartIndex+1,LEN(@Parameters))
--PRINT 'Type = '+STR(@type)
--PRINT @Parameters


SET @StartIndex = CHARINDEX('?',@Parameters)
SET @Lang=SUBSTRING (@Parameters,0,@StartIndex)
SET @Parameters=SUBSTRING(@Parameters,@StartIndex+1,LEN(@Parameters))
PRINT '@Lang  ='+@Lang
PRINT @Parameters

SET @StartIndex = CHARINDEX('?',@Parameters)
SET @SalaryScaleId=SUBSTRING (@Parameters,0,@StartIndex)
SET @Parameters=SUBSTRING(@Parameters,@StartIndex+1,LEN(@Parameters))
--PRINT 'SalaryScaleId  = '+STR(@SalaryScaleId)
--PRINT @Parameters


SET @StartIndex = CHARINDEX('?',@Parameters)
SET @StartDate=SUBSTRING (@Parameters,0,@StartIndex)
SET @Parameters=SUBSTRING(@Parameters,@StartIndex+1,LEN(@Parameters))
--PRINT 'StartDate  = '+@StartDate
--PRINT @Parameters


SET @StartIndex = CHARINDEX('?',@Parameters)
SET @GradeWhere=SUBSTRING (@Parameters,0,@StartIndex)
SET @Parameters=SUBSTRING(@Parameters,@StartIndex+1,LEN(@Parameters))
--PRINT 'GradeWhere  = '+@GradeWhere
--PRINT @Parameters

SET @PlanOptionWhere=@Parameters
PRINT 'PlanOptionWhere  = '+@PlanOptionWhere
PRINT @Parameters

-------------------End Parameters for Load ,Save,Delete
END 

IF @actiontype =1         -----Load && Post
 BEGIN
   
PRINT 'Action  1 started Load & Post'

IF @type=1          ---- load
BEGIN
PRINT 'Now in load ' 

DECLARE @Query AS NVARCHAR(MAX)
DECLARE @ParmDefinition NVARCHAR(100)
DECLARE @Count AS INT
SET @ParmDefinition = N'@CountOut int OUTPUT'
SET @Query=' select @CountOut=count(*)
                 from SalaryScaleBenefits
                 left JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
				 left JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
				 LEFT JOIN Grades ON Grades.Grade = SalaryScaleBenefits.Grade 
 	             WHERE SalaryScaleBenefits.SalaryScaleid = ' +STR(@SalaryScaleId)+' 
                 AND SalaryScaleBenefits.StartDate =   '''+@StartDate +''' '+@GradeWhere+ ' '+@PlanOptionWhere+' ' 
 
EXECUTE sp_executesql @Query, @ParmDefinition, @CountOut=@Count OUTPUT  
--PRINT   @count      

IF  @Count>0 
BEGIN
----------------------------------------------------------

DECLARE @SelectAll AS NVARCHAR(MAX)='' ,@SelectCoverage AS NVARCHAR(MAX)='',@SelectLevel AS NVARCHAR(MAX) =''
DECLARE @ColumnsAll AS NVARCHAR(MAX)=' ' ,@ColumnsCoverage AS NVARCHAR(MAX) ='',@ColumnsLevel AS NVARCHAR(MAX) =''
,@ColumnsCoveragcreation AS NVARCHAR(MAX) ,@ColumnsLevelcreation AS NVARCHAR(MAX) 

SET @SelectAll=' SELECT COLUMN_NAME  FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
                  WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''Post'',''Remarks'',''Row_Number'',''GradeNo'',''Grade'')' 

CREATE TABLE #TempAll (PlanoptionNo  nvarchar(Max))
INSERT INTO #TempAll
EXEC(@SelectAll) 


--SELECT * FROM  #TempAll
--PRINT'........'

SELECT  @ColumnsAll= @ColumnsAll +PlanoptionNo+  ' numeric(18,3) default 0 , '  
FROM #TempAll
SELECT  @ColumnsAll=substring(@ColumnsAll,1,LEN(@ColumnsAll)-1)

SELECT @ColumnsCoverage= @ColumnsCoverage +PlanoptionNo+ ' numeric(18,3) default 0 , '
FROM #TempAll
WHERE #TempAll.PlanoptionNo LIKE '%'+@CapCoverageAmount+'%' 


SELECT  @ColumnsCoverage =SUBSTRING(@ColumnsCoverage,1,LEN(@ColumnsCoverage)-1)

DECLARE @query2 AS NVARCHAR(max)
SET @Query2='CREATE TABLE #tempTableCoverage ( Gradeno smallint , '+@ColumnsCoverage+')' 
Exec sp_Executesql @query2

SELECT  @ColumnsLevel= @ColumnsLevel +PlanoptionNo+ ' numeric(18,3) default 0 , '

FROM #TempAll
WHERE #TempAll.PlanoptionNo  LIKE '%'+@CapLevelAmount+'%' 
SELECT  @ColumnsLevel=SUBSTRING(@ColumnsLevel,1,LEN(@ColumnsLevel)-1)

SET @query2='CREATE TABLE #tempTableLevel ( Gradeno smallint , '+@ColumnsLevel+')'
Exec sp_Executesql @query2
SELECT @ColumnsCoverage=LTRIM(RTRIM(REPLACE (@ColumnsCoverage,'numeric(18,3) default 0 ','')))
SELECT @ColumnsCoverage='['+REPLACE (@ColumnsCoverage,' , ','] , [')+']'

SELECT @ColumnsLevel=LTRIM(RTRIM(replace (@ColumnsLevel,'numeric(18,3) default 0 ','')))
SELECT @ColumnsLevel='['+REPLACE (@ColumnsLevel,' , ','] , [')+']'


DECLARE @CoverageSelect AS NVARCHAR(max)
DECLARE @LevelSelect AS NVARCHAR(max)
SELECT @CoverageSelect ='isnull('+REPLACE(@ColumnsCoverage,',',',0),isnull(')+',0)'
SELECT @LevelSelect ='isnull('+REPLACE(@ColumnsLevel,',',',0),isnull(')+',0)'

exec ('insert into #tempTableCoverage  (Gradeno,'+@ColumnsCoverage+')
SELECT Grade, '+@CoverageSelect +' FROM (
      SELECT DISTINCT Grades.Grade ,isnull(''P''+ltrim(rtrim(STR(((SalaryScaleBenefits.PlanNo*10000)+ISNULL(SalaryScaleBenefits.OptionNo,0)))))+'''+@CapCoverageAmount+''',0) AS PlanOptionno
,isnull(SalaryScaleBenefits.CoverageAmount,0) AS CoverageAmount
             
FROM SalaryScaleBenefits
              LEFT JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
              LEFT JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
              left JOIN Grades ON Grades.Grade = SalaryScaleBenefits.Grade  
               WHERE SalaryScaleBenefits.SalaryScaleid= '+@SalaryScaleId+' and  SalaryScaleBenefits.StartDate ='''+@StartDate+'''  ' +@GradeWhere+'  '+  @PlanOptionWhere +'
)AS Data 
pivot (sum (CoverageAmount) FOR PlanOptionno  IN ('+@ColumnsCoverage+'))  as CoverageAmount

insert into #tempTableLevel  (Gradeno,'+@ColumnsLevel+')
SELECT Grade,'+@LevelSelect +' FROM (SELECT DISTINCT Grades.Grade
,isnull(''P''+ ltrim(rtrim(STR(((SalaryScaleBenefits.PlanNo*10000)+ISNULL(SalaryScaleBenefits.OptionNo,0)))))+'''+@CapLevelAmount+''' ,0)AS PlanOptionno
,isnull(SalaryScaleBenefits.Levelamount,0)AS LevelAmount             
FROM SalaryScaleBenefits
              LEFT JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
              LEFT JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
              left JOIN Grades ON Grades.Grade = SalaryScaleBenefits.Grade  
			  WHERE SalaryScaleBenefits.SalaryScaleid= '+@SalaryScaleId+' and  SalaryScaleBenefits.StartDate ='''+@StartDate+'''  ' +@GradeWhere+'  '+  @PlanOptionWhere +'
)AS Data2 
pivot (sum (LevelAmount) FOR PlanOptionno  IN ('+@ColumnsLevel+'))  LevelAmount')


SELECT @ColumnsAll=replace (@ColumnsAll,' numeric(18,3) default 0 ','')

EXEC(' insert into ' +@tablename+ '(GradeNo ,Grade,'+ @ColumnsAll +')
              select #tempTableCoverage.Gradeno ,case when '''+@Lang+'''= ''A'' then Grades.GradeAName else Grades.GradeName  end  , '+@ColumnsAll+' 
			  from  #tempTableCoverage
			  inner join  #tempTableLevel on  #tempTableLevel.Gradeno = #tempTableCoverage.Gradeno
			  left join grades on Grades.Grade =  #tempTableCoverage.Gradeno')

 EXEC(' SELECT * FROM '+ @tablename)


 DROP TABLE #TempAll
 DROP TABLE #tempTableCoverage
 DROP TABLE #tempTableLevel

PRINT 'End If  count > 0'
end

ELSE
    BEGIN 
	PRINT 'Grade where condition ..'+@GradeWhere
	PRINT '..................................'
	
		EXEC ('insert into '+@tablename+' (GradeNo,Grade) 
		select  Grade,case when '''+@Lang+'''= ''A'' then Grades.GradeAName else Grades.GradeName  end  
		FROM Grades
		where 1=1 '+@GradeWhere)
	END
--DROP TABLE #temp
Print('Ending Load')
END

IF @type = 2
BEGIN 
PRINT 'Now In Save'

DECLARE @GradesValue AS NVARCHAR(max)='' , @GradeVal AS INT 
, @PlanOptionColumns AS NVARCHAR(max)='',@PlanOptionName AS NVARCHAR(100)=''
, @PlanOption AS INT 

SET @GradesValue =  ' DECLARE Gradecursor CURSOR for SELECT distinct gradeno  FROM '+@tablename+ ' t where t.Post = 1 and rtrim(ltrim(ISNULL(t.Remarks,'''')))=''''  '
EXECUTE (@GradesValue)
OPEN Gradecursor
FETCH next FROM Gradecursor
INTO  @GradeVal
WHILE @@FETCH_STATUS=0
BEGIN
PRINT 'Cursor Grades'
--SELECT @GradeVal
PRINT 'Begin PlanoptionCursor'
  SET @PlanOptionColumns =' DECLARE tempcursor CURSOR for SELECT COLUMN_NAME 
                           FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
                     WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''Post'',''Remarks'', ''Row_Number'',''GradeNo'',''Grade'') '
  
EXECUTE(@PlanOptionColumns)
OPEN tempcursor
FETCH next FROM tempcursor
INTO  @PlanOptionName
WHILE @@FETCH_STATUS=0
BEGIN

     DECLARE @CovAmount AS NUMERIC(18,3), @LevAmount AS NUMERIC(18,3)
	 SET @PlanOption = CASE WHEN @PlanOptionName LIKE '%'+@CapCoverageAmount+'%' THEN SUBSTRING(@PlanOptionName,2,CHARINDEX(@CapCoverageAmount,@PlanOptionName)-2) ELSE  SUBSTRING(@PlanOptionName,2,CHARINDEX(@CapLevelAmount,@PlanOptionName)-2) END 
	 	
		DECLARE @sqlCommand  nvarchar(Max) , @paramDef NVARCHAR(100)
		SET @paramDef = ' @Amount numeric (18,3) OUTPUT '
		SET @sqlCommand  = ' SELECT   @Amount = '+@PlanOptionName+' FROM '+@tablename+' WHERE GradeNo = ' + STR(@GradeVal) 
	    
	 IF  @PlanOptionName LIKE '%'+@CapCoverageAmount+'%' 
	 BEGIN 
	       EXECUTE sp_executesql @sqlCommand, @paramDef, @Amount = @CovAmount  output  
			IF EXISTS (SELECT * FROM dbo.SalaryScaleBenefits 
		       WHERE SalaryScaleid=@SalaryScaleId AND StartDate=@StartDate AND (PlanNo*10000) + ISNULL(OptionNo,0) = @PlanOption AND Grade=@GradeVal)
			   BEGIN 
				
					UPDATE SalaryScaleBenefits
			            SET CoverageAmount = @CovAmount
						WHERE  SalaryScaleid= @SalaryScaleId AND StartDate=@StartDate  AND (PlanNo*10000) + ISNULL(OptionNo,0) =  @PlanOption 
						AND Grade= @GradeVal
			END 
			ELSE 
			BEGIN 
			PRINT 'insert cov'
	
			INSERT INTO dbo.SalaryScaleBenefits (SalaryScaleid , PlanNo , OptionNo , Grade ,StartDate , CoverageAmount , LevelAmount)
		            SELECT @SalaryScaleId,FLOOR(@PlanOption/10000) , @PlanOption %10000 , @GradeVal ,  @StartDate , ISNULL(@CovAmount,0) ,  ISNULL(@LevAmount,0) 
			        WHERE  ISNULL(@CovAmount,0)  <> 0
			END 			

	  END 
	  ELSE 
	  BEGIN 
	    EXECUTE sp_executesql @sqlCommand, @paramDef, @Amount = @LevAmount  output  
		 --SELECT  @GradeVal AS grade ,@PlanOptionName AS nam  , @LevAmount AS Lvelval
 

		IF EXISTS (SELECT * FROM dbo.SalaryScaleBenefits 
		       WHERE SalaryScaleid=@SalaryScaleId AND StartDate=@StartDate AND (PlanNo*10000) + ISNULL(OptionNo,0) = @PlanOption AND Grade=@GradeVal)
			   BEGIN
			  UPDATE SalaryScaleBenefits
			            SET LevelAmount = @LevAmount 
						WHERE  SalaryScaleid= @SalaryScaleId AND StartDate=@StartDate  AND (PlanNo*10000) + ISNULL(OptionNo,0) =  @PlanOption 
						AND Grade= @GradeVal

             END 

			ELSE 
			BEGIN 
					INSERT INTO dbo.SalaryScaleBenefits (SalaryScaleid , PlanNo , OptionNo , Grade ,StartDate , CoverageAmount , LevelAmount)
		            SELECT @SalaryScaleId,FLOOR(@PlanOption/10000) , @PlanOption %10000 , @GradeVal ,  @StartDate , ISNULL(@CovAmount,0) ,  ISNULL(@LevAmount,0) 
					WHERE   ISNULL(@LevAmount,0)  <> 0
			  
			END 
	  END 
	 
FETCH NEXT FROM tempcursor
INTO @PlanOptionName
END
CLOSE tempcursor
DEALLOCATE tempcursor

PRINT 'End PlanoptionCursor'

FETCH NEXT FROM Gradecursor
INTO @GradeVal

END

CLOSE Gradecursor
DEALLOCATE Gradecursor

END   -- End Save 


PRINT 'End Load && Saving'
END                 ----End Load && Saving 

IF @actiontype=3           ------Create temp table
BEGIN


PRINT 'action typ3'
IF @ColumnsStr LIKE '%@ColumnsConcat%' 
BEGIN
   PRINT '@ColumnsStr Comming from import '+@ColumnsStr
   DECLARE @index AS INT 
   SET @index = CHARINDEX('@ColumnsConcat',@ColumnsStr)
   SET @ColumnsStr= substring (@ColumnsStr,@index+LEN('@ColumnsConcat'),LEN(@ColumnsStr)-len(@index))

   PRINT 'ColumnsStr when import2222222 '+ @ColumnsStr
END

ELSE 
BEGIN
PRINT '@ColumnsStr Comming by filter to create temp table '+@ColumnsStr

DECLARE @CheckExport AS SMALLINT 

PRINT '1.. '+ @ColumnsStr
SET @ColumnsStr = replace (@ColumnsStr,'WP_ExportBenefitSalaryScales_ar?','')
SET @ColumnsStr = replace (@ColumnsStr,'WP_ExportBenefitSalaryScales?','') 
PRINT '2.. '+ @ColumnsStr


PRINT 'Parameter for where condition' + @ColumnsStr

SET @StartIndex = CHARINDEX('?',@ColumnsStr)
SET @Lang=substring (@ColumnsStr,0,@StartIndex)
SET @ColumnsStr=substring(@ColumnsStr,@StartIndex+1,len(@ColumnsStr))
PRINT 'Lang =........ '+@Lang
PRINT @ColumnsStr 

SET @StartIndex = CHARINDEX('?',@ColumnsStr)
SET @SalaryScaleId=substring (@ColumnsStr,0,@StartIndex)
SET @ColumnsStr=substring(@ColumnsStr,@StartIndex+1,len(@ColumnsStr))
PRINT 'SalaryScaleId = '+ STR(@SalaryScaleId)
PRINT @ColumnsStr

SET @StartIndex = CHARINDEX('?',@ColumnsStr)
SET @StartDate=SUBSTRING (@ColumnsStr,0,@StartIndex) 
--SET @StartDate=CONVERT(nchar(12), SUBSTRING (@ColumnsStr,0,@StartIndex),@DateFormat) 
SET @StartDate = case when isdate(@StartDate)=0 then '19000101' else @StartDate end

SET @ColumnsStr=substring(@ColumnsStr,@StartIndex+1,len(@ColumnsStr))
PRINT @ColumnsStr

SET @StartIndex = CHARINDEX('?',@ColumnsStr)
SET @GradeWhere=substring (@ColumnsStr,0,@StartIndex)
SET @ColumnsStr=substring(@ColumnsStr,@StartIndex+1,len(@ColumnsStr))
PRINT 'GradeWhere = '+ @GradeWhere
PRINT @ColumnsStr

SET @StartIndex = CHARINDEX('?',@ColumnsStr)
SET @PlanOptionWhere= CASE WHEN @StartIndex > 0 THEN SUBSTRING (@ColumnsStr,0,@StartIndex) ELSE @ColumnsStr END 
SET @ColumnsStr=substring(@ColumnsStr,@StartIndex+1,len(@ColumnsStr))
PRINT 'PlanOptionWhere=  '+ @PlanOptionWhere
PRINT 'ColumnsStr now..' + @ColumnsStr


SET @CheckExport =CASE WHEN LTRIM(RTRIM(@ColumnsStr)) <> '1' THEN 0 ELSE @ColumnsStr END   --CASE WHEN LTRIM(RTRIM(@ColumnsStr))='and 1 =1' THEN 0 ELSE @ColumnsStr END 
PRINT 'CheckExport=  '+ STR(@CheckExport)

DECLARE @Queryfilter AS NVARCHAR(max)
DECLARE @ParmDefinitionfilter NVARCHAR(100)

SET @ParmDefinitionfilter = N'@CountOutfilter smallint OUTPUT'

SET @Queryfilter=' select @CountOutfilter=count(*) 
                        from SalaryScaleBenefits 
						left JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
						left JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
						LEFT JOIN Grades ON Grades.Grade = SalaryScaleBenefits.Grade 
 	                    WHERE SalaryScaleBenefits.SalaryScaleid = ' +STR(@SalaryScaleId)+' 
				        and SalaryScaleBenefits.StartDate =  '''+CONVERT(CHAR(10),@StartDate,111)+'''  '+@GradeWhere+ ' '+@PlanOptionWhere+' ' 

EXECUTE sp_executesql @Queryfilter, @ParmDefinitionfilter, @CountOutfilter=@Countfilter OUTPUT  
PRINT  @Countfilter 
	   

DECLARE @PlanOptionCols AS NVARCHAR(max)

DECLARE @PlanOptionNameCol AS NVARCHAR(Max)
,@PlanNoCol AS INT ,  @OptionNoCol AS INT 


DECLARE @From AS NVARCHAR(MAX)
SET @From=''
DECLARE @str AS NVARCHAR(MAX) =''
IF @Countfilter > 0       -- Comming from salaryscalebenefits
BEGIN
	PRINT '@Countfilter= '+STR(@Countfilter)
	PRINT 'Comming from salaryscalebenefits'
	SET @From=' FROM SalaryScaleBenefits 
				left JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
				left JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
				LEFT JOIN Grades ON Grades.Grade = SalaryScaleBenefits.Grade 
				WHERE SalaryScaleBenefits.SalaryScaleid = '+STR(@SalaryScaleId)+' 
				AND SalaryScaleBenefits.StartDate =  '''+CONVERT(CHAR(10),@StartDate,111)+''''+  @GradeWhere  +'  '+ @PlanOptionWhere +''

 PRINT @From  


CREATE table #tempPlanOption(BenefitPlanOption int)

 INSERT INTO #tempPlanOption(BenefitPlanOption)
 EXEC ('select DISTINCT RTRIM(LTRIM(STR(SalaryScaleBenefits.PlanNo*10000+SalaryScaleBenefits.OptionNo))) '+@From)

 SELECT @ColumnsStr=''

 SELECT @ColumnsStr=@ColumnsStr+'P'+ RTRIM(LTRIM(BenefitPlanOption))+''+RTRIM(LTRIM(@CapCoverageAmount))+' numeric(18,'+STR(@DecimalScale)+') default 0 ,'
+'P'+ RTRIM(LTRIM(BenefitPlanOption))+ ''+RTRIM(LTRIM(@CapLevelAmount))+'  numeric(18,'+STR(@DecimalScale)+') default 0 ,'
FROM #tempPlanOption

PRINT 'New Columns Str '+ @ColumnsStr

DROP table #tempPlanOption


END
else      -- Comming from setup
BEGIN
	PRINT '@Countfilter= '+STR(@Countfilter)
	PRINT 'Comming from setup'
	SET @From=' FROM BenefitPlanOptions 
				left JOIN BenefitPlans ON BenefitPlans.PlanNo = BenefitPlanOptions.PlanNo
				left JOIN BenefitOptions ON BenefitOptions.OptionNo = BenefitPlanOptions.OptionNo
				WHERE 1=1 ' + @PlanOptionWhere   --+ @GradeWhere
 PRINT @From  

 CREATE table #tempPlanOptionbenefit(BenefitPlanOption int)
 INSERT INTO #tempPlanOptionbenefit(BenefitPlanOption)
 EXEC ('select DISTINCT  RTRIM(LTRIM(STR(BenefitPlanOptions.PlanNo*10000+BenefitPlanOptions.OptionNo))) '+@From)

 SELECT @ColumnsStr=''

 SELECT @ColumnsStr=@ColumnsStr+'P'+ RTRIM(LTRIM(BenefitPlanOption))+''+RTRIM(LTRIM(@CapCoverageAmount))+'  numeric(18,'+STR(@DecimalScale)+') default 0 ,'
+'P'+ RTRIM(LTRIM(BenefitPlanOption))+ ''+RTRIM(LTRIM(@CapLevelAmount))+'  numeric(18,'+STR(@DecimalScale)+') default 0 ,'
FROM #tempPlanOptionbenefit

PRINT 'New Columns Str '+ @ColumnsStr

DROP table #tempPlanOptionbenefit
END

END -- End else 


DECLARE 
       @insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
       @selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100),
       @updatestr AS NVARCHAR(MAX)
       SET @insertstr=''
       SET @selectstr=''
       SET @updatestr = ''
       
        IF rtrim(ltrim(@tablename))<>'' 
        BEGIN
             
       SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
      +'CREATE TABLE ' + @tablename+ ' (GradeNo int ,Grade nvarchar(60),'+@ColumnsStr +' Post bit , Remarks nvarchar(max) , [Row_Number] int Identity(1,1) NOT NULL Primary Key )' 

              EXECUTE (@select)
              --PRINT @select
              --PRINT @tablename
              
               
 ----------------------Update-----------------------

  SET @SELECT='DECLARE updateCursor CURSOR   for SELECT COLUMN_NAME 
               FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
               WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''Post'',''Remarks'', ''Row_Number'',''GradeNo'',''Grade'')'

   EXECUTE(@SELECT)
   OPEN updateCursor FETCH next FROM updateCursor   INTO  @PlanOptionNameCol
   WHILE @@FETCH_STATUS=0
   BEGIN
	   IF SUBSTRING(@PlanOptionNameCol,1,1) ='P'
	   BEGIN
			   SET @updatestr+= @PlanOptionNameCol+'= @'+@PlanOptionNameCol+',' 
			   PRINT @updatestr
	   end
	   FETCH NEXT FROM updateCursor INTO @PlanOptionNameCol
   END
   CLOSE updateCursor
   DEALLOCATE updateCursor
   
     SET @updatestr=' update  '+@tablename+' set ' +@updatestr +' Post = @Post, GradeNo=@GradeNo ,Grade=@Grade  where [Row_Number]= @originalRow_Number '
 END
 -------------------------------------------------
   
    ELSE
     BEGIN
            --SET @ColumnsStr = SUBSTRING(@ColumnsStr,0,LEN(@ColumnsStr))
            SET @selectstr='select  0 as Post , '''' as Remarks , 0 as [Row_Number] , 0 as GradeNo ,'''' as Grade,  '+ @ColumnsStr +'WHERE 1<>1'
      END   
	  
		DECLARE @countTablename AS INT, @countoutput AS NVARCHAR(MAX)
		SET @countoutput = 'SELECT @countTablename = count(COLUMN_NAME)
			FROM ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns 
			WHERE  ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+ PARSENAME(@tablename,1) + ''''
			
			EXEC sp_executesql @countoutput, 
					N'@countTablename int OUTPUT', 
					@countTablename = @countTablename OUTPUT
			
			PRINT '@countTablename ....' +STR(@countTablename) 
	   
	   SET @DisabledColStr='2,'+STR(@countTablename-1)
	   --SET @DisabledColStr=STR(@countTablename-1)

	   PRINT '@DisabledColStr... '+ @DisabledColStr


	   SET @insertstr=' insert into '+@tablename+' select  @GradeNo ,@Grade ,'+@ColumnsStr+', @post ,@remarks '
       SET @deletestr=' delete from  '+@tablename+' where [Row_Number]=@originalRow_Number '

	  PRINT '@ColumnsStr..........  '+ @ColumnsStr
 
	  SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,ISNULL(@DisabledColStr,'') AS DisabledColStr

----------------------------------------------------Insert Grade in tablename-------------------------
IF @CheckExport = 1
BEGIN
PRINT '@CheckExport..  ='

DECLARE @CountRows AS INT
DECLARE @ParmDefinitionfilterRows AS NVARCHAR(100)
DECLARE @Querynew  AS  NVARCHAR(max)
SET @ParmDefinitionfilterRows = N'@CountOutRows int OUTPUT'

SET @Querynew='select @CountOutRows = count(*)  FROM SalaryScaleBenefits 
left JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
left JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
LEFT JOIN Grades ON Grades.Grade = SalaryScaleBenefits.Grade 
WHERE SalaryScaleBenefits.SalaryScaleid = '+STR(@SalaryScaleId)+' 
AND SalaryScaleBenefits.StartDate =  '''+@StartDate+''''+  @GradeWhere  +'  '+ @PlanOptionWhere +''
  
  
EXECUTE sp_executesql @Querynew, @ParmDefinitionfilterRows, @CountOutRows=@CountRows OUTPUT  
PRINT  @CountRows 
 
  PRINT 'Check count filter'
  PRINT '@Countfilter =' +STR(@Countfilter)
  --IF @CheckExport = 1
  -- BEGIN
  IF  @CountRows=0     -- @Countfilter = 0
     BEGIN
	   PRINT 'Insert grades in temp table when count = 0'
  	   PRINT @Lang

	     EXEC ('insert into '+@tablename+' (GradeNo,Grade) 
		             select  Grade,case when '''+@Lang+'''= ''A'' then Grades.GradeAName else Grades.GradeName  end   FROM Grades
	                where 1=1 '+@GradeWhere)

	 END

	 ELSE 
	 BEGIN
	 PRINT 'Insert grades in temp table when count = '+STR(@CountRows)
	  PRINT @Lang

	     EXEC ('insert into '+@tablename+' (GradeNo,Grade) 
							 select distinct  Grades.Grade,case when '''+@Lang+'''= ''A'' then Grades.GradeAName else Grades.GradeName  end
							 FROM SalaryScaleBenefits
							 left join Grades on SalaryScaleBenefits.Grade = Grades.grade
							 left JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
							 left JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo
							 WHERE SalaryScaleBenefits.SalaryScaleid = '+@SalaryScaleId+' 
							 AND SalaryScaleBenefits.StartDate =  '''+@StartDate+''''+  @GradeWhere  +'  '+ @PlanOptionWhere +'')
	 end
END
-------------------------------------------------------------------------------------------------
END 

IF @actiontype=5           -----Delete 
BEGIN 

    PRINT 'Action Delete '

	PRINT 'SalaryScaleId2 in Delete = '+STR(@SalaryScaleId)
	PRINT 'StartDate2 in Delete =  '+@StartDate 
	PRINT 'Grade Where2 in Delete = '+@GradeWhere
	PRINT 'Plan option Where2 in Delete = '+@PlanOptionWhere
	
	 EXEC  ('DELETE FROM SalaryScaleBenefits 
	         FROM SalaryScaleBenefits
	         inner JOIN Grades ON SalaryScaleBenefits.Grade = Grades.Grade 
	         inner JOIN BenefitPlans ON BenefitPlans.PlanNo = SalaryScaleBenefits.PlanNo
             inner JOIN BenefitOptions ON BenefitOptions.OptionNo = SalaryScaleBenefits.OptionNo 
			 INNER join '+@tablename+' t on t.GradeNo = SalaryScaleBenefits.Grade  and t.post=1 and rtrim(ltrim(isnull(remarks,'''')))='''' 
		     WHERE  SalaryScaleBenefits.SalaryScaleid= '+@SalaryScaleId+' and  SalaryScaleBenefits.StartDate ='''+@StartDate+'''  ' +@GradeWhere+ '   '+ @PlanOptionWhere  +' ')
		   
			PRINT 'End of action delete'
END

END

GO

