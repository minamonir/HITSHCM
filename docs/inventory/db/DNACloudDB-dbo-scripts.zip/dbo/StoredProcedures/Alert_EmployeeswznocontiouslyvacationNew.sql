

CREATE PROCEDURE [dbo].[Alert_EmployeeswznocontiouslyvacationNew]
                  (@Period SMALLINT ,@PayrollOrCal SMALLINT=0 ,@EmployeeOrManager SMALLINT=0,@AlertOrSub AS SMALLINT=0,@Roles AS NVARCHAR(MAX),@Profileid AS INT=0,@donotcountdayoff AS BIT=0,@donotcountholiday AS BIT=0 , @x AS NVARCHAR (250)='')
AS
BEGIN
-- @Period : number of continuous day 
-- @EmployeeOrManager :
-- 0: employee  
-- 1: Manager 
-- @AlertOrSub :
-- 0: subscription
-- 1: Alert
-- @PayrollOrCal :
-- 0: payroll year 
-- 1: calender year
-- @Roles : will contain the RoleIds separated by commas
-- @ProfileId : will contain the profile id of the role in case of manager alert	
--@donotcountdayoff :0
--@donotcountholiday:1

DECLARE @cur_statment NVARCHAR(MAX)
DECLARE @Peroidstart SMALLDATETIME
DECLARE @filterselect nvarchar(MAX)
DECLARE @filterwhere nvarchar(MAX),@filterwhere1 NVARCHAR(MAX)
DECLARE @payrollgroup SMALLINT
DECLARE @EndDate SMALLDATETIME
DECLARE @RolesFilter NVARCHAR(250)

DECLARE @FebruaryEnd AS NCHAR(10)
--schedule preparations
DECLARE @CYear AS NCHAR(4)
SELECT @CYear = ltrim(rtrim(STR(YEAR(GETDATE()))))

--DECLARE @NextMonthDate AS SMALLDATETIME 
--select @NextMonthDate= DATEADD(MONTH,1,GETDATE())

--SELECT @CYear = ltrim(rtrim(STR(YEAR(@NextMonthDate))))

--DECLARE @NextMonth  AS NCHAR(2)
--SELECT @NextMonth= ltrim(rtrim(STR(MONTH(@NextMonthDate))))

--PRINT 'YEAR = '+@CYear  PRINT  'month = '+@NextMonth

--SELECT @FebruaryEnd = CONVERT(NCHAR(10),DATEADD(dd,-1,@cyear+'-03-01'),120)
--PRINT @FebruaryEnd

SET @filterselect=' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  '
set @EndDate=  getdate()
SET @RolesFilter=''


 IF @EmployeeOrManager=0
	  BEGIN
	  	-- SET @filterwhere1= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''')   and convert(nchar(10),convert(smalldatetime,'''+@CYear+'''+''-''+'''+@NextMonth+'''+''-01'')-1,120) = CONVERT(NCHAR(10),Getdate(),120)'
	  	 
		 SET  @filterwhere1= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''') and CONVERT(NCHAR(10),GETDATE(),120) IN ('''+@CYear+'''+''-a-31'','''+@CYear+'''+''-06-30'','''+@CYear+'''+''-09-30'','''+@CYear+'''+''-12-31'')'
		PRINT @filterwhere1
	  END
ELSE 
	 BEGIN 
	  	IF ltrim(rtrim(@Roles))<>''
	  	    BEGIN 
	  	      SET @RolesFilter= ' and RoleId in ('+@Roles+')'
	    	END 
	  		
	  	IF @AlertOrSub=0
	  	BEGIN
	  			SET @filterwhere1='  and  HrStatus.PayStatus=1 AND   EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where 1=1 '+@RolesFilter+') and CONVERT(NCHAR(10),GETDATE(),120) IN ('''+@CYear+'''+''-03-31'','''+@CYear+'''+''-06-30'','''+@CYear+'''+''-09-30'','''+@CYear+'''+''-12-31'')'
	  	--and convert(nchar(10),convert(smalldatetime,'''+@CYear+'''+''-''+'''+@NextMonth+'''+''-01'')-1,120) = CONVERT(NCHAR(10),Getdate(),120)'
	  		PRINT @filterwhere1
	  	END 
	  	ELSE
	  	BEGIN
	  		SET @filterwhere1=' and  HrStatus.PayStatus=1  
	  		                     and EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where profileid = case when '+cast(@Profileid AS NVARCHAR(10))+ ' = 0 then profileid else '+cast(@Profileid AS NVARCHAR(10))+ ' end ' +@RolesFilter+') 
	  		                                                                                                                                                              and CONVERT(NCHAR(10),GETDATE(),120) IN ('''+@CYear+'''+''-03-31'','''+@CYear+'''+''-06-30'','''+@CYear+'''+''-09-30'','''+@CYear+'''+''-12-31'')'
	  		                                                                                                                                                              
	  		 --and convert(nchar(10),convert(smalldatetime,'''+@CYear+'''+''-''+'''+@NextMonth+'''+''-01'')-1,120) = CONVERT(NCHAR(10),Getdate(),120)'
	  	END 
	 END 

    	SET @Peroidstart=  CAST(year(GETDATE()) AS nCHAR(4))+'-01-01'
         SET @filterwhere=@filterwhere1 
        
		 DECLARE @Periodfrom as SMALLDATETIME
		 DECLARE @PeriodTo as SMALLDATETIME
		 DECLARE @NoOFdayscont as INT
		 DECLARE @NoOfDaysNonCont INT
		 DECLARE @filtergroup nvarchar(MAX)
		 SET @Periodfrom=@Peroidstart
		 SET @PeriodTo= @EndDate
		 SET @NoOFdayscont =@Period
		 SET @NoOfDaysNonCont=999
		 SET @filtergroup=''
		
DECLARE @empId AS int
DECLARE @VacFrom AS datetime
DECLARE @VacTo AS DATETIME,@tempDate AS DATETIME ,@dofftype AS INT ,@doffday1  AS INT ,@doffday2 AS INT  ,@DayoffdaysCount AS INT,@Tempholidays AS int

DECLARE @PrevEmpID AS int
DECLARE @PrevToDate AS datetime
DECLARE @ContDays AS numeric(18,3)
DECLARE @VacTakenDays AS numeric(18,3)
DECLARE @tempVacDaysoff AS numeric(18,3)=0.0,@tempdate1 AS datetime


SET @PrevEmpID=0
--SELECT @Periodfrom='2015/04/01', @PeriodTo='2015/04/30', @NoOFdayscont=14 ,@NoOfDaysNonCont=999 , @filterselect=' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  '
--, @filterwhere=' and  ( Empassignment.privacy between 0 and 9 ) and  Empassignment.EmployeeId in (5657,5658,5659)  ',@filtergroup='' --5659,
CREATE TABLE #Temp(
               EmpId INT
              ,Employeeid NVARCHAR(50)
              ,NAME nvarchar(100)
              ,AName nvarchar(100)
              ,JobName nvarchar(250)
              ,JobAName nvarchar(250)
              ,OrganizationName nvarchar(250)
              ,OrganizationAName nvarchar(250)
              ,DivisionName nvarchar(250)
              ,DivisionAName nvarchar(250)
              ,FromDate SMALLDATETIME
              ,ToDate SMALLDATETIME
              ,VacTakenDays NUMERIC(18,3)
              ,dofftype int
              ,doffday1 int
              ,doffday2 int
              ,GroupLevel1 int
              ,GroupName1 nvarchar(250)
              ,GroupLevel2 int
              ,GroupName2 nvarchar(250)
              ,GroupLevel3 int
              ,GroupName3 nvarchar(250)
              ,GroupLevel4 int
              ,GroupName4 nvarchar(250)
              ,GroupLevel5 int
              ,GroupName5 nvarchar(250)
              ,GroupLevel6 int
              ,GroupName6 nvarchar(250)
              ,GroupLevel7 int
              ,GroupName7 nvarchar(250)
              ,GroupLevel8 int
              ,GroupName8 nvarchar(250)
                    ) 
                    
DECLARE @holidays AS INT
SET @holidays=0

--(SELECT vacpack FROM vacpack WHERE vacpack=@vacpack and 
--                                vacpack.dofftype=1 and (datepart(dw,@From)=vacpack.doffday1 or datepart(dw,@From)=vacpack.doffday2))   
DECLARE @tempstr AS NVARCHAR(10)=''

set @tempstr= case when @donotcountdayoff=0 THEN '0' ELSE '1' END +','+case when @donotcountholiday=0 THEN '0' ELSE '1' END
                                   

EXEC('INSERT INTO #Temp SELECT 
EmpVacat.empid, empassignment.employeeid, Profile.Name , Profile.AName , Jobs.JobName , JobAName,Organization.OrganizationName,Organization.OrganizationAName,
dbo.GetOrganizationParent(organization.organization,2,1,1,''E'') as DivisionName ,dbo.GetOrganizationParent(organization.organization,2,1,1,''A'') as DivisionAName,
case when '''+@Periodfrom+'''>EmpVacat.FromDate then  '''+@Periodfrom +'''else EmpVacat.FromDate  end  ,
case when'''+ @PeriodTo+''' < EmpVacat.ToDate then '''+@PeriodTo +'''else EmpVacat.ToDate end  ,
dbo.[X_VacTakenDays]( EmpVacat.empid,CASE WHEN '''+@Periodfrom+''' > EmpVacat.FromDate THEN '''+@Periodfrom +''' ELSE EmpVacat.FromDate END  , CASE WHEN '''+@PeriodTo+''' < Empvacat.ToDate THEN '''+@PeriodTo +''' ELSE EmpVacat.ToDate END,EmpVacat.vaccode,'+@tempstr +',0,0,0)
,vacpack.dofftype,vacpack.doffday1 ,vacpack.doffday2
' + @filterselect +'
FROM EmpVacat 
LEFT JOIN Vacation ON EmpVacat.VacCode = Vacation.vaccode 
LEFT JOIN Empassignment on EmpVacat.Empid = EmpAssignment.Empid
LEFT JOIN Profile on EmpVacat.Empid = Profile.ProfileId 
LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
CROSS JOIN SysParam
where EmpVacat.VacStatus=1 and (Vacation.dayfactor>=1 or Vacation.dayfactor=0)
AND ((EmpVacat.FromDate Between '''+@Periodfrom+''' And'''+ @PeriodTo+''')
Or (EmpVacat.ToDate Between '''+@Periodfrom+''' AND'''+ @PeriodTo+''')
Or ('''+@Periodfrom+''' Between EmpVacat.FromDate And EmpVacat.ToDate)
Or ('''+@PeriodTo+''' Between EmpVacat.FromDate And EmpVacat.ToDate)) 
' +@filterwhere +' Order By Empvacat.EmpId, EmpVacat.Fromdate')


--SELECT * FROM #Temp

declare tempemployee cursor FOR
SELECT empid,FromDate, ToDate, VacTakenDays,dofftype,doffday1,doffday2 FROM #Temp

OPEN tempemployee
FETCH NEXT FROM tempemployee
INTO  @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 
WHILE @@FETCH_STATUS = 0
BEGIN 
             
       PRINT @holidays
       PRINT @VacFrom
       PRINT @VacTo 
   IF @empid<>@PrevEmpID 
    BEGIN
       
       ----------------------for prev employee---------------------------------------------------------------------
       
         IF @PrevToDate<@PeriodTo
         BEGIN
              SET @DayoffdaysCount=0
          SET @tempDate=@PrevToDate+1
                     WHILE @tempDate<=@PeriodTo
                     BEGIN
                           SELECT @Tempholidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
                     WHERE EmpAssignment.EmpId=@PrevEmpID and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @tempDate and @tempDate  AND holidays.holiday=1
       
                     IF @Tempholidays<>0 OR ( @dofftype=1 AND (datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2))
                     BEGIN
                           IF  (@dofftype=1 and (@dofftype=1 and datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2)) AND @donotcountdayoff=0
                            --   set @VacTakenDays=@VacTakenDays+1
                                SET @DayoffdaysCount=@DayoffdaysCount+1
                            ELSE 
                           		IF @Tempholidays<>0 AND @donotcountholiday=0 
                           		SET @DayoffdaysCount=@DayoffdaysCount+1
                           
                     END
                     ELSE
                     BEGIN
                           break  
                     END
                     
                     SET @tempDate=@tempDate+1
                     END
                     
              
                                  set @ContDays=@ContDays+@DayoffdaysCount
                     
       
                     if @ContDays>=@NoOfDaysCont
                     BEGIN
--SELECT '5', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                           DELETE FROM #temp WHERE EmpId=@PrevEmpID
                           set @ContDays=0
                     end    
         END
       ------------------------------------------------------------------------------------------
       SET @tempDate=@VacFrom-1
       SET @DayoffdaysCount=0
       WHILE @tempDate>=@Periodfrom
       BEGIN
              SELECT @Tempholidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
       WHERE EmpAssignment.EmpId=@empId and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @tempDate and @tempDate  AND holidays.holiday=1
       
          
       IF @Tempholidays<>0 OR (@dofftype=1 and (datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2))
       BEGIN
       	--SELECT 'test', @DayoffdaysCount,@tempDate
              IF (@dofftype=1 and (datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2)) AND @donotcountdayoff=0
                     set @DayoffdaysCount=@DayoffdaysCount+1
			  ELSE 
					IF @Tempholidays<>0 AND @donotcountholiday=0 
					SET @DayoffdaysCount=@DayoffdaysCount+1
                     
       END
       ELSE
       BEGIN
       --	   	SELECT @DayoffdaysCount,@tempDate
              break  
       END
       
       
              set @tempDate=@tempDate-1
       END


       
       --SELECT @holidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
       --WHERE EmpAssignment.EmpId=@empId and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @VacFrom AND @VacTo AND holidays.holiday=1
       
          set @ContDays=@VacTakenDays+@DayoffdaysCount
          
--SELECT '0', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
              
          if @contDays>=@NoOfDaysCont
         begin
                     DELETE FROM #temp WHERE EmpId=@empId
                 set @ContDays=0
         end
       
       
  END   
   ELSE
   BEGIN
   --  SELECT @VacFrom,@VacTo,@ContDays,@VacTakenDays,@PrevToDate,datepart(dw,@tempDate),@dofftype,@doffday1 , datepart(dw,@tempDate),@doffday2
--SELECT '00', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                     SET @DayoffdaysCount=0
       --        SELECT @holidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
       --WHERE EmpAssignment.EmpId=@empId and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @VacFrom AND @VacTo AND holidays.holiday=1
              
       
       --     set @ContDays=@VacTakenDays-@holidays
                if @VacTakenDays>=@NoOFdayscont
                BEGIN
--SELECT '1', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                     DELETE FROM #temp WHERE EmpId=@PrevEmpID
                 SET @ContDays=0
               
                END 
                ELSE
                     BEGIN
                            SET @tempDate=@PrevToDate+1
                            SET @DayoffdaysCount=0
                     WHILE @tempDate<@VacFrom
                     BEGIN
                           SELECT @Tempholidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
                     WHERE EmpAssignment.EmpId=@empId and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @tempDate and @tempDate  AND holidays.holiday=1
       
                     IF @Tempholidays<>0 OR ( @dofftype=1 AND (datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2))
                     BEGIN
                           IF  (@dofftype=1 and (@dofftype=1 and datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2)) AND @donotcountdayoff=0
								  set @DayoffdaysCount=@DayoffdaysCount+1
                             ELSE 
                           		IF @Tempholidays<>0 AND @donotcountholiday=0 
                           		SET @DayoffdaysCount=@DayoffdaysCount+1
                     END
                     ELSE
                     BEGIN
                           break  
                     END
                     
                     SET @tempDate=@tempDate+1
                     END
                     ----
                     
                     if @ContDays+@DayoffdaysCount>=@NoOfDaysCont
                     BEGIN
--SELECT '2', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                           DELETE FROM #temp WHERE EmpId=@empId
                           set @ContDays=0
                     END
                     ELSE
                           BEGIN
                                  IF @tempDate=@VacFrom
                     BEGIN
                                  set @ContDays=@ContDays+@VacTakenDays+@DayoffdaysCount
--SELECT '3', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                     END
                     ELSE
                     BEGIN
                     SET @tempDate=@VacFrom-1
                     SET @DayoffdaysCount=0
                     WHILE @tempDate>@PrevToDate
                     BEGIN
                     	--SELECT @tempDate,'1'
                                  SELECT @Tempholidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
                           WHERE EmpAssignment.EmpId=@empId and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @tempDate and @tempDate  AND holidays.holiday=1
       
                           IF @Tempholidays<>0 OR ( @dofftype=1 AND (datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2))
                           BEGIN
                                  IF  (@dofftype=1 and (@dofftype=1 and datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2)) AND @donotcountdayoff=0
								    set @DayoffdaysCount=@DayoffdaysCount+1
                             ELSE 
                           		IF @Tempholidays<>0 AND @donotcountholiday=0 
                           		SET @DayoffdaysCount=@DayoffdaysCount+1
                           END
                           ELSE
                           BEGIN
                                  break  
                           END
                     
                           SET @tempDate=@tempDate-1
                           END
   ----                   
                     set @ContDays=@VacTakenDays    +@DayoffdaysCount
--SELECT '4', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                     END
       
                     if @ContDays>=@NoOfDaysCont
                     begin
                           DELETE FROM #temp WHERE EmpId=@empId
                           set @ContDays=0
                     end
                
                           END
                     
                     
                     
                     
              END 
       
  


---------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------

   END
     
     SET @PrevToDate  =@VacTo 
     
       SET @PrevEmpID=@empId
       FETCH NEXT FROM tempemployee
       INTO  @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 
   END
   
CLOSE tempemployee
DEALLOCATE tempemployee    
   

         IF @PrevToDate<@PeriodTo
         BEGIN
              SET @DayoffdaysCount=0
          SET @tempDate=@PrevToDate+1
                     WHILE @tempDate<=@PeriodTo
                     BEGIN
                           SELECT @Tempholidays=COUNT(holiday) from Holidays INNER JOIN EmpAssignment ON EmpAssignment.vacpack = Holidays.vacpack
                     WHERE EmpAssignment.EmpId=@empId and Holidays.vacpack = EmpAssignment.vacpack AND Holidays.[date] BETWEEN @tempDate and @tempDate  AND holidays.holiday=1
       
                     IF @Tempholidays<>0 OR ( @dofftype=1 AND (datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2))
                     BEGIN
                           IF  (@dofftype=1 and (@dofftype=1 and datepart(dw,@tempDate)=@doffday1 or datepart(dw,@tempDate)=@doffday2)) AND @donotcountdayoff=0
								 set @DayoffdaysCount=@DayoffdaysCount+1
                           ELSE 
                           		IF @Tempholidays<>0 AND @donotcountholiday=0 
                           		SET @DayoffdaysCount=@DayoffdaysCount+1
                           
                     END
                     ELSE
                     BEGIN
                           break  
                     END
                     
                     SET @tempDate=@tempDate+1
                     END
                     
              
                                  set @ContDays=@ContDays+@DayoffdaysCount
                     
       
                     if @ContDays>=@NoOfDaysCont
                     BEGIN
--SELECT '5', @empid,@VacFrom,@VacTo,@VacTakenDays,@dofftype,@doffday1,@doffday2 , @DayoffdaysCount,@holidays,@ContDays ----
                           DELETE FROM #temp WHERE EmpId=@empId
                           set @ContDays=0
                     end    
         END
                     
                

--INSERT INTO #Temp
--EXEC('SELECT 
--empassignment.empid, empassignment.employeeid, Profile.Name , Profile.AName , Jobs.JobName , JobAName,
--EmpVacat.FromDate,
--EmpVacat.ToDate,
--datediff(day,CASE WHEN '''+@Periodfrom+''' > EmpVacat.FromDate THEN '''+@Periodfrom +''' ELSE EmpVacat.FromDate END  , CASE WHEN '''+@PeriodTo+''' < Empvacat.ToDate THEN '''+@PeriodTo +''' ELSE EmpVacat.ToDate END )+1 
--,vacpack.dofftype,vacpack.doffday1 ,vacpack.doffday2
--' + @filterselect +'
--FROM EmpAssignment
--LEFT JOIN EmpVacat on EmpVacat.Empid = EmpAssignment.Empid
--and  EmpVacat.VacStatus=1 
--AND ((EmpVacat.FromDate Between '''+@Periodfrom+''' And'''+ @PeriodTo+''')
--Or (EmpVacat.ToDate Between '''+@Periodfrom+''' AND'''+ @PeriodTo+''')
--Or ('''+@Periodfrom+''' Between EmpVacat.FromDate And EmpVacat.ToDate)
--Or ('''+@PeriodTo+''' Between EmpVacat.FromDate And EmpVacat.ToDate)) 

--LEFT JOIN Vacation ON EmpVacat.VacCode = Vacation.vaccode 
--LEFT JOIN Profile on EmpVacat.Empid = Profile.ProfileId 
--LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center 
--LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
--LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
--LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
--LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
--LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
--LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat
--LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
--LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
--LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
--LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
--LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
--LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
--LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
--LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
--LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp 
--CROSS JOIN SysParam
--      where 1=1 and EmpVacat.empid is null 
--' +@filterwhere )

	 IF  @EmployeeOrManager=0
      BEGIN   
      	--Employee subscription
         SELECT DISTINCT PROFILE.ProfileId,(case when CompanyEmail <>'' then Profile.CompanyEmail else Profile.PrivateEmail end) as CompanyEmail
	 	  FROM #Temp LEFT JOIN PROFILE ON PROFILE.ProfileId= #Temp.EmpId 
		  where #Temp.Employeeid not in ('3505735')
		  ORDER by PROFILE.ProfileId
      END 
     
  ELSE
  	IF @AlertOrSub=0
     BEGIN 
     	
     		PRINT 'Manager sub. '
     		
     	    --Manager Subscription
     		EXEC(' select distinct SSGroupRole.ProfileId,
             (CASE WHEN Mang.CompanyEmail<>'''' THEN Mang.CompanyEmail ELSE Mang.PrivateEmail END )AS CompanyEmail
             from #Temp
			 Left JOIN empassignment ON #Temp.EmpId = empassignment.EmpId
			 inner join SSGroupRole on SSGroupRole.SSGroup =EmpAssignment.SSGroup '+@RolesFilter+'
             left join Profile as Mang on Mang.profileid=SSGroupRole.profileid
             where (Mang.CompanyEmail <>'''' OR Mang.PrivateEmail <>'''')' )

     END 
     ELSE 
     	BEGIN 
     		--Manager Alert
     		DECLARE @str AS NVARCHAR(MAX)
     		
			 
			 SET @str = 'SELECT distinct  ''Dear  ''+rtrim(ltrim(isnull(ManagerProfile.FirstName,'''')))+'','' AS Header ,
			 --''Sorry for the inconvenience, Please ignore the previous alert and only consider the below one.'' +Char(13)+Char(10)+Char(13)+Char(10)+
			 ''Kindly note that the below mentioned employees did not take two consecutive weeks of annual leave.'' as Body,
			EmpAssignment.EmployeeId,#Temp.Name, #Temp.OrganizationName ,'+CAST(@period AS NVARCHAR(5))+' as days,
			CASE WHEN EmpAssignment.PositionNo is null THEN  #Temp.JobName ELSE Positions.PositionName END AS Job,
			 '''+LTRIM (RTRIM (@x))+ '''+'' '' as Footer,
			''EndSelect''

			 FROM #Temp
			 LEFT JOIN EmpAssignment  ON EmpAssignment.EmpId = #Temp.EmpId
			 LEFT JOIN Positions ON EmpAssignment.PositionNo=Positions.PositionNo
			  cross join(select FirstName from profile  where profileid = '+cast(@Profileid AS NVARCHAR(10))+') ManagerProfile
 			 where dbo.EmpAssignment.employeeid not in (''3505735'')
			'
           PRINT @str
           EXECUTE (@str ) 
     	END 
DROP TABLE #Temp
END

GO

