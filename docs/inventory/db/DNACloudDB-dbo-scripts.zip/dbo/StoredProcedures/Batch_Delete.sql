

CREATE  PROCEDURE [dbo].[Batch_Delete] (@tablename as nvarchar(150),@tabletype as nvarchar(100),@Where AS nvarchar(max),@Paramaters AS nvarchar(max)) AS
DECLARE @outstr AS nvarchar(max)
DECLARE @str AS nvarchar(max)
--set @str = 'EXEC [batch'+ltrim(rtrim(@tabletype))+']  1,''' + @tablename  +''',0,@formulaOutput output'

DECLARE @actualtablename AS nvarchar(150)
SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName LIKE @tabletype

IF ltrim(rtrim(@tabletype)) ='WP_GetExternalVacDueAdjust'OR ltrim(rtrim(@tabletype)) ='WP_GetExternalVacDueAdjust_ar'  EXEC BatchWP_GetExternalVacDueAdjust 5,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimePermission'OR ltrim(rtrim(@tabletype)) ='WP_GetExternalTimePermission_ar'  EXEC BatchWP_GetExternalTimePerm 5,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_LoadPaymentData' OR ltrim(rtrim(@tabletype)) ='WP_LoadPaymentData_ar' EXEC BatchWP_LoadPaymentData 5,@tablename ,0,@Where,@Paramaters,@outstr output
ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalTimeKeepingRecords_ar' EXEC BatchWP_GetExternalTimeKeepingRecords 5,@tablename ,0,@Where,@Paramaters,@outstr OUTPUT

ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales_ar%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales%' EXEC BatchWP_ExportBenefitSalaryScales 5,@tablename ,0,@Where,@Paramaters,'',@outstr OUTPUT
-----------------------------------------------------------Export Salary Scales Details
ELSE
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails_ar%' OR ltrim(rtrim(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails%' EXEC BatchWP_ExportSalaryScalesDetails 5,@tablename ,0,@Where,@Paramaters,'',@outstr OUTPUT

ELSE
IF ltrim(rtrim(@tabletype)) ='WP_GetExternalVacRecords' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalVacRecords_ar' EXEC BatchWP_GetExternalVacRecords 5,@tablename ,0,@Where,@Paramaters,@outstr output

IF ltrim(rtrim(@tabletype)) ='WP_AssignSelfServiceGroups' OR ltrim(rtrim(@tabletype)) ='WP_AssignSelfServiceGroups' EXEC [BatchWP_AssignRole] 5,@tablename ,0,@Where,@Paramaters,@outstr output

GO

