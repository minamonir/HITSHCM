CREATE PROCEDURE [dbo].[BatchWP_GetExternalAppraisalCompDataFile]( @tablename NVARCHAR(max) ,@lang AS NVARCHAR(10),@enterby AS INT , @ActivityDate AS smalldatetime 

)
AS 
BEGIN
			CREATE TABLE #EndResultPagging (NAME NVARCHAR(88) , ANAME NVARCHAR(88), JobName NVARCHAR(250), JobAName NVARCHAR(250), OrganizationName NVARCHAR(250), OrganizationAName NVARCHAR(250)
								,HireDate SMALLDATETIME ,StartDate SMALLDATETIME , EndDate SMALLDATETIME ,Expired BIT , EnterDate SMALLDATETIME,SSDocName NVARCHAR(60),SSDocAName NVARCHAR(60),SSDocExpire SMALLINT 
								,EmployeeId NVARCHAR(50), DocumentNo INT , ACTIONReason NVARCHAR(MAX) , ApprovalStatusApp SMALLINT , ApprovalStatusRej SMALLINT,EmpId INT ,SSDocNo SMALLINT 
								,EnterBy INT , AppraisalNo SMALLINT , AppraisalName NVARCHAR(60), AppraisalAName NVARCHAR(60) , AppraisalDate SMALLDATETIME , NextAppraisalDate SMALLDATETIME
								,AppraisalResult NUMERIC(18,3), Dummy NUMERIC(18,3) ,AutoResultTxt NVARCHAR(max),AutoResultATxt NVARCHAR(max),CompetenceResult NUMERIC(18,3),ObjectiveResult NUMERIC(18,3),Dummy2 NUMERIC(18,3)
								,Dummy3 NUMERIC(18,3),AppraisalText NVARCHAR(max),Proficiency BIT ,Performance BIT, SelfAppraisal BIT , ManualResultTxt NVARCHAR(max),ManualResultATxt NVARCHAR(max)
								,AutoObjResultTxt NVARCHAR(max),AutoObjResultATxt NVARCHAR(max) ,Objective BIT , MultiRater BIT , URL NVARCHAR(max),AURL NVARCHAR(max), onbehaveof NVARCHAR(max), Aonbehaveof NVARCHAR(max)
								,LM smallint, LOR SMALLINT, LOW SMALLINT, LCR SMALLINT,MaxObjScore SMALLINT,MisconductValid SMALLINT, [ROW_NUMBER] SMALLINT)

								INSERT INTO #EndResultPagging
								EXEC [dbo].[hits_GetWFAppraisalRequiredWithPaging] @RoleProfileid= @EnterBy, @where = '', @ssdoctype = 6, @action = '1', @p_sort_str = '', @p_page_number = 1, @p_batch_size = 9999,@count =0
	
	
	DECLARE @selectStmt AS NVARCHAR(MAX)=''
	DECLARE @ParmDefinition NVARCHAR(500);  
	DECLARE @comp AS NVARCHAR(MAX)=''
	DECLARE @appraisals AS NVARCHAR(MAX)=''
	select @selectStmt= 'select @Competencies= @Competencies+ ''[''+ Column_name+'']'' + '','' FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns  WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+'''
	and Column_name not in (''EmpId'',''Name'',''Post'',''Remarks'',''ProcessTime'',''Row_number'') '
	SET @ParmDefinition = N'@Competencies nvarchar(max)='''' OUTPUT';  
	
	EXECUTE sp_executesql @selectStmt, @ParmDefinition,    @Competencies = @comp OUT ;  
	SELECT @comp=SUBSTRING(@comp,1,LEN(@comp)-1)
	
	

	SELECT @appraisals=@appraisals +LTRIM(RTRIM(app.appraisalno)) +','
					FROM (SELECT DISTINCT appraisals.appraisalno ,appraisals.AppraisalFromDate,appraisals.AppraisalToDate,appraisals.AppraisalNoCons
							FROM #EndResultPagging
				      inner JOIN appraisals ON appraisals.AppraisalNo = #EndResultPagging.AppraisalNo
				      and @ActivityDate between isnull(appraisals.AppraisalFromDate,@ActivityDate) and isnull(appraisals.AppraisalToDate,@ActivityDate)
				      	and appraisals.appraisalnocons=1 ) app
				inner join AppraisalCompetencies on app.appraisalno =AppraisalCompetencies.appraisalno
				left join competencies on competencies.Competence=AppraisalCompetencies.competence
				where @ActivityDate between isnull(app.AppraisalFromDate,@ActivityDate) and isnull(app.AppraisalToDate,@ActivityDate)
				and app.appraisalnocons=1
	GROUP BY app.appraisalno
	
	SELECT @appraisals=SUBSTRING(@appraisals,1,LEN(@appraisals)-1)

	
	
	
	CREATE TABLE #EmpAppraisalComp(EmpId INT , Documentno INT ,RaterProfileId int , Competence SMALLINT,RatingLevel smallint )
	
	INSERT INTO #EmpAppraisalComp 

	EXEC ('SELECT #EndResultPagging.EmpId ,#EndResultPagging.Documentno ,case when appraisals.MultiRater=1 then '+@enterby+' else #EndResultPagging.empid END AS RaterProfileId ,Competencies.Competence ,RatingLevels.ratingLevel
FROM (
SELECT EmpId ,CompetenceName,RatingLevel
FROM   
   (SELECT *
   FROM '+@tablename+' WHERE post =1) p  
UNPIVOT  
   (RatingLevel FOR CompetenceName IN   
      ('+@comp+')   
)AS unpvt  ) t
left join empassignment on ltrim(rtrim(empassignment.employeeid))=ltrim(rtrim(t.empid))
LEFT JOIN Competencies ON CASE WHEN '''+@lang+'''=''e'' THEN Competencies.CompetenceName ELSE Competencies.CompetenceaName END =t.CompetenceName
inner join #EndResultPagging on #EndResultPagging.empid =empassignment.empid and #EndResultPagging.Appraisalno in ('+@appraisals+')

Inner join  (select ea.empid , ac.Competence,ea.appraisalno ,max(ea.appraisaldate) as appraisaldate
            from empassignment emp
            inner join #EndResultPagging  ea on ea.empid =emp.empid and ea.appraisalno in ('+ @appraisals+') 
            left join appraisals a on a.appraisalno =ea.appraisalno
            inner join appraisalcompetencies ac on ac.appraisalno =ea.appraisalno
            where ea.appraisalDate between  isnull(a.AppraisalFromDate,ea.appraisalDate) and isnull(a.AppraisalToDate,ea.appraisalDate) 
            group by ea.empid, ac.Competence ,ea.appraisalno) app on app.empid=empassignment.empid and app.competence=Competencies.competence and app.appraisalno= #EndResultPagging.appraisalno and app.appraisaldate=#EndResultPagging.appraisaldate
left join appraisals on appraisals.appraisalno =  #EndResultPagging.appraisalno
left join RatingLevels on RatingLevels.RatingScale =appraisals.ratingscale and case when '''+@lang+'''=''e'' then ltrim(rtrim(RatingLevels.LevelName)) else ltrim(rtrim(RatingLevels.LevelAName)) end =ltrim(rtrim(t.RatingLevel))
 where #EndResultPagging.appraisalDate between  isnull(appraisals.AppraisalFromDate,#EndResultPagging.appraisalDate) and isnull(appraisals.AppraisalToDate,#EndResultPagging.appraisalDate)  ')



 --select EmpAppraisal.EmpId , EmpAppraisal.Documentno , EmpAppraisal.RatingLevel , EmpAppraisal.Appraisalno from  #EmpAppraisalComp
 --left join EmpAppraisalComp  on #EmpAppraisalComp.EmpId= EmpAppraisalComp.EmpId 
 --left join EmpAppraisal on EmpAppraisal.DocumentNo=EmpAppraisalComp.DocumentNo 
 --left join appraisals on appraisals.AppraisalNo=EmpAppraisal.Appraisalno
 --where appraisals.AppraisalNoCons= 1 and EmpAppraisal.AppraisalStatus<>1 and EmpAppraisal.AppraisalStatus<>2

 --SELECT * FROM #EmpAppraisalComp	

 --if Exists (select * from EmpAppraisalComp eac
 --           join #EmpAppraisalComp #eac 
	--		on eac.EmpId=#eac.EmpId and eac.Competence=#eac.Competence and
 --           eac.RaterProfileId=#eac.RaterProfileId and eac.DocumentNo=#eac.Documentno ) 
 -- begin
 --  update EmpAppraisalComp
 --  set EmpAppraisalComp.RatingLevel = #eac.RatingLevel
 --  from EmpAppraisalComp eac
 --  JOIN #EmpAppraisalComp #eac 
 --  on eac.EmpId=#eac.EmpId and eac.Competence=#eac.Competence and
 --  eac.RaterProfileId=#eac.RaterProfileId and eac.DocumentNo=#eac.Documentno 
 -- --update EmpAppraisalComp 
 -- --set EmpAppraisalComp.RatingLevel =(select #eac.RatingLevel
 -- --                                    from   #EmpAppraisalComp #eac
 -- --                                    where  EmpAppraisalComp.EmpId=#eac.EmpId and EmpAppraisalComp .Competence=#eac.Competence and
 -- --                                    EmpAppraisalComp.RaterProfileId=#eac.RaterProfileId and EmpAppraisalComp.DocumentNo=#eac.Documentno)

 -- end
 --else
 -- begin
 --  insert into EmpAppraisalComp(EmpId, DocumentNo, RaterProfileId, Competence, RatingLevel)
 --  select EmpId, Documentno, RaterProfileId, Competence, RatingLevel
 --  from   #EmpAppraisalComp
 --  where  EmpId=#EmpAppraisalComp.EmpId and Competence=#EmpAppraisalComp.Competence and
 --         RaterProfileId=#EmpAppraisalComp.RaterProfileId and DocumentNo=#EmpAppraisalComp.Documentno
 -- end
 
    update EmpAppraisalComp
   set EmpAppraisalComp.RatingLevel = #eac.RatingLevel
   from EmpAppraisalComp eac
   INNER JOIN #EmpAppraisalComp #eac  on eac.EmpId=#eac.EmpId and eac.Competence=#eac.Competence AND eac.RaterProfileId=#eac.RaterProfileId and eac.DocumentNo=#eac.Documentno 

   insert into EmpAppraisalComp(EmpId, DocumentNo, RaterProfileId, Competence, RatingLevel)
   select #eac .EmpId, #eac .Documentno,#eac.RaterProfileId, #eac.Competence, #eac.RatingLevel
   from   #EmpAppraisalComp #eac 
   LEFT  JOIN EmpAppraisalComp eac  on eac.EmpId=#eac.EmpId and eac.Competence=#eac.Competence AND eac.RaterProfileId=#eac.RaterProfileId and eac.DocumentNo=#eac.Documentno 
   WHERE eac.empid IS NULL 

 
  --merge EmpAppraisalComp as eac
  --using #EmpAppraisalComp as #eac
  --on (eac.EmpId=#eac.EmpId and eac.Competence=#eac.Competence and
  --    eac.RaterProfileId=#eac.RaterProfileId and eac.DocumentNo=#eac.Documentno) 
  --when matched then
  -- update set eac.RatingLevel = #eac.RatingLevel
  --when not matched by target then
  -- insert (EmpId, DocumentNo, RaterProfileId, Competence, RatingLevel)
  -- values (#eac.EmpId, #eac.Documentno, #eac.RaterProfileId, #eac.Competence, #eac.RatingLevel);





 drop table #EmpAppraisalComp
END

GO

