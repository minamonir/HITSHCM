CREATE PROCEDURE [dbo].[BankInfoChanges] (@runno Int, @netortotal INT,@from int,@to int,@filterselect nvarchar(max)='',@filterwhere nvarchar(max)='',@filtergroup nvarchar(max)='')
AS
BEGIN
SET NOCOUNT ON;
--drop table #ChangedBankInfofff
--drop table #ChangedBankInfoDetails
declare @newPayBankNo as int,@newPayBankAct as nchar(30),@newSwiftcode as nchar(20),@empid as int,@PaymentType as int,@tempPaymentType as int,
@tempEmpId as int,@TempPayBankNo as int,@tempPayBankAct as nchar(30),@tempSwiftcode as nchar(20),@tempYear as int,@tempMonth as int
,@tempRunNo as int

----------------------------------------------------------------------------------
--,@from int ,@to int,@filterselect nvarchar(max),@filterWhere nvarchar(max),@filtergroup nvarchar(max) ,
--@runno Int--,@netortotal int
,@select nvarchar(max),@fromclause nvarchar(max),@where nvarchar(max)
--------------------------------------------------
set @from= 0
set @to=0
set @runno=1
--
--declare @netortotal as int
--set @netortotal=1
---------------------------------------------------------------------------------------------
create table #ChangedBankInfofff
(empid int,PaymentType int,ChangeYear int,Changemonth int,runno int,oldpaybankno int, oldpaybankAct nchar(30),oldswiftcode nchar(20)
)
create table #ChangedBankInfoDetails
(empid int,PaymentType int,ChangeYear int,Changemonth int,runno int,oldpaybankno int,newpaybankno int,oldpaybankAct nchar(30),newpaybankAct nchar(30),oldswiftcode nchar(20),newswiftcode nchar(20)
)
-----------------------------------------

	if (@from=0)
	begin
		Set @filterwhere = Replace(@filterwhere, 'HistoryPAYMENT', 'monthlypayment')
		Set @filterwhere = Replace(@filterwhere, 'HistoryTransaction','monthlytransaction')

		set @select ='insert into #ChangedBankInfofff select distinct 
		Monthlypayment.empid,Monthlypayment.PaymentType,payrollgroup.cyear,payrollgroup.cmonth,Monthlypayment.runno,Monthlypayment.paybankno
		,ltrim(rtrim(Monthlypayment.paybankAct ))
		,ltrim(rtrim(Monthlypayment.swiftcode))
		from Monthlypayment
			left join empassignment on Monthlypayment.empid=empassignment.empid '
			+' LEFT JOIN MonthlyTransaction ON MonthlyTransaction.EmpId = MonthlyPayment.EmpId
			AND MonthlyTransaction.RunNo= MonthlyPayment.RunNo'
			+' LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId '
			+' LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job'
			+' LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat'
			+' LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo'
			+' LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup'
			+' LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center'
			+' LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp'
			+' LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo'
			+' LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade'
			+' LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId'
			+' LEFT JOIN Organization ON EmpAssignment.PayOrganization = Organization.Organization'
			+' LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType'
			+' LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization'
			+' LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'''
			+' WHERE EmpAssignment.Status=1 
			and Monthlypayment.Runno between (case when   '+ rtrim(ltrim(str(@netortotal))) +' =1 then 
			'+ rtrim(ltrim(str(@runno))) +' else 1 end) and '+ rtrim(ltrim(str(@runno))) +' '			--+ltrim(rtrim(@filterwhere))
		
			execute (@select +' ' +@filterwhere)

		if @to=0
		begin
			--Get History records for Previous (@TO)
            set @filterwhere = Replace(@filterwhere, 'monthlypayment', 'HistoryPAYMENT')
			Set @filterwhere = Replace(@filterwhere, 'monthlytransaction','HistoryTransaction')
			set @select=''
			set @select='insert into #ChangedBankInfofff select Distinct historypayment.empid,
			historypayment.PaymentType,historypayment.year,historypayment.month,historypayment.runno,historypayment.paybankno
			,ltrim(rtrim(historypayment.paybankAct )),ltrim(rtrim(historypayment.swiftcode))
			
			from historypayment 
			left join empassignment on historypayment.empid=empassignment.empid 
			left join payrollgroup on empassignment.payrollgroup=payrollgroup.payrollgroup '
			+' left JOIN HistoryTransaction ON HistoryPayment.Year = HistoryTransaction.Year  
			AND HistoryPayment.Month = HistoryTransaction.Month  
			AND HistoryPayment.EmpId = HistoryTransaction.EmpId  
			AND HistoryPayment.RunNo = HistoryTransaction.RunNo '
			+' left JOIN HistoryPayroll on HistoryTransaction.EmpId=HistoryPayroll.Empid and HistoryTransaction.Year=HistoryPayroll.Year and HistoryTransaction.Month=HistoryPayroll.Month and HistoryTransaction.Runno=HistoryPayroll.Runno '
			+' LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId '
			+' LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job '
			+' LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat '
			+' LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo '
			+' LEFT JOIN CostCntr ON HistoryPayroll.Center = CostCntr.Center '
			+' LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp '
			+' LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo '
			+' LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode '
			+' LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade '
			+' LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId '
			+' LEFT JOIN Organization ON HistoryPayroll.PayOrganization = Organization.Organization '
			+' LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType '
			+' LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization '
			+' LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' '
			+' where historypayment.year=( case when Payrollgroup.CMonth=1 then Payrollgroup.CYear-1 else Payrollgroup.CYear end )and historypayment.month=( case when Payrollgroup.CMonth=1 then 12 else Payrollgroup.Cmonth-1 end) 
			and historypayment.Runno between (case when   '+ rtrim(ltrim(str(@netortotal))) +' =1 then 
			'+ rtrim(ltrim(str(@runno))) +' else 1 end) and '+ rtrim(ltrim(str(@runno))) +' '		
--print @Select
			execute(@select+' '+@filterwhere)
		end
	  end
	else
			Begin
			Set @filterwhere = Replace(@filterwhere, 'monthlypayment', 'HistoryPAYMENT')
			Set @filterwhere = Replace(@filterwhere, 'monthlytransaction','HistoryTransaction')
			set @select=''
			set @select=' insert into #ChangedBankInfofff select distinct historypayment.empid,historypayment.PaymentType,
			historypayment.year,historypayment.month,historypayment.runno,historypayment.paybankno,
			ltrim(rtrim(historypayment.paybankAct )),ltrim(rtrim(historypayment.swiftcode)) 
			from historypayment 
			left join empassignment on historypayment.empid=empassignment.empid 
			left join payrollgroup on empassignment.payrollgroup=payrollgroup.payrollgroup '
			+' left JOIN HistoryTransaction ON HistoryPayment.Year = HistoryTransaction.Year   
			AND HistoryPayment.Month = HistoryTransaction.Month 
			AND HistoryPayment.EmpId = HistoryTransaction.EmpId  
			AND HistoryPayment.RunNo = HistoryTransaction.RunNo '
			+' left JOIN HistoryPayroll on HistoryTransaction.EmpId=HistoryPayroll.Empid and HistoryTransaction.Year=HistoryPayroll.Year and HistoryTransaction.Month=HistoryPayroll.Month and HistoryTransaction.Runno=HistoryPayroll.Runno'
			+' LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId '
			+' LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job '
			+' LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat '
			+' LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo '
			+' LEFT JOIN CostCntr ON HistoryPayroll.Center = CostCntr.Center '
			+' LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp '
			+' LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo '
			+' LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode '
			+' LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade '
			+' LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId '
			+' LEFT JOIN Organization ON HistoryPayroll.PayOrganization = Organization.Organization '
			+' LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType '
			+' LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization '
			+' LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'''
			+' where  historypayment.year * 100 + historypayment.month between '+ rtrim(ltrim(str(@from))) +' and '+ rtrim(ltrim(str(@to))) +'  
			and historypayment.Runno between (case when   '+ rtrim(ltrim(str(@netortotal))) +' =1 then 
			'+ rtrim(ltrim(str(@runno))) +' else 1 end) and '+ rtrim(ltrim(str(@runno))) +' '			--+ rtrim(ltrim(@filterwhere))
			
			execute(@select +' ' + @filterwhere)
			End




      /*Set @filterwhere = Replace(@filterwhere,  'monthlypayment','historypayment')
      Set @filterwhere = Replace(@filterwhere,'monthlytransaction', 'historytransaction')
          declare @To2 as nchar(150)
      if @to=0 set @To2='CASE WHEN CPayrollGroup.cmonth = 1 THEN (CPayrollGroup.cyear - 1) * 100 + 12 ELSE (CPayrollGroup.cyear) * 100 + CPayrollGroup.cmonth - 1 END' 
	else set @To2=str(@To)*/


--print @To2

---------------------------------------------
DECLARE test_cursor CURSOR FOR 
------------------------------select Monthly & history-----------------------------------------------------------------
select #ChangedBankInfofff.empid,#ChangedBankInfofff.PaymentType,#ChangedBankInfofff.ChangeYear,
#ChangedBankInfofff.Changemonth,#ChangedBankInfofff.runno,
#ChangedBankInfofff.oldpaybankno, #ChangedBankInfofff.oldpaybankAct,#ChangedBankInfofff.oldswiftcode

from #ChangedBankInfofff
left join empassignment on #ChangedBankInfofff.empid=empassignment.empid
left join payrollgroup on empassignment.payrollgroup=payrollgroup.payrollgroup
order by 1,2,3,4,5

---------------------------------------------------------cursor--------------------------------------------------
open test_cursor
FETCH NEXT FROM test_cursor into @tempEmpId,@tempPaymentType,@tempyear,@tempMonth,@tempRunNo,@TempPayBankNo,@tempPayBankAct,@tempSwiftcode
WHILE @@FETCH_STATUS = 0
begin
-------------------
-----------------
if((@empid=@tempempid)and (@PaymentType=@tempPaymentType)and((@TempPayBankNo<>@newPayBankNo) or (@tempPayBankAct<>@newPayBankAct) or (@tempSwiftcode<>@newSwiftcode)))
insert into #ChangedBankInfoDetails values
(@tempEmpId,@tempPaymentType,@tempyear,@tempMonth,@tempRunNo,@newPayBankNo,@TempPayBankNo,@newPayBankAct,@tempPayBankAct,@newSwiftcode,@tempSwiftcode)

set @empid=@tempEmpId
set @PaymentType=@tempPaymentType
set @newPayBankNo=@TempPayBankNo
set @newPayBankAct=@tempPayBankAct
set @newSwiftcode=@tempSwiftcode

FETCH NEXT FROM test_cursor into @tempEmpId,@tempPaymentType,@tempyear,@tempMonth,@tempRunNo,@TempPayBankNo,@tempPayBankAct,@tempSwiftcode
end
---------------------------------------------------------------
CLOSE test_cursor
DEALLOCATE test_cursor

set @filterselect=''
set @select = ''
set @select = ' select  *,empassignment.employeeid,Profile.Name,Profile.AName '+ @filterselect
set @fromclause = ' from #ChangedBankInfoDetails '

+' LEFT JOIN EmpAssignment ON #ChangedBankInfoDetails.EmpId = EmpAssignment.empid'
+' LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId '
+' LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job'
+' LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat'
+' LEFT JOIN Location ON Location.LocationNo = EmpAssignment.LocationNo'
+' LEFT JOIN PayrollGroup ON PayrollGroup.PayrollGroup = EmpAssignment.PayrollGroup'
+' LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center'
+' LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp'
+' LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo'
+' LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade'
+' LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId'
+' LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization'
+' LEFT JOIN OrganizationType ON Organization.OrganizationType = OrganizationType.OrganizationType'
+' LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization'
+' LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1'
+' LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 '
+' LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3'
+' LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4'
+' LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5'
+' order by 1,2,3,4,5'


--set @Where=@filterWhere
--set @filterwhere=' order by 1,2,3,4'

execute (@select+@fromclause+' '+@filtergroup)
---------------------------------------------------------------------------------
end



--select * from #ChangedBankInfoDetails

GO

