CREATE PROCEDURE [dbo].[AI_InsertEmpQualification]
    @EmpId INT,
    @QualificationNo SMALLINT,
    @AttendFromDate SMALLDATETIME = NULL,
    @AttendToDate SMALLDATETIME = NULL,
    @Establishment SMALLINT = NULL,
    @QualificationGrade SMALLINT = NULL,
    @QualificationMajor SMALLINT = NULL,
    @QualificationScore NUMERIC(18,3) = NULL,
    @QualificationTotalScore NUMERIC(18,3) = NULL,
    @QualificationApprovedDate DATETIME = NULL,
    @LicenseNo NVARCHAR(20) = NULL,
    @LicenseExpDate SMALLDATETIME = NULL,
    @QualificationInfo NVARCHAR(MAX) = NULL,
    @Job SMALLINT = NULL,
    @PositionNo SMALLINT = NULL,
    @QualificationCurrency SMALLINT = NULL,
    @QualificationSalary NUMERIC(18,3) = NULL,
    @QualificationBenefit NUMERIC(18,3) = NULL,
    @EmpQualificationGUID UNIQUEIDENTIFIER = NULL
AS
BEGIN
    SET NOCOUNT ON;

    ---- If GUID not provided, generate a new one
    --IF @EmpQualificationGUID IS NULL
    --    SET @EmpQualificationGUID = NEWID();
	--select @EmpId, @QualificationNo, @AttendFromDate, @AttendToDate, @Establishment,
 --           @QualificationGrade, @QualificationMajor
       
    INSERT INTO dbo.EmpQualification
           (EmpId, QualificationNo, AttendFromDate, AttendToDate, Establishment,
            QualificationGrade, QualificationMajor, QualificationScore, QualificationTotalScore,
            QualificationApprovedDate, LicenseNo, LicenseExpDate, QualificationInfo, Job, PositionNo,
            QualificationCurrency, QualificationSalary, QualificationBenefit)
    VALUES
           (@EmpId, @QualificationNo, cast( @AttendFromDate as date), cast( @AttendToDate as date), @Establishment,
            @QualificationGrade, @QualificationMajor, @QualificationScore, @QualificationTotalScore,
            cast( @QualificationApprovedDate as date), @LicenseNo, @LicenseExpDate, @QualificationInfo, @Job, @PositionNo,
            @QualificationCurrency, @QualificationSalary, @QualificationBenefit)
END

GO

