
CREATE PROC [dbo].[Alert_Employeeswznocontiouslyvacation] 
               (@Period SMALLINT ,@PayrollOrCal SMALLINT=0 ,@EmployeeOrManager SMALLINT=0,@AlertOrSub AS SMALLINT=0,@Roles AS NVARCHAR(MAX),@Profileid AS INT=0,@donotcountdayoff AS BIT=0,@donotcountholiday AS BIT=0, @x AS NVARCHAR (250)='')
AS 
BEGIN
-- @Period : number of continuous day 
-- @EmployeeOrManager :
-- 0: employee  
-- 1: Manager 
-- @AlertOrSub :
-- 0: subscription
-- 1: Alert
-- @PayrollOrCal :
-- 0: payroll year 
-- 1: calender year
-- @Roles : will contain the RoleIds separated by commas
-- @ProfileId : will contain the profile id of the role in case of manager alert	
--@donotcountdayoff :0
--@donotcountholiday:1
	CREATE TABLE #Temp1 (
               EmpId INT
              ,Employeeid nvarchar(50)
              ,NAME nvarchar(88)
              ,AName nvarchar(88)
              ,JobName nvarchar(250)
              ,JobAName nvarchar(250)
              ,OrganizationName nvarchar(250)
              ,OrganizationAName nvarchar(250)
              ,DivisionAName nvarchar(60)
              ,DivisionName nvarchar(60)
              ,GroupLevel1 int
              ,GroupName1 nvarchar(250)
              ,GroupLevel2 int
              ,GroupName2 nvarchar(250)
              ,GroupLevel3 int
              ,GroupName3 nvarchar(250)
              ,GroupLevel4 int
              ,GroupName4 nvarchar(250)
              ,GroupLevel5 int
              ,GroupName5 nvarchar(250)
              ,GroupLevel6 int
              ,GroupName6 nvarchar(250)
              ,GroupLevel7 int
              ,GroupName7 nvarchar(250)
              ,GroupLevel8 int
              ,GroupName8 nvarchar(250))


DECLARE @cur_statment NVARCHAR(MAX)
DECLARE @Peroidstart SMALLDATETIME
DECLARE @filterselect nvarchar(MAX)
DECLARE @filterswhere nvarchar(MAX),@filterswhere1 NVARCHAR(MAX)
DECLARE @payrollgroup SMALLINT
DECLARE @EndDate SMALLDATETIME
DECLARE @RolesFilter NVARCHAR(250)
--schedule preparations
DECLARE @FebruaryEnd AS NCHAR(10)
--schedule preparations
DECLARE @CYear AS NCHAR(4)
SELECT @CYear = ltrim(rtrim(STR(YEAR(GETDATE()))))


SELECT @FebruaryEnd = CONVERT(NCHAR(10),DATEADD(dd,-1,@cyear+'-03-01'),120)
PRINT @FebruaryEnd

SET @filterselect=' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  '
set @EndDate=  getdate()
SET @RolesFilter=''

 IF @EmployeeOrManager=0
	  BEGIN
	  	  --SET @filterswhere1= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''') and convert(nchar(10),convert(smalldatetime,'''+@CYear+'''+''-''+'''+@NextMonth+'''+''-01'')-1,120) = CONVERT(NCHAR(10),Getdate(),120)'
		 SET @filterswhere1= ' and  HrStatus.PayStatus=1 AND (Profile.CompanyEmail <>'''' OR Profile.PrivateEmail <>'''') and CONVERT(NCHAR(10),GETDATE(),120) IN ('''+@FebruaryEnd+''','''+@CYear+'''+''-05-31'','''+@CYear+'''+''-08-31'','''+@CYear+'''+''-11-30'')'
	  	 PRINT @filterswhere1
	  END
ELSE 
	 BEGIN 
	  	IF ltrim(rtrim(@Roles))<>''
	  	    BEGIN 
	  	      SET @RolesFilter= ' and RoleId in ('+@Roles+')'
	    	END 
	  		
	  	IF @AlertOrSub=0
	  	BEGIN
	  		SET @filterswhere1='  and  HrStatus.PayStatus=1 AND EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where 1=1 '+@RolesFilter+') and CONVERT(NCHAR(10),GETDATE(),120) IN ('''+@FebruaryEnd+''','''+@CYear+'''+''-05-31'','''+@CYear+'''+''-08-31'','''+@CYear+'''+''-11-30'')'
	  	END 
	  	ELSE
	  	BEGIN
	  		SET @filterswhere1=' and  HrStatus.PayStatus=1  
	  		                   and EmpAssignment.SSGroup in (select distinct ssgroup from SSGroupRole where profileid = case when '+cast(@Profileid AS NVARCHAR(10))+ ' = 0 then profileid else '+cast(@Profileid AS NVARCHAR(10))+ ' end ' +@RolesFilter+') and CONVERT(NCHAR(10),GETDATE(),120) IN ('''+@FebruaryEnd+''','''+@CYear+'''+''-05-31'','''+@CYear+'''+''-08-31'','''+@CYear+'''+''-11-30'')'
	  	
	  	END 
	 END 
IF  @PayrollOrCal =0 
BEGIN
             
SELECT @cur_statment= 'Declare payrollCur1 Cursor FOR SELECT  PayrollGroup.PayrollGroup, dbo.periodstart(PayrollGroup.PayrollGroup,1,0) FROM PayrollGroup'
exec ( @cur_statment)

Open payrollCur1
Fetch next from payrollCur1 into @payrollgroup,@Peroidstart
while @@FETCH_STATUS=0
BEGIN
	  SET @filterswhere=@filterswhere1+' and EmpAssignment.PayrollGroup='+CONVERT(NVARCHAR(5),@payrollgroup)
	  
	  PRINT @filterswhere
	  INSERT INTO #Temp1
      exec [GetEmployeesListwznocontiouslyvacation] @Peroidstart,@EndDate, @Period,999, @filterselect,@filterswhere, ' ',@donotcountdayoff,@donotcountholiday
   
	 Fetch next from payrollCur1 into  @payrollgroup,@Peroidstart   
END

close payrollcur1
deallocate payrollcur1
END 

ELSE
    BEGIN
    	SET @Peroidstart=  CAST(year(GETDATE()) AS nCHAR(4))+'-01-01'
         SET @filterswhere=@filterswhere1   
	     INSERT INTO #Temp1
         exec [GetEmployeesListwznocontiouslyvacation] @Peroidstart,@EndDate, @Period,999, @filterselect,@filterswhere, ' ',@donotcountdayoff,@donotcountholiday	
	END 
	
	--------------------------------------------------------------------
	--------------------------------------------------------------------
	
  IF  @EmployeeOrManager=0
      BEGIN   
      	--Employee subscription
         SELECT DISTINCT PROFILE.ProfileId,(case when CompanyEmail <>'' then Profile.CompanyEmail else Profile.PrivateEmail end) as CompanyEmail
	 	  FROM #Temp1 LEFT JOIN PROFILE ON PROFILE.ProfileId= #Temp1.EmpId order by PROFILE.ProfileId
      END 
     
  ELSE
  	IF @AlertOrSub=0
     BEGIN 
     	    --Manager Subscription
     		EXEC(' select distinct SSGroupRole.ProfileId,
             (CASE WHEN Mang.CompanyEmail<>'''' THEN Mang.CompanyEmail ELSE Mang.PrivateEmail END )AS CompanyEmail
             from #Temp1
			 Left JOIN empassignment ON #Temp1.EmpId = empassignment.EmpId
			 inner join SSGroupRole on SSGroupRole.SSGroup =EmpAssignment.SSGroup '+@RolesFilter+'
             left join Profile as Mang on Mang.profileid=SSGroupRole.profileid
             where (Mang.CompanyEmail <>'''' OR Mang.PrivateEmail <>'''')' )

     END 
     ELSE 
     	BEGIN 
     		--Manager Alert
     		DECLARE @str AS NVARCHAR(MAX)
     		
			 
			 SET @str = 'SELECT distinct  ''Dear  ''+rtrim(ltrim(isnull(ManagerProfile.FirstName,'''')))+'','' AS Header ,
			 ''Kindly note that the below mentioned employees did not take 2 consecutive weeks of annual leave.'' as Body,
			EmpAssignment.EmployeeId,#Temp1.Name, #Temp1.OrganizationName ,'+CAST(@period AS NVARCHAR(5))+' as days,
			CASE WHEN EmpAssignment.PositionNo is null THEN  #Temp1.JobName ELSE Positions.PositionName END AS Job,
			 '''+LTRIM (RTRIM (@x))+ '''+'' '' as Footer,
			''EndSelect''

			 FROM #Temp1 
			 LEFT JOIN EmpAssignment  ON EmpAssignment.EmpId = #Temp1.EmpId
			 LEFT JOIN Positions ON EmpAssignment.PositionNo=Positions.PositionNo
			 cross join (select FirstName from profile  where profileid = '+cast(@Profileid AS NVARCHAR(10))+') ManagerProfile
			'
           PRINT @str
           EXECUTE (@str ) 
     	END 
  DROP table #Temp1
	END

GO

