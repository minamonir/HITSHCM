CREATE PROCEDURE [dbo].[AutoPostOverTimeApprovedPermissions]
(@filterwhere NVARCHAR(max),@approvedPermissions NVARCHAR(max),@shiftno INT,@before int,@period int)
-- @printorPost 
-- 0 print
-- 1 post


AS
BEGIN
	SET NOCOUNT ON;

	--DECLARE @filterwhere NVARCHAR(max)=' ',@approvedPermissions NVARCHAR(max) = '1,2,3,7,8,9,10,11',@shiftno INT =13,@before int=-60, @period int =60
	--DECLARE @from NVARCHAR(8) ='20120101' ,@to NVARCHAR(8) ='20190601',@OverPaycode NVARCHAR(4)='100',@PreOverPayCode NVARCHAR(4)='17'
	--DECLARE @filterselect NVARCHAR(max) =N'  , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8   '


	DECLARE @Select NVARCHAR(max)


	SET @Select = N'SELECT  Empassignment.EmpId , EmpAssignment.EmployeeId , Profile.Name , Profile.AName ,
	emptimepermission.permissionno,timepermission.permissionname,timepermission.permissionaname,
	emptimepermission.permissionfrom,emptimepermission.permissionto,emptimepermission.documentstatus
	,CASE WHEN EmpShift.ShiftNo IS NULL THEN 0 ELSE 1 END AS [noshift]
	,timeshifts.shiftname,timeshifts.shiftaname
	' 
DECLARE @tablefrom NVARCHAR(MAX)=	'
from EmpAssignment 
inner Join emptimepermission ON EmpAssignment.EmpId=emptimepermission.EmpId
inner join timepermission on timepermission.permissionno = emptimepermission.permissionno
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN EmpShift ON EmpShift.EmpId = EmpTimePermission.EmpId  AND convert(nvarchar(10),shiftdate,120) =
    convert(nvarchar(10),PermissionFrom,120)
left join TimeShifts on TimeShifts.shiftno=Empshift.shiftno
Inner JOIN EmpShiftInOut ON EmpShiftInOut.EmpId = EmpAssignment.EmpId and EmpShiftInOut.TimeIn is not null and EmpShiftInOut.TimeOut is not null
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack
LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON JobCat.JobCat = Jobs.JobCat 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup
LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1
LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname = ''Status'' 
LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus''
LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus''
LEFT JOIN NasArrays HrTaxstat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus''
LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus''
LEFT JOIN NasArrays Gender ON Gender.itemno = Profile.Gender AND Gender.arrayname = ''Gender''
WHERE  emptimepermission.permissionno in ( '+@approvedPermissions+' ) 
and Emptimepermission.documentstatus=1 
and emptimepermission.permissionfrom between 
convert(smalldatetime,convert(char(12),dateadd(dd,'+STR(@before)+',getdate())),103) 
and 
convert(smalldatetime,convert(char(12),dateadd(dd,'+STR(@before+@period)+',getdate())),103) 
 ' +@filterwhere+'

'
DECLARE @group NVARCHAR(MAX)
='group by empassignment.EmpId , EmpAssignment.EmployeeId , Profile.Name , Profile.AName ,
	emptimepermission.permissionno,timepermission.permissionname,timepermission.permissionaname,emptimepermission.permissionfrom,emptimepermission.permissionto,emptimepermission.documentstatus,EmpShift.ShiftNo,timeshifts.shiftname,timeshifts.shiftaname'

--PRINT (@Select + @tablefrom + @group)
--EXEC (@Select + @tablefrom + @group)

	CREATE TABLE #EmpPermissionsCalculations(
	Empid INT,
	EmployeeID NVARCHAR(MAX),
    ProfileName NVARCHAR(MAX),
	ProfileAName NVARCHAR(MAX),
	PermissionNo INT,
	PermissionName NVARCHAR(MAX),
	PermissionAName NVARCHAR(MAX),
	PermissionFrom DATETIME,
	PermissionTo DATETIME,
	PermissionStatus INT,
	ShiftOrNo INT,
	ShiftName NVARCHAR(MAX),
	ShiftANAME NVARCHAR(MAX)
	)
	INSERT INTO #EmpPermissionsCalculations
	(
	    Empid,
	    EmployeeID,
	    ProfileName,
	    ProfileAName,
	    PermissionNo,
		PermissionName,
		PermissionAName,
	    PermissionFrom,
	    PermissionTo,
	    PermissionStatus,
	    ShiftOrNo,
	    ShiftName,
	    ShiftAName
	)
EXEC ( @Select + @tablefrom + @group)

--PRINT (@Select + @tablefrom + @group)

--IF 0=1
--BEGIN
DECLARE @empid INT,@permissionno INT ,@permissionfrom DATETIME,@permissionto DATETIME
DECLARE emprecord CURSOR FOR SELECT empid,PermissionNo,PermissionFrom,PermissionTo FROM #EmpPermissionsCalculations WHERE ShiftOrNo=0
OPEN emprecord 
FETCH NEXT FROM emprecord INTO @empid,@permissionno,@permissionfrom,@permissionto
WHILE @@FETCH_STATUS=0
BEGIN
PRINT 'Loop Started'
IF NOT EXISTS(SELECT empid,shiftno FROM dbo.EmpShift WHERE EmpId=@empid  AND convert(nvarchar(10),shiftdate,120) =
    convert(nvarchar(10),@permissionfrom,120)  )
	
BEGIN

INSERT INTO dbo.EmpShift
(
    EmpId,
    ShiftDate,
    ShiftNo

)
VALUES
(   @empid,                     -- EmpId - int
    convert(nvarchar(10),@permissionfrom,120), -- ShiftDate - smalldatetime
    @shiftno 
    )
	PRINT 'Inserted'
	END
	--ELSE 
	--BEGIN 
	--UPDATE dbo.EmpShift SET ShiftNo=@shiftno  WHERE EmpId=@empid AND convert(nvarchar(10),shiftdate,120)=
 --   convert(nvarchar(10),@permissionfrom,120)
	--end
	
	FETCH NEXT FROM emprecord INTO @empid,@permissionno,@permissionfrom,@permissionto
END
CLOSE emprecord
DEALLOCATE emprecord
--END

SELECT * FROM #EmpPermissionsCalculations 

DROP TABLE #EmpPermissionsCalculations




END

GO

