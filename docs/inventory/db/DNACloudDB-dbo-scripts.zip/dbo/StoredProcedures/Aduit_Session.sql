

CREATE PROCEDURE [dbo].[Aduit_Session]  
(@SessionEvent as int  ,@ComputerName as  nvarchar (50) ,@ApplicationName as nvarchar (128), @UserName as nvarchar (265) , @UserProfileId as int )
AS
--@SessionEvent=1 create new session (logon)
--@SessionEvent=2 delete the session (logout)
--delete from UserAuditSession where UserProfileId = @UserProfileId

DECLARE @AuditCode1 uniqueidentifier
DECLARE @nrows as int
set @nrows=1
declare @hitshost_id  as char(8) ,@hitsHOST_NAME as nvarchar(128)

select @hitsHOST_NAME = '' , @hitshost_id = ''
--select @hitsHOST_NAME = HOST_NAME() , @hitshost_id = host_id()
if  @SessionEvent = 1 
begin 
      INSERT INTO UserAuditSession
                      (SessionStart, ComputerName, ApplicationName, HostId, UserName, UserProfileId, LastAccessTime)
     values            ( getdate()  ,@ComputerName  ,@ApplicationName ,@hitshost_id, @UserName , @UserProfileId  , getdate()  )
     EXEC  Audit_CreateHeader 4,'Logon',@AuditCode1 OUTPUT
end
else
begin
   EXEC  Audit_CreateHeader 5,'Logout',@AuditCode1 OUTPUT
   delete from UserAuditSession where 
      ComputerName = @ComputerName  and  ApplicationName = @ApplicationName  and  
      UserName  = @UserName  and  UserProfileId  = @UserProfileId and HostId=@hitshost_id
end

GO

