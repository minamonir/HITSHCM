
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[AI_GetGoogleFormsResult](@vacancy as int,@FormId as nvarchar(500)= '0',@Overall AS INT = 0,@LogonName as nvarchar(80)='')
AS
BEGIN
	IF @Overall = 0
	Begin
		SELECT dbo.GoogleForms.FormId
		   --, GoogleForms.AssignmentId
		   , GoogleFormsResult.EmpId
		   , Profile.ProfileId
		   , Profile.Name
		   , Profile.AName
		   --, IBMInstrument.InstrumentName
		   --, IBMInstrument.InstrumentAName
		   , Jobs.job
		   , Jobs.jobName
		   , Jobs.JobAName
		   , CASE WHEN AppAssignment.EmpId IS NULL THEN N'Applicant' ELSE N'Employee' END [ApplicantStatus]
		   , CASE WHEN AppAssignment.EmpId IS NULL THEN N'طالب وظيفة' ELSE N'موظف' END [ApplicantAStatus]
		   , Vacancies.VacancyName
		   , Vacancies.VacancyAName
		   , Vacancies.VacancyNo
		   , Organization.OrganizationName
		   , Organization.OrganizationAName
		   ,GoogleFormsResult.RespondentEmail
		   --, GoogleFormsStatus.SessionStatusName
		   --, GoogleFormsStatus.SessionStatusAName
		   , GoogleFormsResult.CorrectQuestions 
		   , GoogleFormsResult.TotalQuestions
		   , CASE WHEN GoogleFormsResult.FormId IS NULL THEN 0 ELSE (CAST(GoogleFormsResult.CorrectQuestions AS NUMERIC(18,3)) / CAST(GoogleFormsResult.TotalQuestions AS NUMERIC(18,3)) * 5) END [CorrectnessPerfive]
		   , CASE WHEN GoogleFormsResult.FormId IS NULL THEN 0 ELSE (CAST(GoogleFormsResult.CorrectQuestions AS NUMERIC(18,3)) / CAST(GoogleFormsResult.TotalQuestions AS NUMERIC(18,3)) * 100) END [CorrectnessPercent]
		   , @vacancy as selectedVacancy 
		FROM dbo.GoogleForms
		LEFT JOIN  GoogleFormsResult ON GoogleFormsResult.FormId = GoogleForms.FormId 
		LEFT JOIN AppAssignment ON  GoogleFormsResult.EmpId=  AppAssignment.EmpId 
		LEFT JOIN dbo.Organization ON Organization.Organization = AppAssignment.Organization
		LEFT JOIN Profile ON GoogleFormsResult.EmpId = Profile.ProfileId
		--LEFT JOIN Vacancies ON Vacancies.VacancyNo = AppAssignment.VacancyNo
		LEFT JOIN Jobs ON Jobs.job = GoogleForms.JobId
			inner JOIN Vacancies ON Vacancies.Job = Jobs.job
		WHERE Vacancies.VacancyNo = @vacancy
		AND GoogleForms.FormId = CASE WHEN LTRIM(RTRIM(@FormId)) = '0' THEN GoogleForms.FormId ELSE  LTRIM(RTRIM(@FormId)) END
		ORDER BY [CorrectnessPercent] DESC , GoogleFormsResult.TotalQuestions DESC
	END

    ELSE IF @Overall = 1
	BEGIN
		SELECT ROW_NUMBER() OVER ( ORDER BY Profile.ProfileId) [FormId]
		  --, GoogleForms.AssignmentId   
		  , GoogleFormsResult.EmpId
		  , Profile.ProfileId
		  , Profile.Name
		  , Profile.AName
		  --, N'' [InstrumentName]
		 -- , N'' [InstrumentAName]
		  , Jobs.job
	      , Jobs.jobName
	      , Jobs.JobAName
		  , CASE WHEN AppAssignment.EmpId IS NULL THEN N'Applicant' ELSE N'Employee' END [ApplicantStatus]
		  , CASE WHEN AppAssignment.EmpId IS NULL THEN N'طالب وظيفة' ELSE N'موظف' END [ApplicantAStatus]
		  , Organization.OrganizationName
		  , Organization.OrganizationAName
		  ,GoogleFormsResult.RespondentEmail
		  --, N'' [SessionStatusName]
		  --, N'' [SessionStatusAName]
		  , SUM(GoogleFormsResult.CorrectQuestions) [CorrectQuestions]
		  , SUM(GoogleFormsResult.TotalQuestions) [TotalQuestions]
		  , SUM(CASE WHEN GoogleFormsResult.FormId IS NULL THEN 0 ELSE (CAST(GoogleFormsResult.CorrectQuestions AS NUMERIC(18,3)) / CAST(GoogleFormsResult.TotalQuestions AS NUMERIC(18,3)) * 5) END) / COUNT(dbo.GoogleForms.FormId) [CorrectnessPerfive]
		  , SUM(CASE WHEN GoogleFormsResult.FormId IS NULL THEN 0 ELSE (CAST(GoogleFormsResult.CorrectQuestions AS NUMERIC(18,3)) / CAST(GoogleFormsResult.TotalQuestions AS NUMERIC(18,3)) * 100) END) / COUNT(dbo.GoogleForms.FormId) [CorrectnessPercent] 
		  , @vacancy as selectedVacancy
		FROM dbo.GoogleForms
		LEFT JOIN  GoogleFormsResult ON GoogleFormsResult.FormId = GoogleForms.FormId 
		LEFT JOIN AppAssignment ON  GoogleFormsResult.EmpId=  AppAssignment.EmpId  
		LEFT JOIN dbo.Organization ON Organization.Organization = AppAssignment.Organization
		LEFT JOIN Profile ON GoogleFormsResult.EmpId = Profile.ProfileId
		--LEFT JOIN Vacancies ON Vacancies.VacancyNo = AppAssignment.VacancyNo
		LEFT JOIN Jobs ON Jobs.job = GoogleForms.JobId
				inner JOIN Vacancies ON Vacancies.Job = Jobs.job
		WHERE Vacancies.VacancyNo = @vacancy
		AND GoogleForms.FormId = CASE WHEN LTRIM(RTRIM(@FormId)) = '0' THEN GoogleForms.FormId ELSE  LTRIM(RTRIM(@FormId)) END
		GROUP BY GoogleFormsResult.RespondentEmail,AppAssignment.EmpId, Profile.ProfileId, Profile.Name, Profile.AName, GoogleFormsResult.EmpId, Organization.OrganizationName, Organization.OrganizationAName, Jobs.job, Jobs.JobName, Jobs.JobAName
		ORDER BY [CorrectnessPercent] DESC , [TotalQuestions] DESC
	END
END

GO

