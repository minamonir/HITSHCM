
CREATE PROCEDURE [dbo].[BatchWP_ExportSalaryScalesDetails] 
	(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS nvarchar(80),@Where AS nvarchar(max),
	 @Parameters AS nvarchar(max),@ColumnsStr AS nvarchar(max),@outputstr AS nvarchar(max)output)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @Countfilter AS INT = 0, @select AS NVARCHAR(MAX), @DecimalScale AS SMALLINT


    SELECT  @DecimalScale=SysParam.DecimalScale
	FROM sysparam 		
	
	PRINT '@DecimalScale = ' + STR(@DecimalScale)

	PRINT 'Parameters for Load ,Save, Delete' + @Parameters 
	DECLARE @type AS INT ,@Lang AS CHAR(1) 
	,@StartIndex2 AS INT , @SalaryScaleId AS INT , @StartDate AS NCHAR(12)
	,@GradeWhere   AS NVARCHAR(MAX), @PaycodeWhere AS NVARCHAR(MAX)

	DECLARE @CapStartValue AS NVARCHAR(MAX),@CapEndValue AS NVARCHAR(MAX)

	SET @CapStartValue = 'Start_Value'
	SET @CapEndValue = 'End_Value'




	IF @actiontype IN (1,5) -- load and delete 
	BEGIN
		SET @StartIndex2 = CHARINDEX('?',@Parameters)
		SET @type=SUBSTRING (@Parameters,0,@StartIndex2)
		SET @Parameters=SUBSTRING(@Parameters,@StartIndex2+1,LEN(@Parameters))
		PRINT 'Type = '+STR(@type)
		PRINT @Parameters


		SET @StartIndex2 = CHARINDEX('?',@Parameters)
		SET @Lang=SUBSTRING (@Parameters,0,@StartIndex2)
		SET @Parameters=SUBSTRING(@Parameters,@StartIndex2+1,LEN(@Parameters))
		PRINT '@Lang2  = '+@Lang
		PRINT @Parameters

		SET @StartIndex2 = CHARINDEX('?',@Parameters)
		SET @SalaryScaleId=SUBSTRING (@Parameters,0,@StartIndex2)
		SET @Parameters=SUBSTRING(@Parameters,@StartIndex2+1,LEN(@Parameters))
		PRINT 'SalaryScaleId2  = '+STR(@SalaryScaleId)
		PRINT @Parameters

		SET @StartIndex2 = CHARINDEX('?',@Parameters)
		SET @StartDate=SUBSTRING (@Parameters,0,@StartIndex2)
		SET @Parameters=SUBSTRING(@Parameters,@StartIndex2+1,LEN(@Parameters))
		PRINT 'StartDate2  = '+@StartDate
		PRINT @Parameters

		SET @StartIndex2 = CHARINDEX('?',@Parameters)
		SET @GradeWhere=SUBSTRING (@Parameters,0,@StartIndex2)
		SET @Parameters=SUBSTRING(@Parameters,@StartIndex2+1,LEN(@Parameters))
		PRINT 'GradeWhere2  = '+@GradeWhere
		PRINT @Parameters

		SET @PaycodeWhere=@Parameters
		PRINT '@PaycodeWhere2  = '+@PaycodeWhere
		PRINT @Parameters
	END

	IF @actiontype = 1 -- Load & Save
	BEGIN
		DECLARE @Selection1 AS NVARCHAR(MAX), @Selection2 AS NVARCHAR(MAX)

		IF @type = 1 --Load
		BEGIN
		    DECLARE @Query AS NVARCHAR(MAX)
			DECLARE @ParmDefinition NVARCHAR(100)
			DECLARE @Count AS INT
			SET @ParmDefinition = N'@CountOut int OUTPUT'


			SET @Query=' select @CountOut=count(*)
							 FROM SalaryScaleDetails
							 LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
							 LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
 							 WHERE Paycode.SalaryScale = 1 AND SalaryScaleDetails.SalaryScaleid = ' +STR(@SalaryScaleId)+' 
							 AND SalaryScaleDetails.StartDate =   '''+@StartDate +''' '+@GradeWhere+ ' '+@PaycodeWhere+' ' 
 
			EXECUTE sp_executesql @Query, @ParmDefinition, @CountOut = @Count OUTPUT  
			PRINT 'count = ' + STR(@count) 
			
			IF @count > 0
			BEGIN
				PRINT 'if cout > 0 load'
				DECLARE @SelectAll AS NVARCHAR(MAX)='' ,@SelectStart AS NVARCHAR(MAX)='',@SelectEnd AS NVARCHAR(MAX) =''
				DECLARE @ColumnsAll AS NVARCHAR(MAX)=' ' ,@ColumnsStart AS NVARCHAR(MAX) ='',@ColumnsEnd AS NVARCHAR(MAX) =''
				,@ColumnsStartcreation AS NVARCHAR(MAX) ,@ColumnsEndcreation AS NVARCHAR(MAX) 

				SET @SelectAll=' SELECT COLUMN_NAME  FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
                  WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''Post'',''Remarks'',''Row_Number'',''GradeNo'',''Grade'')' 
 
				CREATE TABLE #TempAll (Paycode  nvarchar(Max))
				INSERT INTO #TempAll
				EXEC(@SelectAll) 
				PRINT '@SelectAll' + @SelectAll

				SELECT  @ColumnsAll= @ColumnsAll +Paycode+  ' numeric(18,3) default 0 , '  
				FROM #TempAll
				SELECT  @ColumnsAll=substring(@ColumnsAll,1,LEN(@ColumnsAll)-1)
				PRINT '@ColumnsAll'+@ColumnsAll

				SELECT @ColumnsStart= @ColumnsStart +Paycode+ ' numeric(18,3) default 0 , '
				FROM #TempAll
				WHERE #TempAll.Paycode LIKE '%'+@CapStartValue+'%' 
				SELECT  @ColumnsStart =SUBSTRING(@ColumnsStart,1,LEN(@ColumnsStart)-1)
				PRINT '@ColumnsStart'+@ColumnsStart

				DECLARE @query2 AS NVARCHAR(max)
				SET @Query2='CREATE TABLE #tempTableStart ( Gradeno smallint , '+@ColumnsStart+')' 
				PRINT '@query2'+@query2
				Exec sp_Executesql @query2
				

				SELECT  @ColumnsEnd= @ColumnsEnd +Paycode+ ' numeric(18,3) default 0 , '
				FROM #TempAll
				WHERE #TempAll.Paycode  LIKE '%'+@CapEndValue+'%' 
				SELECT  @ColumnsEnd=SUBSTRING(@ColumnsEnd,1,LEN(@ColumnsEnd)-1)
				PRINT '@ColumnsEnd'+@ColumnsEnd

				SET @query2='CREATE TABLE #tempTableEnd ( Gradeno smallint , '+@ColumnsEnd+')'
				Exec sp_Executesql @query2

				PRINT '@query2'+@query2

				SELECT @ColumnsStart=LTRIM(RTRIM(REPLACE (@ColumnsStart,'numeric(18,3) default 0 ','')))
				PRINT '@ColumnsStart1'+@ColumnsStart
				SELECT @ColumnsStart='['+REPLACE (@ColumnsStart,' , ','] , [')+']'
				PRINT '@ColumnsStart2'+@ColumnsStart

				SELECT @ColumnsEnd=LTRIM(RTRIM(replace (@ColumnsEnd,'numeric(18,3) default 0 ','')))
				PRINT '@ColumnsEnd1'+@ColumnsEnd
				SELECT @ColumnsEnd='['+REPLACE (@ColumnsEnd,' , ','] , [')+']'
				PRINT '@ColumnsEnd2'+@ColumnsEnd

				DECLARE @StartSelect AS NVARCHAR(max)
				DECLARE @EndSelect AS NVARCHAR(max)

				PRINT '@ColumnsStart'+@ColumnsStart
				PRINT '@ColumnsEnd'+@ColumnsEnd

				SELECT @StartSelect ='isnull('+REPLACE(@ColumnsStart,',',',0),isnull(')+',0)'
				SELECT @EndSelect ='isnull('+REPLACE(@ColumnsEnd,',',',0),isnull(')+',0)'

				PRINT 'insert into #tempTableStart  (Gradeno,'+@ColumnsStart+')
						SELECT Grade, '+@StartSelect +' FROM (
						SELECT DISTINCT Grades.Grade ,isnull(''P''+ltrim(rtrim(SalaryScaleDetails.Paycode))+'''+@CapStartValue+''',0) AS PaycodeNo
						,isnull(SalaryScaleDetails.StartValue,0) AS StartValue
						FROM SalaryScaleDetails
						LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
						LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
						WHERE SalaryScaleDetails.SalaryScaleid= '+STR(@SalaryScaleId)+' and  SalaryScaleDetails.StartDate ='''+STR(@StartDate)+'''  ' +@GradeWhere+'  '+  @paycodewhere +'
						)AS Data 
						pivot (sum (StartValue) FOR Paycode  IN ('+@ColumnsStart+'))  as StartValue

						insert into #tempTableEnd  (Gradeno,'+@ColumnsEnd+')
						SELECT Grade,'+@EndSelect +' FROM (SELECT DISTINCT Grades.Grade
						,isnull(''P''+ltrim(rtrim(SalaryScaleDetails.Paycode))+'''+@CapEndValue+''' ,0)AS PaycodeNo
						,isnull(SalaryScaleDetails.EndValue,0) AS EndValue
						FROM SalaryScaleDetails
						LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
						LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
						WHERE Paycode.SalaryScale = 1 and SalaryScaleDetails.SalaryScaleid= '+STR(@SalaryScaleId)+' 
						and  SalaryScaleDetails.StartDate ='''+STR(@StartDate)+'''  ' +@GradeWhere+'  '+  @paycodewhere +'
						)AS Data2 
						pivot (sum (EndValue) FOR Paycode  IN ('+@ColumnsEnd+'))  EndValue'

				exec ('insert into #tempTableStart  (Gradeno,'+@ColumnsStart+')
						SELECT Grade, '+@StartSelect +' FROM (
						SELECT DISTINCT Grades.Grade ,isnull(''P''+ltrim(rtrim(SalaryScaleDetails.Paycode))+'''+@CapStartValue+''',0) AS PaycodeNo
						,isnull(SalaryScaleDetails.StartValue,0) AS StartValue
						FROM SalaryScaleDetails
						LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
						LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
						WHERE Paycode.SalaryScale = 1 and SalaryScaleDetails.SalaryScaleid= '+@SalaryScaleId+' 
						and SalaryScaleDetails.StartDate ='''+@StartDate+'''  ' +@GradeWhere+'  '+  @paycodewhere +'
						)AS Data 
						pivot (sum (StartValue) FOR PaycodeNo  IN ('+@ColumnsStart+'))  as StartValue

						insert into #tempTableEnd  (Gradeno,'+@ColumnsEnd+')
						SELECT Grade,'+@EndSelect +' FROM (SELECT DISTINCT Grades.Grade
						,isnull(''P''+ltrim(rtrim(SalaryScaleDetails.Paycode))+'''+@CapEndValue+''' ,0)AS PaycodeNo
						,isnull(SalaryScaleDetails.EndValue,0) AS EndValue
						FROM SalaryScaleDetails
						LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
						LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
						WHERE Paycode.SalaryScale = 1 and SalaryScaleDetails.SalaryScaleid= '+@SalaryScaleId+'
						 and  SalaryScaleDetails.StartDate ='''+@StartDate+'''  ' +@GradeWhere+'  '+  @paycodewhere +'
						)AS Data2 
						pivot (sum (EndValue) FOR PaycodeNo  IN ('+@ColumnsEnd+'))  EndValue')

				SELECT @ColumnsAll=replace (@ColumnsAll,' numeric(18,3) default 0 ','')

				EXEC('insert into ' +@tablename+ '(GradeNo ,Grade,'+ @ColumnsAll +')
					  select #tempTableStart.Gradeno ,case when '''+@Lang+''' = ''A'' then Grades.GradeAName else Grades.GradeName end, '+@ColumnsAll+' 
					  from  #tempTableStart
					  inner join  #tempTableEnd on  #tempTableEnd.Gradeno = #tempTableStart.Gradeno
					  left join grades on Grades.Grade =  #tempTableStart.Gradeno')

			 EXEC(' SELECT   * FROM '+ @tablename )


			 DROP TABLE #TempAll
			 DROP TABLE #tempTableStart
			 DROP TABLE #tempTableEnd
			END   
			ELSE
			BEGIN
			    EXEC ('insert into '+@tablename+' (GradeNo, Grade) 
				select Grade, CASE WHEN '''+@Lang+'''= ''A'' THEN Grades.GradeAName ELSE Grades.GradeName END  
				FROM Grades
				where 1=1 '+@GradeWhere)

				PRINT 'select Grade, CASE WHEN '''+@Lang+'''= ''A'' THEN Grades.GradeAName ELSE Grades.GradeName END  
				FROM Grades
				where 1=1 '+@GradeWhere
			END  
		END

		IF @type = 2 --Save
		BEGIN
		    PRINT 'in type 2'
			DECLARE @GradesValue AS NVARCHAR(max)='' , @GradeVal AS INT, @PaycodeCol2 AS NVARCHAR(max),@ColumnName2 AS NVARCHAR(100)--,@SelectPlanOption AS NVARCHAR(max)
			,@SelectPaycodeStart AS NVARCHAR(max), @PaycodeNo INT, @SelectPaycodeEnd AS NVARCHAR(max)

			SET @SelectPaycodeStart =''
			SET @SelectPaycodeEnd =''
			SET @ColumnName2 = ''

			SET @GradesValue =  ' DECLARE Gradecursor CURSOR for SELECT distinct gradeno  FROM '+@tablename+ ' t where t.Post = 1 and rtrim(ltrim(ISNULL(t.Remarks,'''')))=''''  '
			EXECUTE (@GradesValue)

			PRINT '@GradesValue'+@GradesValue

			OPEN Gradecursor
			FETCH next FROM Gradecursor
			INTO  @GradeVal

			WHILE @@FETCH_STATUS=0
			BEGIN
			PRINT 'in while grade'
			SET @PaycodeCol2 =' DECLARE tempcursor CURSOR for SELECT COLUMN_NAME 
                           FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
                           WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND COLUMN_NAME not in (''Post'',''Remarks'', ''Row_Number'',''GradeNo'',''Grade'')'

			PRINT @PaycodeCol2
			EXECUTE(@PaycodeCol2)
			OPEN tempcursor

			FETCH next FROM tempcursor
			INTO  @ColumnName2

			WHILE @@FETCH_STATUS=0
			BEGIN
				 DECLARE @StartVal AS NUMERIC(18,3), @EndVal AS NUMERIC(18,3)
				 SET @PaycodeNo = CASE WHEN @ColumnName2 LIKE '%'+@CapStartValue+'%' THEN SUBSTRING(@ColumnName2,2,CHARINDEX(@CapStartValue,@ColumnName2)-2) 
				 ELSE  SUBSTRING(@ColumnName2,2,CHARINDEX(@CapEndValue,@ColumnName2)-2) END 
	 	
		  		 DECLARE @sqlCommand  nvarchar(Max) , @paramDef NVARCHAR(100)
				 SET @paramDef = ' @Amount numeric (18,3) OUTPUT '
				 SET @sqlCommand  = ' SELECT   @Amount = '+@ColumnName2+' FROM '+@tablename+' WHERE GradeNo = ' + STR(@GradeVal) 
	    
				IF  @ColumnName2 LIKE '%'+@CapStartValue+'%' 
					BEGIN 
						EXECUTE sp_executesql @sqlCommand, @paramDef, @Amount = @StartVal  OUTPUT
						PRINT '@sqlCommand'+@sqlCommand
						IF EXISTS (SELECT * FROM dbo.SalaryScaleDetails 
							WHERE SalaryScaleid=@SalaryScaleId AND StartDate=@StartDate AND Paycode = @PaycodeNo AND Grade=@GradeVal)
						BEGIN 
							PRINT 'in update'
								UPDATE SalaryScaleDetails
									SET StartValue = @StartVal
									WHERE  SalaryScaleid= @SalaryScaleId AND StartDate=@StartDate  AND Paycode =  @PaycodeNo 
									AND Grade= @GradeVal
						END 
						ELSE 
						BEGIN 
						PRINT 'insert start'
	
						INSERT INTO dbo.SalaryScaleDetails (SalaryScaleid , Paycode , Grade ,StartDate , StartValue , EndValue)
								SELECT @SalaryScaleId,@PaycodeNo , @GradeVal ,  @StartDate , ISNULL(@StartVal,0) ,  ISNULL(@EndVal,0) 
								WHERE  ISNULL(@StartVal,0) <> 0
						END 			

					END 
				ELSE 
					BEGIN 
					EXECUTE sp_executesql @sqlCommand, @paramDef, @Amount = @EndVal  output  
					PRINT '@sqlCommand2'+@sqlCommand
						IF EXISTS (SELECT * FROM dbo.SalaryScaleDetails 
							WHERE SalaryScaleid=@SalaryScaleId AND StartDate=@StartDate AND Paycode = @PaycodeNo AND Grade=@GradeVal)
						BEGIN
							PRINT 'in update'
							UPDATE dbo.SalaryScaleDetails
									SET EndValue = @EndVal 
									WHERE  SalaryScaleid= @SalaryScaleId AND StartDate=@StartDate  AND Paycode =  @PaycodeNo 
									AND Grade= @GradeVal
							END 
						ELSE 
						BEGIN 
						PRINT 'in inset'
								INSERT INTO dbo.SalaryScaleDetails (SalaryScaleid , Paycode, Grade ,StartDate , StartValue , EndValue)
								SELECT @SalaryScaleId,@PaycodeNo, @GradeVal ,  @StartDate , ISNULL(@StartVal,0) ,  ISNULL(@EndVal,0) 
								WHERE   ISNULL(@EndVal,0)  <> 0
			  
						END 
					END 
				FETCH NEXT FROM tempcursor
				INTO @ColumnName2
			END
			CLOSE tempcursor
			DEALLOCATE tempcursor

			FETCH NEXT FROM Gradecursor
			INTO @GradeVal
		END
		CLOSE Gradecursor
	DEALLOCATE Gradecursor
	END
	
	END

	IF @actiontype = 3 --import of export
	BEGIN
	PRINT 'in action 3'
		DECLARE @salaryScale AS INT,@CheckExport AS SMALLINT 
		IF @ColumnsStr LIKE '%@ColumnsConcat%' 
		BEGIN
		   PRINT '@ColumnsStr Comming from import '+@ColumnsStr
		   DECLARE @index AS INT 
		   SET @index = CHARINDEX('@ColumnsConcat',@ColumnsStr)
		   SET @ColumnsStr= substring (@ColumnsStr,@index+LEN('@ColumnsConcat'),LEN(@ColumnsStr)-len(@index))
		   PRINT 'ColumnStr import ' + @ColumnsStr
		END
		ELSE 
		BEGIN
			PRINT '1.. ' + @ColumnsStr
			SET @ColumnsStr = replace (@ColumnsStr,'WP_ExportSalaryScalesDetails_ar?','')
			SET @ColumnsStr = replace (@ColumnsStr,'WP_ExportSalaryScalesDetails?','') 
			PRINT '2.. ' + @ColumnsStr

			DECLARE @StartIndex AS INT 

			SET @StartIndex = CHARINDEX('?',@ColumnsStr)
			SET @Lang = SUBSTRING (@ColumnsStr,0,@StartIndex)
			SET @ColumnsStr = SUBSTRING(@ColumnsStr,@StartIndex + 1,len(@ColumnsStr))
			PRINT 'Lang =' + @Lang
			PRINT @ColumnsStr 

			SET @StartIndex = CHARINDEX('?',@ColumnsStr)
			SET @SalaryScale = SUBSTRING (@ColumnsStr,0,@StartIndex)
			SET @ColumnsStr = SUBSTRING(@ColumnsStr,@StartIndex + 1,len(@ColumnsStr))
			PRINT 'SalaryScaleId = ' + STR(@SalaryScale)
			PRINT @ColumnsStr

			SET @StartIndex = CHARINDEX('?',@ColumnsStr)
			SET @StartDate = SUBSTRING (@ColumnsStr,0,@StartIndex)
			SET @StartDate = CASE WHEN ISDATE(@StartDate) = 0 THEN '19000101' ELSE @StartDate END

			SET @ColumnsStr = SUBSTRING(@ColumnsStr,@StartIndex + 1,len(@ColumnsStr))
			PRINT 'StartDate = ' + @StartDate
			PRINT @ColumnsStr

			SET @StartIndex = CHARINDEX('?',@ColumnsStr)
			SET @GradeWhere = SUBSTRING (@ColumnsStr,0,@StartIndex)
			SET @ColumnsStr = SUBSTRING(@ColumnsStr,@StartIndex + 1,len(@ColumnsStr))
			PRINT 'GradeWhere = ' + @GradeWhere
			PRINT @ColumnsStr

			SET @StartIndex = CHARINDEX('?',@ColumnsStr)
			SET @PaycodeWhere = CASE WHEN @StartIndex > 0 THEN SUBSTRING (@ColumnsStr,0,@StartIndex) ELSE @ColumnsStr END 
			SET @ColumnsStr = substring(@ColumnsStr,@StartIndex + 1,len(@ColumnsStr))
			PRINT 'PlanOptionWhere=  ' + @PaycodeWhere
			PRINT 'ColumnsStr now' + @ColumnsStr

			SET @CheckExport =CASE WHEN LTRIM(RTRIM(@ColumnsStr)) <> '1' THEN 0 ELSE @ColumnsStr END   --CASE WHEN LTRIM(RTRIM(@ColumnsStr))='and 1 =1' THEN 0 ELSE @ColumnsStr END 
			PRINT 'CheckExport=  '+ STR(@CheckExport)
			PRINT @ColumnsStr

			SET @ColumnsStr = ''
		
			DECLARE @Queryfilter	   AS NVARCHAR(MAX)
			DECLARE @ParmDefinitionfilter NVARCHAR(100)
			SET @ParmDefinitionfilter = N'@CountOutfilter int OUTPUT'
 
			SET @Queryfilter = ' select @CountOutfilter=count(*) 
									FROM SalaryScaleDetails
									LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
									LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
 									WHERE Paycode.SalaryScale = 1 AND SalaryScaleDetails.SalaryScaleid = ' + STR(@SalaryScale) + ' 
								   and SalaryScaleDetails.StartDate =  ''' + @StartDate+ '''  ' + @GradeWhere + ' ' + @PaycodeWhere + ' ' 

			EXECUTE sp_executesql @Queryfilter, @ParmDefinitionfilter, @CountOutfilter= @Countfilter OUTPUT  

			DECLARE @From AS NVARCHAR(MAX)
			SET @From = ''

			CREATE table #tempPaycode(Paycode NVARCHAR(256))

			IF @Countfilter > 0
			BEGIN
				PRINT '@Countfilter= ' + STR(@Countfilter)
				PRINT 'Comming from SalaryScaleDetails'
				SET @From = ' FROM SalaryScaleDetails 
							LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
							LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
							WHERE Paycode.SalaryScale = 1 AND SalaryScaleDetails.SalaryScaleid = ' + STR(@SalaryScale) + ' 
							AND SalaryScaleDetails.StartDate =  ''' + @StartDate + ''''+ @GradeWhere  + '  ' + @PaycodeWhere + ''

				PRINT @From  
			END
            ELSE
			BEGIN
			    PRINT '@Countfilter= ' + STR(@Countfilter)
				PRINT 'Comming from setup'
				SET @From = 'FROM Paycode
							WHERE Paycode.SalaryScale = 1 ' + @PaycodeWhere
			 PRINT @From  
			END

			 INSERT INTO #tempPaycode(Paycode)
			 EXEC ('select DISTINCT RTRIM(LTRIM(STR(Paycode.code))) ' + @From)

			 SELECT @ColumnsStr = ''

			 SELECT @ColumnsStr = @ColumnsStr + 'P' + RTRIM(LTRIM(Paycode)) + '' + @CapStartValue + ' numeric(18,'+ STR(@DecimalScale) +') default 0,'
			+ 'P' + RTRIM(LTRIM(Paycode)) + '' + @CapEndValue + ' numeric(18,'+ STR(@DecimalScale) +') default 0,'
			FROM #tempPaycode

			PRINT 'New Columns Str ' + @ColumnsStr

			DROP table #tempPaycode
		END
		-----------------------------------------------------------------------------------------
		DECLARE @PaycodeNameColumn AS NVARCHAR(Max)
		DECLARE 
			   @insertstr AS nvarchar(max) = '', @deletestr AS nvarchar(max) = '',
			   @selectstr AS nvarchar(max) = '', @DisabledColStr AS nvarchar(100) = '',
			   @updatestr AS NVARCHAR(MAX) = ''
       
		IF rtrim(ltrim(@tablename)) <> '' 
		BEGIN
			PRINT 'if table name is empty'
			PRINT '@columnstrsssssss'+@ColumnsStr
			SET @select = 'IF not EXISTS(SELECT top 1 1
			FROM ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns 
			WHERE  ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+ PARSENAME(@tablename,1) + ''')'
			+ 'CREATE TABLE ' + @tablename + ' (GradeNo int ,Grade nvarchar(256),'+ @ColumnsStr + ' Post bit , Remarks nvarchar(max) , [Row_Number] int Identity(1,1) NOT NULL Primary Key)' 

			PRINT 'xxxxxxxxxxxxxxxxxxxxx'+@select
			EXECUTE (@select)
			PRINT '@CheckExport' + STR(@CheckExport)
		----------------------Update-----------------------

			SET @SELECT = 'DECLARE updateCursor CURSOR for SELECT COLUMN_NAME 
								FROM ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns 
								WHERE TABLE_NAME =''' + PARSENAME(@tablename,1) + '''  AND  COLUMN_NAME not in (''Post'',''Remarks'',''GradeNo'',''Grade'')'
			PRINT @select
			EXECUTE(@SELECT)
			OPEN updateCursor FETCH next FROM updateCursor   INTO  @PaycodeNameColumn
			WHILE @@FETCH_STATUS = 0
			BEGIN
				PRINT 'in while'
				IF SUBSTRING(@PaycodeNameColumn,1,1) = 'P'
				BEGIN
					SET @updatestr += @PaycodeNameColumn + '= @' + @PaycodeNameColumn+ ',' 
					PRINT @updatestr
				end
				FETCH NEXT FROM updateCursor INTO @PaycodeNameColumn
			END
			CLOSE updateCursor
			DEALLOCATE updateCursor
   
			PRINT @updatestr  

			SET @updatestr = ' update  ' + @tablename + ' set ' + @updatestr + ' Post = @Post, GradeNo=@GradeNo ,Grade=@Grade  where [Row_Number]= @originalRow_Number '
		END
		 -------------------------------------------------
		ELSE
		BEGIN
			PRINT 'in else if table name is not empty'
			SET @selectstr = 'select  0 as Post , '''' as Remarks , 0 as [Row_Number] , 0 as GradeNo ,'''' as Grade,  '+ @ColumnsStr + 'WHERE 1<>1'
		END   

		-------------------------Find Grade-------------------
		IF @tablename <> ''
		BEGIN
			DECLARE @countTablename AS INT, @countoutput AS NVARCHAR(MAX)
			SET @countoutput = 'SELECT @countTablename = count(COLUMN_NAME)
				FROM ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns 
				WHERE  ' + PARSENAME(@tablename,3) + '.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+ PARSENAME(@tablename,1) + ''''
			
				EXEC sp_executesql @countoutput, 
					   N'@countTablename int OUTPUT', 
					   @countTablename = @countTablename OUTPUT

			PRINT '@countTablename .....'+ str(@countTablename)
			SET @DisabledColStr = '2,'+STR(@countTablename-1)

			PRINT '@countoutput' + @countoutput
			PRINT '@countTablename '+ STR(@countTablename)
			PRINT '@DisabledColStr ' + @DisabledColStr

			PRINT '@updatestr'+@updatestr
			PRINT '@CheckExport' + STR(@CheckExport)
		END
       		PRINT 'end if'
			SET @insertstr = SUBSTRING(@insertstr,0,LEN(@insertstr))

			SET @insertstr=' insert into '+@tablename+' select @Grade ,'+@ColumnsStr+', @post ,@remarks '
    
			SET @deletestr = ' delete from  ' + @tablename + ' where [Row_Number]=@originalRow_Number  '
			PRINT @insertstr+@deletestr

			SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr, ISNULL(@DisabledColStr,'') AS DisabledColStr
		
	----------------------------------------------------Insert Grade in tablename-------------------------
		IF @CheckExport = 1
		BEGIN
			PRINT '@CheckExport..  ='
			DECLARE @CountRows AS INT
			DECLARE @ParmDefinitionfilterRows AS NVARCHAR(100)
			DECLARE @Querynew  AS  NVARCHAR(max)
			SET @ParmDefinitionfilterRows = N'@CountOutRows int OUTPUT'

			SET @Querynew = 'select @CountOutRows = count(*)  FROM SalaryScaleDetails 
						LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
						LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade  
						WHERE Paycode.SalaryScale = 1 AND SalaryScaleDetails.SalaryScaleid = ' + STR(@SalaryScale) + ' 
						AND SalaryScaleDetails.StartDate =  ''' + @StartDate + '''' + @GradeWhere  + '  ' + @PaycodeWhere + ''

			EXECUTE sp_executesql @Querynew, @ParmDefinitionfilterRows, @CountOutRows= @CountRows OUTPUT  
			PRINT  '@CountRows ' + STR(@CountRows)
 
			PRINT 'Check count filter'
			PRINT '@Countfilter =' + STR(@Countfilter)
				
			IF  @CountRows = 0
				BEGIN
					PRINT 'Insert grades in temp table when count = 0'
  					PRINT @Lang
					
					PRINT 'insert into ' + @tablename + ' (GradeNo,Grade) 
									select  Grade,case when ''' + @Lang + '''= ''A'' then Grades.GradeAName else Grades.GradeName  end   FROM Grades
								where 1=1 ' + @GradeWhere

					EXEC ('insert into ' + @tablename + ' (GradeNo,Grade) 
								select  Grade,case when ''' + @Lang + '''= ''A'' then Grades.GradeAName else Grades.GradeName  end   FROM Grades
							where 1=1 ' + @GradeWhere)
				END
			ELSE 
				BEGIN
					PRINT 'Insert grades in temp table when count = ' + STR(@CountRows)
					PRINT @Lang
					PRINT 'insert into ' + @tablename + ' (GradeNo,Grade) 
									select distinct  Grades.Grade,case when ''' + @Lang + '''= ''A'' then Grades.GradeAName else Grades.GradeName  end
									FROM SalaryScaleDetails 
									LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
									LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
									WHERE Paycode.SalaryScale = 1 AND SalaryScaleDetails.SalaryScaleid = ' + STR(@SalaryScale) + ' 
									AND SalaryScaleDetails.StartDate =  ''' + STR(@StartDate) + '''' + @GradeWhere  + '  ' + @paycodewhere + ''

					EXEC ('insert into ' + @tablename + ' (GradeNo,Grade) 
								select distinct  Grades.Grade,case when ''' + @Lang + '''= ''A'' then Grades.GradeAName else Grades.GradeName  end
								FROM SalaryScaleDetails 
								LEFT JOIN Paycode ON Paycode.code = SalaryScaleDetails.Paycode
								LEFT JOIN Grades ON Grades.Grade = SalaryScaleDetails.Grade 
								WHERE Paycode.SalaryScale = 1 AND SalaryScaleDetails.SalaryScaleid = ' + @SalaryScale + ' 
								AND SalaryScaleDetails.StartDate =  ''' + @StartDate+ '''' + @GradeWhere  + '  ' + @paycodewhere + '')
				END
		END
	END

	IF @actiontype = 5
	BEGIN
		PRINT ('DELETE FROM SalaryScaleDetails
				 From SalaryScaleDetails
				 inner JOIN Grades ON SalaryScaleDetails.Grade = Grades.Grade 
				 inner JOIN Paycode ON Paycode.code =  SalaryScaleDetails.Paycode
				 INNER join '+@tablename+' t on t.GradeNo = SalaryScaleDetails.Grade 
				 WHERE t.post=1 and rtrim(ltrim(isnull(remarks,'''')))=''''  and
				 SalaryScaleDetails.SalaryScaleid= '+STR(@SalaryScaleId)+' and  SalaryScaleDetails.StartDate ='''+@StartDate+'''  ' +@GradeWhere+ '   '+ @PaycodeWhere  +' ') 

		 EXEC ('DELETE FROM SalaryScaleDetails
				 From SalaryScaleDetails
				 inner JOIN Grades ON SalaryScaleDetails.Grade = Grades.Grade 
				 inner JOIN Paycode ON Paycode.code =  SalaryScaleDetails.Paycode
				 INNER join '+@tablename+' t on t.GradeNo = SalaryScaleDetails.Grade 
				 WHERE t.post=1 and rtrim(ltrim(isnull(remarks,'''')))=''''  and
				 SalaryScaleDetails.SalaryScaleid= '+@SalaryScaleId+' and  SalaryScaleDetails.StartDate ='''+@StartDate+'''  ' +@GradeWhere+ '   '+ @PaycodeWhere  +' ')
		   
	END
END

GO

