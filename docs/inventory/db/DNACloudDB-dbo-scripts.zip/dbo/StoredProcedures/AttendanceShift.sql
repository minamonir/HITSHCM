CREATE PROCEDURE [dbo].[AttendanceShift] (@from as datetime,@vaccodes as nvarchar(4000),@Type as smallint,@hijri as nCHAR(1),@where as nvarchar(4000),@selectgroups as nvarchar(4000))  AS
----- for le Meridien Oran

----declare @from as datetime,@vaccodes as nvarchar(4000),@Type as smallint,@hijri as CHAR(1),@where as nvarchar(4000),@selectgroups as nvarchar(4000)
--SET @from = '2013/09/21' 
--SET @vaccodes = '2, 3, 4, 5, 6, 7'
--SET @Type = 10
--SET @hijri = 'G'
--SET @where = 
--    'and  ( Empassignment.privacy between 0 and 9 )         AND EMPASSIGNMENT.EMPLOYEEID =  ''1''                  '

--SET @selectgroups = 
--    ' , 0 as GroupLevel1 , '''' as GroupName1  , 0 as GroupLevel2 , '''' as GroupName2  , 0 as GroupLevel3 , '''' as GroupName3  , 0 as GroupLevel4 , '''' as GroupName4  , 0 as GroupLevel5 , '''' as GroupName5  , 0 as GroupLevel6 , '''' as GroupName6  , 0 as GroupLevel7 , '''' as GroupName7 , 0 AS GroupLevel8, '''' AS GroupName8  '

DECLARE @date   AS DATETIME,
        @to     AS DATETIME,
        @Query  AS NVARCHAR(4000)

SET @date = @from
SET @to = CONVERT(
        NCHAR(12),
        DATEADD(m, 1, CONVERT(DATETIME, @from, 111)) -1,
        111
    ) --- add month
SET @Query = 
    'select distinct Empassignment.Empid,Empassignment.Employeeid,cast(Profile.Name as nvarchar(88)),cast(Profile.AName as nvarchar(88)),#Date.Date,#Date.h_Date,0,NULL,0,0,''A'',case when #Date.[Date] not between empassignment.hiredate and empassignment.termdate then N'''' else ''P'' end,-1 '
    +
    ' from Empassignment left join profile on empassignment.empid=profile.profileid '
    +
    ' LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus '
    +
    ' LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname =''Status'' LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade '
    +
    ' LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo '
    +
    ' LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType '
    +
    ' LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId '
    +
    ' cross join #Date where 1=1  and (EmpAssignment.status=1) ' + @where
  
	--create a table contains the values for the date 
CREATE TABLE #Date
(
	[Date]  DATETIME,
	h_Date  NCHAR(12)
)

	--check if hijri or not
IF @hijri = 'G' --if not hijri
BEGIN
    --fill yhe date table
    WHILE @to >= @date
    BEGIN
        INSERT INTO #Date
        VALUES
          (
            @date,
            N''
          )
        SET @date = DATEADD(d, 1, @date)
    END
END
ELSE
    --if hijri
BEGIN
    WHILE @to >= @date
    BEGIN
        INSERT INTO #Date
        VALUES
          (
            @date,
            dbo.Greg2Hijri(@date, 'o')
          )
        SET @date = DATEADD(d, 1, @date)
    END
END
		
	--create table to hold all the data
CREATE TABLE #EmpAttend
(
	EmpId        INT,
	EmployeeId   NVARCHAR(50),
	NAME         NVARCHAR(100),
	AName        NVARCHAR(100) COLLATE database_default,
	Date         DATETIME,
	h_Date       NCHAR(12),
	VacType      SMALLINT,
	shiftno      SMALLINT,
	vacflag      SMALLINT,	-- in type 10 -> flag to display where this employee on this date took vcation in vaccode (2,3,4,5,6,7) or not
	workdays     NUMERIC(18, 3),	-- 30 - numberofdays( vaccode (2,3,4,5,6,7) ) + inputAmount paycode 202
	DESCRIPTION  NCHAR(1),
	VALUE        NVARCHAR(8),
	Color        INT
)
CREATE TABLE #EmpHiringHistory
(
	EmpId INT,
	HireDate SmallDATETIME,
	TermDate SMALLDATETIME,
	FirstHiredDate SMALLDATETIME
)
	
	--fill the table with all the employees
INSERT INTO #EmpAttend
EXECUTE
  (
    @Query
  )
	--PRINT @Query
	--- "Meridian" -> to display attendance sheet and vacation in empattendance table joined with shifts with working days
IF @Type IN (10)
BEGIN
    ---- puting the legend of vacations and shift codes
    
    DECLARE @updateQuery   AS NVARCHAR(4000),
            @vaccodequery  AS NVARCHAR(4000)
    
    SET @vaccodequery = (
            CASE 
                 WHEN @vaccodes IS NOT NULL
            AND @vaccodes <> '' THEN 
                'vacflag = (CASE WHEN Vacation.vaccode IN ( ' + @vaccodes + 
                ' ) THEN 1 ELSE 0 END ),' ELSE 
                'vacflag = (CASE WHEN Vacation.vaccode is not null THEN 1 ELSE 0 END ), '
                END
        )
    
    PRINT @vaccodequery
    SET @updateQuery = 
        'UPDATE #EmpAttend
		SET VacType = isnull(Vacation.vactype,0), Shiftno = (CASE WHEN EmpAttendance.VacCode ='''' OR EmpAttendance.VacCode IS NULL THEN empshift.ShiftNo ELSE Null END ), '
        +
        + @vaccodequery + 
        ' [Value] = ISNULL(ISNULL(Cast(Vacation.legend AS nVARCHAR(8)),ltrim(rtrim(str(empshift.ShiftNo)))),value) '
        +
        ' FROM EmpAssignment LEFT OUTER JOIN EmpAttendance ON EmpAssignment.EmpId = EmpAttendance.EmpId and (Convert(datetime,EmpAttendance.AttendDate,111) between '''
        + CONVERT(NVARCHAR(10), @from, 111) + ''' and ''' + CONVERT(NVARCHAR(10), @to, 111)
        + ''') ' +
        ' LEFT OUTER JOIN Vacation ON Vacation.vaccode = EmpAttendance.VacCode '
        +
        ' FULL OUTER JOIN EmpShift ON EmpShift.EmpId = EmpAssignment.EmpId AND Empshift.ShiftDate= empattendance.AttendDate '
        +
        ' LEFT OUTER JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo ' +
        ' where isnull(empattendance.AttendDate,Empshift.ShiftDate)=#EmpAttend.[Date] and  #EmpAttend.empid = isnull(empattendance.empid,EmpShift.EmpId) '
    
    PRINT @updateQuery
    EXECUTE (@updateQuery)
    
      INSERT INTO #EmpHiringHistory
  
  EXECUTE
  (
  	'SELECT distinct #EmpAttend.EmpId,EmpAssignment.HireDate,
                  (Case when EmpAssignment.TermDate IS NULL AND iSNULL(Profile.FirstHireddate,EmpAssignment.Hiredate)<>EmpAssignment.Hiredate
                  then (SELECT TOP 1 EmpStatusHdr.EffectiveDate FROM EmpStatusHdr 
                  inner JOIN EmpStatusDtl ON EmpStatusHdr.EmpId = EmpStatusDtl.EmpId AND EmpStatusHdr.DocumentNo = EmpStatusDtl.DocumentNo
              LEFT JOIN HrStatus ON EmpStatusDtl.NewValue = HrStatus.hrstatus
               LEFT JOIN HrStatus OldStatus ON OldStatus.hrstatus = dbo.GetOldValue(EmpStatusDtl.EmpId,1,EmpStatusHdr.EffectiveDate,NULL)
                  WHERE EmpStatusDtl.FieldNo=1 AND EmpStatusHdr.DocumentStatus=1 AND EmpStatusHdr.EmpId=#EmpAttend.EmpId AND OldStatus.paystatus=1 AND HrStatus.paystatus=2
                  ORDER BY EmpStatusHdr.EffectiveDate DESC)
                 else EmpAssignment.TermDate end) AS TermDate ,Profile.FirstHiredDate
FROM #EmpAttend inner join EmpAssignment on EmpAssignment.EmpId = #EmpAttend.EmpId inner join Profile on Profile.ProfileId = EmpAssignment.EmpId '
  )
    
    --------------------------------------------------- calculating the paid(work) days  workdays(30-vacations) + inputamount(paycode 202) --------------------------------------------------------------------------------------------------------------------------------
--SELECT * FROM #EmpHiringHistory

       
       --        UPDATE #EmpAttend
       -- SET    workdays = Case when iSNULL(#EmpHiringHistory.FirstHireddate,#EmpHiringHistory.Hiredate)<>#EmpHiringHistory.Hiredate and (#EmpHiringHistory.FirstHireddate>@to OR (#EmpHiringHistory.TermDate<@from AND (#EmpHiringHistory.Hiredate<@from OR #EmpHiringHistory.Hiredate>@to  )))
							--then 0 else dbo.EmpWorkdays(#EmpAttend.EmpId,30,@from,@to,0,1,@vaccodes,1,'202',8) END
       -- FROM   #EmpAttend INNER JOIN #EmpHiringHistory ON #EmpHiringHistory.EmpId = #EmpAttend.EmpId      
       -- WHERE  #EmpAttend.Date = @from

                       UPDATE #EmpAttend
        SET    workdays = Case when iSNULL(#EmpHiringHistory.FirstHireddate,#EmpHiringHistory.Hiredate)<>#EmpHiringHistory.Hiredate and (#EmpHiringHistory.FirstHireddate>@to OR (#EmpHiringHistory.TermDate<@from AND (#EmpHiringHistory.TermDate>#EmpHiringHistory.Hiredate  or #EmpHiringHistory.Hiredate>@to ) ))
							then 0 else dbo.EmpWorkdays(#EmpAttend.EmpId,30,@from,@to,0,1,@vaccodes,1,'202',8) END
        FROM   #EmpAttend INNER JOIN #EmpHiringHistory ON #EmpHiringHistory.EmpId = #EmpAttend.EmpId      
        WHERE  #EmpAttend.Date = @from
 	 	    		
 	 	    		
END
DECLARE @from2 AS NVARCHAR(4000)

SET @from2 = 
    ' from #EmpAttend  left join EmpAssignment on EmpAssignment.empid=#EmpAttend.empid left join Profile on EmpAssignment.empid=profile.profileid LEFT JOIN  Positions ON EmpAssignment.PositionNo = Positions.PositionNo LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job LEFT JOIN  JobCat ON JobCat.jobcat=Jobs.jobcat LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId LEFT JOIN CostCntr ON EmpAssignment.Center = CostCntr.Center LEFT JOIN CostCGrp ON CostCntr.CenterGrp = CostCGrp.CenterGrp LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade LEFT JOIN OrganizationType RIGHT JOIN Organization ON OrganizationType.OrganizationType = Organization.OrganizationType ON EmpAssignment.Organization = Organization.Organization LEFT JOIN Organization Organization_1 RIGHT JOIN Organization Organization_2 RIGHT JOIN Organization Organization_4 RIGHT JOIN OrganizationStructure LEFT JOIN Organization Organization_5 ON OrganizationStructure.Organization5 = Organization_5.Organization ON Organization_4.Organization = OrganizationStructure.Organization4 LEFT JOIN Organization Organization_3 ON OrganizationStructure.Organization3 = Organization_3.Organization ON Organization_2.Organization = OrganizationStructure.Organization2 ON Organization_1.Organization = OrganizationStructure.Organization1 ON Organization.Organization = OrganizationStructure.Organization '

SET @Query = 
    ' select #EmpAttend.EmpId,
                     #EmpAttend.EmployeeId,
                     ltrim(rtrim(#EmpAttend.Name)) as Name,
                     ltrim(rtrim(#EmpAttend.AName)) as AName,
                     #EmpAttend.Date,
                     #EmpAttend.h_Date,
                     #EmpAttend.VacType,
                     #EmpAttend.shiftno,
                     #EmpAttend.vacflag,
                     #EmpAttend.workdays, 
                     #EmpAttend.Description,
                     ltrim(rtrim(#EmpAttend.Value)) as Value,
                     #EmpAttend.Color,
                     PayrollGroup.PayrollGroup,
                     ltrim(rtrim(PayrollGroup.PayrollGroupName)) as PayrollGroupName,
                     ltrim(rtrim(PayrollGroup.PayrollGroupAName)) as PayrollGroupAName '
    + @selectgroups + @from2
 
EXEC sp_executesql @Query

GO

