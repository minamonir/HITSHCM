
CREATE PROCEDURE [dbo].[AI_InsertQualificationMajor]
(
    @QualificationMajor SMALLINT = NULL OUTPUT,
    @QualificationMajorType  SMALLINT,
    @QualificationMajorName NVARCHAR(60)=N'',
    @QualificationMajorAName NVARCHAR(60)=N'',
    @QualificationMajorFName NVARCHAR(60)=N'',
    @QualificationMajorCons INT=0,
    @QualificationMajorNameCons NVARCHAR(250)=N'',
    @QualificationMajorANameCons NVARCHAR(250)=N'',
    @QualificationMajorFNameCons NVARCHAR(250)=N'',
    @QualificationMajorRoles NVARCHAR(MAX)=N'',
    @QualificationMajorOrgs NVARCHAR(MAX)=N'',
    @QualificationMajorRYear SMALLINT=0,
    @QualificationMajorRNo NVARCHAR(10)=N'',
    @QualificationMajorRDesc NVARCHAR(MAX)=N'',
    @UEnterBy NVARCHAR(80),
	@UEnterDate SMALLDATETIME=NULL,
    @UChangeBy NVARCHAR(80),
	@UChangeDate  SMALLDATETIME=NULL,
    @ReviewedBy NVARCHAR(80),
    @ApprovedBy NVARCHAR(80),
    @QualificationMajorOrder INT=0
)
AS
BEGIN
    SET NOCOUNT ON;

	IF NULLIF(LTRIM(RTRIM(@QualificationMajorName)), '') IS NULL
		BEGIN
			SET @QualificationMajor = NULL;  
			RETURN;                          
		END
    DECLARE @ExistingMajor SMALLINT;
    
    /* =========================================================
       Check if qualification major already exists
       ========================================================= */
    SELECT @ExistingMajor = QualificationMajor
    FROM dbo.QualificationMajor
    WHERE QualificationMajorName = @QualificationMajorName
        AND QualificationMajorType = @QualificationMajorType;
    
    /* =========================================================
       If it exists, return the existing major ID
       ========================================================= */
    IF @ExistingMajor IS NOT NULL
    BEGIN
        SET @QualificationMajor = @ExistingMajor;
        RETURN; 
    END

    /* =========================================================
       Generate PK if NULL (only if it doesn't exist)
       ========================================================= */
    IF @QualificationMajor IS NULL
    BEGIN
        DROP TABLE IF EXISTS #StoredResult;

        CREATE TABLE #StoredResult
        (
            PrimaryKey INT,
            IsUEnterByExists INT,
            OrgsColumn INT
        );

        INSERT INTO #StoredResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName = N'QualificationMajor',
            @PkFieldName = N'QualificationMajor',
            @LogonName = @UEnterBy;

        SELECT @QualificationMajor = PrimaryKey
        FROM #StoredResult;
        
        DROP TABLE #StoredResult;
    END

    /* =========================================================
       Insert QualificationMajor (only if it doesn't exist)
       ========================================================= */
    INSERT INTO dbo.QualificationMajor
    (
        QualificationMajor,
        QualificationMajorType,
        QualificationMajorName,
        QualificationMajorAName,
        QualificationMajorFName,
        QualificationMajorCons,
        QualificationMajorNameCons,
        QualificationMajorANameCons,
        QualificationMajorFNameCons,
        QualificationMajorRoles,
        QualificationMajorOrgs,
        QualificationMajorRYear,
        QualificationMajorRNo,
        QualificationMajorRDesc,
        UEnterBy,
		UEnterDate,
     
        QualificationMajorOrder
    )
    VALUES
    (
        @QualificationMajor,
        @QualificationMajorType,
        @QualificationMajorName,
        @QualificationMajorAName,
        @QualificationMajorFName,
        @QualificationMajorCons,
        @QualificationMajorNameCons,
        @QualificationMajorANameCons,
        @QualificationMajorFNameCons,
        @QualificationMajorRoles,
        @QualificationMajorOrgs,
        @QualificationMajorRYear,
        @QualificationMajorRNo,
        @QualificationMajorRDesc,
        @UEnterBy,
		@UEnterDate,
     
        @QualificationMajorOrder
    );
END

GO

