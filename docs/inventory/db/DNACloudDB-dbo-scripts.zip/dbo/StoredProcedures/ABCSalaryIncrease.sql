

CREATE PROCEDURE [dbo].[ABCSalaryIncrease](@budgetNo SMALLINT, @calendarNo SMALLINT, @period SMALLINT,
@zoneStartDate1 SmallDATETIME, @zoneStartDate2 SMALLDATETIME, @filterselect nvarchar(max)='', @filterwhere nvarchar(max)='')

AS
BEGIN
declare @Select as nvarchar(max)
declare @From as nvarchar(max)
declare @From2 as nvarchar(max)

CREATE TABLE #t (
			EmpId INT
		   ,EmployeeId  nVARCHAR(50) 
		   ,DocumnetNo INT
		   ,Name  nVARCHAR(120)  
           ,Grade smallint 
           ,GradeName  nVARCHAR(250)  
           ,AppraisalNo  INT
           ,AppraisalName  nVARCHAR(120)
           ,ScaleNo  smallint
           ,ScaleName  nVARCHAR(120)  
           ,LevelName nVARCHAR(120)   
           ,AppraisalResult numeric(18,3) 
           ,TotalSal  numeric(18,3) 
           ,bonus  numeric(18,3)   
           ,BudgetMidAmount numeric(18,3)     
           ,RSP numeric(18,3)
           ,Zone   numeric(18,3)  
           ,Factor numeric(18,3)
           ,IncreaseSalary numeric(18,3)
           ,GroupLevel1 numeric (18,3)
           ,GroupName1 nvarchar(250)
           ,GroupLevel2 numeric (18,3)
           ,GroupName2 nvarchar(250)
           ,GroupLevel3 numeric (18,3)
           ,GroupName3 nvarchar(250)
           ,GroupLevel4 numeric (18,3)
           ,GroupName4 nvarchar(250)
           ,GroupLevel5 numeric (18,3)
           ,GroupName5 nvarchar(250)
           ,GroupLevel6 numeric (18,3)
           ,GroupName6 nvarchar(250)
           ,GroupLevel7 numeric (18,3)
           ,GroupName7 nvarchar(250)
           ,GroupLevel8 numeric (18,3)
           ,GroupName8 nvarchar(250)
)

Set @Select=
 ' INSERT INTO #t(
		  EmpId,EmployeeId, DocumnetNo,Name, Grade, GradeName, AppraisalNo, AppraisalName, ScaleNo,ScaleName, LevelName,
		  AppraisalResult, TotalSal, bonus, BudgetMidAmount, RSP, Zone, Factor,IncreaseSalary,
		  GroupLevel1, GroupName1, GroupLevel2, GroupName2, GroupLevel3, GroupName3, GroupLevel4, GroupName4,
		  GroupLevel5, GroupName5, GroupLevel6, GroupName6, GroupLevel7, GroupName7, GroupLevel8, GroupName8 )' 
+' SELECT Distinct EmpAssignment.EmpId,EmpAssignment.EmployeeId, EmpAppraisal.DocumentNo,Profile.Name,EmpAssignment.Grade, Grades.GradeName,
		  Appraisals.AppraisalNo, Appraisals.AppraisalName,RatingScales.RatingScale, RatingScales.ScaleName,
		  dbo.GetRatingLevelName(RatingScales.RatingScale,EmpAppraisal.AppraisalResult,''E''),
		  EmpAppraisal.AppraisalResult, EmpAssignment.TotalSal, EmpAssignment.SsBonVal, ISNULL(HRBudgetValues.MidAmount,0) as MidAmount,
		  CASE when isnull(HRBudgetValues.MidAmount,0)=0 THEN 0 
		  ELSE (EmpAssignment.TotalSal+EmpAssignment.SsBonVal)/HRBudgetValues.MidAmount END  AS RSP, 0, 0 ,0' 
		 -- RSP =(Total Salary + Bonus) / Budget Mid Amount
SET @From=
' FROM EmpAssignment
		LEFT JOIN Grades ON Grades.Grade = EmpAssignment.Grade 
		LEFT JOIN EmpAppraisal ON EmpAppraisal.EmpId = EmpAssignment.EmpId 
		LEFT JOIN Appraisals on EmpAppraisal.AppraisalNo= Appraisals.AppraisalNo 
		LEFT JOIN RatingScales on Appraisals.RatingScale=RatingScales.RatingScale 
		LEFT JOIN HRBudgetValues ON HRBudgetValues.Grade=EmpAssignment.Grade AND HRBudgetValues.BudgetNo='+str(@budgetNo)+' 
		AND HRBudgetValues.CalendarNo='+str(@calendarNo)+' 
		AND HRBudgetValues.CalendarYear='+STR(YEAR(GETDATE()))+' AND HRBudgetValues.CalendarPeriod='+STR(@period)+' '
SET @From2= 'LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
		LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
		LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job 
		LEFT JOIN Positions ON SSGroup.SSGroup = Positions.SSGroup AND Jobs.job = Positions.Job 
		LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
		LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.hrstatus
		LEFT JOIN AppraisalActions on AppraisalActions.AppraisalAction=EmpAppraisal.AppraisalAction
		LEFT JOIN AppraisalTypes on AppraisalTypes.AppraisalType=Appraisals.AppraisalType
		LEFT JOIN AppraisalQuestions on AppraisalQuestions.AppraisalNo=Appraisals.AppraisalNo
		LEFT JOIN Questions on Questions.QuestionNo=AppraisalQuestions.QuestionNo
		LEFT JOIN AppraisalCompetencies on AppraisalCompetencies.AppraisalNo=Appraisals.AppraisalNo
		LEFT JOIN Competencies on AppraisalCompetencies.Competence=Competencies.Competence
		LEFT JOIN TypesCompetencies on TypesCompetencies.Competence=Competencies.Competence
		LEFT JOIN CompetenceTypes on CompetenceTypes.CompetenceType=TypesCompetencies.CompetenceType
		LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
		LEFT JOIN JobCat ON Jobs.JobCat=JobCat.JobCat
		LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
		LEFT JOIN CostCntr ON CostCntr.center = EmpAssignment.Center 
		LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
		LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo  
		LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType
		LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
		LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1'
	
PRINT @Select
PRINT @filterselect
PRINT @From
PRINT @From2
PRINT ' WHERE 1=1 '+ @filterwhere 
				
Execute ( @Select +@filterselect+@From+ @From2+ ' WHERE 1=1 ' + @filterwhere)


/* Update Zone according to RSP value */
	      
UPDATE #t 
SET	#t.Zone =(SELECT case when #t.RSP>=125 THEN 125 ELSE min(cast(Zones.Zone AS numeric(18,3)))end
	      FROM Zones
	      WHERE Zones.Zone>=#t.RSP)
	      
/* Update Factor according to the Grade Zone & Rating Level Name & PayCOde=100 */ 
   
UPDATE #t 
SET	Factor = (case WHEN ltrim(rtrim(#t.LevelName))=ltrim(rtrim('Improvement Required')) 
					  Then (SELECT MinAmount 
   							FROM GradeZone
					        WHERE Zone=#t.Zone
							AND #t.Grade=GradeZone.Grade
							AND Paycode=100 AND StartDate=@zoneStartDate2)
					  ELSE (
					  	SELECT case WHEN ltrim(rtrim(#t.LevelName))=ltrim(rtrim('Good')) 
							Then MaxAmount
							WHEN  ltrim(rtrim(#t.LevelName))=ltrim(rtrim('Very Good'))
							Then MidAmount
							WHEN  ltrim(rtrim(#t.LevelName))=ltrim(rtrim('Excellent'))
							Then MinAmount
							ELSE 0 end
   						FROM GradeZone
   						WHERE GradeZone.Zone=#t.Zone
							 AND #t.Grade=GradeZone.Grade
							 AND Paycode=100 AND StartDate=@zoneStartDate1)
   	                  END  
					)
   	                 
SELECT EmpId,EmployeeId,DocumnetNo,[Name],Grade,GradeName,AppraisalNo,AppraisalName,ScaleNo,ScaleName,LevelName,AppraisalResult,
	   TotalSal,bonus,BudgetMidAmount,RSP,Zone,ISNULL(Factor,0) AS Factor,
	   ISNULL(((TotalSal+bonus)*12)*(ISNULL(Factor,0)/100),0) as IncreaseSalary,  -- IncreaseSalary = ((Total Salary + Bonus)*12) *(Factor/100)
	   GroupLevel1,GroupName1,GroupLevel2, GroupName2, GroupLevel3, GroupName3,GroupLevel4, GroupName4,
	   GroupLevel5, GroupName5, GroupLevel6, GroupName6,GroupLevel7, GroupName7, GroupLevel8, GroupName8
FROM #t 	


DROP TABLE #t

END

GO

