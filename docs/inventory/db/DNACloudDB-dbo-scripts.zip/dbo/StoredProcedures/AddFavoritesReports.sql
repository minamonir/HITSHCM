--EXEC AddFavoritesReports '1' , NULL , 202 , 'E' , 1

CREATE PROCEDURE [dbo].[AddFavoritesReports](@LogonName as nvarchar(80),@mydate AS SMALLDATETIME,@reportno SMALLINT,@lang as nchar(1),@action smallint)

AS

--@action = 1 Favorite
--@action <> 1 UnFavorite
--NasUsersReports.ShareType = 1 Favorite


DECLARE @ResultMsg AS NvarCHAR(MAX)=N'',@exist AS SMALLINT=0,@update AS SMALLINT=0
DECLARE @Count INT
IF @action = 1
BEGIN
	SELECT @exist=COUNT(*),@update=MAX(ShareType) FROM NasUsersReports WHERE LogonName=@LogonName AND ReportNo=@reportno AND Sharedby=@LogonName 

	IF isnull(@exist,0)=0
	BEGIN
		INSERT INTO NasUsersReports (LogonName, ReportNo, Sharedby, SharedDate, SharedStatus, ShareType, CanShare)
		SELECT @LogonName,@reportno,@LogonName,ISNULL(@mydate,GETDATE()),0,1,0
		SET @ResultMsg=ISNULL(dbo.Hits_GetDCCaptionWzLogon('FavRepot','Add',@Lang,@LogonName),(CASE WHEN @Lang='E' THEN N'Report added to your favorites' ELSE N'تمت إضافة التقرير إلى المفضلة' END))
		SELECT @Count = COUNT(*) FROM NasUsersReports WHERE LogonName=@LogonName AND Sharedby=@LogonName AND ShareType=1
	END
	ELSE IF @update=1 
	BEGIN
		SET @ResultMsg=ISNULL(dbo.Hits_GetDCCaptionWzLogon('FavRepot','Exist',@Lang,@LogonName),(CASE WHEN @Lang='E' THEN N'Report already in your favorites' ELSE N'التقرير موجود في المفضلة' END))
		SELECT @Count = -1
	END
	ELSE
	BEGIN --will never happen
		UPDATE NasUsersReports SET ShareType=1  WHERE LogonName=@LogonName AND ReportNo=@reportno AND Sharedby=@LogonName 
		SET @ResultMsg=ISNULL(dbo.Hits_GetDCCaptionWzLogon('FavRepot','Add',@Lang,@LogonName),(CASE WHEN @Lang='E' THEN N'Report added to your favorites' ELSE N'تمت إضافة التقرير إلى المفضلة' END))
		SELECT @Count = COUNT(*) FROM NasUsersReports WHERE LogonName=@LogonName AND Sharedby=@LogonName AND ShareType=1
	END
END

ELSE
BEGIN
	DELETE FROM NasUsersReports WHERE LogonName=@LogonName AND ReportNo=@reportno AND Sharedby=@LogonName AND ShareType=1
	SET @ResultMsg=ISNULL(dbo.Hits_GetDCCaptionWzLogon('FavRepot','Remove',@Lang,@LogonName),(CASE WHEN @Lang='E' THEN N'Report already in your favorites' ELSE N'تمت مسح التقرير من المفضلة' END))
	SELECT @Count = 0 --COUNT(*) FROM NasUsersReports WHERE LogonName=@LogonName AND Sharedby=@LogonName AND ShareType=1
END

SELECT @ResultMsg AS ResultMsg , @Count AS ShowFavTab

--SELECT * FROM NasUsersReports where NasUsersReports.LogonName = '1' and NasUsersReports.ShareType=1

GO

