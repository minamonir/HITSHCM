
CREATE PROCEDURE [dbo].[AI_InsertTrainingActivitiesCategories] (
	@ActivityNo SMALLINT
	,@CategoryName NVARCHAR(120)
	,@LogonName NVARCHAR(80)
	)
AS
BEGIN
	DECLARE @CategoryNo AS SMALLINT = 0

	SET @CategoryNo = ISNULL((
				SELECT TOP 1 TrainingCategories.TrainingCategory
				FROM TrainingCategories
				WHERE LTRIM(RTRIM(TrainingCategoryName)) = LTRIM(RTRIM(@CategoryName))
					OR LTRIM(RTRIM(TrainingCategoryAName)) = LTRIM(RTRIM(@CategoryName))
				), 0)

	IF @CategoryNo = 0
	BEGIN
		CREATE TABLE #StoredResult (
			PrimaryKey INT
			,IsUEnterByExists INT
			,OrgsColumn INT
			);

		INSERT INTO #StoredResult
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'TrainingCategories'
			,@PkFieldName = N'TrainingCategory'
			,@LogonName = @LogonName;

		SELECT @CategoryNo = PrimaryKey
		FROM #StoredResult;

		INSERT INTO [dbo].[TrainingCategories] (
			[TrainingCategory]
			,[TrainingCategoryName]
			,[TrainingCategoryAName]
			,[TrainingCategoryFName]
			,[UEnterBy]
			,[UEnterDate]
			)
		VALUES (
			@CategoryNo
			,@CategoryName
			,@CategoryName
			,@CategoryName
			,@LogonName
			,GETDATE()
			)
	END

	IF NOT EXISTS (
			SELECT 1
			FROM [dbo].[TrainingActivitiesCategories]
			WHERE [TrainingActivity] = @ActivityNo
				AND [TrainingCategory] = @CategoryNo
			)
	BEGIN
		INSERT INTO [dbo].[TrainingActivitiesCategories] (
			[TrainingActivity]
			,[TrainingCategory]
			)
		VALUES (
			@ActivityNo
			,@CategoryNo
			);
	END
END

GO

