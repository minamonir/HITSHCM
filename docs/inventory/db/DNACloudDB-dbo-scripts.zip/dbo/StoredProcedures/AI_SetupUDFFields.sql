CREATE PROCEDURE [dbo].[AI_SetupUDFFields]
    @FormNo smallint = 10,
    @Caption nvarchar(250) = '',
    @FieldNo smallint OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    IF NOT EXISTS (SELECT 1 FROM UserFieldsNames WHERE FormNo = @FormNo AND FieldCaption = @Caption)
    BEGIN
        EXEC [dbo].[Insert_UserFieldsNames]
            @FormNo = @FormNo,
            @FieldNo = @FieldNo OUTPUT,
            @FieldCaption = @Caption,
            @FieldACaption = @Caption,
            @FieldType = 1,
            @FieldOrder = 0,
            @Required = 0,
            @DefaultValue = '',
            @MinValue = 0,
            @MaxValue = 0,
            @MaxLength = 0,
            @MultiLine = 0,
            @UserFieldsGroup = NULL;
    END
    ELSE
    BEGIN
        SELECT @FieldNo = FieldNo 
        FROM UserFieldsNames 
        WHERE FormNo = @FormNo AND FieldCaption = @Caption;
    END

    IF NOT EXISTS( SELECT 1 FROM dbo.UserFieldsCodes   WHERE FormNo = @FormNo  AND FieldNo = @FieldNo)
      BEGIN
        EXEC [dbo].[Insert_UserfieldsCodes]
            @Form = @FormNo,
            @FieldNo = @FieldNo,
            @FieldOrder = 0,
            @Required = 0,
            @DefaultValue = N'',
            @MinValue = 0,
            @MaxValue = 0,
            @MaxLength = 0;
    END
END

GO

