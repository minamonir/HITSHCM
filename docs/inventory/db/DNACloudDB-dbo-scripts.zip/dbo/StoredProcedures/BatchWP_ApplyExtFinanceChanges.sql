-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[BatchWP_ApplyExtFinanceChanges]
	
(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS smallint,@Where AS nvarchar(max),@Paramaters AS nvarchar(max),@outputstr AS nvarchar(max)output) AS

DECLARE @SELECT AS nvarchar(max), @ChgField AS nvarchar(10), @ChckBxAdd AS nvarchar(10)
,@Transaction  AS nvarchar(10), @EffectDate AS nvarchar(10), @Descr AS nvarchar(max), @ProfileChngBy AS nvarchar(10)
DECLARE @error AS INT =0,@errormsg AS NVARCHAR(max)=''

IF @actiontype=1			--------Batch Actions--------
begin

SET @ChgField =substring(@Paramaters, 0, charindex(',',@Paramaters,0 ) )
SET @ChckBxAdd= substring(@Paramaters, charindex(',',@Paramaters,0 )+1, len(@Paramaters) )

	PRINT @ChgField
	
SET @Transaction =substring(@Where, 0, charindex(',',@Where,0 ) )
PRINT @Transaction
SET @Where= substring(@Where, charindex(',',@Where,0 )+1, len(@Where) )
PRINT @Where
SET @EffectDate=substring(@Where, 0, charindex(',',@Where,0 ) )
PRINT @EffectDate
SET @Where= substring(@Where, charindex(',',@Where,0 )+1, len(@Where) )
PRINT @Where
SET @ProfileChngBy=substring(@Where, 0, charindex(',',@Where,0 ) )
	PRINT @ProfileChngBy

SET @Descr= substring(@Where, charindex(',',@Where,0 )+1, len(@Where) )
		PRINT @Descr
SET @Descr= (SELECT CASE WHEN rtrim(ltrim(@Descr))='0' THEN '' ELSE @Descr END)	
PRINT 	@Descr

--PRINT @ChckBxAdd

	IF @ChckBxAdd='false'
	BEGIN
		PRINT 'No COS Add'
		
			IF @ChgField=13		----No Of Points
			BEGIN			
			select @select='UPDATE EmpAssignment set hrpoints =isnull(t.NewValue,0.0)
						FROM '+ @tablename+' t  INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default=t.empid collate database_default
						WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' '
			END
		
			IF @ChgField=14		----Basic Salary
			BEGIN
			select @select='UPDATE EmpAssignment set hrbasicsal =isnull(t.NewValue,0.0)
						FROM '+ @tablename+' t  INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default=t.empid collate database_default
						WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''''
			END
		
			IF @ChgField=16		----Fixed Insurance
			BEGIN
			select @select='UPDATE EmpAssignment set hrssfixval =isnull(t.NewValue,0.0)
						FROM '+ @tablename+' t  INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default = t.empid collate database_default
							WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''''
			END
				
			IF @ChgField=17		----Variable Insurance
			BEGIN
			select @select='UPDATE EmpAssignment set hrssvarval =isnull(t.NewValue,0.0)
							FROM '+ @tablename+' t  INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default=t.empid collate database_default
							WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' '
			END
		
			IF @ChgField=18		----Bonus Salary
			BEGIN
			select @select='UPDATE EmpAssignment set hrssbonval =isnull(t.NewValue,0.0)
							FROM '+ @tablename+' t  INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default=t.empid collate database_default
							WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''''
			END
		
			IF @ChgField=20		----Agreed Salary
			BEGIN
				select @select='UPDATE EmpAssignment set ContBasSal =isnull(t.NewValue,0.0)
							FROM '+ @tablename+' t  INNER JOIN EmpAssignment ON EmpAssignment.EmployeeId collate database_default=t.empid collate database_default
							WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' '
			END

			IF @ChgField>1000		------Other Paycodes
			BEGIN
		
			SET @ChgField= @ChgField-1000
						
			select @select= 'update HrPCodes set inputamnt=isnull(t.NewValue,0.0)
							FROM '+ @tablename+' t  INNER JOIN EmpAssignment ea ON ea.EmployeeId collate database_default=t.empid collate database_default
							WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' and HrPCodes.empid = ea.empid and HrPCodes.paycode='+@ChgField
			PRINT @SELECT
			EXECUTE (@SELECT)
			
			select @select=' INSERT INTO HrPCodes (empid, paycode, inputamnt)
						SELECT 	 e.empid,'+@ChgField +', isnull(t.NewValue,0.0)
						FROM '+@tablename+' t 
						inner join empassignment e on e.employeeid collate database_default=t.empid collate database_default
						WHERE  t.post =1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' and isnull(t.NewValue,0.0) <> 0 and  ltrim(rtrim(str(e.EmpId)))+''-''+ltrim(rtrim(str('+@ChgField+')))
						NOT IN (SELECT DISTINCT ltrim(rtrim(str(hp.EmpId)))+''-''+ltrim(rtrim(str(hp.paycode)))
						FROM HrPCodes hp where e.empid=hp.empid )'
	
			END
	PRINT @SELECT
	EXECUTE (@SELECT)
	
	END
	
	ELSE
	BEGIN
				------Chckbx is checked so add change of status record
		PRINT 'COS Add'
		
--		select @select=' update profile set profilechangeby='+ @ProfileChngBy +	' FROM '+ @tablename+' t  INNER JOIN EmpAssignment ea ON ea.EmployeeId=t.empid 
--		                 where   t.post =1 and   ProfileId=ea.empid'
--		PRINT @SELECT
--		EXECUTE (@SELECT)
------------------------	EXEC sp_executesql @SELECT,@Params,@DocNo OUTPUT 


	DECLARE @empid AS int ,@NewValue AS numeric(18, 3),@DocNo AS nvarchar(10), @HrCur AS smallint, @AddTotal Bit,@OldValue AS numeric(18, 3), @TotalSal AS numeric(18, 3)
	CREATE TABLE #Temp (Empid INT ,Docno int)
		 exec(' declare tempemployee cursor for select e.empid, isnull(t.NewValue,0.0), e.HrCurrency, isnull(t.OldValue,0.0),e.HrTotalSal  from '+ @TableName +'t
		       inner join empassignment e on e.employeeid collate database_default= t.empid collate database_default  where t.post=1 and rtrim(ltrim(isnull(t.remarks,'''')))='''' and isnull(t.NewValue,0.0) <> isnull(t.OldValue,0.0)' )		
		OPEN tempemployee
		FETCH NEXT FROM tempemployee
		INTO  @empid,@NewValue,@HrCur,@OldValue,@TotalSal
		WHILE @@FETCH_STATUS = 0
		BEGIN
		SET @DocNo=dbo.GetDocumentNo (@empid ,1)
	
			select @select=' INSERT INTO  empstatushdr (empid, documentno, EffectiveDate, documentstatus,chgcode, hrcurrency, enterby, enterdate, ChgComment)
						     SELECT 	 ' +str(@empid)+', '+@DocNo+','''+@EffectDate+''',1,'+@Transaction+','+str(@HrCur)+','+@ProfileChngBy+',getdate(),N'''+@Descr+''''
		PRINT @SELECT
		EXECUTE (@SELECT)
		SET @error=@@error
	      IF @error <>0
		  BEGIN 
				SELECT @ErrorMsg=  replace (description,'''','''''')
				FROM hitssysmessages
				WHERE error=@error
	            EXEC ('update '+@TableName +' set Remarks = isnull(''' +@ErrorMsg+ ''','''') where empid='+@empid)
		   END 
	     ELSE 
		  BEGIN 
		  INSERT INTO #Temp  SELECT @empid ,@docno
		select @select=' INSERT INTO  empstatusdtl (empid, documentno, fieldno,newvalue)
						SELECT ' +str(@empid)+', '+@DocNo+','+@ChgField+','+CONVERT(nvarchar(19),@NewValue)
			
		PRINT @SELECT
		EXECUTE (@SELECT)	
		SET @error=@@error
		IF @error <>0
		  BEGIN 
				SELECT @ErrorMsg=  replace (description,'''','''''')
				FROM hitssysmessages
				WHERE error=@error
	           EXEC ('update '+@TableName +' set Remarks  = isnull(''' +@ErrorMsg+ ''','''') where empid='+@empid)
		  END 

		SET @AddTotal=(SELECT p.addtotsal FROM Paycode p WHERE p.code=(@ChgField-1000))
		IF @AddTotal =1 
		BEGIN
				select @select=' INSERT INTO  empstatusdtl (empid, documentno, fieldno,newvalue)
						SELECT ' +str(@empid)+', '+@DocNo+',15,'+CONVERT(nvarchar(19),(@TotalSal+@NewValue-@OldValue))
			
		PRINT @SELECT
		EXECUTE (@SELECT)	
		 SET @error=@@error

	              IF @error <>0
		            BEGIN 
				      SELECT @ErrorMsg=  replace (description,'''','''''')
				      FROM hitssysmessages
				      WHERE error=@error
	                   EXEC ('update '+@TableName +' set Remarks = isnull(''' +@ErrorMsg+ ''','''') where empid='+@empid)
		             END 	
		           END
				END 
		  FETCH NEXT FROM tempemployee
		  INTO  @empid,@NewValue,@HrCur,@OldValue,@TotalSal
		END
		CLOSE tempemployee
		DEALLOCATE tempemployee		
			-----------------------------------------------------------------------------------------------------------------------------------------------------
	    DECLARE Cursor_UpdateChanges cursor for SELECT empid ,docno FROM #temp
	    OPEN Cursor_UpdateChanges
		FETCH NEXT FROM Cursor_UpdateChanges INTO  @empid,@docno
		WHILE @@FETCH_STATUS = 0
		BEGIN
		PRINT LTRIM(RTRIM(STR(@empid)))+ ' - '+ LTRIM(RTRIM(STR(@DocNo)))
		exec hits_UpdateChanges @empid,@DocNo, @ProfileChngBy
		  FETCH NEXT FROM Cursor_UpdateChanges INTO  @empid,@docno
		END
		CLOSE Cursor_UpdateChanges
		DEALLOCATE Cursor_UpdateChanges		
		-----------------------------------------------------------------------------------------------------------------------------------------------------		
	END
END

IF @actiontype=2
BEGIN
		DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
		SET @t=@tablename
		SET @t=replace(@t,'dbo.[','')
		SET @t=replace(@t,']','')
		select @count=count(*) FROM sysobjects s WHERE s.name=@t
		
	
		IF @actual>0 SET @str='select 0 as empid,'''' as name, 0.00 as NewValue, 0.00 as OldValue,'''' as remarks,0 as post WHERE 1<>1'
		ELSE
			IF @count=1 SET @str='select * from '+@tablename
			ELSE
				SET @str='select 0 as empid,'''' as name, 0.00 as NewValue, 0.00 as OldValue,'''' as remarks,0 as post WHERE 1<>1'
	exec sp_executesql @str
	
END

IF @actiontype=3				-------Export------
								-------create temp table with same structure as Excel Sheet

	BEGIN
		DECLARE @updatestr AS nvarchar(max),
	@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
	@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100)

DECLARE @TableNamelen AS int 
SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1

DECLARE @DecimalScale AS int
SELECT  @DecimalScale= decimalscale FROM SysParam 

		IF rtrim(ltrim(@tablename))<>'' 
--		 SET @select='   CREATE TABLE ' + @tablename+ '(empid [int] ,name [nchar](88), NewValue [numeric](18,3), OldValue [numeric] (18,3),
--										remarks [nvarchar] (256), post	bit )'

	--SET @select ='IF not EXISTS(SELECT top 1 1
 --      FROM '+substring(@tablename,0,charindex('.dbo',@tablename))+'.INFORMATION_SCHEMA.Columns 
 --      WHERE  '+substring(@tablename,0,charindex('.dbo',@tablename))+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+SUBSTRING(@TableName,charindex('[nasbatch',@TableName)+1,@TableNamelen)+''')'
 --     + ' CREATE TABLE ' + @tablename+ '(empid [int] ,name [nchar](88) collate database_default, NewValue [numeric](18,3), OldValue [numeric] (18,3),
	--								remarks [nvarchar] (256), post	bit )'
									
		SET @select ='IF not EXISTS(SELECT top 1 1
       FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
       WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
         + ' CREATE TABLE ' + @tablename+ '(empid [nvarchar] (256) ,name [nchar](88) collate database_default, NewValue [numeric](18,3), OldValue [numeric] (18,3),
									remarks [nvarchar] (256), post	bit ,[Row_Number] int Identity(1,1) NOT NULL Primary Key)'
       								
--  + ' CREATE TABLE ' + @tablename+ '(empid [int] ,name [nchar](88),'+  (case 
--      when @DecimalScale=0 then  'NewValue numeric(18,0)' 
--      when @DecimalScale=1  then 'NewValue numeric(18,1)' 
--      when @DecimalScale=2  then 'NewValue numeric(18,2)' 
--      else	'NewValue numeric(18,3)'  end)+', '+  (case 
--      when @DecimalScale=0 then  'OldValue numeric(18,0)' 
--      when @DecimalScale=1  then 'OldValue numeric(18,1)' 
--      when @DecimalScale=2  then 'OldValue numeric(18,2)' 
--      else	'OldValue numeric(18,3)'  end)+' ,	remarks [nvarchar] (256), post	bit )'
										
		ELSE
			begin
			SET @tablename='  '
		 SET @selectstr='select 0 as empid,'''' as name, 0.00 as NewValue, 0.00 as OldValue,'''' as remarks,0 as post WHERE 1<>1'
			END
			

	SET @updatestr=' update '+@tablename+' set NewValue=round(@NewValue,'+STR(@DecimalScale)+'), OldValue=round(@OldValue,'+STR(@DecimalScale)+'),
											remarks=@remarks,post=@post
											 where isnull(ltrim(rtrim(Row_Number )),0)= isnull(ltrim(rtrim(@originalRow_Number )),0)'
	   
	SET @insertstr=' insert into '+@tablename+' select @empid ,	@name ,round(@NewValue,'+STR(@DecimalScale)+') ,round(@OldValue,'+STR(@DecimalScale)+') ,@remarks ,@post '


SET @deletestr=' delete from  '+@tablename+'  where isnull(ltrim(rtrim(Row_Number )),0)= isnull(ltrim(rtrim(@originalRow_Number )),0)'

    
			SET @DisabledColStr='1,2,4,5'
			exec sp_executesql @select
			SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr

	END
	
	IF @actiontype=4
	BEGIN
		set @outputstr = 'select 0 as empid,'' '' as name, 0.00 as NewValue, 0.00 as OldValue,'' '' as remarks,0 as post
 , identity(int,1,1) as [Row_Number] into #EndResultPagging  where 1<>1 '

	END

GO

