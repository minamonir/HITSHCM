CREATE PROCEDURE [dbo].[AssignBenefitPlan_EndOfService]
(
    @filterwhere AS NVARCHAR(MAX),
    @post AS BIT
)
AS
BEGIN

    DECLARE @str AS NVARCHAR(MAX)
        = ' SELECT DISTINCT EmpAssignment.EmpId,EmpAssignment.EmployeeId,Profile.Name,Profile.AName,EmpBenefit.EnrollDate,EmpAssignment.HireDate 
		FROM EmpAssignment 
		LEFT JOIN dbo.EmpBenefit ON EmpBenefit.EmpId = EmpAssignment.EmpId AND EmpBenefit.PlanNo =60 and EmpBenefit.OptionNo=50 
		LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId
		LEFT JOIN BenefitOptions ON BenefitOptions.OptionNo = EmpBenefit.OptionNo 
		LEFT JOIN BenefitPlans ON BenefitPlans.PlanNo = EmpBenefit.PlanNo 
		LEFT JOIN BenefitPlanTypes ON BenefitPlanTypes.PlanType=benefitplans.PlanType 
		LEFT JOIN BenefitPrograms ON EmpBenefit.ProgramNo = BenefitPrograms.ProgramNo
		LEFT JOIN SSDocumentStatus ON SSDocumentStatus.SSDocStatusNo = EmpBenefit.BenefitStatus 
		LEFT JOIN Currency ON BenefitPlans.PlanCur=Currency.Cur
		LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
		LEFT JOIN JobCat ON Jobs.jobcat=JobCat.jobcat
		LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
		LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
		LEFT JOIN GradeGroups ON GradeGroups.GradeGroup = Grades.GradeGroup 
		LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
		LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
		LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center
		LEFT JOIN CostCGrp ON CostCGrp.centergrp=CostCntr.centergrp
		LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
		LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
		LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack 
		LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
		LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType 
		LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
		LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
		LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
		LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
		LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
		LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
		LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
		LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status''
		LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus''
		LEFT JOIN NasArrays HrTaxStat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus''
		LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus'' 
		LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus''
		LEFT JOIN NasArrays NasArraysStatus ON NasArraysStatus.itemno = EmpBenefit.EmpBenefitRStatus AND NasArraysStatus.arrayname=''RStatus''
		LEFT JOIN NasArrays NasArraysSource ON NasArraysSource.itemno = EmpBenefit.EmpBenefitRSource AND NasArraysSource.arrayname=''RSource''
        WHERE DATEDIFF(dd, EmpAssignment.HireDate, CAST(GETDATE() AS DATE)) >= 2*365 AND EmpAssignment.Status = 1 AND EmpBenefit.EmpId IS NULL ' + @filterwhere;


    CREATE TABLE #temp
    (
        EmpId INT,
        EmployeeId NVARCHAR(50),
        Name NVARCHAR(MAX),
        AName NVARCHAR(MAX),
        EnrollDate DATE,
        HireDate DATE
    );
    INSERT INTO #temp
    (
        EmpId,
        EmployeeId,
        Name,
        AName,
        EnrollDate,
        HireDate
    )
    EXEC (@str);


    IF @post = 1
    BEGIN

        DECLARE @emp AS INT,
                @hire AS DATE,
                @Enroll DATE,
                @enterdate DATETIME;
        SELECT @enterdate = GETDATE();

        DECLARE cursor1 CURSOR FOR SELECT EmpId, HireDate FROM #temp;
        OPEN cursor1;
        FETCH NEXT FROM cursor1
        INTO @emp,
             @hire;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @DocumentNo INT;
            SELECT @Enroll = DATEADD(YY, 2, @hire);
            EXEC [Insert_EmpBenefit] @EmpId = @emp,                    -- int
                                     @DocumentNo = @DocumentNo OUTPUT, -- int
                                     @BenefitStatus = 1,               -- smallint
                                     @Closed = 0,                      -- bit
                                     @ProgramNo = NULL,                -- smallint
                                     @PlanNo = 60 ,                    -- smallint
                                     @OptionNo = 50 ,                    -- smallint
                                     @EnrollDate = @Enroll,            -- smalldatetime
                                     @EndDate = NULL,                  -- smalldatetime
                                     @CoverageAmount = 0,              -- numeric(18, 3)
                                     @LevelAmount = 0,                 -- numeric(18, 3)
                                     @PlanServiceNo = NULL,            -- smallint
                                     @PlanSupplierNo = NULL,           -- smallint
                                     @BenefitNote = N'',               -- nvarchar(max)
                                     @enterby = 99999999,              -- int
                                     @enterdate = @enterdate,          -- smalldatetime
                                     @chngby = NULL,                   -- int
                                     @chngdate = NULL,                 -- smalldatetime
                                     @wf = 0,                          -- bit
                                     @ssdocno = 0,                     -- smallint
                                     @EmpBenefitRYear = 0,             -- smallint
                                     @EmpBenefitRNo = N'',             -- nvarchar(10)
                                     @EmpBenefitRIssueDate = NULL,     -- datetime
                                     @EmpBenefitRExecDate = NULL,      -- datetime
                                     @EmpBenefitRStatus = NULL,        -- smallint
                                     @EmpBenefitRSource = NULL,        -- smallint
                                     @EmpBenefitRDesc = N'';           -- nvarchar(max)

            ----  UPDATE #temp SET EnrollDate=@Enroll WHERE EmpId=@emp
            FETCH NEXT FROM cursor1
            INTO @emp,
                 @hire;
        END;
        CLOSE cursor1;
        DEALLOCATE cursor1;


    END;

    SELECT DISTINCT
           #temp.EmpId,
           #temp.EmployeeId,
           #temp.Name,
           #temp.AName,
           DATEADD(YY, 2, #temp.HireDate) AS EnrollDate,
           #temp.HireDate
    FROM #temp;



END;

GO

