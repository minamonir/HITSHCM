

CREATE PROCEDURE [dbo].[Absenteeism_Attendance]
( @from int =0, @to INT=0,@filterselect nvarchar(max)='',@filterwhere nvarchar(max)='',@filtergroup nvarchar(max)='',@VacationCodes nvarchar(max)='')
as
BEGIN
DECLARE @select NVARCHAR(max),@from1 NVARCHAR(max),@group NVARCHAR(max),@where NVARCHAR(max)

set @select='select EmpAssignment.EmpId
     ,dbo.GetOrganizationParent(EmpAssignment.Organization,1,1,1,''e'') AS [Divsion]
     ,dbo.GetOrganizationParent(EmpAssignment.Organization,4,1,1,''e'') AS [Factory]
     , (COUNT(DISTINCT CASE WHEN WorkSeconds>0 AND ShiftSeconds >0 THEN EntryDate END)*1.00/ COUNT(DISTINCT CASE WHEN ShiftSeconds >0 THEN EntryDate END)) AS [Present]
	 , (COUNT(DISTINCT CASE WHEN dbo.EmpVacOrNot(EmpAssignment.EmpId,EntryDate)IN (0,1)  THEN EntryDate END)*1.00/ COUNT(DISTINCT CASE WHEN ShiftSeconds >0 THEN EntryDate END)) AS [Absent]
	 , CASE WHEN '+LTRIM(@from)+' = '+LTRIM(@to)+' THEN COUNT(DISTINCT CASE WHEN WorkSeconds>0 AND ShiftSeconds >0 THEN EmpAssignment.EmpId END) ELSE 0 end AS [Present Head Count]
	 , CASE WHEN '+LTRIM(@from)+' = '+LTRIM(@to)+' THEN COUNT(DISTINCT CASE WHEN dbo.EmpVacOrNot(EmpAssignment.EmpId,EntryDate)IN (0,1)  THEN EmpAssignment.EmpId END) ELSE 0 end AS [Absent Head Count]

	 '+@filterselect
set @from1='From EmpShiftInOut 
Left Join EmpAssignment ON EmpAssignment.EmpId=EmpShiftInOut.EmpId
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack
LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON JobCat.JobCat = Jobs.JobCat 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1
LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname = ''STATUS'' 
LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus''
LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus''
LEFT JOIN NasArrays HrTaxstat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus''
LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus''
LEFT JOIN NasArrays Gender ON Gender.itemno = Profile.Gender AND Gender.arrayname = ''Gender'''
SET @where =' WHERE 1=1 and dbo.GetOldValue(EmpAssignment.EmpId,1,CAST('''+str(@to)+'''AS SMALLDATETIME) ,0)=1  AND
 EntryDate BETWEEN CAST('''+str(@from)+''' AS SMALLDATETIME) AND CAST('''+str(@to)+''' AS SMALLDATETIME) AND ShiftSeconds>0 
'+@filterwhere
set @group='GROUP BY EmpAssignment.EmpId 
     ,dbo.GetOrganizationParent(EmpAssignment.Organization,1,1,1,''e'') 
     ,dbo.GetOrganizationParent(EmpAssignment.Organization,4,1,1,''e'') 
	 '+@filtergroup

	CREATE TABLE #tktemp (empid INT,Divsion NVARCHAR(MAX),Factory NVARCHAR(MAX),present FLOAT,absent FLOAT,[Present Head Count] INT,[Absent Head Count] INT,
	GroupLevel1 int, GroupName1  NVARCHAR(250), GroupLevel2 int,  GroupName2  NVARCHAR(250),GroupLevel3 int,  GroupName3 NVARCHAR(250) , GroupLevel4 int, GroupName4  NVARCHAR(250),
	GroupLevel5 int, GroupName5  NVARCHAR(250),GroupLevel6 int, GroupName6  NVARCHAR(250),GroupLevel7 int, GroupName7 NVARCHAR(250),GroupLevel8 int, GroupName8 NVARCHAR(250))
	INSERT INTO #tktemp
	(
	    empid,
	    Divsion,
	    Factory,
	    present,
	    absent,
		[Present Head Count],
		[Absent Head Count],
	    GroupLevel1,
	    GroupName1,
	    GroupLevel2,
	    GroupName2,
	    GroupLevel3,
	    GroupName3,
	    GroupLevel4,
	    GroupName4,
	    GroupLevel5,
	    GroupName5,
	    GroupLevel6,
	    GroupName6,
	    GroupLevel7,
	    GroupName7,
	    GroupLevel8,
	    GroupName8
	)
		EXECUTE (@select + ' ' +@from1 +' '+@where+' '+ @group)
		--SELECT * FROM #tktemp

	CREATE TABLE #vactemp (empid int,Vacation FLOAT)
	INSERT INTO #vactemp
	(
		empid,
		Vacation
	)
	SELECT empid , dbo.VacationsTotalTaken(empid,CAST(CAST(@from AS VARCHAR(10)) AS SMALLDATETIME),CAST(CAST(@to AS VARCHAR(10)) AS SMALLDATETIME),@VacationCodes)
		FROM EmpAssignment 
	WHERE dbo.GetOldValue(EmpAssignment.EmpId,1,CAST(CAST(@to AS VARCHAR(10)) AS SMALLDATETIME),0)=1 AND empid IN (SELECT empid FROM #tktemp)
	--SELECT * FROM #vactemp
SELECT 
      Divsion AS [Divsion],
      Factory AS [Factory],
	  COUNT(DISTINCT #tktemp.EmpId) AS [Total Head Count],
	  SUM(present)/COUNT(DISTINCT #tktemp.EmpId)*100 AS [Present],
	  SUM(absent)/COUNT(DISTINCT #tktemp.EmpId)*100 AS [Absent],
	  [Present Head Count] AS [Present Head Count],
	  [Absent Head Count] AS [Absent Head Count],
	  COUNT(DISTINCT CASE WHEN Vacation>0 THEN #vactemp.EmpId end) AS [On Vacation],
	  SUM(absent)/COUNT(DISTINCT #tktemp.EmpId)*100 AS [Abs. %],
	  CASE WHEN @from = @to THEN 1 ELSE 0 end AS daily,
	  	GroupLevel1,
	    GroupName1,
	    GroupLevel2,
	    GroupName2,
	    GroupLevel3,
	    GroupName3,
	    GroupLevel4,
	    GroupName4,
	    GroupLevel5,
	    GroupName5,
	    GroupLevel6,
	    GroupName6,
	    GroupLevel7,
	    GroupName7,
	    GroupLevel8,
	    GroupName8
	  FROM #tktemp
	  left JOIN #vactemp ON #vactemp.empid = #tktemp.empid
	  GROUP BY   Divsion,
                 Factory,
                 [Present Head Count],
                 [Absent Head Count],
                 GroupLevel1,
                 GroupName1,
                 GroupLevel2,
                 GroupName2,
                 GroupLevel3,
                 GroupName3,
                 GroupLevel4,
                 GroupName4,
                 GroupLevel5,
                 GroupName5,
                 GroupLevel6,
                 GroupName6,
                 GroupLevel7,
                 GroupName7,
                 GroupLevel8,
                 GroupName8

DROP TABLE #tktemp,#vactemp
END

GO

