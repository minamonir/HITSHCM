CREATE PROCEDURE [dbo].[AI_InsertQualificationGrade]
(
    @QualificationGrade SMALLINT = NULL OUTPUT,
    @QualificationGradeType SMALLINT,
    @QualificationGradeName NVARCHAR(30)=N'',
    @QualificationGradeAName NVARCHAR(30)=N'',
    @QualificationGradeFName NVARCHAR(30)=N'',
    @QualificationGradeCons INT=0,
    @QualificationGradeNameCons NVARCHAR(250)=N'',
    @QualificationGradeANameCons NVARCHAR(250)=N'',
    @QualificationGradeFNameCons NVARCHAR(250)=N'',
    @QualificationGradeFromDate SMALLDATETIME=NULL,
    @QualificationGradeRoles NVARCHAR(MAX)=N'',
    @QualificationGradeOrgs NVARCHAR(MAX)=N'',
    @QualificationGradeRYear SMALLINT=0,
    @QualificationGradeRNo NVARCHAR(10)=N'',
    @QualificationGradeRDesc NVARCHAR(MAX)=N'',
    @UEnterBy NVARCHAR(80),
	@UEnterDate SMALLDATETIME=NULL,
    @UChangeBy NVARCHAR(80),
	@UChangeDate  SMALLDATETIME=NULL,
    @QualificationGradeOrder INT=0
)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @ExistingGrade SMALLINT;
    

	IF NULLIF(LTRIM(RTRIM(@QualificationGradeName)), '') IS NULL
		BEGIN
			SET @QualificationGrade = NULL;;
			RETURN;
		END

    /* =========================================================
    Check if qualification grade already exists
    ========================================================= */
    SELECT @ExistingGrade = QualificationGrade
    FROM dbo.QualificationGrade
    WHERE QualificationGradeName = @QualificationGradeName
        AND QualificationGradeType = @QualificationGradeType;
    
    /* =========================================================
    If it exists, return the existing grade ID
    ========================================================= */
    IF @ExistingGrade IS NOT NULL
    BEGIN
        SET @QualificationGrade = @ExistingGrade;
        RETURN; 
    END
    
    /* =========================================================
    Generate PK if NULL (only if it doesn't exist)
    ========================================================= */
    IF @QualificationGrade IS NULL
    BEGIN
        DROP TABLE IF EXISTS #StoredResult;
        CREATE TABLE #StoredResult
        (
            PrimaryKey INT,
            IsUEnterByExists INT,
            OrgsColumn INT
        );
        
        INSERT INTO #StoredResult
        EXEC dbo.GetMaxPrimaryKey
            @TableName = N'QualificationGrade',
            @PkFieldName = N'QualificationGrade',
            @LogonName = @UEnterBy;
            
        SELECT @QualificationGrade = PrimaryKey
        FROM #StoredResult;
        
        DROP TABLE #StoredResult;
    END
    
    /* =========================================================
    Insert QualificationGrade (only if it doesn't exist)
    ========================================================= */
    INSERT INTO dbo.QualificationGrade
    (
        QualificationGrade,
        QualificationGradeType,
        QualificationGradeName,
        QualificationGradeAName,
        QualificationGradeFName,
        QualificationGradeCons,
        QualificationGradeNameCons,
        QualificationGradeANameCons,
        QualificationGradeFNameCons,
        QualificationGradeFromDate,
        QualificationGradeRoles,
        QualificationGradeOrgs,
        QualificationGradeRYear,
        QualificationGradeRNo,
        QualificationGradeRDesc,
        UEnterBy,
		UEnterDate,
     
        QualificationGradeOrder
    )
    VALUES
    (
        @QualificationGrade,
        @QualificationGradeType,
        @QualificationGradeName,
        @QualificationGradeAName,
        @QualificationGradeFName,
        @QualificationGradeCons,
        @QualificationGradeNameCons,
        @QualificationGradeANameCons,
        @QualificationGradeFNameCons,
        @QualificationGradeFromDate,
        @QualificationGradeRoles,
        @QualificationGradeOrgs,
        @QualificationGradeRYear,
        @QualificationGradeRNo,
        @QualificationGradeRDesc,
        @UEnterBy,
		@UEnterDate,
     
        @QualificationGradeOrder
    );
END

GO

