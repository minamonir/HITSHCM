CREATE PROCEDURE [dbo].[BatchWB_ProcessHRRequests]  (@LogonName AS NVARCHAR(80) , @where as nvarchar(max) ,@action as nvarchar(10),@p_sort_str nvarchar(max),@p_page_number int,@p_batch_size int,@IncludeCount INT =0 )
AS 
BEGIN 
	
	------------------------
	IF @action=1
	BEGIN
		SELECT @where =@where +' '+ ' and EmpHRRequest.HRReqDate between isnull(HRRequest.HRReqFromDate, EmpHRRequest.HRReqDate ) and isnull(HRRequest.HRReqToDate,EmpHRRequest.HRReqDate )'
	END

	----------------------------
    declare @RoleProfileid as int ,@RecordsCount INT 
	select @RoleProfileid = empid FROM NasUsers WHERE LogonName=@LogonName

	declare @SelectSortStr AS nvarchar(100),@OrderSortStr AS nvarchar(100)
	IF @p_sort_str=''
	  BEGIN
		SET @SelectSortStr='[dbo].[HitsSort](EmpAssignment.EmployeeId,'''') as orderby'
		SET @OrderSortStr='emphrrequest.hrreqdate asc,[dbo].[HitsSort](EmpAssignment.EmployeeId,'''')'
	  END
	ELSE IF @p_sort_str LIKE '%EmployeeId%'
	  BEGIN
		SET @SelectSortStr='[dbo].[HitsSort](EmpAssignment.EmployeeId,'''')'
		SET @OrderSortStr='[dbo].[HitsSort](EmpAssignment.EmployeeId,'''')'+case when @p_sort_str LIKE '% desc%'  THEN 'desc' ELSE '' END +' ,emphrrequest.hrreqdate asc '
	  END
	ELSE IF @p_sort_str LIKE '%HRReqDate%'
	BEGIN
		set @SelectSortStr='1'
		SET @OrderSortStr= ltrim(@p_sort_str)
	END
	ELSE
	BEGIN
		set @SelectSortStr='1'
		SET @OrderSortStr= ltrim(@p_sort_str) +' ,emphrrequest.hrreqdate asc '
	END 
PRINT @SelectSortStr
PRINT @OrderSortStr 
PRINT @p_sort_str
PRINT @action

declare @str as nvarchar(max)

CREATE TABLE #EndResultPagging(EmployeeId  NVARCHAR(50) ,NAME NVARCHAR(88),AName NVARCHAR(88),HRReqCode SMALLINT , hrreqname NVARCHAR(60),hrreqaname NVARCHAR(60) ,hrreqdate SMALLDATETIME,
empid INT ,documentno INT ,completed BIT ,CompleteInfo NVARCHAR(MAX),[Orderby] nvarchar(100) NULL,[Row_Number] int IDENTITY(1,1))
	
if @action = 2
	BEGIN
	set @str = 'insert into #EndResultPagging (EmployeeId  ,NAME,AName ,HRReqCode  , hrreqname ,hrreqaname  ,hrreqdate ,empid  ,documentno  ,completed  ,CompleteInfo,[Orderby] )
	            SELECT DISTINCT EmpAssignment.EmployeeId, Profile.Name,Profile.AName,hrrequest.HRReqCode,hrrequest.hrreqname,hrrequest.hrreqaname,emphrrequest.hrreqdate,
                emphrrequest.empid ,emphrrequest.documentno,emphrrequest.Completed, emphrrequest.CompleteInfo AS CompleteInfo , '+@SelectSortStr+' 
                FROM  EmpHRRequest 
                INNER JOIN HRRequest ON EmpHRRequest.HRReqCode = HRRequest.HRReqCode 
                INNER JOIN EmpAssignment ON EmpHRRequest.EmpID = EmpAssignment.EmpId  
                INNER JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
                 INNER JOIN WFDocApproval  ON WFDocApproval.Empid = EmpHRRequest.EmpID and WFDocApproval.DocumentNo = EmpHRRequest.DocumentNo 
				and WFDocApproval.SSDocNo in(select ssdocno from SSDocument where ssdoctype=24)               
			 where  WFDocApproval.ApprovalProfileId='+str(@RoleProfileid)+'
             AND  EmpHRRequest.Completed=1 '+ @where +' order by ' +@OrderSortStr
    END 
ELSE 
    BEGIN 
    set @str = 'insert into #EndResultPagging (EmployeeId  ,NAME,AName ,HRReqCode  , hrreqname ,hrreqaname  ,hrreqdate ,empid  ,documentno  ,completed  ,CompleteInfo ,[Orderby])
                SELECT DISTINCT EmpAssignment.EmployeeId, Profile.Name,Profile.AName,hrrequest.HRReqCode,hrrequest.hrreqname,hrrequest.hrreqaname,emphrrequest.hrreqdate,
                emphrrequest.empid ,emphrrequest.documentno,emphrrequest.Completed, emphrrequest.CompleteInfo AS CompleteInfo ,'+@SelectSortStr+' 
                FROM  EmpHRRequest 
                INNER JOIN HRRequest ON EmpHRRequest.HRReqCode = HRRequest.HRReqCode 
                INNER JOIN EmpAssignment ON EmpHRRequest.EmpID = EmpAssignment.EmpId  
                INNER JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
				INNER JOIN WFDocApproval  ON WFDocApproval.Empid = EmpHRRequest.EmpID and WFDocApproval.DocumentNo = EmpHRRequest.DocumentNo 
				and WFDocApproval.SSDocNo in(select ssdocno from SSDocument where ssdoctype=24)                
				where  WFDocApproval.ApprovalProfileId='+str(@RoleProfileid)+'
               AND  EmpHRRequest.Completed=0 and EmpHRRequest.hrreqstatus=1 '+ @where +' order by ' +@OrderSortStr		
   END  
   
   PRINT (@str) 
   
   	 	
EXEC (@str)	
	
iF @p_page_number > 0 and @p_batch_size >= 0 AND @IncludeCount=0
	BEGIN
	SET @str = 'SELECT  count( #EndResultPagging.Row_Number)  as EmployeeCount  '+'from #EndResultPagging' 
    EXECUTE (@str)
	END
	ELSE IF @IncludeCount=1
BEGIN
SELECT @RecordsCount= count( #EndResultPagging.Row_Number)  from #EndResultPagging
END
set @where = ' (#EndResultPagging.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'
   
IF @IncludeCount=0
BEGIN
Set @str='SELECT DISTINCT * from #EndResultPagging where ' + @where + ' order by  #EndResultPagging.Row_Number '
end
else
begin
Set @str='SELECT DISTINCT *, '+ str(@RecordsCount) +' AS RecordsCount  from #EndResultPagging where ' + @where + ' order by  #EndResultPagging.Row_Number '
end
exec sp_executesql @str
print @str     
   	
DROP TABLE #EndResultPagging

END

GO

