
CREATE PROCEDURE [dbo].[AI_BuildTrainingActivityFromJSON] 
	@JsonString NVARCHAR(MAX),
	@LogonName nvarchar(80)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		BEGIN TRANSACTION;

		-- Validate JSON
		IF ISJSON(@JsonString) = 0
		BEGIN
			RAISERROR ('Invalid JSON input', 16, 1);
			RETURN;
		END

		DECLARE @ActivityName AS NVARCHAR(120) = JSON_VALUE(@JsonString, '$.Activity'),
				@TrainingMethodName AS NVARCHAR(60) = JSON_VALUE(@JsonString, '$.Method'),
				@TrainingSuccess AS NVARCHAR(30) = JSON_VALUE(@JsonString, '$.Success'),
				@MinStudent AS SMALLINT = JSON_VALUE(@JsonString, '$.Min_Students'),
				@MaxStudent AS SMALLINT = JSON_VALUE(@JsonString, '$.Max_Students'),
				@TotalHours AS NUMERIC(9,3) = JSON_VALUE(@JsonString, '$.Total_Hours'),
				@Description AS NVARCHAR(MAX) = JSON_VALUE(@JsonString, '$.Description'),
				@Audience AS NVARCHAR(MAX) = '',
				@Objective AS NVARCHAR(MAX) = '',
				@CategoriesQuery AS NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Categories'),
				@ResourcesQuery AS NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Resources'),
				@CompetenceQuery AS NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Competence'),
				@SubjectsQuery AS NVARCHAR(MAX) = JSON_QUERY(@JsonString, '$.Subjects'),

				@PassDegree AS numeric(18, 3) = JSON_VALUE(@JsonString, '$.PassDegree'),
				@ValidityPeriod AS numeric(9, 3) = JSON_VALUE(@JsonString, '$.ValidityPeriod'),
				@RequiredAttendance AS numeric(18, 3) = JSON_VALUE(@JsonString, '$.RequiredAttendance'),
				@TrainingPrerequisites AS nvarchar(MAX) = JSON_VALUE(@JsonString, '$.TrainingPrerequisites'),
				@EvaluationMethod AS NVARCHAR(MAX) = JSON_VALUE(@JsonString, '$.EvaluationMethod'),
				@Supplier AS smallint = JSON_VALUE(@JsonString, '$.Supplier'),
				@OrganizationNO AS smallint = JSON_VALUE(@JsonString, '$.OrganizationNO'),
				@Currency AS smallint = JSON_VALUE(@JsonString, '$.Currency'),
				@ActualCost AS numeric(18, 3) = JSON_VALUE(@JsonString, '$.ActualCost'),
				@BudgetCost AS numeric(18, 3) = JSON_VALUE(@JsonString, '$.BudgetCost'),
				@IntranetPublish AS bit = JSON_VALUE(@JsonString, '$.IntranetPublish'),
				
				@ActivityNo As SMALLINT = 0;

		if  @ActivityName='' 
		BEGIN
			COMMIT;
			RETURN;
		END

		IF @Supplier = 0
		BEGIN
			set @Supplier = null
		END

		IF @OrganizationNO = 0
		BEGIN
			set @OrganizationNO = null
		END

		IF @Currency = 0
		BEGIN
			set @Currency = null
		END
		-- Extract the items array and flatten it with STRING_AGG
		SELECT @Audience = STRING_AGG(value, ' </br> ')
		FROM OPENJSON(@JsonString, '$.Audience');

		SELECT @Objective = STRING_AGG(value, ' </br> ')
		FROM OPENJSON(@JsonString, '$.Objective');

		-- insert training activity
		EXEC dbo.AI_InsertTrainingActivity
			@ActivityName,
			@TrainingMethodName,
			@Description,
			@TotalHours,
			@Audience,
			@Objective,
			@MinStudent,
			@MaxStudent,
			@TrainingSuccess,
			@PassDegree  
			,@ValidityPeriod 
			,@RequiredAttendance 
			,@TrainingPrerequisites  
			,@EvaluationMethod  
			,@Supplier 
			,@OrganizationNO  
			,@Currency  
			,@ActualCost 
			,@BudgetCost 
			,@IntranetPublish,
			@LogonName,
			@ActivityNo = @ActivityNo OUTPUT;

		-- insert training category
		IF @CategoriesQuery IS NOT NULL AND EXISTS (SELECT 1 FROM OPENJSON(@CategoriesQuery))
		BEGIN
			DECLARE @TrainingCategoryName NVARCHAR(100);      
			DECLARE category_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT value
				FROM OPENJSON(@CategoriesQuery);

			OPEN category_cursor;
			FETCH NEXT FROM category_cursor INTO @TrainingCategoryName;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				EXEC dbo.AI_InsertTrainingActivitiesCategories
					@ActivityNo = @ActivityNo,
					@CategoryName = @TrainingCategoryName,
					@LogonName = @LogonName;
				FETCH NEXT FROM category_cursor INTO @TrainingCategoryName;
			END;

			CLOSE category_cursor;
			DEALLOCATE category_cursor;
		END

		-- insert training resources
		IF @ResourcesQuery IS NOT NULL AND EXISTS (SELECT 1 FROM OPENJSON(@ResourcesQuery))
		BEGIN
			-- variables for resource properties
			DECLARE @TrainingResourceName NVARCHAR(100)
					,@TrainingResourceType NVARCHAR(6) -- smallint as an NVARCHAR
					,@TrainingResourceRequired BIT
					,@TrainingResourcesCount INT

			-- cursor to iterate over resources
			DECLARE resource_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT 
					JSON_VALUE(value, '$.Name') AS Name,
					JSON_VALUE(value, '$.Resource_Type') AS Resource_Type,
					CASE JSON_VALUE(value, '$.Required') WHEN 'True' THEN 1 ELSE 0 END AS Required,
					JSON_VALUE(value, '$.Count') AS Count
				FROM OPENJSON(@ResourcesQuery);

			OPEN resource_cursor;
			FETCH NEXT FROM resource_cursor INTO 
				@TrainingResourceName, 
				@TrainingResourceType, 
				@TrainingResourceRequired, 
				@TrainingResourcesCount;
			-- Loop through resources and execute the stored procedure
			WHILE @@FETCH_STATUS = 0
			BEGIN
				EXEC dbo.AI_InsertTrainingActivityResources
					@ActivityNo = @ActivityNo,
					@ResourceName = @TrainingResourceName,
					@ResourceType = @TrainingResourceType,
					@ResourceRequired = @TrainingResourceRequired,
					@ResourcesCount = @TrainingResourcesCount,
					@LogonName = @LogonName;

				FETCH NEXT FROM resource_cursor INTO 
					@TrainingResourceName, 
					@TrainingResourceType, 
					@TrainingResourceRequired, 
					@TrainingResourcesCount;
			END;

			-- Clean up cursor
			CLOSE resource_cursor;
			DEALLOCATE resource_cursor;
		END

		-- insert traingin competensies
		IF @CompetenceQuery IS NOT NULL AND EXISTS(SELECT 1 FROM OPENJSON(@CompetenceQuery))
		BEGIN
			-- variables for competence properties
			DECLARE @CompetenceName NVARCHAR(120)
					,@LevelBefore NCHAR(6)
					,@LevelAfter NCHAR(6);
		
			-- cursor to iterate over competencies 
			DECLARE competence_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT
					JSON_VALUE(value, '$.Competence') AS NAME
					,JSON_VALUE(value, '$.Level_Before') AS LevelBefore
					,JSON_VALUE(value, '$.Level_After') AS LevelAfter
				FROM OPENJSON(@CompetenceQuery);

			OPEN competence_cursor;
			FETCH NEXT FROM competence_cursor INTO
				@CompetenceName,
				@LevelBefore,
				@LevelAfter;

			WHILE @@FETCH_STATUS = 0
			BEGIN 
				EXEC AI_InsertTrainingActivitiesCompetences
					@ActivityNo,
					@CompetenceName,
					@LevelBefore,
					@LevelAfter,
					@LogonName

				FETCH NEXT FROM competence_cursor INTO
					@CompetenceName,
					@LevelBefore,
					@LevelAfter;
			END
			-- Clean up cursor
			CLOSE competence_cursor;
			DEALLOCATE competence_cursor;
		END

		-- insert subjects
		IF @SubjectsQuery IS NOT NULL AND EXISTS(SELECT 1 FROM OPENJSON(@SubjectsQuery))
		BEGIN
			-- SUbject variables
			DECLARE @CategoryName AS NVARCHAR(60),
			@SubjectName AS NVARCHAR(60),
			@Order AS SMALLINT,
			@SessionDay AS SMALLINT,
			@SessionStart AS NVARCHAR(5),
			@SessionEnd AS NVARCHAR(5);

			DECLARE subject_cursor CURSOR LOCAL FAST_FORWARD FOR
				SELECT 
					JSON_VALUE(value, '$.Training_Subject') AS SubjectName,
					JSON_VALUE(value, '$.Order') AS OrderNo,
					JSON_VALUE(value, '$.Training_Subject_Category') AS Category,
					JSON_VALUE(value, '$.Session_Day') AS SessionDay,
					JSON_VALUE(value, '$.Session_Start') AS SessionStart,
					JSON_VALUE(value, '$.Session_End') AS SessionEnd
				FROM OPENJSON(@SubjectsQuery);
		
			OPEN subject_cursor;
			FETCH NEXT FROM subject_cursor INTO 
				@SubjectName, 
				@Order, 
				@CategoryName, 
				@SessionDay,
				@SessionStart,
				@SessionEnd;

			WHILE @@FETCH_STATUS = 0
			BEGIN
				EXEC dbo.AI_InsertTrainingActivitiesSubjects
					@ActivityNo = @ActivityNo,
					@CategoryName = @CategoryName,
					@SubjectName = @SubjectName,
					@Order = @Order,
					@SessionDay = @SessionDay,
					@SessionStart = @SessionStart,
					@SessionEnd = @SessionEnd,
					@LogonName = @LogonName;

				FETCH NEXT FROM subject_cursor INTO 
					@SubjectName, 
					@Order, 
					@CategoryName, 
					@SessionDay,
					@SessionStart,
					@SessionEnd;
			END;

			-- Clean up cursor
			CLOSE subject_cursor;
			DEALLOCATE subject_cursor;
		END

		COMMIT TRANSACTION;

	END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
		THROW;
    END CATCH;
END

GO

