
CREATE PROCEDURE [dbo].[AI_InsertAppraisal] (
    @AppraisalName NVARCHAR(MAX),
    @AppraisalType SMALLINT,
    @RatingScale SMALLINT,
    @RatingMethod SMALLINT = 1,

    @Proficiency BIT = 0,
    @Performance BIT = 0,
    @UpdateCompetence BIT = 0,
	@RoleWeight BIT = 0,
    @SelfAppraisal BIT = 0,
    
    --@NboxEnabled BIT = 0,
    --@NboxPerformanceRating SMALLINT,
    --@NboxPotentialRating SMALLINT,
    --@NboxTotalRating SMALLINT,
    @Objective BIT = 0,
    @MultiRater BIT = 0,
    @ObjectiveWeight DECIMAL(18, 2) = 0,
    @CompetenceWeight DECIMAL(18, 2) = 0,
    --@ManualScoreRole SMALLINT,
    --@MultiRaterCalcMethod SMALLINT = 1,
    --@MultiRaterRole SMALLINT,
    --@AppraisalNoCons INT = 0,
    --@AppraisalNameCons NVARCHAR(MAX) = NULL,
    @QuestionWeight DECIMAL(18, 2) = 0
    --,@AppraisalFromDate DATETIME,
    --@AppraisalToDate DATETIME,
    --@AppraisalsRYear SMALLINT = 0,
    --@AppraisalsRNo NVARCHAR(MAX) = ' ',
    --@AppraisalsRIssueDate DATETIME,
    --@AppraisalsRExecDate DATETIME,
    --@AppraisalsRStatus SMALLINT,
    --@AppraisalsRSource SMALLINT,
    --@AppraisalsRDesc NVARCHAR(MAX) = NULL,
    --@TrainingFlag SMALLINT,
    --@AppraisalsOrder INT = 0
    ,@logonname NVARCHAR(80)=''
	)
AS
BEGIN
declare @AppraisalNo2 as smallint=0

if  ISNull(@AppraisalName ,'') ='' or ISNull(@AppraisalName ,'') = N' Template'
BEGIN

RETURN;
END

set @AppraisalNo2 = isnull((select top 1 Appraisals.AppraisalNo from Appraisals where ltrim(rtrim(AppraisalName))=ltrim(rtrim(@AppraisalName)) or ltrim(rtrim(AppraisalAName))=ltrim(rtrim(@AppraisalName))),0)


if @AppraisalNo2 =0
begin
CREATE TABLE #StoredResult (
					PrimaryKey INT,
					IsUEnterByExists INT,
					OrgsColumn INT
				);
 
				INSERT INTO #StoredResult
				EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Appraisals', @PkFieldName = N'AppraisalNo', @LogonName = '1';
 
				SELECT @AppraisalNo2 = PrimaryKey FROM #StoredResult;

	 INSERT INTO Appraisals(AppraisalNo, AppraisalName, AppraisalType, RatingScale, RatingMethod, AppraisalText, Proficiency, Performance, 
	 UpdateCompetence, RoleWeight,NboxEnabled,NboxPerformanceRating,NboxPotentialRating,NboxTotalRating, SelfAppraisal, Objective, MultiRater, 
	 ObjectiveWeight, CompetenceWeight, ManualScoreRole, MultiRaterCalcMethod, MultiRaterRole, AppraisalNoCons, AppraisalNameCons, QuestionWeight, 
	 AppraisalFromDate, AppraisalToDate, AppraisalsRYear, AppraisalsRNo, AppraisalsRIssueDate, AppraisalsRExecDate, AppraisalsRStatus, AppraisalsRSource, 
	 AppraisalsRDesc, TrainingFlag ,AppraisalsOrder,uenterdate,Uenterby)
         VALUES (@AppraisalNo2, @AppraisalName, @AppraisalType, @RatingScale, @RatingMethod, '', @Proficiency, @Performance, 
		 @UpdateCompetence, @RoleWeight,0,NULL,NULL,NULL, @SelfAppraisal, @Objective, @MultiRater
		 , @ObjectiveWeight, @CompetenceWeight, NULL, 1, NULL, 0, '',@QuestionWeight
		 , NULL, NULL, 0, '', NULL, NULL, NULL,NULL
		 , '', 0 ,0, getdate(),@logonname)
end
else
begin
update Appraisals set 
 AppraisalType=@AppraisalType,
   RatingScale= @RatingScale ,
   RatingMethod= @RatingMethod ,
   --AppraisalText= @AppraisalText,
   Proficiency= @Proficiency,
   Performance= @Performance ,
   UpdateCompetence= @UpdateCompetence,
   SelfAppraisal= @SelfAppraisal,
   RoleWeight= @RoleWeight,
  Objective=  @Objective ,
   MultiRater= @MultiRater ,
   ObjectiveWeight= @ObjectiveWeight ,
   CompetenceWeight= @CompetenceWeight,
   QuestionWeight=@QuestionWeight 
   ,UChangeBy=@logonname
   ,UChangeDate=getdate()
where AppraisalNo=@AppraisalNo2
end
END

GO

