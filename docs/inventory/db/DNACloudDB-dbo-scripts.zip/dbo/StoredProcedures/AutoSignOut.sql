
CREATE Procedure [dbo].[AutoSignOut]
(@Filterwhere AS NVARCHAR(MAX) , @Filterselect AS NVARCHAR(MAX), @before AS INT , @period AS INT, @SpecialFilterwhere AS NVARCHAR(MAX),@reportno INT =0) 
AS
BEGIN	
 
DECLARE @FilterStr NVARCHAR(MAX) = ' ' ,@SelectSTR NVARCHAR(max)

IF	(@Before <> 0 AND @Period = 0 ) OR (@Before = 0 AND @Period <> 0 ) 
BEGIN
	SET @FilterStr = ' AND EmpShiftInOut.EntryDate between 
						convert(smalldatetime,convert(char(12),dateadd(dd,'+LTRIM(@Before)+',getdate())),103) and 
						convert(smalldatetime,convert(char(12),dateadd(dd,'+LTRIM(@Period+@Before)+',getdate())),103) ' 
END 
PRINT @FilterStr	


CREATE TABLE #temp (EmpId INT , EmployeeId NVARCHAR(50) , Name NVARCHAR(88) , AName NVARCHAR(88),
JobOrPosition NVARCHAR(250) , 
AJobOrPosition NVARCHAR(250) , 
TimeIn DATETIME , TimeOut DATETIME , ShiftOut DATETIME , 
CalcTimeOut DATETIME ,ENTRYDATE DATETIME , EntryNo SMALLINT,
  GroupLevel1 numeric (18,3) DEFAULT 0,
  GroupName1 nChar(250) DEFAULT '',  
  GroupLevel2 numeric (18,3)DEFAULT 0,
  GroupName2 nChar(250)DEFAULT '',  
  GroupLevel3 numeric (18,3)DEFAULT 0,
  GroupName3 nChar(250)DEFAULT '',  
  GroupLevel4 numeric (18,3)DEFAULT 0,
  GroupName4 nChar(250)DEFAULT '',  
  GroupLevel5 numeric (18,3)DEFAULT 0,
  GroupName5 nChar(250)DEFAULT '',  
  GroupLevel6 numeric (18,3)DEFAULT 0,
  GroupName6 nChar(250)DEFAULT '',  
  GroupLevel7 numeric (18,3)DEFAULT 0,
  GroupName7 nChar(250)DEFAULT '',  
  GroupLevel8 numeric (18,3)DEFAULT 0,
  GroupName8 nChar(250)DEFAULT '')



SELECT @SelectSTR ='SELECT EmpAssignment.EmpId,EmpAssignment.EmployeeId,Profile.Name,Profile.AName,
(case when EmpAssignment.PositionNo is null then Jobs.JobName else Positions.PositionName end ) as JobName,
(case when EmpAssignment.PositionNo is null then Jobs.JobAName else Positions.PositionAName end ) as AJobName,
EmpShiftInOut.TimeIn,EmpShiftInOut.TimeOut,EmpShiftInOut.ShiftOut
,'+CASE WHEN @reportno=0 THEN ' CASE WHEN DATEADD(MINUTE,DATEDIFF(MINUTE,FromTime,ToTime),EmpShiftInOut.TimeIn) > EmpShiftInOut.ShiftOut 
THEN EmpShiftInOut.ShiftOut ELSE DATEADD(MINUTE,DATEDIFF(MINUTE,FromTime,ToTime),EmpShiftInOut.TimeIn) END' ELSE ' EmpShiftInOut.ShiftOut ' end +' AS CalcTimeOut 
,EmpShiftInOut.ENTRYDATE , EmpShiftInOut.EntryNo' + @Filterselect + 
' from EmpShiftInOut 
Left Join EmpShift ON EmpShiftInOut.EmpId=EmpShift.EmpId AND EmpShiftInOut.EntryDate=EmpShift.ShiftDate
Left Join EmpAssignment ON EmpAssignment.EmpId=EmpShiftInOut.EmpId
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack
LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON JobCat.JobCat = Jobs.JobCat 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1  
LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname = ''Status'' 
LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus''
LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus''
LEFT JOIN NasArrays HrTaxstat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus''
LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus''
LEFT JOIN NasArrays Gender ON Gender.itemno = Profile.Gender AND Gender.arrayname = ''Gender''
LEFT JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo
LEFT JOIN NasArrays ShiftType ON ShiftType.itemno = TimeShifts.ShiftType And ShiftType.arrayname=''ShiftType''
cross join sysparam
where (HrStatus.PayStatus=1)
And	EmpShiftInOut.TimeIn IS NOT NULL
AND EmpShiftInOut.ShiftIN IS NOT NULL
AND EmpShiftInOut.ShiftOUT IS NOT NULL
and	EmpShiftInOut.TimeOut IS NULL ' 
+ @FilterStr
+ @Filterwhere
+ @SpecialFilterwhere 

PRINT (@SelectSTR)
INSERT INTO #temp (   EmpId ,
                      EmployeeId ,
                      Name ,
                      AName ,
					  JobOrPosition,
					  AJobOrPosition,
                      TimeIn ,
                      TimeOut ,
                      ShiftOut,
					  CalcTimeOut,
					  ENTRYDATE ,
					  EntryNo ,
					  GroupLevel1,
					  GroupName1,
					  GroupLevel2,
					  GroupName2,  
					  GroupLevel3,  
					  GroupName3,  
					  GroupLevel4,  
					  GroupName4,
					  GroupLevel5, 
					  GroupName5,  
					  GroupLevel6,  
					  GroupName6,  
					  GroupLevel7, 
					  GroupName7,  
					  GroupLevel8,  
					  GroupName8
                  )

				  EXEC (@SelectSTR)
--SELECT * FROM #temp 

DECLARE @FlagValue NVARCHAR(50) 
DECLARE @TimeSystem SMALLINT
SET @TimeSystem = (SELECT TOP(1) TimeSystem FROM dbo.TimeSystems )
SET @FlagValue = (SELECT TOP (1) LineValues FROM dbo.TimeSystemLines WHERE TimeSystem = @TimeSystem AND	TimeLineType = 2)

INSERT INTO dbo.EmpTimeReadings (EmployeeId ,AttendTime ,TimeSystem ,ReaderValue ,FlagValue ,Inactive ,Manual ,ProcessTime ,ProcessBy ,EmpId)
						  SELECT #temp.EmployeeId ,CalcTimeOut,@TimeSystem,@FlagValue,@FlagValue,0,1,GETDATE(),99999999,#temp.EmpId FROM #temp
						  left join EmpTimeReadings on #temp.EmployeeId= EmpTimeReadings.EmployeeId 
						  and #temp.CalcTimeOut= EmpTimeReadings.AttendTime and EmpTimeReadings.TimeSystem=@TimeSystem
						  and EmpTimeReadings.ReaderValue=@FlagValue and EmpTimeReadings.FlagValue=@FlagValue
						  where EmpTimeReadings.EmployeeId is null 
						 

UPDATE #temp SET TimeOut = CalcTimeOut 
SELECT DISTINCT * FROM #temp  ORDER BY #temp.ENTRYDATE DESC

DROP TABLE #temp
END

GO

