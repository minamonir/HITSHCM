--/****** Object:  StoredProcedure [dbo].[BatchWP_DeployReports]    Script Date: 01/04/2011 12:45:26 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
---- =============================================
---- Author:		<Author,,Name>
---- Create date: <Create Date,,>
---- Description:	<Description,,>
-- -- =============================================
CREATE PROCEDURE [dbo].[BatchWP_DeployReports]
	(@TableName nvarchar(150),@tabletype nvarchar(max)) AS
	
--declare @TableType AS  nvarchar(max)

--DECLARE @tabletype nvarchar(max)
--DECLARE @TableName AS nvarchar(max),@x AS nvarchar(max)
DECLARE @all int,@alert int,@reportno int
DECLARE @StartIndex AS int
--SET @TableName='NASDOTNETDEVBatchTemp.dbo.[NasbatchWB_1_401320110104124333c972b96eeea44afcbfb2059a9ab8eece]'
DECLARE @SelectStr AS nvarchar(max)
--SET @TableType='BatchWP_DeployReports:0 , 1'
  BEGIN
 
SET @StartIndex=CHARINDEX(':',@TableType)
SET @TableType=substring (@tabletype,@StartIndex+1,len(@tabletype)-len(substring(@tabletype,0,@startindex)))



SET @StartIndex=CHARINDEX(',',@TableType)
SET @alert=substring (@TableType,0,@StartIndex)



 SET @tabletype=substring(@tabletype,@StartIndex+1,len(@tabletype))
 SET @StartIndex=CHARINDEX(',',@TableType)
 SET @all=substring (@TableType,0,@StartIndex)
 
 
 SET @tabletype=substring(@tabletype,@StartIndex+1,len(@tabletype))
 SET @reportno=@tabletype
  

  DECLARE @TableNamelen AS int 
  SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1



 SET @selectstr ='IF not EXISTS(SELECT top 1 1 FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
 WHERE '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
+' BEGIN CREATE TABLE ' + @tablename+ '(
[Item] nvarchar(200),[Processed] nvarchar(max),[Row_Number] int Identity(1,1) NOT NULL Primary Key) end'
    


 PRINT @SelectStr
exec sp_executesql @selectstr
SET @SelectStr=''
IF @alert=0
BEGIN
IF @all=1 
SET @SelectStr='insert into '+ @TableName+' (Item,Processed) select reportno,'''' from Reports where ReportFile<>'''' or ReportAFile<>'''' '
ELSE
--IF @all=0
	SET @SelectStr='insert into '+ @TableName+' (Item,Processed) select reportno,'''' from Reports where reportno='+str(@reportno)
	
 PRINT @SelectStr

END
--exec sp_executesql @selectstr

  END

GO

