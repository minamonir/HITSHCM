CREATE PROCEDURE [dbo].[Applicant_Hire] 
(@EmpId int,@EmployeeId NVARCHAR(50),@AssignmentId smallint,@ApplicationStatus smallint,@Original_AppStatus smallint,@HRStatus smallint ,@Org smallint ,@HireDate smalldatetime ,@Job smallint ,@Grade smallint ,@Position smallint,
 @Location smallint ,@Employer smallint ,@SSGroup int,@Payrollgrp   smallint,@EnterBy int,@WorkReceivingDate smalldatetime ,@SalaryScaleId smallint,@RetirementAge INT,@Applicant AS BIT,@ChgCode as INT,@HRReqest as INT)
 
 
                 	
AS
 
 --DECLARE  @EmpId int,@EmployeeId int,@AssignmentId smallint,@ApplicationStatus smallint,@Original_AppStatus smallint,@HRStatus smallint ,@Org smallint ,@HireDate smalldatetime ,@Job smallint ,@Grade smallint ,@Position smallint,
 --@Location smallint ,@Employer smallint ,@SSGroup smallint,@Payrollgrp   smallint,@EnterBy int,@WorkReceivingDate smalldatetime ,@SalaryScaleId smallint,@RetirementAge INT,@Applicant AS BIT,@ChgCode as INT,@Termstatus AS INT
 ----@Organization = N'101', @Positionno = N'37',@LocationNo = N'88', @EmployerId = N'307',@PropStartDate = N'13/12/1988',@OrgName = N'Sales   @OldAppStatus = N'0', 
 --SELECT @EmpId = 206559, @EmployeeId = 0, @AssignmentId = 1, @ApplicationStatus = N'14', 	 @HRStatus = N'0',  @HireDate = 'Jan  2 2011 12:00:00:000AM', @Job = N'12', 
 --@Grade = N'3685',
 -- @SSGroup = N'50', @Payrollgrp = NULL, @EnterBy = 3087, @WorkReceivingDate = 'Jan 26 2011 12:00:00:000AM', 
 --@SalaryScaleId = N'2', @RetirementAge = 10, @applicant = N'0', @ChgCode = N'3', @TermStatus = N'0'--,                                                      ', @jobName = N'Marketing Manager                                           ', @positionname = N'assistant                                                   ', @gradename = N'ddddddddddd                                                 ', @locationname = N'nvj                                                         ', @original_EmployeeId = N'0', @original_HireDate = N'02/01/2011 11:00:03', @original_PropStartDate = N'13/12/1988', @original_OrgName = N'Sales                                                       ', @original_Organization = N'101', @original_jobName = N'Marketing Manager                                           ', @original_RetirementAge = N'', @original_positionname = N'assistant                                                   ', @original_WorkReceivingDate = N'', @original_SSGroup = N'', @original_gradename = N'ddddddddddd                                                 ', @original_locationname = N'abbasia                                                     '                                          ', @original_locationname = N'abbasia '
	 
	 
BEGIN
	
			Declare @existSSGroup bit = 0
			Declare @existEmployer bit = 0
			Declare @existHRStatus bit= 0
			Declare @existPosition bit= 0
			Declare @existJob bit= 0
			Declare @existOrg bit= 0
			Declare @existGrade bit= 0
			Declare @existLocation bit= 0
			Declare @existSalaryScaleId bit= 0

	SET @SSGroup=null
	 
IF @Applicant=1 ---from recruitment form
BEGIN
	
DECLARE @ExistEmp smallint ,@EmpHRStatus smallint
Declare @AutoEmpId as bit 
declare @Latinlang as nchar(1)
DECLARE @ErrorMsg AS nvarchar(500)



set @AutoEmpId=(select sysparam.AutoEmpId from SysParam)

SET @ExistEmp= (SELECT count(*) FROM  EmpAssignment WHERE EmployeeId=@EmployeeId)
select @Latinlang=ErrorLang  from SysParam
--@Latinlang='E'

IF (ltrim(rtrim(@EmployeeId))='0' AND @AutoEmpId=0 ) 
BEGIN 
--DECLARE @message nvarchar(255)
--SET @message = 'test' + nCHAR(13) + nCHAR(10) + 'message'
--RAISERROR(@message, 0, 1)

  SELECT @ErrorMsg =isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('HireNowErr','1stError',@latinlang))),(case when @latinlang='E' then 'Enter a valid Employee ID' else N'أدخل رقم صحيح للموظف' end))
          	    RAISERROR(@ErrorMsg,16,1);
END
ELSE IF @ExistEmp> 0 
BEGIN 
--DECLARE @message nvarchar(255)
--SET @message = 'test' + nCHAR(13) + nCHAR(10) + 'message'
--RAISERROR(@message, 0, 1)

  SELECT @ErrorMsg =isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('HireNowErr','2ndtError',@latinlang))),(case when @latinlang='E' then 'Duplicate Employee ID' else N'رقم الموظف مكرر' end))
          	    RAISERROR(@ErrorMsg,16,1);
END
ELSE
	BEGIN
		
	

DECLARE @OrgParent smallint
DECLARE @Center smallint
DECLARE @TaxCode smallint
DECLARE @SSCode smallint
DECLARE @TimeRule smallint
DECLARE @VacPack smallint
DECLARE @HRCurr smallint
DECLARE @ProbDate smalldatetime



SET @Center=NULL 
SET @TaxCode=NULL 
SET @SSCode=NULL 


SET @OrgParent=@Org
WHILE @Payrollgrp IS NULL 
BEGIN 
	SET @Payrollgrp =(SELECT PayrollGroup FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	IF @Payrollgrp IS NULL AND @OrgParent Is NULL
	BEGIN
		SET @Payrollgrp=(SELECT PayrollGroup FROM SysParam) BREAK
	END

END


SET @OrgParent=@Org
WHILE @Location IS NULL 
BEGIN 
	SET @Location =(SELECT Locationno FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	IF @Location IS NULL AND @OrgParent Is NULL
	BEGIN
		SET @Location=(SELECT Locationno FROM SysParam) BREAK
	END
END

SET @OrgParent=@Org
WHILE @Employer IS NULL 
BEGIN 
	SET @Employer =(SELECT EmployerId FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	IF @Employer IS NULL AND @OrgParent Is NULL
	BEGIN
		SET @Employer=(SELECT EmployerId FROM SysParam) BREAK
	END
END

--SET @OrgParent=@Org
--IF @SSGroup IS NULL
--BEGIN 
--	WHILE @OrgParent IS not NULL AND @SSGroup IS null
--BEGIN 
--	SET @SSGroup =(SELECT SSGroup FROM Organization WHERE Organization=@OrgParent)
--	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
--	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	
--END
--END

SET @OrgParent=@Org
IF @Center IS NULL
BEGIN 
	WHILE @OrgParent IS not NULL AND @Center IS null
BEGIN 
	SET @Center =(SELECT CostCenter FROM Organization WHERE Organization=@OrgParent)
	SET @OrgParent=(SELECT OrganizationStructure.OrganizationParent FROM OrganizationStructure 
	WHERE OrganizationStructure.Organization=@OrgParent AND OrganizationStructure.VersionNo=1)
	
END
END

SET @TaxCode =(SELECT deftaxcode FROM Payrollgroup WHERE Payrollgroup=@Payrollgrp)
SET @SSCode =(SELECT defsscode FROM Payrollgroup WHERE Payrollgroup=@Payrollgrp)
SET @HRCurr= ISnull((SELECT HrCurrency FROM AppAssignment  WHERE EmpId=@EmpId AND AppAssignment.AssignmentId=@AssignmentId),(SELECT currency FROM Payrollgroup WHERE Payrollgroup=@Payrollgrp))
SET @TimeRule=ISnull((SELECT TimeRule FROM AppAssignment  WHERE EmpId=@EmpId AND AppAssignment.AssignmentId=@AssignmentId),(SELECT deftrule FROM sysparam))
SET @VacPack=ISnull((SELECT vacpack FROM AppAssignment  WHERE EmpId=@EmpId AND AppAssignment.AssignmentId=@AssignmentId),(SELECT defvacpack FROM sysparam))
SET @ProbDate=isnull((SELECT probdate FROM AppAssignment  WHERE EmpId=@EmpId AND AppAssignment.AssignmentId=@AssignmentId),dateadd(dd,(SELECT sysparam.nhireprob FROM sysparam) ,@HireDate))

DECLARE @P1 NVARCHAR(50)   --integer 


IF ltrim(rtrim(@EmployeeId))='0'  and @AutoEmpId=1
BEGIN 
EXECUTE hits_getempid @P1 output,@Org
if @p1 like '%error%'
begin
     SELECT @ErrorMsg ='002-'+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('V_Employees','CheckEmployeeIdRange',@latinlang))),
	      (case when @latinlang='E' then 'EmployeeId out of Org range. ' else N'رقم الموظف خارج نطاق الادارة' end))
         RAISERROR(@ErrorMsg,16,1);
		return
end
else
     SET @EmployeeId=@P1
END

if @AutoEmpId=0
begin

declare @statusResult  as int
 set @statusResult  =[dbo].[GetOrganizationSysParam] (@Org,@EmployeeId)
  if @statusResult =-2
   begin
		 SELECT @ErrorMsg ='002-'+isnull(ltrim(rtrim(dbo.Hits_GetDCCaption('V_Employees','CheckEmployeeIdRange',@latinlang))),
	      (case when @latinlang='E' then 'EmployeeId out of Org range. ' else N'رقم الموظف خارج نطاق الادارة' end))
         RAISERROR(@ErrorMsg,16,1);
		return
    end 
end

-----------------------------------
set @EmpHRStatus=@HRStatus
if isnull(@ChgCode,0) > 0 and not exists (select HrStatus from HrStatus where HrStatus=@HRStatus and paystatus=2)
  Begin
     set @HRStatus = (select top(1) HrStatus from HrStatus where paystatus=2)
  End
-------------------------------------


INSERT INTO EmpAssignment 
(EmpId,EmployeeId,SSGroup,HireDate,HrStatus,HrTaxStat,TaxCode,HrScStatus,PayrollGroup,PositionNo,Job,Organization,
Center,LocationNo,Grade,ContractType,HrSsAppl,SsCode,HrSsFixVal,HrSsVarVal,HrSsBonVal,EmployerId,HrBenefit,HrBasicSal,
ContBasSal,ContBasCur,ContNet,ContInfo,ContStart,ContEnd,ProbDate,VacPack,Privacy,TimeRule,EnterBy,EnterDate,ChangeBy,
LastEffectiveDate,HrCurrency,WorkReceivingDate,SalaryScaleId,RetirementAge) 


SELECT @EmpId,@EmployeeId ,@SSGroup,@HireDate,@HRStatus,HrTaxStat,@TaxCode,HrScStatus,@Payrollgrp,@Position,@Job,@Org,
@Center,@Location,@Grade,ContractType,HrSsAppl,@SSCode,
HrSsFixVal,HrSsVarVal,HrSsBonVal,@Employer,HrBenefit,HrBasicSal,
ContBasSal,ContBasCur,ContNet,ContInfo,ContStart,ContEnd,@ProbDate,@VacPack,Privacy,@TimeRule,@EnterBy ,getdate(),null,
LastEffectiveDate,@HRCurr,@WorkReceivingDate,@SalaryScaleId,@RetirementAge
FROM AppAssignment  WHERE EmpId=@EmpId AND AppAssignment.AssignmentId=@AssignmentId



UPDATE dbo.Profile SET FirstHiredDate= @HireDate
 WHERE ProfileId=@EmpId 

UPDATE dbo.AppAssignment SET 
ApplicationStatus=@ApplicationStatus
WHERE EmpId=@EmpId AND 
      AssignmentId=@AssignmentId AND 
      ApplicationStatus=@Original_AppStatus  
   
INSERT INTO HrPCodes (empid, paycode, inputamnt)        
SELECT EmpId, Paycode, InputAmnt from AppHrPCodes where empid=@EmpId  and  AssignmentId=@AssignmentId 
-----cos----

DECLARE @UpdateEmpass AS nVARCHAR(max),@UpdateAppAss AS nVARCHAR(max),@UpdateChanges AS nVARCHAR(max),@DocNo AS INT,@AssPosition AS INT

	if isnull(@ChgCode,0) > 0
	begin


		SELECT @AssPosition=PositionNo FROM EmpAssignment WHERE EmpId=@EmpId


		SELECT @DocNo=dbo.GetDocumentNo(@EmpId,1)

		--------------------------------
		--declare @existDocNo int
		--	select @existDocNo = DocumentNo from EmpStatusHdr where  EmpId=@EmpId and ChgCode=@ChgCode and EffectiveDate=@HireDate

		--	If @existDocNo is NOT NULL
				
		--		Begin
		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=21 and NewValue=@SSGroup)
		--			   Set @existSSGroup=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=10 and NewValue=@Employer)
		--			   Set @existEmployer=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=1 and NewValue=@HRStatus)
		--			   Set @existHRStatus=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=8 and NewValue=@Position)
		--			   Set @existPosition=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=5 and NewValue=@Job)
		--			   Set @existJob=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=6 and NewValue=@Org)
		--			   Set @existOrg=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=7 and NewValue=@Grade)
		--			   Set @existGrade=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=9 and NewValue=@Location)
		--			   Set @existLocation=1

		--			   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=22 and NewValue=@SalaryScaleId)
		--			   Set @existSalaryScaleId=1

		--		End

				--IF @existDocNo is NULL OR 
				--( (@existSSGroup =0 AND ISNULL(@SSGroup,0)>0 ) OR 
				--(@existEmployer =0 AND ISNULL(@Employer,0)>0 )OR 
				--(@existHRStatus =0 AND ISNULL(@HRStatus,0)>0 ) OR 
				--(@existPosition =0 AND ISNULL(@Position,0)>0 )OR 
				--(@existJob=0 AND  ISNULL(@Job,0)>0 )OR 
				--(@existOrg=0 AND ISNULL(@Org,0)>0 )OR 
				--(@existGrade=0 AND ISNULL(@Grade,0)>0 )OR 
				--(@existLocation =0 AND ISNULL(@Location,0)>0 )OR 
				--(@existSalaryScaleId = 0 AND ISNULL(@SalaryScaleId,0)>0 ) )
				--Begin
					INSERT INTO EmpStatusHdr(EmpId,DocumentNo,DocumentStatus,DocumentSource,ChgCode,EffectiveDate,HRCurrency,ChgComment,IncreaseAmount,
					EnterBy,EnterDate,EmpStatusHdrRYear,EmpStatusHdrRNo,EmpStatusHdrRDesc)
				    select @EmpId,@DocNo,5,0,@ChgCode,@HireDate,hrcurrency,N'',0,@EnterBy,GETDATE(),0,N'',N'' FROM EmpAssignment WHERE EmpId=@EmpId
				--PRINT 'inserted2'
				--End
		--------------------------------

			--INSERT INTO EmpStatusHdr(EmpId,DocumentNo,DocumentStatus,DocumentSource,ChgCode,EffectiveDate,HRCurrency,ChgComment,IncreaseAmount,
			--	EnterBy,EnterDate,EmpStatusHdrRYear,EmpStatusHdrRNo,EmpStatusHdrRDesc)
			--select @EmpId,@DocNo,5,0,@ChgCode,@HireDate,hrcurrency,N'',0,@EnterBy,GETDATE(),0,N'',N'' FROM EmpAssignment WHERE EmpId=@EmpId
--If @existSSGroup =0 OR @existEmployer =0 OR @existHRStatus =0 OR @existPosition =0 OR @existJob=0 OR @existOrg=0 OR @existGrade=0 OR @existLocation =0 OR @existSalaryScaleId = 0
--     Begin 

		IF ISNULL(@SSGroup,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,21,@SSGroup)
				--PRINT 'ssgroup'
			END
			IF ISNULL(@Employer,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,10,@Employer)
			END
			IF ISNULL(@EmpHRStatus,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,1,@EmpHRStatus)
			END
			
		
			IF ISNULL(@Position,0)>0 
			BEGIN  
			    INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,8,@Position)
			END
			
			IF ISNULL(@Job,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,5,@Job)
			END
			
			
			IF ISNULL(@Org,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,6,@Org)
				--PRINT 'org'
			END
			
			IF ISNULL(@Grade,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,7,@Grade)
			END

			IF ISNULL(@Location,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,9,@Location)
			END

			IF ISNULL(@SalaryScaleId,0)>0 
			BEGIN  
				INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				VALUES(@EmpId,@DocNo,22,@SalaryScaleId)
			END
   --END
			------------
			Declare @ssdocno int
			EXEC GetSSDocNo 1,@ChgCode,@ssdocno OUTPUT 

			INSERT INTO WFDocument(DocumentNo, EmpID, SSDocNo, StartDate,EnterDate, EnterBy)
			VALUES(@DocNo,@EmpId,@Ssdocno,GETDATE(),getdate(),@EnterBy)
	end
---------------------------------------
if isnull(@HRReqest,0)>0
begin
SELECT @DocNo=dbo.GetDocumentNo(@EmpId,24)

INSERT INTO [dbo].[EmpHRRequest]([Empid],[DocumentNo],[HRReqCode],[HRReqDate],[HRReqStatus],EnterDate, EnterBy)
select @EmpId,@DocNo,@HRReqest,@HireDate,5,getdate(),@EnterBy

Declare @ssdocno2 int
			EXEC GetSSDocNo 24,@HRReqest,@ssdocno2 OUTPUT 

			INSERT INTO WFDocument(DocumentNo, EmpID, SSDocNo, StartDate,EnterDate, EnterBy)
			VALUES(@DocNo,@EmpId,@Ssdocno2,GETDATE(),getdate(),@EnterBy)

end



---------------------------------------
	END
    END



	ELSE --from profile
		BEGIN 
			--PRINT 'from profile'
			--DECLARE @UpdateEmpass AS nVARCHAR(max),@UpdateAppAss AS nVARCHAR(max),@UpdateChanges AS nVARCHAR(max),@DocNo AS INT,@AssPosition AS INT
			
			SELECT @AssPosition=PositionNo FROM EmpAssignment WHERE EmpId=@EmpId
			--IF @Termstatus>0
			--BEGIN
			--	--PRINT '@Termstatus>0'
			--	DECLARE @DocNo2 AS INT
			--	SELECT @DocNo2=dbo.GetDocumentNo(@EmpId,1)
			--	INSERT INTO EmpStatusHdr(EmpId,DocumentNo,DocumentStatus,DocumentSource,ChgCode,EffectiveDate,HRCurrency,ChgComment,IncreaseAmount,
			--	EnterBy,EnterDate,EmpStatusHdrRYear,EmpStatusHdrRNo,EmpStatusHdrRDesc)
			--	select @EmpId,@DocNo2,1,0,@ChgCode,@HireDate,hrcurrency,'',0,@EnterBy,GETDATE(),0,'','' FROM EmpAssignment WHERE EmpId=@EmpId
			--	INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
			--	VALUES(@EmpId,@DocNo2,1,@Termstatus)
			--	--PRINT 'inserted1'
			--END
			



			SELECT @DocNo=dbo.GetDocumentNo(@EmpId,1)
			---------------------------------------------------
			--declare @existDocNo int
			--select @existDocNo = DocumentNo from EmpStatusHdr where  EmpId=@EmpId and ChgCode=@ChgCode and EffectiveDate=@HireDate


			--If @existDocNo is NOT NULL
				
			--	Begin
			--		   if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=21 and NewValue=@SSGroup)
					   --Set @existSSGroup=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=10 and NewValue=@Employer)
					   --Set @existEmployer=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=1 and NewValue=@HRStatus)
					   --Set @existHRStatus=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=8 and NewValue=@Position)
					   --Set @existPosition=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=5 and NewValue=@Job)
					   --Set @existJob=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=6 and NewValue=@Org)
					   --Set @existOrg=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=7 and NewValue=@Grade)
					   --Set @existGrade=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=9 and NewValue=@Location)
					   --Set @existLocation=1

					   --if exists (select EmpId from EmpStatusDtl where EmpId=@EmpId and DocumentNo=@existDocNo and FieldNo=22 and NewValue=@SalaryScaleId)
					   --Set @existSalaryScaleId=1

				--End
		
				--IF @existDocNo is NULL OR 
				--( (@existSSGroup =0 AND ISNULL(@SSGroup,0)>0 ) OR 
				--(@existEmployer =0 AND ISNULL(@Employer,0)>0 )OR 
				--(@existHRStatus =0 AND ISNULL(@HRStatus,0)>0 ) OR 
				--(@existPosition =0 AND ISNULL(@Position,0)>0 )OR 
				--(@existJob=0 AND  ISNULL(@Job,0)>0 )OR 
				--(@existOrg=0 AND ISNULL(@Org,0)>0 )OR 
				--(@existGrade=0 AND ISNULL(@Grade,0)>0 )OR 
				--(@existLocation =0 AND ISNULL(@Location,0)>0 )OR 
				--(@existSalaryScaleId = 0 AND ISNULL(@SalaryScaleId,0)>0 ) )
				--Begin
					INSERT INTO EmpStatusHdr(EmpId,DocumentNo,DocumentStatus,DocumentSource,ChgCode,EffectiveDate,HRCurrency,ChgComment,IncreaseAmount,
					EnterBy,EnterDate,EmpStatusHdrRYear,EmpStatusHdrRNo,EmpStatusHdrRDesc)
				    select @EmpId,@DocNo,5,0,@ChgCode,@HireDate,hrcurrency,N'',0,@EnterBy,GETDATE(),0,N'',N'' FROM EmpAssignment WHERE EmpId=@EmpId
				--PRINT 'inserted2'
				--End
		   --------------------------------------------------

  --If @existSSGroup =0 OR @existEmployer =0 OR @existHRStatus =0 OR @existPosition =0 OR @existJob=0 OR @existOrg=0 OR @existGrade=0 OR @existLocation =0 OR @existSalaryScaleId = 0
  --   Begin 
			IF ISNULL(@SSGroup,0)>0 
			BEGIN  
	    
					 INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,21,@SSGroup)
						--PRINT 'ssgroup'
				
			END
			IF ISNULL(@Employer,0)>0 
			BEGIN  

			
					INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
					VALUES(@EmpId,@DocNo,10,@Employer)
				
			END
			IF ISNULL(@HRStatus,0)>0 
			BEGIN 
			  
					INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
				    VALUES(@EmpId,@DocNo,1,@HRStatus)
                
			END
			
			--IF  isnull(@AssPosition,N'')<>N'' AND  @Position=0 AND ((@Job >0 OR @Org >0) OR (@Job=0 AND @Org=0))
			--BEGIN
			--	UPDATE EmpAssignment
			--	SET	PositionNo = NULL WHERE EmpId=@EmpId
			--END
			--ELSE
			--BEGIN
				IF ISNULL(@Position,0)>0 
				BEGIN  
				
						INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,8,@Position)
			    	
				END
			--END
			IF ISNULL(@Job,0)>0 
			BEGIN  
			   
						INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,5,@Job)
				  
			END
			
			
			IF ISNULL(@Org,0)>0 
			BEGIN 
			   
						INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,6,@Org)
				   
				--PRINT 'org'
			END
			
			IF ISNULL(@Grade,0)>0 
			BEGIN  
			   
						INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,7,@Grade)
					
			END

			IF ISNULL(@Location,0)>0 
			BEGIN  
			 
						INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,9,@Location)
				   
			END

			IF ISNULL(@SalaryScaleId,0)>0 
			BEGIN  
			    
						INSERT INTO EmpStatusDtl(EmpId,DocumentNo,FieldNo,NewValue)
						VALUES(@EmpId,@DocNo,22,@SalaryScaleId)
					 
			END
	--End		
	-----------------------------




	if isnull(@HRReqest,0)>0
begin
SELECT @DocNo=dbo.GetDocumentNo(@EmpId,24)

INSERT INTO [dbo].[EmpHRRequest]([Empid],[DocumentNo],[HRReqCode],[HRReqDate],[HRReqStatus],EnterDate, EnterBy)
select @EmpId,@DocNo,@HRReqest,@HireDate,5,getdate(),@EnterBy

Declare @ssdocno3 int
			EXEC GetSSDocNo 24,@HRReqest,@ssdocno3 OUTPUT 

			INSERT INTO WFDocument(DocumentNo, EmpID, SSDocNo, StartDate,EnterDate, EnterBy)
			VALUES(@DocNo,@EmpId,@Ssdocno3,GETDATE(),getdate(),@EnterBy)

end





			------------
			--Declare @ssdocno int
			EXEC GetSSDocNo 1,@ChgCode,@ssdocno OUTPUT 

			INSERT INTO WFDocument(DocumentNo, EmpID, SSDocNo, StartDate,EnterDate, EnterBy)
			VALUES(@DocNo,@EmpId,@Ssdocno,GETDATE(),getdate(),@EnterBy)
			-------
			
			set @updateEmpass='UPDATE empassignment set '+CASE WHEN ISNULL(@Payrollgrp,0) >0  THEN 'PayrollGroup ='+str(@Payrollgrp)+',' ELSE N'' END
			set @UpdateEmpass=@UpdateEmpass + CASE WHEN NOT(@WorkReceivingDate  IS NULL) THEN 'WorkReceivingDate ='''+convert(nChar(12),convert(datetime,@workReceivingDate,103))+''',' ELSE N'' END
			 --PRINT (@UpdateEmpass)
			SET @UpdateEmpass=@UpdateEmpass + CASE WHEN @RetirementAge>0 THEN 'RetirementAge = '+STR(@RetirementAge)+',' ELSE N'' END 
			SET @UpdateEmpass=CASE WHEN CHARINDEX(',', @UpdateEmpass)>0 THEN LEFT(@UpdateEmpass,LEN(@UpdateEmpass)-1) ELSE N'' END
			SET @UpdateEmpass=@UpdateEmpass + ' where empassignment.empid='+STR (@EmpId)
			
		    SET @UpdateAppAss='update AppAssignment set ApplicationStatus=' +STR(@ApplicationStatus)+' where Empid='+STR(@EmpId) +' and assignmentid='+STR(@AssignmentId)
		   -- SET @UpdateChanges=' exec hits_UpdateChanges '+STR (@EmpId)+','+str(@DocNo)+','+STR (@enterBy)
		    PRINT (@UpdateEmpass)
		    PRINT (@UpdateAppAss)
		   -- PRINT (@UpdateChanges)
		    EXEC (@UpdateEmpass)
		    EXEC (@UpdateAppAss)
		   -- EXEC (@UpdateChanges)
         END
END

GO

