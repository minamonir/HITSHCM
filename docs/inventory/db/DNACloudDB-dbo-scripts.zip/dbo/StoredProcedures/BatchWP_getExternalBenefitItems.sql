

CREATE PROCEDURE [dbo].[BatchWP_getExternalBenefitItems]

	
(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS smallint,@Where AS nvarchar(max),@Paramaters AS nvarchar(max),@outputstr AS nvarchar(max)output) AS

DECLARE @SELECT AS nvarchar(max)
DECLARE @DateFormat AS INT

 SELECT @DateFormat= dateformat FROM SysParam 
   IF @DateFormat=1 SET @DateFormat=103
  IF @DateFormat=2 SET @DateFormat=101
  IF @DateFormat=0 SET @DateFormat=111

DECLARE @lang AS CHAR(1)

DECLARE @StartIndex AS int 
PRINT @Paramaters
		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @lang= case when (substring (@Paramaters,0,@StartIndex) <>'') THEN substring (@Paramaters,0,@StartIndex) ELSE 'E' END --lang
		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT @lang
		
	
DECLARE @InvalidRelativeNameerrormsg AS NVARCHAR(250)
DECLARE @InvalidServiceNameerrormsg AS NVARCHAR(250)
DECLARE @InvalidSupplierNameerrormsg AS NVARCHAR(250)
DECLARE @disableAmount AS NVARCHAR(250) 
DECLARE @disableQuantity AS NVARCHAR(250)

DECLARE @DecimalScale AS int
SELECT  @DecimalScale= decimalscale FROM SysParam 

SELECT @InvalidRelativeNameerrormsg= isnull(dbo.Hits_GetDCCaption('WP_GetExternalBenefitItems','InvalidRelativeName',@lang),
(case when @lang=N'A' then N'اسم القريب غير صحيح ' ELSE N'Invalid Relative Name'  end))


SELECT @InvalidServiceNameerrormsg= isnull(dbo.Hits_GetDCCaption('WP_GetExternalBenefitItems','InvalidServiceName',@lang),
(case when @lang=N'A' then N'اسم الخدمه غير صحيح ' ELSE N'Invalid Service Name'  end))

SELECT @InvalidSupplierNameerrormsg= isnull(dbo.Hits_GetDCCaption('WP_GetExternalBenefitItems','InvalidSupplierName',@lang),
(case when @lang=N'A' then N'اسم المورد غير صحيح ' ELSE N'Invalid Supplier Name'  end))	

SELECT @disableQuantity= isnull(dbo.Hits_GetDCCaption('WP_GetExternalBenefitItems','DisableQuantity',@lang),
(case when @lang='A' then N'لا يمكن ادخال الكمية, تعطيل إدخال الكمية مفعل في إعدادات النظام' ELSE N'Can not input Quantity, Disable Quantity is checked in system setup'  end))
SELECT @disableAmount= isnull(dbo.Hits_GetDCCaption('WP_GetExternalBenefitItems','DisableAmount',@lang),
(case when @lang='A' then N'لا يمكن ادخال المبلغ, تعطيل إدخال المبلغ مفعل في إعدادات النظام' ELSE N'Can not input Amount, Disable Amount is checked in system setup'  end))



IF @actiontype=1
	BEGIN 
		DECLARE @paramater1 AS nvarchar (60)
		DECLARE @paramater2 AS nvarchar (10)
		DECLARE @paramater3 AS nvarchar (60)
		DECLARE @paramater4 AS nvarchar (60)
		DECLARE @paramater5 AS nvarchar (max)
		DECLARE @paramater6 AS nvarchar (10)
		DECLARE @paramater7 AS nvarchar (10)--chcbxOverwrite
		DECLARE @paramater8 AS nvarchar (10)--chcbxOverwriteAmount
		DECLARE @paramater9 AS nvarchar (10)--chcbxOverwriteQuantity
		DECLARE @RefYear AS nvarchar (100)--RefYear
		DECLARE @RefNum AS nvarchar (100)--RefNum
		DECLARE @IssueDate AS nvarchar (100)--IssueDate
		DECLARE @ExecDate AS nvarchar (100)--ExecDate
		DECLARE @RefStatus AS nvarchar (100)--RefStatus
		DECLARE @RefSource AS nvarchar (100)--RefSource
		DECLARE @RrfDesc AS nvarchar(max)--RrfDesc
		DECLARE @AttachmentPath AS nvarchar(max)--AttachmentPath
		DECLARE @AttachmentDesc AS nvarchar(120)--Desc
		DECLARE @AttachmentADesc AS nvarchar(120)--ADesc
		DECLARE @EnterDate AS nvarchar (100)--EnterDate
		DECLARE @EnterBy AS nvarchar (100)--EnterBy
		DECLARE @enableAttachments AS BIT
		DECLARE @enableRef AS BIT
		DECLARE @ErrorValue AS int
		DECLARE @Result AS NVARCHAR(MAX) =''
		DECLARE @updatetablestr as nvarchar(MAX)
		DECLARE @cur_empid AS NVARCHAR(256)
		declare @rowNumber as int
		declare @BenefitBatchInsertItemsSameDaySupServ as int=0
SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 

		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater1= substring (@Paramaters,0,@StartIndex) --BenefitItem
		

		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater1='+@paramater1
		PRINT @Paramaters

		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater2=substring(@Paramaters,0,@StartIndex) --ActivityDate

		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater2='+@paramater2
		PRINT @Paramaters
		
		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater3=ltrim(rtrim(substring(@Paramaters,0,@StartIndex))) --service
		IF @paramater3='' SET @paramater3='NULL' 
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater3='+@paramater3
		PRINT @Paramaters

		SET @StartIndex=CHARINDEX('@ItemreferenceStart',@Paramaters)
		SET @paramater4=ltrim(rtrim(substring(@Paramaters,0,@StartIndex))) --supplier
		IF @paramater4='' SET @paramater4='NULL' 
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+len('@ItemreferenceStart'),len(@Paramaters))
		PRINT '@paramater4='+@paramater4
		PRINT @Paramaters
		
		SET @StartIndex=CHARINDEX('@ItemreferenceEnd',@Paramaters)
		SET @paramater5=replace(ltrim(rtrim(substring(@Paramaters,0,@StartIndex))),'''','''''') --Reference
		IF @paramater5='' SET @paramater5='' 
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+len('@ItemreferenceEnd'),len(@Paramaters))
		PRINT '@paramater5='+@paramater5
		PRINT @Paramaters
		
		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater6=ltrim(rtrim(substring(@Paramaters,0,@StartIndex))) --ProfileID
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater6='+@paramater6
		PRINT @Paramaters
		
		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater7=ltrim(rtrim(substring(@Paramaters,0,@StartIndex))) --ProfileID
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater7='+@paramater7
		PRINT @Paramaters

		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater8=ltrim(rtrim(substring(@Paramaters,0,@StartIndex))) --chcbxOverwriteAmount
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater8='+@paramater8
		PRINT @Paramaters

		SET @StartIndex=CHARINDEX(',',@Paramaters)
		SET @paramater9=ltrim(rtrim(substring(@Paramaters,0,@StartIndex))) --chcbxOverwriteQuantity
		
		SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
		PRINT '@paramater9='+@paramater9
		PRINT @Paramaters
		
		--Enable Refrence params
	SET @StartIndex=charindex('@referenceNostart',@Paramaters)	
	PRINT @Paramaters
	SET @RefYear=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@referenceNostart'),len(@Paramaters))
	PRINT '@RefYear='+@RefYear
	PRINT @Paramaters
	
	SET @StartIndex=charindex('@referenceNoEnd',@Paramaters)	
	SET @RefNum=replace(substring(@Paramaters,0,@StartIndex),'''','''''')
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@referenceNoEnd'),len(@Paramaters))

	PRINT '@RefNum='+@RefNum
	PRINT @Paramaters
	
	SET @StartIndex=charindex(',',@Paramaters)	
	SET @IssueDate=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
	PRINT '@IssueDate='+@IssueDate
	PRINT @Paramaters
	
	SET @StartIndex=charindex(',',@Paramaters)	
	SET @ExecDate=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
	PRINT '@ExecDate='+@ExecDate
	PRINT @Paramaters
	
	SET @StartIndex=charindex(',',@Paramaters)	
	SET @RefStatus=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
	PRINT '@RefStatus='+@RefStatus
	PRINT @Paramaters
	
	SET @StartIndex=charindex('@referenceDescstart',@Paramaters)	
	SET @RefSource=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@referenceDescstart'),len(@Paramaters))
	PRINT '@RefSource='+@RefSource
	PRINT @Paramaters
	
	IF EXISTS(SELECT * FROM SysParamConfig WHERE SysParamConfig.ConfigID = 'BenefitBatchInsertItemsSameDaySupServ' AND SysParamConfig.ConfigValue = '1')
BEGIN
set @paramater7='false'
set @BenefitBatchInsertItemsSameDaySupServ=1
end

IF @enableAttachments=1
BEGIN
		SET @StartIndex=charindex('@referenceDescEnd',@Paramaters)	
	SET @RrfDesc=replace(substring(@Paramaters,0,@StartIndex),'''','''''')
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@referenceDescEnd'),len(@Paramaters))
	PRINT '@RrfDesc='+@RrfDesc
	PRINT @Paramaters
	
	SET @StartIndex=charindex('@AttachmentPathEnd',@Paramaters)	
	SET @AttachmentPath=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@AttachmentPathEnd'),len(@Paramaters))
	PRINT '@AttachmentPath='+@AttachmentPath
	PRINT @Paramaters
	
	SET @StartIndex=charindex('@AttachmentDesEnd',@Paramaters)	
	SET @AttachmentDesc=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@AttachmentDesEnd'),len(@Paramaters))
	PRINT '@AttachmentDesc='+@AttachmentDesc
	PRINT @Paramaters
	
	SET @StartIndex=charindex('@AttachmentADesEnd',@Paramaters)	
	SET @AttachmentADesc=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+len('@AttachmentADesEnd'),len(@Paramaters))
	PRINT '@AttachmentADesc='+@AttachmentADesc
	PRINT @Paramaters
	
	SET @StartIndex=charindex(',',@Paramaters)	
	SET @EnterDate=substring(@Paramaters,0,@StartIndex)
	SET @Paramaters=substring(@Paramaters,@StartIndex+1,len(@Paramaters))
	PRINT '@EnterDate='+@EnterDate
	PRINT @Paramaters
	
	SET @EnterBy=@Paramaters
	PRINT '@EnterBy='+@EnterBy
	
END
ELSE
	BEGIN
		SET @RrfDesc=replace(@Paramaters,'''','''''')
		PRINT '@RrfDesc='+@RrfDesc
	END
		
--		SET @paramater7=ltrim(rtrim(@Paramaters)) --chcbxOverwrite.Checked
--		PRINT '@paramater7='+@paramater7
--		PRINT @Paramaters

DECLARE @empid AS int
DECLARE @Documentno AS int 
DECLARE @Amount AS numeric(18,3)
DECLARE @Quantity AS numeric(18,3)
DECLARE @ActivityNote AS NVARCHAR(MAX)

DECLARE @servicename AS NVARCHAR(60)
DECLARE @suppliername AS NVARCHAR(60)
DECLARE @Reference AS NVARCHAR(MAX)
DECLARE @Relativename AS NVARCHAR(88)


DECLARE @serviceno AS INT
DECLARE @supplierno AS INT
DECLARE @relativeid AS INT 


DECLARE @BenefitServiceNo AS INT ,@BenefitSupplierNo AS INT 

DECLARE @Calc_Quantity AS NUMERIC(18, 3), @Calc_Amount as numeric(18, 3)
	, @OptionNo AS INT, @PlanNo AS INT, @Disable_Amount AS BIT, @Disable_Qty AS BIT 

	-----------------declare ----------------------------
DECLARE @Cur_RYear AS SMALLINT=null, @Cur_RNo AS nvarchar(10)=null, @Cur_IssueDate as nvarchar (100)=null, @Cur_ExecDate AS nvarchar (100)=null
					,@Cur_RStatus AS SMALLINT=null, @Cur_RSource  AS SMALLINT =null, @Cur_RDesc nvarchar(max) =null
					,@cur_AttachDesc nvarchar(max) , @cur_AttachPath nvarchar(max)  

             ,@cur_str NVARCHAR(MAX)='',@cur_str2 NVARCHAR(MAX)=''


					
IF   @enableRef = 1
 begin
 SET @cur_str= ' , t.[RYear], t.[RNo], t.[RIssueDate] , t.[RExecDate] 
				,NasArraysStatus.itemno [RStatus], NasArraysSource.itemno [RSource] , t.[RDesc] '

				
 SET @cur_str2=' LEFT JOIN NasArrays NasArraysStatus ON t.[RStatus] = case when '''+@lang+'''= ''e'' then ltrim(rtrim(NasArraysStatus.edesc)) else ltrim(rtrim(NasArraysStatus.adesc)) end 
AND NasArraysStatus.arrayname=''RStatus'' 
LEFT JOIN NasArrays NasArraysSource ON t.[RSource] = case when '''+@lang+'''= ''e'' then ltrim(rtrim(NasArraysSource.edesc)) else ltrim(rtrim(NasArraysSource.adesc)) end  
AND NasArraysSource.arrayname=''RSource'' '
end
ELSE
SET @cur_str= ' , null, null, null , null,null,null , null '

IF @enableAttachments=1
SET @cur_str= @cur_str +' ,t.AttDesc, t.AttPath '
ELSE
SET @cur_str= @cur_str + ' , null, null '

					
exec(N'DECLARE benefitcursor CURSOR FOR SELECT t.Row_Number,e.empid,e.Documentno,
		isnull(t.Amount,0.000) as Amount ,
		isnull(t.Quantity,0.000) as Quantity 
			,isnull(t.Relativename,'''') as Relativename
          ,isnull(t.servicename,'''') as servicename
          ,isnull(t.suppliername,'''') as suppliername
          ,isnull(t.Reference,N'''+@paramater5+''') as Reference
          ,isnull(t.activitynote,'''') as activitynote, BenefitPlanItems.PlanNo, BenefitPlanItems.OptionNo
		  , BenefitPlanItems.DisableAmount, BenefitPlanItems.DisableQty ,t.empid'+@cur_str+'
                                       FROM '+ @tablename+N' t  
						inner join empassignment on empassignment.employeeid=t.empid  
						inner join EmpBenefit e on e.empid=empassignment.empid
						INNER JOIN BenefitPlans ON BenefitPlans.PlanNo=e.PlanNo
						INNER JOIN BenefitOptions ON BenefitOptions.OptionNo=e.OptionNo
						INNER JOIN dbo.BenefitPlanItems ON e.OptionNo = BenefitPlanItems.OptionNo AND e.PlanNo = BenefitPlanItems.PlanNo AND BenefitPlanItems.itemno = '+@paramater1+'
						INNER JOIN SSDocumentStatus ON SSDocumentStatus.SSDocStatusNo=e.BenefitStatus'+@cur_str2+'
						WHERE t.post =1 and e.Closed<>1 and (isnull(t.amount,0.000)<>0 or isnull(t.Quantity,0.000)<>0 or ltrim('''+ @BenefitBatchInsertItemsSameDaySupServ+''')=1)'+
						@Where+N' and rtrim(ltrim(isnull(Replace(Replace(Replace(REPLACE(t.remarks,''-'',''''),rtrim(ltrim(N'''+@InvalidServiceNameerrormsg+''')),''''),rtrim(ltrim(N'''+@InvalidSupplierNameerrormsg+''')),''''),rtrim(ltrim(N'''+@InvalidRelativeNameerrormsg+''')),''''),'''')))=''''')
OPEN benefitcursor
FETCH next FROM benefitcursor
INTO @rowNumber,@empid,@Documentno,@Amount,@Quantity,@Relativename,@servicename,@suppliername,@Reference,@ActivityNote,@PlanNo,@OptionNo,@Disable_Amount,@Disable_Qty,@cur_empid
    ,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath

WHILE @@FETCH_STATUS=0
BEGIN

PRINT '1'
SET @serviceno=NULL
SET @supplierno=NULL
SET @relativeid=NULL

SELECT @relativeid=Relatives.RelProfileId
FROM   Relatives
       INNER JOIN PROFILE	ON  PROFILE.ProfileId = Relatives.RelProfileId
WHERE Relatives.ProfileId=@empid AND  ltrim(rtrim(@Relativename)) = CASE WHEN @lang=N'E' THEN ltrim(rtrim(PROFILE.Name))ELSE ltrim(rtrim(PROFILE.aName)) end



SELECT @supplierno=SupplierNo
FROM Supplier  
WHERE ltrim(rtrim(@suppliername)) <> '' AND ltrim(rtrim(@suppliername))= CASE WHEN @lang=N'E' THEN ltrim(rtrim(SupplierName))ELSE ltrim(rtrim(SupplieraName)) END 
 and ((isnull(SupplierNo,0) IN (SELECT BenefitPlanItems.SupplierNo FROM BenefitPlanItems WHERE BenefitPlanItems.itemno=@paramater1 and BenefitPlanItems.PlanNo=@PlanNo and
BenefitPlanItems.OptionNo= OptionNo and BenefitPlanItems.SupplierNo is not null ))  or (not exists(SELECT BenefitPlanItems.SupplierNo FROM BenefitPlanItems
 WHERE BenefitPlanItems.itemno = @paramater1 and BenefitPlanItems.PlanNo=@PlanNo and BenefitPlanItems.OptionNo=OptionNo and BenefitPlanItems.SupplierNo is not null )))  
		  
SELECT @serviceno=ServiceNo
FROM [Service]
WHERE  ltrim(rtrim(@servicename)) <> '' AND  ltrim(rtrim(@servicename)) = CASE WHEN @lang=N'E' THEN ltrim(rtrim(ServiceName))ELSE ltrim(rtrim(ServiceaName)) end  
AND ServiceNo in (select ServiceNo from SupplierService where SupplierService.SupplierNo = @supplierno) 
 	

SET @serviceno=ISNULL(@serviceno,NullIf(@paramater3, 'NULL') )

SET @supplierno=ISNULL(@supplierno,NullIf(@paramater4, 'NULL'))


SET @BenefitServiceNo = ISNULL(@serviceno,0)
SET @BenefitSupplierNo =ISNULL (@supplierno,0)



	IF LOWER(@paramater9) ='true'  
	BEGIN
	  IF @Disable_Qty = 0
	  BEGIN
		SET @Calc_Quantity=@Quantity
	  END
	  ELSE
	  BEGIN
	  	SELECT @updatetablestr = 'update '+@TableName+' set remarks = N'''+replace(cast(@disableQuantity AS NVARCHAR(250)),'''','''''')+N''' where Row_Number = ''' + ltrim(rtrim(Str(@rowNumber))) +''''
	    EXECUTE (@updatetablestr)
		FETCH NEXT FROM benefitcursor
          INTO  @rowNumber,@empid,@Documentno,@Amount,@Quantity,@Relativename,@servicename,@suppliername,@Reference,@ActivityNote,@PlanNo,@OptionNo,@Disable_Amount,@Disable_Qty,@cur_empid
  	           ,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath
	  END
	END 
	ELSE 
	BEGIN 
	----select '1',  @EmpID,@PlanNo,@OptionNo,@paramater1,@Documentno,@paramater2
		EXEC benefitformula @EmpID,null,@PlanNo,@OptionNo,@paramater1,@Documentno,@paramater2,3,' ',@Calc_Quantity OUTPUT, 0, @BenefitSupplierNo, @BenefitServiceNo
	END 
	
	IF LOWER(@paramater8) ='true'  
	BEGIN
		IF @Disable_Amount = 0
	    BEGIN
			SET @Calc_Amount=@Amount
	    END 
	    ELSE
	    BEGIN
		   SELECT @updatetablestr = 'update '+@TableName+' set remarks = N'''+replace(cast(@disableAmount AS NVARCHAR(250)),'''','''''')+N''' where Row_Number  = ''' + ltrim(rtrim(Str(@rowNumber))) +''''
	       EXECUTE (@updatetablestr)
		   FETCH NEXT FROM benefitcursor
          INTO  @rowNumber,@empid,@Documentno,@Amount,@Quantity,@Relativename,@servicename,@suppliername,@Reference,@ActivityNote,@PlanNo,@OptionNo,@Disable_Amount,@Disable_Qty,@cur_empid
  	           ,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath
	  END
	END 
	ELSE 
	BEGIN
	----select  '2', @EmpID,@PlanNo,@OptionNo,@paramater1,@Documentno,@paramater2
		EXEC benefitformula @EmpID,null,@PlanNo,@OptionNo,@paramater1,@Documentno,@paramater2,2,' ',@Calc_Amount OUTPUT, @Calc_Quantity, @BenefitSupplierNo, @BenefitServiceNo --original Qty is the first param after out param
	END 

--exec benefitformula @EmpID,null,@PlanNo,@OptionNo,@paramater1,@Documentno,@EnrollDate,3,' ',@Calc_Quantity OUTPUT, 0, 0, 0
--exec benefitformula @EmpID,null,@PlanNo,@OptionNo,@paramater1,@Documentno,@EnrollDate,2,' ',@Calc_Amount OUTPUT, 0, 0, 0 
PRINT 'Calc_Amount = '+convert(nvarchar(max),@Calc_Amount)
PRINT 'Calc_Quantity = '+convert(nvarchar(max),@Calc_Quantity)
PRINT 'Disable_Amount = '+convert(nvarchar(max),@Disable_Amount)
PRINT 'Disable_Qty = '+convert(nvarchar(max),@Disable_Qty)

PRINT @empid	

PRINT isnull(str(@relativeid),'NULL')
PRINT isnull(str(@serviceno),'NULL')
PRINT isnull(str(@supplierno),'NULL')
PRINT @paramater7
	BEGIN TRY
		IF LOWER(@paramater7)='true'
			BEGIN
			print 'update'
			--SET @select='UPDATE EmpBenefitItems 
			--				SET ServiceNo='+isnull(str(@serviceno),'NULL')
			--				+ ',ActivityNote= N'''+@ActivityNote+''''
			--				+ ',ForProfileId='+isnull(str(@relativeid),'NULL')				
			--				+ ',SupplierNo='+isnull(str(@supplierno),'NULL')
			--				+ ',ActivityAmount= case when '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Amount))),0.000)+'=0.000 then ActivityAmount else '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Amount))),0.000)+' end '
			--				+ ',ActivityQty= case when '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Quantity))),0.000)+'=0.000 then ActivityQty else '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Quantity))),0.000)+' end '
			--				+ ',Reference='+ 'N'''+@Reference+ ''''+', ChangeBy='+@paramater6+',ChangeDate=getdate() ,
			--				EmpBenefitItemsRYear='+@RefYear+',EmpBenefitItemsRNo= N'''+@RefNum+'''
			--				,EmpBenefitItemsRIssueDate= case when '+@IssueDate+' IS NULL then NULL else '+ ''''+@IssueDate+''' END 
			--				,EmpBenefitItemsRExecDate=case when '+@ExecDate+' IS NULL  then NULL else '+ ''''+@ExecDate+''' END,
			--			    EmpBenefitItemsRStatus='+@RefStatus+',EmpBenefitItemsRSource='+@RefSource+', EmpBenefitItemsRDesc= N'''+@RrfDesc+'''
			--				where empid = '+str(@empid)+' AND DocumentNo= '+str(@Documentno)+' AND 
			--				ItemNo='+@paramater1+' AND ActivityDate='+''''+@paramater2+''''+
			--				' and  ltrim(rtrim(str('+str(@empid)+')))+ ''-'' +'''+ltrim(rtrim(@Paramater1))+ '''+ ''-'' +'''+ltrim(rtrim(@Paramater2))+''''+
			--				' IN ( 
			--				SELECT DISTINCT ltrim(rtrim(str(ebi.EmpId)))+''-''+ltrim(rtrim(str(ebi.ItemNo)))+''-''+ltrim(rtrim(CONVERT(nchar(10),ebi.ActivityDate,112))) 
			--				FROM EmpBenefitItems ebi 
			--				where ebi.empid='+str(@empid)+' )'

			--print
			--'UPDATE EmpBenefitItems 
			--				SET ServiceNo='+isnull(str(@serviceno),'NULL')
			--				+ ',ActivityNote= N'''+@ActivityNote+''''
			--				+ ',ForProfileId='+isnull(str(@relativeid),'NULL')				
			--				+ ',SupplierNo='+isnull(str(@supplierno),'NULL')
			--				+ ',ActivityAmount= case when '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Amount))),0.000)+'=0.000 then ActivityAmount else '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Amount))),0.000)+' end '
			--				+ ',ActivityQty= case when '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Quantity))),0.000)+'=0.000 then ActivityQty else '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Quantity))),0.000)+' end '
			--				+ ',Reference='+ 'N'''+@Reference+ ''''+', ChangeBy='+@paramater6+',ChangeDate=getdate() ,
			--				EmpBenefitItemsRYear='+ISNULL(lTRIM(@Cur_RYear),@RefYear)+',EmpBenefitItemsRNo= N'''+ISNULL(@Cur_RNo,@RefNum)+'''
			--				,EmpBenefitItemsRIssueDate= '+ISNULL(''''+@Cur_IssueDate+'''',+'CASE WHEN '+@IssueDate+' is NULL THEN NULL ELSE '+ ''''+@IssueDate +''' end')
			--				+',EmpBenefitItemsRExecDate='+ISNULL(''''+@Cur_ExecDate+'''',+'CASE WHEN '+@ExecDate+' is NULL THEN NULL ELSE '+ ''''+@ExecDate +''' end')
			--				+',
			--			 EmpBenefitItemsRStatus='+ISNULL(ltrim(@Cur_RStatus),@RefStatus)+'
			--				,EmpBenefitItemsRSource='+ISNULL(ltrim(@Cur_RSource),@RefSource)+'
			--				, EmpBenefitItemsRDesc= N'''+ISNULL(@Cur_RDesc,@RrfDesc)+''' '
			--				+'where empid = '+str(@empid)+' AND DocumentNo= '+str(@Documentno)+' AND 
			--				ItemNo='+@paramater1+' AND ActivityDate='+''''+@paramater2+''''+
			--				' and  ltrim(rtrim(str('+str(@empid)+')))+ ''-'' +'''+ltrim(rtrim(@Paramater1))+ '''+ ''-'' +'''+ltrim(rtrim(@Paramater2))+''''+
			--				' IN ( 
			--				SELECT DISTINCT ltrim(rtrim(str(ebi.EmpId)))+''-''+ltrim(rtrim(str(ebi.ItemNo)))+''-''+ltrim(rtrim(CONVERT(nchar(10),ebi.ActivityDate,112))) 
			--				FROM EmpBenefitItems ebi 
			--				where ebi.empid='+str(@empid)+' )'

				SET @select='UPDATE EmpBenefitItems 
							SET ServiceNo='+isnull(str(@serviceno),'NULL')
							+ ',ActivityNote= N'''+@ActivityNote+''''
							+ ',ForProfileId='+isnull(str(@relativeid),'NULL')				
							+ ',SupplierNo='+isnull(str(@supplierno),'NULL')
							+ ',ActivityAmount= case when '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Amount))),0.000)+'=0.000 then ActivityAmount else '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Amount))),0.000)+' end '
							+ ',ActivityQty= case when '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Quantity))),0.000)+'=0.000 then ActivityQty else '+isnull(ltrim(rtrim(CONVERT(NVARCHAR(max),@Calc_Quantity))),0.000)+' end '
							+ ',Reference='+ 'N'''+@Reference+ ''''+', ChangeBy='+@paramater6+',ChangeDate=getdate() ,
							EmpBenefitItemsRYear='+ISNULL(lTRIM(@Cur_RYear),@RefYear)+',EmpBenefitItemsRNo= N'''+ISNULL(@Cur_RNo,@RefNum)+'''
							,EmpBenefitItemsRIssueDate= '+ISNULL(''''+@Cur_IssueDate+'''',+'CASE WHEN '+@IssueDate+' is NULL THEN NULL ELSE '+ ''''+@IssueDate +''' end')
							+',EmpBenefitItemsRExecDate='+ISNULL(''''+@Cur_ExecDate+'''',+'CASE WHEN '+@ExecDate+' is NULL THEN NULL ELSE '+ ''''+@ExecDate +''' end')
							+',
						 EmpBenefitItemsRStatus='+ISNULL(ltrim(@Cur_RStatus),@RefStatus)+'
							,EmpBenefitItemsRSource='+ISNULL(ltrim(@Cur_RSource),@RefSource)+'
							, EmpBenefitItemsRDesc= N'''+ISNULL(@Cur_RDesc,@RrfDesc)+''' '
							+'where empid = '+str(@empid)+' AND DocumentNo= '+str(@Documentno)+'
							and isnull(SupplierNo,0) = case when  isnull('+isnull(ltrim(@supplierno),'NULL')+',0)=0 then isnull(SupplierNo,0)  else isnull('+isnull(ltrim(@supplierno),'NULL')+',0) end
							and isnull(ServiceNo,0) = case when  isnull('+isnull(ltrim(@serviceno),'NULL')+',0)=0 then isnull(ServiceNo,0)  else isnull('+isnull(ltrim(@serviceno),'NULL')+',0) end
							and ItemNo='+@paramater1+' AND ActivityDate='+''''+@paramater2+''''+
							' and  ltrim(rtrim(str('+str(@empid)+')))+ ''-'' +'''+ltrim(rtrim(@Paramater1))+ '''+ ''-'' +'''+ltrim(rtrim(@Paramater2))+''''+
							' IN ( 
							SELECT DISTINCT ltrim(rtrim(str(ebi.EmpId)))+''-''+ltrim(rtrim(str(ebi.ItemNo)))+''-''+ltrim(rtrim(CONVERT(nchar(10),ebi.ActivityDate,112))) 
							FROM EmpBenefitItems ebi 
							where ebi.empid='+str(@empid)+' )'
							
								
								EXECUTE (@SELECT)
							
							IF EXISTS(SELECT * FROM EmpBenefitItems WHERE  empid =@empid AND DocumentNo= @Documentno AND 
							ItemNo=@paramater1 AND ActivityDate=@paramater2 
                            and isnull(SupplierNo,0) = case when  isnull(@supplierno,0)=0 then isnull(SupplierNo,0)  else isnull(@supplierno,0) end
						    and isnull(ServiceNo,0) = case when  isnull(@serviceno,0)=0 then isnull(ServiceNo,0)  else isnull(@serviceno,0) end)
							BEGIN
									IF @enableAttachments=1
										BEGIN
							            	IF  ISNULL(@cur_AttachPath,@AttachmentPath)<>'' 

											--IF  ISNULL(@cur_AttachPath,@AttachmentPath)<>''
												BEGIN
													INSERT INTO Attachments
													(
														-- AttachmentId -- this column value is auto-generated,
														EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,	AttachmentPath,EnterBy,EnterDate
													)
													select 
											        @empid,7,@Documentno,
itemDocumentNo,
0
											        	,ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachPath,@AttachmentPath)
,@EnterBy,@EnterDate
											        from EmpbenefitITems where DocumentNo=@Documentno
						                            and ItemNo =  @paramater1 and ActivityDate =  @paramater2
						                            and isnull(SupplierNo,0) = case when  isnull(@supplierno,0)=0 then isnull(SupplierNo,0)  else isnull(@supplierno,0) end
						                            and isnull(ServiceNo,0) = case when  isnull(@serviceno,0)=0 then isnull(ServiceNo,0)  else isnull(@serviceno,0) end
												END 
										END
			
							END
							
		
			
			END
			 
	       print'insert'
		--print 'INSERT INTO EmpBenefitItems ( 
		--			EmpId,  DocumentNo, ItemNo,  ActivityDate, ServiceNo, 
		--			SupplierNo, ActivityAmount,ActivityQty, Reference, EnterBy,  EnterDate,
		--			ActivityNote,ForProfileId,
		--			EmpBenefitItemsRYear,EmpBenefitItemsRNo,EmpBenefitItemsRIssueDate,EmpBenefitItemsRExecDate,
		--			EmpBenefitItemsRStatus,EmpBenefitItemsRSource, EmpBenefitItemsRDesc) 
		--			select '
		--			+
		--			str(@empid)+' , '+str(@Documentno)+' , '+ @paramater1+', '+''''+@paramater2+''''+', '+isnull(str(@serviceno),'NULL')+', '+ 
		--			isnull(str(@supplierno),'NULL')+', '+isnull(ltrim(rtrim(convert(nvarchar(max),@Calc_Amount))),0.000)+', '+isnull(ltrim(rtrim(convert(nvarchar(max),@Calc_Quantity))),0.000)+' , N'
		--			+ ''''+@Reference+''''+', '+ @paramater6+' ,'+ 'getdate(), N'''+
		--			@ActivityNote+''','+isnull(str(@relativeid),'NULL')
		--			+','+
		--			ISNULL(lTRIM(@Cur_RYear),@RefYear)+','+ N''''+ISNULL(@Cur_RNo,@RefNum) +''' '
					
		--			+','+ISNULL(''''+@Cur_IssueDate+'''',+'CASE WHEN '+@IssueDate+' is NULL THEN NULL ELSE '+ ''''+@IssueDate +''' end')
		--		+','+ISNULL(''''+@Cur_ExecDate+'''',+'CASE WHEN '+@ExecDate+' is NULL THEN NULL ELSE '+ ''''+@ExecDate +''' end') +','
		--			+ISNULL(ltrim(@Cur_RStatus),@RefStatus)+','
		--			+ ISNULL(ltrim(@Cur_RSource),@RefSource)+','
		--			+   N''''+ISNULL(@Cur_RDesc,@RrfDesc) +''' '
						 
			
			--select @Cur_IssueDate,@IssueDate
			SET @select='INSERT INTO EmpBenefitItems ( 
					EmpId,  DocumentNo, ItemNo,  ActivityDate, ServiceNo, 
					SupplierNo, ActivityAmount,ActivityQty, Reference, EnterBy,  EnterDate,
					ActivityNote,ForProfileId,
					EmpBenefitItemsRYear,EmpBenefitItemsRNo,EmpBenefitItemsRIssueDate,EmpBenefitItemsRExecDate,
					EmpBenefitItemsRStatus,EmpBenefitItemsRSource, EmpBenefitItemsRDesc) 
					select '
					+
					str(@empid)+' , '+str(@Documentno)+' , '+ @paramater1+', '+''''+@paramater2+''''+', '+isnull(str(@serviceno),'NULL')+', '+ 
					isnull(str(@supplierno),'NULL')+', '+isnull(ltrim(rtrim(convert(nvarchar(max),@Calc_Amount))),0.000)+', '+isnull(ltrim(rtrim(convert(nvarchar(max),@Calc_Quantity))),0.000)+' , N'
					+ ''''+@Reference+''''+', '+ @paramater6+' ,'+ 'getdate(), N'''+
					@ActivityNote+''','+isnull(str(@relativeid),'NULL')
					+','+
					ISNULL(lTRIM(@Cur_RYear),@RefYear)+','+ N''''+ISNULL(@Cur_RNo,@RefNum) +''' '
					
					+','+ISNULL(''''+@Cur_IssueDate+'''',+'CASE WHEN '+@IssueDate+' is NULL THEN NULL ELSE '+ ''''+@IssueDate +''' end')
				+','+ISNULL(''''+@Cur_ExecDate+'''',+'CASE WHEN '+@ExecDate+' is NULL THEN NULL ELSE '+ ''''+@ExecDate +''' end') +','
					+ISNULL(ltrim(@Cur_RStatus),@RefStatus)+','
					+ ISNULL(ltrim(@Cur_RSource),@RefSource)+','
					+   N''''+ISNULL(@Cur_RDesc,@RrfDesc) +''' 
						 
						where (' + str(@empid) + ' not in (select empid from EmpBenefitItems where DocumentNo='+str(@Documentno)
						+ ' and ItemNo = '+ @paramater1+' and ActivityDate = '''+ @paramater2+ ''' 
	and isnull(SupplierNo,0) = case when  isnull('+isnull(ltrim(@supplierno),'NULL')+',0)=0 then isnull(SupplierNo,0)  else isnull('+isnull(ltrim(@supplierno),'NULL')+',0) end
						and isnull(ServiceNo,0) = case when  isnull('+isnull(ltrim(@serviceno),'NULL')+',0)=0 then isnull(ServiceNo,0)  else isnull('+isnull(ltrim(@serviceno),'NULL')+',0) end) or '+ltrim(@BenefitBatchInsertItemsSameDaySupServ)+'=1 )'

   	
			

					--@RefYear+', N'''+@RefNum+''', case when '+@IssueDate+' IS NULL then NULL else '+ ''''+@IssueDate+''' END ,
					--	case when '+@ExecDate+'  IS NULL  then NULL else '+ ''''+@ExecDate+''' END ,'+@RefStatus+', '+@RefSource+', N'''+@RrfDesc+''' 
						 
					--	where ' + str(@empid) + ' not in (select empid from EmpBenefitItems where DocumentNo='+str(@Documentno)
					--	+ ' and ItemNo = '+ @paramater1+' and ActivityDate = '''+ @paramater2+ ''' )'

						
		EXECUTE (@SELECT)

				DECLARE @NumRowsChanged AS int
			SELECT @NumRowsChanged = @@ROWCOUNT
			--SELECT @NumRowsChanged
	
							SET @ErrorValue=@@ERROR
								PRINT str(@@ERROR)+'error'+str(@ErrorValue)
                     
										--IF @enableAttachments=1 AND @AttachmentPath<>'' AND @ErrorValue=0 AND @NumRowsChanged <>0
										IF @enableAttachments=1 AND ISNULL(@cur_AttachPath,@AttachmentPath)<>'' AND @ErrorValue=0 AND @NumRowsChanged <>0

										BEGIN
                             				INSERT INTO Attachments
											(
												-- AttachmentId -- this column value is auto-generated,
												EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,	AttachmentPath,EnterBy,EnterDate
											)
											select 
											@empid,7,@Documentno,itemDocumentNo,0
											,ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachDesc,@AttachmentADesc), ISNULL(@cur_AttachPath,@AttachmentPath),@EnterBy,@EnterDate
											from EmpbenefitITems where DocumentNo=@Documentno
						                    and ItemNo =  @paramater1 and ActivityDate =  @paramater2
						                    and isnull(SupplierNo,0) = case when  isnull(@supplierno,0)=0 then isnull(SupplierNo,0)  else isnull(@supplierno,0) end
						                    and isnull(ServiceNo,0) = case when  isnull(@serviceno,0)=0 then isnull(ServiceNo,0)  else isnull(@serviceno,0) end
										END 
END TRY
							    BEGIN CATCH
							    SELECT @Result = ERROR_MESSAGE()
								--SELECT @Result
								SELECT @updatetablestr = 'update '+@TableName+' set remarks = N'''+replace(cast(@Result AS NVARCHAR(250)),'''','''''')+N''' where Row_Number = ''' + ltrim(rtrim(Str(@rowNumber))) +''''
								EXECUTE (@updatetablestr)
							    END CATCH 
                             
FETCH NEXT FROM benefitcursor
  INTO  @rowNumber,@empid,@Documentno,@Amount,@Quantity,@Relativename,@servicename,@suppliername,@Reference,@ActivityNote,@PlanNo,@OptionNo,@Disable_Amount,@Disable_Qty,@cur_empid
  	,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath

END
CLOSE benefitcursor
DEALLOCATE benefitcursor


END

IF @actiontype=2 --Export
	BEGIN
		DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
		SET @t=@tablename
		SET @t=replace(@t,'dbo.[','')
		SET @t=replace(@t,']','')
		select @count=count(*) FROM sysobjects s WHERE s.name=@t
			
		IF @actual>0 SET @str='select '''' as empid,'''' as name,0.000 as amount,0.000 as Quantity,'''' as servicename,'''' as suppliername,'''' as Relativename,'''' as Reference,'''' as activitynote,0 as post,'''' as remarks WHERE 1<>1'
		ELSE
			IF @count=1 SET @str='select * from '+@tablename
			ELSE
				SET @str='select '''' as empid,'''' as name,0.000 as amount,0.000 as Quantity,'''' as servicename,'''' as suppliername,'''' as Relativename,'''' as Reference,'''' as activitynote,0 as post,'''' as remarks WHERE 1<>1'
	
		exec sp_executesql @str
	END

IF @actiontype=3 --Import
	BEGIN
	  SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 

		DECLARE @updatestr AS nvarchar(max),
				@insertstr AS nvarchar(max),@deletestr AS nvarchar(max),
				@selectstr AS nvarchar(max),@DisabledColStr AS nvarchar(100)
			 , @CreateStrRefAttach AS nvarchar(max)='', @SelectStrRefAttach AS nvarchar(max)='', @InsertStrRefAttach AS nvarchar(max)='', @UpdateStrRefAttach AS nvarchar(max)=''

		IF rtrim(ltrim(@tablename))<>'' 
		
			BEGIN
				
			--DECLARE @TableNamelen AS int 
			--SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
			--SET @select ='IF not EXISTS(SELECT top 1 1
			--FROM '+substring(@tablename,0,charindex('.dbo',@tablename))+'.INFORMATION_SCHEMA.Columns 
			--WHERE  '+substring(@tablename,0,charindex('.dbo',@tablename))+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+SUBSTRING(@TableName,charindex('[nasbatch',@TableName)+1,@TableNamelen)+''')'
			--+'CREATE TABLE ' + @tablename+ ' ( EmpId int, Name nvarchar(88) collate database_default, amount [numeric](18,3), Post bit, Remarks nvarchar(256))'
			
			------------------------------- create -------------------------------------------
					IF  @enableRef = 1
		SET @CreateStrRefAttach='[RYear] [smallint],[RNo] [nvarchar](10),[RIssueDate] [datetime],[RExecDate] [datetime]
					,[RStatus] [nvarchar](30),[RSource] [nvarchar](30),[RDesc] [nvarchar](max) ,'

		  IF @enableAttachments=1
		SET @CreateStrRefAttach= @CreateStrRefAttach+' AttDesc [nvarchar](max), AttPath [nvarchar](max),'

			SET @select ='IF not EXISTS(SELECT top 1 1
		    FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
		    WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
			+'CREATE TABLE ' + @tablename+ ' ( EmpId nvarchar(50), Name nvarchar(88) collate database_default, amount [numeric](18,3),Quantity [numeric](18,3), servicename nvarchar(60) collate database_default,suppliername nvarchar(60) collate database_default, Relativename nvarchar(88) collate database_default
			,Reference nvarchar(max) collate database_default, Activitynote nvarchar(max) collate database_default,'  + @CreateStrRefAttach +' Post bit, Remarks nvarchar(256) collate database_default,[Row_Number] int Identity(1,1) NOT NULL Primary Key)'
PRINT @select
			END 
		
		
			--SET @select='   CREATE TABLE ' + @tablename+ ' (empid [int] ,name [nchar](88), 
 		--					 amount	[numeric](18,3) ,post bit ,remarks [nvarchar](256))'
		ELSE
			begin
				SET @tablename='  '
				-------------------------select------------------------------------------------
				IF  @enableRef = 1
		 SET @SelectStrRefAttach=' 0  as [RYear] ,'''' as [RNo], '''' as [RIssueDate] , '''' as [RExecDate] 
	     , ''''  as [RStatus] ,''''  as [RSource] ,'''' as [RDesc] ,'

		IF @enableAttachments=1
		   SET @SelectStrRefAttach= @SelectStrRefAttach+' ''''  as AttDesc , ''''  as AttPath ,'

				SET @selectstr='select '''' as empid,'''' as name,0.000 as amount,0.000 as Quantity,'''' as servicename,'''' as suppliername,'''' as Relativename,'''' as Reference,'''' as Activitynote,'+ @SelectStrRefAttach+'0 as post,'''' as remarks WHERE 1<>1'
			END
			
	/*	SET @updatestr=N' update '+@tablename+N' set amount=@amount,Quantity=@Quantity ,post=@post ,remarks=@remarks
		,Activitynote=@Activitynote 
		,servicename=@servicename 
		,suppliername=@suppliername 
		,Relativename=@Relativename
		,Reference=@Reference 
		
						 where isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)
						 DECLARE @str AS NVARCHAR(max)
						    DECLARE @errormsg0 AS NVARCHAR(250)
SELECT @errormsg0= isnull(dbo.Hits_GetDCCaption(''WP_GetExternalBenefitItems'',''InvalidRelativeName'','''+@lang+N'''),
(case when '''+@lang+N'''=N''A'' then N''اسم غير صحيح '' ELSE N''Invalid Relative Name''  end))

select @str=''UPDATE '+@tablename+N' set remarks= 

case when (profile.profileid is not null or  ltrim(rtrim(isnull(temptable.Relativename,'''''''')))='''''''') then replace ( '''',''''+ltrim(rtrim(remarks))+ '''','''', '''','''' +''''''+ltrim(rtrim(@errormsg0))+''''''  + '''','''','''' '''')
when CHARINDEX(''''''+@errormsg0+'''''',remarks,0)=0 then remarks +case when ltrim(rtrim(remarks)) <> '''''''' then '''','''' else '''''''' end + ''''''+@errormsg0+''''''
else remarks
	 end 
  
	FROM '+@tablename+N' temptable
	inner JOIN EmpAssignment ON temptable.empid=empassignment.EmployeeId 
	inner join Relatives on Relatives.ProfileId=EmpAssignment.empid --and Relatives.RelProfileId = temptable.Relativeid
	left join profile on profile.profileid=Relatives.RelProfileId and temptable.Relativename=''+CASE WHEN '''+@lang+N'''=''A'' THEN ''profile.aname'' ELSE ''profile.name'' END+'' 
 
where  
 
isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(''+str(@originalRow_Number)+'')),0)
and temptable.empid = '' + str(@originalEmpId)

	
	PRINT @str
	EXECUTE(@str)
	
						 '
		   
		

*/
/*
DECLARE @errormsg0 AS NVARCHAR(250)
SELECT @errormsg0= isnull(dbo.Hits_GetDCCaption(''WP_GetExternalBenefitItems'',''InvalidRelativeName'','''+@lang+N'''),
(case when '''+@lang+N'''=N''A'' then N''اسم القريب غير صحيح '' ELSE N''Invalid Relative Name''  end))

set @errormsg0= isnull(dbo.Hits_GetDCCaption(''WP_GetExternalBenefitItems'',''InvalidServiceName'','''+@lang+N'''),
(case when '''+@lang+N'''=N''A'' then N''اسم الخدمه غير صحيح '' ELSE N''Invalid Service Name''  end))

set @errormsg0= isnull(dbo.Hits_GetDCCaption(''WP_GetExternalBenefitItems'',''InvalidSupplierName'','''+@lang+N'''),
(case when '''+@lang+N'''=N''A'' then N''اسم المورد غير صحيح '' ELSE N''Invalid Supplier Name''  end))
*/

-------------------------------update ---------------------------------------------
  IF  @enableRef = 1 
  SET @UpdateStrRefAttach=' RYear=ltrim(rtrim(@RYear)), RNo=ltrim(rtrim(@RNo))
, RIssueDate=convert(datetime,@RIssueDate,'+ltrim(rtrim(str(@DateFormat)))+')
, RExecDate =convert(datetime,@RExecDate,'+ltrim(rtrim(str(@DateFormat)))+')
,RStatus=ltrim(rtrim(@RStatus)), RSource=ltrim(rtrim(@RSource)), RDesc=ltrim(rtrim(@RDesc)),'

IF @enableAttachments=1
  SET @UpdateStrRefAttach= @UpdateStrRefAttach+' AttDesc=ltrim(rtrim(@AttDesc)) , AttPath=ltrim(rtrim(@AttPath)) ,'

	SET @updatestr=N' update '+@tablename+N' set amount=round(@amount,'+STR(@DecimalScale)+'),Quantity=round(@Quantity,'+STR(@DecimalScale)+') ,'+@UpdateStrRefAttach+'post=@post ,remarks=isnull(@remarks,'''')
,Activitynote=@Activitynote,servicename=@servicename,suppliername=@suppliername,Relativename=@Relativename,Reference=@Reference 
where isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)
DECLARE @str AS NVARCHAR(max)
select @str=N''UPDATE '+@tablename+N' set remarks=
case when (profile.profileid is not null or  ltrim(rtrim(isnull(temptable.Relativename,'''''''')))='''''''')
then replace ( ltrim(rtrim(remarks)), ''''-'''' +ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidRelativeNameerrormsg))+'''''))  ,'''' '''')
when CHARINDEX(ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidRelativeNameerrormsg))+''''')),remarks,0)=0
then remarks +'''' -''''  + ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidRelativeNameerrormsg))+'''''))
else remarks end
FROM '+@tablename+N' temptable
inner JOIN EmpAssignment ON temptable.empid=empassignment.EmployeeId 
inner join Relatives on Relatives.ProfileId=EmpAssignment.empid --and Relatives.RelProfileId = temptable.Relativeid
left join profile on profile.profileid=Relatives.RelProfileId and temptable.Relativename=''+CASE WHEN '''+@lang+N'''=''A'' THEN ''profile.aname'' ELSE ''profile.name'' END+'' 
where isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(''+str(@originalRow_Number)+'')),0) and temptable.empid = ''''''+@originalEmpId+ ''''''''
PRINT @str
EXECUTE(@str)
select @str=N''UPDATE '+@tablename+N' set remarks= 
case when (service.serviceNo is not null or  ltrim(rtrim(isnull(temptable.servicename,'''''''')))='''''''')
then replace ( ltrim(rtrim(remarks)), ''''-'''' +ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidServiceNameerrormsg))+'''''))  ,'''' '''')
when CHARINDEX(ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidServiceNameerrormsg))+''''')),remarks,0)=0
then remarks +'''' -''''  + ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidServiceNameerrormsg))+'''''))
else remarks end
FROM '+@tablename+N' temptable
left JOIN service on  temptable.serviceName = ''+CASE WHEN '''+@lang+N'''=''A'' THEN N''service.serviceaName'' ELSE N''service.serviceName'' END+N''
where  isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(''+str(@originalRow_Number)+'')),0) and temptable.empid = ''''''+@originalEmpId+ ''''''''
PRINT @str
EXECUTE(@str)
select @str=N''UPDATE '+@tablename+N' set remarks= 
case when (Supplier.SupplierNo is not null or  ltrim(rtrim(isnull(temptable.Suppliername,'''''''')))='''''''')
then replace ( ltrim(rtrim(remarks)), ''''-'''' +ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidSupplierNameerrormsg))+'''''))  ,'''' '''')
when CHARINDEX(ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidSupplierNameerrormsg))+''''')),remarks,0)=0
then remarks +'''' -''''  + ltrim(rtrim(N'''''+ltrim(rtrim(@InvalidSupplierNameerrormsg))+'''''))
else remarks end
FROM '+@tablename+N' temptable
left JOIN Supplier on  temptable.SupplierName = ''+CASE WHEN '''+@lang+N'''=''A'' THEN N''Supplier.SupplieraName'' ELSE N''Supplier.SupplierName'' END+N''
where  isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(''+str(@originalRow_Number)+'')),0)
and temptable.empid = ''''''+@originalEmpId+ ''''''''
PRINT @str
EXECUTE(@str)
'
      
		   
		   ------------------------------- insert---------------------
		   IF  @enableRef = 1  
	SET @InsertStrRefAttach=' @RYear, @RNo, @RIssueDate, @RExecDate 
					,@RStatus, @RSource, @RDesc, '
     IF @enableAttachments=1
	 	SET @InsertStrRefAttach= @InsertStrRefAttach+' @AttDesc , @AttPath ,'

		

		SET @insertstr=' insert into '+@tablename+' select @empid , @name , round(@amount,'+STR(@DecimalScale)+'),@servicename,@suppliername
		,@Relativename,@Reference,@Quantity,@Activitynote,'+@InsertStrRefAttach+'  @post ,@remarks'

		--------------------delete--------------------
		SET @deletestr=' delete from  '+@tablename+' where isnull(ltrim(rtrim(Row_Number)),0)=isnull(ltrim(rtrim(@originalRow_Number)),0) '

		 
		  DECLARE @count1 AS int 
	     	set @count1=11
		             IF  @enableRef = 1  SET @count1=@count1+7
                     IF  @enableAttachments = 1  SET @count1=@count1+2
		    
		SET @DisabledColStr='1,2,'+ltrim(rtrim(str(@count1)))
		exec sp_executesql @select
		SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr
	END
	
	
	IF @actiontype=4
	BEGIN
		set @outputstr = 'select '''' as empid,'' '' as name,0.000 as amount,0.000 as Quantity,0 as post,'' '' as servicename,'' '' as suppliername,'' '' as Relativename,'' '' as Reference,'' '' as activitynote,'' '' as remarks
						 , identity(int,1,1) as [Row_Number] into #EndResultPagging  where 1<>1 '
	END
	
	                 
	
	/*
	IF ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems' OR ltrim(rtrim(@tabletype)) ='WP_GetExternalBenefitItems_ar'
BEGIN	
-- get relative name 
select @str='UPDATE '+@tablename+' set Relativename='+CASE WHEN @lang='A' THEN 'profile.Aname ' ELSE 'profile.name' END+' 
	FROM '+@tablename+' temptable
	inner JOIN EmpAssignment ON temptable.empid=empassignment.EmployeeId 
	inner join Relatives on Relatives.ProfileId=EmpAssignment.empid and Relatives.RelProfileId = temptable.Relativeid
	inner join profile on profile.profileid=Relatives.RelProfileId
 
where    ( Empassignment.privacy between '+ltrim(str(@PrivacyLevelFrom))+' and '+ltrim(str(@PrivacyLevelTo))+' )' 
	+ case when @ApplySSGroups=1  then N' and EmpAssignment.SSGroup  in (select SSGroup from SSGroupRole where SSGroupRole.ProfileId='+str(@empid)+')' else N' '  end	

	PRINT @str
	EXECUTE(@str)
END
*/

GO

