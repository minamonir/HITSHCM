

CREATE PROCEDURE [dbo].[AttendanceStatus] (@DataBase nvarchar(40),@Before INT=-1 ,@Period INT=0)

AS

BEGIN
--Time Rule is First In Last Out
--For splitted shift 2 records will be inserted (if different atendance status)
--for late in and early out together ==> AttendanceStatus=1 (First case LateIn)

--AttendanceStatus BanglalinkData
--DECLARE @Before INT ,@Period INT
--SELECT @before=-1,@period=0

Declare @select nvarchar(max),@select2 nvarchar(max)

set @select= '
CREATE TABLE #temp
(EmployeeId nvarchar(50)
,Mobile nCHAR (20)
,Name nCHAR(88)
,AttendanceStatus INT
,AttendanceDate SMALLDATETIME
,UpdateDate SMALLDATETIME)

INSERT INTO #temp
Select  Distinct
EmpAssignment.EmployeeId
,Profile.Mobile
,Profile.Name
,CASE WHEN  dbo.EmpVacOrNot(EmpShiftInOut.empid,EmpShiftInOut.entrydate)<2 THEN 0 -- Absent
WHEN ((EmpShiftInOut.TimeIn  is null and EmpShiftInOut.TimeOut is not null)OR(EmpShiftInOut.TimeIn  is not null and EmpShiftInOut.TimeOut is  null)) THEN 3 --InComplete

--when ((isnull(DATEDIFF(minute,EmpShiftInOut.ShiftIn,EmpShiftInOut.timeIn),0)>30)AND(EmpShiftInOut.PShortSecondsIn=0))
--and ((isnull(DATEDIFF(minute,EmpShiftInOut.ShiftOut,EmpShiftInOut.timeOut),0)<-30)AND(EmpShiftInOut.PShortSecondsOut=0)) then 4 --LateIn&EarlyOut

WHEN((isnull(DATEDIFF(minute,EmpShiftInOut.ShiftIn,EmpShiftInOut.timeIn),0)>30) AND(EmpShiftInOut.PShortSecondsIn=0) AND WorkSeconds<ShiftSeconds) THEN 1 --LateIn
WHEN((isnull(DATEDIFF(minute,EmpShiftInOut.ShiftOut,EmpShiftInOut.timeOut),0)<-30) AND(EmpShiftInOut.PShortSecondsOut=0) AND WorkSeconds<ShiftSeconds) THEN 2 --EarlyOut
ELSE NULL END 
AS AttendanceStatus
,EmpShiftInOut.EntryDate AS AttendanceDate
,NULL AS UpdateDate 
FROM EmpShiftInOut
left JOIN EmpShift ON EmpShiftInOut.EmpId=EmpShift.EmpId AND EmpShiftInOut.EntryDate=EmpShift.ShiftDate
LEFT JOIN EmpAssignment ON EmpAssignment.EmpId=EmpShiftInOut.EmpId
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN TimeShifts ON TimeShifts.ShiftNo = EmpShift.ShiftNo
WHERE HrStatus.PayStatus=1 
AND EmpShiftInOut.ShiftSeconds<>0
AND convert(smalldatetime,convert(nchar(12),EmpShiftInOut.EntryDate),103) 
BETWEEN (CASE WHEN TimeShifts.ShiftType=3 THEN convert(smalldatetime,convert(nchar(12),dateadd(d,'+str(@before-1)+',Getdate())),103)			ELSE convert(smalldatetime,convert(nchar(12),dateadd(d,'+str(@before)+',Getdate())),103) END)
AND 	(CASE WHEN TimeShifts.ShiftType=3 THEN convert(smalldatetime,convert(nchar(12),dateadd(d,'+str(@before-1+@period)+',Getdate())),103)  ELSE  convert(smalldatetime,convert(nchar(12),dateadd(d,'+str(@before+@period)+',Getdate())),103) END)
AND convert(nchar(10),EmpShiftInOut.EntryDate,112) not in 
(SELECT convert(nchar(10),Holidays.date,112) FROM Holidays WHERE holidays.vacpack=empassignment.vacpack AND holidays.holiday=1)
'
select @select2 ='
DELETE FROM #temp WHERE AttendanceStatus IS NULL
IF NOT EXISTS (SELECT * 
               FROM '+@DataBase+'.INFORMATION_SCHEMA.TABLES  
               WHERE TABLE_TYPE=''BASE TABLE'' 
               AND TABLE_NAME=''AttendanceSMS'')
BEGIN
	CREATE TABLE  '+@DataBase+'.[dbo].[AttendanceSMS](
	[EmployeeId] [nvarchar](50) NULL,
	[Mobile] [nchar](20) NULL,
	[Name] [nchar](88) NULL,
	[AttendanceStatus] [int] NULL,
	[AttendanceDate] [smalldatetime] NULL,
	[UpdateDate] [smalldatetime] NULL
	) ON [PRIMARY]
END 

INSERT INTO '+@DataBase+'.dbo.AttendanceSMS
SELECT * FROM #temp
WHERE #temp.EmployeeId NOT IN (SELECT Att.EmployeeId 
							   FROM '+@DataBase+'.dbo.AttendanceSMS Att 
							   WHERE Att.AttendanceDate=#temp.AttendanceDate)
DROP TABLE #temp
'
PRINT @select
PRINT @select2
EXEC(@select + @select2)



END

GO

