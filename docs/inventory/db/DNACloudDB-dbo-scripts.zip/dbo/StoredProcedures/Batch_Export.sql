CREATE    PROCEDURE [dbo].[Batch_Export]  (
@tablename AS nvarchar(150),@tabletype AS nvarchar(100),@actual AS smallint) 

AS

BEGIN
	
	DECLARE @str AS nvarchar(max),@count AS int,@t AS nvarchar(150)
    DECLARE @outstr	AS nvarchar(max)
	SET @t=@tablename
	SET @t=replace(@t,'dbo.[','')
	SET @t=replace(@t,']','')
select @count=count(*) FROM sysobjects s WHERE s.name=@t


--set @str = 'EXEC [batch'+ltrim(rtrim(@tabletype))+'] 2,''' + @tablename  +''','+str(@actual)+',@formulaOutput output'
DECLARE @actualtablename AS nvarchar(150)
SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName LIKE @tabletype

SET @actualtablename=isnull(@actualtablename,'')

--IF ltrim(rtrim(@tabletype))='WP_JVSetup' 
--BEGIN
--
--EXEC BatchWP_JVSetup 2,@tablename,@actual,'',@outstr output
--end
IF ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes'   OR  ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes_ar'  
OR ltrim(rtrim(@tabletype))LIKE 'WP_GetExternalPaycodes%'   OR  ltrim(rtrim(@tabletype))LIKE 'WP_GetExternalPaycodes_ar%'  
BEGIN 

DECLARE @SELECT AS nvarchar(max)
---------------------
DECLARE @Selectpaycodes AS NVARCHAR(max)=''
DECLARE @PayCodeName AS NVARCHAR(30)
DECLARE @PayCodeAName AS NVARCHAR(30)
DECLARE @ColumnName AS NVARCHAR(30)


IF ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes'   OR  ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes_ar'  
begin
SET @SELECT='DECLARE tempcursor CURSOR for SELECT  COLUMN_NAME 
FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  ORDINAL_POSITION > 15 '
END
ELSE
BEGIN
SET @SELECT='DECLARE tempcursor CURSOR for SELECT COLUMN_NAME 
FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  ORDINAL_POSITION > 5 '
end
EXECUTE(@SELECT)
OPEN tempcursor
FETCH next FROM tempcursor
INTO  @ColumnName
WHILE @@FETCH_STATUS=0
BEGIN
IF SUBSTRING(@ColumnName,1,1) ='P'
BEGIN
IF ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes_ar' OR ltrim(rtrim(@tabletype)) like'WP_GetExternalPaycodes_ar%'   
	BEGIN	
	SET @PayCodeAName=''
	SELECT @PayCodeAName=LTRIM(RTRIM(PayCodeAName)) FROM Paycode WHERE code=SUBSTRING(@ColumnName,2,LEN(@ColumnName)) 
	PRINT @ColumnName
	SET @Selectpaycodes=@Selectpaycodes+',' + @ColumnName+' AS [' +@PayCodeAName+']'	
	end
	ELSE
	begin		
	SET @PayCodeName=''
	SELECT @PayCodeName=LTRIM(RTRIM(PayCodeName)) FROM Paycode WHERE code=SUBSTRING(@ColumnName,2,LEN(@ColumnName)) 
	PRINT @ColumnName
	SET @Selectpaycodes=@Selectpaycodes+',' + @ColumnName+' AS [' +@PayCodeName+']'
	END
END
FETCH NEXT FROM tempcursor
INTO @ColumnName
END


CLOSE tempcursor
DEALLOCATE tempcursor
PRINT @Selectpaycodes

DECLARE @enableAttachments AS BIT
	DECLARE @enableRef AS BIT
	DECLARE @SelectStrRefAttach as  nVarChar(max) =''
	SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 

		IF  @enableRef = 1
		BEGIN
		set @SelectStrRefAttach= (CASE WHEN LTRIM(RTRIM(@tabletype)) like '%Paycodes_ar%' THEN N',RYear as  [سنة القرار], RNo  as [رقم القرار]  ,RIssueDate  as [تارىخ الاصدار]  ,RExecDate as [تارىخ التنفىذ] ,RStatus as [الحالة] ,RSource as [المصدر] ,RDesc as [الوصف] ' 
		                       ELSE ',RYear as  [Ref.Year] ,RNo  as [Ref.N#]  ,RIssueDate  as [Ref.Issue Date]  ,RExecDate as [Ref.Exec. Date] ,RStatus as [Ref.Status] ,RSource as [Ref.Source] ,RDesc as [Ref.Description]' END )			     
		end 
	  IF @enableAttachments=1
		BEGIN
		SET @SelectStrRefAttach= @SelectStrRefAttach+ (CASE WHEN LTRIM(RTRIM(@tabletype)) like '%Paycodes_ar%' THEN  N' ,AttDesc as [وصف الملحق], AttPath [وصف الملحق] 'else  ',AttDesc as [Description], AttPath [Path]'end )
		end

		
IF ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes'   OR  ltrim(rtrim(@tabletype))='WP_GetExternalHistoryPaycodes_ar'  
	SET @SELECT='select Year,month,EmpId,Name,RunNo,PayrollGroup,Currency,CurrencyRate,Center,Organisation,Status,FamilyAllow,Post,Remarks,Row_Number'
	
	+@SelectStrRefAttach+@Selectpaycodes+' from '+@tablename
ELSE
    SET @SELECT='select EmpId as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) like 'WP_GetExternalPaycodes_ar%' 
						THEN N'[رقم الموظف]' ELSE '[EmpId]' END ) +',Name as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) like 'WP_GetExternalPaycodes_ar%' 
						THEN N'[الاسم]' ELSE '[Name]' END ) +',Post as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) like 'WP_GetExternalPaycodes_ar%' 
						THEN N'[تحميل]' ELSE '[Post]' END ) +',Remarks as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) like 'WP_GetExternalPaycodes_ar%' 
						THEN N'[ملاحظات]' ELSE '[Remarks]' END ) +',Row_Number as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) like 'WP_GetExternalPaycodes_ar%' 
						THEN N'[رقم الصف]' ELSE '[Row_Number]' END )
						+@SelectStrRefAttach+@Selectpaycodes+' from '+@tablename

	PRINT @SELECT


 	exec sp_executesql @SELECT
END


IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales%'   OR  ltrim(rtrim(@tabletype)) LIKE 'WP_ExportBenefitSalaryScales_ar%' 
BEGIN 
DECLARE @SELECTsal AS nvarchar(max) =''
DECLARE @CapCoverageAmount AS NVARCHAR(max),@CapLevelAmount AS NVARCHAR(max),@CapCoverageAmount2 AS NVARCHAR(max),@CapLevelAmount2 AS NVARCHAR(max),@indexlang AS int,@Lang AS CHAR(1)
PRINT @tabletype
SET @tabletype = replace (@tabletype,'WP_ExportBenefitSalaryScales_ar?','')
SET @tabletype = replace (@tabletype,'WP_ExportBenefitSalaryScales?','')  

SET @indexlang = CHARINDEX('?',@tabletype)
SET @Lang=substring (@tabletype,0,@indexlang)
SET @tabletype=substring(@tabletype,@indexlang+1,len(@tabletype))
PRINT 'Lang = '+@Lang
PRINT @tabletype


SET @CapCoverageAmount2= ISNULL(dbo.Hits_GetDCCaption('WP_ExportBenefitSalaryScales','CoverageAmount',@Lang),CASE WHEN @Lang ='A' THEN N'قيمة_التغطية' ELSE 'Coverage_Amount' end)
SET @CapLevelAmount2 = ISNULL(dbo.Hits_GetDCCaption('WP_ExportBenefitSalaryScales','LevelAmount',@Lang),CASE WHEN @Lang ='A' THEN N'مستوى_التعويض'ELSE  'Level_Amount' END)

SET @CapCoverageAmount= 'Coverage_Amount'
SET @CapLevelAmount = 'Level_Amount'

DECLARE @SelectPlanOption AS NVARCHAR(max)=''
DECLARE @PlanOptionName AS NVARCHAR(max)=''
,@PlanOptioNo AS NVARCHAR(max)
,@PlanNo AS INT
,@OptionNo AS int 
,@PlanName AS NVARCHAR(60)=''
,@OptionName AS NVARCHAR(60)=''

SET @SELECTsal='DECLARE tempcursor CURSOR for SELECT COLUMN_NAME 
FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND COLUMN_NAME not in (''Post'',''Remarks'',''Row_Number'',''GradeNo'',''Grade'') '

EXECUTE(@SELECTsal)
OPEN tempcursor

FETCH next FROM tempcursor
INTO  @PlanOptioNo
WHILE @@FETCH_STATUS=0
BEGIN

	--PRINT '4'
	IF SUBSTRING(@PlanOptioNo,1,1) = 'P'
	BEGIN 
				IF @PlanOptioNo LIKE '%'+@CapCoverageAmount+'%'
					BEGIN
			
	    				SET @PlanOptioNo =  SUBSTRING(@PlanOptioNo,2,CHARINDEX(@CapCoverageAmount,@PlanOptioNo)-2)
	    		
						SET @PlanOptioNo = CAST (@PlanOptioNo AS INT)
		
					   SET @PlanNo=FLOOR(@PlanOptioNo/10000)
					   SET @OptionNo=@PlanOptioNo % 10000

	
						SELECT @planname= CASE WHEN @Lang ='A' THEN LTRIM(RTRIM(planAname)) ELSE LTRIM(RTRIM(planname)) END  FROM BenefitPlans WHERE planno=isnull(@PlanNo,0)
						SELECT @OptionName= CASE WHEN  @Lang ='A' THEN  LTRIM(RTRIM(OptionAName)) ELSE  LTRIM(RTRIM(OptionName)) END  FROM BenefitOptions WHERE OptionNo=isnull(@OptionNo,0)
	
						--SELECT @PlanOptionName= @planname +' - ' + @OptionName
						SELECT @PlanOptionName=  CASE WHEN @planname = '' THEN @OptionName  ELSE @planname +' - ' + @OptionName END 
	
						SET @SelectPlanOption=@SelectPlanOption+',' + 'P'+LTRIM(RTRIM(@PlanOptioNo))+@CapCoverageAmount+' AS [' +@PlanOptionName+'('+@CapCoverageAmount2+')'+']'
	    	
					END
			IF @PlanOptioNo LIKE '%'+@CapLevelAmount+'%'--'%LevAmount%'
					BEGIN
	     
						SET @PlanOptioNo =  SUBSTRING(@PlanOptioNo,2,CHARINDEX(@CapLevelAmount,@PlanOptioNo)-2)
						SET @PlanOptioNo = CAST (@PlanOptioNo AS INT)

						SET @PlanNo=FLOOR(@PlanOptioNo/10000 )
						SET @OptionNo=@PlanOptioNo % 10000
	
						SELECT @planname= CASE WHEN @Lang ='A' THEN LTRIM(RTRIM(planAname)) ELSE LTRIM(RTRIM(planname)) END  FROM BenefitPlans WHERE planno=isnull(@PlanNo,0)
						SELECT @OptionName= CASE WHEN  @Lang ='A' THEN  LTRIM(RTRIM(OptionAName)) ELSE  LTRIM(RTRIM(OptionName)) END  FROM BenefitOptions WHERE OptionNo=isnull(@OptionNo,0)
	
						SET @PlanOptionName= ''
						SELECT @PlanOptionName= CASE WHEN @planname = '' THEN @OptionName  ELSE @planname +' - ' + @OptionName END 

						SET @SelectPlanOption=@SelectPlanOption+','  + 'P'+LTRIM(RTRIM(@PlanOptioNo))+@CapLevelAmount+' AS [' +@PlanOptionName+'('+@CapLevelAmount2+')'+']'
					END
	   --END 

FETCH NEXT FROM tempcursor
INTO @PlanOptioNo

END 
END

CLOSE tempcursor
DEALLOCATE tempcursor

PRINT @SelectPlanOption
    
----------------------------------- insert Grades in temp table --------------------------
--DECLARE @CountRows AS INT
--DECLARE @ParmDefinitionfilterRows AS NVARCHAR(100)
--DECLARE @Querynew  AS  NVARCHAR(max)

--DECLARE  @GradeWhere AS NVARCHAR(max)
--SET @ParmDefinitionfilterRows = N'@CountOutRows int OUTPUT'

--SET @Querynew=' select @CountOutRows = count(*) from '+@tablename    
--EXECUTE sp_executesql @Querynew, @ParmDefinitionfilterRows, @CountOutRows=@CountRows OUTPUT  
--PRINT  @CountRows 

--   IF  @CountRows=0 
--     BEGIN
--	 PRINT 'TableType Now..'+ @tabletype 
--	 SET @tabletype = replace (@tabletype,'WP_ExportBenefitSalaryScales_ar?','')
--     SET @tabletype = replace (@tabletype,'WP_ExportBenefitSalaryScales?','')   
--	 SET @GradeWhere =SUBSTRING(@tabletype, CHARINDEX('?',@tabletype,CHARINDEX('?',@tabletype)+1)+1,(CHARINDEX('?',@tabletype,CHARINDEX('?',@tabletype,CHARINDEX('?',@tabletype)+1)+1)-1)-(CHARINDEX('?',@tabletype,CHARINDEX('?',@tabletype)+1)+1)+1)
--	 EXEC ('insert into '+@tablename+' (Grade) 
--		     select  GradeName   FROM Grades
--		     where 1=1  '+ @GradeWhere)
--     END
------------------------------------------------------------------------------------------
PRINT 'Test 1'+@SelectPlanOption
	SET @SELECTsal='select  GradeNo ,Grade '+@SelectPlanOption+', Post,Remarks, [Row_Number]  from '+@tablename
	exec sp_executesql @SELECTsal			 
 END
 
 IF  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalNASUsers%'   OR  ltrim(rtrim(@tabletype)) LIKE 'WP_GetExternalNASUsers_ar%' 
BEGIN
     	DECLARE @SELECTTEMP AS nvarchar(max) =''
	   SET @SELECTTEMP = ' SELECT EmpId,Name,LogonName,UserGroup,Post,Remarks,Row_Number FROM '+ @tablename
	   	exec sp_executesql @SELECTTEMP
END
IF ltrim(rtrim(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails%'   OR  ltrim(rtrim(@tabletype)) LIKE 'WP_ExportSalaryScalesDetails_ar%' 
BEGIN
	DECLARE @SELECTCur AS nvarchar(max) =''
	DECLARE @CapStartValue AS NVARCHAR(max),@CapEndValue AS NVARCHAR(max),@CapStartValue2 AS NVARCHAR(max),@CapEndValue2 AS NVARCHAR(max),@indexlang1 AS int,@Lang1 AS CHAR(1)
	PRINT @tabletype
	SET @tabletype = replace (@tabletype,'WP_ExportSalaryScalesDetails_ar?','')
	SET @tabletype = replace (@tabletype,'WP_ExportSalaryScalesDetails?','')  

	SET @indexlang = CHARINDEX('?',@tabletype)
	SET @Lang1=substring (@tabletype,0,@indexlang)
	SET @tabletype=substring(@tabletype,@indexlang+1,len(@tabletype))
	PRINT 'Lang = '+@Lang1
	PRINT @tabletype

	SET @CapStartValue2= ISNULL(dbo.Hits_GetDCCaption('WP_ExportSalaryScalesDetails','StartValue',@Lang1),CASE WHEN @Lang1 ='A' THEN N'القيمة_المبدئية' ELSE 'Start_Value' END)
	SET @CapEndValue2 = ISNULL(dbo.Hits_GetDCCaption('WP_ExportSalaryScalesDetails','EndValue',@Lang1),CASE WHEN @Lang1 ='A' THEN N'القيمة_النهائية'ELSE  'End_Value' END)

	SET @CapStartValue = 'Start_Value'
	SET @CapEndValue = 'End_Value'

	DECLARE @SelectPaycode AS NVARCHAR(max)=''
	DECLARE @PaycodeNameDetails AS NVARCHAR(max),@PaycodeANameDetails AS NVARCHAR(max)
	,@PaycodeNoCur AS NVARCHAR(max)
	,@PaycodeNo AS INT
	SET @PaycodeNameDetails = ''
	
	
	SET @SELECTCur='DECLARE cursorDetails CURSOR for SELECT COLUMN_NAME 
	FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
	WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND COLUMN_NAME not in (''Post'',''Remarks'',''Row_Number'',''GradeNo'',''Grade'') ' 

	EXECUTE(@SELECTCur)
	OPEN cursorDetails

	FETCH next FROM cursorDetails
	INTO  @PaycodeNoCur

	WHILE @@FETCH_STATUS=0
	BEGIN
		IF SUBSTRING(@PaycodeNoCur,1,1) = 'P'
		BEGIN
			    IF @PaycodeNoCur LIKE '%'+ @CapStartValue + '%'
				BEGIN
				    SET @PaycodeNoCur = SUBSTRING(@PaycodeNoCur,2,CHARINDEX(@CapStartValue,@PaycodeNoCur)-2)
					SET @PaycodeNoCur = CAST (@PaycodeNoCur AS INT)

					SELECT @PaycodeNameDetails = CASE WHEN @Lang1 = 'A' THEN LTRIM(RTRIM(PayCodeAName)) ELSE LTRIM(RTRIM(PayCodeName)) END FROM paycode WHERE code=isnull(@PaycodeNoCur,0)

					SET @SelectPaycode=@SelectPaycode+',' + 'P'+LTRIM(RTRIM(@PaycodeNoCur))+@CapStartValue+' AS [' +@PaycodeNameDetails+'('+@CapStartValue2+')'+']'
					PRINT '@SelectPaycode start'+@SelectPaycode
				END
				 IF @PaycodeNoCur LIKE '%'+ @CapEndValue + '%'
				BEGIN
				    SET @PaycodeNoCur = SUBSTRING(@PaycodeNoCur,2,CHARINDEX(@CapEndValue,@PaycodeNoCur)-2)
					SET @PaycodeNoCur = CAST (@PaycodeNoCur AS INT)

					SELECT @PaycodeNameDetails = CASE WHEN @Lang1 = 'A' THEN LTRIM(RTRIM(PayCodeAName)) ELSE LTRIM(RTRIM(PayCodeName)) END FROM paycode WHERE code=isnull(@PaycodeNoCur,0)

					SET @SelectPaycode=@SelectPaycode+',' + 'P'+LTRIM(RTRIM(@PaycodeNoCur))+@CapEndValue+' AS [' +@PaycodeNameDetails+'('+@CapEndValue2+')'+']'
					PRINT '@SelectPaycode end'+@SelectPaycode
				END
			--END
			FETCH NEXT FROM cursorDetails
			INTO @PaycodeNoCur
		END
	END
	CLOSE cursorDetails
	DEALLOCATE cursorDetails

	SET @SELECTsal='select GradeNo ,Grade '+@SelectPaycode+', Post,Remarks, [Row_Number]   from '+@tablename
	exec sp_executesql @SELECTsal	
END

IF LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalEmpSSGroupRoles' OR  LTRIM(RTRIM(@tabletype)) LIKE 'WP_GetExternalEmpSSGroupRoles_ar'
BEGIN
	DECLARE @Rowcount AS INT = 0 , @Countstr AS nvarchar (MAX)
	SET @Countstr = ' SELECT @Rowcount = COUNT (*) FROM '+ @tablename
	exec sp_executesql @Countstr  , N' @Rowcount int OUTPUT ' , @Rowcount  OUTPUT 
	
	IF @Rowcount = 0 
	BEGIN
		DECLARE @ColumnStr AS NVARCHAR (MAX)=''
		SELECT @ColumnStr = @ColumnStr +  ' '''' as [' + (CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' THEN LTRIM(RTRIM(RoleAName))ELSE  ltrim(rtrim(RoleName)) END)  + '],'
		FROM SSRole  WHERE  (CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' THEN LTRIM(RTRIM(RoleAName))
		ELSE  ltrim(rtrim(RoleName)) END) <>  '' 
		
		SET @SELECT = 'SELECT empid as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
						THEN N'[رقم الموظف]' ELSE '[EmpId]' END ) +
						' , Name as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
						THEN N'[الاسم]' ELSE '[Name]' END )+','+@ColumnStr+
						' Post as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
						THEN N'[تحميل]' ELSE '[Post]' END )+
						',Remarks as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
						THEN N'[ملاحظات النظام]' ELSE '[Remarks]' END )+
						',[Row_Number] as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
						THEN N'[رقم الصف]' ELSE '[Row_Number]' END ) +' from '+@tablename
		EXEC (@SELECT)	
	END	
	ELSE
	BEGIN
		DECLARE @selectTable AS NVARCHAR (MAX)='' , @TblStr AS NVARCHAR (MAX)=''
		CREATE TABLE #temp ( RoleID NVARCHAR(60),RoleName NVARCHAR (60)  , RoleAName NVARCHAR (60))
		SET @SELECT = 'INSERT INTO #Temp (RoleID , RoleName , RoleAName ) SELECT COLUMN_NAME , ssrole.RoleName ,ssrole.RoleAName 
						FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns   
						INNER JOIN ssrole ON ssrole.RoleId  =  CAST (replace(rtrim(ltrim(COLUMN_NAME)),''R'','''') AS SMALLINT)
						WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME not in (''EmpId'' , ''NAME'' , ''Post'' , ''Remarks'' ,''Row_Number'') '
		PRINT @SELECT
		EXEC (@SELECT)
		PRINT 'after select'
		select * from #temp
		--select @selectTable = @selectTable + ltrim(rtrim(RoleId)) + ' as [' + (CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' THEN LTRIM(RTRIM(RoleAName))ELSE  ltrim(rtrim(RoleName)) END) +'], '  
		--FROM #temp 
		--PRINT @selectTable
		--SET @TblStr = 'SELECT empid as '+ (CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
		--				THEN N'[رقم الموظف]' ELSE '[EmpId]' END ) +
		--				' , Name as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
		--				THEN N'[الاسم]' ELSE '[Name]' END )+' , '+@selectTable+
		--               ' Post as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
		--				THEN N'[تحميل]' ELSE '[Post]' END )+
		--				',Remarks as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
		--				THEN N'[ملاحظات النظام]' ELSE '[Remarks]' END )+
		--				',[Row_Number] as '+(CASE WHEN LTRIM(RTRIM(@tabletype)) = 'WP_GetExternalEmpSSGroupRoles_ar' 
		--				THEN N'[رقم الصف]' ELSE '[Row_Number]' END ) +' from '+@tablename
		--PRINT @TblStr
		--EXEC (@TblStr)               
		
	END 
		
END

ELSE
	begin
set @str = 'EXEC [hits_importexport] 2,''' +@actualtablename+''','''+ @tablename  +''','+str(@actual)+',@formulaOutput output'

print @str
	exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
	end
-- 
-- IF ltrim(rtrim(@type))='WP_JVSetup' EXEC BatchWP_JVSetup 2,@tablename,@actual,@outstr output
-- IF ltrim(rtrim(@type))='WP_BankData' EXEC batch_BankData 2,@tablename,@actual,@outstr output
END

GO

