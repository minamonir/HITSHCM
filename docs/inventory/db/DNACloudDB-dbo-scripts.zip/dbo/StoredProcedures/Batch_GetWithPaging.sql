
CREATE     PROCEDURE [dbo].[Batch_GetWithPaging]  (
@tablename AS nvarchar(150),
@p_sort_str nvarchar(max),
@p_page_number int,
@p_batch_size int,@tabletype  nvarchar(100),@filterwhere nvarchar(max) = ' ' ,@count int OUTPUT) 

AS

SET NOCOUNT ON 
DECLARE @filterwhere2 nvarchar(max)=''
			
DECLARE @str AS nvarchar(max),@where as nvarchar(max)
DECLARE @outstr AS nvarchar(max),@actualtablename AS nvarchar(150)
SELECT DISTINCT @actualtablename= LookupSelect FROM DataDictionary 
WHERE TableName LIKE @tabletype

SET @actualtablename=CASE WHEN @actualtablename=N'' THEN NULL ELSE @actualtablename END

--added by sandy 2015-07-05
SELECT  @p_sort_str= case WHEN  ltrim(rtrim(@p_sort_str)) LIKE '%Employeeid%' AND ltrim(rtrim(@p_sort_str))  NOT LIKE '%dbo.HitsSort(Employeeid,'''')%'
 THEN 'dbo.HitsSort(Employeeid,'''')' +CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%DESC%' THEN ' DESC' ELSE '' END 
  ELSE @p_sort_str END
  ---[Batch_GetWithPaging] @tablename , 1 , 0 ,  -1 ,  'WP_BatchResult','',0
-------------------------------------------------------------------------------------------------
if ltrim(rtrim(@tabletype))= 'WP_BatchResult'   or ltrim(rtrim(@tabletype))= 'WP_INTApplyBatchPath'  or ltrim(rtrim(@tabletype))= 'WP_BatchResult_ar' OR ltrim(rtrim(@tabletype))= 'WP_ApplyBatchPath' OR ltrim(rtrim(@tabletype))= 'WP_ApplyBatchPath_ar' or ltrim(rtrim(@tabletype)) like '%WP_ManageApproveAll%' OR ltrim(rtrim(@tabletype))='WP_ApplyAssessmentBatch' OR ltrim(rtrim(@tabletype))='WP_ApplyAssessmentBatch_ar' OR ltrim(rtrim(@tabletype))='MCPayrollApprovals'
BEGIN

--if  ltrim(rtrim(@tabletype))= 'WP_ApplyBatchPath' 
	if  charindex('WP_ApplyBatchPath' ,ltrim(rtrim(@tabletype)))>0 or charindex('WP_ManageApproveAll' ,ltrim(rtrim(@tabletype)))>0  OR charindex('WP_ApplyAssessmentBatch' ,ltrim(rtrim(@tabletype)))>0 OR CHARINDEX('MCPayrollApprovals',ltrim(rtrim(@tabletype)) ) <> 0 
	begin
		SET @str=' SELECT @formulaOutput= count('+@tablename+'.Row_Number)  from '+@tablename+' where processtime is not null ' 
		
		set @where = '  ('+@tablename+'.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'+@filterwhere
		
		
		--Set @str=@str+' select * from '+@tablename+' where' + @where + ' and processtime is not null ' + ' order by '+@tablename+'.processtime desc'

 		DECLARE @time_Sort_Direction nvarchar(max)
 	
 		SET @time_Sort_Direction =( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime DESC%' THEN 'DESC'
 		WHEN  ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN  N''
 		ELSE  'DESC' END ) 
 	
		SET @p_sort_str=( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN N' '
 		ELSE @p_sort_str  END ) 

		SELECT @p_sort_str=REPLACE(@p_sort_str,'[t0].','')
		if  @p_page_number = 1
		BEGIN
	   if @tabletype NOT LIKE 'WP_ManageApproveAll%'
		begin
			Set @str=@str+'SELECT TOP ' + str(@p_batch_size) 
			+ ' * FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) where    processtime is not null ORDER BY '
			+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		end 
      ELSE IF  @tabletype LIKE 'WP_ManageApproveAllDeleg%'
        BEGIN
            IF RIGHT(@tabletype,1)='A'
        
            SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
                SSDocument.ssdocaname, ssrole.roleaname,
                [t0].DelegateFrom , [t0].DelegateTo ,                       
                        case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
                    Organization.OrganizationAName,
                     HRStatus.HRStatusAName 
                        ,[t0].Processed
                    FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
                    INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                    INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                    LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                    LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                    LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                    Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                    left join SSDocument ON [t0].SSDocNo = SSDocument.SSDocNo
                    left join ssrole on [t0].DocumentNo = ssrole.roleid
                    where    processtime is not null ORDER BY '
                +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
                ELSE 
                SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
                SSDocument.ssdocname,ssrole.rolename, 
                [t0].DelegateFrom , [t0].DelegateTo ,
                        case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
                        Organization.OrganizationName,
                        HRStatus.HRStatusName 
                        ,[t0].Processed
                    FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
                    INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                    INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                    LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                    LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                    LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                    Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                    left join SSDocument ON [t0].SSDocNo = SSDocument.SSDocNo
                    left join ssrole on [t0].DocumentNo = ssrole.roleid
                    where    processtime is not null ORDER BY '
                +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
        END
        ELSE IF  @tabletype LIKE 'WP_ManageApproveAllJobReq%'
        BEGIN
            IF RIGHT(@tabletype,1)='A'
        
            SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,              
                            Vacancies.vacancyaname,
                        case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
                    Organization.OrganizationAName,
                     HRStatus.HRStatusAName 
                        ,[t0].Processed
                    FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
                    INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                    INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                    LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                    LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                    LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                    Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                    left join Vacancies ON [t0].DocumentNo = Vacancies.VacancyNo
                    
                    where    processtime is not null ORDER BY '
                +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
                ELSE 
                SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
                    Vacancies.vacancyname,
                        case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
                        Organization.OrganizationName,
                        HRStatus.HRStatusName 
                        ,[t0].Processed
                    FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
                    INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                    INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                    LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                    LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                    LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                    Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                    left join Vacancies ON [t0].DocumentNo = Vacancies.VacancyNo
                    
                    where    processtime is not null ORDER BY '
                +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
        end
		
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllDocument%'
        BEGIN
            IF RIGHT(@tabletype,1)='A'
        
            SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
               Document.DocAName,
			   EmpDoc.issdate,
               case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
               Organization.OrganizationAName,
               HRStatus.HRStatusAName ,[t0].Processed
               FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
               INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
               INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
               LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
               LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
               LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
               Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus			   
			   LEFT JOIN EmpDoc on [t0].DocumentNo = EmpDoc.DocumentNo and [t0].EmpID = EmpDoc.Empid
			   LEFT JOIN Document on EmpDoc.docid = Document.docid
               where    processtime is not null ORDER BY '
               +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
                ELSE 
                SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
                Document.DocName,
				EmpDoc.issdate,
                case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
                Organization.OrganizationName,
                HRStatus.HRStatusName,[t0].Processed
                FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
                INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                LEFT JOIN EmpDoc on [t0].DocumentNo = EmpDoc.DocumentNo and [t0].EmpID = EmpDoc.Empid
			    LEFT JOIN Document on EmpDoc.docid = Document.docid
                where    processtime is not null ORDER BY '
                +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
        END
		
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllMisconduct%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'
		
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,				
							Mscondct.MiscondAName,EmpMscon.misdate,
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpMsDtl on [t0].EmpID = EmpMsDtl.EmpId and [t0].DocumentNo = EmpMsDtl.DocumentNo
					left join EmpMscon on [t0].EmpID = EmpMscon.EmpId and [t0].DocumentNo = EmpMscon.DocumentNo
					LEFT JOIN Mscondct on EmpMsDtl.mscode = Mscondct.mscode					
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
				ELSE 
				SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
					Mscondct.MiscondName,EmpMscon.misdate,
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpMsDtl on [t0].EmpID = EmpMsDtl.EmpId and [t0].DocumentNo = EmpMsDtl.DocumentNo
					left join EmpMscon on [t0].EmpID = EmpMscon.EmpId and [t0].DocumentNo = EmpMscon.DocumentNo
					LEFT JOIN Mscondct on EmpMsDtl.mscode = Mscondct.mscode
					
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		end

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllHRRequest%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					HRRequest.HRReqAName, EmpHRRequest.hrreqdate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpHRRequest on [t0].DocumentNo = EmpHRRequest.DocumentNo and [t0].EmpID = EmpHRRequest.Empid
					left join HRRequest on EmpHRRequest.HRReqCode = HRRequest.HRReqCode
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
					HRRequest.HRReqName, EmpHRRequest.hrreqdate,
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpHRRequest on [t0].DocumentNo = EmpHRRequest.DocumentNo and [t0].EmpID = EmpHRRequest.Empid
					left join HRRequest on EmpHRRequest.HRReqCode = HRRequest.HRReqCode
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		END

			ELSE IF  @tabletype LIKE 'WP_ManageApproveAllAppraisal%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					Appraisals.AppraisalAName, EmpAppraisal.AppraisalDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpAppraisal on [t0].DocumentNo = EmpAppraisal.DocumentNo and [t0].EmpID = EmpAppraisal.Empid
					left join Appraisals on EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						Appraisals.AppraisalName, EmpAppraisal.AppraisalDate,	
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpAppraisal on [t0].DocumentNo = EmpAppraisal.DocumentNo and [t0].EmpID = EmpAppraisal.Empid
					left join Appraisals on EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		END
		------------------ Objectives Approvals----------------
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllObjectives%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					Objectives.ObjectiveAName, Objectives.ObjectiveStartDate,Objectives.ObjectiveEndDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpObjectives on [t0].DocumentNo = EmpObjectives.ObjectiveId and [t0].EmpID = EmpObjectives.Empid
					left join Objectives on EmpObjectives.ObjectiveId = Objectives.ObjectiveId
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
			ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						Objectives.ObjectiveName, Objectives.ObjectiveStartDate,Objectives.ObjectiveEndDate,	
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpObjectives on [t0].DocumentNo = EmpObjectives.ObjectiveId and [t0].EmpID = EmpObjectives.Empid
					left join Objectives on EmpObjectives.ObjectiveId = Objectives.ObjectiveId
					where    processtime is not null ORDER BY '
				    +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		END
		
		------------------ Change of Status Approvals----------------
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllChangeOfStatus%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					ChngStat.ChgAName, EmpStatusHdr.effectiveDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpStatusHdr on [t0].DocumentNo = EmpStatusHdr.DocumentNo and [t0].EmpID = EmpStatusHdr.Empid
					left join ChngStat on EmpStatusHdr.chgcode = ChngStat.chgcode
					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
							ChngStat.ChgName, EmpStatusHdr.effectiveDate,	
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpStatusHdr on [t0].DocumentNo = EmpStatusHdr.DocumentNo and [t0].EmpID = EmpStatusHdr.Empid
					left join ChngStat on EmpStatusHdr.chgcode = ChngStat.chgcode
					where    processtime is not null ORDER BY '
				    +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		END

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllTasks%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					EmpTask.TaskAName, EmpTask.StartDate, EmpTask.DueDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTask on [t0].DocumentNo = EmpTask.DocumentNo and [t0].EmpID = EmpTask.Empid

					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						   EmpTask.TaskName, EmpTask.StartDate, EmpTask.DueDate,
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTask on [t0].DocumentNo = EmpTask.DocumentNo and [t0].EmpID = EmpTask.Empid
					where    processtime is not null ORDER BY '
				    +@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		END

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllGeoTimeKeepingUncommitted%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'
			begin
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					EmpTimeReadingsGeoUncommitted.AttendTime, EmpTimeReadingsGeoUncommitted.FlagValue, EmpTimeReadingsGeoUncommitted.ReaderValue,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTimeReadingsGeoUncommitted on [t0].DocumentNo = EmpTimeReadingsGeoUncommitted.DocumentNo and [t0].EmpID = EmpTimeReadingsGeoUncommitted.Empid

					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
			end 
			else
			begin
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
					EmpTimeReadingsGeoUncommitted.AttendTime, EmpTimeReadingsGeoUncommitted.FlagValue, EmpTimeReadingsGeoUncommitted.ReaderValue,					
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
					Organization.OrganizationName,
					 HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTimeReadingsGeoUncommitted on [t0].DocumentNo = EmpTimeReadingsGeoUncommitted.DocumentNo and [t0].EmpID = EmpTimeReadingsGeoUncommitted.Empid

					where    processtime is not null ORDER BY '
				+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
			end 

		
		END

		else
		begin
				
				Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].*,
				Profile.Name,Profile.AName,
				case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
				case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
				Organization.OrganizationName,Organization.OrganizationAName,
				HRStatus.HRStatusName ,  HRStatus.HRStatusAName ,EmpAssignment.EmployeeId 
				FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
				INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
				INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
				LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
				LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
				LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
				Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
				where    processtime is not null ORDER BY '
			+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
		end 
			PRINT @str	
		END 
		ELSE
		BEGIN
		
			DECLARE @IndexedSort AS nvarchar(max)
			
			SET @IndexedSort=replace(@p_sort_str,'0','1')

	if @tabletype NOT LIKE 'WP_ManageApproveAll%'
		begin
			Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + ' *
			FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
			WHERE NOT (EXISTS(
				SELECT NULL AS [EMPTY]
				FROM (
				SELECT TOP '+ str(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
				FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
				where processtime is not null
				ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
				') AS [t2]
			WHERE [t0].[row_number] = [t2].[row_number]
			)) and   processtime is not null
			ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
			  END
            ELSE IF  @tabletype LIKE 'WP_ManageApproveAllDeleg%'
            BEGIN
                IF RIGHT(@tabletype,1)='A'
                Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
                SSDocument.ssdocaname, ssrole.roleaname,
                [t0].DelegateFrom , [t0].DelegateTo ,                       
                        case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
                        Organization.OrganizationAName,
                          HRStatus.HRStatusAName 
                        ,[t0].Processed
                        FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
                        INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                        INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                        LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                        LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                        LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                        Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                        left join SSDocument ON [t0].SSDocNo = SSDocument.SSDocNo
                        left join ssrole on [t0].DocumentNo = ssrole.roleid
                        WHERE NOT (EXISTS(
                        SELECT NULL AS [EMPTY]
                        FROM (
                            SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
                            FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
                            where processtime is not null
                            ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
                            ') AS [t2]
                        WHERE [t0].[row_number] = [t2].[row_number]
                )) and   processtime is not null
                ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
                ELSE 
                Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
                SSDocument.ssdocname,ssrole.rolename, 
                [t0].DelegateFrom , [t0].DelegateTo ,
                        case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
                        Organization.OrganizationName,
                        HRStatus.HRStatusName 
                        ,[t0].Processed
                        FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
                        INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                        INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                        LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                        LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                        LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                        Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                        left join SSDocument ON [t0].SSDocNo = SSDocument.SSDocNo
                        left join ssrole on [t0].DocumentNo = ssrole.roleid
                        WHERE NOT (EXISTS(
                        SELECT NULL AS [EMPTY]
                        FROM (
                            SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
                            FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
                            where processtime is not null
                            ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
                            ') AS [t2]
                        WHERE [t0].[row_number] = [t2].[row_number]
                )) and   processtime is not null
                ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
            END
            ELSE IF  @tabletype LIKE 'WP_ManageApproveAllJobReq%'
		 BEGIN
            IF RIGHT(@tabletype,1)='A'
        
            Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
                                Vacancies.vacancyaname,
                        case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
                        Organization.OrganizationAName,
                          HRStatus.HRStatusAName 
                        ,[t0].Processed
                        FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
                        INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                        INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                        LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                        LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                        LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                        Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                        left join Vacancies ON [t0].DocumentNo = Vacancies.VacancyNo 
                        
                        WHERE NOT (EXISTS(
                        SELECT NULL AS [EMPTY]
                        FROM (
                            SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
                            FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
                            where processtime is not null
                            ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
                            ') AS [t2]
                        WHERE [t0].[row_number] = [t2].[row_number]
                )) and   processtime is not null
                ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
                ELSE 
                Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
                        Vacancies.vacancyname,
                        case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
                        Organization.OrganizationName,
                        HRStatus.HRStatusName 
                        ,[t0].Processed
                        FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
                        INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                        INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                        LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                        LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                        LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                        Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                        left join Vacancies ON [t0].DocumentNo = Vacancies.VacancyNo 
                        
                        WHERE NOT (EXISTS(
                        SELECT NULL AS [EMPTY]
                        FROM (
                            SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
                            FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
                            where processtime is not null
                            ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
                            ') AS [t2]
                        WHERE [t0].[row_number] = [t2].[row_number]
                )) and   processtime is not null
                ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				end 

		 ELSE IF  @tabletype LIKE 'WP_ManageApproveAllDocument%'
		 BEGIN
            IF RIGHT(@tabletype,1)='A'
        
            SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
               Document.DocAName,  
			   EmpDoc.issdate,
               case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
               Organization.OrganizationAName,
               HRStatus.HRStatusAName ,[t0].Processed
               FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
               INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
               INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
               LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
               LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
               LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
               Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
               LEFT JOIN EmpDoc on [t0].DocumentNo = EmpDoc.DocumentNo and [t0].EmpID = EmpDoc.Empid
			   LEFT JOIN Document on EmpDoc.docid = Document.docid
                        
               WHERE NOT (EXISTS(
               SELECT NULL AS [EMPTY]
               FROM (
                   SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
                   FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
                   where processtime is not null
                   ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+') AS [t2]
                   WHERE [t0].[row_number] = [t2].[row_number])) and   processtime is not null
                   ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
                ELSE 
               SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
                Document.DocName,
				EmpDoc.issdate,
                case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
                Organization.OrganizationName,
                HRStatus.HRStatusName,[t0].Processed
                FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
                INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
                INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
                LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
                LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
                LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
                Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
                LEFT JOIN EmpDoc on [t0].DocumentNo = EmpDoc.DocumentNo and [t0].EmpID = EmpDoc.Empid
			    LEFT JOIN Document on EmpDoc.docid = Document.docid
                        
               WHERE NOT (EXISTS(
               SELECT NULL AS [EMPTY]
               FROM (
                   SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
                   FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
                   where processtime is not null
                   ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
                   ') AS [t2]
               WHERE [t0].[row_number] = [t2].[row_number])) and processtime is not null
               ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				end 

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllMisconduct%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'
		
			Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
								Mscondct.MiscondAName,EmpMscon.misdate,
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpMsDtl on [t0].EmpID = EmpMsDtl.EmpId and [t0].DocumentNo = EmpMsDtl.DocumentNo
					left join EmpMscon on [t0].EmpID = EmpMscon.EmpId and [t0].DocumentNo = EmpMscon.DocumentNo
					LEFT JOIN Mscondct on EmpMsDtl.mscode = Mscondct.mscode
						
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				ELSE 
				Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						Mscondct.MiscondName,EmpMscon.misdate,
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpMsDtl on [t0].EmpID = EmpMsDtl.EmpId and [t0].DocumentNo = EmpMsDtl.DocumentNo
				    left join EmpMscon on [t0].EmpID = EmpMscon.EmpId and [t0].DocumentNo = EmpMscon.DocumentNo
					LEFT JOIN Mscondct on EmpMsDtl.mscode = Mscondct.mscode
						
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				end

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllHRRequest%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'
		
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					HRRequest.HRReqAName, EmpHRRequest.hrreqdate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpHRRequest on [t0].DocumentNo = EmpHRRequest.DocumentNo and [t0].EmpID = EmpHRRequest.Empid
					left join HRRequest on EmpHRRequest.HRReqCode = HRRequest.HRReqCode

						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
		ELSE 
				SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					HRRequest.HRReqName, EmpHRRequest.hrreqdate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpHRRequest on [t0].DocumentNo = EmpHRRequest.DocumentNo and [t0].EmpID = EmpHRRequest.Empid
					left join HRRequest on EmpHRRequest.HRReqCode = HRRequest.HRReqCode
						
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
		end

				-----------------------------------------------	--------------------------------------------------------------------------
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllAppraisal%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					Appraisals.AppraisalAName, EmpAppraisal.AppraisalDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpAppraisal on [t0].DocumentNo = EmpAppraisal.DocumentNo and [t0].EmpID = EmpAppraisal.Empid
					left join Appraisals on EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						Appraisals.AppraisalName, EmpAppraisal.AppraisalDate,	
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpAppraisal on [t0].DocumentNo = EmpAppraisal.DocumentNo and [t0].EmpID = EmpAppraisal.Empid
					left join Appraisals on EmpAppraisal.AppraisalNo = Appraisals.AppraisalNo
					WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
		END
		------------------ Objectives Approvals----------------
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllObjectives%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					Objectives.ObjectiveAName, Objectives.ObjectiveStartDate,Objectives.ObjectiveEndDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpObjectives on [t0].DocumentNo = EmpObjectives.ObjectiveId and [t0].EmpID = EmpObjectives.Empid
					left join Objectives on EmpObjectives.ObjectiveId = Objectives.ObjectiveId
					WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						Objectives.ObjectiveName, Objectives.ObjectiveStartDate,Objectives.ObjectiveEndDate,	
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpObjectives on [t0].DocumentNo = EmpObjectives.ObjectiveId and [t0].EmpID = EmpObjectives.Empid
					left join Objectives on EmpObjectives.ObjectiveId = Objectives.ObjectiveId
					WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
		END


		------------------ Change of Status Approvals----------------
		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllChangeOfStatus%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					ChngStat.ChgAName, EmpStatusHdr.effectiveDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpStatusHdr on [t0].DocumentNo = EmpStatusHdr.DocumentNo and [t0].EmpID = EmpStatusHdr.Empid
					left join ChngStat on EmpStatusHdr.chgcode = ChngStat.chgcode
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
							ChngStat.ChgName, EmpStatusHdr.effectiveDate,	
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpStatusHdr on [t0].DocumentNo = EmpStatusHdr.DocumentNo and [t0].EmpID = EmpStatusHdr.Empid
					left join ChngStat on EmpStatusHdr.chgcode = ChngStat.chgcode
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
		END

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllTasks%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'

			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					EmpTask.TaskAName, EmpTask.StartDate, EmpTask.DueDate,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTask on [t0].DocumentNo = EmpTask.DocumentNo and [t0].EmpID = EmpTask.Empid

						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				ELSE 
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
						   EmpTask.TaskName, EmpTask.StartDate, EmpTask.DueDate,
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
						Organization.OrganizationName,
						HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTask on [t0].DocumentNo = EmpTask.DocumentNo and [t0].EmpID = EmpTask.Empid
						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
		END

		ELSE IF  @tabletype LIKE 'WP_ManageApproveAllGeoTimeKeepingUncommitted%'
		BEGIN
			IF RIGHT(@tabletype,1)='A'
			begin
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.AName,
					EmpTimeReadingsGeoUncommitted.AttendTime, EmpTimeReadingsGeoUncommitted.FlagValue, EmpTimeReadingsGeoUncommitted.ReaderValue,					
						case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationAName,
					 HRStatus.HRStatusAName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTimeReadingsGeoUncommitted on [t0].DocumentNo = EmpTimeReadingsGeoUncommitted.DocumentNo and [t0].EmpID = EmpTimeReadingsGeoUncommitted.Empid
	WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
			end 
			else
			begin
			SET @str=@str+'SELECT TOP ' + str(@p_batch_size) + '[t0].ProcessTime , EmpAssignment.EmployeeId,Profile.Name,
					EmpTimeReadingsGeoUncommitted.AttendTime, EmpTimeReadingsGeoUncommitted.FlagValue, EmpTimeReadingsGeoUncommitted.ReaderValue,					
						case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
					Organization.OrganizationName,
					 HRStatus.HRStatusName 
						,[t0].Processed
					FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) 
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					LEFT JOIN EmpTimeReadingsGeoUncommitted on [t0].DocumentNo = EmpTimeReadingsGeoUncommitted.DocumentNo and [t0].EmpID = EmpTimeReadingsGeoUncommitted.Empid

						WHERE NOT (EXISTS(
						SELECT NULL AS [EMPTY]
						FROM (
							SELECT TOP '+ STR(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
							FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
							where processtime is not null
							ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
							') AS [t2]
						WHERE [t0].[row_number] = [t2].[row_number]
				)) and   processtime is not null

				ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
			end 

		
		END


		----------------------------------------------------------------------------------------------------------------------


		else
				BEGIN
				
					Set @str=@str+'SELECT TOP ' + str(@p_batch_size) + ' [t0].* , 
					Profile.Name,Profile.AName,
					case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName,
					case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName,
					Organization.OrganizationName,Organization.OrganizationAName,
					HRStatus.HRStatusName ,  HRStatus.HRStatusAName ,EmpAssignment.EmployeeId
					FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
					INNER JOIN EmpAssignment with (nolock) ON [t0].EmpID = EmpAssignment.EmpId
					INNER JOIN Profile with (nolock) ON EmpAssignment.EmpId = Profile.ProfileId
					LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization
					LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.job
					LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo
					Left join HRStatus on HRStatus.HRStatus=EmpAssignment.HRStatus
					
					WHERE NOT (EXISTS(
					SELECT NULL AS [EMPTY]
					FROM (
						SELECT TOP '+ str(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
						FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
						where processtime is not null
						ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
						') AS [t2]
					WHERE [t0].[row_number] = [t2].[row_number]
			)) and   processtime is not null

			ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				end

			PRINT @str
		END
	END
	----------------------//WP_INTApplyBatchPath
	Else if charindex('WP_INTApplyBatchPath' ,ltrim(rtrim(@tabletype)))>0
	begin
	set @filterwhere=case when @filterwhere='' then '  1=1 ' else  @filterwhere end
	SET @str=' SELECT @formulaOutput= count('+@tablename+'.Row_Number)  from '+@tablename+' where processtime is not null and ' +@filterwhere 

 		SET @time_Sort_Direction =( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime DESC%' THEN 'DESC'
 		WHEN  ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN  N''
 		ELSE  'DESC' END ) 
 	
		SET @p_sort_str=( CASE WHEN ltrim(rtrim(@p_sort_str)) LIKE '%processtime%' THEN N' '
 		ELSE @p_sort_str  END ) 
		if  @p_page_number = 1
		BEGIN
			Set @str=@str+' SELECT TOP ' + str(@p_batch_size) 
			+ ' * FROM ' + @tablename+' AS [t0]  WITH  (NOLOCK) where  processtime is not null and '+@filterwhere+' ORDER BY '
			+@p_sort_str+'[t0].[processtime] ' +@time_Sort_Direction
			PRINT @str	
		END 
		ELSE
		BEGIN

			SET @IndexedSort=replace(@p_sort_str,'0','1')
			Set @str=@str+' SELECT TOP ' + str(@p_batch_size) + ' *
			FROM ' + @tablename+'  AS [t0] WITH  (NOLOCK)
			WHERE  '+ @filterwhere +' and NOT (EXISTS(
				SELECT NULL AS [EMPTY]
				FROM (
				SELECT TOP '+ str(@p_batch_size * (@p_page_number-1)) +' [t1].[Row_Number]
				FROM '+@tablename+'AS [t1]  WITH  (NOLOCK)
				where   processtime is not null and '+@filterwhere+
				' ORDER BY '+ @IndexedSort+' [t1].[processtime] '+@time_Sort_Direction+
				') AS [t2]
			WHERE  [t0].[row_number] = [t2].[row_number]
			))  and   processtime is not null and '+@filterwhere+
			' ORDER BY '+@p_sort_str+' [t0].[processtime] '+@time_Sort_Direction 
				
			PRINT @str
		END
	end 
	else
	begin 
		IF @p_page_number=0 AND @p_batch_size=-1 AND @tabletype='WP_BatchResult'
		BEGIN
			SET @str=' SELECT  * FROM '+@tableName +'ORDER BY '+@p_sort_str
			PRINT @str 
			PRINT 'Hi'
		END 
		ELSE
		BEGIN 
					SET @str=' SELECT @formulaOutput= count('+@tablename+'.Row_Number)  from '+@tablename+' where 1=1 '+ @filterwhere 
			--set @where = ' ('+@tablename+'.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'
			--Set @str=@str+' select * from '+@tablename+' where' + @where + ' order by '+@p_sort_str
			IF ltrim(rtrim(@p_sort_str)) =''
			BEGIN
				SET @str=@str+' SELECT top '+str(@p_batch_size)+' * FROM '+@tableName +
						' WHERE ROW_NUMBER NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER FROM '+@tableName + 'where 1=1 '+@filterwhere+') '+ @filterwhere
			END
			ELSE
			BEGIN
				SET @str=@str+' SELECT top '+str(@p_batch_size)+' * FROM '+@tableName +
				' WHERE ROW_NUMBER  NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER FROM '+@tableName + 'where 1=1 '+@filterwhere+' order by '+@p_sort_str+') '+ @filterwhere
				+ ' order by '+@p_sort_str
			END
		END
	END 
	print @str

	exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
end 
ELSE 
IF CHARINDEX('WFDueAdjustmentManage',ltrim(rtrim(@tabletype)) ) <> 0 
BEGIN

--WAITFOR DELAY '00:00:02'

Set @str='SELECT ProcessTime
,EmpAssignment.EmployeeId
,Profile.Name
,VacationDue.VacDueName
,VacDueDate
,VacDueDays
,WFDocument.StartDate
,ProcessMsg
FROM ' + @tablename+' AS t0
INNER JOIN EmpAssignment ON EmpAssignment.EmpID = t0.EmpID
INNER JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpID
INNER JOIN WFDocument ON t0.EmpID=WFDocument.EmpID AND t0.DocumentNo= WFDocument.DocumentNo AND t0.SSDocNo  = WFDocument.SSDocNo
INNER JOIN EmpVacationDue ON  t0.EmpID = EmpVacationDue.EmpId AND t0.DocumentNo = EmpVacationDue.DocumentNo 
INNER JOIN VacationDue ON EmpVacationDue.VacDueCode = VacationDue.VacDueCode
Order by ErrorCode desc, ProcessTime desc '
PRINT @str
EXEC(@str)
END

--ELSE
--IF CHARINDEX('MCPayrollApprovals',ltrim(rtrim(@tabletype)) ) <> 0 
--BEGIN

----WAITFOR DELAY '00:00:02'
--Set @str='SELECT @formulaOutput= count('+@tablename+'.Row_Number) FROM '+@tableName
--exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
--Set @str='SELECT ProcessTime 
--,EmployeeId
--,Name
--,AName
--,Organization, OrganizationName , OrganizationAName 
--, Job, JobName , JobAName , Hrstatus , HrstatusName , HrstatusaName
--,processed 
--from '+@tablename+' as [t0]
--where ([t0].Row_Number between '+ str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +') 
--   order by  '+@p_sort_str 
--PRINT @str
--exec (@str)
--END
else
BEGIN

	IF @p_page_number > 0 and @p_batch_size >= 0 
	BEGIN
		IF ltrim(rtrim(@tablename))<>N''
		BEGIN
	
			---hena
			------------------------create table dynamically without select in to------------
			DECLARE @SelectStr AS NVARCHAR(max)
			DECLARE @tableStr AS NVARCHAR(max)

			--SELECT @tableStr=SUBSTRING(@tableName,CHARINDEX('.',@tableName,CHARINDEX('dbo.',@tableName,0))+1,LEN(@tableName))
			--SELECT @tableStr=REPLACE(@tableStr,'[','')
			--SELECT @tableStr=REPLACE(@tableStr,']','')
			set @tableStr=parsename(@tablename,1)

			SET @SelectStr='select Column_Name ,Data_Type + case when CHARACTER_MAXIMUM_LENGTH is not null then case when CHARACTER_MAXIMUM_LENGTH = -1 then ''(Max)'' else ''(''+ltrim(rtrim(str(CHARACTER_MAXIMUM_LENGTH)))+'')'' end else case when Data_Type=''Numeric'' then ''(''+ltrim(rtrim(str(NUMERIC_PRECISION)))+'',''+ltrim(rtrim(str(NUMERIC_SCALE))) +'')'' else N'''' end end   from '+ parsename(@tablename,3)+'.INFORMATION_SCHEMA.Columns' 
			    +' WHERE ' +parsename(@tablename,3)+'.INFORMATION_SCHEMA.Columns.Table_Name' +'='''+parsename(@tablename,1)+''' and ltrim(rtrim( '+parsename(@tablename,3)+'.INFORMATION_SCHEMA.Columns.Column_Name))' +'<>''Row_Number'''

			PRINT @SelectStr
			
					declare @colname  NVARCHAR (500),@datetype NVARCHAR(500),@temptable NVARCHAR(MAX),@columnsStr AS NVARCHAR(max)
						 
			SET @columnsStr=N''	
			SET @temptable=N' '

			exec('DECLARE Temp_cursor CURSOR FOR '+@SelectStr)

			OPEN Temp_cursor
			FETCH NEXT FROM Temp_cursor
			INTO @colname,@Datetype
			WHILE @@FETCH_STATUS = 0 
			BEGIN

				
	IF @tabletype like N'%WP_GetExternalPayrollfromExternalSystem%' OR @tabletype LIKE N'%WP_GetExternalDataFile%'
				BEGIN
				select @temptable=@temptable +'['+@colname+']'+N' '+@datetype+ ','  
				SELECT @columnsStr=@columnsStr + ',['+@colname+']'
				END
				ELSE 
				BEGIN
				select @temptable=@temptable +@colname+N' '+@datetype+ ','  
				SELECT @columnsStr=@columnsStr + ','+@colname
				END
				FETCH NEXT FROM Temp_cursor
			INTO @colname,@Datetype

			END
			CLOSE Temp_cursor;
			DEALLOCATE Temp_cursor;

			SET @columnsStr=SUBSTRING(@columnsStr,2,LEN(@columnsStr))
			set @temptable='create table #EndResultPagging('+@temptable+'[Row_Number] Int identity(1,1))'

			

			-------------------------------------------------------------------------------------------------------------------
			IF charindex( 'WP_WFVacationManageAll',ltrim(rtrim(@tabletype)) ) <> 0 OR charindex( 'WP_WFBenefitManageAll',ltrim(rtrim(@tabletype)) ) <> 0
			BEGIN
				SET @str=@temptable+N' '+'insert into #EndResultPagging SELECT * from '+@tablename + ' WHERE processmessage IS NULL '
			END
			ELSE
			BEGIN
				
				SET @str=@temptable+N' '+'insert into #EndResultPagging SELECT '+ @columnsStr+'  from '+@tablename
			END
			PRINT 11111
			PRINT @str
			PRINT 22222
			
			
		END	
		ELSE
		begin
			print @tablename
		
			--if ltrim(rtrim(@tabletype))='WP_JVSetup' SET @str ='exec [BatchWP_JVSetup] 4,'''+@tablename+''',0,'''+@filterwhere+''', @formulaOutput output'
			--else
			set @str = 'EXEC [hits_importexport]  4,''' +@actualtablename+''','''+ @tablename  +''',0,@formulaOutput output'

			exec sp_executesql @str , N' @formulaOutput nvarchar(max) OUTPUT', @formulaOutput=@outstr OUTPUT
			PRINT @str
			-- 
			-- if ltrim(rtrim(@type))='WP_JVSetup' exec batch_JV 4,@tablename,0, @outstr output
			-- if ltrim(rtrim(@type))='WP_BankData' exec batch_BankData 4,@tablename,0, @outstr output
			SET @str=@outstr
		END

		DECLARE @col AS NVARCHAR(50),@checkcoltype AS NVARCHAR(1000),@coloutput AS SMALLINT,@isnumeric AS SMALLINT,@desc AS NVARCHAR(5)

		IF charindex( 'WP_WFVacationManageAll',ltrim(rtrim(@tabletype)) ) <> 0 
		BEGIN
		print '00000'
			SET @filterwhere2=@filterwhere
			SET @filterwhere2 = REPLACE (@filterwhere2,'EMPASSIGNMENT','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'PROFILE','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'VACATION','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'EMPVACAT','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'WFDOCUMENT','#EndResultPagging')
			PRINT 'WFVacationManageAll'
			print @filterwhere2
			DECLARE @StartIndex_val AS INT, @RoleProfileid_val as int , @tabletype_val NVARCHAR(max)

			SET @StartIndex_val=CHARINDEX('$',@tabletype)
			SET @tabletype_val = substring(@tabletype,0,@StartIndex_val)
			SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

			SET @StartIndex_val=CHARINDEX('$',@tabletype)
			SET @RoleProfileid_val = substring(@tabletype,0,@StartIndex_val)
			SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

			SET @str=@str+' SELECT @formulaOutput= count(#EndResultPagging.Row_Number)  from #EndResultPagging' 
			+' WHERE (1=1) ' + @filterwhere2
			
			SELECT @col=@p_sort_str,@checkcoltype=N'',@coloutput=0,@isnumeric=0
			
			SelecT @col=replace(@col,' desc',''),@desc=CASE WHEN @p_sort_str LIKE '% desc%' THEN ' desc' ELSE '' END
			PRINT @col
			PRINT @desc
			IF @p_sort_str<>N'' and charindex('row_number',@p_sort_str)=0 AND @tablename<>''
			BEGIN
				SET @checkcoltype=' SELECT @coloutput= min(ISNUMERIC(isnull('+@col+',0)))  from '+@tablename+'' 
				exec sp_executesql @checkcoltype , N' @coloutput int OUTPUT', @coloutput=@isnumeric OUTPUT
				PRINT @checkcoltype
				PRINT @isnumeric
			END
			else
			BEGIN
				SET @p_sort_str=CASE WHEN @p_sort_str='' THEN '#EndResultPagging.ROW_NUMBER ' ELSE @p_sort_str END
				PRINT @p_sort_str
			END
			SET @p_sort_str=REPLACE (@p_sort_str,'Employeeid','#EndResultPagging.Employeeid')
			PRINT @p_sort_str
			SET @str=@str+' SELECT  top '+str(@p_batch_size)
			+' #EndResultPagging.EmployeeId'
			+' ,#EndResultPagging.EmpID'
			+' ,#EndResultPagging.DocumentNo'
			+' ,#EndResultPagging.SSDocNo'
			+' ,#EndResultPagging.StartDate'
			+' ,#EndResultPagging.EndDate'
			+' ,#EndResultPagging.Expired'
			+' ,#EndResultPagging.EnterDate'
			+' ,#EndResultPagging.EnterBy'
			+' ,#EndResultPagging.ApprovalStatusApp'
			+' ,#EndResultPagging.ApprovalStatusRej'
			+' ,#EndResultPagging.ActionReason'
			+' ,#EndResultPagging.RowNum'
			+' ,#EndResultPagging.Name'
			+' ,#EndResultPagging.AName'
			+' ,#EndResultPagging.vaccode'
			+' ,#EndResultPagging.VacationName'
			+' ,#EndResultPagging.VacationAName'
			+' ,#EndResultPagging.FromDate'
			+' ,#EndResultPagging.ToDate '
			+' ,case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName'
			+' ,case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName'
			+' ,OrganizationName'
			+' ,OrganizationAName'
			+' ,HireDate'
			+' ,SSDocName'
			+' ,SSDocAName'
			+' ,SSDocExpire'
			+' ,dbo.VacTakenDays(EmpAssignment.EmpID, #EndResultPagging.FromDate, #EndResultPagging.ToDate, #EndResultPagging.VacCode,#EndResultPagging.DocumentNo,EmpVacat.PartDayFrom,EmpVacat.PartDayTo) AS numberofdays'
			+' ,''SSPrvDetails.aspx?id=''+ ltrim(rtrim(str(#EndResultPagging.EmpID)))+''&doc=''+ltrim(rtrim(str(#EndResultPagging.DocumentNo))) +''&ssdocno=''+ltrim(rtrim(str(#EndResultPagging.SSDocno)))+''&rep=''+ltrim(rtrim(str(SSDocument.SSReportNo))) +''&wftype=3''  as url'
			+' ,''SSPrvDetails_ar.aspx?id=''+ ltrim(rtrim(str(#EndResultPagging.EmpID)))+''&doc=''+ltrim(rtrim(str(#EndResultPagging.DocumentNo))) +''&ssdocno=''+ltrim(rtrim(str(#EndResultPagging.SSDocno)))+''&rep=''+ltrim(rtrim(str(SSDocument.SSReportNo))) +''&wftype=3''  as aurl'
			+' ,dbo.get_delegation(EmpAssignment.EmpID,'+str(@RoleProfileid_val)+', #EndResultPagging.ssdocno,''E'',#EndResultPagging.DocumentNo) as onbehaveof'
			+' ,dbo.get_delegation(EmpAssignment.EmpID,'+str(@RoleProfileid_val)+', #EndResultPagging.ssdocno,''A'',#EndResultPagging.DocumentNo) as Aonbehaveof'
			+' ,#EndResultPagging.Row_Number'
			+' FROM #EndResultPagging '
			+' LEFT JOIN EmpAssignment  ON #EndResultPagging.EmpID = EmpAssignment.EmpId'
			+' INNER JOIN SSDocument ON #EndResultPagging.SSDocNo = SSDocument.SSDocNo'
			+' INNER JOIN EmpVacat ON EmpVacat.EmpId = #EndResultPagging.EmpId AND EmpVacat.DocumentNo = #EndResultPagging.DocumentNo'
			+' INNER JOIN Vacation ON EmpVacat.VacCode = Vacation.vaccode '
			+' INNER JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId '
			+' LEFT OUTER JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup'
			+' LEFT OUTER JOIN Organization ON EmpAssignment.Organization = Organization.Organization'
			+' LEFT OUTER JOIN Jobs ON EmpAssignment.Job = Jobs.job'
			+' LEFT OUTER JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo '
			+' WHERE #EndResultPagging.ROW_NUMBER NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER '
			+' FROM #EndResultPagging '
			+' WHERE (1=1) ' + @filterwhere2
			+' order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
			+ ') ' + @filterwhere2
			+' order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
			
			SET @str=@str+' drop table #EndResultPagging'
			print @str
			exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
		END
		ELSE IF charindex( 'WP_WFBenefitManageAll',ltrim(rtrim(@tabletype)) ) <> 0 
				BEGIN
				
			SET @filterwhere2=@filterwhere
			SET @filterwhere2 = REPLACE (@filterwhere2,'EMPASSIGNMENT','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'PROFILE','#EndResultPagging')
			--SET @filterwhere2 = REPLACE (@filterwhere2,'VACATION','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'Empbenefit','#EndResultPagging')
			SET @filterwhere2 = REPLACE (@filterwhere2,'WFDOCUMENT','#EndResultPagging')
			PRINT 'WPWFBenefitManageAll'
			
			--DECLARE @StartIndex_val AS INT, @RoleProfileid_val as int , @tabletype_val NVARCHAR(max)

			SET @StartIndex_val=CHARINDEX('$',@tabletype)
			SET @tabletype_val = substring(@tabletype,0,@StartIndex_val)
			SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

			SET @StartIndex_val=CHARINDEX('$',@tabletype)
			SET @RoleProfileid_val = substring(@tabletype,0,@StartIndex_val)
			SET @TableType=substring (@tabletype,@StartIndex_val+1,len(@tabletype))

			SET @str=@str+' SELECT @formulaOutput= count(#EndResultPagging.Row_Number)  from #EndResultPagging' 
			+' WHERE (1=1) ' + @filterwhere2
			
			SELECT @col=@p_sort_str,@checkcoltype=N'',@coloutput=0,@isnumeric=0
			
			SelecT @col=replace(@col,' desc',''),@desc=CASE WHEN @p_sort_str LIKE '% desc%' THEN ' desc' ELSE '' END
			PRINT @col
			PRINT @desc
			IF @p_sort_str<>N'' and charindex('row_number',@p_sort_str)=0 AND @tablename<>''
			BEGIN
				SET @checkcoltype=' SELECT @coloutput= min(ISNUMERIC(isnull('+@col+',0)))  from '+@tablename+'' 
				exec sp_executesql @checkcoltype , N' @coloutput int OUTPUT', @coloutput=@isnumeric OUTPUT
				PRINT @checkcoltype
				PRINT @isnumeric
			END
			else
			BEGIN
				SET @p_sort_str=CASE WHEN @p_sort_str='' THEN '#EndResultPagging.ROW_NUMBER ' ELSE @p_sort_str END
				PRINT @p_sort_str
			END
			SET @p_sort_str=REPLACE (@p_sort_str,'Employeeid','#EndResultPagging.Employeeid')
			PRINT @p_sort_str
			SET @str=@str+' SELECT  top '+str(@p_batch_size)
			+' #EndResultPagging.EmployeeId'
			+' ,#EndResultPagging.EmpID'
			+' ,#EndResultPagging.DocumentNo'
			+' ,#EndResultPagging.SSDocNo'
			+' ,#EndResultPagging.StartDate'
			+' ,#EndResultPagging.EndDate'
			+' ,#EndResultPagging.Expired'
			+' ,#EndResultPagging.EnterDate'
			+' ,#EndResultPagging.EnterBy'
			+' ,#EndResultPagging.ApprovalStatusApp'
			+' ,#EndResultPagging.ApprovalStatusRej'
			+' ,#EndResultPagging.ActionReason'
			+' ,#EndResultPagging.RowNum'
			+' ,#EndResultPagging.Name'
			+' ,#EndResultPagging.AName'
			+' ,#EndResultPagging.PlanNo'
			+' ,#EndResultPagging.OptionNo'
			+' ,#EndResultPagging.PlanName'
			+' ,#EndResultPagging.PlanAName'
			+' ,#EndResultPagging.OptionName'
			+' ,#EndResultPagging.OptionAName'
			+' ,#EndResultPagging.CurName'
			+' ,#EndResultPagging.CurAName ' 
			+' ,#EndResultPagging.EnrollDate '
			+' ,#EndResultPagging.Closed '
			+' ,case when EmpAssignment.positionno is null then jobs.JobName else positions.PositionName end as JobName'
			+' ,case when EmpAssignment.positionno is null then jobs.JobAName else positions.PositionAName end as JobAName'
			+' ,OrganizationName'
			+' ,OrganizationAName'
			+' ,HireDate'
			+' ,SSDocName'
			+' ,SSDocAName'
			+' ,SSDocExpire'
			+' ,''SSPrvDetails.aspx?id=''+ ltrim(rtrim(str(#EndResultPagging.EmpID)))+''&doc=''+ltrim(rtrim(str(#EndResultPagging.DocumentNo))) +''&ssdocno=''+ltrim(rtrim(str(#EndResultPagging.SSDocno)))+''&rep=''+ltrim(rtrim(str(SSDocument.SSReportNo))) +''&wftype=7''  as url'
			+' ,''SSPrvDetails_ar.aspx?id=''+ ltrim(rtrim(str(#EndResultPagging.EmpID)))+''&doc=''+ltrim(rtrim(str(#EndResultPagging.DocumentNo))) +''&ssdocno=''+ltrim(rtrim(str(#EndResultPagging.SSDocno)))+''&rep=''+ltrim(rtrim(str(SSDocument.SSReportNo))) +''&wftype=7''  as aurl'
			+' ,dbo.get_delegation(EmpAssignment.EmpID,'+str(@RoleProfileid_val)+', #EndResultPagging.ssdocno,''E'',#EndResultPagging.DocumentNo) as onbehaveof'
			+' ,dbo.get_delegation(EmpAssignment.EmpID,'+str(@RoleProfileid_val)+', #EndResultPagging.ssdocno,''A'',#EndResultPagging.DocumentNo) as Aonbehaveof'
			+' ,#EndResultPagging.Row_Number'
			+' FROM #EndResultPagging '
			+' LEFT JOIN EmpAssignment  ON #EndResultPagging.EmpID = EmpAssignment.EmpId'
			+' INNER JOIN SSDocument ON #EndResultPagging.SSDocNo = SSDocument.SSDocNo'
			+' INNER JOIN Empbenefit ON Empbenefit.EmpId = #EndResultPagging.EmpId AND Empbenefit.DocumentNo = #EndResultPagging.DocumentNo'
			+' INNER JOIN BenefitOptions ON BenefitOptions.OptionNo = EmpBenefit.OptionNo  '
			+' INNER JOIN BenefitPlans ON BenefitPlans.PlanNo = EmpBenefit.PlanNo  '
			+' INNER JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId '
			+' LEFT OUTER JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup'
			+' LEFT OUTER JOIN Organization ON EmpAssignment.Organization = Organization.Organization'
			+' LEFT OUTER JOIN Jobs ON EmpAssignment.Job = Jobs.job'
			+' LEFT OUTER JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo '
			+' WHERE #EndResultPagging.ROW_NUMBER NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER '
			+' FROM #EndResultPagging '
			+' WHERE (1=1) ' + @filterwhere2
			+' order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
			+ ') ' + @filterwhere2
			+' order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
			
			SET @str=@str+' drop table #EndResultPagging'
			print @str
			exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
		END
		ELSE
        BEGIN
		
			PRINT  @str
			SET @str=@str+' SELECT @formulaOutput= count(#EndResultPagging.Row_Number)  from #EndResultPagging' 
			--set @where = ' (#EndResultPagging.Row_Number between '+str(@p_batch_size * (@p_page_number-1) +1)+ ' and '+ str(@p_batch_size * @p_page_number) +')'
			--Set @str=@str+' select * from #EndResultPagging where' + @where +' order by #EndResultPagging.Row_Number'

			SELECT @col=@p_sort_str,@checkcoltype=N'',@coloutput=0,@isnumeric=0
			
			SelecT @col=replace(@col,' desc',''),@desc=CASE WHEN @p_sort_str LIKE '% desc%' THEN ' desc' ELSE '' END
			PRINT @col
			PRINT @desc
			IF @p_sort_str<>N'' and charindex('row_number',@p_sort_str)=0 AND @tablename<>''
			BEGIN
				SET @checkcoltype=' SELECT @coloutput= min(ISNUMERIC(isnull('+@col+',0)))  from '+@tablename+'' 
				exec sp_executesql @checkcoltype , N' @coloutput int OUTPUT', @coloutput=@isnumeric OUTPUT
				PRINT @checkcoltype
				PRINT @isnumeric
			END
			else
			BEGIN
				SET @p_sort_str=CASE WHEN @p_sort_str='' THEN '#EndResultPagging.ROW_NUMBER ' ELSE @p_sort_str END
				PRINT @p_sort_str
			END
			DECLARE @selectspecificcol AS NVARCHAR(MAX)=''
			DECLARE @ObjectiveJoin AS NVARCHAR(MAX)=''
			IF ltrim(rtrim(@tabletype)) LIKE '%WP_EmpAppraisalObj%'  
			BEGIN
				
				DECLARE @CountHideMax AS INT =0 , @CountHideThreshold AS INT =0 
				select @CountHideMax  =count (*) FROM objectives 
				WHERE ObjectiveParentId is NULL AND HideMax=0
				select @CountHideThreshold  =count (*) FROM objectives 
				WHERE ObjectiveParentId is NULL AND HideThreshold =0
				
				IF @CountHideMax = 0
				BEGIN
					set @selectspecificcol =' , 0.0 as ObjectiveMax '
				END
				IF @CountHideThreshold = 0
				BEGIN
					set @selectspecificcol =@selectspecificcol +' , 0.0 as ObjectiveThreshold '
				END
				set @selectspecificcol =@selectspecificcol +' ,parent.MaxCompletion '
				SET @ObjectiveJoin =' INNER JOIN objectives ON objectives.ObjectiveId=#EndResultPagging.ObjectiveId
				INNER JOIN objectives parent ON parent.ObjectiveId = objectives.ObjectiveParentId'
			END
			PRINT @selectspecificcol
		
			PRINT @selectspecificcol 
			PRINT @tabletype
				PRINT @str
			SET @str=@str+' SELECT top '+str(@p_batch_size)
			+'#EndResultPagging.* ' +@selectspecificcol+' FROM #EndResultPagging'+ @ObjectiveJoin +' WHERE #EndResultPagging.ROW_NUMBER NOT IN (SELECT TOP '+str(@p_batch_size*(@p_page_number -1))+' ROW_NUMBER FROM #EndResultPagging order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
			+ ') order by '+CASE WHEN @isnumeric=0 THEN @p_sort_str ELSE 'cast('+@col+' as numeric(18,3))'+@desc END 
			print '****************'
			PRINT @str
			SET @str=@str+' drop table #EndResultPagging'
			print @str
			exec sp_executesql @str , N' @formulaOutput int OUTPUT', @formulaOutput=@count OUTPUT
		END

	


end 
end

GO

