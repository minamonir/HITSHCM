CREATE PROCEDURE [dbo].[AutoAssignShift] 
( 
 @FilterWhere NVARCHAR(MAX) , @Filterselect AS NVARCHAR(MAX) , @From DATE , @To DATE , @Before INT , @Period INT , @MinuteAdd INT=15 , @CallingBeforeShiftNo INT 	,@RefreshReadings INT =0 ,@RefreshMinutes INT =0 )

AS 
BEGIN 

 --select @FilterWhere=@FilterWhere + ' AND EmpAssignment.TimeRule in(1,2,3,6,7) ' 
 --SELECT @FilterWhere=@FilterWhere + ' AND EmpAssignment.TimeRule in(1,2,3,6,7,4,5,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22) ' 
 SELECT @FilterWhere=@FilterWhere + ' AND EmpAssignment.TimeRule in(1,2,3,6,7,4,5,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,101,102,103) and status=1 ' 
	DECLARE @FromTemp DATE  , @ToTemp DATE
	-- @MinuteAdd			 : this paramter used to increase time of comparing permission 
	-- @CallingBeforeShiftNo : this paramter = PermissionNo of (Calling before shift)

	IF @From <> '' AND @To <> ''
	BEGIN
		SELECT @FromTemp = DATEADD(DAY,-1,@From) , @ToTemp = DATEADD(DAY,1,@To)
	END 
	ELSE IF	(@Before <> 0 AND @Period = 0 ) OR (@Before = 0 AND @Period <> 0 ) 
	BEGIN
		SELECT @FromTemp = CONVERT(SMALLDATETIME,CONVERT(char(12),dateadd(dd,@Before,getdate())),103), 
			   @ToTemp   = CONVERT(SMALLDATETIME,CONVERT(char(12),dateadd(dd,(@Period+@Before)+1,getdate())),103) 
	END 	
	
	IF @RefreshReadings IN (2,3)
	BEGIN
		EXEC InactiveReadingWithinSameMinute @FilterWhere = @FilterWhere , 
		    @From = @From, 
		    @To = @To ,
		    @Before = @Before,
		    @Period = @Period,
		    @min = @RefreshMinutes		
	END	


	CREATE TABLE #Temp 
	   (EmpId INT , TimeIn DATETIME  , VacLength DECIMAL(18,3) , NewTimeIn DATETIME , FromDate DATETIME ,NewTimeDate DATETIME
	   , VacCode INT , PermissionLength INT , PermissionNo INT ,TimeDiff INT , TimeRule INT, VacPack INT , NewShiftNo INT ,
		GroupLevel1 numeric (18,3),GroupName1 nvarchar(250),  GroupLevel2 numeric (18,3),GroupName2 nvarchar(250),  GroupLevel3 numeric (18,3),
		GroupName3 nvarchar(250),  GroupLevel4 numeric (18,3),GroupName4 nvarchar(250),  GroupLevel5 numeric (18,3),GroupName5 nvarchar(250),  
		GroupLevel6 numeric (18,3),GroupName6 nvarchar(250),  GroupLevel7 numeric (18,3),GroupName7 nvarchar(250),  GroupLevel8 numeric (18,3),GroupName8 nvarchar(250) )

	DECLARE @Str NVARCHAR(MAX) = 'SELECT DISTINCT 
	EmpTimeReadings.EmpId , AttendTime 
	, IsNull(dbo.PermissionLength(EmpTimeReadings.EmpId ,0,0,PermissionFrom , PermissionTo),0) 
	AS PermissionLength , PermissionNo  
	--, IsNull(DATEDIFF(hh,TimeShifts.FromTime,TimeShifts.ToTime),0) AS TimeDiff
	,8 AS TimeDiff , EmpAssignment.TimeRule , EmpAssignment.VacPack
	' + @Filterselect + '
	FROM EmpTimeReadings 	
	LEFT JOIN Empassignment ON EmpAssignment.EmpId = EmpTimeReadings.EmpId 
	LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
	LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId 
	LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
	LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule 
	LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack
	LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
	LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType 
	LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
	LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode 
	LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup 
	LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
	LEFT JOIN JobCat ON JobCat.JobCat = Jobs.JobCat 
	LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
	LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
	LEFT JOIN GradeGroups ON gradeGroups.GradeGroup = Grades.GradeGroup
	LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
	LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center
	LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
	LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
	LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType
	LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
	LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1  
	LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname = ''Status'' 
	LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus''
	LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus''
	LEFT JOIN NasArrays HrTaxstat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus''
	LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus''
	LEFT JOIN NasArrays Gender ON Gender.itemno = Profile.Gender AND Gender.arrayname = ''Gender''
    inner JOIN TimeSystemLines ON TimeSystemLines.TimeSystem = EmpTimeReadings.TimeSystem and TimeLineType=1
	 and TimeSystemLines.LineValues = case when  linefield=1 then EmpTimeReadings.ReaderValue else EmpTimeReadings.flagvalue end 
	--LEFT JOIN EmpVacat ON EmpVacat.EmpId = EmpTimeReadings.EmpId AND CAST(EmpTimeReadings.AttendTime AS DATE) BETWEEN EmpVacat.FromDate AND EmpVacat.ToDate and vacstatus=1 
					  -- AND dbo.VacTotalTaken(EmpTimeReadings.EmpId, EmpTimeReadings.ShiftDate , EmpTimeReadings.ShiftDate,0) BETWEEN 0 AND .99 

	LEFT JOIN EmpTimePermission ON EmpTimePermission.EmpId = EmpTimeReadings.EmpId AND PermissionNo = '+LTRIM(@CallingBeforeShiftNo)+' 
						AND EmpTimeReadings.AttendTime BETWEEN DATEADD(MINUTE,-'+LTRIM(@MinuteAdd)+',EmpTimePermission.PermissionFrom)  AND DATEADD(MINUTE,'+LTRIM(@MinuteAdd)+',EmpTimePermission.PermissionTo)
	cross join sysparam

	WHERE  EmpTimeReadings.inactive=0 
	
	AND  CAST(EmpTimeReadings.AttendTime AS DATE) BETWEEN '''+LTRIM(@FromTemp)+''' AND '''+ LTRIM(@ToTemp)+ '''  '+ @FilterWhere +' '

	  --EXEC (@Str)

  PRINT @Str
    print @FilterWhere
  INSERT INTO #Temp
		   (EmpId , TimeIn ,PermissionLength , PermissionNo , TimeDiff ,TimeRule,VacPack , 
   			GroupLevel1,GroupName1,  GroupLevel2,GroupName2,GroupLevel3,GroupName3, GroupLevel4,GroupName4,GroupLevel5,GroupName5,
			GroupLevel6,GroupName6,  GroupLevel7,GroupName7,  GroupLevel8,GroupName8)
  
  EXEC (@Str)

  -- SELECT '111', * FROM #Temp 

	DECLARE @EmpId INT , @TimeDate SMALLDATETIME , @TimeDateVac SMALLDATETIME ,  @TimeIn DATETIME , @VacLength DECIMAL(18,3) , @NewTimeIn DATETIME  
	, @PermissionLength INT , @PermissionNo INT  ,@TimeDiff INT , @NewShiftNo INT , @NextTimeOut DATETIME , @MinuteDiff INT , @ShiftType INT 
	  ,@TimeRule INT ,@VacPack INT , @Holiday INT, @DayOff INT ,@DayType INT , @VacDueDays DECIMAL (18,2),@DocumentNo INT,@ssdocno int

      -- @DayType = 1 DayOff 
	  -- @DayType = 2 Holiday

	DECLARE EmpCursor CURSOR FOR  
		SELECT EmpId , CAST(TimeIn AS DATE) , TimeIn , PermissionLength , PermissionNo , TimeDiff  , TimeRule , VacPack FROM #Temp 
		ORDER BY 1,2

	OPEN EmpCursor   
	FETCH NEXT FROM EmpCursor INTO @EmpId , @TimeDate , @TimeIn , @PermissionLength , @PermissionNo , @TimeDiff , @TimeRule , @VacPack
	WHILE @@FETCH_STATUS = 0   
	BEGIN   
		SELECT @NewShiftNo = NULL , @NewTimeIn = @TimeIn , @NextTimeOut = NULL , @MinuteDiff = 0 , @VacLength = 0 
		      
		SELECT @Holiday=0,@DayOff=0,@DayType=0

		SELECT @DayOff = (CASE  WHEN DATEPART(dw,@TimeDate) =  v.doffday1 THEN 1 
								WHEN DATEPART(dw,@TimeDate) =  v.doffday2 THEN 1 ELSE 0 END) 
						FROM vacpack v 
						WHERE v.vacpack=@VacPack AND v.dofftype=1

		IF @DayOff <> 0 SELECT @DayType=1
	
		--SELECT @Holiday = 1 
		--				FROM holidays h 
		--				WHERE h.vacpack=@VacPack AND h.holiday=1 AND h.date = @TimeDate
			SELECT @Holiday = COUNT(*)
						FROM empvacat 
						WHERE empid=@EmpId ANd @TimeDate BETWEEN FromDate AND ToDate AND VacCode=25 and vacstatus=1 

		IF @Holiday <> 0 SELECT @DayType=2

		IF @DayType IN (1,2)
		BEGIN 
			SELECT TOP 1 @NewShiftNo = ShiftNo FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @DayType = 1 THEN 'DayOff' ELSE 'Holiday' END  
										AND @TimeIn BETWEEN DATEADD(hh, -6 ,CONVERT(datetime,(convert(nchar(10), @TimeDate,120) +' '+TimeShifts.FromTime),120)) 		 -- ( CASE WHEN DATEPART(hh,@TimeIn) = 00 THEN @TimeDate ELSE @TimeDate END ) 
	  									AND DATEADD(hh, 6 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120))
			
			IF (SELECT ShiftNameCons FROM TimeShifts WHERE ShiftNo = @NewShiftNo) = 'DayOff' 
			BEGIN 
				IF NOT EXISTS (SELECT * FROM EmpVacationDue WHERE Empid = @EmpId AND VacDueDate = @TimeDate)
				BEGIN 
				-- PRINT 'SELECT * FROM EmpVacationDue WHERE Empid = '+@EmpId+' AND VacDueDate = '+@TimeDate+' '
				select @DocumentNo=dbo.getdocumentno(@empid,8)
				
				EXEC	[dbo].[GetSSDocNo]		@doctype = 8,@Code = N'10',	@SSDocNo = @SSDocNo OUTPUT

				SELECT TOP 1 @VacDueDays = WorkSeconds/3600.000/8.000 FROM EmpShiftInOut WHERE EmpId = @EmpId AND EntryDate = @TimeDate  							
					INSERT INTO EmpVacationDue
							( Empid ,DocumentNo ,VacDueCode ,VacDueDate ,VacDueStatus ,VacDueDays ,VacDueInfo ,EnterBy ,EnterDate)
					SELECT @EmpId ,@DocumentNo ,10 , @TimeDate ,5 , @VacDueDays ,'DayOff Replacement',99999999 , GETDATE() 
					WHERE @VacDueDays > 0

				INSERT INTO WFDocument (DocumentNo, EmpID, SSDocNo, StartDate,  Expired, EnterDate, EnterBy)
				VALUES (@DocumentNo,@EmpID,@SSDocNo,getdate(),0,getdate(),99999999)
				END 						
			END 
									
			------ (- one day to match over night shifts)
			----IF @NewShiftNo IS NULL 
			----BEGIN
			----	SELECT TOP 1 @NewShiftNo = ShiftNo, @TimeDate = @TimeDate-1 FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @DayType = 1 THEN 'DayOff' ELSE 'Holiday' END  
			----								 AND @TimeIn BETWEEN  DATEADD(hh, -4 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120))
	  ----										 AND DATEADD(hh, 4 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120))
			----								 AND ShiftType = 3 
			----END
		END 
		ELSE IF @TimeRule IN (1,6)
		BEGIN 

			SELECT TOP 1 @NewShiftNo = ShiftNo FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' WHEN @TimeRule IN (6) THEN  'AutoAssignShift4' END  
										AND @TimeIn BETWEEN DATEADD(hh, -2 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120)) 		
	  									AND DATEADD(hh, 2 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120))
									
			-- (- one day to match over night shifts)
			IF @NewShiftNo IS NULL 
			BEGIN
				SELECT TOP 1 @NewShiftNo = ShiftNo, @TimeDate = @TimeDate-1 FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END  
											 AND @TimeIn BETWEEN  DATEADD(hh, -2 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120))
	  										 AND DATEADD(hh, 2 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120))
											 AND ShiftType = 3 
			END
													  
			-- Permission
			IF @NewShiftNo IS NULL AND @PermissionLength > 0 AND @PermissionNo <> 0 
			BEGIN 
				SELECT @NextTimeOut = MIN(AttendTime) FROM EmpTimeReadings WHERE EmpId = @EmpId 
									   AND ReaderValue IN (SELECT TimeSystemLines.LineValues FROM TimeSystemLines WHERE TimeLineType = 2 and linefield=1) 
			-- or FlagValue in (SELECT TimeSystemLines.LineValues FROM TimeSystemLines WHERE TimeLineType = 1 and linefield=2)  
									  --AND FlagValue ='44444444   '
									  AND AttendTime > @TimeIn
			
				SELECT @MinuteDiff = DATEDIFF(MINUTE,@TimeIn,@NextTimeOut) 

				IF @MinuteDiff >= 360 AND @MinuteDiff <= 1440
				BEGIN      
					SET @NewTimeIn = DATEADD(MINUTE, (ISNULL(@PermissionLength  ,0) / 60.000 ) ,@TimeIn)
										 
					SELECT TOP 1 @NewShiftNo =  ShiftNo FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END   
												AND @NewTimeIn BETWEEN DATEADD(hh, -2 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120)) 
												AND DATEADD(hh, 2 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120)) 
												
				   -- (- one day to match over night shifts)
					IF @NewShiftNo IS NULL 
					BEGIN
						SELECT TOP 1 @NewShiftNo = ShiftNo , @TimeDate = @TimeDate-1  FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END   
													AND @NewTimeIn BETWEEN DATEADD(hh, -2 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120)) 		
	  												AND DATEADD(hh, 2  ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120)) 
													AND ShiftType = 3 
					END																																									 		
				END
			END 		
			-- Vacation
			IF @NewShiftNo IS NULL 
			BEGIN 
			-------------------------------------------------------
				--------if time in between shift from-to to cehck for vacation---
			SELECT @TimeDateVac=@TimeDate
				SELECT TOP 1 @NewShiftNo =  ShiftNo FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END   
								 AND @TimeIn BETWEEN CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120)
													AND CONVERT(datetime,(convert(nchar(10),@TimeDate+CASE WHEN ShiftType=3 THEN 1 ELSE 0 end ,120) +' '+TimeShifts.ToTime),120) 
			--	SELECT 'Vacation1', @NewShiftNo AS NewShiftNo , @NewTimeIn AS  time , @TimeDate AS TimeDate		
				IF @NewShiftNo IS NULL 
				BEGIN
					SELECT TOP 1 @NewShiftNo =  ShiftNo, @TimeDateVac = @TimeDate-1  FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END  AND ShiftType = 3 
							   					AND @TimeIn BETWEEN CONVERT(datetime,(convert(nchar(10),@TimeDate-1 ,120) +' '+TimeShifts.FromTime),120) 
												AND CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.ToTime),120) 
				END
			
			
				SET @NewShiftNo = null
		----------------------------------------------------------	
				SELECT @VacLength = IsNull(dbo.VacTotalTaken(@EmpId, @TimeDateVac,@TimeDateVac,0),0)
			
				IF @VacLength > 0 AND @VacLength <1
				BEGIN
					SET @NewTimeIn = DATEADD(hh,ISNULL((-1 * @VacLength * @TimeDiff),0) ,@TimeIn) 
		
					SELECT TOP 1 @NewShiftNo = ShiftNo FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END   
									 AND @NewTimeIn BETWEEN DATEADD(hh, -2 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120)) 
													 AND DATEADD(hh, 2 ,CONVERT(datetime,(convert(nchar(10),@TimeDate ,120) +' '+TimeShifts.FromTime),120)) 
					IF @NewShiftNo IS NULL 
					BEGIN
						SELECT TOP 1 @NewShiftNo = ShiftNo, @TimeDate = @TimeDate-1 FROM TimeShifts WHERE ShiftNameCons = CASE WHEN @TimeRule IN (1) THEN 'AutoAssignShift3' ELSE 'AutoAssignShift4' END  
												 AND @NewTimeIn BETWEEN DATEADD(hh, -2 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120)) 		
	  											 AND DATEADD(hh, 2 ,CONVERT(datetime,(convert(nchar(10),DATEADD(DAY,-1,@TimeDate) ,120) +' '+TimeShifts.FromTime),120))
												 AND ShiftType = 3 
					END										 		
				END
			END 
		END 





		UPDATE #Temp SET NewTimeIn = @NewTimeIn , NewShiftNo = @NewShiftNo , VacLength = @VacLength,NewTimeDate = @TimeDate
     									WHERE EmpId = @EmpId AND TimeIn = @TimeIn

		-- Actions
		IF @NewShiftNo IS NULL 
		BEGIN 
			PRINT '@NewShiftNo IS NULL '
			--UPDATE EmpShift SET ShiftNo = NULL ,ChangeBy = 99999999, ChangeDate = GETDATE()
			--WHERE EmpShift.EmpId = @EmpId AND EmpShift.ShiftDate = @TimeDate AND EmpShift.ShiftNo IS NOT NULL
		END 
		ELSE 
		BEGIN 	
			IF EXISTS(SELECT * FROM EmpShift WHERE EmpId = @EmpId AND EmpShift.ShiftDate = @TimeDate)
			BEGIN 
				PRINT 'Update' 
				UPDATE EmpShift SET ShiftNo = @NewShiftNo ,ChangeBy = 99999999, ChangeDate = GETDATE()
				WHERE  EmpShift.EmpId = @EmpId AND EmpShift.ShiftDate = @TimeDate AND isnull(EmpShift.ShiftNo,0) <> @NewShiftNo
			END 
			ELSE 
			BEGIN                
				PRINT 'Insert'
				INSERT INTO EmpShift ( EmpId ,ShiftDate ,ShiftNo ,EnterBy ,EnterDate)		
				SELECT @EmpId , @TimeDate , @NewShiftNo , 99999999 , GETDATE()
				-----FROM EmpShift WHERE EmpShift.EmpId = @EmpId AND ShiftDate IS NULL AND @NewShiftNo IS NOT NULL 
			END 
-----------------------------------------update next day-------------------------------------------
			IF @NewShiftNo in (SELECT shiftno FROM  TimeShifts WHERE ShiftNameCons IN( 'AutoAssignShift3','AutoAssignShift4') AND ShiftType=3   ) 
			BEGIN
				
			
			SELECT @Holiday=0,@DayOff=0,@DayType=0

						SELECT @DayOff = (CASE  WHEN DATEPART(dw,@TimeDate+1) =  v.doffday1 THEN 1 
												WHEN DATEPART(dw,@TimeDate+1) =  v.doffday2 THEN 1 ELSE 0 END) 
										FROM vacpack v 
										WHERE v.vacpack=@VacPack AND v.dofftype=1

						IF @DayOff <> 0 SELECT @DayType=1
	
						SELECT @Holiday = 1 
										FROM holidays h 
										WHERE h.vacpack=@VacPack AND h.holiday=1 AND h.date = @TimeDate+1
	
						IF @Holiday <> 0 SELECT @DayType=2 
				IF EXISTS(SELECT * FROM EmpShift WHERE EmpId = @EmpId AND EmpShift.ShiftDate = @TimeDate+1) AND @DayType NOT IN (1,2)
				BEGIN 
				--	SELECT 'Update next day',@NewShiftNo [@NewShiftNo2], @TimeDate+1,@TimeIn
					PRINT 'Update next day' 
					UPDATE EmpShift SET ShiftNo = @NewShiftNo ,ChangeBy = 99999999, ChangeDate = GETDATE()
					WHERE  EmpShift.EmpId = @EmpId AND EmpShift.ShiftDate = @TimeDate+1 AND isnull(EmpShift.ShiftNo,0) <> @NewShiftNo
				END 
				----ELSE 
				----BEGIN                
				----	PRINT 'Insert next day'
				------	SELECT 'insert next day',@EmpId , @TimeDate+1,@TimeIn , @NewShiftNo , 99999999 , GETDATE() 
				----	INSERT INTO EmpShift ( EmpId ,ShiftDate ,ShiftNo ,EnterBy ,EnterDate)		
				----	SELECT @EmpId , @TimeDate+1 , @NewShiftNo , 99999999 , GETDATE()
				----	---FROM EmpShift WHERE EmpShift.EmpId = @EmpId AND ShiftDate IS NULL AND @NewShiftNo IS NOT NULL 
				----END 
			END	 
			if @RefreshReadings IN (1,3)
			BEGIN
				UPDATE EmpTimeReadings SET inactive=inactive
				WHERE empid=@EmpId and attendtime  =@TimeIn
			END	
		END 


		FETCH NEXT FROM EmpCursor INTO @EmpId , @TimeDate , @TimeIn , @PermissionLength , @PermissionNo , @TimeDiff , @TimeRule , @VacPack
	END   
	CLOSE EmpCursor   
	DEALLOCATE EmpCursor



	SELECT #Temp.EmpId , EmpAssignment.EmployeeId , Profile.Name ,Profile.AName ,#Temp.NewTimeDate,#Temp.TimeIn , #Temp.NewShiftNo ,#Temp.VacLength ,TimeDiff
		, #Temp.NewTimeIn ,#Temp.FromDate,#Temp.VacCode ,Vacation.VacationName ,Vacation.VacationAName  ,#Temp.PermissionLength ,#Temp.PermissionNo 
		, TimePermission.PermissionName , TimePermission.PermissionAName
		, TimeShifts.ShiftName , TimeShifts.ShiftAName 			
		, GroupLevel1,GroupName1,  GroupLevel2,GroupName2,  GroupLevel3,GroupName3,  GroupLevel4,GroupName4
		, GroupLevel5,GroupName5,  GroupLevel6,GroupName6,  GroupLevel7,GroupName7,  GroupLevel8,GroupName8
	FROM #Temp 
	LEFT JOIN EmpAssignment ON EmpAssignment.EmpId = #Temp.EmpId 
	LEFT JOIN Profile ON Profile.ProfileId = EmpAssignment.EmpId
	LEFT JOIN TimeShifts ON TimeShifts.ShiftNo = #Temp.NewShiftNo
	LEFT JOIN Vacation ON #Temp.VacCode = Vacation.vaccode 
	LEFT JOIN TimePermission ON TimePermission.PermissionNo = #Temp.PermissionNo 
	ORDER BY EmpId   -- CAST(#Temp.TimeIn AS DATE) 

	DROP TABLE #Temp 
END

GO

