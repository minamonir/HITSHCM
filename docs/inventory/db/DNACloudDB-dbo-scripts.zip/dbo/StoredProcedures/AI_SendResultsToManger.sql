

CREATE  PROCEDURE [dbo].[AI_SendResultsToManger](@GoogleFormsId as int,@Manager as nvarchar(max),@Lang as nchar(1))
AS
BEGIN
	-- ================================================================
    -- MANAGER EMAIL: Send HTML results table after all emails are sent
    -- ================================================================
	DECLARE @jobName as nvarchar(max)=''
	select @jobName= LTRIM(RTRIM(jobname)) from GoogleForms where id=@GoogleFormsId

    DECLARE 
		@ManagerName  AS NVARCHAR(MAX),
        @ManagerSubject  AS NVARCHAR(MAX),
        @ManagerBody     AS NVARCHAR(MAX),
        @ManagerEmail    AS NVARCHAR(MAX),
        @HtmlTable       AS NVARCHAR(MAX) = ''

		SELECT @ManagerEmail = LTRIM(RTRIM(p.companyemail)), 
			   @ManagerName = CASE WHEN @Lang='E' THEN LTRIM(RTRIM(p.Name)) ELSE LTRIM(RTRIM(p.AName)) END
		FROM EmpAssignment ea
		INNER JOIN Profile p ON LTRIM(RTRIM(p.ProfileId)) = LTRIM(RTRIM(ea.EmpId))
		WHERE ea.EmployeeId = @Manager

    -- Build HTML table header
	DECLARE 
		@HeaderMsg  AS NVARCHAR(MAX),
		@Dear AS NVARCHAR(MAX),
		@RespondentEmailmsg AS NVARCHAR(MAX),
		@TotalQuestionsmsg AS NVARCHAR(MAX),
		@CorrectQuestionsmsg AS NVARCHAR(MAX),
		@OverallScoremsg AS NVARCHAR(MAX)


	select 
		@HeaderMsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Header',@Lang),(case when @Lang='E' then N'Please Find Below The Assessment Results Summary For The Position:' else N':يرجى الاطلاع أدناه على ملخص نتائج التقييم للوظيفة' end)),
		@Dear = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','Dear',@Lang),(case when @Lang='E' then N'Dear' else N'عزيزي' end)),
		@RespondentEmailmsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','RespondentEmail',@Lang),(case when @Lang='E' then N'Respondent Email' else N'بريد المستجيب' end)),
		@TotalQuestionsmsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','TotalQuestions',@Lang),(case when @Lang='E' then N'Total Questions' else N'مجموع الأسئلة' end)),
		@CorrectQuestionsmsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','CorrectQuestions',@Lang),(case when @Lang='E' then N'Correct Questions' else N'الأسئلة الصحيحة' end)),
		@OverallScoremsg = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','OverallScore',@Lang),(case when @Lang='E' then N'Overall Score' else N'النتيجة الإجمالية' end))
		
		    --<p>' + CASE WHEN @Lang='E' THEN @Dear + ' ' + @ManagerName ELSE @ManagerName + ' ' + @Dear END + ',</p>

    SET @HtmlTable = '
    <html>
	<body>
    <p>' + case when @Lang='A' then ',' else '' end  +  @Dear + ' ' + @ManagerName + case when @Lang='E' then ',' else '' end +'</p>
    <p>' + CASE WHEN @Lang='E' THEN @HeaderMsg + ' <strong>' + @jobName + '</strong>' ELSE '<strong>' + @jobName + '</strong> ' + @HeaderMsg END + '</p>
    <table border="1" cellpadding="6" cellspacing="0" 
           style="border-collapse:collapse; font-family:Arial, sans-serif; font-size:13px; ' + case when @Lang='E' then N'' else N'direction: rtl;' end + '">
        <thead>
            <tr style="background-color:#4472C4; color:#ffffff; text-align:center;">
                <th style="padding:8px;">' + @RespondentEmailmsg + '</th>
                <th style="padding:8px;">' + @TotalQuestionsmsg +' </th>
                <th style="padding:8px;">' + @CorrectQuestionsmsg + '</th>
                <th style="padding:8px;">' + @OverallScoremsg + '</th>
            </tr>
        </thead>
        <tbody>'

    -- Build HTML rows dynamically from GoogleFormsResults filtered by FormId
    DECLARE 
        @RespondentEmail    AS NVARCHAR(MAX),
        @TotalQuestions     AS INT,
        @CorrectQuestions   AS INT,
        @OverallScore       AS numeric(18,3),
        @RowColor           AS NVARCHAR(20),
        @RowCount           AS INT = 0

    DECLARE results_cursor CURSOR FOR
        SELECT 
            RespondentEmail,
            TotalQuestions,
            CorrectQuestions,
            OverallScore
        FROM GoogleFormsResult
        WHERE FormId = (SELECT FormId FROM GoogleForms WHERE id = @GoogleFormsId)



    OPEN results_cursor
    FETCH NEXT FROM results_cursor INTO @RespondentEmail, @TotalQuestions, @CorrectQuestions, @OverallScore

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Alternate row colors for readability
        SET @RowColor = CASE WHEN @RowCount % 2 = 0 THEN '#ffffff' ELSE '#dce6f1' END

        SET @HtmlTable = @HtmlTable + '
            <tr style="background-color:' + @RowColor + ';">
                <td style="padding:7px;">' + ISNULL(@RespondentEmail, '') + '</td>
                <td style="padding:7px; text-align:center;">' + CAST(@TotalQuestions AS NVARCHAR) + '</td>
                <td style="padding:7px; text-align:center;">' + CAST(@CorrectQuestions AS NVARCHAR) + '</td>
                <td style="padding:7px; text-align:center;">' + CAST(ROUND(@OverallScore, 3) AS NVARCHAR) + '</td>
            </tr>'

        SET @RowCount = @RowCount + 1
        FETCH NEXT FROM results_cursor INTO @RespondentEmail, @TotalQuestions, @CorrectQuestions, @OverallScore
    END

    CLOSE results_cursor
    DEALLOCATE results_cursor

    -- Close HTML
	SET @HtmlTable = @HtmlTable + '
        </tbody>
    </table>
    </body></html>'

    --SET @HtmlTable = @HtmlTable + '
    --    </tbody>
    --</table>
    --<br/><p>Regards,<br/>HR System</p>
    --</body></html>'

    -- Set manager email subject
    SET @ManagerSubject = isnull(dbo.Hits_GetDCCaption('AI_SendGoogleFormsLink','ManagerSub',@Lang),(case when @Lang='E' then  N'Assessment Results Summary -' else N'ملخص نتائج التقييم -' end)) + ' ' + @jobName

    -- Insert manager email into mail log
    IF @ManagerEmail IS NOT NULL AND @RowCount > 0
    BEGIN
        INSERT INTO [dbo].[SQLMailLog] ([SQLMailTo], [SQLMailSubject], [SQLMailBody])
        VALUES (@ManagerEmail, @ManagerSubject, @HtmlTable)
    END

END

GO

