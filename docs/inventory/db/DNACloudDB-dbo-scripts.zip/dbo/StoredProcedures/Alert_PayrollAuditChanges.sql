CREATE PROCEDURE [dbo].[Alert_PayrollAuditChanges] (@AlertSubscription AS BIT,@ExecutionDay AS SMALLINT=0, @RoleId AS SMALLINT)
AS
BEGIN
-- @AlertSubscription=0 --> Alert
-- @AlertSubscription=1 -->Subscription
IF @AlertSubscription=0
BEGIN
select  
UserAuditHeader.AuditDate,
dbo.Greg2Hijri(UserAuditHeader.AuditDate,'E')as h_AuditDate,
UserAuditHeader.AuditType,
UserAuditHeader.UserProfileId, 
UserProfile.Name AS UserProfileName, 
UserProfile.AName AS UserProfileAName, 
case when DataDictTable.Description <>''  then DataDictTable.Description else UserAuditDetail.TableName end as TableName,

CASE WHEN ltrim(rtrim(UserAuditDetail.FieldName))='Amount'
     AND LTRIM(RTRIM(UserAuditDetail.TableName))='MonthlyTransaction' THEN  (SELECT p.PayCodeName FROM paycode p
                                                                             WHERE p.code=ltrim(rtrim(SUBSTRING(UserAuditDetail.PrimaryKey,CHARINDEX('Paycode',UserAuditDetail.PrimaryKey)+9,4)))
                                                                             and ltrim(rtrim(UserAuditDetail.FieldName))='Amount' 
                                                                             AND LTRIM(RTRIM(UserAuditDetail.TableName))='Monthlytransaction')
ELSE case WHEN LTRIM(RTRIM(UserAuditDetail.FieldName))='PaymentInactive' AND LTRIM(RTRIM(UserAuditDetail.TableName))='MonthlyPayment' THEN 
'Payment Bank Account'  
     ELSE  case when DataDictionary.Description <>'' then DataDictionary.Description else UserAuditDetail.FieldName  END END END  as FieldName,

CASE WHEN ltrim(rtrim(UserAuditDetail.FieldName))='Amount' AND LTRIM(RTRIM(UserAuditDetail.TableName))='MonthlyTransaction' THEN 
(SELECT p.PayCodeAName FROM paycode p
 WHERE p.code=ltrim(rtrim(SUBSTRING(UserAuditDetail.PrimaryKey,CHARINDEX('Paycode',UserAuditDetail.PrimaryKey)+9,4)))
and ltrim(rtrim(UserAuditDetail.FieldName))='Amount' AND LTRIM(RTRIM(UserAuditDetail.TableName))='Monthlytransaction')
ELSE case WHEN LTRIM(RTRIM(UserAuditDetail.FieldName))='PaymentInactive' AND LTRIM(RTRIM(UserAuditDetail.TableName))='MonthlyPayment' THEN 
N'رقم حساب البنك' ELSE case when DataDictionary.ADescription <>'' 
then DataDictionary.Description else UserAuditDetail.FieldName end END end as FieldAName,

case WHEN (LTRIM(RTRIM(UserAuditDetail.FieldName))='PaymentInactive' 
AND LTRIM(RTRIM(UserAuditDetail.TableName))='MonthlyPayment') THEN 
                                                              case when UserAuditDetail.OldValue=1 
                                                              THEN 'InActive' ELSE 'Active' END 

ELSE UserAuditDetail.OldValue END  AS OldValue ,

case WHEN LTRIM(RTRIM(UserAuditDetail.FieldName))='PaymentInactive' 
AND LTRIM(RTRIM(UserAuditDetail.TableName))='MonthlyPayment' THEN 
                                                             case when UserAuditDetail.NewValue=1 
                                                             THEN 'InActive' ELSE 'Active' END 
                                                           
ELSE UserAuditDetail.NewValue END AS NewValue ,

 
isnull(empassignment.employeeid,UserAuditDetail.ProfileId) as chngEmployeeid, 
Profile.Name AS ChngprofileName,
Profile.AName AS ChngprofileAName, 
UserAuditDetail.DocumentNo,
Cast (UserAuditHeader.AuditCode as nvarchar (max))  as TableId,
UserAuditHeader.AuditCode 


from UserAuditDetail  
inner join UserAuditHeader on UserAuditHeader.AuditCode=UserAuditDetail.AuditCode
left join UserAuditType On UserAuditType.AuditType=UserAuditHeader.AuditType
Left join Profile UserProfile on UserProfile.Profileid=UserAuditHeader.UserProfileId
left join Empassignment UserEmpassignment on UserEmpassignment.empid=UserAuditHeader.UserProfileId
left join PersonType on PersonType.PersonType=UserProfile.PersonType
left join DataDictionary on DataDictionary.TableName=UserAuditDetail.TableName and DataDictionary.FieldName=UserAuditDetail.FieldName
left join DataDictionary DataDictTable on DataDictTable.TableName=UserAuditDetail.TableName and DataDictTable.Fieldname =''
left join Profile on Profile.profileid=UserAuditDetail.ProfileId
left join empassignment on empassignment.empid=UserAuditDetail.ProfileId
inner JOIN (SELECT dbo.periodstart (PG.PayrollGroup,PG.CMonth,PG.CYear) AS Periodstart, 
dbo.periodend(PG.PayrollGroup,PG.CMonth,PG.CYear) AS periodend,payrollgroup FROM payrollgroup PG) CPG ON CPG.payrollgroup=empassignment.PayrollGroup
AND UserAuditHeader.AuditDate >= cpg.Periodstart 
left join Organization ON Organization .Organization =empassignment .Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN GradeGroups ON GradeGroups.GradeGroup = Grades.GradeGroup 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center 
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId


WHERE  
  ISNULL(empassignment.employeeid, UserAuditDetail.ProfileId)IS NOT NULL
 
AND (
	(ltrim(rtrim(UserAuditDetail.TableName))='monthlytransaction' AND LTRIM(rtrim(userauditdetail.fieldname))='Amount' AND (
	ltrim(rtrim(SUBSTRING(UserAuditDetail.PrimaryKey,CHARINDEX('Paycode',UserAuditDetail.PrimaryKey)+9,4))) IN (SELECT code FROM Paycode WHERE paycode.hrvalues = 1 )))
OR (ltrim(rtrim(UserAuditDetail.TableName))='Empassignment' AND ((ltrim(rtrim(UserAuditDetail.FieldName))='Hiredate')
OR (ltrim(rtrim(UserAuditDetail.FieldName))='HrStatus'AND empassignment.hiredate BETWEEN CPG.periodstart AND cpg.periodend)
OR ( ltrim(rtrim(userauditdetail.FieldName))IN ('Positionno','Organization','BasicSal'))
OR (ltrim(rtrim(userauditdetail.FieldName))IN ('Status') AND ltrim(rtrim(userauditdetail.OldValue))=N'Active / يعمل' AND LTRIM(RTRIM(UserAuditDetail.NewValue))
=N'Inactive / لايعمل')))
OR  (LTRIM(RTRIM(UserAuditDetail.TableName))='Monthlypayment' AND (ltrim(rtrim(userauditdetail.FieldName)) IN ('paybankact','PaymentInactive'))))
AND UserAuditHeader.AuditDate BETWEEN Periodstart AND periodend

END 
ELSE
BEGIN

DECLARE @ChangesFound AS BIGINT=0

IF DAY(GETDATE())= @ExecutionDay
BEGIN

SELECT @ChangesFound= COUNT(*)
from UserAuditDetail  
inner join UserAuditHeader on UserAuditHeader.AuditCode=UserAuditDetail.AuditCode
left join UserAuditType On UserAuditType.AuditType=UserAuditHeader.AuditType
Left join Profile UserProfile on UserProfile.Profileid=UserAuditHeader.UserProfileId
left join Empassignment UserEmpassignment on UserEmpassignment.empid=UserAuditHeader.UserProfileId
left join PersonType on PersonType.PersonType=UserProfile.PersonType
left join DataDictionary on DataDictionary.TableName=UserAuditDetail.TableName and DataDictionary.FieldName=UserAuditDetail.FieldName
left join DataDictionary DataDictTable on DataDictTable.TableName=UserAuditDetail.TableName and DataDictTable.Fieldname =''
left join Profile on Profile.profileid=UserAuditDetail.ProfileId
left join empassignment on empassignment.empid=UserAuditDetail.ProfileId
inner JOIN (SELECT dbo.periodstart (PG.PayrollGroup,PG.CMonth,PG.CYear) AS Periodstart, 
dbo.periodend(PG.PayrollGroup,PG.CMonth,PG.CYear) AS periodend,payrollgroup FROM payrollgroup PG) CPG ON CPG.payrollgroup=empassignment.PayrollGroup
AND UserAuditHeader.AuditDate >= cpg.Periodstart 
left join Organization ON Organization .Organization =empassignment .Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON Jobs.JobCat = JobCat.JobCat 
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade 
LEFT JOIN GradeGroups ON GradeGroups.GradeGroup = Grades.GradeGroup 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center 
LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp 
LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId


WHERE  
  ISNULL(empassignment.employeeid, UserAuditDetail.ProfileId)IS NOT NULL
 
AND (
	(ltrim(rtrim(UserAuditDetail.TableName))='monthlytransaction' AND LTRIM(rtrim(userauditdetail.fieldname))='Amount' AND (
	ltrim(rtrim(SUBSTRING(UserAuditDetail.PrimaryKey,CHARINDEX('Paycode',UserAuditDetail.PrimaryKey)+9,4))) IN (SELECT code FROM Paycode WHERE paycode.hrvalues = 1 )))
OR (ltrim(rtrim(UserAuditDetail.TableName))='Empassignment' AND ((ltrim(rtrim(UserAuditDetail.FieldName))='Hiredate')
OR (ltrim(rtrim(UserAuditDetail.FieldName))='HrStatus'AND empassignment.hiredate BETWEEN CPG.periodstart AND cpg.periodend)
OR ( ltrim(rtrim(userauditdetail.FieldName))IN ('Positionno','Organization','BasicSal'))
OR (ltrim(rtrim(userauditdetail.FieldName))IN ('Status') AND ltrim(rtrim(userauditdetail.OldValue))=N'Active / يعمل' AND LTRIM(RTRIM(UserAuditDetail.NewValue))
=N'Inactive / لايعمل')))
OR  (LTRIM(RTRIM(UserAuditDetail.TableName))='Monthlypayment' AND (ltrim(rtrim(userauditdetail.FieldName)) IN ('paybankact','PaymentInactive'))))
AND UserAuditHeader.AuditDate BETWEEN Periodstart AND periodend


END


SELECT Distinct SSGroupRole.ProfileId,
(CASE WHEN Profile.CompanyEmail<>'' THEN Profile.CompanyEmail ELSE Profile.PrivateEmail END )AS CompanyEmail
from SSGroupRole
left join Profile on profile.profileid=SSGroupRole.profileid
left join empassignment on empassignment.empid=Profile.Profileid
left join HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus  
where (Profile.CompanyEmail <>'' OR Profile.PrivateEmail <>'') 
and  HrStatus.PayStatus=1 
AND SSGroupRole.RoleId=@RoleId
AND 1 =  (CASE WHEN @ChangesFound >0 THEN 1 ELSE 0 END)	

END

END

GO

