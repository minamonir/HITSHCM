

					CREATE PROCEDURE [dbo].[BatchWP_GetExternalAppraisalWMR]

					(@actiontype AS smallint, @tablename as nvarchar(150),@actual AS smallint,@Where AS nvarchar(max),@Parameters AS nvarchar(max),@ColumnsStr AS nvarchar(max))
					AS
					BEGIN

					DECLARE @select AS nvarchar(max),@FieldType AS INT ,@lang AS NCHAR(1),@ErrorMsg AS NVARCHAR(MAX) = '',@langindex AS INT ,@logonName AS NVARCHAR(max)
					DECLARE @DateFormat AS int
					SELECT @DateFormat= dateformat FROM SysParam 
					IF @DateFormat=1 SET @DateFormat=103
					IF @DateFormat=2 SET @DateFormat=101
					IF @DateFormat=0 SET @DateFormat=111

					DECLARE @Params nvarchar(500), @Cursor_UDF nCHAR(4) 

					CREATE TABLE #UDFTemp(UDF nVARCHAR(8))
					IF rtrim(ltrim(@tablename))<>''

					BEGIN

					SET @select ='INSERT INTO #UDFTemp (UDF) SELECT substring(COLUMN_NAME ,4,len(COLUMN_NAME))
					FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
					WHERE TABLE_NAME ='''+PARSENAME(@tablename,1)+''' AND  COLUMN_NAME Like ''UDF%'' '
					PRINT @select
					PRINT 'SELECT '+@Parameters
					EXECUTE(@select)

					END


					IF @actiontype=1 --Post
					BEGIN

					DECLARE @RefYear AS nvarchar (100)--RefYear
					DECLARE @RefNum AS nvarchar (10)--RefNum
					DECLARE @IssueDate AS nvarchar (100)--IssueDate
					DECLARE @ExecDate AS nvarchar (100)--ExecDate
					DECLARE @RefStatus AS nvarchar (100)--RefStatus
					DECLARE @RefSource AS nvarchar (100)--RefSource
					DECLARE @RrfDesc AS nvarchar(max)--RrfDesc
					DECLARE @AttachmentPath AS nvarchar(max)--AttachmentPath
					DECLARE @AttachmentDesc AS nvarchar(120)--Desc
					DECLARE @AttachmentADesc AS nvarchar(120)--ADesc
					DECLARE @EnterDateAttachment AS nvarchar (100)
					DECLARE @EnterBy AS nvarchar (100)--ProfileID
					DECLARE @workflow AS bit --work flow 
					DECLARE @enableAttachments AS BIT
					DECLARE @enableRef AS BIT

					DECLARE @empid AS int
					DECLARE @Date AS smalldatetime
					DECLARE @AppraisalNo AS INT ,@AppraisalStatus AS INT ,@AppraisalRatingLevel INT 
					DECLARE @OtherInfo AS nvarchar(max)
					DECLARE @Manual AS  NUMERIC(18,3)
					DECLARE @CompetenceResult AS  NUMERIC(18,3),@ObjectiveResult AS  NUMERIC(18,3),@QuestionResult AS  NUMERIC(18,3)
					DECLARE @Row_Number AS INT 
					DECLARE @EnterDate AS SMALLDATETIME
					DECLARE @UDFCrsr_FieldValue AS NVARCHAR(MAX)

					DECLARE @docno AS INT 
					DECLARE @ErrMsg AS Nvarchar(max)
					DECLARE @ErrorValue AS INT
					SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 
					PRINT 'start '+@Parameters

					DECLARE @index AS smallint
					SET @EnterDate=GETDATE()
					SET @index= charindex(',',@Parameters)
					SET @lang = substring(@Parameters,0,@index)
					PRINT '@lang='+@lang
					SET @Parameters = substring(@Parameters,@index+1,len(@Parameters))
					PRINT '1 '+@Parameters

					SET @index=charindex(',',@Parameters)	
					SET @EnterBy=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
					PRINT '@ProfileID '+@EnterBy
					PRINT '2 '+@Parameters

					SET @index=charindex(',',@Parameters)
					SET @workflow=cast(substring(@Parameters,0,@index) AS BIT)
					SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
					PRINT '@workflow '+cast(@workflow AS NCHAR)
					PRINT '3 '+@Parameters

					PRINT 'END '+@Parameters

					IF @enableRef = 1
					BEGIN
					SET @index=charindex('@referenceNostart',@Parameters)	
					PRINT @Parameters
					SET @RefYear=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@referenceNostart'),len(@Parameters))
					PRINT '@RefYear='+@RefYear
					PRINT @Parameters

					SET @index=charindex('@referenceNoEnd',@Parameters)	
					SET @RefNum=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@referenceNoEnd'),len(@Parameters))
					PRINT '@RefNum='+@RefNum
					PRINT @Parameters

					SET @index=charindex(',',@Parameters)	
					SET @IssueDate=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
					PRINT '@IssueDate='+@IssueDate
					PRINT @Parameters

					SET @index=charindex(',',@Parameters)	
					SET @ExecDate=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
					PRINT '@ExecDate='+@ExecDate
					PRINT @Parameters

					SET @index=charindex(',',@Parameters)	
					SET @RefStatus=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
					PRINT '@RefStatus='+@RefStatus
					PRINT @Parameters

					SET @index=charindex('@referenceDescstart',@Parameters)	
					SET @RefSource=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@referenceDescstart'),len(@Parameters))
					PRINT '@RefSource='+@RefSource
					PRINT @Parameters

					END 
					IF @enableAttachments=1
					BEGIN
					SET @index=charindex('@referenceDescEnd',@Parameters)	
					SET @RrfDesc=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@referenceDescEnd'),len(@Parameters))
					PRINT '@RrfDesc='+@RrfDesc
					PRINT @Parameters

					SET @index=charindex('@AttachmentPathEnd',@Parameters)	
					SET @AttachmentPath=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@AttachmentPathEnd'),len(@Parameters))
					PRINT '@AttachmentPath='+@AttachmentPath
					PRINT @Parameters

					SET @index=charindex('@AttachmentDesEnd',@Parameters)	
					SET @AttachmentDesc=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@AttachmentDesEnd'),len(@Parameters))
					PRINT '@AttachmentDesc='+@AttachmentDesc
					PRINT @Parameters

					SET @index=charindex('@AttachmentADesEnd',@Parameters)	
					SET @AttachmentADesc=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+len('@AttachmentADesEnd'),len(@Parameters))
					PRINT '@AttachmentADesc='+@AttachmentADesc
					PRINT @Parameters

					SET @index=charindex(',',@Parameters)	
					SET @EnterDateAttachment=substring(@Parameters,0,@index)
					SET @Parameters=substring(@Parameters,@index+1,len(@Parameters))
					PRINT '@EnterDate='+@EnterDateAttachment
					PRINT @Parameters

					END 

					ELSE
					BEGIN
					SET @RrfDesc=@Parameters
					PRINT '@RrfDesc='+@RrfDesc
					END			
					
					DECLARE @str_cursor AS NVARCHAR(MAX)
					
                     DECLARE @Cur_RYear AS SMALLINT=null, @Cur_RNo AS nvarchar(10)=null, @Cur_IssueDate as nvarchar (100)=null, @Cur_ExecDate AS nvarchar (100)=null
					,@Cur_RStatus AS SMALLINT=null, @Cur_RSource  AS SMALLINT =null, @Cur_RDesc nvarchar(max) =null
					,@cur_AttachDesc nvarchar(max) , @cur_AttachPath nvarchar(max)  
					 ,@cur_str NVARCHAR(MAX)='',@cur_str2 NVARCHAR(MAX)=''


					 IF   @enableRef = 1
              begin
                 SET @cur_str= ' , t.[RYear], t.[RNo], t.[RIssueDate] , t.[RExecDate] 
			          	,NasArraysStatus.itemno [RStatus], NasArraysSource.itemno [RSource] , t.[RDesc] '

				
             SET @cur_str2='LEFT JOIN NasArrays NasArraysStatus ON t.[RStatus] = case when '''+@lang+'''= ''e'' then ltrim(rtrim(NasArraysStatus.edesc)) else ltrim(rtrim(NasArraysStatus.adesc)) end 
                AND NasArraysStatus.arrayname=''RStatus'' 
                   LEFT JOIN NasArrays NasArraysSource ON t.[RSource] = case when '''+@lang+'''= ''e'' then ltrim(rtrim(NasArraysSource.edesc)) else ltrim(rtrim(NasArraysSource.adesc)) end  
                AND NasArraysSource.arrayname=''RSource'' '
         end
              ELSE
            SET @cur_str= ' , null, null, null , null,null,null , null '

            IF @enableAttachments=1
            SET @cur_str= @cur_str +' ,t.AttDesc, t.AttPath '
             ELSE
             SET @cur_str= @cur_str + ' , null, null '

					SET @str_cursor=N'DECLARE Appraisalcursor CURSOR FOR SELECT distinct e.empid,Appraisals.AppraisalNo,t.[Date], SSDocumentStatus.SSDocStatusNo
					,RatingLevels.[RatingLevel],ISNULL(t.[Manual],0),ISNULL(t.[CompetenceResult],0),ISNULL(t.[ObjectiveResult],0),ISNULL(t.[QuestionResult],0),ISNULL(t.[OtherInfo],''''),t.[Row_Number]'+@cur_str +' 
					FROM empassignment e inner join '+@tablename+' t on e.employeeid=t.empid 
					LEFT join Appraisals on LTRIM(RTRIM(t.[AppraisalName]))= CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''E'' THEN appraisals.AppraisalName 
					ELSE CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''A'' THEN appraisals.AppraisalAName END END
					LEFT join SSDocumentStatus on LTRIM(RTRIM(t.[Status]))= CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''E'' THEN SSDocumentStatus.SSDocStatus
					ELSE CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''A'' THEN SSDocumentStatus.SSDocAStatus END END
					LEFT join RatingLevels on Appraisals.RatingScale = RatingLevels.RatingScale
					and LTRIM(RTRIM(t.[RatingLevel]))= CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''E'' THEN LTRIM(rtrim(RatingLevels.LevelName))
					                             ELSE CASE WHEN LTRIM(RTRIM('''+@lang+'''))=''A'' THEN LTRIM(rtrim(RatingLevels.LevelAName))END END
                     '+@cur_str2  +'   
					where t.post=1 and ltrim(rtrim(t.Remarks))='''''
					PRINT 'i am here ' + @str_cursor
					EXECUTE(@str_cursor)
					
					OPEN Appraisalcursor
					FETCH next FROM Appraisalcursor
					INTO @empid,@AppraisalNo,@Date,@AppraisalStatus,@AppraisalRatingLevel,@Manual,@CompetenceResult,@ObjectiveResult,@QuestionResult,@OtherInfo,@Row_Number
					,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath

					WHILE @@FETCH_STATUS=0
					BEGIN
					SET @docno = dbo.GetDocumentNo(@empid,6)
					
					INSERT INTO EmpAppraisal(EmpId,DocumentNo,AppraisalStatus,RatingLevel,AppraisalNo,
					AppraisalDate, EnterBy, EnterDate,AppraisalText,AppraisalResult,CompetenceResult,
					ObjectiveResult, QuestionResult,EmpAppraisalRYear
					,EmpAppraisalRNo,EmpAppraisalRIssueDate,EmpAppraisalRExecDate,EmpAppraisalRStatus, EmpAppraisalRSource, EmpAppraisalRDesc)
						VALUES (@empid,@docno,ISNULL(@AppraisalStatus,0),@AppraisalRatingLevel,ISNULL(@AppraisalNo,0)
					,@Date,cast(@EnterBy AS INT),@EnterDate,ISNULL(@OtherInfo,''),ISNULL(@Manual,0),ISNULL(@CompetenceResult,0),ISNULL(@ObjectiveResult,0),ISNULL(@QuestionResult,0)
				   , ISNULL(lTRIM(cast(@Cur_RYear AS SMALLINT)),ISNULL(cast(@RefYear AS SMALLINT),0))
				   ,ISNULL(Cast(@Cur_RNo AS NVARCHAR(10)),ISNULL(Cast(@RefNum AS NVARCHAR(10)),''))
					,ISNULL(convert(DATETIME,@Cur_IssueDate,111),CASE WHEN @IssueDate='NULL' THEN NULL ELSE convert(DATETIME,@IssueDate,111) END)
					,ISNULL(convert(DATETIME,@Cur_ExecDate,111),CASE WHEN @ExecDate='NULL' THEN NULL ELSE convert(DATETIME,@ExecDate,111) END)
		           ,ISNULL(lTRIM(cast(@Cur_RStatus AS SMALLINT)),CASE WHEN @RefStatus='NULL' THEN NULL ELSE cast(@RefStatus AS SMALLINT) END)
		           ,ISNULL(lTRIM(cast(@Cur_RSource AS SMALLINT)),CASE WHEN @RefSource='NULL' THEN NULL ELSE cast(@RefSource AS SMALLINT) END) 
		          , ISNULL(@Cur_RDesc,ISNULL(@RrfDesc,'')))
					--VALUES (@empid,@docno,ISNULL(@AppraisalStatus,0),@AppraisalRatingLevel,ISNULL(@AppraisalNo,0)
					--,@Date,cast(@EnterBy AS INT),@EnterDate,ISNULL(@OtherInfo,''),ISNULL(@Manual,0),ISNULL(@CompetenceResult,0),ISNULL(@ObjectiveResult,0),ISNULL(@QuestionResult,0)
					--,ISNULL(cast(@RefYear AS SMALLINT),0),ISNULL(Cast(@RefNum AS NVARCHAR(10)),'')
					--,CASE WHEN @IssueDate='NULL' THEN NULL ELSE convert(DATETIME,@IssueDate,111) END 
					--,CASE WHEN @ExecDate='NULL' THEN NULL ELSE  convert(DATETIME,@ExecDate,111) END,
					--CASE WHEN @RefStatus='NULL' THEN NULL ELSE cast(@RefStatus AS SMALLINT) END,
					--CASE WHEN @RefSource='NULL' THEN NULL ELSE cast(@RefSource AS SMALLINT) END,ISNULL(@RrfDesc,'')) 

					SELECT  @ErrorValue=@@ERROR
					IF @ErrorValue<>0
					BEGIN
					SELECT @ErrorMsg=@ErrorMsg + ' Insertion Error: ' +sqlmessages.[description] 
					FROM SQLmessages WHERE [error]=@ErrorValue

					EXEC (N'UPDATE '+ @tablename + ' SET Remarks = Remarks + '''+@ErrorMsg+''' WHERE Row_Number = '+ @Row_Number)
					END

					--IF @enableAttachments=1 AND @AttachmentPath<>''
				 IF @enableAttachments=1 AND ISNULL(@cur_AttachPath,@AttachmentPath)<>'' AND @ErrorValue=0 

					BEGIN

					INSERT INTO Attachments
					(
					EmpId,FormNo,DocumentNo,SubDocumentNo,SubDocumentIdentity,AttachmentDescription,AttachmentADescription,	AttachmentPath,EnterBy,EnterDate
					)
					VALUES
					(
					@EmpId,6,@docno,0,0,ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachDesc,@AttachmentDesc),ISNULL(@cur_AttachPath,@AttachmentPath),cast(@EnterBy AS INT),convert(datetime,@EnterDateAttachment,111)
					)

					END 
					PRINT @workflow
					IF upper(@workflow) = 1 AND @AppraisalStatus =5
					BEGIN
						DECLARE @Ssdocno AS SMALLINT 
                        EXEC dbo.GetSSDocNo 6,@AppraisalNo,@Ssdocno OUTPUT
					PRINT 'insert into Wf doc'
					INSERT INTO WFDocument(DocumentNo, EmpID, SSDocNo, StartDate,EnterDate, EnterBy)
					VALUES(@docno,@empid,@Ssdocno,GETDATE(),@EnterDate,cast(@EnterBy AS INT ))
					END

					---Insert UDF

					DECLARE TempTable_cursor2 CURSOR FOR SELECT UDF FROM #UDFTemp 
					OPEN TempTable_cursor2
					FETCH NEXT FROM TempTable_cursor2 INTO @Cursor_UDF
					WHILE @@FETCH_STATUS = 0
					BEGIN 
					SET @select =	'SELECT @UDFValueOut=UDF' + @Cursor_UDF+' FROM '+ @tablename + ' WHERE Row_Number = '+ STR(@Row_Number)
					Exec sp_executesql  @select, N'@UDFValueOut nvarchar(max) OUTPUT', @UDFValueOut = @UDFCrsr_FieldValue OUTPUT
					
					PRINT '@cursorUDF'+@Cursor_UDF
					
					SELECT  @FieldType = FieldType
					FROM UserFieldsNames WHERE formno = 11 AND fieldno = CONVERT(SMALLINT, @Cursor_UDF)
					IF @FieldType = 4 --date
					BEGIN
					INSERT INTO UserFieldsValues (ProfileId,DocumentNo,FormNo,FieldNo,FieldValue,FieldAValue)
					VALUES(@empid,@docno,11,CONVERT(SMALLINT,@Cursor_UDF),convert(NVARCHAR(8),convert(smalldatetime,@UDFCrsr_FieldValue,@DateFormat),112),convert(NVARCHAR(8),convert(smalldatetime,@UDFCrsr_FieldValue,@DateFormat),112))
					END
					Else IF @FieldType=2 --multi selection
					BEGIN

						SET @UDFCrsr_FieldValue=CAST((SELECT FieldItemNo FROM UserFieldsItems 
						WHERE FormNo=11 AND FieldNo=@Cursor_UDF AND LTRIM(RTRIM(@UDFCrsr_FieldValue)) = case when @lang ='E' 
						then ltrim(rtrim(FieldItemValue))ELSE CASE WHEN @lang ='A' THEN FieldItemAValue END END)AS NVARCHAR(254))
					 INSERT INTO UserFieldsValues (ProfileId,DocumentNo,FormNo,FieldNo,FieldValue,FieldAValue)
					 VALUES(@empid,@docno,11,CONVERT(SMALLINT,@Cursor_UDF),@UDFCrsr_FieldValue,@UDFCrsr_FieldValue)
						END
					ELSE
					BEGIN
					INSERT INTO UserFieldsValues (ProfileId,DocumentNo,FormNo,FieldNo,FieldValue,FieldAValue)
					VALUES(@empid,@docno,11,CONVERT(SMALLINT,@Cursor_UDF),@UDFCrsr_FieldValue,@UDFCrsr_FieldValue)
					END	 												
					set @ErrorValue=@@ERROR
					IF @ErrorValue<>0   
					SELECT @ErrMsg=@ErrMsg+' UDf'+ltrim(rtrim(str(@Cursor_UDF)))+ ' error: '+sqlmessages.[description] 
					FROM SQLmessages WHERE [error]=@ErrorValue

					FETCH NEXT FROM TempTable_cursor2 into @Cursor_UDF

					END
					CLOSE TempTable_cursor2
					DEALLOCATE TempTable_cursor2

					FETCH next FROM Appraisalcursor
					INTO @empid,@AppraisalNo,@Date,@AppraisalStatus,@AppraisalRatingLevel,@Manual,@CompetenceResult,@ObjectiveResult,@QuestionResult,@OtherInfo,@Row_Number
						,@Cur_RYear , @Cur_RNo , @Cur_IssueDate , @Cur_ExecDate ,@Cur_RStatus , @Cur_RSource , @Cur_RDesc,@cur_AttachDesc , @cur_AttachPath

					END 
					CLOSE Appraisalcursor
					DEALLOCATE Appraisalcursor
					
					END 
					IF @actiontype=2 --export
					BEGIN

					DECLARE @str AS nvarchar(max),@Cursor_FieldNo nchar(4),@t AS nvarchar(150),@count AS INT
					DECLARE actiontype2_cursor2 CURSOR FOR SELECT * FROM #UDFTemp 
					OPEN actiontype2_cursor2
					FETCH NEXT FROM actiontype2_cursor2 INTO @Cursor_UDF
					WHILE @@FETCH_STATUS = 0
					BEGIN
					SET @str=@str+'''0'' as UDF'+@Cursor_FieldNo+','	
					FETCH NEXT FROM actiontype2_cursor2 into @Cursor_UDF	
					END
					CLOSE actiontype2_cursor2
					DEALLOCATE actiontype2_cursor2	
					--------------------------------------------------------
					SET @t=@tablename
					SET @t=replace(@t,'dbo.[','')
					SET @t=replace(@t,']','')
					select @count=count(*) FROM sysobjects s WHERE s.name=@t


					IF @actual>0 SET @str='select 0 as empid,'''' as name,'''' as [AppraisalName], getdate() as [Date],'''' as [Status],'''' as [RatingLevel],'''' as [Manual],'''' as [CompetenceResult],'''' as [ObjectiveResult],'''' as [QuestionResult],'''' as [OtherInfo],'''' as remarks WHERE 1<>1'
					ELSE

					IF @count=1 SET @str='select * from '+@tablename
					ELSE
					SET @str='select 0 as empid,'''' as name,'''' as [AppraisalName], getdate() as [Date],'''' as [Status],'''' as [RatingLevel],'''' as [Manual],'''' as [CompetenceResult],'''' as [ObjectiveResult],'''' as [QuestionResult],'''' as [OtherInfo],'''' as remarks WHERE 1<>1'
					exec sp_executesql @str

					END

					IF @actiontype=3 --import

					BEGIN
					  SELECT @enableRef= EnableReferences ,@enableAttachments=enableattachments FROM SysParam 


					SET @ColumnsStr = replace (@ColumnsStr,'WP_GetExternalAppraisalWMR_ar','')
					SET @ColumnsStr = replace (@ColumnsStr,'WP_GetExternalAppraisalWMR','') 

					DECLARE @updatestr AS nvarchar(max),@updatestrUDF AS NVARCHAR(max),
					@insertstr AS nvarchar(max),@insertstrUDF AS NVARCHAR(max),@deletestr AS nvarchar(max),
					@selectstr AS nvarchar(max),@selectstrUDF AS NVARCHAR(max),@DisabledColStr AS nvarchar(100),
					@CreateStrRefAttach AS nvarchar(max)='', @SelectStrRefAttach AS nvarchar(max)='', @InsertStrRefAttach AS nvarchar(max)='', @UpdateStrRefAttach AS nvarchar(max)=''



					SET @updatestr=''
					SET @updatestrUDF=''
					SET @insertstr=''
					SET @insertstrUDF=''
					SET @selectstr=''
					SET @selectstrUDF=''

					PRINT @ColumnsStr

					DECLARE @TableNamelen AS int 
					SET @TableNamelen=len(@TableName)-charindex('[nasbatch',@TableName)-1
					IF rtrim(ltrim(@tablename))<>'' 
					BEGIN
        -------------------------------------------------------------------
	   IF  @enableRef = 1
		SET @CreateStrRefAttach='[RYear] [smallint],[RNo] [nvarchar](10),[RIssueDate] [datetime],[RExecDate] [datetime]
					,[RStatus] [nvarchar](30),[RSource] [nvarchar](30),[RDesc] [nvarchar](max) ,'

		IF @enableAttachments=1
		SET @CreateStrRefAttach= @CreateStrRefAttach+' AttDesc [nvarchar](max), AttPath [nvarchar](max),'
		-------------------------------------------------------------

					SET @select ='IF not EXISTS(SELECT top 1 1
					FROM '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns 
					WHERE  '+PARSENAME(@tablename,3)+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+PARSENAME(@tablename,1)+''')'
					+' CREATE TABLE ' + @tablename+ ' (empid nvarchar(50),name nvarchar(256),
					 [AppraisalName] nvarchar(120),[Date] smalldatetime ,[Status] nvarchar(20),[RatingLevel] nvarchar(20)
					 ,[Manual] NUMERIC(18,3),[CompetenceResult] NUMERIC(18,3),[ObjectiveResult] NUMERIC(18,3),[QuestionResult] NUMERIC(18,3),[OtherInfo] nvarchar(256),'+@ColumnsStr+@CreateStrRefAttach+ ' post bit, remarks nvarchar(256),[Row_Number] int Identity(1,1) NOT NULL Primary Key)'
					END
					ELSE
					BEGIN

					SET @tablename='  '

					DECLARE selectstr2_cursor CURSOR FOR SELECT * FROM #UDFTemp 
					OPEN selectstr2_cursor
					FETCH NEXT FROM selectstr2_cursor into @Cursor_UDF
					WHILE @@FETCH_STATUS = 0
					BEGIN
					SET @selectstrUDF=@selectstrUDF+' '' 0'' as UDF'+@Cursor_UDF+','
					FETCH NEXT FROM selectstr2_cursor into @Cursor_UDF	
					END
					CLOSE selectstr2_cursor
					DEALLOCATE selectstr2_cursor 
					-------------------------------
					 IF  @enableRef = 1
		              SET @SelectStrRefAttach=' 0  as [RYear] ,'''' as [RNo], '''' as [RIssueDate] , '''' as [RExecDate] 
	                    , ''''  as [RStatus] ,''''  as [RSource] ,'''' as [RDesc] ,'

		              IF @enableAttachments=1
		                        SET @SelectStrRefAttach= @SelectStrRefAttach+' ''''  as AttDesc , ''''  as AttPath ,'


					SET @selectstr='select 0 as empid,'''' as name,'''' as [AppraisalName], getdate() as [Date],'''' as [Status],'''' as [RatingLevel],'''' as [Manual],'''' as [CompetenceResult],'''' as [ObjectiveResult],'''' as [QuestionResult],'''' as [OtherInfo],'+@selectstr+@selectstrUDF+@SelectStrRefAttach+' 0 as post,'''' as remarks WHERE 1<>1'
					END
					PRINT @select	
					DECLARE update_cursor2 CURSOR FOR SELECT * FROM #UDFTemp 
					OPEN update_cursor2
					FETCH NEXT FROM update_cursor2 INTO @Cursor_UDF
					WHILE @@FETCH_STATUS = 0
					BEGIN
					SET @updatestrUDF=@updatestrUDF+' UDF'+@Cursor_UDF+'=@UDF'+@Cursor_UDF+', '
					SET @insertstrUDF=' @UDF'+@Cursor_UDF+','	
					FETCH NEXT FROM update_cursor2 into @Cursor_UDF	
					END
					CLOSE update_cursor2
					  -----------------------------------------------------------------------------------------------------	
          IF  @enableRef = 1 
               SET @UpdateStrRefAttach=' RYear=ltrim(rtrim(@RYear)), RNo=ltrim(rtrim(@RNo))
                   , RIssueDate=convert(datetime,@RIssueDate,'+ltrim(rtrim(str(@DateFormat)))+')
                  , RExecDate =convert(datetime,@RExecDate,'+ltrim(rtrim(str(@DateFormat)))+')
                 ,RStatus=ltrim(rtrim(@RStatus)), RSource=ltrim(rtrim(@RSource)), RDesc=ltrim(rtrim(@RDesc)),'

                 IF @enableAttachments=1
                      SET @UpdateStrRefAttach= @UpdateStrRefAttach+' AttDesc=ltrim(rtrim(@AttDesc)) , AttPath=ltrim(rtrim(@AttPath)) ,'
					

					SET @updatestr=' update '+@tablename+' set [Date] = convert(datetime,@Date,'+ltrim(rtrim(str(@DateFormat)))+'),[AppraisalName]=@AppraisalName,[Status]=@Status,
					[RatingLevel]=@Ratinglevel ,[Manual]=@Manual,[CompetenceResult]=@CompetenceResult,
					[ObjectiveResult]=@ObjectiveResult,[QuestionResult]=@QuestionResult,[OtherInfo]=@OtherInfo,'+@updatestrUDF+@UpdateStrRefAttach+' post=@post
					where isnull(Row_Number,0)= isnull(@originalRow_Number,0)'
					
					PRINT 'Update Appraisal' + @updatestr
					-----------------------------------------------
					IF  @enableRef = 1  
                       	SET @InsertStrRefAttach=' @RYear, @RNo, @RIssueDate, @RExecDate 
				               	,@RStatus, @RSource, @RDesc, '
                       IF @enableAttachments=1
	                     SET @InsertStrRefAttach= @InsertStrRefAttach+' @AttDesc , @AttPath ,'

					SET @insertstr=' insert into '+@tablename+' select @empid ,
					@name ,@AppraisalName,@Date ,@Status ,@RatingLevel,
					@Manual,@CompetenceResult,@ObjectiveResult,@QuestionResult,@OtherInfo,'+@insertstr+@insertstrUDF+@InsertStrRefAttach+' @post ,@remarks'

					SET @deletestr=' delete from  '+@tablename
					+' where isnull(Row_Number,0)= isnull(@originalRow_Number,0)'

					SELECT @count=COUNT(UDF) FROM #UDFTemp 
					 IF  @enableRef = 1  SET @count=@count+7
                     IF  @enableAttachments = 1  SET @count=@count+2
					SET @count=@count+13 
					SET @DisabledColStr='1,2,'+ltrim(rtrim(str(@count)))
					exec sp_executesql @select
					SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr

					END

					END

GO

