
CREATE PROCEDURE [dbo].[ABKPayrollChanges] (@filterselect NVARCHAR(max),@filterwhere NVARCHAR(max),@StatusCode NVARCHAR(50)) 
	
AS
--declare @filterselect NVARCHAR(4000),@filterwhere NVARCHAR(4000)
--	SELECT @filterselect=' , 0 as GroupLevel1 , '''' as GroupName1 , 0 as GroupLevel2 , '''' as GroupName2, 0 as GroupLevel3 , '''' as GroupName3 , 0 as GroupLevel4 , '''' as GroupName4, 0 as GroupLevel5 , '''' as GroupName5, 0 as GroupLevel6 , '''' as GroupName6, 0 as GroupLevel7 , '''' as GroupName7, 0 as GroupLevel8 , '''' as GroupName8  ' 
--	, @filterwhere=' and EmpAssignment.EmployeeId=99997775'
	
BEGIN
	
DECLARE @Select AS NVARCHAR(max),@From AS NVARCHAR(max)
DECLARE @changeStathdrfilterwhere AS NVARCHAR(max)
DECLARE @changeStatdtlfilterwhere AS NVARCHAR(max)
SET @changeStathdrfilterwhere=''
SET @changeStatdtlfilterwhere=''
SET @filterwhere= @filterwhere+' and 1=1'

if (CHARINDEX(' AND EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere))>0
begin
SET @changeStathdrfilterwhere=SUBSTRING(@filterwhere,CHARINDEX(' AND EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere),CHARINDEX('And',@filterwhere,CHARINDEX('EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere))-CHARINDEX(' AND EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere))
SET @filterwhere=REPLACE(@filterwhere ,SUBSTRING(@filterwhere,CHARINDEX(' AND EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere),CHARINDEX('And',@filterwhere,CHARINDEX('EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere))-CHARINDEX(' AND EMPSTATUSHDR.DOCUMENTSTATUS',@filterwhere)) , ' ')
END

if (CHARINDEX(' AND EMPSTATUSDTL.FIELDNO',@filterwhere))>0
BEGIN
SET @changeStatdtlfilterwhere=@changeStatdtlfilterwhere +' '+ SUBSTRING(@filterwhere,CHARINDEX(' AND EMPSTATUSDTL.FIELDNO',@filterwhere),CHARINDEX('And',@filterwhere,CHARINDEX('EMPSTATUSDTL.FIELDNO',@filterwhere))-CHARINDEX(' AND EMPSTATUSDTL.FIELDNO',@filterwhere))
SET @filterwhere=REPLACE(@filterwhere ,SUBSTRING(@filterwhere,CHARINDEX(' AND EMPSTATUSDTL.FIELDNO',@filterwhere),CHARINDEX('And',@filterwhere,CHARINDEX('EMPSTATUSDTL.FIELDNO',@filterwhere))-CHARINDEX(' AND EMPSTATUSDTL.FIELDNO',@filterwhere)) , ' ')
END

if(CHARINDEX(' AND EMPSTATUSHDR.CHGCODE',@filterwhere))>0
BEGIN
SET @changeStathdrfilterwhere=@changeStathdrfilterwhere +' '+ SUBSTRING(@filterwhere,CHARINDEX(' AND EMPSTATUSHDR.CHGCODE',@filterwhere),CHARINDEX('And',@filterwhere,CHARINDEX('EMPSTATUSHDR.CHGCODE',@filterwhere))-CHARINDEX(' AND EMPSTATUSHDR.CHGCODE',@filterwhere))
SET @filterwhere=REPLACE(@filterwhere ,SUBSTRING(@filterwhere,CHARINDEX(' AND EMPSTATUSHDR.CHGCODE',@filterwhere),CHARINDEX('And',@filterwhere,CHARINDEX('EMPSTATUSHDR.CHGCODE',@filterwhere))-CHARINDEX(' AND EMPSTATUSHDR.CHGCODE',@filterwhere)) , ' ')
END

if(CHARINDEX(' AND ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere))>0
BEGIN
SET @changeStathdrfilterwhere=@changeStathdrfilterwhere +' '+ SUBSTRING(@filterwhere,CHARINDEX(' AND ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere),CHARINDEX(')',@filterwhere,CHARINDEX(' ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere))+1-CHARINDEX(' AND ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere))
SET @filterwhere=REPLACE(@filterwhere ,SUBSTRING(@filterwhere,CHARINDEX(' AND ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere),CHARINDEX(')',@filterwhere,CHARINDEX(' ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere))+1-CHARINDEX(' AND ( EMPSTATUSHDR.EFFECTIVEDATE Between  ',@filterwhere)) , ' ')
END

SET @filterwhere=' where 1=1 '+@filterwhere

PRINT @filterwhere
-- Temp table to save data
---------------------------
CREATE TABLE #Temp
(
	EmpId INT,
	EmployeeId NVARCHAR(50),
	Name NVARCHAR(88),
	EffectiveDate SMALLDATETIME,
	DocumentNo INT,
	PayrollGroup SMALLINT,
	PayrollGroupName NCHAR(60),
	Cur SMALLINT,
	CurName NCHAR(30),
	Old_JT NCHAR(250),
	New_JT NCHAR(250),
	Old_Org NVARCHAR(250),
	New_Org NVARCHAR(250),
	OldSal NUMERIC(18,3),
	NewSal NUMERIC(18,3),
	IncAmount NUMERIC(18,3),
	IncPer NUMERIC(18,3),
	Old_GD NVARCHAR(250),
	New_GD NVARCHAR(250),
	OldHousingAllowance NUMERIC(18,3),
	NewHousingAllowance NUMERIC(18,3),
	OldCarAllowance NUMERIC(18,3),
	NewCarAllowance NUMERIC(18,3),
	StatusName NCHAR(20), --for resigned row
	GroupLevel1 int,
    GroupName1 NChar(250),  
    GroupLevel2 int,
    GroupName2 NChar(250),  
    GroupLevel3 int,
    GroupName3 NChar(250),  
    GroupLevel4 int,
    GroupName4 NChar(250),  
    GroupLevel5 int,
    GroupName5 NChar(250),  
    GroupLevel6 int,
    GroupName6 NChar(250),  
    GroupLevel7 int,
    GroupName7 NChar(250),
    GroupLevel8 INT,
    GroupName8 NCHAR(250)
)

-- Insert Main Data from EmpStatusHdr ( EmpId,DocNo,EffectiveDate )
--------------------------------------------------------------------
SET @Select='	
SELECT Distinct
EmpAssignment.EmpId,
EmpAssignment.EmployeeId,
Profile.Name,
case when EmpStatusDtl.DocumentNo is NULL then NULL else EmpStatusHdr.EffectiveDate End,
EmpStatusDtl.DocumentNo,
PayrollGroup.PayrollGroup,
PayrollGroup.PayrollGroupName,
Currency.cur,
Currency.CurName ' 

SET @From = '
FROM EmpAssignment
CROSS JOIN SysParam   
LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
LEFT JOIN EmpStatusHdr on EmpAssignment.EmpId = EmpStatusHdr.EmpId and EmpStatusHdr.DocumentStatus = 1  and SysParam.nhirechgcd <> EmpStatusHdr.ChgCode'+@changeStathdrfilterwhere+'
LEFT JOIN EmpStatusDtl on EmpStatusDtl.EmpId = EmpStatusHdr.EmpId and EmpStatusDtl.FieldNo IN (5,6,7,14,1105,1110)'+@changeStatdtlfilterwhere+'
 And EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo 
LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo 
LEFT JOIN Grades ON Grades.Grade = EmpAssignment.Grade 
LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job 
LEFT JOIN JobCat ON JobCat.jobcat=Jobs.jobcat
LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo 
LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode 
LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus 
LEFT JOIN PayrollGroup on EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup 
LEFT JOIN Currency ON Currency.cur = PayrollGroup.Currency
LEFT JOIN CostCntr on CostCntr.Center = EmpAssignment.Center
LEFT JOIN CostCGrp ON CostCGrp.centergrp=CostCntr.centergrp
LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId
LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization 
LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType 
LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization 
LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 
LEFT JOIN NasArrays Status ON Status.itemno = EmpAssignment.Status AND Status.arrayname = ''Status'' 
LEFT JOIN NasArrays ChangeField ON EmpStatusDtl.FieldNo = ChangeField.itemno 
 AND ChangeField.arrayname = ''ChngStatus''
LEFT JOIN SSDocumentStatus ON EmpStatusHdr.DocumentStatus = SSDocumentStatus.SSDocStatusNo
LEFT JOIN ChngStat ON EmpStatusHdr.ChgCode = ChngStat.ChgCode
'


PRINT @Select 
print @filterselect 
print @From 
print @filterwhere

INSERT INTO #Temp
(   EmpId ,
	EmployeeId ,
	Name ,
	EffectiveDate ,
	DocumentNo ,
	PayrollGroup,
	PayrollGroupName,
	Cur,
	CurName,
	GroupLevel1,
	GroupName1,
	GroupLevel2,
	GroupName2,
	GroupLevel3,
	GroupName3,
	GroupLevel4,
	GroupName4,
	GroupLevel5,
	GroupName5,
	GroupLevel6,
	GroupName6,
	GroupLevel7,
	GroupName7,
	GroupLevel8,
	GroupName8)

EXEC( @Select + ' '  + @filterselect + ' '  + @From + ' ' +  @filterwhere) 
DELETE FROM #Temp WHERE EmpId IN (SELECT EmpId FROM #Temp GROUP BY EmpId HAVING COUNT(EmpId)>1 ) AND #Temp.DocumentNo IS NULL 
--UPDATE #Temp SET #Temp.EffectiveDate = NULL WHERE #Temp.DocumentNo is NULL
--SELECT * FROM #Temp
-----------------------------------------------------------------------------------------------
-- Update Job
-------------
exec('UPDATE #Temp
SET Old_JT =  case when EmpStatusDtl.FieldNo = 5 then dbo.GetOldValueTxt(5,dbo.GetOldValue(#Temp.EmpId,5,#Temp.EffectiveDate,NULL),''E'') else NULL END,
    New_JT =  case when EmpStatusDtl.FieldNo = 5 then Jobs.JobName else dbo.GetOldValueTxt(5,dbo.GetOldValue(#Temp.EmpId,5,#Temp.EffectiveDate,NULL),''E'')END
FROM #Temp
LEFT JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = #Temp.EmpId AND EmpStatusDtl.DocumentNo = #Temp.DocumentNo and EmpStatusDtl.FieldNo = 5'+@changeStatdtlfilterwhere+'
LEFT JOIN Jobs ON Jobs.job = EmpStatusDtl.NewValue
 ')
----------------------------------
-- update org
--------------
EXEC('UPDATE #Temp
SET Old_Org = case when EmpStatusDtl.FieldNo=6 then dbo.GetOldValueTxt(6,dbo.GetOldValue(#Temp.EmpId,6,#Temp.EffectiveDate,NULL),''E'') else NULL END,
    New_Org = case when EmpStatusDtl.FieldNo=6 then Organization.OrganizationName else dbo.GetOldValueTxt(6,dbo.GetOldValue(#Temp.EmpId,6,#Temp.EffectiveDate,NULL),''E'') END
FROM #Temp
LEFT JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = #Temp.EmpId AND EmpStatusDtl.DocumentNo = #Temp.DocumentNo and EmpStatusDtl.FieldNo=6  '+@changeStatdtlfilterwhere+'  
LEFT JOIN Organization ON Organization.Organization = EmpStatusDtl.NewValue
')
----------------------------------------------------
-- update grade
----------------
exec('UPDATE #Temp
SET Old_GD = case when EmpStatusDtl.FieldNo=7 then dbo.GetOldValueTxt(7,dbo.GetOldValue(#Temp.EmpId,7,#Temp.EffectiveDate,NULL),''E'') else NULL END,
    New_GD = case when EmpStatusDtl.FieldNo=7 then Grades.GradeName else dbo.GetOldValueTxt(7,dbo.GetOldValue(#Temp.EmpId,7,#Temp.EffectiveDate,NULL),''E'') END
FROM #Temp
LEFT JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = #Temp.EmpId AND EmpStatusDtl.DocumentNo = #Temp.DocumentNo and EmpStatusDtl.FieldNo=7'+@changeStatdtlfilterwhere+'
LEFT JOIN Grades ON Grades.Grade = EmpStatusDtl.NewValue
')
-----------------------------------------------------
-- update basic sal
---------------------
exec('UPDATE #Temp
SET OldSal = case when EmpStatusDtl.FieldNo=14 then dbo.GetOldValue(#Temp.EmpId,14,#Temp.EffectiveDate,#Temp.Cur) else NULL END,
    NewSal = case when EmpStatusDtl.FieldNo=14 then dbo.ConvertAmount(EmpStatusDtl.NewValue,EmpStatusHdr.HRCurrency,#Temp.Cur,#Temp.EffectiveDate) else dbo.GetOldValue(#Temp.EmpId,14,#Temp.EffectiveDate,#Temp.Cur) END
FROM #Temp
LEFT JOIN EmpStatusHdr ON EmpStatusHdr.EmpId = #Temp.EmpId AND EmpStatusHdr.DocumentNo = #Temp.DocumentNo
LEFT JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = #Temp.EmpId AND EmpStatusDtl.DocumentNo = #Temp.DocumentNo and EmpStatusDtl.FieldNo=14'+@changeStatdtlfilterwhere+'
')
-----------------------------------------------------
-- Update Basic Sal (IncAmnt,IncPercentage)
-------------------------------------------
UPDATE #Temp
SET IncAmount = #Temp.NewSal - #Temp.OldSal ,
    IncPer = CASE WHEN #Temp.OldSal = 0 THEN 100 ELSE ((( #Temp.NewSal - #Temp.OldSal ) / #Temp.OldSal ) * 100)END
FROM #Temp
WHERE #Temp.OldSal IS NOT NULL 
------------------------------------------------------
-- Update Housing
------------------
exec('UPDATE #Temp
SET OldHousingAllowance = case when EmpStatusDtl.FieldNo = 1105 then dbo.GetOldValue(#Temp.EmpId,1105,#Temp.EffectiveDate,#Temp.Cur) else NULL END,
    NewHousingAllowance = case when EmpStatusDtl.FieldNo = 1105 then dbo.ConvertAmount(EmpStatusDtl.NewValue,EmpStatusHdr.HRCurrency,#Temp.Cur,#Temp.EffectiveDate) else dbo.GetOldValue(#Temp.EmpId,1105,#Temp.EffectiveDate,#Temp.Cur) END
FROM #Temp
LEFT JOIN EmpStatusHdr ON EmpStatusHdr.EmpId = #Temp.EmpId AND EmpStatusHdr.DocumentNo = #Temp.DocumentNo
LEFT JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = #Temp.EmpId AND EmpStatusDtl.DocumentNo = #Temp.DocumentNo and EmpStatusDtl.FieldNo = 1105'+@changeStatdtlfilterwhere+'
')
------------------------------------------------------
-- Update Car
--------------
exec('UPDATE #Temp
SET OldCarAllowance = case when EmpStatusDtl.FieldNo = 1110 then dbo.GetOldValue(#Temp.EmpId,1110,#Temp.EffectiveDate,#Temp.Cur) else NULL END,
    NewCarAllowance = case when EmpStatusDtl.FieldNo = 1110 then dbo.ConvertAmount(EmpStatusDtl.NewValue,EmpStatusHdr.HRCurrency,#Temp.Cur,#Temp.EffectiveDate) else dbo.GetOldValue(#Temp.EmpId,1110,#Temp.EffectiveDate,#Temp.Cur) END
FROM #Temp
LEFT JOIN EmpStatusHdr ON EmpStatusHdr.EmpId = #Temp.EmpId AND EmpStatusHdr.DocumentNo = #Temp.DocumentNo
LEFT JOIN EmpStatusDtl ON EmpStatusDtl.EmpId = #Temp.EmpId AND EmpStatusDtl.DocumentNo = #Temp.DocumentNo and EmpStatusDtl.FieldNo = 1110'+@changeStatdtlfilterwhere+'
')
------------------------------------------------------- 


-----------------insert top1 of  hirining information

-----------------insert top1 of  hirining information
exec('INSERT INTO #Temp (EmpId,EmployeeId,NAME,PayrollGroup,PayrollGroupName,Cur,CurName,EffectiveDate,New_JT,New_Org,NewSal
            ,New_GD,NewHousingAllowance,NewCarAllowance
 ,GroupLevel1,GroupName1,GroupLevel2,GroupName2,	GroupLevel3,GroupName3,	GroupLevel4,GroupName4,	GroupLevel5,
	GroupName5,	GroupLevel6,GroupName6,	GroupLevel7,GroupName7,	GroupLevel8,GroupName8)
                 SELECT  #temp.EmpId,
                         #temp.EmployeeId,
                         #temp.Name,
                         #temp.PayrollGroup,
                         #temp.PayrollGroupName,
                         #temp.cur,
                         #temp.CurName,
                         EmpStatusHdr.EffectiveDate
                         ,max(case when EmpStatusDtl.FieldNo=5 then jobs.JobName else null END)
                         ,max(case when EmpStatusDtl.FieldNo=6 then Organization.OrganizationName else null END)
                         ,max(case when EmpStatusDtl.FieldNo=14 THEN  dbo.ConvertAmount(EmpStatusDtl.NewValue,EmpStatusHdr.HRCurrency,#Temp.Cur,#Temp.EffectiveDate) ELSE NULL END)
                         ,max(case when EmpStatusDtl.FieldNo=7 then grades.Gradename else null END)
                         ,MAX(case when EmpStatusDtl.FieldNo=1105 then dbo.ConvertAmount(EmpStatusDtl.NewValue,EmpStatusHdr.HRCurrency,#Temp.Cur,#Temp.EffectiveDate) ELSE NULL END )
                         ,MAX(case when EmpStatusDtl.FieldNo=1110 then dbo.ConvertAmount(EmpStatusDtl.NewValue,EmpStatusHdr.HRCurrency,#Temp.Cur,#Temp.EffectiveDate) ELSE NULL END )
                          ,#Temp.GroupLevel1,
						  #Temp.GroupName1,
						  #Temp.GroupLevel2,
						  #Temp.GroupName2,
						  #Temp.GroupLevel3,
						  #Temp.GroupName3,
						  #Temp.GroupLevel4,
						  #Temp.GroupName4,
						  #Temp.GroupLevel5,
						  #Temp.GroupName5,
						  #Temp.GroupLevel6,
						  #Temp.GroupName6,
						  #Temp.GroupLevel7,
						  #Temp.GroupName7,
						  #Temp.GroupLevel8,
						  #Temp.GroupName8
                         FROM EmpAssignment
                         inner JOIN #temp ON #temp.EmpId = EmpAssignment.EmpId
                         CROSS JOIN SysParam   
                         LEFT JOIN Profile ON EmpAssignment.EmpId = Profile.ProfileId 
                         LEFT JOIN EmpStatusHdr on EmpAssignment.EmpId = EmpStatusHdr.EmpId and EmpStatusHdr.DocumentStatus = 1  and SysParam.nhirechgcd = EmpStatusHdr.ChgCode 
                         LEFT JOIN EmpStatusDtl on EmpStatusDtl.EmpId = EmpStatusHdr.EmpId and EmpStatusDtl.FieldNo IN (5,6,7,14,1105,1110)
                         And EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo 
                         LEFT JOIN jobs ON EmpStatusDtl.NewValue=jobs.[job] AND EmpStatusDtl.FieldNo=5
                         LEFT JOIN Organization ON EmpStatusDtl.NewValue=Organization.Organization AND empstatusdtl.FieldNo=6
                         LEFT JOIN grades ON  EmpStatusDtl.NewValue=grades.Grade AND empstatusdtl.FieldNo=7
                         where #Temp.EffectiveDate is not null'
                        +' GROUP BY #temp.EmpId,
                         #temp.EmployeeId,
                         #temp.Name,
                         #temp.PayrollGroup,
                         #temp.PayrollGroupName,
                         #temp.cur,
                         #temp.CurName,
                         EmpStatusHdr.EffectiveDate,
                        #Temp.GroupLevel1,
						#Temp.GroupName1,
						#Temp.GroupLevel2,
						#Temp.GroupName2,
						#Temp.GroupLevel3,
						#Temp.GroupName3,
						#Temp.GroupLevel4,
						#Temp.GroupName4,
						#Temp.GroupLevel5,
						#Temp.GroupName5,
						#Temp.GroupLevel6,
						#Temp.GroupName6,
						#Temp.GroupLevel7,
						#Temp.GroupName7,
						#Temp.GroupLevel8,
						#Temp.GroupName8')



--insert row for the changed Hrstatus to resigned                         
                      
exec('INSERT INTO #Temp (EmpId,EmployeeId,NAME,PayrollGroup,PayrollGroupName,Cur,CurName,EffectiveDate,StatusName
,   GroupLevel1,GroupName1,	GroupLevel2,GroupName2,	GroupLevel3,GroupName3,	GroupLevel4,GroupName4,	GroupLevel5,
	GroupName5,	GroupLevel6,GroupName6,	GroupLevel7,GroupName7,	GroupLevel8,GroupName8)                    
				 SELECT  #temp.EmpId,
                         #temp.EmployeeId,
                         #temp.Name,
                         #temp.PayrollGroup,
                         #temp.PayrollGroupName,
                         #temp.cur,
                         #temp.CurName,
                         EmpStatusHdr.EffectiveDate
                        ,HrStatus.HrstatusName  --''Resigned''
                        ,#Temp.GroupLevel1,
						#Temp.GroupName1,
						#Temp.GroupLevel2,
						#Temp.GroupName2,
						#Temp.GroupLevel3,
						#Temp.GroupName3,
						#Temp.GroupLevel4,
						#Temp.GroupName4,
						#Temp.GroupLevel5,
						#Temp.GroupName5,
						#Temp.GroupLevel6,
						#Temp.GroupName6,
						#Temp.GroupLevel7,
						#Temp.GroupName7,
						#Temp.GroupLevel8,
						#Temp.GroupName8
                         
						FROM 
						#temp inner join Empassignment on #temp.EmpId = EmpAssignment.EmpId
						LEFT JOIN EmpStatusHdr ON EmpStatusHdr.EmpId = #temp.EmpId 
						LEFT JOIN EmpStatusDtl ON  EmpStatusDtl.EmpId = EmpStatusHdr.EmpId AND EmpStatusDtl.DocumentNo = EmpStatusHdr.DocumentNo
						left join HrStatus on HrStatus.hrstatus = EmpStatusDtl.NewValue and  EmpStatusDtl.FieldNo=1 
						
				 WHERE EmpStatusDtl.FieldNo=1 
						AND EmpStatusDtl.NewValue IN ('+ @StatusCode+' )
						and EmpStatusHdr.DocumentStatus = 1 
						GROUP BY #temp.EmpId,
						#temp.EmployeeId,
                         #temp.Name,
                         #temp.PayrollGroup,
                         #temp.PayrollGroupName,
                         #temp.cur,
                         #temp.CurName,
                         #Temp.GroupLevel1,
						 #Temp.GroupName1,
						 #Temp.GroupLevel2,
						 #Temp.GroupName2,
						 #Temp.GroupLevel3,
						 #Temp.GroupName3,
						 #Temp.GroupLevel4,
						 #Temp.GroupName4,
						 #Temp.GroupLevel5,
						 #Temp.GroupName5,
						 #Temp.GroupLevel6,
						 #Temp.GroupName6,
						 #Temp.GroupLevel7,
						 #Temp.GroupName7,
						 #Temp.GroupLevel8,
						 #Temp.GroupName8,
                         EmpStatusHdr.EffectiveDate
                         ,HrStatus.HrstatusName')


-- Select report data
--------------------
SELECT  
isnull(#Temp.EffectiveDate,EmpAssignment.HireDate) AS EffectiveDate,
#Temp.EmployeeId AS EmployeeId,
#Temp.Name,
max(isnull(#Temp.Old_JT,'')) AS Old_JT,
max(isnull(#Temp.New_JT,Jobs.JobName)) AS New_JT,
max(isnull(#Temp.Old_Org,'')) AS Old_Org,
max(isnull(#Temp.New_Org,Organization.OrganizationName)) AS New_Org,
max(#Temp.OldSal) AS OldSal,
max(#Temp.IncAmount) as IncAmount,
max(#Temp.IncPer) AS IncPer,
max(isnull(#Temp.NewSal,EmpAssignment.HrBasicSal)) AS NewSal,
max(isnull(#Temp.Old_GD,'')) AS Old_GD,
max(isnull(#Temp.New_GD,Grades.GradeName)) AS New_GD,
max(#Temp.OldHousingAllowance)  AS OldHousingAllowance,
max(#Temp.NewHousingAllowance)  AS NewHousingAllowance,
max(#Temp.OldCarAllowance)  AS OldCarAllowance,
max(#Temp.NewCarAllowance)  AS NewCarAllowance,
max(isnull(#Temp.StatusName,''))  AS StatusName,
#Temp.PayrollGroup,
#Temp.PayrollGroupName,
#Temp.Cur,
#Temp.CurName,
#Temp.GroupLevel1,
#Temp.GroupName1,
#Temp.GroupLevel2,
#Temp.GroupName2,
#Temp.GroupLevel3,
#Temp.GroupName3,
#Temp.GroupLevel4,
#Temp.GroupName4,
#Temp.GroupLevel5,
#Temp.GroupName5,
#Temp.GroupLevel6,
#Temp.GroupName6,
#Temp.GroupLevel7,
#Temp.GroupName7,
#Temp.GroupLevel8,
#Temp.GroupName8
FROM #Temp 
LEFT JOIN EmpAssignment ON EmpAssignment.EmpId = #Temp.EmpId
LEFT JOIN grades ON grades.Grade = EmpAssignment.Grade
LEFT JOIN jobs ON jobs.[job] = EmpAssignment.[Job]
LEFT JOIN organization ON organization.Organization = EmpAssignment.Organization

GROUP BY 
#Temp.EffectiveDate,
#Temp.EmployeeId,
#Temp.Name,
#Temp.PayrollGroup,
#Temp.PayrollGroupName,
#Temp.Cur,
#Temp.CurName,
#Temp.GroupLevel1,
#Temp.GroupName1,
#Temp.GroupLevel2,
#Temp.GroupName2,
#Temp.GroupLevel3,
#Temp.GroupName3,
#Temp.GroupLevel4,
#Temp.GroupName4,
#Temp.GroupLevel5,
#Temp.GroupName5,
#Temp.GroupLevel6,
#Temp.GroupName6,
#Temp.GroupLevel7,
#Temp.GroupName7,
#Temp.GroupLevel8,
#Temp.GroupName8,
Jobs.JobName,
Organization.OrganizationName,
Grades.GradeName,
EmpAssignment.HrBasicSal,
EmpAssignment.HireDate

ORDER BY [dbo].[HitsSort](#Temp.EmployeeId,''),EffectiveDate
--SELECT * FROM #Temp
END

DROP TABLE #Temp
-- Select report data

GO

