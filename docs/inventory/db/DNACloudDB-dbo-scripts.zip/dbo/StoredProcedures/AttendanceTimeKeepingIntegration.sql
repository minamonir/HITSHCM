

CREATE PROCEDURE [dbo].[AttendanceTimeKeepingIntegration] (@UserId AS INT, @where AS NVARCHAR(Max)=N'',@Absent AS INT=0)
AS 
BEGIN

    --EXECUTE UpdateEmpAttendance @where, 0, 0, 1
    --' and TimeRule not in (5) '

	DECLARE @currency AS INT, @str AS NVARCHAR(Max)
	
	SELECT @currency=syscur FROM SysParam 
	 
	CREATE TABLE #TempEmp (EmpId INT, TimeRule INT, PayrollGroup INT)
	SELECT @str='INSERT INTO #TempEmp (EmpId,TimeRule, PayrollGroup)
	SELECT EmpId, TimeRule, PayrollGroup FROM EmpAssignment Where 1=1 ' + ISNULL(@where,'')
	EXEC (@str)
 
	CREATE TABLE #TempPayrollGroups (PayrollGroup INT,CurrentPeriodStart SMALLDATETIME,NextPeriodEnd SMALLDATETIME)
	INSERT INTO #TempPayrollGroups
	SELECT distinct PayrollGroup.PayrollGroup,dbo.periodstart(PayrollGroup.PayrollGroup, 0, 0),dbo.periodend(PayrollGroup.PayrollGroup, 0,0) 
	FROM PayrollGroup
	INNER JOIN #TempEmp ON #TempEmp.PayrollGroup = PayrollGroup.PayrollGroup

	-------Update records with Holiday, dayoff, Vacation code
	UPDATE EA
	SET VacCode = CASE WHEN EA.AttendDate BETWEEN EmpAssignment.HireDate AND isnull(EmpAssignment.TermDate,#TempPayrollGroups.NextPeriodEnd) THEN  (CASE 
	WHEN TimeIn IS NULL AND [TimeOut] IS NULL AND EA.AttendDate BETWEEN EmpVacat.FromDate AND EmpVacat.ToDate AND EmpVacat.VacStatus=1 THEN Vacation.vaccode
	WHEN TimeIn IS NULL AND [TimeOut] IS NULL AND dofftype=1 AND (DATEPART(dw,EA.AttendDate)=doffday1 OR DATEPART(dw,EA.AttendDate)=doffday2) THEN TimeRules.VacDayoff
	WHEN TimeIn IS NULL AND [TimeOut] IS NULL AND Holidays.[date]=EA.AttendDate AND holiday=1 THEN TimeRules.VacHoli 
	ELSE TimeRules.VacAbsent END ) ELSE NULL END 
	, ChangedBy = @UserId, ChangeDate = GETDATE()
	FROM EmpAttendance EA
	INNER JOIN #TempEmp ON #TempEmp.EmpId = EA.EmpId
	INNER JOIN EmpAssignment ON  EmpAssignment.EmpId = Ea.EmpId
	INNER JOIN #TempPayrollGroups ON  #TempPayrollGroups.PayrollGroup = #TempEmp.PayrollGroup
	LEFT JOIN EmpShiftInOut ON EmpShiftInOut.EmpId = EA.EmpId AND EmpShiftInOut.EntryDate=EA.AttendDate
	LEFT JOIN EmpVacat ON EmpVacat.EmpId = EA.EmpId 
		AND EA.AttendDate BETWEEN EmpVacat.FromDate AND EmpVacat.ToDate 
		AND EmpVacat.VacStatus=1
	LEFT JOIN Vacation ON Vacation.vaccode = EmpVacat.VacCode
	LEFT JOIN TimeRules ON TimeRules.TimeRule = #TempEmp.TimeRule
	LEFT JOIN VacPack ON VacPack.vacpack =dbo.GetOldValue(#TempEmp.empid,19,EA.AttendDate+1,@currency)
	LEFT JOIN Holidays ON Holidays.[date] = EA.AttendDate AND Holidays.VacPack = VacPack.vacpack
	WHERE (TimeIn IS NULL OR [TimeOut] IS NULL)
	AND ( CONVERT(NCHAR(10), EA.AttendDate, 120)
	         BETWEEN CONVERT(NCHAR(10), #TempPayrollGroups.CurrentPeriodStart, 120) AND CONVERT(NCHAR(10), #TempPayrollGroups.NextPeriodEnd, 120))
	
	AND (EA.ChangedBy IS NULL OR EA.ChangedBy=@UserId)
	AND ea.SubmitBy IS NULL

	-------Update employees who have a vac. or day off or holiday but actually they have in and out records (so should be updated to be Present)
	UPDATE EA
	SET VacCode = NULL, ChangedBy = @UserId, ChangeDate = GETDATE()
	FROM EmpAttendance EA
	INNER JOIN #TempEmp ON #TempEmp.EmpId = EA.EmpId
	--INNER JOIN EmpAssignment ON  EmpAssignment.EmpId = Ea.EmpId
	INNER JOIN #TempPayrollGroups ON  #TempPayrollGroups.PayrollGroup = #TempEmp.PayrollGroup
	LEFT JOIN EmpShiftInOut ON EmpShiftInOut.EmpId = EA.EmpId AND EmpShiftInOut.EntryDate=EA.AttendDate
	WHERE (TimeIn IS NOT NULL AND [TimeOut] IS NOT NULL)
	AND EA.AttendDate=EmpShiftInOut.EntryDate AND EmpShiftInOut.EmpId=EA.EmpId
	AND (EA.ChangedBy IS NULL OR EA.ChangedBy=@UserId) 
AND ( CONVERT(NCHAR(10), EA.AttendDate, 120)
	         BETWEEN CONVERT(NCHAR(10), #TempPayrollGroups.CurrentPeriodStart, 120) AND CONVERT(NCHAR(10), #TempPayrollGroups.NextPeriodEnd, 120))
AND ea.SubmitBy IS NULL

IF @Absent=1
BEGIN
	
	UPDATE EA
	SET VacCode = CASE WHEN EA.AttendDate BETWEEN EmpAssignment.HireDate AND  isnull(EmpAssignment.TermDate,#TempPayrollGroups.NextPeriodEnd) THEN TimeRules.VacAbsent ELSE NULL END  
	, ChangedBy = @UserId, ChangeDate = GETDATE()
	FROM EmpAttendance EA
	INNER JOIN #TempEmp ON #TempEmp.EmpId = EA.EmpId
    INNER JOIN EmpAssignment ON  EmpAssignment.EmpId = Ea.EmpId
	INNER JOIN #TempPayrollGroups ON  #TempPayrollGroups.PayrollGroup = #TempEmp.PayrollGroup
	LEFT JOIN EmpShiftInOut ON EmpShiftInOut.EmpId = EA.EmpId AND EmpShiftInOut.EntryDate=EA.AttendDate
	LEFT JOIN TimeRules ON TimeRules.TimeRule = #TempEmp.TimeRule
	WHERE EA.VacCode IS NULL AND (TimeIn IS NULL OR [TimeOut] IS NULL)
	AND ( CONVERT(NCHAR(10), EA.AttendDate, 120)
	         BETWEEN CONVERT(NCHAR(10), #TempPayrollGroups.CurrentPeriodStart, 120) AND CONVERT(NCHAR(10), #TempPayrollGroups.NextPeriodEnd, 120))
	--AND ea.SubmitBy IS NULL
END

	DROP TABLE #TempEmp 
	DROP TABLE #TempPayrollGroups
END

GO

