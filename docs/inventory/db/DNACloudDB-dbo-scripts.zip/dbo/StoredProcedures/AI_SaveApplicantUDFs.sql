CREATE PROCEDURE [dbo].[AI_SaveApplicantUDFs]
(
    @userlogonname NVARCHAR(80),
    @empid INT,
    @fieldno SMALLINT,
    @fieldvalue NVARCHAR(254),
    @lang NCHAR(1) = 'E'
)
AS
BEGIN
    SET NOCOUNT ON;
	IF @fieldvalue IS NULL OR LTRIM(RTRIM(@fieldvalue)) = ''
		BEGIN
			RETURN; -- Exit the procedure, do nothing
		END
    DECLARE 
        @FormNo INT = 10,
        @DocumentNo INT = 1;

    DECLARE 
        @error INT,
        @SPResult NVARCHAR(MAX) = '',
        @fieldtype INT;

    SELECT 
        @fieldtype = ufn.FieldType
    FROM UserFieldsNames AS ufn
    WHERE ufn.FieldNo = @fieldno;


    IF @fieldtype IN (4,5)
       AND @fieldvalue LIKE '%19000101%'
    BEGIN
        SET @fieldvalue = '';
    END

    
      -- Update / Insert Logic

    IF EXISTS
    (
        SELECT 1
        FROM dbo.UserFieldsValues
        WHERE FormNo = @FormNo
          AND FieldNo = @fieldno
          AND ProfileId = @empid
          AND DocumentNo = @DocumentNo
    )
    BEGIN
        UPDATE dbo.UserFieldsValues
        SET FieldValue = @fieldvalue,
            FieldAValue = @fieldvalue
        WHERE FormNo = @FormNo
          AND FieldNo = @fieldno
          AND ProfileId = @empid
          AND DocumentNo = @DocumentNo;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.UserFieldsValues
        (
            ProfileId,
            DocumentNo,
            FormNo,
            FieldNo,
            FieldValue,
            FieldAValue
        )
        VALUES
        (
            @empid,
            @DocumentNo,
            @FormNo,
            @fieldno,
            @fieldvalue,
            @fieldvalue
        );
    END


       --Error Handling
    SELECT @error = @@ERROR;

    IF @error <> 0
    BEGIN
        SELECT 
            @SPResult = CASE 
                            WHEN @lang = 'E' THEN description 
                            ELSE Adescription 
                        END
        FROM dbo.SQLmessages
        WHERE error = @error;
    END

    --SELECT '' AS SPResult;
END

GO

