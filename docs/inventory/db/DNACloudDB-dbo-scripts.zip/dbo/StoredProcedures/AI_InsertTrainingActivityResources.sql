
CREATE PROCEDURE [dbo].[AI_InsertTrainingActivityResources] (
	@ActivityNo SMALLINT
	,@ResourceName NVARCHAR(150)
	,@ResourceType NVARCHAR(6) -- SMALLINT as NVARCHAR
	,@ResourceRequired BIT
	,@ResourcesCount SMALLINT
	,@LogonName NVARCHAR(80)
	)
AS
BEGIN
	DECLARE @ResourceNo AS SMALLINT = 0,
			@ResourceTypeNo AS SMALLINT = CAST(@ResourceType AS SMALLINT),
			@ResourceCategory INT
	
	SET @ResourceCategory = ISNULL((
				SELECT TOP 1 ResourceCategory 
				FROM TrainingResourceTypes 
				WHERE TrainingResourceType = @ResourceTypeNo
				), 0)

	SET @ResourceNo = isnull((
				SELECT TOP 1 TrainingResources.TrainingResource
				FROM TrainingResources
				WHERE LTRIM(RTRIM(TrainingResourceName)) = LTRIM(RTRIM(@ResourceName))
					OR LTRIM(RTRIM(TrainingResourceAName)) = LTRIM(RTRIM(@ResourceName))
					AND ResourceCategory = @ResourceCategory
				), 0)

	IF @ResourceNo = 0
	BEGIN
		CREATE TABLE #StoredResultResource (
			PrimaryKey INT,
			IsUEnterByExists INT,
			OrgsColumn INT);

		DECLARE @str AS NVARCHAR(MAX)=' ResourceCategory= ' + STR(@ResourceCategory);
 
		INSERT INTO #StoredResultResource
		EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'TrainingResources',
		@PkFieldName = N'TrainingResource',
		@LogonName = @LogonName,
		@Where=@str;

		SELECT @ResourceNo = PrimaryKey
		FROM #StoredResultResource;

		INSERT INTO TrainingResources (
			[TrainingResource]
			,[ResourceCategory]
			,[TrainingResourceName]
			,[TrainingResourceAName]
			,[TrainingResourceFName]
			,[TrainingResourceType]
			,[UEnterBy]
			,[UEnterDate]
			)
		SELECT @ResourceNo
			,@ResourceCategory
			,@ResourceName
			,@ResourceName
			,@ResourceName
			,@ResourceTypeNo
			,@LogonName
			,GETDATE()
	END
	ELSE
	BEGIN
		UPDATE TrainingResources
		SET [TrainingResourceType] = @ResourceTypeNo, 
			[UChangeBy] = @LogonName,
			[UChangeDate] = GETDATE()
		WHERE [TrainingResource] = @ResourceNo
			AND ResourceCategory = @ResourceCategory
	END

	IF NOT EXISTS (
			SELECT 1
			FROM TrainingActivityResources
			WHERE TrainingActivity = @ActivityNo
				AND TrainingResource = @ResourceNo
				AND ResourceCategory = @ResourceCategory
			)
	BEGIN
		INSERT INTO [dbo].[TrainingActivityResources] (
			[TrainingActivity]
			,[TrainingResource]
			,[ResourceCategory]
			,[TrainingResourcesCount]
			,[TrainingResourceRequired]
			)
		VALUES (
			@ActivityNo
			,@ResourceNo
			,@ResourceCategory
			,@ResourcesCount
			,@ResourceRequired
			)
	END
	ELSE 
	BEGIN
		UPDATE [dbo].[TrainingActivityResources]
		SET [TrainingResourcesCount] = @ResourcesCount, [TrainingResourceRequired] = @ResourceRequired
		WHERE TrainingActivity = @ActivityNo
			AND TrainingResource = @ResourceNo
			AND ResourceCategory = @ResourceCategory 
	END
END

GO

