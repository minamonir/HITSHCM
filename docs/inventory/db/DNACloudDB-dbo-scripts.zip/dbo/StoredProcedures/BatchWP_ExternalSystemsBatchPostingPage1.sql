

CREATE   PROCEDURE  [dbo].[BatchWP_ExternalSystemsBatchPostingPage1]
(
	    @actiontype AS SMALLINT,
	    @tablename as nvarchar(150),
		@actual AS SMALLINT,
		@Where AS NVARCHAR(MAX),
		@Paramaters AS NVARCHAR(MAX),
		@alterTable as bit =0,
		@outputstr AS NVARCHAR(MAX)OUTPUT
)
AS

--drop table DNACLOUDDBBatchTemp.dbo.[Nasbatch4042023091811240073b6e25371034392a721d18d2a2d15e6]
--SELECT * FROM DNACLOUDDBBatchTemp.dbo.[Nasbatch4042023091811240073b6e25371034392a721d18d2a2d15e6]

--declare @actiontype AS SMALLINT=1,
--	    @tablename as nvarchar(150)=N'DNACLOUDDBBatchTemp.dbo.[Nasbatch4042023091811240073b6e25371034392a721d18d2a2d15e6]',
--		@actual AS SMALLINT=0,
--		@Where AS NVARCHAR(MAX)=N'',
--		@Paramaters AS NVARCHAR(MAX)=N'1,2023,9,1,1,E',
--		@alterTable as bit =0,
--		@outputstr AS NVARCHAR(MAX)


BEGIN
DECLARE 
	@StartIndex AS INT,
	@PayrollGroup AS smallint,
	@periodyear AS smallint=0,
	@periodmonth AS SMALLINT=0,
	@RunNo AS SMALLINT=1,
	@LogonName  AS varchar (100),
	@lang AS nCHAR(1),
	@CurrentEmpID as int,
	@CurrentEmployeeID as nvarchar(50),
	@CurrentFormBatch as nvarchar(250),
	@CurrentEmp901tax as numeric(18,3),
	@Row_Number as int,
	@Error AS int,
	@ErrMsg as  nvarchar(max)
declare @select nvarchar(max)
IF @actiontype=1
BEGIN


IF LTRIM(RTRIM(@Paramaters))<>''
BEGIN

	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @PayrollGroup= substring (@Paramaters,0,@StartIndex) 
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')
	
	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @periodyear=isnull(substring(@Paramaters,0,@StartIndex),0)
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')

	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @periodmonth=isnull(substring(@Paramaters,0,@StartIndex),0)
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')

	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @RunNo=isnull(substring(@Paramaters,0,@StartIndex),1)
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')
	SET @StartIndex=CHARINDEX(',',@Paramaters)
	SET @LogonName=isnull(substring(@Paramaters,0,@StartIndex),'')
	set @Paramaters = STUFF(@Paramaters,1,@StartIndex,'')

	SET @lang = isnull(@Paramaters,'E')
	
	
    declare @updatetablestr as nvarchar(MAX), @P901Name as nvarchar(250)

	select @P901Name =case when @lang='e' then PaycodeName else PaycodeAName end  from Paycode where code =901
END

if @alterTable=1
begin
exec('Alter table '+@tablename +' ADD EmpId int, EmployeeId NVARCHAR(50) default ''0'' ,Emp901tax numeric(18,3)
						,FormBatch NVARCHAR(100),processed			nvarchar(MAX) ,Post				bit ,[Row_Number] int identity(1,1) PRIMARY KEY,processtime  datetime NULL,Name  nvarchar(250),OrganizationName  nvarchar(250) , JobName  nvarchar(250) ,HrstatusName  nvarchar(250) ')

--PRINT('update  '+@tablename+' 
--		set EmpId = empassignment.empid,
--		Name = case when '''+@lang +'''=''e'' then profile.Name else profile.AName END , 
--		OrganizationName = case when '''+@lang +'''=''e'' then Organization.OrganizationName else  Organization.OrganizationAName end ,
--		hrstatusname=case when '''+@lang +'''=''e'' then HrStatus.HrstatusName else HrStatus.HrstatusAName end ,
--		jobname=case when EmpAssignment.PositionNo is null then case when '''+@lang +'''=''e'' then Jobs.JobName else Jobs.JobAName end  else case when '''+@lang +'''=''e'' then Positions.PositionName else Positions.PositionAName end end 
--		from '+@tablename+' 
--		inner join empassignment on ltrim(rtrim(empassignment.employeeid)) =ltrim(rtrim('+@tablename+'.[كود الموظف]))
--		left join profile on profile.profileid=empassignment.empid 
--		left join Organization on Organization.Organization=EmpAssignment.Organization 
--		left join HrStatus on HrStatus.hrstatus=EmpAssignment.HrStatus 
--		left join jobs on jobs.job=EmpAssignment.Job  
--		left join Positions on Positions.PositionNo =EmpAssignment.positionno
--		WHERE empassignment.EMPLOYEEID = '+@TABLENAME+N'.[كود الموظف]
--		')

declare @batchguid as nvarchar(250)
set @batchguid=NEWID()

exec('update  '+@tablename+' 
		set EmpId = empassignment.empid,
		Employeeid = empassignment.employeeid,
		Name = case when '''+@lang +'''=''e'' then profile.Name else profile.AName END , 
		OrganizationName = case when '''+@lang +'''=''e'' then Organization.OrganizationName else  Organization.OrganizationAName end ,
		hrstatusname=case when '''+@lang +'''=''e'' then HrStatus.HrstatusName else HrStatus.HrstatusAName end ,
		jobname=case when EmpAssignment.PositionNo is null then case when '''+@lang +'''=''e'' then Jobs.JobName else Jobs.JobAName end  else case when '''+@lang +'''=''e'' then Positions.PositionName else Positions.PositionAName end end 
		,Post=1, FormBatch ='''+ @batchguid+''',Emp901tax =0
		from '+@tablename+' 
		inner join empassignment on ltrim(rtrim(empassignment.employeeid)) =ltrim(rtrim('+@tablename+N'.[كود الموظف]))
		left join profile on profile.profileid=empassignment.empid 
		left join Organization on Organization.Organization=EmpAssignment.Organization 
		left join HrStatus on HrStatus.hrstatus=EmpAssignment.HrStatus 
		left join jobs on jobs.job=EmpAssignment.Job  
		left join Positions on Positions.PositionNo =EmpAssignment.positionno
		WHERE empassignment.EMPLOYEEID = '+@TABLENAME+N'.[كود الموظف]
		')
return	
end 



if RTRIM(LTRIM(@tablename))<>'' 
begin 
exec('UPDATE '+@tablename+' SET  post  = 0,processtime=getdate(),
processed= isnull(dbo.Hits_GetDCCaption(''wp_ExternalStystemBatchPosting'',''EmployeeDoesntExist'','''+@lang+'''),
CASE WHEN '''+@lang+'''=''e'' THEN ''Employee doesnt exist in this payrollgroup'' ELSE N''الموظف غير موجود بالمجموعه الحسابية'' END )
		from '+@tablename +'temp 
		inner join EmpAssignment on ltrim(rtrim(EmpAssignment.Employeeid))=temp.EmployeeId
        WHERE post =1 and empassignment.Payrollgroup <>'+@PayrollGroup)

set @select=('DECLARE Emp901Taxs CURSOR FOR SELECT EmpAssignment.Empid, Emp901tax ,FormBatch,Row_Number 
                                            FROM '+@tablename+ 'temp ' +
                                            ' Inner Join EmpAssignment on ltrim(rtrim(EmpAssignment.EmployeeId)) = ltrim(rtrim(temp.EmployeeId)) '+
                                            '  where post = 1')
exec (@select)	
OPEN Emp901Taxs
FETCH next FROM Emp901Taxs  INTO  @CurrentEmpID , @CurrentEmp901tax , @CurrentFormBatch,@Row_Number
WHILE @@FETCH_STATUS=0
BEGIN
select @Error =0 ,@ErrMsg=''

--if exists(select * from MonthlyTransaction where empid = @CurrentEmpID and paycode = 901 and runno = @RunNo )
--	BEGIN
--		update MonthlyTransaction set  Amount = @CurrentEmp901tax , InputAmnt = @CurrentEmp901tax  where EmpID = @CurrentEmpID and RunNo = @RunNo  and paycode = 901 AND Amount <>@CurrentEmp901tax
--		  SET @Error=@@ERROR
--		  IF @error<>0
--          SELECT @ErrMsg=@ErrMsg+ 'error: '+sqlmessages.[description]   
--		  FROM SQLmessages WHERE [error]=@error   
--	END
--ELSE 
--	BEGIN
--	   INSERT INTO MonthlyTransaction(EmpId, RunNo, Paycode, InputAmnt, Amount)
--	   SELECT @CurrentEmpID,@RunNo ,901,@CurrentEmp901tax,@CurrentEmp901tax
--	    SET @Error=@@ERROR
--		IF @error<>0
--        SELECT @ErrMsg=@ErrMsg+ 'error: '+sqlmessages.[description]   
--		FROM SQLmessages WHERE [error]=@error   
--	END
IF @error =''
begin
if exists(select * from EmpETaxResults where empid = @CurrentEmpID  and payrollgroup = @PayrollGroup and Year = @periodyear and month = @periodmonth and runno = @RunNo and batchid = @CurrentFormBatch )
	BEGIN 
	update EmpETaxResults set  P901Amount = @CurrentEmp901tax,BatchDate = GETDATE(),Username =@LogonName where empid = @CurrentEmpID  and payrollgroup = @PayrollGroup and Year = @periodyear and month = @periodmonth and runno = @RunNo and batchid = @CurrentFormBatch AND P901Amount <>@CurrentEmp901tax
		    SET @Error=@@ERROR
		IF @error<>0
        SELECT @ErrMsg=@ErrMsg+ 'error: '+sqlmessages.[description]   
		FROM SQLmessages WHERE [error]=@error   
	END
ELSE
	BEGIN
		insert into EmpETaxResults (payrollgroup,year,month,runno,batchid,batchdate,empid,p901amount,username,otherinfo) 
	    SELECT @PayrollGroup, @periodyear,@periodmonth, @RunNo,@CurrentFormBatch  ,GetDate(),@CurrentEmpID,@CurrentEmp901tax,@logonname,'Success'
		 SET @Error=@@ERROR
		IF @error<>0
        SELECT @ErrMsg=@ErrMsg+ 'error: '+sqlmessages.[description]   
		FROM SQLmessages WHERE [error]=@error   
	END
END 
--Hits_GetDCCaption related with Database DNACloudDB201909
select @errMsg =case when @errMsg='' THEN case WHEN @lang='e' THEN  N'Paycode ' ELSE N' البند' end +@P901Name+' '+ ISNULL(dbo.Hits_GetDCCaption('wp_ExternalStystemBatchPosting','updatedSuccess',@lang),  CASE WHEN @lang='e' THEN 'updated Successfuly' ELSE N'تم تحديثه بنجاح' END ) else @errMsg end 
set @updatetablestr='update '+@tablename+' set processtime = getdate() , processed = N'''+replace(cast(@ErrMsg AS NVARCHAR(250)),'''','''''')+N''' where  '+@tablename+'.Row_Number = '+ str(ltrim(rtrim(@Row_Number )))
exec(@updatetablestr)

FETCH next FROM Emp901Taxs  INTO  @CurrentEmpID , @CurrentEmp901tax , @CurrentFormBatch,@Row_Number
end	
close Emp901Taxs
deallocate Emp901Taxs
--exec('select * from ' +@tablename)


END


----exec ('select * from '+ @tableName)
create Table #temp(ColumnName nvarchar(max), itemkey nvarchar(max))


insert into #temp(ColumnName,itemkey)
--select N'مسلسل' , '1'
--Union 
--select N'كود الموظف' , 'Employeeid'
--Union 
--select N'اسم الموظف' , 'Employee Name'
--Union 
--select N'الجنسية / الحالة التعاقدية' ,'2'
--Union select N'الرقم القومي' ,'2'
--Union select N'رقم جواز السفر' ,'2'
--Union select N'رقم التليفون' ,'2'
--Union select N'حالة تصريح العمل لغير المصريين' ,'2'
--Union select N'رقم تصريح العمل' ,'2'
--Union select N'الوظيفة' ,'2'
--Union select N'الدرجة الوظيفية' ,'2'
--Union select N'اسم الجهة/الفرع' ,'2'
--Union select N'المعاملة الضريبية' ,'2'
--Union select N'رقم التسجيل الضريبي لجهة العمل الأصلية' ,'2'
--Union select N'الحالة التأمينية' ,'2'
--Union select N'الرقم التأمينى' ,'2'
--Union select N'تاريخ الالتحاق بالتأمينات' ,'2'
--Union select N'قسط مدة سابقة/أنظمة تأمينية بديلة' ,'2'
--Union select N'تاريخ نهاية الخدمة' ,'2'
--Union select N'تاريخ انتهاء الاشتراك من التأمينات الاجتماعية' ,'2'
--Union select N'الأجر الشامل' ,'2'
--Union select N'بدلات غير خاضعة تأمينيأ' ,'2'
--Union
select N'الأجر التأميني' , 'EI110'
--Union select N'حالة التأمين  الصحي الشامل','2' 
--Union select N'عدد الزوجات الغير عاملات (التأمين الصحي الشامل)' ,'2'
--Union select N'عدد المعالين (التأمين الصحي  الشامل)' ,'2'
--Union select N'مدة العمل' ,'2'
--Union select N'الاجر الوظيفى' ,'2'
--Union select N'الاجر المكمل' ,'2'
--Union select N'علاوة دورية مقررة بقانون الخدمة المدنية' ,'2'
--Union select N'علاوه  تشجيعية' ,'2'
--Union select N'علاوة الحافز العلمى' ,'2'
--Union select N'علاوة استثنائية' ,'2'
--Union select N'حافز تعويضي' ,'2'
--Union select N'المرتب الاساسى  المجرد' ,'2'
--Union select N'علاوات مضمومة' ,'2'
--Union select N'العلاوة الاجتماعية/الإضافية' ,'2'
--Union select N'علاوة غلاء معيشة' ,'2'
--Union select N'المرتب الأساسي' ,'2'
--Union select N'مكافات وحوافز/أجر إضافي/منح' ,'2'
--Union select N'علاوات خاصة معفاة' ,'2'
--Union select N'علاوات خاصة خاضعة' ,'2'
--Union select N'عمولات' ,'2'
--Union select N'نصيب العامل في الأرباح' ,'2'
--Union select N'مقابل الخدمة' ,'2'
--Union select N'البقشيش' ,'2'
--Union select N'مرتبات ومكافات رؤساء اعضاء مجلس الادارة (مقابل العمل الإداري)' ,'2'
--Union select N'المقابل النقدى لرصيد الاجازات أثناء الخدمة' ,'2'
--Union select N'مكافأة نهاية الخدمة الخاضعة' ,'2'
--Union select N'مبالغ منصرفة بقوانين خاصة (الجزء المعفي منها)' ,'2'
--Union select N'إضافات وبدلات اخرى خاضعة' ,'2'
--Union select N'ما تحملته المنشاة من ضريبة مرتبات' ,'2'
--Union select N'ما تحملته المنشاة من التأمينات الاجتماعية' ,'2'
--Union select N'مبالغ خاضعة منصرفة بصورة ربع سنوية' ,'2'
--Union select N'مبالغ خاضعة منصرفة بصورة نصف سنوية' ,'2'
--Union select N'مبالغ خاضعة منصرفة بصورة  سنوية' ,'2'
--Union select N'مزايا: السيارات' ,'2'
--Union select N'مزايا: الهواتف المحمولة' ,'2'
--Union select N'مزايا: قروض وسلف' ,'2'
--Union select N'مزايا: التأمين على الحياة (حصة صاحب العمل)' ,'2'
--Union select N'مزايا: اسهم الشركة داخل مصر او خارج مصر' ,'2'
--Union select N'مزايا أخرى' ,'2'
Union select N'اجمالى الاستحقاقات', 'DTE295' 
Union select N'حصة العامل فى التأمينات الإجتماعية  والمعاشات' , 'DAE405'
Union select N'حصة العامل المستقطعة في التأمين الصحي الشامل' , 'DAE410'
Union select N'مبالغ معفاة  بقوانين خاصة', 'DAE415' 
Union select N'علاوات خاصة معفاة' , 'DAE420'
Union select N'العلاوة الاجتماعية/الإضافية لجهات حكومية و ق.ع. وغير خاضع للخدمة المدنية' , 'DAE425'
Union select N'الاعفاء الشخصى' , 'DAE430'
Union select N'اقساط (مدة سابقة/اعارة/اعتبارية)' , 'DAE435'
Union select N'نصيب العامل في الأرباح', 'DAE440'
Union select N'الدمغة النسبية' , 'DAE445'
--Union select N'اشتراكات العاملين فى صناديق التامين التى تنشاء طبقا لاحكام ق 54 لسنة 75' ,'2'
--Union select N'أقساط التأمين على حياة الممول لمصلحتة ومصلحةزوجته وأولاده القصر' ,'2'
--Union select N'أقساط التأمين الصحي' ,'2'
--Union select N'أقساط تأمين لإستحقاق معاش' ,'2'
Union select N'إجمالي اشتراكات صناديق التأمين', 'DAE470' 
Union select N'اجمالى الاستقطاعات' , 'DAE475'
Union select N'صافى الدخل (وعاء الفترة)' , 'TC505'
Union select N'الوعاء السنوى' , 'TC510'
Union select N'الضريبة  المستحقة من بداية الفترة للعمالة الاصلية', 'TC515' 
Union select N'الضريبة  المستحقة من بداية الفترة للعمالة المدرجه بنموذج 3 مرتبات' , 'TC520'
Union select N'الضريبة المستحقة من بداية الفترة للعمالة المدرجه بنموذج 2 مرتبات' , 'TC525'
Union select N'اجمالى الضريبة المستحقة عن جميع انواع العمالة' , 'TC530'
Union select N'الضريبة المحتسبة عن الفترة' , 'TC535'
Union select N'الضريبة المحتسبة عن الفترات السابقة للمعاملات الضريبية 1 و4 و5 و6 و7','TC540' 
Union select N'الضريبة المحتسبة عن الفترة للمعاملات الضريبية 1 و4 و5 و6 و7' , 'TC545'
Union select N'الضريبة المحتسبة عن الفترات السابقة للمعاملة ضريبية 2' ,'TC550'
Union select N'الضريبة المحتسبة عن الفترة للمعاملة ضريبية 2' , 'TC555'
Union select N'الضريبة المحتسبة عن الفترات السابقة للمعاملة ضريبية 3' ,'TC560'
Union select N'الضريبة المحتسبة عن الفترة للمعاملة ضريبية 3' , 'TC565'
Union select N'صافي الأجر النهائي' ,'END705'
Union select N'مشاركه اجتماعيه استقطاع لصندوق الشهداء وما فى حكمها', 'NAD610' 
Union select N'دعم ذوي الهمم (قانون 200 لسنة 2020)', 'CLD825'
--Union select N'اضافات: قيمة السلفة/قروض' ,'2'
--Union select N'اضافات: قيمة مكافأة نهاية الخدمة الغير خاضعة' ,'2'
--Union select N'اضافات: قيمة رصيد الأجازات الغير خاضعة' ,'2'
--Union select N'اضافات أخرى' ,'2'
--Union select N'استقطاعات: نفقة' ,'2'
--Union select N'استقطاعات: قيمة قسط السلفة/القرض' ,'2'
--Union select N'استقطاعات: اشتراكات نقابات/أندية' ,'2'
--Union select N'استقطاعات: جزاءات' ,'2'
--Union select N'استقطاعات: قيمة قسط بوليصة التأمين على الحياة' ,'2'
--Union select N'استقطاعات أخرى' ,'2'
Union select N'حصة الشركة في التأمينات الاجتماعية' ,'CLD805'
Union select N'حصة الشركة في التأمين الصحي الشامل' ,'CLD810'
Union select N'المساهمة فى صندوق الشهداء', 'CLD815'
Union select N'الدمغات' , 'CLD820'
--Union select N'المبالغ المحولة فعلياً','2'


----select * from #temp where itemkey not in ('1','2')
----order by itemkey
declare @set_Items as nvarchar(max)='set'

select  @set_Items = @set_Items + ' ['+itemkey+'] = isnull(['+ColumnName +'],0.00)' +','from #temp
select @set_Items = SUBSTRING(@set_Items,1,len(@set_Items)-1)

exec('
update EmpETaxResults '+@set_Items+'  
from '+@TableName+ 't where EmpETaxResults.empid = t.empid and EmpETaxResults.payrollgroup = '+@PayrollGroup+' and EmpETaxResults.year = '+@periodyear+' and EmpETaxResults.month = '+@periodmonth+' and EmpETaxResults.runno = '+@RunNo)


drop  table #temp 




END 

IF @actiontype=3
BEGIN

    DECLARE @updatestr       AS NVARCHAR(MAX)
           ,@insertstr       AS NVARCHAR(MAX)
           ,@deletestr       AS NVARCHAR(MAX)
           ,@selectstr       AS NVARCHAR(MAX)
           ,@DisabledColStr  AS NVARCHAR(Max)


		   IF RTRIM(LTRIM(@tablename))<>'' 
		BEGIN
			DECLARE @TableNamelen AS INT 
			SET @TableNamelen = LEN(@TableName)-CHARINDEX('[nasbatch' ,@TableName)-1
--			SET @select = 'IF not EXISTS(SELECT top 1 1
--						FROM '+SUBSTRING(@tablename ,0 ,CHARINDEX('.dbo' ,@tablename))+'.INFORMATION_SCHEMA.Columns 
--						WHERE  '+SUBSTRING(@tablename ,0 ,CHARINDEX('.dbo' ,@tablename))+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+SUBSTRING(@TableName,CHARINDEX('[nasbatch' ,@TableName)+1,@TableNamelen)+''')'
--						+'CREATE TABLE '+@tablename+'(EmployeeId NVARCHAR(50) default ''0'' ,Emp901tax numeric(18,3)
--						,FormBatch NVARCHAR(100),processed			nvarchar(MAX) ,Post				bit ,[Row_Number] int identity(1,1) PRIMARY KEY
--						,EI110 numeric(18, 3)
--,DAE410 numeric(18, 3)
--,CLD805 numeric(18, 3)
--,CLD810   numeric(18, 3)
--,DTE295  numeric(18, 3)
--,DAE415 numeric(18, 3)
--,DAE420 numeric(18, 3)
--,DAE425 numeric(18, 3)
--,DAE430 numeric(18, 3)
--,DAE435 numeric(18, 3)
--,DAE440 numeric(18, 3)
--,DAE445 numeric(18, 3)
--,DAE470 numeric(18, 3)
--,DAE475 numeric(18, 3)
--,TC505 numeric(18, 3)
--,TC510 numeric(18, 3)
--,TC515 numeric(18, 3)
--,TC520 numeric(18, 3)
--,TC525 numeric(18, 3)
--,TC530 numeric(18, 3)
--,TC535 numeric(18, 3)
--,TC540 numeric(18, 3)
--,TC545 numeric(18, 3)
--,TC550 numeric(18, 3)
--,TC555 numeric(18, 3)
--,TC560 numeric(18, 3)
--,TC565 numeric(18, 3)
--,END705 numeric(18, 3)
--,NAD610 numeric(18, 3) 
--,CLD825 numeric(18, 3)
--,CLD815 numeric(18, 3)
--,CLD820 numeric(18, 3))'

SET @select = 'IF not EXISTS(SELECT top 1 1
						FROM '+SUBSTRING(@tablename ,0 ,CHARINDEX('.dbo' ,@tablename))+'.INFORMATION_SCHEMA.Columns 
						WHERE  '+SUBSTRING(@tablename ,0 ,CHARINDEX('.dbo' ,@tablename))+'.INFORMATION_SCHEMA.Columns.TABLE_NAME='''+SUBSTRING(@TableName,CHARINDEX('[nasbatch' ,@TableName)+1,@TableNamelen)+''')'
						+'CREATE TABLE '+@tablename+N'([مسلسل] int NULL,
	[كود الموظف] nvarchar(50) NULL,
	[اسم الموظف] nvarchar(max) NULL,
	[الجنسية / الحالة التعاقدية] nvarchar(max) NULL,
	[الرقم القومي] nvarchar(max) NULL,
	[رقم جواز السفر] nvarchar(max) NULL,
	[رقم جواز السفر الجديد] nvarchar(max) NULL,
	[رقم التليفون] nvarchar(max) NULL,
	[حالة تصريح العمل لغير المصريين] nvarchar(max) NULL,
	[رقم تصريح العمل] nvarchar(max) NULL,
	[الوظيفة] nvarchar(max) NULL,
	[الدرجة الوظيفية] nvarchar(max) NULL,
	[اسم الجهة/الفرع] nvarchar(max) NULL,
	[المعاملة الضريبية] nvarchar(max) NULL,
	[رقم التسجيل الضريبي لجهة العمل الأصلية] nvarchar(max) NULL,
	[الحالة التأمينية] nvarchar(max) NULL,
	[الرقم التأمينى] nvarchar(max) NULL,

	[تاريخ الالتحاق بالتأمينات] nvarchar(max) NULL,
	--[تاريخ الالتحاق بالتأمينات] smalldatetime NULL,
	
	[قسط مدة سابقة/أنظمة تأمينية بديلة] numeric(18,3) NULL,
	
	[تاريخ نهاية الخدمة]  nvarchar(max) NULL,
	--[تاريخ نهاية الخدمة] smalldatetime NULL,

	[تاريخ انتهاء الاشتراك من التأمينات الاجتماعية]  nvarchar(max) NULL,
	--[تاريخ انتهاء الاشتراك من التأمينات الاجتماعية] smalldatetime NULL,

	[الأجر الشامل] numeric(18,3) NULL,
	[بدلات غير خاضعة تأمينيأ] numeric(18,3) NULL,
	[الأجر التأميني] numeric(18,3) NULL,
	[حالة التأمين  الصحي الشامل] Int NULL,
	[عدد الزوجات الغير عاملات (التأمين الصحي الشامل)] numeric(18,3) NULL,
	[عدد المعالين (التأمين الصحي  الشامل)] numeric(18,3) NULL,
	[مدة العمل] numeric(18,3) NULL,
	[الاجر الوظيفى] numeric(18,3) NULL,
	[الاجر المكمل] numeric(18,3) NULL,
	[علاوة دورية مقررة بقانون الخدمة المدنية] numeric(18,3) NULL,
	[علاوه  تشجيعية] numeric(18,3) NULL,
	[علاوة الحافز العلمى] numeric(18,3) NULL,
	[علاوة استثنائية] numeric(18,3) NULL,
	[حافز تعويضي] numeric(18,3) NULL,
	[المرتب الاساسى  المجرد] numeric(18,3) NULL,
	[علاوات مضمومة] numeric(18,3) NULL,
	[العلاوة الاجتماعية/الإضافية] numeric(18,3) NULL,
	[علاوة غلاء معيشة] numeric(18,3) NULL,
	[المرتب الأساسي] nvarchar(max) NULL,
	[مكافات وحوافز/أجر إضافي/منح] numeric(18,3) NULL,
	[علاوات خاصة معفاة1] numeric(18,3) NULL,
	[علاوات خاصة خاضعة] numeric(18,3) NULL,
	[عمولات] numeric(18,3) NULL,
	[نصيب العامل في الأرباح1] numeric(18,3) NULL,
	[مقابل الخدمة] numeric(18,3) NULL,
	[البقشيش] numeric(18,3) NULL,
	[مرتبات ومكافات رؤساء اعضاء مجلس الادارة (مقابل العمل الإداري)] numeric(18,3) NULL,
	[المقابل النقدى لرصيد الاجازات أثناء الخدمة] numeric(18,3) NULL,
	[مكافأة نهاية الخدمة الخاضعة] numeric(18,3) NULL,
	[مبالغ منصرفة بقوانين خاصة (الجزء المعفي منها)] numeric(18,3) NULL,
	[إضافات وبدلات اخرى خاضعة] numeric(18,3) NULL,
	[ما تحملته المنشاة من ضريبة مرتبات] numeric(18,3) NULL,
	[ما تحملته المنشاة من التأمينات الاجتماعية] numeric(18,3) NULL,
	[مبالغ خاضعة منصرفة بصورة ربع سنوية] numeric(18,3) NULL,
	[مبالغ خاضعة منصرفة بصورة نصف سنوية] numeric(18,3) NULL,
	[مبالغ خاضعة منصرفة بصورة  سنوية] numeric(18,3) NULL,
	[مزايا: السيارات] numeric(18,3) NULL,
	[مزايا: الهواتف المحمولة] numeric(18,3) NULL,
	[مزايا: قروض وسلف] numeric(18,3) NULL,
	[مزايا: التأمين على الحياة (حصة صاحب العمل)] numeric(18,3) NULL,
	[مزايا: اسهم الشركة داخل مصر او خارج مصر] numeric(18,3) NULL,
	[مزايا أخرى] numeric(18,3) NULL,
	[اجمالى الاستحقاقات] numeric(18,3) NULL,
	[حصة العامل فى التأمينات الإجتماعية  والمعاشات] numeric(18,3) NULL,
	[حصة العامل المستقطعة في التأمين الصحي الشامل] numeric(18,3) NULL,
	[مبالغ معفاة  بقوانين خاصة] numeric(18,3) NULL,
	[علاوات خاصة معفاة] numeric(18,3) NULL,
	[العلاوة الاجتماعية/الإضافية لجهات حكومية و ق.ع. وغير خاضع للخدمة المدنية] numeric(18,3) NULL,
	[الاعفاء الشخصى] numeric(18,3) NULL,
	[اقساط (مدة سابقة/اعارة/اعتبارية)] numeric(18,3) NULL,
	[نصيب العامل في الأرباح] numeric(18,3) NULL,
	[الدمغة النسبية] numeric(18,3) NULL,
	[اشتراكات العاملين فى صناديق التامين التى تنشاء طبقا لاحكام ق 54 لسنة 75] numeric(18,3) NULL,
	[اشتراكات العاملين فى صناديق التامين التى تنشأ طبقا لاحكام ق 155 لسنة 2024] numeric(18,3) NULL,
	[أقساط التأمين على حياة الممول لمصلحتة ومصلحةزوجته وأولاده القصر] numeric(18,3) NULL,
	[أقساط التأمين الصحي] numeric(18,3) NULL,
	[أقساط تأمين لإستحقاق معاش] numeric(18,3) NULL,
	[إجمالي اشتراكات صناديق التأمين] numeric(18,3) NULL,
	[اجمالى الاستقطاعات] numeric(18,3) NULL,
	[صافى الدخل (وعاء الفترة)] numeric(18,3) NULL,
	[الوعاء السنوى] numeric(18,3) NULL,
	[الضريبة  المستحقة من بداية الفترة للعمالة الاصلية] numeric(18,3) NULL,
	[الضريبة  المستحقة من بداية الفترة للعمالة المدرجه بنموذج 3 مرتبات] numeric(18,3) NULL,
	[الضريبة المستحقة من بداية الفترة للعمالة المدرجه بنموذج 2 مرتبات] numeric(18,3) NULL,
	[اجمالى الضريبة المستحقة عن جميع انواع العمالة] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترة] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترات السابقة للمعاملات الضريبية 1 و4 و5 و6 و7] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترة للمعاملات الضريبية 1 و4 و5 و6 و7] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترات السابقة للمعاملة ضريبية 2] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترة للمعاملة ضريبية 2] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترات السابقة للمعاملة ضريبية 3] numeric(18,3) NULL,
	[الضريبة المحتسبة عن الفترة للمعاملة ضريبية 3] numeric(18,3) NULL,
	[صافي الأجر النهائي] numeric(18,3) NULL,
	[مشاركه اجتماعيه استقطاع لصندوق الشهداء وما فى حكمها] numeric(18,3) NULL,
	[دعم ذوي الهمم (قانون 200 لسنة 2020)] numeric(18,3) NULL,
	[اضافات: قيمة السلفة/قروض] numeric(18,3) NULL,
	[اضافات: قيمة مكافأة نهاية الخدمة الغير خاضعة] numeric(18,3) NULL,
	[اضافات: قيمة رصيد الأجازات الغير خاضعة] numeric(18,3) NULL,
	[اضافات أخرى] numeric(18,3) NULL,
	[استقطاعات: نفقة] numeric(18,3) NULL,
	[استقطاعات: قيمة قسط السلفة/القرض] numeric(18,3) NULL,
	[استقطاعات: اشتراكات نقابات/أندية] numeric(18,3) NULL,
	[استقطاعات: جزاءات] numeric(18,3) NULL,
	[استقطاعات: قيمة قسط بوليصة التأمين على الحياة] numeric(18,3) NULL,
	[استقطاعات أخرى] numeric(18,3) NULL,
	[حصة الشركة في التأمينات الاجتماعية] numeric(18,3) NULL,
	[حصة الشركة في التأمين الصحي الشامل] numeric(18,3) NULL,
	[المساهمة فى صندوق الشهداء] numeric(18,3) NULL,
	[الدمغات] numeric(18,3) NULL,
	[المبالغ المحولة فعلياً] numeric(18,3) NULL)'

	--print @select
		END
		else
		begin
		SET @tablename='  '
		--SET @selectstr='SELECT ''0'' as  EmployeeID,0 as Emp901tax,'''' as FormBatch,'''' as processed,0 as Post WHERE 1<>1'
		SET @selectstr='SELECT ''0'' as  EmployeeID,0 as Emp901tax,'''' as FormBatch,'''' as processed,0 as Post WHERE 1<>1'
		END
			SET @updatestr=''

	SET @insertstr=''
	SET @deletestr=''
	SET @DisabledColStr=''
	--	SET @updatestr=' 	update '+@tablename+'set Emp901tax=@Emp901tax,EmployeeId=@EmpID,FormBatch=@FormBatch
	--, Post=@post,processed=@remarks
	--where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'
    SET @updatestr=' 	update '+@tablename+'set Post=1, processed=@remarks
	where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'

	--SET @insertstr=' insert into '+@tablename+' select isnull(@EmpID,''0''),@Emp901tax,@FormBatch,@remarks,@post)'
	--SET @deletestr=' delete from  '+@tablename+' where isnull(ltrim(rtrim([Row_Number])),0)=isnull(ltrim(rtrim(@originalRow_Number)),0)'


--	declare @str109 as nvarchar(max) = ''
--SELECT TOP  109 @str109 = @str109+ cast(ROW_NUMBER()  OVER (ORDER BY (SELECT NULL)) as nvarchar)+','
--FROM sys.all_columns a CROSS JOIN sys.all_columns b
--set @str109= SUBSTRING(@str109,1,len(@str109)-1)
--SET @DisabledColStr=ltrim(rtrim(@str109))

    SET @DisabledColStr= '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109'

	exec sp_executesql @select

	SELECT @updatestr AS updatestr,@insertstr AS insertstr,@deletestr AS deletestr,@DisabledColStr AS DisabledColStr
end

end

GO

