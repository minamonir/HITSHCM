CREATE PROCEDURE [dbo].[BatchWP_GetExternalBenefitItemsDataFile] (@tablename as nvarchar(150),@lang AS nchar(1),@activitydate smalldatetime)
AS

BEGIN
    DECLARE @planno SMALLINT =7 
	DECLARE @optionno SMALLINT=7 -- it will be used only in employees has no plans 
	DECLARE @ItemName NVARCHAR(60)
	DECLARE @empid int, @docno int, @itemno SMALLINT, @Percentage NVARCHAR(20), @amount NVARCHAR(max)  ,@newItemno SMALLINT 
	DECLARE @errormsg AS NVARCHAR(max)	, @rowno AS SMALLINT 	
	CREATE TABLE #temp (employeeid NVARCHAR(50),ItemName NVARCHAR(60),BenefitItemPercent nvarchar(20), Amount NVARCHAR(max), Post BIT, remarks NVARCHAR(MAX),Row_Number smallint)
	INSERT INTO #temp
	EXEC('SELECT f002,f003,f004,f005,post,remarks,Row_Number FROM '+@tablename)
	DELETE TOP (1) FROM #temp

	---------------------Insert Benefit Items Setup ------------------------------------------------

	DECLARE BenefitItemsCursor CURSOR FOR SELECT distinct ltrim(rtrim(#temp.ItemName))  FROM #temp 
										  LEFT join BenefitItems ON LTRIM(rtrim(#temp.ItemName))  =CASE WHEN @lang='e' THEN ltrim(rtrim(BenefitItems.ItemName)) ELSE ltrim(rtrim(BenefitItems.ItemAName)) END 
										  WHERE #temp.Post=1 and (rtrim(ltrim(isnull(#temp.remarks,'')))='' ) AND BenefitItems.ItemNo IS NULL 
	OPEN BenefitItemsCursor 
	FETCH NEXT FROM BenefitItemsCursor INTO @ItemName
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		IF NOT EXISTS (SELECT * FROM dbo.BenefitItems WHERE CASE WHEN @lang='e' THEN ltrim(rtrim(BenefitItems.ItemName)) ELSE ltrim(rtrim(BenefitItems.ItemAName)) END  = @ItemName )
	    BEGIN
	    	SELECT @newItemno = MAX(ISNULL(itemno,0))+1  FROM BenefitItems
			INSERT INTO dbo.BenefitItems(itemno,ItemName, ItemAname, DebitorCredit )
			SELECT @newItemno, @ItemName, @ItemName, 1 
			
			INSERT INTO BenefitPlanItems(PlanNo, OptionNo, ItemNo)
			SELECT @planno,@optionno,@newItemno
	    END
	
	FETCH NEXT FROM BenefitItemsCursor INTO @ItemName
	END
	CLOSE BenefitItemsCursor 
	DEALLOCATE BenefitItemsCursor


	----------------------Insert EmpBenefit --------------------------------------------------------
							    			 
   DECLARE EmpBenefit_Cursor CURSOR FOR SELECT DISTINCT EmpAssignment.empid
							FROM #temp
							LEFT JOIN dbo.EmpAssignment ON EmpAssignment.EmployeeId = #temp.employeeid
							LEFT JOIN dbo.EmpBenefit ON EmpBenefit.EmpId = EmpAssignment.EmpId AND EmpBenefit.PlanNo=@planno AND EmpBenefit.BenefitStatus=1 AND empbenefit.Closed=0
							WHERE EmpBenefit.empid IS NULL AND #temp.employeeid IS NOT NULL
	OPEN EmpBenefit_Cursor 
	FETCH NEXT FROM EmpBenefit_Cursor INTO @empid
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		INSERT INTO dbo.EmpBenefit(EmpId ,Documentno,BenefitStatus ,Closed, Planno , Optionno , enrolldate)
		SELECT @empid,dbo.GetDocumentNo(@empid ,7),1,0,@planno,@optionno,@activitydate
		FETCH NEXT FROM EmpBenefit_Cursor  INTO @empid
	END
	CLOSE EmpBenefit_Cursor  
	DEALLOCATE EmpBenefit_Cursor 

	----------Insert EmpBenefit Items---------------------------------------------------------------------------
	DECLARE EmpBenefitItemsCursor CURSOR FOR SELECT DISTINCT EmpBenefit.EmpId, EmpBenefit.DocumentNo, BenefitItems.ItemNo,LTRIM(RTRIM(t.BenefitItemPercent)), LTRIM(RTRIM(t.Amount)) ,t.Row_Number
										FROM #temp t
										LEFT JOIN dbo.EmpAssignment ON EmpAssignment.EmployeeId = t.employeeid
										LEFT JOIN dbo.EmpBenefit ON EmpBenefit.EmpId = EmpAssignment.EmpId 
										AND empbenefit.PlanNo=@planno AND empbenefit.BenefitStatus=1 AND empbenefit.Closed=0
										AND empbenefit.EnrollDate=(SELECT MAX(enrolldate) 
										                           FROM empbenefit eb 
																   WHERE eb.empid =empassignment.empid
																   AND eb.PlanNo=@planno AND eb.BenefitStatus=1 )
										LEFT join BenefitItems ON CASE WHEN @lang='e' THEN LTRIM(RTRIM(BenefitItems.ItemName)) ELSE LTRIM(RTRIM(BenefitItems.ItemAName)) END = LTRIM(RTRIM(t.ItemName))  
										WHERE t.Post=1 and (LTRIM(RTRIM(ISNULL(t.remarks,'')))='' ) AND t.employeeid IS NOT NULL 
	OPEN EmpBenefitItemsCursor 
	FETCH NEXT FROM EmpBenefitItemsCursor INTO @empid, @docno,@itemno,@Percentage, @amount,@rowno
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		        IF NOT EXISTS (SELECT * FROM dbo.EmpBenefitItems WHERE EmpId=@empid AND DocumentNo=@docno AND ItemNo=@itemno AND activitydate=@activitydate)
	                 BEGIN
		                  INSERT INTO dbo.EmpBenefitItems	( EmpId, DocumentNo, ItemNo, ActivityDate, ActivityAmount, Reference )
			              SELECT @empid, @docno, @itemno, @activitydate ,@amount,@Percentage
                     END 
                  ELSE 
                  	BEGIN
                  		UPDATE EmpBenefitItems SET ActivityAmount=@amount,Reference=@Percentage WHERE EmpId=@empid AND DocumentNo=@docno AND itemno= @itemno AND ActivityDate=@activitydate
                  	END
                  EXEC (' update '+@tablename +' set processtime =getdate() where Row_number =  '+@rowno)
	     
		FETCH NEXT FROM EmpBenefitItemsCursor INTO @empid, @docno, @itemno,@Percentage, @amount,@rowno	
	END
	CLOSE EmpBenefitItemsCursor 
	DEALLOCATE EmpBenefitItemsCursor
  END   

  DROP TABLE #temp

GO

