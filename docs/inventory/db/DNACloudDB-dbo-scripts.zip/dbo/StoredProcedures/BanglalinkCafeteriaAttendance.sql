

CREATE PROCEDURE [dbo].[BanglalinkCafeteriaAttendance]
(@MachineNo AS nchar(10), @from AS smalldatetime=getdate, @to AS smalldatetime=getdate,@filterselect AS nvarchar(max),@filterwhere AS nvarchar(max),@filtergroup AS nvarchar(max), @ReportType AS smallint)
as
BEGIN
SET NOCOUNT ON	
	--@ReportType: 0 in case of crystal report, 1 for alert sent to an employee , 2 for the alert sent to a manager
	-- used to change the query according to the caller
	---note: to test on hits database kindly change timesystem in the queries from 1 to 78
	-- as timesystem=1 at banglalink database 
	
	CREATE TABLE #tmptable(EmpId  int,EmployeeId  NVARCHAR(50),Name  nvarchar(250),AName nvarchar(250)
	,ManagerName nvarchar(250), ManagerAName nvarchar(250),eprefix nvarchar(30), fprefix nvarchar(30),aprefix nvarchar(30) 
	,ShiftNo smallint,EntryDate smalldatetime,
	ShiftIn datetime,ShiftOut  datetime,ShiftHours  numeric(18,3),TimeIn  datetime,[TimeOut] datetime,
	WorkingHours  numeric(18,3),tin  datetime,tout datetime,CafeteriaHours numeric(18,3))
															
	-- select all 'in' entries of the specified employee into a temp table, putting into account that the time calculated is within the date range and the specified time system

	
DECLARE @str AS nvarchar(max)
IF @ReportType=0 OR @ReportType=1
BEGIN
	SET @str=N' Insert INTO #tmptable SELECT empassignment.EmpId, empassignment.EmployeeId
	, Profile.Name, Profile.AName,'''' as ManagerName,'''' as ManagerAName
	, isnull(ltrim(rtrim(prefix.edesc)),'''') as eprefix,isnull(ltrim(rtrim(prefix.fdesc)),'''') as fprefix,isnull(ltrim(rtrim(prefix.adesc)),'''') as aprefix
, EmpShiftInOut.ShiftTimeNo, EmpShiftInOut.EntryDate 
,EmpShiftInOut.ShiftIn,EmpShiftInOut.ShiftOut
, datediff(minute, EmpShiftInOut.ShiftIn, EmpShiftInOut.ShiftOut) AS ShiftHours
,EmpShiftInOut.TimeIn, EmpShiftInOut.TimeOut
,datediff(minute, EmpShiftInOut.TimeIn, EmpShiftInOut.TimeOut) AS WorkingHours 
, EmpTimeReadings.AttendTime AS tin 
,NULL AS tout
,0. AS CafeteriaHours 
FROM empassignment
INNER JOIN Profile ON Profile.ProfileId = empassignment.EmpId 
left join nasarrays prefix on prefix.itemno=Profile.NamePrefix and prefix.arrayname=''nameprefix'' 
INNER JOIN EmpShiftInOut ON EmpShiftInOut.EmpId = empassignment.EmpId AND  EmpShiftInOut.EntryDate BETWEEN '''+convert(nvarchar(20),@from)+''' AND '''+convert(nvarchar(20),@to)
+''' INNER JOIN EmpTimeReadings ON EmpTimeReadings.EmpId = EmpShiftInOut.EmpId AND EmpTimeReadings.Inactive=0
AND  EmpTimeReadings.FlagValue =(select LineValues from TimeSystemLines where TimeSystem=EmpTimeReadings.TimeSystem and TimeLineType=1)  AND ((EmpTimeReadings.AttendTime BETWEEN EmpShiftInOut.ShiftIn AND EmpShiftInOut.ShiftOut) 
OR (EmpTimeReadings.AttendTime BETWEEN EmpShiftInOut.timein AND EmpShiftInOut.timeout)) 
where EmpTimeReadings.ReaderValue = '''+@MachineNo+''' and EmpTimeReadings.TimeSystem=1 '	



END
IF @ReportType=2
BEGIN
	DECLARE @ManagerId AS nvarchar(100)
	SELECT @ManagerId=substring(@filterwhere,charindex('SSGroupRole.ProfileId',@filterwhere),len(@filterwhere)) 
SELECT @ManagerId=replace(replace (@ManagerId,'SSGroupRole.ProfileId=',' '),')','')
--PRINT @ManagerId

	SET @str=N' Insert INTO #tmptable SELECT distinct empassignment.EmpId, empassignment.EmployeeId, '
+'Profile.Name, Profile.AName,Managers.Name as ManagerName,Managers.AName as ManagerAName, '
+'isnull(ltrim(rtrim(prefix.edesc)),'''') as eprefix,isnull(ltrim(rtrim(prefix.fdesc)),'''') as fprefix,isnull(ltrim(rtrim(prefix.adesc)),'''') as aprefix,'
+'EmpShiftInOut.ShiftTimeNo, EmpShiftInOut.EntryDate '
+',EmpShiftInOut.ShiftIn,EmpShiftInOut.ShiftOut'
+',datediff(minute, EmpShiftInOut.ShiftIn, EmpShiftInOut.ShiftOut) AS ShiftHours'
+',EmpShiftInOut.TimeIn, EmpShiftInOut.TimeOut'
+',datediff(minute, EmpShiftInOut.TimeIn, EmpShiftInOut.TimeOut) AS WorkingHours '
+', EmpTimeReadings.AttendTime AS tin ,NULL AS tout'
+',0. AS CafeteriaHours '
+'FROM empassignment INNER JOIN Profile ON Profile.ProfileId = empassignment.EmpId '
--+'inner join SSGroupRole on Empassignment.SSGroup=SSGroupRole.ssgroup '    --SSGroupRole.profileid 
+'left join Profile Managers on  Managers.profileid='+@ManagerId+' 
left join nasarrays prefix on prefix.itemno=Managers.NamePrefix and prefix.arrayname=''nameprefix'' 
INNER JOIN EmpShiftInOut ON EmpShiftInOut.EmpId = empassignment.EmpId AND  EmpShiftInOut.EntryDate BETWEEN '''+convert(nvarchar(20),@from)+''' AND '''+convert(nvarchar(20),@to)
+''' INNER JOIN EmpTimeReadings ON EmpTimeReadings.EmpId = EmpShiftInOut.EmpId AND EmpTimeReadings.Inactive=0
AND  EmpTimeReadings.FlagValue =(select LineValues from TimeSystemLines where TimeSystem=EmpTimeReadings.TimeSystem and TimeLineType=1)  AND ((EmpTimeReadings.AttendTime BETWEEN EmpShiftInOut.ShiftIn AND EmpShiftInOut.ShiftOut) 
OR (EmpTimeReadings.AttendTime BETWEEN EmpShiftInOut.timein AND EmpShiftInOut.timeout)) 
where EmpTimeReadings.ReaderValue = '''+@MachineNo+''' and EmpTimeReadings.TimeSystem=1 '-- and Managers.ProfileId='+@ManagerId+' '	

END

--PRINT @str
--PRINT @filterwhere
EXEC(@str+@filterwhere)



DECLARE @eid AS int, @entryDate AS smalldatetime, @tin AS datetime, @tout AS datetime, @ShiftIn as datetime, @ShiftOut as datetime, @TimeIn as datetime, @TimeOut as datetime
DECLARE @toutprev AS datetime

create  table #tempOut (empid  int ,AttendTime datetime )
insert into #tempOut select etr2.empid,etr2.AttendTime  FROM 
 EmpTimeReadings etr2 

--SELECT etr2.empid,etr2.AttendTime into #tempOut FROM 
-- EmpTimeReadings etr2 
WHERE
 etr2.FlagValue=(SELECT TimeSystemLines.LineValues from TimeSystemLines where TimeSystem=etr2.TimeSystem AND TimeLineType=2)  
 AND  etr2.AttendTime BETWEEN @from  AND dateadd(day,1,@to)
 AND etr2.Inactive=0
 AND etr2.ReaderValue = @MachineNo  and etr2.TimeSystem=1


--loop in a cursor on each record in the table, while updating the output field
DECLARE mycursor CURSOR FOR (SELECT EmpId, EntryDate, tin, ShiftIn, ShiftOut, TimeIn, TimeOut  FROM #tmptable) 
OPEN mycursor
FETCH next FROM mycursor
INTO @eid, @entryDate, @tin, @ShiftIn, @ShiftOut, @TimeIn, @TimeOut

--print @eid
--print @entrydate
--print @tin

WHILE @@FETCH_STATUS = 0
BEGIN



SET @toutprev=@tout
--select the output as the top 'out' entry that directly follows the current record's 'in' entry
SET @tout=(SELECT TOP 1 etr2.AttendTime FROM
 #tempOut etr2 
WHERE
 etr2.EmpId=@eid
 AND etr2.AttendTime > @tin 
AND ((etr2.AttendTime BETWEEN @ShiftIn AND @ShiftOut) OR (etr2.AttendTime BETWEEN @TimeIn AND @TimeOut))   

ORDER BY etr2.AttendTime asc
)



--PRINT'toutprev:'
--PRINT @toutprev
--
--PRINT 'tout:'
--PRINT @tout

-- case there are 2 'in' entries followed by 1 'out' entry, remove the 2nd entry
IF @tout=@toutprev AND @tout IS NOT NULL 
BEGIN
	DELETE FROM #tmptable WHERE #tmptable.EmpId=@eid
	AND #tmptable.tin = @tin 
	AND #tmptable.entryDate=@entryDate
END	
ELSE
 --else update the 'out' fields 

	BEGIN
		UPDATE #tmptable 
		SET tout=@tout 
		WHERE #tmptable.EmpId=@eid
		AND #tmptable.tin = @tin 
		AND #tmptable.entryDate=@entryDate		
	END


FETCH next FROM  mycursor
INTO @eid, @entryDate, @tin, @ShiftIn, @ShiftOut, @TimeIn, @TimeOut
END

CLOSE mycursor
DEALLOCATE mycursor


UPDATE #tmptable SET CafeteriaHours=isnull(datediff(minute,tin,tout),0)

--
--PRINT @filterselect
--PRINT @filtergroup

DECLARE @strselect AS nvarchar(max), @strgroup AS nvarchar(max)
	
		SET @strselect='SELECT isnull(ltrim(rtrim(#tmptable.eprefix)),'''') as eprefix,isnull(ltrim(rtrim(#tmptable.fprefix)),'''') as fprefix
		,isnull(ltrim(rtrim(#tmptable.aprefix)),'''') as aprefix,#tmptable.EmpId,#tmptable.EmployeeId,#tmptable.Name  ,#tmptable.AName  ,#tmptable.EntryDate ,#tmptable.ShiftNo,'
	+'#tmptable.ShiftIn ,#tmptable.ShiftOut,#tmptable.ShiftHours  ,#tmptable.TimeIn  ,#tmptable.TimeOut ,'
	+'#tmptable.ManagerName,#tmptable.ManagerAName,'
	+'#tmptable.WorkingHours  ,#tmptable.tin  ,#tmptable.tout ,#tmptable.CafeteriaHours,dbo.Greg2Hijri(#tmptable.EntryDate,''E'') as h_EntryDate,(CASE WHEN Sysparam.DateFormat = 0 THEN ''yyyy/MM/dd'' WHEN Sysparam.DateFormat = 1 THEN ''dd/MM/yyyy'' ELSE ''MM/dd/yyyy'' END) AS DateFormat '+@filterselect	
	+ ' FROM #tmptable '
+'LEFT JOIN EmpAssignment on #tmptable.empid=EmpAssignment.empid '
+'left join Profile on EmpAssignment.empid=Profile.ProfileId '
+'left join nasarrays prefix on prefix.itemno=Profile.NamePrefix and prefix.arrayname=''nameprefix'' '
+'LEFT JOIN Employer ON EmpAssignment.EmployerId = Employer.EmployerId '
+'LEFT JOIN Positions ON EmpAssignment.PositionNo = Positions.PositionNo '
+'LEFT JOIN TimeRules ON EmpAssignment.TimeRule = TimeRules.TimeRule '
+'LEFT JOIN VacPack ON EmpAssignment.VacPack = VacPack.VacPack '
+'LEFT JOIN SsRules ON EmpAssignment.SsCode = SsRules.SsCode '
+'LEFT JOIN ContractType ON EmpAssignment.ContractType = ContractType.ContractType '
+'LEFT JOIN HrStatus ON EmpAssignment.HrStatus = HrStatus.HrStatus '
+'LEFT JOIN TaxRules ON EmpAssignment.TaxCode = TaxRules.TaxCode  '
+'LEFT JOIN SSGroup ON EmpAssignment.SSGroup = SSGroup.SSGroup '
+'LEFT JOIN Jobs ON EmpAssignment.Job = Jobs.Job '
+'LEFT JOIN JobCat ON JobCat.JobCat = Jobs.JobCat '
+'LEFT JOIN Location ON EmpAssignment.LocationNo = Location.LocationNo '
+'LEFT JOIN Grades ON EmpAssignment.Grade = Grades.Grade '
+'LEFT JOIN PayrollGroup ON EmpAssignment.PayrollGroup = PayrollGroup.PayrollGroup '
+'LEFT JOIN CostCntr ON CostCntr.Center = EmpAssignment.Center '
+'LEFT JOIN CostCGrp ON CostCGrp.CenterGrp = CostCntr.CenterGrp '
+'LEFT JOIN Organization ON EmpAssignment.Organization = Organization.Organization '
+'LEFT JOIN OrganizationType ON OrganizationType.OrganizationType = Organization.OrganizationType '
+'LEFT JOIN OrganizationStructure ON Organization.Organization = OrganizationStructure.Organization '
+'LEFT JOIN Organization Organization_1 ON Organization_1.Organization = OrganizationStructure.Organization1 '
+'LEFT JOIN Organization Organization_2 ON Organization_2.Organization = OrganizationStructure.Organization2 '
+'LEFT JOIN Organization Organization_3 ON Organization_3.Organization = OrganizationStructure.Organization3 '
+'LEFT JOIN Organization Organization_4 ON Organization_4.Organization = OrganizationStructure.Organization4 '
+'LEFT JOIN Organization Organization_5 ON Organization_5.Organization = OrganizationStructure.Organization5 '
+'LEFT JOIN NasArrays Status ON EmpAssignment.Status = Status.itemno AND Status.arrayname = ''Status'' '
+'LEFT JOIN NasArrays HrScStatus ON HrScStatus.itemno=EmpAssignment.HrScStatus AND HrScStatus.arrayname=''ScStatus'' '
+'LEFT JOIN NasArrays TaxStatus ON TaxStatus.itemno = EmpAssignment.TaxStatus AND TaxStatus.arrayname = ''TaxStatus'' '
+'LEFT JOIN NasArrays HrTaxstat ON HrTaxStat.itemno = EmpAssignment.HrTaxStat AND HrTaxStat.arrayname = ''TaxStatus'' '
+'LEFT JOIN NasArrays ScStatus ON ScStatus.itemno = EmpAssignment.ScStatus AND ScStatus.arrayname = ''ScStatus'' '
+'cross join sysparam '
SET @strgroup='GROUP BY #tmptable.aprefix,#tmptable.fprefix,#tmptable.eprefix,#tmptable.EmpId,#tmptable.EmployeeId ,#tmptable.Name  ,#tmptable.AName  ,#tmptable.EntryDate ,#tmptable.ShiftNo,'
	   +'#tmptable.ShiftIn ,#tmptable.ShiftOut,#tmptable.ShiftHours  ,#tmptable.TimeIn  ,#tmptable.TimeOut ,'
	+'#tmptable.WorkingHours  ,#tmptable.tin  ,#tmptable.tout ,#tmptable.CafeteriaHours, #tmptable.ManagerName , #tmptable.ManagerAName ,Sysparam.DateFormat '+@filtergroup
PRINT @strselect
PRINT @strgroup
EXEC(@strselect+@strgroup)
	
	


--drop table #tempOut
--DROP TABLE #tmptable

END

GO

