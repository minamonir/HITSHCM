
CREATE PROCEDURE [dbo].[AI_InsertComptences](@AppraisalName as nvarchar(max),@CompetenceName as nvarchar(max),@CompetenceDescription as nvarchar(max),@RatingScale as smallint,@Weight as numeric(18,3),@CompetenceCategory as smallint,	@logonName as NVARCHAR(MAX)='')

AS
BEGIN
	declare @CompetenceNo as smallint=0
	set @CompetenceNo = isnull((select top 1 Competencies.Competence from Competencies where ltrim(rtrim(Competencies.CompetenceName))=ltrim(rtrim(@CompetenceName)) or ltrim(rtrim(Competencies.CompetenceAName))=ltrim(rtrim(@CompetenceName))),0)

	set @RatingScale = case when @RatingScale=0 then null else @RatingScale end

if @CompetenceNo =0
begin
CREATE TABLE #StoredResult4 (
					PrimaryKey INT,
					IsUEnterByExists INT,
					OrgsColumn INT
				);
 
				INSERT INTO #StoredResult4
				EXEC [dbo].[GetMaxPrimaryKey] @TableName = N'Competencies', @PkFieldName = N'Competence', @LogonName = '1';
 
				SELECT @CompetenceNo = PrimaryKey FROM #StoredResult4;
drop table #StoredResult4
INSERT INTO [dbo].[Competencies]
           ([Competence]
          ,[CompetenceCategory]
           ,[CompetenceName]
           ,[CompetenceAName]
           ,[CompetenceFName]
           ,[CompetenceDesc]
           ,[CompetenceADesc]
           ,[CompetenceFDesc]
           ,[RatingScale]
           --,[Behavior]
           --,[ABehavior]
           --,[FBehavior]
           --,[RatingEvery]
           --,[RatingLength]
           --,[CompetenceCons]
           --,[CompetenceNameCons]
           --,[CompetenceANameCons]
           --,[CompetenceFNameCons]
           --,[CompetenceFromDate]
           --,[CompetenceToDate]
           --,[CompetenciesRoles]
           --,[CompetenciesOrgs]
           --,[CompetenciesRYear]
           --,[CompetenciesRNo]
           --,[CompetenciesRIssueDate]
           --,[CompetenciesRExecDate]
           --,[CompetenciesRStatus]
           --,[CompetenciesRSource]
           --,[CompetenciesRDesc]
           --,[CompetenciesGUID]
           ,[UEnterBy]
           ,[UEnterDate]
           --,[UChangeBy]
           --,[UChangeDate]
           --,[ReviewedBy]
           --,[ReviewedDate]
           --,[ApprovedBy]
           --,[ApprovedDate]
           --,[CodeStatus]
           --,[CompetenciesOrder]
		   )
     VALUES
           (@CompetenceNo
           ,@CompetenceCategory
           ,@CompetenceName
           ,@CompetenceName
           ,@CompetenceName
           ,@CompetenceDescription
           ,@CompetenceDescription
           ,@CompetenceDescription
           ,@RatingScale
           --,<Behavior, nvarchar(max),>
           --,<ABehavior, nvarchar(max),>
           --,<FBehavior, nvarchar(max),>
           --,<RatingEvery, int,>
           --,<RatingLength, smallint,>
           --,<CompetenceCons, int,>
           --,<CompetenceNameCons, nvarchar(250),>
           --,<CompetenceANameCons, nvarchar(250),>
           --,<CompetenceFNameCons, nvarchar(250),>
           --,<CompetenceFromDate, smalldatetime,>
           --,<CompetenceToDate, smalldatetime,>
           --,<CompetenciesRoles, nvarchar(max),>
           --,<CompetenciesOrgs, nvarchar(max),>
           --,<CompetenciesRYear, smallint,>
           --,<CompetenciesRNo, nvarchar(10),>
           --,<CompetenciesRIssueDate, datetime,>
           --,<CompetenciesRExecDate, datetime,>
           --,<CompetenciesRStatus, smallint,>
           --,<CompetenciesRSource, smallint,>
           --,<CompetenciesRDesc, nvarchar(max),>
           --,<CompetenciesGUID, uniqueidentifier,>
           ,@logonName
           ,GETDATE()
           --,<UChangeBy, nvarchar(80),>
           --,<UChangeDate, smalldatetime,>
           --,<ReviewedBy, nvarchar(80),>
           --,<ReviewedDate, smalldatetime,>
           --,<ApprovedBy, nvarchar(80),>
           --,<ApprovedDate, smalldatetime,>
           --,<CodeStatus, int,>
           --,<CompetenciesOrder, int,>
		   )
end
else
begin
update [Competencies] set CompetenceName=@CompetenceName, CompetenceDesc=@CompetenceDescription,RatingScale=@RatingScale,CompetenceCategory=@CompetenceCategory,UChangeBy=@logonname ,UChangeDate=GETDATE() where Competence=@CompetenceNo
end

declare @AppraisalNo as smallint=0
set @AppraisalNo = isnull((select top 1 Appraisals.AppraisalNo from Appraisals where ltrim(rtrim(AppraisalName))=ltrim(rtrim(@AppraisalName)) or ltrim(rtrim(AppraisalAName))=ltrim(rtrim(@AppraisalName))),0)

if not exists(select * from AppraisalCompetencies where AppraisalNo=@AppraisalNo and Competence=@CompetenceNo)
begin
INSERT INTO [dbo].[AppraisalCompetencies]
           ([AppraisalNo]
           ,[Competence]
           ,[Weight]
           ,[CompetenceOrder])
     VALUES
           (@AppraisalNo
           ,@CompetenceNo
           ,@Weight
           ,0)

end
else
begin
update AppraisalCompetencies set Weight=@Weight where AppraisalNo=@AppraisalNo and Competence=@CompetenceNo
end


END

GO

