CREATE SEQUENCE [dbo].[CountBy]
    AS BIGINT
    START WITH 1
    INCREMENT BY 1;


GO

